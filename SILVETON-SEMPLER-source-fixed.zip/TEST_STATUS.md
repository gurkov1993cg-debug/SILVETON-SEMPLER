# SILVETON SAMPLER — R4 Direct-ALSA MIDI verification

## R4-DIRECT-ALSA-MIDI — 2026-10-03
- Sampler MIDI data path changed from Android `android.media.midi` to native Direct-ALSA raw MIDI.
- Native runtime scans `/dev/snd/midiC*D*`, configures input with `SNDRV_RAWMIDI_IOCTL_PARAMS`, reads with `poll/read`, merges up to 16 raw-MIDI ports on one native thread, parses running status and dispatches Note On/Off, CC, Channel Pressure and Pitch Bend directly into `SamplerEngine`.
- `SamplerMidiController.kt` is status-only and no longer opens Android MIDI devices; its MIDI count/error display comes from the native raw-MIDI backend.
- Direct MIDI contract audit: 14/14 PASS.
- Direct ALSA audio contract audit: PASS.
- GUI/JNI contract audit: 103/103 PASS.
- Core Release tests: 3/3 PASS.
- Core ASan+UBSan tests: 3/3 PASS.
- Host C++ syntax/warnings check for `SamplerAudioBridge.cpp`: PASS with `-Wall -Wextra -Wpedantic -Wshadow -Werror`.
- NOT YET PROVEN: Android NDK/APK build of this exact R4 tree and physical open/read permission for `/dev/snd/midiC*D*` on SM-X130 under its SELinux policy. No Android-MIDI fallback is used in the sampler runtime.

---

# SILVETON-LIVE-MIDI Test Status — v0.9.7-GOLD-V1.1

## v0.9.7-GOLD-V1.1 — GOLD V1 (= A11.6) + Ribbon range law
- User: sometimes the Ribbon gives only 1 semitone and the keyboard wheel ends up on 2; they must
  not affect each other. Log 02:02: the blend reported range 1/1/0 on the Sound change (0:14); the
  PA600's reset of all channels (0:16) reported 2; the app took 2 as the blend's range, skipped the
  Ribbon range write (max(Rr, B) == "B") and after the Ribbon restored 2 instead of 1.
- Law (core, MidiRouter): while the Ribbon is in use R = B + Rr is always written (never assumed),
  Pitch Bend = 8192 * (w*B + s) / R, so the wheel gives exactly w*B and the Ribbon exactly s and
  |w*B + s| <= R never clips. At rest R = B. B is learned only from RPN 0 that follows a Program
  Change on that Upper within 150 ms; the reset report never changes B (the app re-asserts its R
  if the Ribbon is in use). Kotlin, portamento, TERCA, TRANSPOSE and the note path unchanged.
- Check (real core, model of the PA600 range): 5 460 wheel x Ribbon combinations, B 0..12,
  RANGE 1..12: error <= 0.0015 semitones, range back to the blend after rest in all.
  GOLD V1 on the same check: 1 009 off by more than 1 cent (clipping / skipped writes, worst 12 st).
  Log case (blend 1/1/0, reset says 2, RANGE 3): Ribbon use R 4/4/3, full right +3.000 st,
  after rest 1/1/0 (GOLD V1: 2/2/2).
- Core tests updated to the law (PC before RPN, like the PA600); all pass, fuzz 0 failures,
  also under ASan + UBSan. NOT tested on a PA600.

## v0.9.7-A11.6 — A11.5 + key count law (no phantom note after a wrong-key release)
- User (log 01:31, A11.3): a note keeps sounding; Korg Shift+Start/Stop does not stop it,
  the app PANIC does. The log: mono Sound, D#5 held, E5 pressed and released, D#5 released ->
  the PA600 sent "E5 off" twice and never "D#5 off"; MONO kept D#5 and played it after every
  release until PANIC. Same in 5 places, not only semitones (3 and 5 semitones in 28.09 logs).
- Law: per channel keys down = presses - releases (the PA600 can name the wrong key, never
  lose or add one; velocity-64 PA600 releases excluded). The app's held set always has that
  size: a release naming a key not held releases the held key pressed last before it (else the
  last pressed). All keys up -> set empty -> nothing can sound. EchoGuard (Kotlin) only; core,
  portamento, ribbon, TERCA, TRANSPOSE unchanged.
- Simulation, real EchoGuard + a11 core, all 20 user logs: stuck notes A11.5 -> A11.6:
  01:31 18 (14.5 s) -> 0; 20:33 20 -> 0; 20:03 6 -> 0; 19:13 12 -> 0; 21:55 1 -> 0; others 0.
  Cut-while-held unchanged everywhere except one old 0.8.6 echo log (+1, 0.1 s).
- Synthetic, 60 x 6000 events, 1..5 keys held, intervals 1..24 up/down, 30 % wrong-key releases
  naming an already released key: stuck A11.5 46 811 (6 909 s) -> 0; brief gaps while a key is
  held 1 -> 29 (3.4 s total). NOT tested on a PA600.


## v0.9.7-A11.5 — A11.4 without the periodic Coarse Tune resend
- User: nothing extra may be sent while playing with both hands. Coarse Tune for the style is
  now sent only when TRANSPOSE is pressed, on connect and when U1's Sound/Performance changes
  (Program Change report, transposed only). The 4 s repeat is removed. Kotlin compiles.


## v0.9.7-A11.4 — TEST: the style follows the app TRANSPOSE (RPN Coarse Tune)
- User: with the app TRANSPOSE the style stayed in the old key (the PA600 reads chords from its
  own keys; no chord MIDI channel on the PA600).
- The app sends RPN 2 Coarse Tune = TRANSPOSE on MIDI channels 5..10 (PA600 MIDI IN: Ch05 Bass,
  Ch06..Ch10 Acc1..Acc5; OUT off). One channel every 3 ms, on change, on connect and every 4 s
  while transposed. Never on an Upper/Lower channel. Drums untouched. Kotlin only.
- Checked: message bytes (B4 65 00 / 64 02 / 06 40+T / 26 00 / 65 7F / 64 7F), channels never
  1..4; transposer simulation unchanged (1 440 141 notes, 0 hanging, 0 wrong pitch).
- UNKNOWN until tested on the PA600: whether style parts apply received Coarse Tune.


## v0.9.7-A11.3 — A11.2 with the screen rotated to the other side
- User asked: landscape turned 180° (reverseLandscape in the manifest and in MainActivity).
  Nothing else changed. Kotlin compiles; core unchanged. NOT tested on a phone.


## v0.9.7-A11.2 — A11.1 + app TRANSPOSE, bigger keys, SENSITIVITY value, TIME default 10 ms
- TRANSPOSE -12..+12 above the ribbon (approved preview 23:54-00:04). The app shifts every
  note it returns (Uppers + Lower) and remembers each note's wire pitch: a release always goes
  to the pitch its Note On used, whatever the transpose is now; changes affect new notes only.
  TERCA / MONO / portamento work on the played keys (unchanged). Saved between sessions.
  The PA600's own Transpose stays at 0 (KORG_SETUP.md updated). Kotlin only; core = A11.1.
- Ribbon row: RANGE / SENSITIVITY / TRANSPOSE keys bigger (height +48 %), SENSITIVITY value
  shown above its slider, buttons step 0.05 (was 0.10); the ribbon moved down (same width).
- Portamento TIME default 10 ms (slider 12) when no value is saved yet.
- Simulation (real OctaveCompensator + core, PA600 Transpose 0, 400 sessions, fast and normal,
  mono legato with portamento/TERCA and poly chords, transpose changed ~12 000 times at random
  moments incl. while holding): 2 880 282 notes, 0 left sounding, 0 wrong pitch, 0 cut.
  Control (transposer without note memory, like the PA600): 48 939 left sounding.
- CoreTests, FuzzTests (core unchanged), Kotlin compiles, screen rendered and compared with the
  approved preview. NOT tested on a PA600.


## v0.9.7-A11.1 — golden A11 + unused code removed (nothing else)
- User asked: the golden A11 without the code that is never executed. Only the A13 clean-up is
  applied on A11 (none of A12/A14/A15): legacy Pitch Bend portamento engine and its glide lane,
  Local ON leftovers, unused parameters, unused Kotlin (setUpperChannel, channelMap1Based,
  sender helpers/note sets, unused colours, calibration flag), 2 JNI functions; the log label
  is built only when MIDI LOG / trace is on. The stored calibration of older versions is kept.
- Transpose sticking: solved on the PA600 by Global > Tuning > Transpose Control >
  "Transpose applies to Midi In notes" ON (user confirmed 21:12).
- Equivalence to A11: 21 user logs, 309 405 messages -> identical output. 30 random sessions
  with ribbon/transport/portamento/TERCA: identical notes and settled pitch on every Upper.
- CoreTests, FuzzTests, ASan+UBSan, g++/clang++ strict JNI, Kotlin compiles. NOT tested on a PA600.


## v0.9.7-A11 — notes from the PA600 jump the MIDI thread queue
- User: LATENCY up to 5 ms with portamento + TERCA + ribbon together. Incoming packets now go
  to the front of the MIDI thread queue (ahead of the 2 ms ribbon/glide polls); a FIFO queue
  keeps their order (no Note On/Off reordering). Kotlin only; core unchanged.


## v0.9.7-A10 — A9 with the ribbon rest timing of the golden A7
- User (log 12:59): ribbon works, no stuck notes, but the ribbon range changed after a blend
  change. A9 kept the raised range 1.5 s after the last touch; a blend change inside that time
  resets the Sound's range on the PA600 without the app writing it again. Back to 0.25 s as in
  A7. Sub-cent skip and spread range writes stay. Kotlin only; core unchanged.


## v0.9.7-A9 — A8 + latency readout + lighter ribbon traffic (user approved)
- LATENCY readout left of the MIDI pill: real measurement per Note On, from Android's arrival
  timestamp of the PA600 packet to the moment the note is sent back; average of the last 32,
  updated at most twice a second; hidden when not connected. (USB + PA600 time not included.)
- Ribbon lighter, same sound:
  * steps smaller than 1 cent are not sent while the ribbon moves; the rest value is always
    sent exactly (new CoreTest: slow drag -> no step < 1 cent, < 110 messages per Upper instead
    of ~2000, rest = 8192 on every Upper);
  * RPN 0 range writes on engage are spread: U1 at once, U2/U3 on the next polls (6 messages at
    a time instead of 21); rest restores all at once;
  * the raised range goes back only after 1.5 s without a touch (was 0.25 s), so quick repeated
    touches send no range writes.
- Software-checked: CoreTests + FuzzTests (Release, ASan+UBSan), g++/clang++ strict -Werror on
  core and JNI, Kotlin compiles, screens rendered. NOT tested on a PA600.


## v0.9.7-A8 — golden A7 with unused code removed (no change in behaviour)
- Removed: PITCH TEST (RPN tuning probe) and PORTA CALIBRATE (microphone) from the settings,
  PortaCalibration.kt, GlideAnalyzer (+ its tests), RECORD_AUDIO permission. A calibration
  stored by an older version is still applied, so the portamento sounds exactly as before.
- Removed: ribbon TUNING output (core, JNI, Kotlin, tests).
- Removed: Local Control ON mode (core branches, JNI, Kotlin, its tests). The app always
  bridges with Local OFF, exactly the path that stays.
- Removed: hidden ribbon modes (relative, hold, rounding, invert) and the unused legacy ribbon
  JNI calls. New Ribbon = absolute + return only; compared against the old Ribbon on 900 000
  random steps: output identical (max difference 0).
- Settings screen: right column now PORTA BALANCE + MIDI LOG. Main screen pixel-identical to A7.
- Software-checked: CoreTests + FuzzTests (Release, ASan+UBSan), g++/clang++ strict -Werror on
  core and JNI, Kotlin compiles. NOT tested on a PA600.


## v0.9.7-A7 — on BASE-v0.9.7-A2 (Pitch Bend ribbon, option A), old HQ ribbon feel
- User chose option A: the ribbon stays on Pitch Bend exactly as in A2 (RPN 0 raised to the
  ribbon RANGE only while the ribbon is used, the blend's value restored on rest).
- From the user's spec: smoothMs 36 / returnMs 60 (old HQ feel), centre dead zone 0.008,
  ribbon RANGE 1..12 (default 2). The critically damped follow formula was already identical.
- The TUNING path of A4/A6 is not used (PA600 glitch at +/-1 st, coarse tuning step).
- New golden test: ribbon follow matches the HQ trajectory step by step, no overshoot.
- Software-checked: CoreTests + FuzzTests (Release, ASan+UBSan), g++/clang++ -Wall -Wextra
  -Wpedantic -Wconversion -Wshadow: 0 warnings, Kotlin compiles. NOT tested on a PA600.


## v0.9.7-A2 — new look (approved from previews), on top of v0.9.7-A1
- Title: SILVETON (brushed steel) + "keyboard processor" (small letters) + "version 1" plate.
- Hardware look: machined faceplates, keys with status LEDs, engraved title rules, metal knob
  caps in a dark groove, fine background grain (small tile). Bigger TIME/SENSITIVITY knobs
  (SENSITIVITY grab zone a bit taller). Static layer + GPU drawing kept: ~7.5 ms/frame (JVM
  bench) while dragging. Only LiveMidiView.kt changed; MIDI code untouched.


## v0.9.7-A1 — golden v0.9.7-A, notes returned without octave shift
- User's PA600 (photo): Midi In Octave Transpose OFF, Track Mute Active OFF, Upper/Lower Trk
  Octave Transp 0. With these the PA600 plays received notes exactly as received, so the
  app's global +12 moved both hands. OctaveCompensator(12) -> (0): notes go back exactly as the
  PA600 transmitted them. Only this line changed (MidiController.kt).


## v0.9.7-A — locked v0.9.7 + ribbon ABSOLUTE (approved by the user in the simulator)
- Base: STABLE-v0.9.7, unchanged. Only RibbonConfig.fixed(): relative = false, so the finger
  position is the pitch exactly on the drawn semitone lines (centre 0, ends ±RANGE), anywhere
  on the strip; release returns to 0. Core Ribbon absolute mode and the screen are the same as
  in v0.9.7. versionCode 38 so it installs over any earlier build.


## v0.9.7 — smooth screen (user: app got heavy and stutters)
- LiveMidiView: static parts drawn once into a bitmap (redrawn only when their state changes);
  per frame only the TIME value/slider, SENSITIVITY slider and ribbon wheel are drawn, with
  preallocated paints and no allocations; LAYER_TYPE_SOFTWARE removed (GPU rendering);
  knob shadow and wheel halo use cached gradients instead of blur.
- JVM benchmark of the same drawing code (Java2D stand-in): 76.5 -> 6.9 ms per frame while
  dragging the ribbon. Screen pixel-comparable to v0.9.6 (band ends now square, under the wheel).
- Only LiveMidiView.kt changed; MIDI, portamento, TERCA, octave untouched.

## v0.9.6 — approved by the user from previews
- Portamento TIME slider: 1..100 ms, linear (PortaTime). Portamento code itself unchanged.
- Ribbon: SETUP removed; only RANGE and SENSITIVITY. Fixed smooth behaviour (smooth 60 ms,
  return 120 ms), mode kept as it was (RELATIVE by default), Pitch Bend output, no hold/rounding.
- Ribbon strip graduated: a line on every semitone where it sounds (RANGE + SENSITIVITY), numbers
  above the lines, centre 0. Bigger ribbon wheel. Title in one colour, medium weight.
- Dead code of the removed ribbon setup and arrows deleted (screen pixel-identical).
- C++ core, JNI, MidiController, octave, TERCA: unchanged from v0.9.5.

## v0.9.5 — modern look (approved by the user from previews)
- Based on the v0.9.3 look: glass cards (shadow, top sheen, bevel hairline), pill buttons with
  a top highlight, brand wave mark before the title, ribbon band from centre to the marker.
- Bigger ribbon marker, bigger TIME/SENSITIVITY knobs (thicker tracks, TIME grab zone follows),
  bigger TERCA SCAN / ON-OFF buttons.
- Unneeded labels removed: calibration line, "BLEND ·" prefix, "NO TONALITY", ribbon mode
  caption, RIBBON SETUP hint line.
- No button added or removed; MIDI code untouched.

## v0.9.4 — original look back, cosmetic size changes only
User did not like the v0.9.3 restyle -> LiveMidiView back to the v0.9.2 look, plus:
- Ribbon marker bigger (radius 0.036 -> 0.048).
- TIME and SENSITIVITY slider knobs bigger (0.025 -> 0.034), track slightly thicker; TIME grab
  zone follows the bigger knob.
- TERCA SCAN and ON/OFF buttons bigger (same positions, larger area), labels a bit larger.
No button added or removed; MIDI code untouched.

## v0.9.2 — TERCA back on C4-C5
User: with the octave raised there is no TERCA from C5 down to C4.
Cause: the v0.8.6 accompaniment test (note < 60 on an Upper = raw) looked at the note numbers
the PA600 sends, which carry each Upper's octave (U3 at -1 sends keys C4-C5 as C3-C4), so those
keys bypassed TERCA. The PA600's own split already sends the left hand on the Lower channel,
which the app returns untouched, so the Upper-channel split is switched off
(NativeMidiEngine: setSplitNote(0)). Nothing else changed (TERCA/portamento/ribbon code same).


## v0.9.1 — Ribbon range independent of the blend's Pitch Bend
User: blend bend 1 + ribbon 1 -> the ribbon behaves like the blend's pitch; the two must be
completely separate.
- Ribbon (PITCH BEND output): while it is in use RPN 0 = max(Ribbon RANGE, blend range) on
  U1-U3, so the Ribbon always spans its own RANGE. The wheel keeps the blend's meaning inside
  it (composed). When the Ribbon rests (transport off), PANIC, or a Sound change while resting,
  RPN 0 goes back to EXACTLY the blend's reported value (fallback 2 if never reported).
  A Sound change while the Ribbon is in use re-writes the Ribbon range.
- Kotlin: the PA600's echo of a range the app wrote is not learned as the blend's range.
- Portamento, TERCA, octave: unchanged from v0.9.0.
Verification: new core test (ribbon 12 on a +-1 blend: RPN 12 on engage, wheel full = +1 st,
ribbon half = 12288, new sound while engaged -> 12 again, rest -> 2/1/1 exactly, ribbon range
below blend -> nothing written, TUNING never writes, PANIC restores); fuzz: after rest RPN 0
equals the blend's value on every Upper; 40k ASan/UBSan runs: 0 failures.


## v0.9.0 — base v0.8.6 + one octave up
User: take the version that removed the PORTA button (v0.8.6) as the base and add the octave.
- Everything is exactly v0.8.6 (core, portamento, ribbon, TERCA, EchoGuard, UI) plus one change:
  every Note On/Off the app sends to the PA600 goes out +12 semitones (OctaveCompensator(12),
  wire level; a Note Off uses its Note On's wire note). v0.8.7-v0.8.9 changes are not included.


## v0.8.6 — portamento only from the blend, octaves, accompaniment zone
- PORTA ON/OFF button removed: the portamento switch comes only from the selected Sound
  (CC65 report before its Program Change); the panel shows "BLEND · OFF" / "BLEND · U1 U3".
  The app sets only TIME (equal-time CC5 per note on the Uppers the blend has it on).
- Octaves in Local OFF: the log shows the PA600 transmits each Upper already octave-shifted
  (U2 = U1 - 12 for every key). With "Midi In Octave Transpose = On" the PA600 shifts it again
  on reception. Fix = PA600 Global > MIDI > MIDI In Controls > Midi In Octave Transpose = OFF
  (Pa600 Reference Manual). Documented in KORG_SETUP; the app does not compensate (it would
  double-correct once the setting is right).
- Accompaniment zone: keys below C4 (splitNote 60, measured on U1; U2/U3 mapped through their
  octave offset to U1, learned from the same key arriving on every Upper within 4 ms with the
  same velocity) are returned exactly as played — no MONO, TERCA, SCAN, portamento CC5 or glide.
  A Note Off follows the route its Note On took. The TERCA safety sweep never sends CC123 while
  accompaniment is held on U3.
Verification: new core tests (left-hand chord under PORTA stays a chord with no CC5, right hand
never cuts it, U2 octave offset learned, B3/D4 boundary, TERCA sweep keeps U3 accompaniment);
fuzz with split on/off at random; 40k ASan/UBSan runs: 0 failures.


## v0.8.5 — PORTAMENTO follows the blend
From the session log: on every Sound selection the PA600 sends, per Upper, CC65 (the Sound's
portamento switch) and CC5 immediately (< 1 ms) before the Program Change.
- The app reads CC65 when a Program Change follows within 150 ms (an older CC65 is an echo of
  the app's own button and is ignored) and follows it per Upper. Nothing is sent: the PA600
  has already switched. Piano blend -> PORTA OFF; blend with portamento -> ON on those Uppers.
- Per-Upper portamento: equal-time CC5 and automatic MONO only on the Uppers that have it.
- PORTA button OFF: CC65 0 only on the Uppers that had it (PA600 portamento off too).
  ON: back on the blend's Uppers; all three when the blend has none. UI shows e.g. "ON U1·U3".
- Previously the app re-sent CC65 127 to every Upper after each Program Change, which forced
  portamento onto blends that do not have it (piano). Removed.
- PORTA no longer restored from saved settings at start-up: the blend decides.
Verification: new core test block (mask follows reports, no output on reports, OFF/ON only on
the blend's Uppers, stale echo ignored, PC without report ignored); fuzz feeds random CC65/CC5
reports with on-time and late Program Changes — found a glide offset surviving a Sound change
(fixed: a Sound change always ends the old glide); 40k ASan/UBSan runs: 0 failures.


## v0.8.4 — blend pitch-bend range is never changed
User report: blend with bend range 1 -> touching the ribbon switched it to 2 (the app wrote
RPN 0 = 12 on touch and restored 2 on release).
- The app no longer writes RPN 0 (pitch-bend sensitivity) at all in Local OFF. All
  configurePitchBendRange calls removed (transport engage, ribbon rest, PANIC, PC re-sync).
- Blend-native pitch: on every sound change the PA600 reports RPN 0 (CC101=0, CC100=0, CC6=n);
  the app learns n per Upper (log: "BEND RANGE Un learned = n").
- The keyboard wheel passes exactly as the blend has it; the ribbon PITCH BEND output is
  scaled into the blend's own range and clamps at its end. Range 0 -> wheel passes unchanged.
  For a wider ribbon range use OUTPUT = TUNING (RPN 1/2, does not touch the blend's range).
Verification: new core tests (range 1: wheel 16383 stays 16383, ribbon +0.5 st = 12288, beyond
range clamps with no RPN, re-learn on new report, range 0 passthrough); fuzz asserts no RPN 0
write in blend-native Local OFF; 40k ASan/UBSan runs: 0 failures.


## v0.8.3 — fixes from the user's session log (2026-09-27, Xiaomi, Android 16, PA600)
Log findings (42 475 IN / 37 869 OUT, 0 send errors, bridge latency median 0.9 ms, p99 2.6 ms):
- The PA600 returns controllers it receives (CC#5 2106/2559 incoming were echoes, CC#123, RPN);
  the bridge returned them -> CC5 ping-pong -> loop breaker tripped at 468 s ("notes stick").
- At times the PA600 also returns NOTES it receives, with the track octave transpose applied
  (U2: A4 -> A3 -> A2 -> ... every ~6 ms; U3 thirds climbing to note 127): note loops.
- Note-offs sometimes arrive an octave away from the pressed note (on D5, off D6), and one
  release was lost completely (D5 pressed twice without a note-off) -> hanging notes.
- First session: the app never connected (no discovery info in that log version).
Fixes:
- BridgeFilter: in Local OFF only performance messages are returned (notes, pitch wheel,
  pressure, CC 1/2/4/11/64/66/67/68). Reports (Program Change, bank, volume, pan, effects,
  CC5/65, RPN/NRPN, All Notes/Sound Off) are never returned. Program Change still triggers the
  app's own re-sync.
- EchoGuard: identical CC sent within 30 ms dropped; note-on with the velocity of a note the app
  sent on that channel within 12 ms, same pitch or whole octaves away, dropped as echo; note-offs
  only for keys really held, octave-shifted offs corrected, a re-press without release first
  releases the key.
- Log: MIDI device discovery, open failures, dropped echoes and fixed releases are written.
Verification: replay of the real log through BridgeFilter+EchoGuard (JVM): normal playing
forwards 17 263 messages, drops 82 echoes/strays, fixes 110 releases, 0 notes left sounding.
C++ replay with a simulated echoing PA600: v0.8.2 -> runaway loop (>14 000 echoes/100 ms);
with the filter -> max 9-34 echoes/100 ms, all dropped. Core tests + fuzz unchanged and passing.


## v0.8.2
- App icon: elegant silver sound wave with a cyan tone line (variant C). Android 8+: gradient
  adaptive icon (drawable-v26); Android 6-7.1: solid-colour legacy vector.


## v0.8.1
- New app icon (adaptive vector + legacy): keys, cyan equal-time glide curve, purple terca line.
  Vector XML parsed and re-rendered for verification.


## v0.8.0 — every effect isolated
- PORTAMENTO default engine = KorgNative: CC65 ON + CC#5 before every note, chosen by
  KorgGlideModel (t = a(cc) + b(cc)*interval, inverted per interval) so every interval takes TIME.
  No Pitch Bend, no RPN. U3 (TERCA) gets its own CC#5 from the interval of the thirds.
  Program Change re-sync re-sends CC#5 + CC65. Legacy Pitch-Bend engine kept, tests pin it explicitly.
- Equal-time model: manual PORTA BALANCE (CC steps per doubling of glide time) or microphone
  calibration: YIN pitch tracker (GlideAnalyzer), glide measured between leaving the start pitch and
  settling on the target (threshold loss compensated), start pitch auto-detected (transposed Sounds),
  least-squares fit per CC#5 with monotonic b.
- MIDI LOG: session file in Download/Silveton MIDI Live (MediaStore on Android 10+), IN/OUT with ms
  timestamps and decoded meaning, UI actions, status, connect/disconnect, send failures, loop breaker.
- Tests: model inversion within one CC step, manual balance behaviour, router emits CC#5 before the
  note / no Pitch Bend / no RPN / no re-send for same interval / sync / disable CC65 0, TERCA U3 CC#5,
  analyzer on synthetic glides 60–1000 ms up/down 3 & 12 semitones (±6 % / 15 ms), transposed start,
  silence/no-glide rejected, fit exactness.
- Fuzz 40 000 (ASan/UBSan) with random portamento engine: 0 failures. JNI 29/29. Kotlin compiled.


## v0.7.1 — MIDI bandwidth fix ("notes stick")
- Root cause: with PORTAMENTO + RIBBON the app sent ~1350 msgs/s (Pitch Bend output) and
  ~5900 msgs/s (TUNING output) — above what a MIDI link can carry (~1000 msgs/s). Messages queued,
  Note Offs arrived late -> hanging/lagging notes.
- Fix: continuous-data budget. Pitch Bend <= 100 Hz per Upper (latest value wins, the resting
  value is always sent at once); ribbon TUNING <= 40 Hz, Data Entry only while RPN 1 stays selected,
  coarse steps lead in the direction of travel. Notes are never delayed.
  Measured: PB path <= 3 x 100 msgs/s; TUNING fast +-12 sweep ~375 msgs/s.
- FIX (found by fuzz): any RPN selection change (core RPN 0, Android RPN writes, (N)RPN CCs passing
  through from the PA600) now invalidates the tuning RPN selection, so a tuning Data Entry can never
  land in Pitch Bend Sensitivity. Fuzz now flags any unexpected Pitch Bend Sensitivity value.
- New test: bandwidth budget (PB <= 303 msgs/s with glides on 3 Uppers + fast ribbon; TUNING <= 450).
- Fuzz 40 000 (ASan/UBSan): 0 failures. JNI 24/24.


## v0.7.0 — RIBBON as an independent module
- `Ribbon` rewritten as a stand-alone module with its own settings: RANGE ±1..24, SENSITIVITY,
  MODE Relative/Absolute, RELEASE Return/Hold (tap clears), OUTPUT PitchBend/Tuning, INVERT,
  SMOOTH, RETURN, ROUNDING + ROUND RATE (average-based, vibrato preserved), ROUND INITIAL.
  Design references: Doepfer R2M (absolute/relative), Korg Lock (hold), Haken Continuum (rounding).
- TUNING output: RPN 1 Fine + RPN 2 Coarse on U1/U2/U3 with hysteresis (coarse written only when
  fine cannot cover the pitch; within ±1 semitone only Fine is used), max 250 updates/s, RPN null
  at rest. Never sends Pitch Bend or RPN 0 — the wheel and the blend's bend range stay untouched.
- UI: SETUP overlay; strip sends down/move/up by pointer id; HOLD keeps the marker.
- PANIC returns the ribbon to 0 on its destination (tuning reset).
- Tests: relative no-jump, absolute mapping + dead zone, invert/24 st, hold/continue/tap-clear,
  rounding pulls 3.3 -> 3.0 and keeps vibrato depth, round-initial, router TUNING output emits no
  Pitch Bend and no RPN 0 and returns to coarse 0 / fine centre + RPN null, ±1 range never writes Coarse.
- Fuzz (CTest + 40 000 local, ASan/UBSan) now includes random ribbon settings/touches/output
  switches; criteria add "tuning back at 0": 0 failures. Found and fixed: tuning could rest at
  coarse -1 / fine +1 (≈0 but not reset).
- JNI 23/23. Kotlin compiled.


## v0.6.1-test — hardware probe build
- Settings -> TUNING TEST -> RUN: sends RPN 1 Fine Tuning sweep (-100..+100 cents, 3 s) and
  RPN 2 Coarse Tuning steps (+1..+5, then 0) on U1/U2/U3, then resets tuning to 0 and RPN null.
  Purpose: find out whether the PA600 applies RPN tuning live to a sounding note, so Ribbon and
  TIME portamento can move off Pitch Bend entirely (wheel and blend bend range untouched).


## v0.6.0
- UI: the PA600 LOCAL switch and the LOCAL label are removed. The app always runs the
  Local-OFF bridge; the keyboard's Local Control must be OFF. (Local-ON support stays in the
  native core and its tests, but the app never enables it.)
- Kotlin compiled (kotlinc 2.0.21), JNI unchanged.


## v0.5.3 — automatic MONO
- MONO legato is automatic: on for U1/U2/U3 while TIME portamento is ON, on for the TERCA
  source while TERCA owns U3; otherwise every Upper is untouched (poly blends play chords).
  Key memory is cleared whenever MONO switches on/off for a channel.
- Tests updated for the mono TERCA line; new test: poly chord with PORTA OFF, mono with PORTA ON.
- Fuzz 30 000 sessions (ASan/UBSan): 0 failures.


## v0.5.2
- App MONO is OFF: mono/poly is decided by the PA600 Sound (poly blends play chords normally).
  The MONO stage and both v0.5.1 fuzz-found fixes remain; fuzz still exercises MONO on/off.


## v0.5.1 — MONO legato always on
- MONO legato for U1/U2/U3 and the TERCA line (last-note priority, return to a held key,
  legato order new-on then old-off). Always on, no UI button. Unknown Note Offs pass through.
- FIX: SCAN start clears MONO memory (SCAN swallows releases of keys held at that moment;
  MONO could later "return" to a key already up -> stuck note). Found by fuzz.
- FIX: a Pitch Bend transport change drops any running glide offset (stale glide lane could
  leave an Upper detuned). Found by fuzz.
- Fuzz: 30 000 sessions under ASan/UBSan + 100 000 sessions (-O2): 0 failures.


## v0.5.0 — Local ON without wheel conflicts
- Local ON: the native core owns RPN 0 (Pitch Bend Sensitivity). It stays at ±2 so the PA600's
  own wheel keeps its normal feel, widens to ±12 only while a glide wider than 2 semitones or a
  Ribbon with RANGE > 2 needs it (RPN before the Pitch Bend), and returns to ±2 150 ms after.
  Program Change re-asserts the current range. The Android layer no longer sends RPN 12 in Local ON.
- Tests: wheel full-up stays 16383 at ±2; 2-semitone glide without any RPN; 7-semitone glide
  switches to 12 first and returns to 2; Ribbon ≤2 never switches; Ribbon 7 widens and returns.
- Fuzz (CTest + 30 000 local sessions): also requires Local ON to end at RPN ±2 — 0 failures.


## v0.4.3
- Local OFF: TERCA source is Upper 3 itself (raw U3 keys are consumed and replaced by their
  thirds). U1/U2 are fully independent of TERCA; CC123 on U1 no longer touches U3.
- Local ON: source stays U1 (only channel 1 is transmitted in that mode).
- SCAN recognises the chord from any Upper (works while U3 is muted).
- All TERCA tests run on the mode's source channel; fuzz 30 000 sessions: 0 failures.


## v0.4.2 — all Uppers with all effects, no conflicts
- Local OFF: each Upper glides from its own notes (a muted/untransmitted Upper never affects another).
- TERCA source = U1 and/or U2 (same key on both = exactly one third, released after both offs).
- U3 glide is reset whenever TERCA ownership of U3 changes (no raw<->terca cross-glide).
- FIX: SCAN no longer swallows Pitch Bend — a wheel returning to centre during SCAN left the
  Upper permanently bent (found by the fuzz test).
- New `core/tests/FuzzTests.cpp` in CTest (runs in CI, also under ASan/UBSan): 6000 random
  PA600-like sessions on U1/U2/U3 with random muted Uppers, wheel, Ribbon, SCAN, TERCA,
  TIME portamento and transport toggles in both Local modes. Pass criteria: no hanging note
  on any channel, every Upper's pitch back at centre. Result: 0 failures (30 000 locally).


## v0.4.1
- TERCA safety sweep: releasing the last U1 source sends Note Offs for anything still known on
  U3 plus CC123 on U3 only (never U1/U2).
- Fuzz: 20 000 random sequences (notes, legato overlaps, SCAN, TERCA/PORTA/transport toggles,
  both Local modes) — zero stuck notes on U3/U1 (ASan+UBSan).
- Setup guide: LOCAL OFF + Track Mute Active ON is the recommended mode for TERCA/Ribbon/PORTA.


## v0.4.0
- TIME portamento: equal total glide time for every interval (Pitch Bend, ±12 transport),
  U3 glides along the TERCA line; Korg CC65 forced OFF while enabled. TIME shown in ms.
- TERCA: every key gets a third (out-of-scale: in-scale m3, else in-scale M3, else m3).
- Tests: glide 2 / 12 / 24 semitones all finish at exactly the set time; halfway values;
  mid-glide retarget; Pitch Bend precedes the note; Local ON + TERCA U3 glide by its own
  interval; disable returns to centre; chromatic thirds for all 6 cells × 12 keys; D phrygian E→G, B→D.
- Kotlin compiled (kotlinc 2.0.21), JNI 19/19.


## Changes in this version
- Keyboard Local mode (`LOCAL ON` default / `LOCAL OFF`) in native router, JNI, controller and UI.
- Local ON never echoes keyboard traffic; Local OFF bridges only U1/U2/U3 + Lower channel.
- System Realtime, SysEx and style/chord/player/global channels are never returned to the PA600.
- USB-only device selection with KORG/PA preference (no virtual/Bluetooth ports).
- Runaway MIDI loop breaker with automatic PANIC and on-screen warning.
- PANIC button in the top bar (panic now also covers the Lower channel).
- TERCA: six scan cells (major/minor up & down, phrygian up, hijaz up), all 12 tonalities; result shown in UI.
- Ribbon: RPN range restored to ±2 and raw wheel re-asserted after release.
- UI: PORTA TIME drag zone no longer steals TERCA button presses; drags follow pointer id
  (second finger can no longer make the Ribbon jump).
- Poller runs at 2 ms only while Ribbon/SCAN is active (15 ms idle, no JNI poll when idle).
- `LoopGuard.kt` removed.

## Actually run in this environment

PASS:
- C++ core Release build + regression tests (GCC, -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror).
- Clang build + regression tests.
- AddressSanitizer + UndefinedBehaviorSanitizer regression run.
- New tests: 6 scan cells × 12 tonalities × 2 Local modes with hand-written expected notes;
  inversion/octave-independent scan; unknown shapes never lock; Local ON never echoes
  U1/U2/U3/Lower/style/damper/Pitch Bend/Program Change/CC123; Local ON SCAN sends no CC123 to U1/U2;
  Ribbon transport exit re-asserts raw wheel.
- All previous regression tests unchanged and passing (Local OFF bridge behaviour preserved).
- Kotlin: all app sources compiled with kotlinc 2.0.21 against android.jar (API 34) + androidx stubs.
- JNI: host shared library built from NativeBridge.cpp + core; Kotlin externals vs exports 19/19.

## Not tested here
- Full Gradle/APK build (Android SDK/Google Maven not reachable here) — GitHub Actions builds the APK.
- Physical PA600 behaviour. Must be verified on the keyboard following KORG_SETUP.md.


## 2026-10-04 finalization verification

- GCC strict core build (`-Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror`): PASS.
- Clang 17 strict core build: PASS.
- Release tests: 3/3 PASS.
- ASan + UBSan tests: 3/3 PASS.
- `SvBankRuntime` compatibility test: PASS (single-file header/records/PCM mmap/reference reconstruction plus SHA corruption rejection).
- GUI/JNI contract: 104/104 PASS.
- Direct-ALSA audit: PASS.
- Direct raw-MIDI audit: 14/14 PASS.
- Android APK/physical SM-X130 test intentionally not run yet; project workflow defers the one device build/test until source finalization.
