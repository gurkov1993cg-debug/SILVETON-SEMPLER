#include <jni.h>
#include "silveton/NativeMidiEngine.h"
#include <cstdint>
#include <memory>
#include <vector>

namespace {
using silveton::MidiMessage;
using silveton::NativeMidiEngine;

std::unique_ptr<NativeMidiEngine> gEngine;

NativeMidiEngine& engine() {
    if (!gEngine) gEngine = std::make_unique<NativeMidiEngine>();
    return *gEngine;
}

jintArray pack(JNIEnv* env, const std::vector<MidiMessage>& messages) {
    std::vector<jint> flat;
    flat.reserve(messages.size() * 4U);
    for (const auto& m : messages) {
        flat.push_back(static_cast<jint>(m.status));
        flat.push_back(static_cast<jint>(m.data1));
        flat.push_back(static_cast<jint>(m.data2));
        flat.push_back(static_cast<jint>(m.size));
    }
    jintArray result = env->NewIntArray(static_cast<jsize>(flat.size()));
    if (result != nullptr && !flat.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(flat.size()), flat.data());
    }
    return result;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeInit(JNIEnv*, jobject) {
    gEngine = std::make_unique<NativeMidiEngine>();
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetPortamentoEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, engine().router().setPortamentoEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetPortamentoTimeMs(JNIEnv* env, jobject, jint ms) {
    return pack(env, engine().router().setPortamentoTimeMs(static_cast<int>(ms)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSyncPortamento(JNIEnv* env, jobject) {
    return pack(env, engine().router().syncPortamento());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSyncPitchChannel(JNIEnv* env, jobject, jint upper) {
    return pack(env, engine().router().syncPitchChannel(static_cast<int>(upper)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetPitchTransportEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, engine().router().setPitchTransportEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetThirdEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, engine().router().setThirdEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetThirdScanning(JNIEnv* env, jobject, jboolean scanning) {
    return pack(env, engine().router().setThirdScanning(scanning == JNI_TRUE));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeThirdScanning(JNIEnv*, jobject) {
    return engine().router().thirdScanning() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeThirdScanResult(JNIEnv*, jobject) {
    return static_cast<jint>(engine().router().thirdScanResult());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeThirdScanRevision(JNIEnv*, jobject) {
    return static_cast<jint>(engine().router().third().scanRevision());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeRibbonTouch(JNIEnv* env, jobject, jint action, jfloat position, jlong nowUs) {
    return pack(env, engine().router().ribbonTouch(static_cast<int>(action), static_cast<double>(position),
                                                   static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetRibbonSettings(JNIEnv* env, jobject,
        jint range, jfloat sensitivity, jint smoothMs, jint returnMs) {
    silveton::Ribbon::Settings s;
    s.output = silveton::Ribbon::Output::PitchBend;
    s.rangeSemitones = static_cast<int>(range);
    s.sensitivity = static_cast<double>(sensitivity);
    s.smoothMs = static_cast<int>(smoothMs);
    s.returnMs = static_cast<int>(returnMs);
    return pack(env, engine().router().setRibbonSettings(s));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeRibbonReset(JNIEnv* env, jobject) {
    return pack(env, engine().router().ribbonReset());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeObserveReport(JNIEnv* env, jobject, jint status, jint data1, jint data2, jlong nowUs) {
    silveton::MidiMessage m{static_cast<std::uint8_t>(status & 0xFF), static_cast<std::uint8_t>(data1 & 0x7F),
                            static_cast<std::uint8_t>(data2 & 0x7F), 3};
    return pack(env, engine().router().observeReport(m, static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativePortaMask(JNIEnv*, jobject) {
    return static_cast<jint>(engine().router().portamento().activeMask());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeLearnedBendRange(JNIEnv*, jobject, jint upper) {
    return static_cast<jint>(engine().router().learnedBendRange(static_cast<int>(upper)));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeRibbonActive(JNIEnv*, jobject) {
    return engine().router().ribbon().active() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetGlidePoints(JNIEnv* env, jobject, jfloatArray flat) {
    const jsize n = env->GetArrayLength(flat);
    std::vector<jfloat> f(static_cast<std::size_t>(n));
    env->GetFloatArrayRegion(flat, 0, n, f.data());
    std::vector<silveton::KorgGlideModel::Point> pts;
    for (std::size_t i = 0; i + 2 < f.size(); i += 3) {
        pts.push_back({static_cast<int>(f[i]), static_cast<double>(f[i + 1]), static_cast<double>(f[i + 2])});
    }
    if (!pts.empty()) engine().router().portamento().model().setPoints(pts, true);
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeSetGlideBalance(JNIEnv*, jobject, jfloat ccPerDoubling) {
    engine().router().portamento().model().setManualBalance(static_cast<double>(ccPerDoubling));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativeProcess(JNIEnv* env, jobject,
                                                           jint status, jint data1, jint data2,
                                                           jint size, jlong nowUs) {
    return pack(env, engine().handleMidiIn(static_cast<std::uint8_t>(status & 0xFF),
                                           static_cast<std::uint8_t>(data1 & 0x7F),
                                           static_cast<std::uint8_t>(data2 & 0x7F),
                                           static_cast<std::uint8_t>(size),
                                           static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativePoll(JNIEnv* env, jobject, jlong nowUs) {
    return pack(env, engine().router().poll(static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_sampler_NativeMidiEngine_nativePanic(JNIEnv* env, jobject) {
    return pack(env, engine().router().panic());
}
