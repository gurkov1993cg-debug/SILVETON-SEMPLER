package com.silveton.sampler

/**
 * What the Local-OFF bridge may return to the PA600.
 *
 * With Local Control OFF the PA600 disconnects only its PERFORMANCE controls
 * from the sound engine: keys, pitch wheel, modulation, pedals, expression,
 * aftertouch. Those must be returned by the app or they are silent.
 *
 * Everything else the PA600 transmits is a REPORT of something it already
 * applied itself (sound selection, volume, pan, effects, portamento time,
 * RPN/NRPN, All Notes Off...). Returning a report is redundant and — as the
 * session log of 2026-09-27 showed — the PA600 reports CC#5 / CC#123 / RPN it
 * receives, so returning them closes an infinite MIDI loop. Reports are never
 * returned.
 */
object BridgeFilter {
    /** Performance controllers bridged in Local OFF. */
    private val performanceCcs = intArrayOf(
        1,   // modulation (joystick +Y)
        2,   // breath
        4,   // foot controller
        11,  // expression pedal
        64,  // damper
        66,  // sostenuto
        67,  // soft
        68   // legato footswitch
    )

    fun isPerformanceCc(cc: Int): Boolean = cc in performanceCcs

    /** True when a channel message from the PA600 must be returned (Local OFF). */
    fun forward(status: Int, data1: Int): Boolean = when (status and 0xF0) {
        0x80, 0x90, 0xA0, 0xD0, 0xE0 -> true          // notes, pressure, pitch wheel
        0xB0 -> isPerformanceCc(data1)
        else -> false                                  // Program Change etc. = reports
    }
}

/**
 * Protection against the PA600 sending back what the app sends it.
 *
 * The session log of 2026-09-27 shows the PA600 at times returning:
 *  - controllers the app sent (CC#5, CC#123, RPN) -> dropped when identical and recent;
 *  - NOTES the app sent, with the track's octave transpose applied (U2 = -1 octave:
 *    A4 -> A3 -> A2 -> ... every ~6 ms) -> a note-on with the same velocity as a
 *    note-on the app sent on that channel within [noteWindowNs], at the same pitch
 *    or whole octaves away, is an echo and is dropped;
 *  - and note-offs an octave away from the note that was pressed (on D5, off D6).
 * Note-offs are only forwarded for keys that are really held; an off whose key is
 * not held but whose octave neighbour is, releases that neighbour. Nothing can hang.
 *
 * Key count law (log 2026-09-29 01:31): in a mono Sound the PA600 may name the
 * wrong key in a release (D#5 held, E5 pressed and released, D#5 released -> it
 * sends "E5 off" twice). The NAME can be wrong, the COUNT never is: every press
 * sends one note-on and every release one note-off. So per channel
 *     keys down = presses - releases
 * and the set of keys the app holds must always have exactly that size. A key
 * release naming a key that is not held still releases one held key: the one
 * pressed last before the named key (else the one pressed last). When all keys
 * are up the set is empty, so MONO has nothing left to sound.
 * The PA600's own releases with velocity exactly 64 (its reset of all notes,
 * voice steal) are not key releases and never count.
 */
class EchoGuard(
    private val ccWindowNs: Long = 30_000_000L,
    private val noteWindowNs: Long = 12_000_000L
) {
    private val lastValue = Array(16) { IntArray(128) { -1 } }
    private val lastTime = Array(16) { LongArray(128) }
    private val sentVel = Array(16) { IntArray(128) { -1 } }
    private val sentTime = Array(16) { LongArray(128) }
    private val held = Array(16) { IntArray(128) }
    private val onNs = Array(16) { LongArray(128) }

    fun rememberSent(message: ByteArray, nowNs: Long) {
        if (message.size < 3) return
        val status = message[0].toInt() and 0xFF
        val ch = status and 0x0F
        val d1 = message[1].toInt() and 0x7F
        val d2 = message[2].toInt() and 0x7F
        when (status and 0xF0) {
            0xB0 -> { lastValue[ch][d1] = d2; lastTime[ch][d1] = nowNs }
            0x90 -> if (d2 > 0) { sentVel[ch][d1] = d2; sentTime[ch][d1] = nowNs }
        }
    }

    /** Controller echo (identical CC recently sent on the same channel). */
    fun isEcho(message: ByteArray, nowNs: Long): Boolean {
        if (message.size < 3) return false
        val status = message[0].toInt() and 0xFF
        if (status and 0xF0 != 0xB0) return false
        val ch = status and 0x0F
        val cc = message[1].toInt() and 0x7F
        val v = message[2].toInt() and 0x7F
        return lastValue[ch][cc] == v && nowNs - lastTime[ch][cc] <= ccWindowNs
    }

    /**
     * Notes from the PA600. Returns the messages to process, in order: empty =
     * drop; one message = normal (possibly with a corrected note number for an
     * octave-shifted note-off); two messages = a missing release was detected
     * (the key was pressed again without a note-off) -> release first, then press.
     */
    fun filterNote(message: ByteArray, nowNs: Long): List<ByteArray> {
        if (message.size < 3) return listOf(message)
        val status = message[0].toInt() and 0xFF
        val cmd = status and 0xF0
        if (cmd != 0x80 && cmd != 0x90) return listOf(message)
        val ch = status and 0x0F
        val note = message[1].toInt() and 0x7F
        val vel = message[2].toInt() and 0x7F
        val isOn = cmd == 0x90 && vel > 0
        if (isOn) {
            // Echo of a note-on the app just sent (same velocity, same pitch class).
            var n = note % 12
            while (n < 128) {
                if (sentVel[ch][n] == vel && nowNs - sentTime[ch][n] <= noteWindowNs) return emptyList()
                n += 12
            }
            if (held[ch][note] > 0) {
                // A key cannot be pressed twice without being released: the
                // release was lost. Release it first so nothing can hang.
                onNs[ch][note] = nowNs
                return listOf(byteArrayOf((0x80 or ch).toByte(), note.toByte(), 64), message)
            }
            held[ch][note] = 1
            onNs[ch][note] = nowNs
            return listOf(message)
        }
        // Note-off: only for a key that is really held.
        if (held[ch][note] > 0) {
            held[ch][note] = 0
            return listOf(message)
        }
        for (shift in intArrayOf(12, -12, 24, -24, 36, -36)) {
            val other = note - shift
            if (other in 0..127 && held[ch][other] > 0) {
                held[ch][other] = 0
                return listOf(byteArrayOf(message[0], other.toByte(), message[2]))
            }
        }
        // Key count law: a real key release (velocity not 64) of a key that was
        // pressed since the connection still releases one held key.
        if (vel != 64 && onNs[ch][note] != 0L) {
            val j = keyReallyReleased(ch, onNs[ch][note])
            if (j >= 0) {
                held[ch][j] = 0
                return listOf(byteArrayOf(message[0], j.toByte(), message[2]))
            }
        }
        return emptyList()   // release of a key that is not held: echo / stray -> ignore
    }

    /** The held key pressed last before [namedOn]; if none, the held key pressed last. -1 = none held. */
    private fun keyReallyReleased(ch: Int, namedOn: Long): Int {
        var before = -1; var beforeOn = Long.MIN_VALUE
        var any = -1; var anyOn = Long.MIN_VALUE
        for (j in 0..127) {
            if (held[ch][j] == 0) continue
            val t = onNs[ch][j]
            if (t > anyOn) { any = j; anyOn = t }
            if (t < namedOn && t > beforeOn) { before = j; beforeOn = t }
        }
        return if (before >= 0) before else any
    }

    fun clear() {
        for (row in lastValue) row.fill(-1)
        for (row in sentVel) row.fill(-1)
        for (row in held) row.fill(0)
        for (row in onNs) row.fill(0L)
    }
}
