package com.silveton.sampler

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.os.SystemClock
import android.view.View
import kotlin.math.*

class LiveMidiView(context: Context) : View(context) {

    interface Listener {
        fun onPortamentoEnabled(enabled: Boolean)
        fun onPortamentoTime(value: Int)
        fun onThirdScan(scanning: Boolean)
        fun onThirdEnabled(enabled: Boolean)
        fun onRibbonConfig(config: RibbonConfig)
        fun onRibbonTouch(action: Int, position: Float)
        fun onChannelMapChanged(slot: Int, midiChannel1Based: Int)
        fun onPanic()
        fun onLowerChannel(midiChannel1Based: Int)
        fun onPortaBalance(value: Int)
        fun onMidiLog(enabled: Boolean)
        /** App TRANSPOSE changed (-12..+12 semitones). */
        fun onTranspose(semitones: Int)
    }

    var listener: Listener? = null

    var connected: Boolean = false
        set(value) { field = value; invalidate() }

    var thirdScanResult: Int = 0
        set(value) {
            field = value
            if (value != 0) {
                thirdScanning = false
                thirdEnabled = true
            }
            invalidate()
        }

    fun syncThirdScanning(scanning: Boolean) {
        if (thirdScanning != scanning) {
            thirdScanning = scanning
            invalidate()
        }
    }

    var channelMap: IntArray = intArrayOf(1, 2, 3)
        set(value) { field = value.copyOf(); invalidate() }

    /** Short warning shown in the top bar (e.g. MIDI loop stopped); null = none. */
    var warning: String? = null

    /** App processing time of the last notes (PA600 in -> PA600 out), in ms; < 0 = unknown. */
    var latencyMs: Float = -1f
        set(value) {
            val shown = if (value < 0f) "— ms" else String.format(java.util.Locale.US, "%.1f ms", value)
            field = value
            if (shown != latencyText) { latencyText = shown; invalidate() }
        }
    private var latencyText = "— ms"
    private var midiPillLeft = 0f
        set(value) { field = value; invalidate() }

    /** Lower MIDI channel bridged in Local OFF mode, 1..16, 0 = OFF. */
    var lowerChannel: Int = 4
        private set

    private var panicFlashUntil = 0L

    private var portamentoEnabled = false
    /** Uppers with portamento (bit0 = U1), set by the controller when a blend is selected. */
    var portaMask: Int = 0
        set(value) {
            field = value and 7
            portamentoEnabled = field != 0
            invalidate()
        }
    private var portamentoTime = 12 // TIME slider 0..127 -> PortaTime.msForSlider() milliseconds (12 = 10 ms).
    private var thirdEnabled = false
    private var thirdScanning = false
    private var ribbonConfig = RibbonConfig()
    private val ribbonSensitivity get() = ribbonConfig.sensitivity
    private val ribbonRangeSemitones get() = ribbonConfig.rangeSemitones
    private var ribbonValue = 0f
    private var settingsOpen = false

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val gearRect = RectF()
    private val portPanel = RectF()
    private val thirdPanel = RectF()
    private val ribbonPanel = RectF()
    private val ribbonTouch = RectF()
    private val timeTrack = RectF()
    private val portToggleRect = RectF()
    private val sensTrack = RectF()
    private val scanRect = RectF()
    private val thirdToggleRect = RectF()
    private val sensMinusRect = RectF()
    private val sensPlusRect = RectF()
    private val rangeMinusRect = RectF()
    private val rangePlusRect = RectF()
    private val transMinusRect = RectF()
    private val transPlusRect = RectF()
    /** App TRANSPOSE in semitones (-12..+12), shown above the ribbon. */
    private var transpose = 0
    private val panicRect = RectF()
    // Left column: 0..2 Upper channels, 3 Lower channel.
    // Right column: 6 PORTA BALANCE, 7 MIDI LOG (slots 4 and 5 are no longer used).
    private val settingsRowCount = 8
    var portaBalance: Int = 11
        private set
    var midiLogOn: Boolean = true
        private set
    private val settingsRows = Array(settingsRowCount) { RectF() }
    private val settingsMinus = Array(settingsRowCount) { RectF() }
    private val settingsPlus = Array(settingsRowCount) { RectF() }
    private val settingsPanel = RectF()

    private enum class DragTarget { NONE, TIME, SENS, RIBBON }
    private var dragTarget = DragTarget.NONE
    private var dragPointerId = MotionEvent.INVALID_POINTER_ID

    init {
        isFocusable = true
        keepScreenOn = true
        contentDescription = "SILVETON LIVE MIDI"
    }

    private fun sx(v: Float) = width * v
    private fun sy(v: Float) = height * v
    private fun radius(v: Float) = min(width, height) * v

    private fun layoutRects() {
        val marginX = sx(0.019f)
        val gap = sx(0.010f)
        val top = sy(0.128f)
        val panelBottom = sy(0.414f)
        val usable = width - 2f * marginX - gap
        val leftW = usable * 0.55f

        gearRect.set(sx(0.040f), sy(0.033f), sx(0.092f), sy(0.105f))
        panicRect.set(sx(0.108f), sy(0.030f), sx(0.215f), sy(0.100f))
        portPanel.set(marginX, top, marginX + leftW, panelBottom)
        thirdPanel.set(portPanel.right + gap, top, width - marginX, panelBottom)

        ribbonPanel.set(marginX, sy(0.430f), width - marginX, sy(0.965f))
        ribbonTouch.set(sx(0.032f), sy(0.585f), sx(0.968f), sy(0.940f))

        val buttonY = portPanel.top + portPanel.height() * 0.31f
        val buttonH = portPanel.height() * 0.24f
        portToggleRect.set(
            portPanel.centerX() - portPanel.width() * 0.12f, buttonY,
            portPanel.centerX() + portPanel.width() * 0.12f, buttonY + buttonH
        )

        timeTrack.set(
            portPanel.left + portPanel.width() * 0.16f,
            portPanel.top + portPanel.height() * 0.82f,
            portPanel.right - portPanel.width() * 0.16f,
            portPanel.top + portPanel.height() * 0.86f
        )

        scanRect.set(
            thirdPanel.left + thirdPanel.width() * 0.05f,
            thirdPanel.top + thirdPanel.height() * 0.315f,
            thirdPanel.left + thirdPanel.width() * 0.48f,
            thirdPanel.top + thirdPanel.height() * 0.755f
        )
        thirdToggleRect.set(
            thirdPanel.left + thirdPanel.width() * 0.52f,
            thirdPanel.top + thirdPanel.height() * 0.315f,
            thirdPanel.right - thirdPanel.width() * 0.05f,
            thirdPanel.top + thirdPanel.height() * 0.755f
        )

        // One row above the ribbon: RANGE, SENSITIVITY, TRANSPOSE (big keys).
        val sensY = ribbonPanel.top + ribbonPanel.height() * 0.125f
        val controlW = ribbonPanel.width()
        val keyHalfH = sy(0.040f)
        fun key(a: Float, b: Float, r: RectF) =
            r.set(ribbonPanel.left + controlW * a, sensY - keyHalfH, ribbonPanel.left + controlW * b, sensY + keyHalfH)
        key(0.080f, 0.135f, rangeMinusRect)
        key(0.190f, 0.245f, rangePlusRect)
        key(0.370f, 0.425f, sensMinusRect)
        sensTrack.set(
            ribbonPanel.left + controlW * 0.440f, sensY - sy(0.010f),
            ribbonPanel.left + controlW * 0.635f, sensY + sy(0.010f)
        )
        key(0.650f, 0.705f, sensPlusRect)
        key(0.810f, 0.865f, transMinusRect)
        key(0.920f, 0.975f, transPlusRect)

        settingsPanel.set(sx(0.07f), sy(0.12f), sx(0.93f), sy(0.90f))
        val colGap = settingsPanel.width() * 0.03f
        val sColW = (settingsPanel.width() - colGap * 3f) / 2f
        val rowTop = settingsPanel.top + settingsPanel.height() * 0.08f
        val rowH = settingsPanel.height() * 0.18f
        val rowGap = settingsPanel.height() * 0.05f
        for (i in 0 until settingsRowCount) {
            if (i == 4 || i == 5) {           // removed rows: no area, never drawn or touched
                settingsRows[i].set(0f, 0f, 0f, 0f); settingsMinus[i].set(0f, 0f, 0f, 0f); settingsPlus[i].set(0f, 0f, 0f, 0f)
                continue
            }
            val col = if (i < 4) 0 else 1
            val row = if (i < 4) i else i - 6   // right column: PORTA BALANCE, MIDI LOG
            val left = settingsPanel.left + colGap + col * (sColW + colGap)
            val y = rowTop + row * (rowH + rowGap)
            settingsRows[i].set(left, y, left + sColW, y + rowH)
            settingsMinus[i].set(left + sColW * 0.52f, y + rowH * 0.16f, left + sColW * 0.63f, y + rowH * 0.84f)
            settingsPlus[i].set(left + sColW * 0.86f, y + rowH * 0.16f, left + sColW * 0.97f, y + rowH * 0.84f)
        }
    }

    // ---- Rendering -----------------------------------------------------------
    // Everything that does not move while a finger drags (background, cards,
    // titles, buttons, the ribbon strip and its scale) is drawn once into a
    // bitmap and only redrawn when its state changes. Each frame then draws that
    // bitmap plus the few moving parts (TIME value and slider, SENSITIVITY slider,
    // ribbon wheel) without allocating, on the GPU.
    private var staticLayer: Bitmap? = null
    private var staticSig = 0L
    private var drawingStatic = true
    private var layoutW = -1
    private var layoutH = -1
    private val tmpRect = RectF()
    private val tmpRect2 = RectF()
    private val dyn = Paint(Paint.ANTI_ALIAS_FLAG)
    private var timeFill: Paint? = null
    private var sensFill: Paint? = null
    private var knobShadow: Paint? = null
    private var knobCap: Paint? = null
    private var grain: Paint? = null
    private var haloPaint: Paint? = null
    private var bandPaint: Paint? = null
    private val tfLight: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val tfMedium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val tfNormal: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)

    private fun blinkOn() = !thirdScanning || ((SystemClock.uptimeMillis() / 250L) % 2L == 0L)

    private fun staticSignature(): Long {
        var h = 17L
        fun mix(v: Long) { h = h * 31L + v }
        mix(width.toLong()); mix(height.toLong())
        mix(if (connected) 1 else 0)
        mix((warning?.hashCode() ?: 0).toLong())
        mix(if (SystemClock.uptimeMillis() < panicFlashUntil) 1 else 0)
        mix(portaMask.toLong()); mix(if (portamentoEnabled) 1 else 0)
        mix(if (thirdEnabled) 1 else 0); mix(if (thirdScanning) 1 else 0)
        mix(if (blinkOn()) 1 else 0); mix(thirdScanResult.toLong())
        mix(ribbonRangeSemitones.toLong()); mix(ribbonSensitivity.toRawBits().toLong())
        mix(transpose.toLong())
        mix(if (settingsOpen) 1 else 0)
        if (settingsOpen) {
            for (c in channelMap) mix(c.toLong())
            mix(lowerChannel.toLong()); mix(portaBalance.toLong()); mix(if (midiLogOn) 1 else 0)
            mix(portamentoTime.toLong()); mix(ribbonValue.toRawBits().toLong())
        }
        return h
    }

    private fun prepareDynamicPaints() {
        timeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(timeTrack.left, 0f, timeTrack.right, 0f, T.accentDeep, T.accent, Shader.TileMode.CLAMP)
        }
        sensFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(sensTrack.left, 0f, sensTrack.right, 0f, T.accentDeep, T.accent, Shader.TileMode.CLAMP)
        }
        val kr = radius(0.040f)
        knobShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(0f, 0f, kr * 1.45f, intArrayOf(Color.argb(150, 0, 0, 0), Color.argb(150, 0, 0, 0), Color.argb(0, 0, 0, 0)),
                floatArrayOf(0f, 0.62f, 1f), Shader.TileMode.CLAMP)
        }
        // Brushed-metal cap, light from the top left (drawn around the origin).
        knobCap = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(-kr * 0.35f, -kr * 0.45f, kr * 1.5f,
                intArrayOf(Color.rgb(250, 251, 253), Color.rgb(196, 203, 211), Color.rgb(120, 128, 138)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        }
        // Fine grain for the background (a small tile, made once).
        val g = 96
        val px = IntArray(g * g)
        val rnd = java.util.Random(7)
        for (i in px.indices) { val v = rnd.nextInt(256); px[i] = Color.argb(10, v, v, v) }
        val tile = Bitmap.createBitmap(g, g, Bitmap.Config.ARGB_8888)
        tile.setPixels(px, 0, g, 0, 0, g, g)
        grain = Paint().apply { shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
        val mr = radius(0.075f)
        haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(0f, 0f, mr * 2.4f, T.tint(T.accent, 70), T.tint(T.accent, 0), Shader.TileMode.CLAMP)
        }
        // Unit gradient 0..1 along x, stretched from the centre to the wheel.
        bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 1f, 0f, T.tint(T.accent, 0), T.tint(T.accent, 110), Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        if (width != layoutW || height != layoutH) {
            layoutW = width
            layoutH = height
            layoutRects()
            prepareDynamicPaints()
            staticLayer?.recycle()
            staticLayer = null
        }

        val sig = staticSignature()
        var layer = staticLayer
        if (layer == null || sig != staticSig) {
            if (layer == null) {
                layer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                staticLayer = layer
            }
            layer.eraseColor(Color.TRANSPARENT)
            drawStaticScene(Canvas(layer))
            staticSig = sig
        }
        canvas.drawBitmap(layer, 0f, 0f, null)

        // Moving parts on top (the settings sheet covers them and is in the layer).
        if (!settingsOpen) {
            drawingStatic = false
            drawPortamento(canvas)
            drawRibbon(canvas)
            drawLatency(canvas)
        }
        if (thirdScanning) postInvalidateDelayed(120L)
        if (SystemClock.uptimeMillis() < panicFlashUntil) postInvalidateDelayed(60L)
    }

    private fun drawStaticScene(canvas: Canvas) {
        drawingStatic = true
        // Deep graphite background with a faint cool light from the top.
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), T.bgTop, T.bgBottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        bg.shader = RadialGradient(width * 0.5f, -height * 0.25f, width * 0.55f,
            Color.argb(28, 120, 180, 255), Color.argb(0, 120, 180, 255), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        grain?.let { canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), it) }

        drawTopBar(canvas)
        drawPortamento(canvas)
        drawThird(canvas)
        drawRibbon(canvas)

        if (settingsOpen) {
            drawingStatic = false
            drawPortamento(canvas)
            drawRibbon(canvas)
            drawingStatic = true
            drawSettings(canvas)
        }
    }

    /** Colour and type palette of the whole screen. */
    private object T {
        val bgTop = Color.rgb(12, 15, 20)
        val bgBottom = Color.rgb(6, 8, 11)
        val raised = Color.rgb(25, 31, 40)
        val hairline = Color.argb(26, 255, 255, 255)
        val hairlineStrong = Color.argb(46, 255, 255, 255)
        val text = Color.rgb(232, 236, 241)
        val textDim = Color.rgb(138, 150, 163)
        val textFaint = Color.rgb(92, 102, 114)
        val accent = Color.rgb(108, 198, 255)
        val accentDeep = Color.rgb(47, 127, 214)
        val violet = Color.rgb(176, 140, 255)
        val green = Color.rgb(61, 220, 151)
        val red = Color.rgb(229, 72, 77)
        fun tint(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun setText(size: Float, color: Int = Color.WHITE, bold: Boolean = true, align: Paint.Align = Paint.Align.CENTER, spacing: Float = 0.04f, light: Boolean = false) {
        p.reset()
        p.isAntiAlias = true
        p.color = color
        p.textSize = size
        p.textAlign = align
        p.letterSpacing = spacing
        p.typeface = when {
            light -> tfLight
            bold -> tfMedium
            else -> tfNormal
        }
    }

    private fun textCenterY(rect: RectF) = rect.centerY() - (p.ascent() + p.descent()) / 2f

    private fun drawRound(canvas: Canvas, rect: RectF, fill: Int, stroke: Int? = null, strokeWidth: Float = 2f, r: Float = radius(0.018f), glow: Float = 0f) {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = fill
        if (glow > 0f && stroke != null) p.setShadowLayer(glow, 0f, 0f, stroke)
        canvas.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()
        if (stroke != null) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = strokeWidth
            p.color = stroke
            canvas.drawRoundRect(rect, r, r, p)
        }
    }

    private fun gradientPaint(rect: RectF, c1: Int, c2: Int, vertical: Boolean = true): Paint {
        val gp = Paint(Paint.ANTI_ALIAS_FLAG)
        gp.shader = if (vertical) {
            LinearGradient(rect.left, rect.top, rect.left, rect.bottom, c1, c2, Shader.TileMode.CLAMP)
        } else {
            LinearGradient(rect.left, rect.centerY(), rect.right, rect.centerY(), c1, c2, Shader.TileMode.CLAMP)
        }
        return gp
    }

    private fun hairline() = max(1f, radius(0.0014f))

    /** A card: soft vertical gradient, hairline border, a thin accent line at the top. */
    private fun drawCard(canvas: Canvas, rect: RectF, accent: Int?) {
        // Machined faceplate: soft drop shadow, satin face, light on the top bevel,
        // dark line on the bottom bevel. No neon.
        val r = radius(0.022f)
        val body = gradientPaint(rect, Color.rgb(29, 34, 41), Color.rgb(18, 22, 27))
        body.setShadowLayer(radius(0.028f), 0f, radius(0.010f), Color.argb(190, 0, 0, 0))
        canvas.drawRoundRect(rect, r, r, body)
        body.clearShadowLayer()
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = hairline()
        edge.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            intArrayOf(Color.argb(46, 255, 255, 255), Color.argb(10, 255, 255, 255), Color.argb(120, 0, 0, 0)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, r, r, edge)
    }

    /** Card title: a small status LED and quiet silver caps, with an engraved rule. */
    private fun drawCardTitle(canvas: Canvas, rect: RectF, title: String, accent: Int, baselineY: Float) {
        val x = rect.left + rect.width() * 0.045f
        val ly = baselineY - radius(0.010f)
        drawLed(canvas, x, ly, radius(0.0075f), accent, true)
        setText(min(width, height) * 0.026f, Color.rgb(206, 213, 221), true, Paint.Align.LEFT, 0.24f)
        val tx = x + radius(0.024f)
        canvas.drawText(title, tx, baselineY, p)
        val end = tx + p.measureText(title) + radius(0.024f)
        if (end < rect.right - radius(0.04f)) {
            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeWidth = hairline()
            p.color = Color.argb(90, 0, 0, 0)
            canvas.drawLine(end, ly, rect.right - rect.width() * 0.045f, ly, p)
            p.color = Color.argb(18, 255, 255, 255)
            canvas.drawLine(end, ly + hairline(), rect.right - rect.width() * 0.045f, ly + hairline(), p)
        }
    }

    /** A small LED: dark when off, lit with a soft halo when on. */
    private fun drawLed(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int, on: Boolean) {
        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        if (on) {
            lp.shader = RadialGradient(cx, cy, r * 3.2f, T.tint(color, 90), T.tint(color, 0), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r * 3.2f, lp)
            lp.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.2f, Color.WHITE, color, Shader.TileMode.CLAMP)
        } else {
            lp.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.2f, Color.rgb(78, 86, 96), Color.rgb(34, 39, 46), Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(cx, cy, r, lp)
        lp.shader = null
        lp.style = Paint.Style.STROKE
        lp.strokeWidth = hairline()
        lp.color = Color.argb(160, 0, 0, 0)
        canvas.drawCircle(cx, cy, r, lp)
    }

    /** Hardware key face shared by all buttons. */
    private fun drawKeyFace(canvas: Canvas, rect: RectF, r: Float, lit: Int?) {
        val face = gradientPaint(rect, Color.rgb(44, 50, 59), Color.rgb(27, 31, 38))
        face.setShadowLayer(radius(0.008f), 0f, radius(0.003f), Color.argb(160, 0, 0, 0))
        canvas.drawRoundRect(rect, r, r, face)
        face.clearShadowLayer()
        if (lit != null) {
            // Light from the LED spilling across the lower face.
            val spill = Paint(Paint.ANTI_ALIAS_FLAG)
            spill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, T.tint(lit, 0), T.tint(lit, 34), Shader.TileMode.CLAMP)
            canvas.drawRoundRect(rect, r, r, spill)
        }
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = hairline()
        edge.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            intArrayOf(Color.argb(60, 255, 255, 255), Color.argb(8, 255, 255, 255), Color.argb(150, 0, 0, 0)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, r, r, edge)
    }

    /** Button with a status LED on the left and a silver label. */
    private fun drawPill(canvas: Canvas, rect: RectF, label: String, color: Int, active: Boolean, solid: Boolean = false, textSize: Float = min(width, height) * 0.026f) {
        val r = min(rect.height() * 0.30f, radius(0.020f))
        drawKeyFace(canvas, rect, r, if (active && solid) color else null)
        val ledR = min(rect.height() * 0.075f, radius(0.009f))
        val ledX = rect.left + max(rect.height() * 0.32f, radius(0.03f))
        drawLed(canvas, ledX, rect.centerY(), ledR, color, active)
        setText(textSize, if (active) Color.rgb(236, 240, 245) else Color.rgb(142, 153, 166), true, Paint.Align.CENTER, 0.16f)
        val cx = (ledX + ledR * 2f + rect.right) / 2f
        canvas.drawText(label, if (rect.width() > rect.height() * 2.2f) cx else rect.centerX(), textCenterY(rect), p)
    }

    private fun drawTopBar(canvas: Canvas) {
        // Thin divider under the header instead of a box.
        p.reset()
        p.isAntiAlias = true
        val dy = sy(0.116f)
        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        lp.shader = LinearGradient(sx(0.02f), dy, sx(0.98f), dy,
            intArrayOf(T.tint(Color.WHITE, 0), T.tint(Color.WHITE, 30), T.tint(Color.WHITE, 0)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        lp.strokeWidth = hairline()
        lp.style = Paint.Style.STROKE
        canvas.drawLine(sx(0.02f), dy, sx(0.98f), dy, lp)

        drawRound(canvas, gearRect, T.raised, T.hairlineStrong, hairline(), radius(0.020f))
        drawGear(canvas, gearRect.centerX(), gearRect.centerY(), min(gearRect.width(), gearRect.height()) * 0.27f)

        val titleY = sy(0.080f)
        // Title in one tone and one colour.
        // SILVETON (brushed steel) + "keyboard processor" (small letters) + "version 1".
        val title = "SILVETON"
        val sub = "keyboard processor"
        val ver = "version 1"
        val markW = radius(0.100f)
        val ts = min(width, height) * 0.045f
        val ss = min(width, height) * 0.031f
        val vs = min(width, height) * 0.019f
        setText(ts, Color.WHITE, true, Paint.Align.LEFT, 0.14f)
        val titleW = p.measureText(title)
        setText(ss, Color.WHITE, true, Paint.Align.LEFT, 0.06f)
        val subW = p.measureText(sub)
        setText(vs, Color.WHITE, true, Paint.Align.LEFT, 0.10f)
        val verW = p.measureText(ver)
        val gap1 = radius(0.022f)
        val gap2 = radius(0.020f)
        val verPadX = radius(0.012f)
        val total = markW + titleW + gap1 + subW + gap2 + verW + verPadX * 2f
        val x = width / 2f - total / 2f
        drawWaveMark(canvas, x, titleY - radius(0.016f), markW * 0.66f, radius(0.024f))
        val tx = x + markW
        drawSteelText(canvas, title, tx, titleY, ts, 0.14f)
        val sx0 = tx + titleW + gap1
        drawSteelText(canvas, sub, sx0, titleY, ss, 0.06f)
        // "version 1" in a small engraved plate.
        val vx = sx0 + subW + gap2
        setText(vs, Color.WHITE, true, Paint.Align.LEFT, 0.10f)
        val plate = RectF(vx, titleY + p.ascent() - radius(0.008f), vx + verW + verPadX * 2f, titleY + p.descent() + radius(0.006f))
        drawRound(canvas, plate, Color.argb(40, 255, 255, 255), Color.argb(70, 255, 255, 255), hairline(), plate.height() / 2f)
        setText(vs, Color.rgb(196, 204, 214), true, Paint.Align.LEFT, 0.10f)
        canvas.drawText(ver, vx + verPadX, titleY - radius(0.001f), p)

        // Connection: small status pill.
        val dotX = sx(0.894f)
        val dotY = sy(0.068f)
        setText(min(width, height) * 0.024f, if (connected) T.text else T.textFaint, true, Paint.Align.LEFT, 0.18f)
        val label = "MIDI"
        val pill = RectF(dotX - radius(0.026f), dotY - radius(0.030f), dotX + sx(0.018f) + p.measureText(label) + radius(0.026f), dotY + radius(0.030f))
        drawRound(canvas, pill, T.raised, T.hairline, hairline(), pill.height() / 2f)
        midiPillLeft = pill.left
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = if (connected) T.green else T.textFaint
        if (connected) p.setShadowLayer(radius(0.012f), 0f, 0f, T.green)
        canvas.drawCircle(dotX, dotY, radius(0.0085f), p)
        p.clearShadowLayer()
        setText(min(width, height) * 0.024f, if (connected) T.text else T.textFaint, true, Paint.Align.LEFT, 0.18f)
        canvas.drawText(label, dotX + sx(0.018f), dotY - (p.ascent() + p.descent()) / 2f, p)

        // PANIC: always reachable, releases every note the app knows about.
        val flashing = SystemClock.uptimeMillis() < panicFlashUntil
        drawPill(canvas, panicRect, "PANIC", T.red, true, solid = flashing, textSize = min(width, height) * 0.027f)

        warning?.let {
            setText(min(width, height) * 0.024f, T.red, true, Paint.Align.LEFT, 0.08f)
            canvas.drawText(it, panicRect.right + sx(0.015f), dotY - (p.ascent() + p.descent()) / 2f, p)
        }
    }

    /** Brushed-steel text: dark drop shadow, thin top highlight, metal gradient face. */
    private fun drawSteelText(canvas: Canvas, text: String, x: Float, baseline: Float, size: Float, spacing: Float) {
        setText(size, Color.argb(220, 3, 5, 8), true, Paint.Align.LEFT, spacing)
        canvas.drawText(text, x, baseline + size * 0.09f, p)
        setText(size, Color.argb(110, 255, 255, 255), true, Paint.Align.LEFT, spacing)
        canvas.drawText(text, x, baseline - size * 0.035f, p)
        setText(size, Color.WHITE, true, Paint.Align.LEFT, spacing)
        val capTop = baseline + p.ascent() * 0.72f
        p.shader = LinearGradient(0f, capTop, 0f, baseline,
            intArrayOf(Color.rgb(252, 253, 255), Color.rgb(200, 207, 215), Color.rgb(118, 128, 139),
                Color.rgb(176, 184, 193), Color.rgb(236, 240, 244)),
            floatArrayOf(0f, 0.40f, 0.53f, 0.78f, 1f), Shader.TileMode.CLAMP)
        canvas.drawText(text, x, baseline, p)
        p.shader = null
    }

    /** Silver sound wave with a cyan tone line: the app's mark. */
    private fun drawWaveMark(canvas: Canvas, left: Float, cy: Float, w: Float, amp: Float) {
        val wp = Paint(Paint.ANTI_ALIAS_FLAG)
        wp.style = Paint.Style.STROKE
        wp.strokeCap = Paint.Cap.ROUND
        wp.strokeJoin = Paint.Join.ROUND
        wp.strokeWidth = radius(0.0045f)
        wp.shader = LinearGradient(left, cy - amp, left, cy + amp, Color.rgb(236, 240, 245), Color.rgb(140, 150, 162), Shader.TileMode.CLAMP)
        path.reset()
        val steps = 40
        for (i in 0..steps) {
            val t = i / steps.toFloat()
            val env = sin(t * Math.PI).toFloat()
            val y = cy - sin(t * Math.PI * 4.0).toFloat() * amp * env
            val xx = left + t * w
            if (i == 0) path.moveTo(xx, y) else path.lineTo(xx, y)
        }
        canvas.drawPath(path, wp)
        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        lp.style = Paint.Style.STROKE
        lp.strokeCap = Paint.Cap.ROUND
        lp.strokeWidth = radius(0.0030f)
        lp.color = T.accent
        lp.setShadowLayer(radius(0.008f), 0f, 0f, T.accent)
        canvas.drawLine(left - radius(0.006f), cy, left + w + radius(0.006f), cy, lp)
        lp.clearShadowLayer()
    }

    private fun drawGear(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        p.reset()
        p.isAntiAlias = true
        p.color = Color.rgb(196, 204, 214)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.30f
        for (i in 0 until 8) {
            val a = i * Math.PI / 4.0
            val x1 = cx + cos(a).toFloat() * r * 0.80f
            val y1 = cy + sin(a).toFloat() * r * 0.80f
            val x2 = cx + cos(a).toFloat() * r * 1.10f
            val y2 = cy + sin(a).toFloat() * r * 1.10f
            canvas.drawLine(x1, y1, x2, y2, p)
        }
        p.strokeWidth = r * 0.26f
        canvas.drawCircle(cx, cy, r * 0.66f, p)
        canvas.drawCircle(cx, cy, r * 0.22f, p)
    }

    private fun drawPortamento(canvas: Canvas) {
        val accent = T.accent
        if (!drawingStatic) {
            // Moving parts: TIME value and slider.
            val ms = PortaTime.msForSlider(portamentoTime).toString()
            setText(min(width, height) * 0.021f, T.textDim, true, Paint.Align.RIGHT, 0.10f)
            val unitW = p.measureText(" ms")
            canvas.drawText(" ms", timeTrack.right, timeTrack.top - sy(0.032f), p)
            setText(min(width, height) * 0.040f, T.text, false, Paint.Align.RIGHT, 0.02f, light = true)
            canvas.drawText(ms, timeTrack.right - unitW, timeTrack.top - sy(0.032f), p)
            drawSlider(canvas, timeTrack, portamentoTime / 127f, accent, timeFill)
            return
        }
        drawCard(canvas, portPanel, accent)
        val headY = portPanel.top + portPanel.height() * 0.20f
        drawCardTitle(canvas, portPanel, "PORTAMENTO", accent, headY)


        // Indicator only: what the selected blend has.
        val portLabel = when {
            !portamentoEnabled -> "OFF"
            else -> (0..2).filter { (portaMask shr it) and 1 != 0 }.joinToString("  ") { "U${it + 1}" }
        }
        drawPill(canvas, portToggleRect, portLabel, accent, portamentoEnabled, textSize = min(width, height) * 0.021f)

        setText(min(width, height) * 0.021f, T.textDim, true, Paint.Align.LEFT, 0.22f)
        canvas.drawText("TIME", timeTrack.left, timeTrack.top - sy(0.032f), p)
    }

    private fun drawThird(canvas: Canvas) {
        val violet = T.violet
        drawCard(canvas, thirdPanel, violet)
        drawCardTitle(canvas, thirdPanel, "TERCA", violet, thirdPanel.top + thirdPanel.height() * 0.20f)

        val blinkOn = blinkOn()
        when {
            thirdScanResult != 0 -> drawPill(canvas, scanRect, "SCAN TERCA", T.green, true, textSize = min(width, height) * 0.030f)
            thirdScanning -> drawPill(canvas, scanRect, "SCAN TERCA", T.accent, blinkOn, textSize = min(width, height) * 0.030f)
            else -> drawPill(canvas, scanRect, "SCAN TERCA", violet, true, textSize = min(width, height) * 0.030f)
        }
        drawPill(canvas, thirdToggleRect, if (thirdEnabled) "ON" else "OFF", violet, thirdEnabled, solid = true, textSize = min(width, height) * 0.030f)

        val scanLabel = when {
            thirdScanning -> "HOLD 3 NOTES"
            thirdScanResult != 0 -> scanResultName(thirdScanResult)
            else -> ""
        }
        setText(min(width, height) * 0.023f, if (thirdScanResult != 0) T.green else T.textFaint, true, Paint.Align.CENTER, 0.16f)
        canvas.drawText(scanLabel, thirdPanel.centerX(), thirdPanel.top + thirdPanel.height() * 0.90f, p)
    }

    private fun scanResultName(code: Int): String {
        val names = arrayOf("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
        val cells = arrayOf("MAJOR ↑", "MAJOR ↓", "MINOR ↑", "MINOR ↓", "PHRYGIAN ↑", "HIJAZ ↑")
        val index = code - 1
        if (index < 0) return ""
        val root = index % 12
        val cell = index / 12
        if (cell !in cells.indices) return ""
        return "${names[root]} ${cells[cell]}"
    }

    /** Small readout left of the MIDI pill: "LATENCY 1.4 ms". Drawn every frame, no allocation. */
    private fun drawLatency(canvas: Canvas) {
        if (!connected || midiPillLeft <= 0f) return
        val y = sy(0.068f)
        setText(min(width, height) * 0.024f, T.accent, false, Paint.Align.RIGHT, 0.04f, light = true)
        val right = midiPillLeft - sx(0.012f)
        canvas.drawText(latencyText, right, y - (p.ascent() + p.descent()) / 2f, p)
        val valueW = p.measureText(latencyText)
        setText(min(width, height) * 0.018f, T.textFaint, true, Paint.Align.RIGHT, 0.18f)
        canvas.drawText("LATENCY", right - valueW - sx(0.008f), y - (p.ascent() + p.descent()) / 2f, p)
    }

    private fun drawRibbon(canvas: Canvas) {
        val accent = T.accent
        if (!drawingStatic) {
            drawSlider(canvas, sensTrack, (ribbonSensitivity - 0.25f) / 1.75f, accent, sensFill)
            drawRibbonWheel(canvas, accent)
            return
        }
        drawCard(canvas, ribbonPanel, null)

        val cy = sensTrack.centerY()
        setText(min(width, height) * 0.020f, T.textDim, true, Paint.Align.RIGHT, 0.12f)
        canvas.drawText("RANGE", rangeMinusRect.left - sx(0.012f), cy - (p.ascent() + p.descent()) / 2f, p)
        drawSmallButton(canvas, rangeMinusRect, "−", big = true)
        drawSmallButton(canvas, rangePlusRect, "+", big = true)
        setText(min(width, height) * 0.028f, T.text, false, Paint.Align.CENTER, 0.04f, light = true)
        val rangeValueX = (rangeMinusRect.right + rangePlusRect.left) / 2f
        canvas.drawText("±${ribbonRangeSemitones} st", rangeValueX, cy - (p.ascent() + p.descent()) / 2f, p)

        setText(min(width, height) * 0.020f, T.textDim, true, Paint.Align.RIGHT, 0.08f)
        canvas.drawText("SENSITIVITY", sensMinusRect.left - sx(0.012f), cy - (p.ascent() + p.descent()) / 2f, p)
        drawSmallButton(canvas, sensMinusRect, "−", big = true)
        drawSmallButton(canvas, sensPlusRect, "+", big = true)
        // SENSITIVITY value above its slider.
        setText(min(width, height) * 0.022f, T.text, true, Paint.Align.CENTER, 0.04f)
        canvas.drawText(String.format(java.util.Locale.US, "%.2f", ribbonSensitivity), sensTrack.centerX(), sensMinusRect.top - sy(0.004f), p)

        // TRANSPOSE -12..+12: white at 0, green when transposed.
        setText(min(width, height) * 0.020f, T.textDim, true, Paint.Align.RIGHT, 0.10f)
        canvas.drawText("TRANSPOSE", transMinusRect.left - sx(0.012f), cy - (p.ascent() + p.descent()) / 2f, p)
        drawSmallButton(canvas, transMinusRect, "−", big = true)
        drawSmallButton(canvas, transPlusRect, "+", big = true)
        setText(min(width, height) * 0.036f, if (transpose == 0) T.text else T.green, true, Paint.Align.CENTER, 0.02f)
        canvas.drawText(if (transpose > 0) "+$transpose" else "$transpose",
            (transMinusRect.right + transPlusRect.left) / 2f, cy - (p.ascent() + p.descent()) / 2f, p)



        // The strip: dark glass with a soft cool sheen.
        val rr = radius(0.018f)
        val zone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                ribbonTouch.left, ribbonTouch.top, ribbonTouch.right, ribbonTouch.top,
                intArrayOf(Color.rgb(14, 30, 46), Color.rgb(9, 14, 20), Color.rgb(14, 30, 46)),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(ribbonTouch, rr, rr, zone)
        val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, ribbonTouch.top, 0f, ribbonTouch.bottom,
                intArrayOf(Color.argb(22, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(0, 0, 0, 0), Color.argb(40, 0, 0, 0)),
                floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(ribbonTouch, rr, rr, sheen)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = hairline()
        p.color = T.tint(accent, 70)
        canvas.drawRoundRect(ribbonTouch, rr, rr, p)

        // Semitone scale: a line exactly where each semitone sounds (RANGE and
        // SENSITIVITY decide the spacing), numbered, centre = 0.
        drawRibbonScale(canvas, accent)

        val centerX = ribbonTouch.centerX()
        val cl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, ribbonTouch.top, 0f, ribbonTouch.bottom,
                intArrayOf(T.tint(accent, 0), T.tint(accent, 150), T.tint(accent, 0)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            style = Paint.Style.STROKE
            strokeWidth = max(1.5f, radius(0.0020f))
        }
        canvas.drawLine(centerX, ribbonTouch.top + ribbonTouch.height() * 0.24f, centerX, ribbonTouch.bottom, cl)


    }

    /** The wheel and its band: drawn every frame, no allocations. */
    private fun drawRibbonWheel(canvas: Canvas, accent: Int) {
        val centerX = ribbonTouch.centerX()
        // The marker rests in the middle; while touched it follows the finger.
        val markerX = centerX + ribbonValue * ribbonTouch.width() * 0.5f
        val my = ribbonTouch.centerY()
        val band = bandPaint
        if (abs(markerX - centerX) > 1f && band != null) {
            val bandH = ribbonTouch.height() * 0.10f
            val dx = markerX - centerX
            canvas.save()
            canvas.translate(centerX, my)
            canvas.scale(dx, 1f)
            // Unit-length band in local space (0..1 on x); rounded ends are not scaled.
            tmpRect.set(0f, -bandH / 2f, 1f, bandH / 2f)
            canvas.drawRect(tmpRect, band)
            canvas.restore()
        }
        val mr = radius(0.075f)
        haloPaint?.let {
            canvas.save()
            canvas.translate(markerX, my)
            canvas.drawCircle(0f, 0f, mr * 2.4f, it)
            canvas.restore()
        }
        dyn.reset()
        dyn.isAntiAlias = true
        dyn.style = Paint.Style.FILL
        dyn.color = Color.rgb(12, 18, 26)
        canvas.drawCircle(markerX, my, mr, dyn)
        dyn.style = Paint.Style.STROKE
        dyn.strokeWidth = radius(0.0035f)
        dyn.color = Color.rgb(224, 242, 255)
        canvas.drawCircle(markerX, my, mr, dyn)
        dyn.style = Paint.Style.FILL
        dyn.color = accent
        canvas.drawCircle(markerX, my, radius(0.007f), dyn)
    }

    /** Strip position (-1..1) where the ribbon reaches `semis` semitones. */
    private fun ribbonXForSemitones(semis: Float): Float {
        val range = ribbonRangeSemitones.toFloat()
        val dead = 0.008f   // same centre dead zone as the native Ribbon
        val n = (abs(semis) / range).coerceIn(0f, 1f).toDouble().pow(sqrt(ribbonSensitivity.toDouble())).toFloat()
        val pos = if (semis == 0f) 0f else (dead + n * (1f - dead)) * sign(semis)
        return ribbonTouch.centerX() + pos * ribbonTouch.width() * 0.5f
    }

    private fun drawRibbonScale(canvas: Canvas, accent: Int) {
        val range = ribbonRangeSemitones
        val labelEvery = when {
            range <= 7 -> 1
            range <= 12 -> 2
            range <= 18 -> 3
            else -> 4
        }
        val top = ribbonTouch.top + ribbonTouch.height() * 0.24f      // numbers sit above the lines
        val bottom = ribbonTouch.bottom - radius(0.010f)
        val labelY = ribbonTouch.top + ribbonTouch.height() * 0.15f
        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        lp.style = Paint.Style.STROKE
        lp.strokeCap = Paint.Cap.ROUND
        for (k in -range..range) {
            if (k == 0) continue
            val x = ribbonXForSemitones(k.toFloat())
            val labelled = abs(k) % labelEvery == 0
            val edge = abs(k) == range
            // Full-height line on every semitone; brighter on the numbered ones.
            lp.strokeWidth = if (labelled) max(1.5f, radius(0.0020f)) else hairline()
            lp.color = when {
                edge -> T.tint(accent, 150)
                labelled -> T.tint(accent, 95)
                else -> Color.argb(38, 255, 255, 255)
            }
            canvas.drawLine(x, top, x, bottom, lp)
            // Half-semitone marks when there is room.
            if (range <= 4) {
                val hx = ribbonXForSemitones(k - 0.5f * sign(k.toFloat()))
                lp.strokeWidth = hairline()
                lp.color = Color.argb(26, 255, 255, 255)
                canvas.drawLine(hx, bottom - ribbonTouch.height() * 0.12f, hx, bottom, lp)
                canvas.drawLine(hx, top, hx, top + ribbonTouch.height() * 0.12f, lp)
            }
            if (labelled) {
                val align = when {
                    edge && k < 0 -> Paint.Align.LEFT
                    edge -> Paint.Align.RIGHT
                    else -> Paint.Align.CENTER
                }
                val lx = when {
                    edge && k < 0 -> ribbonTouch.left + radius(0.014f)
                    edge -> ribbonTouch.right - radius(0.014f)
                    else -> x
                }
                setText(min(width, height) * 0.024f, if (edge) T.text else T.textDim, false, align, 0f)
                canvas.drawText(if (k > 0) "+$k" else "$k", lx, labelY, p)
            }
        }
        setText(min(width, height) * 0.024f, T.accent, true, Paint.Align.CENTER, 0f)
        canvas.drawText("0", ribbonTouch.centerX(), labelY, p)
    }

    private fun drawSlider(canvas: Canvas, track: RectF, norm: Float, color: Int, fill: Paint?) {
        val n = norm.coerceIn(0f, 1f)
        val h = max(radius(0.0050f), 3f)
        tmpRect.set(track.left, track.centerY() - h, track.right, track.centerY() + h)
        dyn.reset()
        dyn.isAntiAlias = true
        dyn.style = Paint.Style.FILL
        dyn.color = Color.rgb(8, 10, 13)
        canvas.drawRoundRect(tmpRect, h, h, dyn)
        dyn.style = Paint.Style.STROKE
        dyn.strokeWidth = hairline()
        dyn.color = Color.argb(28, 255, 255, 255)
        canvas.drawLine(tmpRect.left + h, tmpRect.bottom, tmpRect.right - h, tmpRect.bottom, dyn)
        dyn.style = Paint.Style.FILL
        tmpRect2.set(tmpRect.left, tmpRect.top, tmpRect.left + tmpRect.width() * n, tmpRect.bottom)
        if (tmpRect2.width() > 0f) {
            if (fill != null) canvas.drawRoundRect(tmpRect2, h, h, fill)
            else { dyn.color = color; canvas.drawRoundRect(tmpRect2, h, h, dyn) }
        }
        val x = tmpRect.left + tmpRect.width() * n
        val cy = tmpRect.centerY()
        val kr = radius(0.040f)
        knobShadow?.let {
            canvas.save()
            canvas.translate(x, cy + radius(0.003f))
            canvas.drawCircle(0f, 0f, kr * 1.45f, it)
            canvas.restore()
        }
        // Metal cap with a dark rim and a small lit dot in the middle.
        dyn.style = Paint.Style.FILL
        dyn.color = Color.rgb(12, 15, 19)
        canvas.drawCircle(x, cy, kr, dyn)
        knobCap?.let {
            canvas.save()
            canvas.translate(x, cy)
            canvas.drawCircle(0f, 0f, kr * 0.86f, it)
            canvas.restore()
        }
        dyn.style = Paint.Style.STROKE
        dyn.strokeWidth = hairline()
        dyn.color = Color.argb(120, 255, 255, 255)
        canvas.drawCircle(x, cy, kr * 0.86f, dyn)
        dyn.style = Paint.Style.FILL
        dyn.color = color
        canvas.drawCircle(x, cy, kr * 0.16f, dyn)
    }

    private fun drawSmallButton(canvas: Canvas, rect: RectF, label: String, big: Boolean = false) {
        drawKeyFace(canvas, rect, min(rect.height() * 0.30f, radius(0.016f)), null)
        setText(min(width, height) * (if (big) 0.038f else 0.030f), Color.rgb(206, 214, 224), false, Paint.Align.CENTER, 0f, light = true)
        canvas.drawText(label, rect.centerX(), textCenterY(rect), p)
    }

    private fun drawOverlayBackdrop(canvas: Canvas) {
        p.reset()
        p.style = Paint.Style.FILL
        p.color = Color.argb(214, 4, 6, 9)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
    }

    private fun drawSheet(canvas: Canvas, rect: RectF) {
        val r = radius(0.030f)
        val gp = gradientPaint(rect, Color.rgb(22, 27, 35), Color.rgb(14, 18, 24))
        gp.setShadowLayer(radius(0.040f), 0f, radius(0.010f), Color.argb(180, 0, 0, 0))
        canvas.drawRoundRect(rect, r, r, gp)
        gp.clearShadowLayer()
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = hairline()
        p.color = T.hairlineStrong
        canvas.drawRoundRect(rect, r, r, p)
    }

    private fun drawRow(canvas: Canvas, row: RectF) {
        drawRound(canvas, row, Color.argb(10, 255, 255, 255), T.hairline, hairline(), radius(0.016f))
    }

    private fun drawSettings(canvas: Canvas) {
        drawOverlayBackdrop(canvas)
        drawSheet(canvas, settingsPanel)

        for (i in 0 until settingsRowCount) {
            if (i == 4 || i == 5) continue
            val row = settingsRows[i]
            drawRow(canvas, row)
            setText(min(width, height) * 0.026f, T.text, true, Paint.Align.LEFT, 0.14f)
            val title = when (i) {
                in 0..2 -> "UPPER ${i + 1} CH"
                3 -> "LOWER CH"
                6 -> "PORTA BALANCE"
                else -> "MIDI LOG"
            }
            canvas.drawText(title, row.left + row.width() * 0.06f, textCenterY(row), p)

            if (i == 7) {
                val tg = RectF(settingsMinus[i].left, settingsMinus[i].top, settingsPlus[i].right, settingsPlus[i].bottom)
                drawPill(canvas, tg, if (midiLogOn) "ON" else "OFF", T.green, midiLogOn)
                continue
            }
            drawSmallButton(canvas, settingsMinus[i], "−")
            setText(min(width, height) * 0.036f, T.accent, false, Paint.Align.CENTER, 0.02f, light = true)
            val valueX = (settingsMinus[i].right + settingsPlus[i].left) / 2f
            val value = when (i) {
                in 0..2 -> channelMap[i].toString()
                6 -> portaBalance.toString()
                else -> if (lowerChannel == 0) "OFF" else lowerChannel.toString()
            }
            canvas.drawText(value, valueX, textCenterY(row), p)
            drawSmallButton(canvas, settingsPlus[i], "+")
        }
    }

    fun applyInitialSettings(
        portamentoEnabled: Boolean,
        portamentoTime: Int,
        thirdEnabled: Boolean,
        ribbon: RibbonConfig,
        channels: IntArray,
        lowerChannel: Int = 4,
        portaBalance: Int = 11,
        midiLogOn: Boolean = true,
        transpose: Int = 0
    ) {
        this.transpose = transpose.coerceIn(-12, 12)
        this.portaBalance = portaBalance.coerceIn(3, 40)
        this.midiLogOn = midiLogOn
        this.lowerChannel = lowerChannel.coerceIn(0, 16)
        this.portamentoEnabled = portamentoEnabled
        this.portamentoTime = portamentoTime.coerceIn(0, 127)
        this.thirdEnabled = thirdEnabled
        this.ribbonConfig = ribbon.fixed()
        if (channels.size >= 3 && channels.take(3).toSet().size == 3) {
            this.channelMap = channels.take(3).toIntArray()
        }
        invalidate()
    }

    private fun updateTime(x: Float) {
        val n = ((x - timeTrack.left) / timeTrack.width()).coerceIn(0f, 1f)
        portamentoTime = (n * 127f).roundToInt()
        listener?.onPortamentoTime(portamentoTime)
        invalidate()
    }

    private fun sensStep(dir: Int): Float =
        ((ribbonSensitivity * 20f).roundToInt() + dir).coerceIn(5, 40) / 20f

    private fun updateSens(x: Float) {
        val n = ((x - sensTrack.left) / sensTrack.width()).coerceIn(0f, 1f)
        updateRibbonConfig(ribbonConfig.copy(sensitivity = 0.25f + n * 1.75f))
    }

    private fun ribbonPos(x: Float) = ((x - ribbonTouch.centerX()) / (ribbonTouch.width() / 2f)).coerceIn(-1f, 1f)

    private fun updateRibbon(x: Float) {
        ribbonValue = ribbonPos(x)
        listener?.onRibbonTouch(1, ribbonValue)
        invalidate()
    }

    private fun updateRibbonConfig(config: RibbonConfig) {
        ribbonConfig = config.fixed()
        listener?.onRibbonConfig(config)
        invalidate()
    }

    private fun changeLowerChannel(delta: Int) {
        var next = lowerChannel + delta
        if (next < 0) next = 16
        if (next > 16) next = 0
        lowerChannel = next
        listener?.onLowerChannel(next)
        invalidate()
    }

    private fun changeChannel(slot: Int, delta: Int) {
        var next = channelMap[slot] + delta
        if (next < 1) next = 16
        if (next > 16) next = 1

        val other = channelMap.indexOf(next)
        if (other >= 0 && other != slot) {
            val old = channelMap[slot]
            channelMap[other] = old
        }
        channelMap[slot] = next
        listener?.onChannelMapChanged(slot, next)
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val index = event.actionIndex
                val x = event.getX(index)
                val y = event.getY(index)
                // A second finger may press buttons, but never steals a drag.
                if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN && dragTarget != DragTarget.NONE) {
                    handleTap(x, y, allowDrag = false)
                } else {
                    val target = handleTap(x, y, allowDrag = true)
                    if (target != DragTarget.NONE) {
                        dragTarget = target
                        dragPointerId = event.getPointerId(index)
                    }
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (dragTarget == DragTarget.NONE) return true
                val index = event.findPointerIndex(dragPointerId)
                if (index < 0) return true
                val x = event.getX(index)
                when (dragTarget) {
                    DragTarget.TIME -> updateTime(x)
                    DragTarget.SENS -> updateSens(x)
                    DragTarget.RIBBON -> updateRibbon(x)
                    else -> Unit
                }
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == dragPointerId) endDrag()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                endDrag()
                return true
            }
        }
        return true
    }

    private fun endDrag() {
        if (dragTarget == DragTarget.RIBBON) {
            // HOLD keeps the marker where the pitch was left.
            ribbonValue = 0f
            listener?.onRibbonTouch(2, ribbonValue)
            invalidate()
        }
        dragTarget = DragTarget.NONE
        dragPointerId = MotionEvent.INVALID_POINTER_ID
    }

    /** Handles a press; returns the drag target it started, if any. */
    private fun handleTap(x: Float, y: Float, allowDrag: Boolean): DragTarget {
        if (settingsOpen) {
            if (gearRect.contains(x, y) || !settingsPanel.contains(x, y)) {
                settingsOpen = false
                invalidate()
                return DragTarget.NONE
            }
            for (i in 0..2) {
                if (settingsMinus[i].contains(x, y)) { changeChannel(i, -1); return DragTarget.NONE }
                if (settingsPlus[i].contains(x, y)) { changeChannel(i, +1); return DragTarget.NONE }
            }
            if (settingsMinus[3].contains(x, y)) { changeLowerChannel(-1); return DragTarget.NONE }
            if (settingsPlus[3].contains(x, y)) { changeLowerChannel(+1); return DragTarget.NONE }
            if (settingsMinus[6].contains(x, y) || settingsPlus[6].contains(x, y)) {
                val d = if (settingsPlus[6].contains(x, y)) 1 else -1
                portaBalance = (portaBalance + d).coerceIn(3, 40)
                listener?.onPortaBalance(portaBalance)
                invalidate()
                return DragTarget.NONE
            }
            val logRect = RectF(settingsMinus[7].left, settingsMinus[7].top, settingsPlus[7].right, settingsPlus[7].bottom)
            if (logRect.contains(x, y)) {
                midiLogOn = !midiLogOn
                listener?.onMidiLog(midiLogOn)
                invalidate()
                return DragTarget.NONE
            }
            return DragTarget.NONE
        }

        if (panicRect.contains(x, y)) {
            panicFlashUntil = SystemClock.uptimeMillis() + 300L
            listener?.onPanic()
            invalidate()
            return DragTarget.NONE
        }

        if (gearRect.contains(x, y)) {
            settingsOpen = true
            invalidate()
            return DragTarget.NONE
        }

        // No ON/OFF button: portamento is switched by the blend itself (the
        // indicator only shows what the selected Sound has).
        if (portToggleRect.contains(x, y)) return DragTarget.NONE

        // TIME grab zone is limited to the PORTAMENTO panel. Previously it
        // spanned the full screen width and stole presses on the lower half of
        // the TERCA SCAN / ON-OFF buttons.
        if (allowDrag && x in portPanel.left..portPanel.right &&
            y in (timeTrack.top - sy(0.045f))..(timeTrack.bottom + sy(0.045f))) {
            updateTime(x)
            return DragTarget.TIME
        }

        if (scanRect.contains(x, y)) {
            // Real toggle: first press starts SCAN, second press cancels it immediately.
            thirdScanning = !thirdScanning
            if (thirdScanning) thirdScanResult = 0
            listener?.onThirdScan(thirdScanning)
            invalidate()
            return DragTarget.NONE
        }

        if (thirdToggleRect.contains(x, y)) {
            thirdEnabled = !thirdEnabled
            listener?.onThirdEnabled(thirdEnabled)
            invalidate()
            return DragTarget.NONE
        }

        if (rangeMinusRect.contains(x, y)) {
            updateRibbonConfig(ribbonConfig.copy(rangeSemitones = (ribbonRangeSemitones - 1).coerceAtLeast(1)))
            return DragTarget.NONE
        }

        if (rangePlusRect.contains(x, y)) {
            updateRibbonConfig(ribbonConfig.copy(rangeSemitones = (ribbonRangeSemitones + 1).coerceAtMost(12)))
            return DragTarget.NONE
        }

        // SENSITIVITY in fine 0.05 steps (value shown above the slider).
        if (sensMinusRect.contains(x, y)) {
            updateRibbonConfig(ribbonConfig.copy(sensitivity = sensStep(-1)))
            return DragTarget.NONE
        }

        if (sensPlusRect.contains(x, y)) {
            updateRibbonConfig(ribbonConfig.copy(sensitivity = sensStep(+1)))
            return DragTarget.NONE
        }

        if (transMinusRect.contains(x, y) || transPlusRect.contains(x, y)) {
            val t = (transpose + if (transPlusRect.contains(x, y)) 1 else -1).coerceIn(-12, 12)
            if (t != transpose) {
                transpose = t
                listener?.onTranspose(t)
                invalidate()
            }
            return DragTarget.NONE
        }

        if (allowDrag && x in sensTrack.left - sx(0.02f)..sensTrack.right + sx(0.02f) &&
            y in (sensTrack.top - sy(0.050f))..(sensTrack.bottom + sy(0.035f))) {
            updateSens(x)
            return DragTarget.SENS
        }

        if (allowDrag && ribbonTouch.contains(x, y)) {
            ribbonValue = ribbonPos(x)
            listener?.onRibbonTouch(0, ribbonValue)
            invalidate()
            return DragTarget.RIBBON
        }
        return DragTarget.NONE
    }
}
