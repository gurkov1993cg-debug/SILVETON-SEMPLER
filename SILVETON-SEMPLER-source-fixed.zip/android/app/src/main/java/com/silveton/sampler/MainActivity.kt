package com.silveton.sampler

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Android lifecycle host for the functional SILVETON SAMPLER touchscreen UI. */
class MainActivity : AppCompatActivity() {
    private lateinit var sampler: SamplerAppController
    private lateinit var samplerView: SilvetonSamplerView
    private var created = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        sampler = SamplerAppController(
            this,
            statusChanged = { warning ->
                if (::samplerView.isInitialized) runOnUiThread { samplerView.setWarning(warning) }
            },
            midiConnectionChanged = { count ->
                if (::samplerView.isInitialized) runOnUiThread { samplerView.setMidiConnections(count) }
            }
        )
        samplerView = SilvetonSamplerView(this, sampler)
        setContentView(samplerView)
        created = true
    }

    override fun onStart() {
        super.onStart()
        if (created && !sampler.start()) {
            samplerView.setWarning(sampler.engine.nativeLastTextError().ifBlank { "Sampler start failed" })
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemUi()
        if (created) sampler.resumeAudio()
    }

    override fun onPause() {
        if (created) sampler.pauseAudio()
        super.onPause()
    }

    override fun onDestroy() {
        if (created) sampler.close()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}
