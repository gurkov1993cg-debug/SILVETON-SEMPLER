package com.silveton.sampler

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import java.io.IOException

class MidiController(
    context: Context,
    private val connectionChanged: (Boolean) -> Unit,
    private val thirdScanChanged: (Int) -> Unit,
    private val thirdScanningChanged: (Boolean) -> Unit,
    private val statusChanged: (String?) -> Unit = {},
    /** Portamento state changed (bit mask of Uppers, bit0 = U1; 0 = OFF). */
    private val portaChanged: (Int) -> Unit = {},
    // App processing time (PA600 in -> PA600 out) of the last notes, in ms; -1 = unknown.
    private val latencyChanged: (Float) -> Unit = {}
) {
    private val midiManager = context.getSystemService(MidiManager::class.java)
    private val engine = NativeMidiEngine()
    private val sender = Pa600MidiSender()
    private val echoGuard = EchoGuard()
    // TRANSPOSE of the app (-12..+12); 0 = notes go back exactly as the PA600 sent
    // them. The PA600's own Transpose stays at 0. Also requires on the PA600:
    // Midi In Octave Transpose OFF, Upper/Lower Trk Octave Transp 0.
    private val octave = OctaveCompensator(0)
    private val parser = MidiByteStreamParser(::onMidiMessage)

    private var device: MidiDevice? = null
    private var deviceInfo: MidiDeviceInfo? = null
    private var toKorg: MidiInputPort? = null
    private var fromKorg: MidiOutputPort? = null
    private var receiver: MidiReceiver? = null

    private val midiThread = HandlerThread("SilvetonMidi", Process.THREAD_PRIORITY_URGENT_AUDIO).apply { start() }
    private val handler = Handler(midiThread.looper)
    @Volatile private var running = false
    @Volatile private var closed = false

    // Physical MIDI channels, zero-based. Defaults are Upper 1/2/3 -> MIDI 1/2/3.
    private val channelMap = intArrayOf(0, 1, 2)
    private var lastScanResult = 0
    private var lastScanRevision = 0
    private var lastScanning = false
    private var thirdEnabledState = false
    private var thirdTonalityValidState = false
    private var portamentoEnabledState = false
    private var portamentoTimeState = 120 // milliseconds
    // The PA600 runs with Local Control OFF: the app bridges U1/U2/U3 (+ Lower).
    // Zero-based Lower MIDI channel bridged; -1 = none.
    private var lowerChannel = 3

    // Runaway-traffic breaker. A human on a PA600 cannot produce anywhere near
    // this many channel messages; a MIDI feedback loop produces far more.
    private var rateWindowStartNs = 0L
    private var rateWindowCount = 0
    private var loopMutedUntilNs = 0L
    private val loopWindowNs = 100_000_000L
    private val loopMaxPerWindow = 500
    private val loopCooldownNs = 2_000_000_000L

    // Ribbon rest handling: after the finger leaves and the ribbon has settled,
    // the PA600 is returned to its normal +/-2 bend range.
    private var ribbonRestGeneration = 0
    // The Ribbon's raised range goes back to the blend's 0.25 s after the last
    // touch, exactly as in the golden A7 (a blend change right after the ribbon
    // then always finds the ribbon at rest and gets its range written again).
    private val ribbonRestDelayMs = 250L

    // False means physical PA600 Pitch Bend is byte-for-byte pass-through at
    // the normal +/-2 range. It becomes true only after Ribbon is actually used.
    private var pitchTransportConfigured = false

    private val poller = object : Runnable {
        override fun run() {
            if (!running) return
            // Always poll: the RIBBON module and glides live here.
            sendPacked(engine.nativePoll(nowUs()))
            reportLatency()
            if (loopMutedUntilNs != 0L && System.nanoTime() >= loopMutedUntilNs) {
                loopMutedUntilNs = 0L
                statusChanged(null)
            }
            val revision = engine.nativeThirdScanRevision()
            if (revision != lastScanRevision) {
                lastScanRevision = revision
                val scan = engine.nativeThirdScanResult()
                lastScanResult = scan
                if (scan != 0) {
                    thirdEnabledState = true
                    thirdTonalityValidState = true
                }
                thirdScanChanged(scan)
            }
            val scanning = engine.nativeThirdScanning()
            if (scanning != lastScanning) {
                lastScanning = scanning
                thirdScanningChanged(scanning)
            }
            val fast = pitchTransportConfigured || lastScanning || System.nanoTime() < ribbonBusyUntilNs
            handler.postDelayed(this, if (fast) 2L else 15L)
        }
    }

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            handler.post { if (!running) tryAutoConnect() }
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (deviceInfo?.id == info.id) {
                handler.post {
                    disconnectInternal()
                    tryAutoConnect()
                }
            }
        }
    }

    fun start() {
        midiManager.registerDeviceCallback(deviceCallback, handler)
        handler.post { tryAutoConnect() }
    }

    fun setPortamentoEnabled(enabled: Boolean) {
        handler.post {
            portamentoEnabledState = enabled
            if (!running) {
                engine.nativeSetPortamentoEnabled(enabled)
                publishPorta()
                return@post
            }
            // Korg engine: CC65/CC5 only — the Pitch Bend lane stays untouched.
            sendPacked(engine.nativeSetPortamentoEnabled(enabled))
            publishPorta()
        }
    }

    private var lastPortaMask = -1
    /** Tell the UI which Uppers have portamento now. */
    private fun publishPorta() {
        val mask = engine.nativePortaMask()
        portamentoEnabledState = mask != 0
        if (mask == lastPortaMask) return
        lastPortaMask = mask
        MidiLog.event("PORTA STATE " + (if (mask == 0) "OFF" else "ON " +
            (0..2).filter { (mask shr it) and 1 != 0 }.joinToString(" ") { "U${it + 1}" }))
        portaChanged(mask)
    }

    /** value = TIME slider position 0..127 (converted to milliseconds). */
    /** App TRANSPOSE in semitones (-12..+12). Held notes still release on their own pitch. */
    fun setTranspose(semitones: Int) {
        handler.post {
            octave.semitones = semitones
            sendStyleTranspose()
        }
    }

    // Style parts follow TRANSPOSE through RPN Coarse Tune (see StyleTranspose).
    // Written one channel every 3 ms (never one long burst) only when TRANSPOSE is
    // pressed, on connect and when a Sound/Performance is selected (the PA600 may
    // reset it then) - never while playing.
    private var styleTuneGeneration = 0

    private fun sendStyleTranspose() {
        if (!running) return
        val gen = ++styleTuneGeneration
        val semis = octave.semitones
        var delay = 0L
        for (ch in StyleTranspose.channels) {
            if (ch in channelMap || ch == lowerChannel) continue   // never an Upper / the Lower
            handler.postDelayed({
                if (running && gen == styleTuneGeneration) {
                    for (m in StyleTranspose.coarseTune(ch, semis)) sendRaw(m, "STYLE TRANSPOSE CH${ch + 1}")
                }
            }, delay)
            delay += 3L
        }
    }

    fun setPortamentoTime(value: Int) {
        val ms = PortaTime.msForSlider(value)
        handler.post {
            portamentoTimeState = ms
            sendPacked(engine.nativeSetPortamentoTimeMs(ms))
        }
    }

    private fun engagePitchTransport() {
        if (!running || pitchTransportConfigured) return
        // The Sound's Pitch Bend range is NEVER written: the core composes the
        // wheel and the Ribbon inside the range the PA600 reported for it.
        sendPacked(engine.nativeSetPitchTransportEnabled(true))
        pitchTransportConfigured = true
    }

    /** After a panic/reset the transport is gone; bring PORTA back if it is ON. */
    private fun reengagePortamento() {
        if (!running || !portamentoEnabledState) return
        sendPacked(engine.nativeSyncPortamento())
    }

    fun setThirdEnabled(enabled: Boolean) {
        handler.post {
            thirdEnabledState = enabled
            sendPacked(engine.nativeSetThirdEnabled(enabled))
        }
    }

    fun setThirdScanning(scanning: Boolean) {
        handler.post {
            sendPacked(engine.nativeSetThirdScanning(scanning))
            val actual = engine.nativeThirdScanning()
            if (actual != lastScanning) {
                lastScanning = actual
                thirdScanningChanged(actual)
            }
        }
    }

    fun setLowerChannel(midiChannel1Based: Int) {
        handler.post {
            lowerChannel = if (midiChannel1Based in 1..16) midiChannel1Based - 1 else -1
        }
    }

    // ---------------- RIBBON module ----------------
    private var ribbonConfig = RibbonConfig()
    private var ribbonBusyUntilNs = 0L

    fun setRibbonConfig(config: RibbonConfig) {
        handler.post {
            ribbonConfig = config
            sendPacked(
                engine.nativeSetRibbonSettings(
                    config.rangeSemitones.coerceIn(1, 24),
                    config.sensitivity.coerceIn(0.25f, 2.0f),
                    config.smoothMs, config.returnMs
                )
            )
        }
    }

    /** action: 0 = down, 1 = move, 2 = up; position -1..+1 across the strip. */
    fun ribbonTouch(action: Int, position: Float) {
        val p = position.coerceIn(-1f, 1f)
        handler.post {
            if (!running) return@post
            ribbonRestGeneration++
            ribbonBusyUntilNs = System.nanoTime() + 3_000_000_000L
            // The ribbon rides the Pitch Bend transport.
            if (action != 2) engagePitchTransport()
            sendPacked(engine.nativeRibbonTouch(action, p, nowUs()))
            if (action == 2) scheduleRibbonRest()
        }
    }

    private fun scheduleRibbonRest() {
        val generation = ribbonRestGeneration
        handler.postDelayed({
            if (!running || !pitchTransportConfigured) return@postDelayed
            if (generation != ribbonRestGeneration) return@postDelayed
            // A HOLD ribbon (or one still returning) keeps the transport.
            if (engine.nativeRibbonActive()) {
                scheduleRibbonRest()
                return@postDelayed
            }
            sendPacked(engine.nativePoll(nowUs()))
            sendPacked(engine.nativeSetPitchTransportEnabled(false))
            pitchTransportConfigured = false
        }, ribbonRestDelayMs)
    }

    fun setChannelMap(values1Based: IntArray) {
        if (values1Based.size < 3) return
        val candidate = intArrayOf(
            (values1Based[0] - 1).coerceIn(0, 15),
            (values1Based[1] - 1).coerceIn(0, 15),
            (values1Based[2] - 1).coerceIn(0, 15)
        )
        if (candidate.toSet().size != 3) return
        handler.post {
            panicOutputAndReset()
            for (i in 0..2) channelMap[i] = candidate[i]
            reengagePortamento()
        }
    }

    fun setGlideBalance(ccPerDoubling: Int) {
        handler.post { engine.nativeSetGlideBalance(ccPerDoubling.toFloat()) }
    }

    fun setGlidePoints(flat: FloatArray) {
        if (flat.size < 3) return
        handler.post { engine.nativeSetGlidePoints(flat) }
    }

    private fun tryAutoConnect() {
        if (closed || running) return
        val all = midiManager.devices
        MidiLog.event("SCAN MIDI DEVICES: " + if (all.isEmpty()) "none" else all.joinToString("; ") {
            val typeName = when (it.type) { MidiDeviceInfo.TYPE_USB -> "USB"; MidiDeviceInfo.TYPE_VIRTUAL -> "VIRTUAL"; MidiDeviceInfo.TYPE_BLUETOOTH -> "BT"; else -> "type" + it.type }
            (it.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "?") + " [" + typeName + " in=" + it.inputPortCount + " out=" + it.outputPortCount + "]"
        })
        val info = pickKorgDevice(all)
        if (info == null) {
            MidiLog.event("NO USABLE USB MIDI DEVICE (waiting for the PA600)")
            connectionChanged(false)
            return
        }
        open(info)
    }

    /**
     * Only a real USB MIDI device with both directions is accepted. Virtual
     * ports (other apps, loopback drivers) and Bluetooth are never chosen:
     * bridging into a virtual port that echoes back is an instant MIDI loop.
     * A device whose name mentions KORG / PA is preferred.
     */
    private fun pickKorgDevice(devices: Array<MidiDeviceInfo>): MidiDeviceInfo? {
        return devices
            .filter { it.type == MidiDeviceInfo.TYPE_USB && it.inputPortCount > 0 && it.outputPortCount > 0 }
            .maxByOrNull { info ->
                val props = info.properties
                val text = listOfNotNull(
                    props.getString(MidiDeviceInfo.PROPERTY_NAME),
                    props.getString(MidiDeviceInfo.PROPERTY_MANUFACTURER),
                    props.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
                ).joinToString(" ").uppercase()
                when {
                    "PA600" in text || "PA 600" in text -> 3
                    "KORG" in text -> 2
                    Regex("\\bPA\\d").containsMatchIn(text) -> 1
                    else -> 0
                }
            }
    }

    private fun open(info: MidiDeviceInfo) {
        midiManager.openDevice(info, { opened ->
            if (opened == null) {
                MidiLog.event("OPEN FAILED (Android refused the device)")
                connectionChanged(false)
                return@openDevice
            }
            handler.post {
                if (closed) {
                    opened.close()
                    return@post
                }
                val input = opened.openInputPort(0)
                val output = opened.openOutputPort(0)
                if (input == null || output == null) {
                    MidiLog.event("OPEN PORTS FAILED in=" + (input != null) + " out=" + (output != null))
                    input?.close()
                    output?.close()
                    opened.close()
                    connectionChanged(false)
                    return@post
                }

                val rx = object : MidiReceiver() {
                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                        // Notes from the PA600 go to the FRONT of the MIDI thread's queue,
                        // ahead of ribbon/glide polling, so a note never waits. Packets keep
                        // their order: they are queued here and drained oldest first.
                        rxQueue.add(RxPacket(msg.copyOfRange(offset, offset + count), timestamp))
                        handler.postAtFrontOfQueue(rxDrain)
                    }
                }
                output.connect(rx)

                device = opened
                deviceInfo = info
                toKorg = input
                sender.attach(input)
                fromKorg = output
                receiver = rx
                running = true
                MidiLog.event("CONNECTED: " + (info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "?") +
                    "  uppers=" + channelMap.joinToString("/") { (it + 1).toString() } + "  lower=" + (lowerChannel + 1))
                // True transparent baseline for Local Control OFF. Connecting
                // must not alter the PA600: no RPN, no CC5/CC65 and no Pitch
                // Bend reset are emitted here. We only reset the app's internal
                // pitch-composition state.
                pitchTransportConfigured = false
                engine.nativeSetPitchTransportEnabled(false)
                // Restore Portamento only when the user explicitly left it ON.
                // With it OFF, connection remains byte-for-byte transparent.
                engine.nativeSetPortamentoTimeMs(portamentoTimeState)
                reengagePortamento()
                handler.removeCallbacks(poller)
                handler.post(poller)
                sendStyleTranspose()
                connectionChanged(true)
            }
        }, handler)
    }


    private fun canonicalSlotForPhysical(physicalChannel: Int): Int {
        for (i in 0..2) if (channelMap[i] == physicalChannel) return i
        return -1
    }

    private fun physicalChannelForCanonical(canonicalChannel: Int): Int {
        return if (canonicalChannel in 0..2) channelMap[canonicalChannel] else canonicalChannel
    }

    private fun onMidiMessage(message: ByteArray) {
        if (!running || message.isEmpty()) return
        MidiLog.midi("IN ", message)

        val statusByte = message[0].toInt() and 0xFF
        // System messages (MIDI Clock, Active Sensing, Start/Stop, SysEx, ...)
        // are never returned to the PA600. Echoing Clock/Active Sensing/SysEx
        // back into the instrument is a classic source of loops and freezes.
        if (statusByte !in 0x80..0xEF || message.size > 3) return

        if (loopBreakerTripped()) return

        val command = statusByte and 0xF0
        val physicalChannel = statusByte and 0x0F
        val canonical = canonicalSlotForPhysical(physicalChannel)
        val d1raw = if (message.size > 1) message[1].toInt() and 0x7F else 0

        // Sound/STS selection on an Upper: the PA600 already switched; only
        // re-assert what the app owns on that Upper. Never returned.
        if (command == 0xC0) {
            if (canonical >= 0) {
                // The Sound's portamento switch (CC65 just before this PC) is
                // followed: the app's PORTA turns ON/OFF with the blend. Nothing
                // is sent for it — the PA600 has already switched.
                sendPacked(engine.nativeObserveReport(0xC0 or canonical, d1raw, 0, nowUs()))
                if (canonical == 0 && octave.semitones != 0) sendStyleTranspose()   // new Sound/Performance
                if (pitchTransportConfigured) sendPacked(engine.nativeSyncPitchChannel(canonical))
                publishPorta()
            }
            return
        }
        // Reports (volume, pan, bank, CC5/65, RPN, All Notes Off, ...) and
        // echoes of what the app itself sent are never returned: that was the
        // MIDI loop seen in the session log (CC5 ping-pong).
        // The PA600 reports each Sound's Pitch Bend range (RPN 0) when it is
        // selected: learn it (never return it).
        // (The PA600's echo of a range the app wrote for the Ribbon is not the blend's.)
        if (command == 0xB0 && canonical >= 0 &&
            (d1raw == 6 || d1raw == 38 || d1raw == 100 || d1raw == 101 || d1raw == 65 || d1raw == 5) &&
            !echoGuard.isEcho(message, System.nanoTime())) {
            val d2raw = if (message.size > 2) message[2].toInt() and 0x7F else 0
            sendPacked(engine.nativeObserveReport(0xB0 or canonical, d1raw, d2raw, nowUs()))
            if (d1raw == 6) MidiLog.event("BEND RANGE U${canonical + 1} learned = " + engine.nativeLearnedBendRange(canonical))
        }
        if (!BridgeFilter.forward(statusByte, d1raw)) return
        val nowNs = System.nanoTime()
        if (echoGuard.isEcho(message, nowNs)) return
        // Notes: drop the PA600's echoes of notes the app sent and never let a
        // release go missing (octave-shifted note-offs are corrected).
        val filtered = echoGuard.filterNote(message, nowNs)
        if (filtered.isEmpty()) {
            MidiLog.event("DROP echo/stray " + MidiLog.describe(message))
            return
        }
        if (filtered.size == 2) MidiLog.event("FIX lost release -> " + MidiLog.describe(filtered[0]))
        else if (filtered[0] !== message) MidiLog.event("FIX release -> " + MidiLog.describe(filtered[0]))
        for (m in filtered) onBridgedMessage(m, canonical, physicalChannel, m[0].toInt() and 0xF0)
    }

    private fun onBridgedMessage(message: ByteArray, canonical: Int, physicalChannel: Int, command: Int) {
        if (canonical < 0) {
            // Local OFF: the Lower part must be returned or it stays silent.
            // Style/Drum/Chord/Player/Global channels are never echoed: the
            // PA600 already plays them, returning them doubles them, and a
            // Global-channel echo re-enters the keyboard -> infinite loop.
            if (physicalChannel == lowerChannel) sendRaw(message)
            return
        }

        val canonicalStatus = command or canonical
        val d1 = if (message.size > 1) message[1].toInt() and 0x7F else 0
        val d2 = if (message.size > 2) message[2].toInt() and 0x7F else 0
        val packed = engine.nativeProcess(canonicalStatus, d1, d2, message.size, nowUs())
        sendPacked(packed)
    }

    private fun loopBreakerTripped(): Boolean {
        val now = System.nanoTime()
        if (loopMutedUntilNs != 0L) {
            if (now < loopMutedUntilNs) return true
            loopMutedUntilNs = 0L
            statusChanged(null)
        }
        if (now - rateWindowStartNs > loopWindowNs) {
            rateWindowStartNs = now
            rateWindowCount = 0
        }
        rateWindowCount++
        if (rateWindowCount <= loopMaxPerWindow) return false

        // Runaway traffic: stop everything, release all notes, and ignore input
        // for a short cooldown so the loop dies out.
        loopMutedUntilNs = now + loopCooldownNs
        rateWindowCount = 0
        MidiLog.event("LOOP BREAKER: >$loopMaxPerWindow msgs in 100 ms -> panic, input muted 2 s")
        panicOutputAndReset()
        reengagePortamento()
        statusChanged("MIDI LOOP STOPPED")
        return true
    }

    private fun sendPacked(packed: IntArray) {
        var i = 0
        while (i + 3 < packed.size) {
            val size = packed[i + 3].coerceIn(1, 3)
            val status = packed[i] and 0xFF
            val bytes = ByteArray(size)
            var canonical = -1
            if (status in 0x80..0xEF) {
                canonical = status and 0x0F
                val physical = physicalChannelForCanonical(canonical)
                bytes[0] = ((status and 0xF0) or physical).toByte()
            } else {
                bytes[0] = status.toByte()
            }
            if (size > 1) bytes[1] = (packed[i + 1] and 0x7F).toByte()
            if (size > 2) bytes[2] = (packed[i + 2] and 0x7F).toByte()
            // The readable label is only built when a log or trace will print it.
            val label = if (MidiLog.enabled || sender.tracing) traceLabel(status, packed[i + 1], packed[i + 2], canonical) else ""
            sendRaw(bytes, label)
            i += 4
        }
    }

    private fun traceLabel(status: Int, data1: Int, data2: Int, canonical: Int): String {
        if (status !in 0x80..0xEF) return "SYSTEM"
        val command = status and 0xF0
        val upper = if (canonical in 0..2) "U${canonical + 1}" else "CH${(status and 0x0F) + 1}"
        return when {
            command == 0x90 && (data2 and 0x7F) != 0 && canonical == 2 && thirdEnabledState && thirdTonalityValidState -> "TERCA $upper"
            command == 0x90 && (data2 and 0x7F) != 0 -> "NOTE ON $upper"
            command == 0x80 || (command == 0x90 && (data2 and 0x7F) == 0) -> "NOTE OFF $upper"
            command == 0xB0 && (data1 and 0x7F) == 5 -> "PORTA TIME $upper"
            command == 0xB0 && (data1 and 0x7F) == 65 && (data2 and 0x7F) != 0 -> "PORTA ON $upper"
            command == 0xB0 && (data1 and 0x7F) == 65 -> "PORTA OFF $upper"
            command == 0xB0 && (data1 and 0x7F) == 123 -> "ALL NOTES OFF $upper"
            command == 0xB0 && (data1 and 0x7F) == 120 -> "ALL SOUND OFF $upper"
            command == 0xE0 -> "PITCH $upper"
            else -> "MIDI $upper"
        }
    }

    // ---------------- Incoming packets (front of the queue, in order) ----------------
    private class RxPacket(val bytes: ByteArray, val timestampNs: Long)
    private val rxQueue = java.util.concurrent.ConcurrentLinkedQueue<RxPacket>()
    private val rxDrain = Runnable {
        while (true) {
            val packet = rxQueue.poll() ?: break
            // Android stamps each packet when it arrives (System.nanoTime base).
            rxTimestampNs = packet.timestampNs
            parser.feed(packet.bytes, 0, packet.bytes.size)
            rxTimestampNs = 0L
        }
    }

    // ---------------- Latency (PA600 in -> PA600 out) ----------------
    // Set while an incoming packet is being processed on the MIDI thread.
    private var rxTimestampNs = 0L
    private val latencySamples = FloatArray(32)
    private var latencyCount = 0
    private var latencyNext = 0
    private var latencyReportedAtNs = 0L
    private var latencyShown = -2f

    private fun recordLatency(message: ByteArray) {
        val rx = rxTimestampNs
        if (rx <= 0L || message.size < 3) return
        val status = message[0].toInt() and 0xF0
        if (status != 0x90 || (message[2].toInt() and 0x7F) == 0) return   // Note On only
        val ms = (System.nanoTime() - rx) / 1_000_000f
        if (ms < 0f || ms > 1000f) return                                 // clock glitch
        latencySamples[latencyNext] = ms
        latencyNext = (latencyNext + 1) % latencySamples.size
        if (latencyCount < latencySamples.size) latencyCount++
    }

    /** Average of the last notes, sent to the screen at most twice a second. */
    private fun reportLatency() {
        val now = System.nanoTime()
        if (now - latencyReportedAtNs < 500_000_000L) return
        latencyReportedAtNs = now
        val value = if (!running || latencyCount == 0) -1f else {
            var sum = 0f
            for (i in 0 until latencyCount) sum += latencySamples[i]
            sum / latencyCount
        }
        if (value != latencyShown) {
            latencyShown = value
            latencyChanged(value)
        }
    }

    private fun clearLatency() {
        latencyCount = 0
        latencyNext = 0
        latencyShown = -2f
        latencyChanged(-1f)
    }

    private fun sendRaw(original: ByteArray, label: String = "PASS") {
        // Notes go out one octave up; everything else unchanged.
        val message = octave.outgoing(original, System.nanoTime())
        val ok = sender.send(message, label)
        if (ok) recordLatency(message)
        if (ok) echoGuard.rememberSent(message, System.nanoTime())
        MidiLog.midi(if (ok) "OUT" else "ERR", message, if (ok) label else "SEND FAILED $label")
        if (!ok) {
            if (running) {
                running = false
                handler.post {
                    disconnectInternal()
                    tryAutoConnect()
                }
            }
            return
        }
    }

    private fun panicOutputAndReset() {
        // The final Android sender is the physical source of truth: it knows
        // exactly which Note Ons were successfully accepted by MidiInputPort.
        if (running) {
            val panicChannels = if (lowerChannel in 0..15 && lowerChannel !in channelMap) {
                channelMap.copyOf() + lowerChannel
            } else {
                channelMap.copyOf()
            }
            // Ribbon back to 0 on its own destination (clears TUNING too).
            sendPacked(engine.nativeRibbonReset())
            // A Ribbon range raised for the Ribbon goes back to the blend's value.
            if (pitchTransportConfigured) sendPacked(engine.nativeSetPitchTransportEnabled(false))
            sender.panic(panicChannels)
        } else {
            sender.clearState()
        }

        // Clear the independent native ledgers/states without re-sending a
        // second set of panic packets. nativePanic() performs the state reset;
        // its returned packets are deliberately ignored here.
        engine.nativePanic()
        octave.clear()              // every wire note was released above
        pitchTransportConfigured = false
        ribbonRestGeneration++
    }

    private fun disconnectInternal() {
        MidiLog.event("DISCONNECT")
        clearLatency()
        echoGuard.clear()
        panicOutputAndReset()
        octave.clear()
        running = false
        handler.removeCallbacks(poller)
        try { fromKorg?.close() } catch (_: IOException) {}
        try { toKorg?.close() } catch (_: IOException) {}
        try { device?.close() } catch (_: IOException) {}
        sender.attach(null)
        parser.reset()
        fromKorg = null
        toKorg = null
        device = null
        deviceInfo = null
        receiver = null
        connectionChanged(false)
    }

    fun panic() {
        handler.post {
            panicOutputAndReset()
            parser.reset()
            reengagePortamento()
        }
    }

    fun close() {
        closed = true
        handler.post {
            disconnectInternal()
            midiManager.unregisterDeviceCallback(deviceCallback)
            midiThread.quitSafely()
        }
    }

    private fun nowUs(): Long = System.nanoTime() / 1000L
}
