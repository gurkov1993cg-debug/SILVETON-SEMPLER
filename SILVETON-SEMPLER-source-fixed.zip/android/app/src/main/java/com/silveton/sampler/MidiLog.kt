package com.silveton.sampler

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.provider.MediaStore
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Session log written to the phone storage:  Download/Silveton MIDI Live/
 * One text file per app session. Every MIDI message IN (from the PA600) and OUT
 * (to the PA600) with a millisecond timestamp, plus UI actions, settings and
 * warnings. Written on a background thread so it never delays the MIDI path.
 */
object MidiLog {
    const val FOLDER = "Silveton MIDI Live"

    @Volatile var enabled = true
    private var writer: BufferedWriter? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val t0 = SystemClock.elapsedRealtimeNanos()
    @Volatile var location: String = ""
        private set

    fun start(context: Context) {
        if (writer != null) return
        val name = "silveton_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val stream: OutputStream? = try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                location = "Download/$FOLDER/$name"
                uri?.let { context.contentResolver.openOutputStream(it) }
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
                val target = if (dir.exists() || dir.mkdirs()) dir else File(context.getExternalFilesDir(null), FOLDER).apply { mkdirs() }
                val file = File(target, name)
                location = file.absolutePath
                FileOutputStream(file)
            }
        } catch (e: Exception) {
            // Fallback: app folder (always writable).
            try {
                val dir = File(context.getExternalFilesDir(null), FOLDER).apply { mkdirs() }
                val file = File(dir, name)
                location = file.absolutePath
                FileOutputStream(file)
            } catch (_: Exception) { null }
        }
        if (stream == null) return
        writer = BufferedWriter(OutputStreamWriter(stream, Charsets.UTF_8), 64 * 1024)
        thread = HandlerThread("SilvetonLog").apply { start() }
        handler = Handler(thread!!.looper)
        val version = try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        } catch (_: Exception) { "?" }
        event("SESSION START  app=$version  android=${Build.VERSION.RELEASE}  device=${Build.MANUFACTURER} ${Build.MODEL}")
        event("FORMAT: time_ms  DIR  hex bytes  | meaning")
        scheduleFlush()
    }

    private fun scheduleFlush() {
        handler?.postDelayed({
            try { writer?.flush() } catch (_: Exception) {}
            scheduleFlush()
        }, 1000L)
    }

    private fun stamp(): String {
        val ms = (SystemClock.elapsedRealtimeNanos() - t0) / 1_000_000.0
        return String.format(Locale.US, "%10.1f", ms)
    }

    private fun write(line: String) {
        if (!enabled) return
        val h = handler ?: return
        h.post {
            try {
                writer?.write(line)
                writer?.newLine()
            } catch (_: Exception) {}
        }
    }

    fun midi(direction: String, bytes: ByteArray, label: String = "") {
        if (!enabled || handler == null) return
        val hex = bytes.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
        write("${stamp()}  $direction  ${hex.padEnd(9)}| ${describe(bytes)}${if (label.isNotEmpty() && label != "PASS") "  [$label]" else ""}")
    }

    fun event(text: String) {
        write("${stamp()}  ---  $text")
    }

    fun flush() {
        handler?.post { try { writer?.flush() } catch (_: Exception) {} }
    }

    fun close() {
        val h = handler ?: return
        event("SESSION END")
        h.post {
            try { writer?.flush(); writer?.close() } catch (_: Exception) {}
            writer = null
        }
        thread?.quitSafely()
        handler = null
        thread = null
    }

    private val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    fun describe(b: ByteArray): String {
        if (b.isEmpty()) return ""
        val s = b[0].toInt() and 0xFF
        if (s >= 0xF0) return "SYSTEM"
        val ch = (s and 0x0F) + 1
        val d1 = if (b.size > 1) b[1].toInt() and 0x7F else 0
        val d2 = if (b.size > 2) b[2].toInt() and 0x7F else 0
        val note = "${noteNames[d1 % 12]}${d1 / 12 - 1}"
        return when (s and 0xF0) {
            0x90 -> if (d2 == 0) "ch$ch NOTE OFF $note" else "ch$ch NOTE ON  $note vel $d2"
            0x80 -> "ch$ch NOTE OFF $note"
            0xB0 -> "ch$ch CC $d1 = $d2" + when (d1) {
                5 -> " (porta time)"; 65 -> " (porta sw)"; 64 -> " (damper)"; 6 -> " (data entry)"
                38 -> " (data LSB)"; 100 -> " (RPN LSB)"; 101 -> " (RPN MSB)"; 120 -> " (all sound off)"
                123 -> " (all notes off)"; 0 -> " (bank MSB)"; 32 -> " (bank LSB)"; else -> ""
            }
            0xC0 -> "ch$ch PROGRAM $d1"
            0xE0 -> "ch$ch PITCH BEND ${d1 or (d2 shl 7)}"
            0xD0 -> "ch$ch CH PRESSURE $d1"
            0xA0 -> "ch$ch POLY PRESSURE $note $d2"
            else -> ""
        }
    }
}
