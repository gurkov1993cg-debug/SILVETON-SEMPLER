package com.silveton.sampler

class NativeMidiEngine {
    init {
        System.loadLibrary("silveton_jni")
        nativeInit()
    }

    external fun nativeInit()
    external fun nativeSetPortamentoEnabled(enabled: Boolean): IntArray
    external fun nativeSetPortamentoTimeMs(ms: Int): IntArray
    external fun nativeSyncPortamento(): IntArray
    external fun nativeSyncPitchChannel(upper: Int): IntArray
    external fun nativeSetPitchTransportEnabled(enabled: Boolean): IntArray

    external fun nativeSetThirdEnabled(enabled: Boolean): IntArray
    external fun nativeSetThirdScanning(scanning: Boolean): IntArray
    external fun nativeThirdScanResult(): Int
    external fun nativeThirdScanRevision(): Int
    external fun nativeThirdScanning(): Boolean

    external fun nativeRibbonTouch(action: Int, position: Float, nowUs: Long): IntArray
    external fun nativeSetRibbonSettings(range: Int, sensitivity: Float, smoothMs: Int, returnMs: Int): IntArray
    external fun nativeRibbonReset(): IntArray
    external fun nativeRibbonActive(): Boolean
    external fun nativeObserveReport(status: Int, data1: Int, data2: Int, nowUs: Long): IntArray
    /** Bit mask of the Uppers with portamento active (bit0 = U1). */
    external fun nativePortaMask(): Int
    external fun nativeLearnedBendRange(upper: Int): Int
    external fun nativeSetGlidePoints(flat: FloatArray)
    external fun nativeSetGlideBalance(ccPerDoubling: Float)

    external fun nativeProcess(status: Int, data1: Int, data2: Int, size: Int, nowUs: Long): IntArray
    external fun nativePoll(nowUs: Long): IntArray
    external fun nativePanic(): IntArray
}
