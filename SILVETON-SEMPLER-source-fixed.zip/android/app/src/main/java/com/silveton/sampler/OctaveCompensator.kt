package com.silveton.sampler

/**
 * TRANSPOSE of every note the app returns to the PA600 (-12..+12 semitones).
 *
 * The PA600's own Transpose cannot be used with Local Control OFF: it sends
 * nothing when it changes and transposes each received Note Off with the value
 * of THAT moment, so a note held across a change keeps sounding. Here the app
 * transposes itself and remembers the wire note of every held (channel, note):
 * a Note Off always goes to the wire note its Note On used, whatever the
 * transpose is now, so nothing can hang. A change only affects new notes.
 * Only note numbers change: CC, Pitch Bend, portamento and everything else
 * pass untouched (TERCA, MONO and portamento work on the played keys).
 */
class OctaveCompensator(semitones: Int = 0) {
    @Volatile var semitones: Int = semitones.coerceIn(-12, 12)
        set(value) { field = value.coerceIn(-12, 12) }

    // Wire note of each held (channel, played note) and how many times it is held.
    private val wireFor = Array(16) { IntArray(128) { -1 } }
    private val count = Array(16) { IntArray(128) }

    fun outgoing(message: ByteArray, @Suppress("UNUSED_PARAMETER") nowNs: Long): ByteArray {
        if (message.size < 3) return message
        val status = message[0].toInt() and 0xFF
        val cmd = status and 0xF0
        if (cmd != 0x80 && cmd != 0x90) return message
        val ch = status and 0x0F
        val note = message[1].toInt() and 0x7F
        val vel = message[2].toInt() and 0x7F
        val wire: Int
        if (cmd == 0x90 && vel > 0) {
            // The same note pressed again while held keeps its first wire note,
            // so both of its releases reach it.
            if (count[ch][note] == 0) wireFor[ch][note] = shifted(note)
            count[ch][note]++
            wire = wireFor[ch][note]
        } else if (count[ch][note] > 0) {
            wire = wireFor[ch][note]
            if (--count[ch][note] == 0) wireFor[ch][note] = -1
        } else {
            wire = shifted(note)          // release of a note not held: current transpose
        }
        if (wire == note) return message
        return byteArrayOf(message[0], wire.toByte(), message[2])
    }

    private fun shifted(note: Int): Int {
        var t = note + semitones
        while (t > 127) t -= 12
        while (t < 0) t += 12
        return t
    }

    fun clear() {
        for (row in wireFor) row.fill(-1)
        for (row in count) row.fill(0)
    }
}
