package com.silveton.sampler

import android.media.midi.MidiInputPort
import android.util.Log
import java.io.IOException

/**
 * The single final Android MIDI-output transport.
 *
 * It counts the notes that were ACTUALLY accepted by MidiInputPort.send(), so
 * PANIC releases exactly the final physical byte stream, after the canonical
 * U1/U2/U3 -> user channel mapping.
 */
class Pa600MidiSender {
    private var port: MidiInputPort? = null
    private val noteRefs: Array<IntArray> = Array(16) { IntArray(128) }
    /** adb logcat trace (MIDI_TRACE), read once per connection, not per message. */
    @Volatile var tracing = false
        private set

    @Synchronized
    fun attach(newPort: MidiInputPort?) {
        port = newPort
        tracing = Log.isLoggable("MIDI_TRACE", Log.DEBUG)
        if (newPort == null) clearState()
    }

    @Synchronized
    fun send(message: ByteArray, label: String): Boolean {
        val out = port ?: return false
        return try {
            out.send(message, 0, message.size)
            trackSuccessfulOutput(message)
            if (tracing) {
                Log.d("MIDI_TRACE", "OUT ${hex(message)} $label")
            }
            true
        } catch (e: IOException) {
            if (tracing) {
                Log.e("MIDI_TRACE", "SEND FAILED ${hex(message)} $label", e)
            }
            false
        }
    }

    @Synchronized
    fun clearState() {
        for (ch in 0 until 16) noteRefs[ch].fill(0)
    }

    private fun noteOff(upper: Int, note: Int): Boolean {
        require(upper in 0..15)
        val n = note.coerceIn(0, 127)
        return send(byteArrayOf((0x90 or upper).toByte(), n.toByte(), 0x00), "NOTE OFF CH${upper + 1}")
    }

    private fun pitchBend(upper: Int, bend14: Int): Boolean {
        require(upper in 0..15)
        val value = bend14.coerceIn(0, 16383)
        val lsb = value and 0x7F
        val msb = (value shr 7) and 0x7F
        return send(byteArrayOf((0xE0 or upper).toByte(), lsb.toByte(), msb.toByte()), "PITCH CH${upper + 1}")
    }

    @Synchronized
    fun panic(physicalUpperChannels: IntArray) {
        for (ch in physicalUpperChannels.distinct()) {
            if (ch !in 0..15) continue
            val refs = noteRefs[ch].copyOf()
            for (note in 0..127) repeat(refs[note]) { noteOff(ch, note) }
            send(byteArrayOf((0xB0 or ch).toByte(), 0x7B.toByte(), 0x00.toByte()), "ALL NOTES OFF CH${ch + 1}")
            send(byteArrayOf((0xB0 or ch).toByte(), 0x78.toByte(), 0x00.toByte()), "ALL SOUND OFF CH${ch + 1}")
            pitchBend(ch, 8192)
        }
        clearState()
    }

    private fun trackSuccessfulOutput(message: ByteArray) {
        if (message.size < 2) return
        val status = message[0].toInt() and 0xFF
        if (status !in 0x80..0xEF) return
        val command = status and 0xF0
        val ch = status and 0x0F
        val d1 = message[1].toInt() and 0x7F
        val d2 = if (message.size > 2) message[2].toInt() and 0x7F else 0

        if (command == 0x90 && d2 != 0) {
            noteRefs[ch][d1]++
        } else if (command == 0x80 || command == 0x90) {
            if (noteRefs[ch][d1] > 0) noteRefs[ch][d1]--
        } else if (command == 0xB0 && (d1 == 120 || d1 == 123)) {
            noteRefs[ch].fill(0)
        }
    }

    private fun hex(message: ByteArray): String = message.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
}
