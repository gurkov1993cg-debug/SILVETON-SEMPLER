package com.silveton.sampler

import kotlin.math.roundToInt

/** TIME slider (0..127) <-> total glide time in milliseconds: 1 .. 100 ms, linear. */
object PortaTime {
    private const val MIN_MS = 1.0
    private const val MAX_MS = 100.0

    fun msForSlider(value: Int): Int {
        val n = value.coerceIn(0, 127) / 127.0
        return (MIN_MS + (MAX_MS - MIN_MS) * n).roundToInt()
    }
}
