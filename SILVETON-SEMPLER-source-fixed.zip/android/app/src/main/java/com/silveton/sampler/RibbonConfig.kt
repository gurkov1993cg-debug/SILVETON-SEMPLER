package com.silveton.sampler

import android.content.SharedPreferences

/** Settings of the RIBBON module (mirrors silveton::Ribbon::Settings). */
data class RibbonConfig(
    val rangeSemitones: Int = 2,         // 1..12
    val sensitivity: Float = 1.0f,       // 0.25..2.0 response curve
    val smoothMs: Int = SMOOTH_MS,       // 0..200
    val returnMs: Int = RETURN_MS        // 0..2000
) {
    fun save(e: SharedPreferences.Editor): SharedPreferences.Editor = e
        .putInt("ribbon_range_semitones", rangeSemitones)
        .putFloat("ribbon_sensitivity", sensitivity)

    /** The ribbon has no setup: absolute strip (finger position = pitch, centre 0), returns to centre,
     *  own range on Pitch Bend, smooth. Only RANGE and SENSITIVITY are kept. */
    fun fixed(): RibbonConfig = copy(smoothMs = SMOOTH_MS, returnMs = RETURN_MS)

    companion object {
        const val SMOOTH_MS = 36    // old HQ feel
        const val RETURN_MS = 60
        fun load(p: SharedPreferences) = RibbonConfig(
            rangeSemitones = p.getInt("ribbon_range_semitones", 2).coerceIn(1, 12),
            sensitivity = p.getFloat("ribbon_sensitivity", 1.0f).coerceIn(0.25f, 2.0f)
        )
    }
}
