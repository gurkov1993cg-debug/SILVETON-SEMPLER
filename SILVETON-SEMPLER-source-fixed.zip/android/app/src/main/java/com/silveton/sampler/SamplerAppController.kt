package com.silveton.sampler

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Technical Android host for the SILVETON SAMPLER engine.
 *
 * This class intentionally contains no GUI. The final LIST/COMBI/PROGRAM/
 * SAMPLE/GLOBAL/MEDIA screens call this host, while audio and MIDI stay owned
 * by the native/runtime layer.
 */
class SamplerAppController(
    context: Context,
    private val statusChanged: (String?) -> Unit = {},
    private val midiConnectionChanged: (Int) -> Unit = {}
) : AutoCloseable {
    data class AudioStatus(
        val sampleRate: Int,
        val framesPerBurst: Int,
        val bufferSizeFrames: Int,
        val xrunCount: Int,
        val sharingMode: Int,
        val performanceMode: Int,
        val deviceId: Int,
        val estimatedLatencyMs: Double,
        val peakLeft: Float,
        val peakRight: Float,
        val limiterGainReductionDb: Float,
        val activeVoices: Int,
        val droppedRealtimeEvents: Int
    )


    data class SoundItem(val bank: Int, val page: Int, val slot: Int, val name: String)

    data class UpperState(
        val enabled: Boolean, val solo: Boolean, val mute: Boolean,
        val levelDb: Float, val pan: Float, val keyLow: Int, val keyHigh: Int,
        val velocityLow: Int, val velocityHigh: Int, val voiceMode: Int,
        val octave: Int, val transpose: Int, val fineCents: Float,
        val pitchBendRange: Int, val portamentoSec: Float,
        val breath: Boolean, val expression: Boolean, val aftertouch: Boolean, val damper: Boolean,
        val midiChannel: Int, val attackScale: Float, val decayScale: Float,
        val sustainScale: Float, val releaseScale: Float, val cutoffOctaves: Float,
        val resonanceOffset: Float, val lfoRateScale: Float, val lfoDepthScale: Float,
        val eqLowDb: Float, val eqMidDb: Float, val eqHighDb: Float,
        val fxSend1: Float, val fxSend2: Float, val soundName: String
    )


    data class FxState(
        val type: Int, val wet: Float, val timeMs: Float, val feedback: Float,
        val rateHz: Float, val depth: Float, val tone: Float
    )

    data class CombiFxState(val fx1: FxState, val fx2: FxState, val routing: Int)

    data class GlobalUiState(
        val masterTuneHz: Float, val transpose: Int, val masterGainDb: Float,
        val eqLowDb: Float, val eqMidDb: Float, val eqHighDb: Float,
        val limiterEnabled: Boolean, val limiterCeilingDb: Float, val velocityCurve: Int,
        val breathCc: Int, val expressionCc: Int, val damperCc: Int,
        val pitchBendEnabled: Boolean, val aftertouchEnabled: Boolean
    )

    private val appContext = context.applicationContext
    val engine = NativeSamplerEngine()
    val media = SamplerMediaStorage(appContext)
    private val runtime = SamplerRuntime(engine, statusChanged)
    private val midi = SamplerMidiController(
        appContext,
        engine,
        connectionChanged = midiConnectionChanged,
        statusChanged = statusChanged
    )
    private val started = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private var defaultBankAttempted = false

    /** Start low-latency output first, then accept MIDI. */
    fun start(): Boolean {
        if (closed.get()) return false
        if (started.get()) return true
        loadDefaultBankOnce()
        if (!runtime.start()) return false
        midi.start()
        started.set(true)
        return true
    }


    private fun loadDefaultBankOnce() {
        if (defaultBankAttempted) return
        defaultBankAttempted = true
        val candidates = listOfNotNull(
            File(appContext.filesDir, "SILVETON_BANK.sv"),
            appContext.getExternalFilesDir(null)?.let { File(it, "SILVETON_BANK.sv") },
            File("/storage/emulated/0/SILVETON_BANK.sv")
        )
        val bank = candidates.firstOrNull { it.isFile } ?: return
        if (!engine.nativeLoadSvBank(bank.absolutePath)) {
            statusChanged(engine.nativeLastTextError().ifBlank { "SILVETON_BANK.sv load failed" })
        }
    }

    /**
     * Activity pause does not destroy engine state. It only suspends the
     * hardware stream; MIDI is kept attached so hot-plug bookkeeping is not
     * rebuilt on every transient window change.
     */
    fun pauseAudio() {
        if (!closed.get() && started.get()) runtime.suspendAudio()
    }

    fun resumeAudio(): Boolean {
        if (closed.get()) return false
        if (!started.get()) return start()
        val ok = runtime.resumeAudio()
        if (!ok) statusChanged(engine.nativeLastTextError().ifBlank { "Audio resume failed" })
        return ok
    }

    fun panic(): Boolean = !closed.get() && engine.nativePanic()

    fun loadAudioFile(path: File): Boolean = nativeResult(engine.nativeLoadAudio(path.absolutePath))
    fun loadKmp(path: File): Boolean = nativeResult(engine.nativeLoadKmp(path.absolutePath))
    fun loadSvBank(path: File): Boolean = nativeResult(engine.nativeLoadSvBank(path.absolutePath))
    fun loadSet(path: File): Boolean = nativeResult(engine.nativeLoadSet(path.absolutePath))

    fun importKmpToLibrary(path: File): IntArray {
        val ids = engine.nativeImportKmpToLibrary(path.absolutePath)
        if (ids.isEmpty()) statusChanged(engine.nativeLastTextError().ifBlank { "KMP import failed" }) else statusChanged(null)
        return ids
    }

    fun importKscToLibrary(path: File): IntArray {
        val ids = engine.nativeImportKscToLibrary(path.absolutePath)
        if (ids.isEmpty()) statusChanged(engine.nativeLastTextError().ifBlank { "KSC import failed" }) else statusChanged(null)
        return ids
    }

    fun multisampleCatalog(): List<Pair<Int, String>> {
        val ids = engine.nativeMultisampleIds()
        val names = engine.nativeMultisampleNames()
        val count = minOf(ids.size, names.size)
        return List(count) { index -> ids[index] to names[index] }
    }

    data class ListItem(
        val number: Int,
        val name: String,
        val combiBank: Int,
        val combiPage: Int,
        val combiSlot: Int
    )

    fun listItems(bank: Int, page: Int, slot: Int): List<ListItem> {
        val numbers = engine.nativeListEntryNumbers(bank, page, slot)
        val names = engine.nativeListEntryNames(bank, page, slot)
        val addresses = engine.nativeListEntryCombiAddresses(bank, page, slot)
        val count = minOf(numbers.size, names.size, addresses.size / 3)
        return List(count) { index ->
            val base = index * 3
            ListItem(numbers[index], names[index], addresses[base], addresses[base + 1], addresses[base + 2])
        }
    }

    fun activeListEntry(bank: Int, page: Int, slot: Int): Int =
        engine.nativeActiveListEntry(bank, page, slot)

    fun activateListEntry(bank: Int, page: Int, slot: Int, index: Int): Boolean =
        nativeResult(engine.nativeActivateListEntry(bank, page, slot, index))

    fun kscNames(path: File): List<String> = engine.nativeKscNames(path.absolutePath).toList()

    fun loadKscItem(path: File, index: Int): Boolean =
        nativeResult(engine.nativeLoadKscItem(path.absolutePath, index))

    /**
     * Materialize one ordinary standalone audio document. KMP/KSC should be
     * imported from a folder tree so their sibling KSF/KMP dependencies remain
     * beside them.
     */
    fun importAudioDocument(uri: Uri): Boolean {
        val local = media.materializeDocument(uri)
        return when (local.extension.lowercase()) {
            "wav", "wave", "aif", "aiff", "aifc" -> loadAudioFile(local)
            else -> fail("Unsupported standalone sample format: ${local.extension}")
        }
    }

    /** Copy a complete Korg folder first so relative KMP/KSF/KSC paths work. */
    fun importKorgTree(treeUri: Uri, folderName: String): File =
        media.materializeTree(treeUri, folderName)

    fun importSetTree(treeUri: Uri, setName: String): Boolean {
        val local = media.materializeSetTree(treeUri, setName)
        return loadSet(local)
    }

    /** Save atomically in app-owned storage. SetPackage performs the native validation. */
    fun saveInternalSet(setName: String): File? {
        val safe = media.safeSetDirectoryName(setName)
        val target = File(media.internalSetsDirectory(), safe)
        return if (nativeResult(engine.nativeSaveSet(target.absolutePath))) target else null
    }

    fun exportSet(source: File, destinationTree: Uri, folderName: String = source.name): Uri =
        media.exportSetDirectory(source, destinationTree, folderName)

    fun upperMeters(): List<Pair<Float, Float>> {
        val meters = engine.nativeMeters()
        return List(7) { index ->
            val base = 5 + index * 2
            meters.getOrElse(base) { 0f } to meters.getOrElse(base + 1) { 0f }
        }
    }

    fun audioStatus(): AudioStatus {
        val info = engine.nativeAudioInfo()
        val meters = engine.nativeMeters()
        return AudioStatus(
            sampleRate = info.getOrElse(0) { 0 },
            framesPerBurst = info.getOrElse(1) { 0 },
            bufferSizeFrames = info.getOrElse(2) { 0 },
            xrunCount = info.getOrElse(3) { 0 },
            sharingMode = info.getOrElse(4) { -1 },
            performanceMode = info.getOrElse(5) { -1 },
            deviceId = info.getOrElse(6) { -1 },
            estimatedLatencyMs = engine.nativeLatencyMs(),
            peakLeft = meters.getOrElse(0) { 0f },
            peakRight = meters.getOrElse(1) { 0f },
            limiterGainReductionDb = meters.getOrElse(2) { 0f },
            activeVoices = meters.getOrElse(3) { 0f }.toInt(),
            droppedRealtimeEvents = meters.getOrElse(4) { 0f }.toInt()
        )
    }

    fun combiName(): String = engine.nativeCombiName().ifBlank { "COMBI" }

    fun soundCatalog(): List<SoundItem> {
        val addresses = engine.nativeSoundCatalogAddresses()
        val names = engine.nativeSoundCatalogNames()
        val count = minOf(names.size, addresses.size / 3)
        return List(count) { index ->
            val base = index * 3
            SoundItem(addresses[base], addresses[base + 1], addresses[base + 2], names[index])
        }
    }

    fun upperState(upper: Int): UpperState? {
        val v = engine.nativeUpperState(upper)
        if (v.size < 33) return null
        return UpperState(
            enabled=v[0] >= 0.5f, solo=v[1] >= 0.5f, mute=v[2] >= 0.5f,
            levelDb=v[3], pan=v[4], keyLow=v[5].toInt(), keyHigh=v[6].toInt(),
            velocityLow=v[7].toInt(), velocityHigh=v[8].toInt(), voiceMode=v[9].toInt(),
            octave=v[10].toInt(), transpose=v[11].toInt(), fineCents=v[12],
            pitchBendRange=v[13].toInt(), portamentoSec=v[14],
            breath=v[15] >= 0.5f, expression=v[16] >= 0.5f, aftertouch=v[17] >= 0.5f, damper=v[18] >= 0.5f,
            midiChannel=v[19].toInt(), attackScale=v[20], decayScale=v[21], sustainScale=v[22], releaseScale=v[23],
            cutoffOctaves=v[24], resonanceOffset=v[25], lfoRateScale=v[26], lfoDepthScale=v[27],
            eqLowDb=v[28], eqMidDb=v[29], eqHighDb=v[30], fxSend1=v[31], fxSend2=v[32],
            soundName=engine.nativeUpperSoundName(upper).ifBlank { "EMPTY" }
        )
    }

    fun assignUpperSound(upper: Int, item: SoundItem): Boolean =
        nativeResult(engine.nativeAssignUpperSound(item.bank, item.page, item.slot, upper))

    fun clearUpperSound(upper: Int): Boolean = nativeResult(engine.nativeClearUpperSound(upper))

    fun updateUpperMain(upper: Int, state: UpperState): Boolean = nativeResult(
        engine.nativeUpdateUpperMain(upper, state.enabled, state.solo, state.mute, state.levelDb, state.pan, state.keyLow, state.keyHigh, state.voiceMode)
    )

    fun updateUpperTune(upper: Int, state: UpperState): Boolean = nativeResult(
        engine.nativeUpdateUpperTune(upper, state.octave, state.transpose, state.fineCents, state.pitchBendRange, state.portamentoSec)
    )

    fun updateUpperRange(upper: Int, state: UpperState): Boolean = nativeResult(
        engine.nativeUpdateUpperRange(upper, state.velocityLow, state.velocityHigh)
    )

    fun updateUpperControl(upper: Int, state: UpperState): Boolean = nativeResult(
        engine.nativeUpdateUpperControl(upper, state.breath, state.expression, state.aftertouch, state.damper, state.midiChannel)
    )

    fun updateUpperTone(upper: Int, state: UpperState): Boolean = nativeResult(
        engine.nativeUpdateUpperTone(upper, state.attackScale, state.decayScale, state.sustainScale, state.releaseScale,
            state.cutoffOctaves, state.resonanceOffset, state.lfoRateScale, state.lfoDepthScale,
            state.eqLowDb, state.eqMidDb, state.eqHighDb)
    )

    fun updateUpperFx(upper: Int, state: UpperState): Boolean = nativeResult(
        engine.nativeUpdateUpperFxSends(upper, state.fxSend1, state.fxSend2)
    )

    fun combiFxState(): CombiFxState? {
        val v = engine.nativeCombiFxState()
        if (v.size < 15) return null
        fun fx(base: Int) = FxState(v[base].toInt(), v[base+1], v[base+2], v[base+3], v[base+4], v[base+5], v[base+6])
        return CombiFxState(fx(0), fx(7), v[14].toInt())
    }

    fun updateCombiFx(slot: Int, fx: FxState): Boolean = nativeResult(
        engine.nativeUpdateCombiFx(slot, fx.type, fx.wet, fx.timeMs, fx.feedback, fx.rateHz, fx.depth, fx.tone)
    )

    fun updateCombiFxRouting(routing: Int): Boolean = nativeResult(engine.nativeUpdateCombiFxRouting(routing))

    fun globalUiState(): GlobalUiState? {
        val v = engine.nativeGlobalState()
        if (v.size < 14) return null
        return GlobalUiState(v[0], v[1].toInt(), v[2], v[3], v[4], v[5], v[6] >= 0.5f, v[7], v[8].toInt(),
            v[9].toInt(), v[10].toInt(), v[11].toInt(), v[12] >= 0.5f, v[13] >= 0.5f)
    }

    fun updateGlobalUi(state: GlobalUiState): Boolean = nativeResult(
        engine.nativeUpdateGlobal(state.masterTuneHz, state.transpose, state.masterGainDb, state.eqLowDb, state.eqMidDb, state.eqHighDb,
            state.limiterEnabled, state.limiterCeilingDb, state.velocityCurve, state.breathCc, state.expressionCc, state.damperCc,
            state.pitchBendEnabled, state.aftertouchEnabled)
    )

    private fun nativeResult(ok: Boolean): Boolean {
        if (ok) {
            statusChanged(null)
            return true
        }
        statusChanged(engine.nativeLastTextError().ifBlank { "Native sampler operation failed" })
        return false
    }

    private fun fail(message: String): Boolean {
        statusChanged(message)
        return false
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        started.set(false)
        midi.close()
        runtime.close()
    }
}
