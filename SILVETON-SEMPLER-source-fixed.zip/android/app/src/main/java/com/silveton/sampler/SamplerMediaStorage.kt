package com.silveton.sampler

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import java.io.File
import java.io.FileOutputStream

/**
 * MEDIA backend for SILVETON SAMPLER.
 *
 * Native DSP never receives a content:// URI. Android SAF trees/documents are
 * copied to an app-owned working directory first, so SetPackage/KMP/KSF/WAV
 * code can use ordinary seekable filesystem paths. Export performs the reverse
 * copy. Original file bytes are preserved; no audio conversion occurs here.
 */
class SamplerMediaStorage(private val context: Context) {
    data class Device(
        val id: String,
        val name: String,
        val removable: Boolean,
        val primary: Boolean,
        val directory: File?
    )

    data class Entry(val name: String, val uri: Uri, val directory: Boolean)

    data class EntryInfo(
        val name: String,
        val directory: Boolean,
        val sizeBytes: Long,
        val lastModifiedMs: Long,
        val mimeType: String
    )

    private val resolver: ContentResolver get() = context.contentResolver
    private val storageManager: StorageManager get() = context.getSystemService(StorageManager::class.java)

    fun devices(): List<Device> = storageManager.storageVolumes.mapIndexed { index, volume ->
        val directory = if (Build.VERSION.SDK_INT >= 30) volume.directory else null
        Device(
            id = volume.uuid ?: if (volume.isPrimary) "primary" else "volume-$index",
            name = volume.getDescription(context),
            removable = volume.isRemovable,
            primary = volume.isPrimary,
            directory = directory
        )
    }

    fun internalSetsDirectory(): File = File(context.filesDir, "sets").apply { mkdirs() }
    fun importWorkingDirectory(): File = File(context.filesDir, "media-import").apply { mkdirs() }

    fun persistTreePermission(uri: Uri) {
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
            android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        resolver.takePersistableUriPermission(uri, flags)
    }

    fun listTree(uri: Uri): List<Entry> = listDirectory(uri, null)

    fun listDirectory(treeUri: Uri, directoryUri: Uri?): List<Entry> {
        val parentId = if (directoryUri == null) {
            DocumentsContract.getTreeDocumentId(treeUri)
        } else {
            DocumentsContract.getDocumentId(directoryUri)
        }
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val result = ArrayList<Entry>()
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idCol)
                val name = cursor.getString(nameCol) ?: id.substringAfterLast('/')
                val mime = cursor.getString(mimeCol)
                val child = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                result += Entry(name, child, mime == DocumentsContract.Document.MIME_TYPE_DIR)
            }
        }
        return result.sortedWith(compareByDescending<Entry> { it.directory }.thenBy { it.name.lowercase() })
    }

    fun info(uri: Uri): EntryInfo {
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        resolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val name = cursor.getString(0) ?: ""
                val mime = cursor.getString(1) ?: "application/octet-stream"
                val size = if (cursor.isNull(2)) 0L else cursor.getLong(2)
                val modified = if (cursor.isNull(3)) 0L else cursor.getLong(3)
                return EntryInfo(name, mime == DocumentsContract.Document.MIME_TYPE_DIR, size, modified, mime)
            }
        }
        error("Cannot query media entry")
    }

    fun rename(uri: Uri, newName: String): Uri {
        val safe = sanitizeName(newName)
        require(safe.isNotBlank()) { "Name cannot be empty" }
        return DocumentsContract.renameDocument(resolver, uri, safe)
            ?: error("Rename failed")
    }

    fun delete(uri: Uri): Boolean = DocumentsContract.deleteDocument(resolver, uri)

    fun copy(treeUri: Uri, sourceUri: Uri, destinationDirectoryUri: Uri?, overwrite: Boolean): Uri {
        val sourceInfo = info(sourceUri)
        val destinationId = if (destinationDirectoryUri == null) {
            DocumentsContract.getTreeDocumentId(treeUri)
        } else {
            DocumentsContract.getDocumentId(destinationDirectoryUri)
        }
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, destinationId)
        val existing = findChild(treeUri, destinationId, sourceInfo.name, sourceInfo.directory)
        if (existing != null && !overwrite) error("Destination already exists")
        if (existing != null && overwrite) DocumentsContract.deleteDocument(resolver, existing)

        return if (sourceInfo.directory) {
            val created = DocumentsContract.createDocument(
                resolver, parentUri, DocumentsContract.Document.MIME_TYPE_DIR, sourceInfo.name
            ) ?: error("Cannot create destination directory")
            copyDocumentTree(sourceUri, treeUri, DocumentsContract.getDocumentId(created))
            created
        } else {
            val created = DocumentsContract.createDocument(
                resolver, parentUri, sourceInfo.mimeType, sourceInfo.name
            ) ?: error("Cannot create destination file")
            resolver.openInputStream(sourceUri).use { input ->
                requireNotNull(input) { "Cannot read source media file" }
                resolver.openOutputStream(created, "wt").use { output ->
                    requireNotNull(output) { "Cannot write destination media file" }
                    input.copyTo(output, DEFAULT_BUFFER_SIZE)
                }
            }
            created
        }
    }

    fun backupAllSets(destinationTree: Uri, backupFolderName: String): Uri {
        val source = internalSetsDirectory()
        return exportSetDirectory(source, destinationTree, sanitizeName(backupFolderName).ifBlank { "SILVETON-BACKUP" })
    }

    fun restoreAllSets(sourceTree: Uri, overwrite: Boolean) {
        val staging = File(context.cacheDir, "sets-restore-staging")
        if (staging.exists()) staging.deleteRecursively()
        staging.mkdirs()
        copyTreeChildrenToDirectory(sourceTree, DocumentsContract.getTreeDocumentId(sourceTree), staging)

        val destination = internalSetsDirectory()
        staging.listFiles()?.forEach { item ->
            val target = File(destination, item.name)
            if (target.exists()) {
                if (!overwrite) error("${item.name} already exists")
                target.deleteRecursively()
            }
            if (!item.renameTo(target)) {
                if (item.isDirectory) item.copyRecursively(target, overwrite = true)
                else item.copyTo(target, overwrite = true)
            }
        }
        staging.deleteRecursively()
    }

    /** Copy one selected SAF file byte-for-byte into app storage for native import. */
    fun materializeDocument(uri: Uri, preferredName: String? = null): File {
        val name = preferredName?.takeIf { it.isNotBlank() } ?: queryDisplayName(uri) ?: "import.bin"
        val safeName = sanitizeName(name)
        val target = uniqueTarget(importWorkingDirectory(), safeName)
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open selected media document" }
            FileOutputStream(target).use { output -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
        }
        return target
    }

    /**
     * Copy a selected SET directory tree into an app-owned .SVSET directory.
     * The returned directory can be passed directly to nativeLoadSet().
     */
    fun materializeTree(treeUri: Uri, folderName: String): File {
        val target = File(importWorkingDirectory(), sanitizeName(folderName).ifBlank { "Imported" })
        if (target.exists()) target.deleteRecursively()
        target.mkdirs()
        copyTreeChildrenToDirectory(treeUri, DocumentsContract.getTreeDocumentId(treeUri), target)
        return target
    }

    fun materializeSetTree(treeUri: Uri, setName: String): File =
        materializeTree(treeUri, safeSetDirectoryName(setName))

    fun safeSetDirectoryName(name: String): String {
        val safe = sanitizeName(name).ifBlank { "SILVETON" }
        return if (safe.endsWith(".SVSET", ignoreCase = true)) safe else "$safe.SVSET"
    }

    /** Export an app/native SET directory byte-for-byte into a user-selected SAF tree. */
    fun exportSetDirectory(source: File, destinationTree: Uri, folderName: String = source.name): Uri {
        require(source.isDirectory) { "SET source is not a directory" }
        val parentId = DocumentsContract.getTreeDocumentId(destinationTree)
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(destinationTree, parentId)
        val outDir = findChild(destinationTree, parentId, folderName, true)
            ?: DocumentsContract.createDocument(
                resolver,
                parentUri,
                DocumentsContract.Document.MIME_TYPE_DIR,
                folderName
            ) ?: error("Cannot create SET folder on selected media")
        val outId = DocumentsContract.getDocumentId(outDir)
        copyDirectoryToTree(source, destinationTree, outId)
        return outDir
    }

    private fun copyDocumentTree(sourceDirectoryUri: Uri, destinationTree: Uri, destinationParentId: String) {
        val sourceId = DocumentsContract.getDocumentId(sourceDirectoryUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(sourceDirectoryUri, sourceId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val destParentUri = DocumentsContract.buildDocumentUriUsingTree(destinationTree, destinationParentId)
            while (cursor.moveToNext()) {
                val childId = cursor.getString(idCol)
                val childName = sanitizeName(cursor.getString(nameCol) ?: childId.substringAfterLast('/'))
                val mime = cursor.getString(mimeCol)
                val sourceChild = DocumentsContract.buildDocumentUriUsingTree(sourceDirectoryUri, childId)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    val destDir = DocumentsContract.createDocument(
                        resolver, destParentUri, DocumentsContract.Document.MIME_TYPE_DIR, childName
                    ) ?: error("Cannot create destination directory $childName")
                    copyDocumentTree(sourceChild, destinationTree, DocumentsContract.getDocumentId(destDir))
                } else {
                    val destFile = DocumentsContract.createDocument(
                        resolver, destParentUri, mime ?: "application/octet-stream", childName
                    ) ?: error("Cannot create destination file $childName")
                    resolver.openInputStream(sourceChild).use { input ->
                        requireNotNull(input) { "Cannot read $childName" }
                        resolver.openOutputStream(destFile, "wt").use { output ->
                            requireNotNull(output) { "Cannot write $childName" }
                            input.copyTo(output, DEFAULT_BUFFER_SIZE)
                        }
                    }
                }
            }
        }
    }

    private fun copyTreeChildrenToDirectory(treeUri: Uri, parentDocumentId: String, destination: File) {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idCol)
                val name = sanitizeName(cursor.getString(nameCol) ?: id.substringAfterLast('/'))
                val mime = cursor.getString(mimeCol)
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                val out = File(destination, name)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    out.mkdirs()
                    copyTreeChildrenToDirectory(treeUri, id, out)
                } else {
                    resolver.openInputStream(childUri).use { input ->
                        requireNotNull(input) { "Cannot read $name" }
                        FileOutputStream(out).use { output -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
                    }
                }
            }
        }
    }

    private fun copyDirectoryToTree(source: File, treeUri: Uri, parentDocumentId: String) {
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocumentId)
        source.listFiles()?.sortedBy { it.name.lowercase() }?.forEach { item ->
            if (item.isDirectory) {
                val child = findChild(treeUri, parentDocumentId, item.name, true)
                    ?: DocumentsContract.createDocument(
                        resolver, parentUri, DocumentsContract.Document.MIME_TYPE_DIR, item.name
                    ) ?: error("Cannot create directory ${item.name}")
                copyDirectoryToTree(item, treeUri, DocumentsContract.getDocumentId(child))
            } else {
                val existing = findChild(treeUri, parentDocumentId, item.name, false)
                val target = existing ?: DocumentsContract.createDocument(
                    resolver, parentUri, mimeFor(item.name), item.name
                ) ?: error("Cannot create file ${item.name}")
                resolver.openOutputStream(target, "wt").use { output ->
                    requireNotNull(output) { "Cannot write ${item.name}" }
                    item.inputStream().use { input -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
                }
            }
        }
    }

    private fun findChild(treeUri: Uri, parentDocumentId: String, name: String, directory: Boolean): Uri? {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val childName = cursor.getString(nameCol) ?: continue
                val mime = cursor.getString(mimeCol)
                if (childName == name && (mime == DocumentsContract.Document.MIME_TYPE_DIR) == directory) {
                    return DocumentsContract.buildDocumentUriUsingTree(treeUri, cursor.getString(idCol))
                }
            }
        }
        return null
    }

    private fun queryDisplayName(uri: Uri): String? {
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        resolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private fun uniqueTarget(dir: File, name: String): File {
        var target = File(dir, name)
        if (!target.exists()) return target
        val stem = target.nameWithoutExtension
        val ext = target.extension.let { if (it.isEmpty()) "" else ".$it" }
        var index = 1
        while (target.exists()) target = File(dir, "$stem-$index$ext").also { index++ }
        return target
    }

    private fun sanitizeName(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "wav", "wave" -> "audio/wav"
        "aif", "aiff", "aifc" -> "audio/aiff"
        "kmp", "ksf", "ksc", "svs" -> "application/octet-stream"
        else -> "application/octet-stream"
    }
}
