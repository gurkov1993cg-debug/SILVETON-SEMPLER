package com.silveton.sampler

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Process

/**
 * Status/lifecycle companion for the native Direct-ALSA MIDI backend.
 *
 * MIDI bytes do NOT pass through this class. The native sampler scans and
 * reads /dev/snd/midiC*D* directly on its own urgent-priority C++ thread and
 * posts parsed channel messages straight into SamplerEngine. This Kotlin class
 * only mirrors the real native port count/error state to the existing UI.
 */
class SamplerMidiController(
    @Suppress("UNUSED_PARAMETER") context: Context,
    private val engine: NativeSamplerEngine,
    private val connectionChanged: (Int) -> Unit = {},
    private val statusChanged: (String?) -> Unit = {}
) : AutoCloseable {
    private val thread = HandlerThread(
        "SilvetonDirectMidiStatus",
        Process.THREAD_PRIORITY_BACKGROUND
    ).apply { start() }
    private val handler = Handler(thread.looper)

    @Volatile private var running = false
    @Volatile private var closed = false
    private var lastConnectionCount = -1
    private var lastError = 0

    private val statusPoll = object : Runnable {
        override fun run() {
            if (closed || !running) return

            val count = engine.nativeMidiDeviceCount().coerceAtLeast(0)
            if (count != lastConnectionCount) {
                lastConnectionCount = count
                connectionChanged(count)
            }

            val error = engine.nativeMidiLastError()
            if (error != lastError) {
                val previous = lastError
                lastError = error
                if (error != 0) {
                    statusChanged("Direct ALSA MIDI access failed (errno ${-error})")
                } else if (previous != 0) {
                    statusChanged(null)
                }
            }

            handler.postDelayed(this, 250L)
        }
    }

    fun start() {
        if (closed || running) return
        running = true
        handler.post(statusPoll)
    }

    fun panic() {
        if (!closed) engine.nativePanic()
    }

    override fun close() {
        if (closed) return
        closed = true
        running = false
        handler.removeCallbacks(statusPoll)
        if (lastConnectionCount != 0) connectionChanged(0)
        thread.quitSafely()
    }
}
