package com.silveton.sampler

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.InputType
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Functional SILVETON SAMPLER touchscreen surface.
 *
 * Visual baseline: docs/APPROVED_COMBI_UI.png + docs/APPROVED_LIST_UI.png.
 * Visible controls are intentionally limited to functions that have a native
 * state/DSP/action path. PROGRAM, SAMPLE and MIXER are not tablet top-level
 * pages; prepared sounds are selected directly into COMBI UPPER 1..7.
 */
class SilvetonSamplerView(
    context: Context,
    private val sampler: SamplerAppController
) : View(context) {

    private enum class Page { LIST, COMBI, EFFECTS, SETTINGS }
    private enum class UpperTab { TUNE, RANGE, CONTROL, TONE, FX }

    private data class Hit(
        val rect: RectF,
        val tap: (Float, Float) -> Unit,
        val reset: (() -> Unit)? = null
    )

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hits = ArrayList<Hit>(96)
    private var page = Page.COMBI
    private var tab = UpperTab.TUNE
    private var selectedUpper = 0
    private var midiConnections = 0
    private var warning: String? = null
    private var listPage = 0

    private val upperStates = arrayOfNulls<SamplerAppController.UpperState>(7)
    private var fxState: SamplerAppController.CombiFxState? = null
    private var globalState: SamplerAppController.GlobalUiState? = null

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            hitAt(e.x, e.y)?.tap?.invoke(e.x, e.y)
            invalidate()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val hit = hitAt(e.x, e.y)
            if (hit?.reset != null) hit.reset.invoke() else hit?.tap?.invoke(e.x, e.y)
            invalidate()
            return true
        }
    })

    init {
        isFocusable = true
        refreshAllUppers()
        refreshFx()
        refreshGlobal()
    }

    fun setMidiConnections(count: Int) {
        midiConnections = max(0, count)
        invalidate()
    }

    fun setWarning(message: String?) {
        warning = message?.takeIf { it.isNotBlank() }
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = detector.onTouchEvent(event)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hits.clear()
        canvas.drawColor(C_BG)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        drawHeader(canvas, w, h)
        val navW = w * 0.125f
        val margin = h * 0.016f
        val headerH = h * 0.082f
        val navLeft = w - navW - margin
        val content = RectF(margin, headerH + margin, navLeft - margin, h - margin)
        drawRightNav(canvas, RectF(navLeft, headerH + margin, w - margin, h - margin))

        when (page) {
            Page.LIST -> drawList(canvas, content)
            Page.COMBI -> drawCombi(canvas, content)
            Page.EFFECTS -> drawEffects(canvas, content)
            Page.SETTINGS -> drawSettings(canvas, content)
        }

        warning?.let { msg ->
            val box = RectF(content.left, h - margin - 36f.dp, content.right, h - margin)
            panel(canvas, box, C_WARN_BG, 10f.dp)
            text(canvas, msg, box.left + 12f.dp, box.centerY() + 5f.dp, 13f.dp, C_WARN_TEXT)
        }

        postInvalidateDelayed(40L)
    }

    private fun drawHeader(c: Canvas, w: Float, h: Float) {
        val hh = h * 0.082f
        line(c, 0f, hh, w, hh, C_BORDER, 1f.dp)
        val m = h * 0.014f
        val gear = RectF(m, m, m + 54f.dp, hh - m)
        button(c, gear, "⚙", page == Page.SETTINGS)
        hit(gear, { _, _ -> page = Page.SETTINGS; refreshGlobal() })

        val panic = RectF(gear.right + 10f.dp, m, gear.right + 150f.dp, hh - m)
        button(c, panic, "●   PANIC", false, C_PANIC)
        hit(panic, { _, _ -> sampler.panic() })

        text(c, "〰  S I L V E T O N", w * 0.31f, hh * 0.56f, 27f.dp, C_TEXT, bold = true)
        text(c, "sampler", w * 0.55f, hh * 0.56f, 18f.dp, C_TEXT_DIM)

        val status = sampler.audioStatus()
        val chipH = hh * 0.58f
        var x = w * 0.72f
        val y = (hh - chipH) * 0.5f
        x = chip(c, x, y, "ЗВУК ${"%.1f".format(status.estimatedLatencyMs)} ms", chipH)
        x = chip(c, x + 8f.dp, y, "XRUN ${status.xrunCount}", chipH)
        chip(c, x + 8f.dp, y, "MIDI $midiConnections", chipH)
    }

    private fun drawRightNav(c: Canvas, r: RectF) {
        panel(c, r, C_NAV_BG, 14f.dp)
        val gap = 10f.dp
        val bh = (r.height() - gap * 4f) / 3f
        val labels = listOf(Page.LIST to "ЛИСТ", Page.COMBI to "КОМБИ", Page.EFFECTS to "ЕФЕКТИ")
        labels.forEachIndexed { i, (p, label) ->
            val y = r.top + gap + i * bh + i * gap
            val b = RectF(r.left + gap, y, r.right - gap, y + bh)
            button(c, b, label, page == p)
            hit(b, { _, _ ->
                page = p
                if (p == Page.COMBI) refreshAllUppers()
                if (p == Page.EFFECTS) refreshFx()
            })
        }
    }

    private fun drawCombi(c: Canvas, r: RectF) {
        panel(c, r, C_PANEL, 14f.dp)
        val pad = 16f.dp
        val titleH = r.height() * 0.145f
        text(c, "●  К О М Б И", r.left + pad, r.top + 27f.dp, 13f.dp, C_TEXT_DIM)
        val combiName = sampler.combiName()
        text(c, combiName, r.left + pad, r.top + titleH * 0.70f, 31f.dp, C_TEXT, bold = true)
        val st = sampler.audioStatus()
        text(c, "ГЛАСОВЕ", r.right - 145f.dp, r.top + 34f.dp, 10f.dp, C_TEXT_MUTED)
        text(c, st.activeVoices.toString(), r.right - 120f.dp, r.top + 60f.dp, 22f.dp, C_TEXT)
        text(c, "ПУКАНЕ", r.right - 68f.dp, r.top + 34f.dp, 10f.dp, C_TEXT_MUTED)
        text(c, st.xrunCount.toString(), r.right - 46f.dp, r.top + 60f.dp, 22f.dp, C_TEXT)

        val rowsTop = r.top + titleH
        val lowerH = r.height() * 0.37f
        val rowsBottom = r.bottom - lowerH - 10f.dp
        val rowH = (rowsBottom - rowsTop) / 7f
        val meters = sampler.upperMeters()

        for (i in 0 until 7) {
            val state = upperStates[i] ?: sampler.upperState(i)?.also { upperStates[i] = it } ?: continue
            val rr = RectF(r.left + pad, rowsTop + i * rowH + 2f.dp, r.right - pad, rowsTop + (i + 1) * rowH - 2f.dp)
            drawUpperRow(c, rr, i, state, meters.getOrElse(i) { 0f to 0f })
        }

        val lower = RectF(r.left + pad, rowsBottom + 8f.dp, r.right - pad, r.bottom - pad)
        drawUpperEditor(c, lower)
    }

    private fun drawUpperRow(c: Canvas, r: RectF, i: Int, s: SamplerAppController.UpperState, meter: Pair<Float, Float>) {
        val selected = i == selectedUpper
        panel(c, r, if (selected) C_ROW_SELECTED else C_ROW, 9f.dp, if (selected) C_ACCENT_DARK else C_BORDER)
        val x0 = r.left + 13f.dp
        text(c, "UPPER ${i + 1}", x0, r.centerY() + 5f.dp, 12f.dp, if (selected) C_ACCENT else C_TEXT_DIM, bold = selected)

        val soundL = r.left + r.width() * 0.13f
        val soundR = r.left + r.width() * 0.36f
        text(c, s.soundName, soundL, r.centerY() + 6f.dp, 13f.dp, if (s.soundName == "EMPTY") C_TEXT_MUTED else C_TEXT)
        hit(RectF(soundL - 4f.dp, r.top, soundR, r.bottom), { _, _ -> selectedUpper = i; showSoundPicker(i) })

        val onR = RectF(r.left + r.width() * 0.365f, r.top + 6f.dp, r.left + r.width() * 0.405f, r.bottom - 6f.dp)
        tinyToggle(c, onR, "ON", s.enabled)
        hit(onR, { _, _ -> if (s.soundName != "EMPTY") commitMain(i, s.copy(enabled = !s.enabled)) })

        val soloR = RectF(r.left + r.width() * 0.410f, r.top + 6f.dp, r.left + r.width() * 0.455f, r.bottom - 6f.dp)
        tinyToggle(c, soloR, "S", s.solo)
        hit(soloR, { _, _ -> commitMain(i, s.copy(solo = !s.solo)) })

        val muteR = RectF(r.left + r.width() * 0.460f, r.top + 6f.dp, r.left + r.width() * 0.505f, r.bottom - 6f.dp)
        tinyToggle(c, muteR, "M", s.mute)
        hit(muteR, { _, _ -> commitMain(i, s.copy(mute = !s.mute)) })

        val volR = RectF(r.left + r.width() * 0.515f, r.top + 5f.dp, r.left + r.width() * 0.655f, r.bottom - 5f.dp)
        drawMiniSlider(c, volR, s.levelDb, -60f, 12f, "${"%.1f".format(s.levelDb)} dB")
        hit(volR, { x, _ ->
            val v = mapX(x, volR, -60f, 12f)
            commitMain(i, s.copy(levelDb = v))
        }, { commitMain(i, s.copy(levelDb = 0f)) })

        val panR = RectF(r.left + r.width() * 0.665f, r.top + 5f.dp, r.left + r.width() * 0.755f, r.bottom - 5f.dp)
        drawMiniSlider(c, panR, s.pan, -1f, 1f, panText(s.pan))
        hit(panR, { x, _ -> commitMain(i, s.copy(pan = mapX(x, panR, -1f, 1f))) }, { commitMain(i, s.copy(pan = 0f)) })

        val rangeR = RectF(r.left + r.width() * 0.765f, r.top, r.left + r.width() * 0.855f, r.bottom)
        text(c, "${noteName(s.keyLow)}  –  ${noteName(s.keyHigh)}", rangeR.centerX(), r.centerY() + 5f.dp, 11f.dp, C_TEXT, alignCenter = true)
        hit(rangeR, { _, _ -> selectedUpper = i; showKeyRange(i, s) })

        val modeR = RectF(r.left + r.width() * 0.86f, r.top + 5f.dp, r.left + r.width() * 0.94f, r.bottom - 5f.dp)
        button(c, modeR, voiceModeName(s.voiceMode), false)
        hit(modeR, { _, _ -> commitMain(i, s.copy(voiceMode = (s.voiceMode + 1) % 3)) }, { commitMain(i, s.copy(voiceMode = 0)) })

        val meterR = RectF(r.left + r.width() * 0.947f, r.top + 10f.dp, r.right - 9f.dp, r.bottom - 10f.dp)
        drawUpperMeter(c, meterR, max(meter.first, meter.second))

        hit(RectF(r.left, r.top, soundL - 6f.dp, r.bottom), { _, _ -> selectedUpper = i })
    }

    private fun drawUpperEditor(c: Canvas, r: RectF) {
        panel(c, r, C_PANEL_DARK, 12f.dp)
        val s = upperStates[selectedUpper] ?: return
        text(c, "●  UPPER ${selectedUpper + 1}", r.left + 15f.dp, r.top + 27f.dp, 15f.dp, C_ACCENT)
        val tabsY = r.top + 40f.dp
        val tabH = 38f.dp
        val tabStart = r.left + 165f.dp
        val tabGap = 8f.dp
        val tabW = (r.right - tabStart - 10f.dp - tabGap * 4f) / 5f
        UpperTab.entries.forEachIndexed { idx, t ->
            val rr = RectF(tabStart + idx * (tabW + tabGap), tabsY - 29f.dp, tabStart + idx * (tabW + tabGap) + tabW, tabsY + 9f.dp)
            button(c, rr, t.name, tab == t)
            hit(rr, { _, _ -> tab = t })
        }
        val body = RectF(r.left + 12f.dp, tabsY + 18f.dp, r.right - 12f.dp, r.bottom - 10f.dp)
        when (tab) {
            UpperTab.TUNE -> drawTune(c, body, s)
            UpperTab.RANGE -> drawRange(c, body, s)
            UpperTab.CONTROL -> drawControl(c, body, s)
            UpperTab.TONE -> drawTone(c, body, s)
            UpperTab.FX -> drawUpperFx(c, body, s)
        }
    }

    private fun drawTune(c: Canvas, r: RectF, s: SamplerAppController.UpperState) {
        val labels = listOf(
            Triple("PORTAMENTO", s.portamentoSec * 1000f, "ms"),
            Triple("ОКТАВА", s.octave.toFloat(), ""),
            Triple("ТРАНСПОНИРАНЕ", s.transpose.toFloat(), "st"),
            Triple("ФИНА НАСТРОЙКА", s.fineCents, "cent"),
            Triple("PITCH BEND", s.pitchBendRange.toFloat(), "st")
        )
        val cols = labels.size
        val gap = 10f.dp
        val cw = (r.width() - gap * (cols - 1)) / cols
        labels.forEachIndexed { i, item ->
            val rr = RectF(r.left + i * (cw + gap), r.top, r.left + i * (cw + gap) + cw, r.bottom)
            panel(c, rr, C_SUBPANEL, 9f.dp)
            text(c, item.first, rr.centerX(), rr.top + 23f.dp, 10f.dp, C_TEXT_MUTED, alignCenter = true)
            drawKnob(c, rr.centerX(), rr.centerY() + 8f.dp, min(rr.width(), rr.height()) * 0.22f)
            text(c, formatValue(item.second, item.third), rr.centerX(), rr.bottom - 18f.dp, 12f.dp, C_TEXT, alignCenter = true)
            val tap = when (i) {
                0 -> { -> showNumber("Portamento ms", s.portamentoSec * 1000f, 0f, 5000f, 1) { commitTune(s.copy(portamentoSec = it / 1000f)) } }
                1 -> { -> showNumber("Октава", s.octave.toFloat(), -4f, 4f, 0) { commitTune(s.copy(octave = it.toInt())) } }
                2 -> { -> showNumber("Транспониране", s.transpose.toFloat(), -48f, 48f, 0) { commitTune(s.copy(transpose = it.toInt())) } }
                3 -> { -> showNumber("Fine cents", s.fineCents, -100f, 100f, 1) { commitTune(s.copy(fineCents = it)) } }
                else -> { -> showNumber("Pitch Bend Range", s.pitchBendRange.toFloat(), 0f, 24f, 0) { commitTune(s.copy(pitchBendRange = it.toInt())) } }
            }
            val reset = when (i) {
                0 -> { -> commitTune(s.copy(portamentoSec = 0f)) }
                1 -> { -> commitTune(s.copy(octave = 0)) }
                2 -> { -> commitTune(s.copy(transpose = 0)) }
                3 -> { -> commitTune(s.copy(fineCents = 0f)) }
                else -> { -> commitTune(s.copy(pitchBendRange = 2)) }
            }
            hit(rr, { _, _ -> tap() }, reset)
        }
    }

    private fun drawRange(c: Canvas, r: RectF, s: SamplerAppController.UpperState) {
        val rr = RectF(r.left, r.top, r.left + r.width() * 0.62f, r.bottom)
        panel(c, rr, C_SUBPANEL, 9f.dp)
        text(c, "VELOCITY RANGE", rr.left + 16f.dp, rr.top + 25f.dp, 11f.dp, C_TEXT_MUTED)
        val bar = RectF(rr.left + 38f.dp, rr.centerY() - 7f.dp, rr.right - 38f.dp, rr.centerY() + 7f.dp)
        drawRangeBar(c, bar, s.velocityLow.toFloat(), s.velocityHigh.toFloat(), 1f, 127f)
        text(c, s.velocityLow.toString(), rr.left + 18f.dp, rr.centerY() + 5f.dp, 13f.dp, C_TEXT)
        text(c, s.velocityHigh.toString(), rr.right - 18f.dp, rr.centerY() + 5f.dp, 13f.dp, C_TEXT, alignCenter = true)
        hit(rr, { _, _ -> showVelocityRange(selectedUpper, s) }, { commitRange(s.copy(velocityLow = 1, velocityHigh = 127)) })

        val info = RectF(rr.right + 12f.dp, r.top, r.right, r.bottom)
        panel(c, info, C_SUBPANEL, 9f.dp)
        text(c, "KEY RANGE", info.left + 16f.dp, info.top + 25f.dp, 11f.dp, C_TEXT_MUTED)
        text(c, "${noteName(s.keyLow)}  –  ${noteName(s.keyHigh)}", info.left + 16f.dp, info.centerY() + 6f.dp, 22f.dp, C_TEXT)
        text(c, "Редактира се от UPPER реда горе", info.left + 16f.dp, info.bottom - 19f.dp, 10f.dp, C_TEXT_MUTED)
    }

    private fun drawControl(c: Canvas, r: RectF, s: SamplerAppController.UpperState) {
        val gap = 10f.dp
        val cols = 5
        val cw = (r.width() - gap * (cols - 1)) / cols
        val items = listOf(
            "BREATH CC2" to s.breath,
            "EXPRESSION CC11" to s.expression,
            "AFTERTOUCH" to s.aftertouch,
            "DAMPER CC64" to s.damper
        )
        items.forEachIndexed { i, item ->
            val rr = RectF(r.left + i * (cw + gap), r.top, r.left + i * (cw + gap) + cw, r.bottom)
            panel(c, rr, C_SUBPANEL, 9f.dp)
            text(c, item.first, rr.centerX(), rr.top + 25f.dp, 10f.dp, C_TEXT_MUTED, alignCenter = true)
            val tr = RectF(rr.left + 22f.dp, rr.centerY() - 18f.dp, rr.right - 22f.dp, rr.centerY() + 18f.dp)
            tinyToggle(c, tr, if (item.second) "ON" else "OFF", item.second)
            val ns = when (i) {
                0 -> s.copy(breath = !s.breath)
                1 -> s.copy(expression = !s.expression)
                2 -> s.copy(aftertouch = !s.aftertouch)
                else -> s.copy(damper = !s.damper)
            }
            hit(rr, { _, _ -> commitControl(ns) })
        }
        val rr = RectF(r.left + 4 * (cw + gap), r.top, r.right, r.bottom)
        panel(c, rr, C_SUBPANEL, 9f.dp)
        text(c, "MIDI CHANNEL", rr.centerX(), rr.top + 25f.dp, 10f.dp, C_TEXT_MUTED, alignCenter = true)
        text(c, (s.midiChannel + 1).toString(), rr.centerX(), rr.centerY() + 10f.dp, 25f.dp, C_TEXT, alignCenter = true)
        text(c, "1 – 16", rr.centerX(), rr.bottom - 18f.dp, 10f.dp, C_TEXT_MUTED, alignCenter = true)
        hit(rr, { _, _ -> showNumber("MIDI Channel", (s.midiChannel + 1).toFloat(), 1f, 16f, 0) { commitControl(s.copy(midiChannel = it.toInt() - 1)) } },
            { commitControl(s.copy(midiChannel = 0)) })
    }

    private fun drawTone(c: Canvas, r: RectF, s: SamplerAppController.UpperState) {
        val gap = 8f.dp
        val sections = 4
        val sw = (r.width() - gap * (sections - 1)) / sections
        drawToneSection(c, RectF(r.left, r.top, r.left + sw, r.bottom), "AMP", listOf(
            "A" to s.attackScale, "D" to s.decayScale, "S" to s.sustainScale, "R" to s.releaseScale
        )) { idx, value ->
            val ns = when (idx) { 0 -> s.copy(attackScale=value); 1 -> s.copy(decayScale=value); 2 -> s.copy(sustainScale=value); else -> s.copy(releaseScale=value) }
            commitTone(ns)
        }
        drawToneSection(c, RectF(r.left + (sw+gap), r.top, r.left + (sw+gap) + sw, r.bottom), "FILTER", listOf(
            "CUT" to s.cutoffOctaves, "RES" to s.resonanceOffset
        )) { idx, value -> commitTone(if (idx==0) s.copy(cutoffOctaves=value) else s.copy(resonanceOffset=value)) }
        drawToneSection(c, RectF(r.left + 2*(sw+gap), r.top, r.left + 2*(sw+gap) + sw, r.bottom), "LFO", listOf(
            "RATE" to s.lfoRateScale, "DEPTH" to s.lfoDepthScale
        )) { idx, value -> commitTone(if (idx==0) s.copy(lfoRateScale=value) else s.copy(lfoDepthScale=value)) }
        drawToneSection(c, RectF(r.left + 3*(sw+gap), r.top, r.right, r.bottom), "EQ", listOf(
            "LOW" to s.eqLowDb, "MID" to s.eqMidDb, "HIGH" to s.eqHighDb
        )) { idx, value ->
            val ns = when (idx) { 0 -> s.copy(eqLowDb=value); 1 -> s.copy(eqMidDb=value); else -> s.copy(eqHighDb=value) }
            commitTone(ns)
        }
    }

    private fun drawToneSection(c: Canvas, r: RectF, title: String, values: List<Pair<String, Float>>, commit: (Int, Float) -> Unit) {
        panel(c, r, C_SUBPANEL, 9f.dp)
        text(c, title, r.left + 12f.dp, r.top + 22f.dp, 11f.dp, C_TEXT_MUTED)
        val gap = 5f.dp
        val top = r.top + 32f.dp
        val cellW = (r.width() - gap * (values.size + 1)) / values.size
        values.forEachIndexed { i, pair ->
            val rr = RectF(r.left + gap + i*(cellW+gap), top, r.left + gap + i*(cellW+gap)+cellW, r.bottom-8f.dp)
            text(c, pair.first, rr.centerX(), rr.top + 15f.dp, 9f.dp, C_TEXT_MUTED, alignCenter = true)
            drawKnob(c, rr.centerX(), rr.centerY(), min(rr.width(), rr.height()) * 0.23f)
            text(c, "%.2f".format(pair.second), rr.centerX(), rr.bottom - 6f.dp, 10f.dp, C_TEXT, alignCenter = true)
            val limits = when (title) {
                "AMP" -> if (i==2) (0f to 2f) else (0f to 16f)
                "FILTER" -> if (i==0) (-10f to 10f) else (-1f to 1f)
                "LFO" -> if (i==0) (0f to 16f) else (0f to 8f)
                else -> (-18f to 18f)
            }
            val default = when (title) {
                "AMP" -> 1f
                "FILTER" -> 0f
                "LFO" -> 1f
                else -> 0f
            }
            hit(rr, { _, _ -> showNumber("$title ${pair.first}", pair.second, limits.first, limits.second, 2) { commit(i,it) } }, { commit(i,default) })
        }
    }

    private fun drawUpperFx(c: Canvas, r: RectF, s: SamplerAppController.UpperState) {
        val left = RectF(r.left, r.top, r.left + r.width()*0.49f, r.bottom)
        val right = RectF(left.right + 10f.dp, r.top, r.right, r.bottom)
        listOf(left to 1, right to 2).forEach { (rr, n) ->
            panel(c, rr, C_SUBPANEL, 9f.dp)
            val value = if (n==1) s.fxSend1 else s.fxSend2
            text(c, "FX$n SEND", rr.left + 16f.dp, rr.top + 25f.dp, 11f.dp, C_TEXT_MUTED)
            val bar = RectF(rr.left + 28f.dp, rr.centerY()-7f.dp, rr.right-28f.dp, rr.centerY()+7f.dp)
            drawRangeBar(c, bar, 0f, value, 0f, 1f)
            text(c, "${(value*100f).toInt()} %", rr.centerX(), rr.bottom-18f.dp, 12f.dp, C_TEXT, alignCenter = true)
            hit(rr, { x, _ ->
                val nv = mapX(x, rr, 0f, 1f)
                commitUpperFx(if(n==1) s.copy(fxSend1=nv) else s.copy(fxSend2=nv))
            }, { commitUpperFx(if(n==1) s.copy(fxSend1=0f) else s.copy(fxSend2=0f)) })
        }
    }

    private fun drawList(c: Canvas, r: RectF) {
        panel(c, r, C_PANEL, 14f.dp)
        val pad = 18f.dp
        text(c, "●  Л И С Т", r.left+pad, r.top+28f.dp, 13f.dp, C_TEXT_DIM)
        val entries = sampler.listItems(0,0,0)
        val active = sampler.activeListEntry(0,0,0)
        val totalPages = max(1, (entries.size + 9) / 10)
        listPage = listPage.coerceIn(0, totalPages-1)
        text(c, "СТРАНИЦА ${listPage+1}/$totalPages", r.right-140f.dp, r.top+28f.dp, 10f.dp, C_TEXT_MUTED)
        val prev = RectF(r.right-220f.dp, r.top+42f.dp, r.right-160f.dp, r.top+78f.dp)
        val next = RectF(r.right-150f.dp, r.top+42f.dp, r.right-90f.dp, r.top+78f.dp)
        button(c, prev, "◀", false); button(c, next, "▶", false)
        hit(prev, {_,_-> if(listPage>0) listPage--})
        hit(next, {_,_-> if(listPage+1<totalPages) listPage++})

        val start = listPage*10
        val top = r.top + 92f.dp
        val gap = 9f.dp
        val rowH = (r.bottom-top-pad-gap*4f)/5f
        val colGap = 10f.dp
        val colW = (r.width()-pad*2-colGap)/2f
        for (j in 0 until 10) {
            val idx = start+j
            val col = j%2
            val row = j/2
            val rr = RectF(r.left+pad+col*(colW+colGap), top+row*(rowH+gap), r.left+pad+col*(colW+colGap)+colW, top+row*(rowH+gap)+rowH)
            val item = entries.getOrNull(idx)
            panel(c, rr, if(idx==active) C_ROW_SELECTED else C_ROW, 9f.dp, if(idx==active) C_ACCENT_DARK else C_BORDER)
            if(item!=null) {
                text(c, "%03d".format(item.number), rr.left+18f.dp, rr.centerY()+6f.dp, 15f.dp, C_ACCENT)
                text(c, item.name, rr.left+78f.dp, rr.centerY()+6f.dp, 16f.dp, C_TEXT)
                hit(rr,{_,_-> if(sampler.activateListEntry(0,0,0,idx)) { refreshAllUppers() }})
            } else {
                text(c, "EMPTY", rr.left+18f.dp, rr.centerY()+6f.dp, 13f.dp, C_TEXT_MUTED)
            }
        }
    }

    private fun drawEffects(c: Canvas, r: RectF) {
        panel(c, r, C_PANEL, 14f.dp)
        text(c, "●  Е Ф Е К Т И", r.left+18f.dp, r.top+30f.dp, 13f.dp, C_TEXT_DIM)
        val fx = fxState ?: sampler.combiFxState()?.also { fxState=it } ?: return
        val top = r.top+55f.dp
        val gap = 12f.dp
        val half = (r.width()-36f.dp-gap)/2f
        val f1r = RectF(r.left+18f.dp, top, r.left+18f.dp+half, r.bottom-85f.dp)
        val f2r = RectF(f1r.right+gap, top, r.right-18f.dp, r.bottom-85f.dp)
        drawFxSlot(c,f1r,1,fx.fx1)
        drawFxSlot(c,f2r,2,fx.fx2)
        val route = RectF(r.left+18f.dp, r.bottom-68f.dp, r.right-18f.dp, r.bottom-18f.dp)
        button(c,route, if(fx.routing==0) "ROUTING: PARALLEL" else "ROUTING: FX1 → FX2", true)
        hit(route,{_,_-> val next=if(fx.routing==0)1 else 0; if(sampler.updateCombiFxRouting(next)) refreshFx()},{ if(sampler.updateCombiFxRouting(0)) refreshFx() })
    }

    private fun drawFxSlot(c: Canvas, r: RectF, slot: Int, fx: SamplerAppController.FxState) {
        panel(c,r,C_SUBPANEL,10f.dp)
        text(c,"FX$slot",r.left+16f.dp,r.top+28f.dp,17f.dp,C_ACCENT,bold=true)
        val typeR=RectF(r.right-145f.dp,r.top+10f.dp,r.right-15f.dp,r.top+45f.dp)
        button(c,typeR,effectName(fx.type),false)
        hit(typeR,{_,_-> val n=(fx.type+1)%4; if(sampler.updateCombiFx(slot,fx.copy(type=n))) refreshFx()},{ if(sampler.updateCombiFx(slot,fx.copy(type=0))) refreshFx() })
        val params=listOf(
            "WET" to fx.wet, "TIME ms" to fx.timeMs, "FEEDBACK" to fx.feedback,
            "RATE Hz" to fx.rateHz, "DEPTH" to fx.depth, "TONE" to fx.tone
        )
        val cols=3; val rows=2; val gap=8f.dp
        val areaTop=r.top+58f.dp
        val cw=(r.width()-32f.dp-gap*(cols-1))/cols
        val ch=(r.bottom-areaTop-16f.dp-gap*(rows-1))/rows
        params.forEachIndexed { i,pair ->
            val col=i%cols; val row=i/cols
            val rr=RectF(r.left+16f.dp+col*(cw+gap), areaTop+row*(ch+gap), r.left+16f.dp+col*(cw+gap)+cw, areaTop+row*(ch+gap)+ch)
            text(c,pair.first,rr.centerX(),rr.top+16f.dp,9f.dp,C_TEXT_MUTED,alignCenter=true)
            drawKnob(c,rr.centerX(),rr.centerY()+3f.dp,min(rr.width(),rr.height())*0.20f)
            text(c,"%.2f".format(pair.second),rr.centerX(),rr.bottom-7f.dp,10f.dp,C_TEXT,alignCenter=true)
            val lim=when(i){0->0f to 1f;1->1f to 2500f;2->0f to .95f;3->.05f to 8f;else->0f to 1f}
            val def=when(i){0->0f;1->320f;2->.25f;3->.8f;4->.35f;else->.5f}
            hit(rr,{_,_-> showNumber("FX$slot ${pair.first}",pair.second,lim.first,lim.second,2){v->
                val nf=when(i){0->fx.copy(wet=v);1->fx.copy(timeMs=v);2->fx.copy(feedback=v);3->fx.copy(rateHz=v);4->fx.copy(depth=v);else->fx.copy(tone=v)}
                if(sampler.updateCombiFx(slot,nf)) refreshFx()
            }},{ val nf=when(i){0->fx.copy(wet=def);1->fx.copy(timeMs=def);2->fx.copy(feedback=def);3->fx.copy(rateHz=def);4->fx.copy(depth=def);else->fx.copy(tone=def)}; if(sampler.updateCombiFx(slot,nf)) refreshFx() })
        }
    }

    private fun drawSettings(c: Canvas, r: RectF) {
        panel(c,r,C_PANEL,14f.dp)
        text(c,"●  Н А С Т Р О Й К И",r.left+18f.dp,r.top+30f.dp,13f.dp,C_TEXT_DIM)
        val g=globalState ?: sampler.globalUiState()?.also{globalState=it} ?: return
        val items=listOf(
            "MASTER TUNE" to "%.1f Hz".format(g.masterTuneHz),
            "TRANSPOSE" to g.transpose.toString(),
            "MASTER GAIN" to "%.1f dB".format(g.masterGainDb),
            "EQ LOW" to "%.1f dB".format(g.eqLowDb),
            "EQ MID" to "%.1f dB".format(g.eqMidDb),
            "EQ HIGH" to "%.1f dB".format(g.eqHighDb),
            "LIMITER" to if(g.limiterEnabled)"ON" else "OFF",
            "CEILING" to "%.1f dB".format(g.limiterCeilingDb),
            "VELOCITY CURVE" to g.velocityCurve.toString(),
            "BREATH CC" to g.breathCc.toString(),
            "EXPRESSION CC" to g.expressionCc.toString(),
            "DAMPER CC" to g.damperCc.toString(),
            "PITCH BEND" to if(g.pitchBendEnabled)"ON" else "OFF",
            "AFTERTOUCH" to if(g.aftertouchEnabled)"ON" else "OFF"
        )
        val cols=4; val gap=10f.dp; val top=r.top+55f.dp
        val cw=(r.width()-36f.dp-gap*(cols-1))/cols
        val rows=(items.size+cols-1)/cols
        val ch=(r.bottom-top-18f.dp-gap*(rows-1))/rows
        items.forEachIndexed{i,item->
            val col=i%cols; val row=i/cols
            val rr=RectF(r.left+18f.dp+col*(cw+gap),top+row*(ch+gap),r.left+18f.dp+col*(cw+gap)+cw,top+row*(ch+gap)+ch)
            panel(c,rr,C_SUBPANEL,9f.dp)
            text(c,item.first,rr.centerX(),rr.top+23f.dp,9f.dp,C_TEXT_MUTED,alignCenter=true)
            text(c,item.second,rr.centerX(),rr.centerY()+12f.dp,18f.dp,C_TEXT,alignCenter=true)
            hit(rr,{_,_-> editGlobal(i,g)},{ resetGlobal(i,g) })
        }
    }

    private fun editGlobal(i:Int,g:SamplerAppController.GlobalUiState){
        when(i){
            0->showNumber("Master Tune Hz",g.masterTuneHz,400f,480f,1){commitGlobal(g.copy(masterTuneHz=it))}
            1->showNumber("Transpose",g.transpose.toFloat(),-48f,48f,0){commitGlobal(g.copy(transpose=it.toInt()))}
            2->showNumber("Master Gain dB",g.masterGainDb,-60f,18f,1){commitGlobal(g.copy(masterGainDb=it))}
            3->showNumber("EQ Low dB",g.eqLowDb,-18f,18f,1){commitGlobal(g.copy(eqLowDb=it))}
            4->showNumber("EQ Mid dB",g.eqMidDb,-18f,18f,1){commitGlobal(g.copy(eqMidDb=it))}
            5->showNumber("EQ High dB",g.eqHighDb,-18f,18f,1){commitGlobal(g.copy(eqHighDb=it))}
            6->commitGlobal(g.copy(limiterEnabled=!g.limiterEnabled))
            7->showNumber("Limiter Ceiling",g.limiterCeilingDb,-12f,0f,1){commitGlobal(g.copy(limiterCeilingDb=it))}
            8->showNumber("Velocity Curve",g.velocityCurve.toFloat(),0f,4f,0){commitGlobal(g.copy(velocityCurve=it.toInt()))}
            9->showNumber("Breath CC",g.breathCc.toFloat(),0f,127f,0){commitGlobal(g.copy(breathCc=it.toInt()))}
            10->showNumber("Expression CC",g.expressionCc.toFloat(),0f,127f,0){commitGlobal(g.copy(expressionCc=it.toInt()))}
            11->showNumber("Damper CC",g.damperCc.toFloat(),0f,127f,0){commitGlobal(g.copy(damperCc=it.toInt()))}
            12->commitGlobal(g.copy(pitchBendEnabled=!g.pitchBendEnabled))
            13->commitGlobal(g.copy(aftertouchEnabled=!g.aftertouchEnabled))
        }
    }

    private fun resetGlobal(i:Int,g:SamplerAppController.GlobalUiState){
        val n=when(i){
            0->g.copy(masterTuneHz=440f);1->g.copy(transpose=0);2->g.copy(masterGainDb=0f);3->g.copy(eqLowDb=0f);4->g.copy(eqMidDb=0f);5->g.copy(eqHighDb=0f)
            6->g.copy(limiterEnabled=true);7->g.copy(limiterCeilingDb=-0.3f);8->g.copy(velocityCurve=0);9->g.copy(breathCc=2);10->g.copy(expressionCc=11);11->g.copy(damperCc=64)
            12->g.copy(pitchBendEnabled=true);else->g.copy(aftertouchEnabled=true)
        }; commitGlobal(n)
    }

    private fun showSoundPicker(upper:Int){
        val sounds=sampler.soundCatalog()
        val labels=ArrayList<String>(sounds.size+1); labels.add("EMPTY"); sounds.forEach{labels.add(it.name)}
        AlertDialog.Builder(context).setTitle("UPPER ${upper+1} — SOUND").setItems(labels.toTypedArray()){d,which->
            if(which==0) sampler.clearUpperSound(upper) else sampler.assignUpperSound(upper,sounds[which-1])
            refreshUpper(upper); d.dismiss(); invalidate()
        }.setNegativeButton("CANCEL",null).show()
    }

    private fun showKeyRange(upper:Int,s:SamplerAppController.UpperState){
        showTwoInts("KEY RANGE", "Low 0-127", s.keyLow, "High 0-127", s.keyHigh, 0,127){lo,hi-> if(lo<=hi) commitMain(upper,s.copy(keyLow=lo,keyHigh=hi))}
    }

    private fun showVelocityRange(upper:Int,s:SamplerAppController.UpperState){
        showTwoInts("VELOCITY RANGE", "Low 1-127", s.velocityLow, "High 1-127", s.velocityHigh,1,127){lo,hi-> if(lo<=hi) commitRange(s.copy(velocityLow=lo,velocityHigh=hi))}
    }

    private fun showTwoInts(title:String,l1:String,v1:Int,l2:String,v2:Int,minV:Int,maxV:Int,done:(Int,Int)->Unit){
        val box=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,0)}
        fun field(label:String,value:Int):EditText{
            box.addView(TextView(context).apply{text=label;setTextColor(Color.LTGRAY)})
            return EditText(context).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED;setText(value.toString());setTextColor(Color.WHITE);box.addView(this)}
        }
        val a=field(l1,v1); val b=field(l2,v2)
        AlertDialog.Builder(context).setTitle(title).setView(box).setPositiveButton("OK"){_,_->
            val x=a.text.toString().toIntOrNull()?.coerceIn(minV,maxV)?:v1
            val y=b.text.toString().toIntOrNull()?.coerceIn(minV,maxV)?:v2
            done(x,y); invalidate()
        }.setNegativeButton("CANCEL",null).show()
    }

    private fun showNumber(title:String,current:Float,minV:Float,maxV:Float,decimals:Int,done:(Float)->Unit){
        val edit=EditText(context).apply{
            inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(if(decimals==0) current.toInt().toString() else "% .${decimals}f".format(current).trim())
            setSelection(text.length)
        }
        AlertDialog.Builder(context).setTitle(title).setView(edit).setPositiveButton("OK"){_,_->
            val v=edit.text.toString().replace(',','.').toFloatOrNull()?.coerceIn(minV,maxV)?:current
            done(v); invalidate()
        }.setNegativeButton("CANCEL",null).show()
    }

    private fun commitMain(i:Int,s:SamplerAppController.UpperState){ if(sampler.updateUpperMain(i,s)){upperStates[i]=sampler.upperState(i)} }
    private fun commitTune(s:SamplerAppController.UpperState){ if(sampler.updateUpperTune(selectedUpper,s)){upperStates[selectedUpper]=sampler.upperState(selectedUpper)} }
    private fun commitRange(s:SamplerAppController.UpperState){ if(sampler.updateUpperRange(selectedUpper,s)){upperStates[selectedUpper]=sampler.upperState(selectedUpper)} }
    private fun commitControl(s:SamplerAppController.UpperState){ if(sampler.updateUpperControl(selectedUpper,s)){upperStates[selectedUpper]=sampler.upperState(selectedUpper)} }
    private fun commitTone(s:SamplerAppController.UpperState){ if(sampler.updateUpperTone(selectedUpper,s)){upperStates[selectedUpper]=sampler.upperState(selectedUpper)} }
    private fun commitUpperFx(s:SamplerAppController.UpperState){ if(sampler.updateUpperFx(selectedUpper,s)){upperStates[selectedUpper]=sampler.upperState(selectedUpper)} }
    private fun commitGlobal(g:SamplerAppController.GlobalUiState){ if(sampler.updateGlobalUi(g)){globalState=sampler.globalUiState()} }

    private fun refreshUpper(i:Int){upperStates[i]=sampler.upperState(i)}
    private fun refreshAllUppers(){for(i in 0 until 7)refreshUpper(i)}
    private fun refreshFx(){fxState=sampler.combiFxState()}
    private fun refreshGlobal(){globalState=sampler.globalUiState()}

    private fun hit(r:RectF,tap:(Float,Float)->Unit,reset:(()->Unit)?=null){hits.add(Hit(RectF(r),tap,reset))}
    private fun hitAt(x:Float,y:Float):Hit?=hits.asReversed().firstOrNull{it.rect.contains(x,y)}

    private fun panel(c:Canvas,r:RectF,color:Int,rad:Float,border:Int=C_BORDER){paint.style=Paint.Style.FILL;paint.color=color;c.drawRoundRect(r,rad,rad,paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=1f.dp;paint.color=border;c.drawRoundRect(r,rad,rad,paint);paint.style=Paint.Style.FILL}
    private fun button(c:Canvas,r:RectF,label:String,active:Boolean,accent:Int=C_ACCENT){panel(c,r,if(active)C_BUTTON_ACTIVE else C_BUTTON,8f.dp,if(active)accent else C_BORDER);text(c,label,r.centerX(),r.centerY()+5f.dp,12f.dp,if(active)C_TEXT else C_TEXT_DIM,alignCenter=true,bold=active)}
    private fun tinyToggle(c:Canvas,r:RectF,label:String,on:Boolean){panel(c,r,if(on)C_BUTTON_ACTIVE else C_BUTTON,6f.dp,if(on)C_ACCENT else C_BORDER);text(c,label,r.centerX(),r.centerY()+4f.dp,10f.dp,if(on)C_TEXT else C_TEXT_MUTED,alignCenter=true,bold=on)}
    private fun chip(c:Canvas,x:Float,y:Float,label:String,h:Float):Float{paint.textSize=11f.dp;val ww=paint.measureText(label)+25f.dp;val r=RectF(x,y,x+ww,y+h);panel(c,r,C_CHIP,999f, C_BORDER);text(c,label,r.centerX(),r.centerY()+4f.dp,11f.dp,C_TEXT_DIM,alignCenter=true);return r.right}
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,alignCenter:Boolean=false,bold:Boolean=false){paint.color=color;paint.textSize=size;paint.typeface=if(bold)Typeface.create(Typeface.SANS_SERIF,Typeface.BOLD) else Typeface.create(Typeface.SANS_SERIF,Typeface.NORMAL);paint.textAlign=if(alignCenter)Paint.Align.CENTER else Paint.Align.LEFT;c.drawText(s,x,y,paint);paint.textAlign=Paint.Align.LEFT}
    private fun line(c:Canvas,x1:Float,y1:Float,x2:Float,y2:Float,color:Int,w:Float){paint.color=color;paint.strokeWidth=w;c.drawLine(x1,y1,x2,y2,paint)}
    private fun drawKnob(c:Canvas,cx:Float,cy:Float,r:Float){paint.style=Paint.Style.FILL;paint.color=C_KNOB;c.drawCircle(cx,cy,r,paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=2f.dp;paint.color=C_ACCENT;c.drawArc(RectF(cx-r,cy-r,cx+r,cy+r),135f,225f,false,paint);paint.style=Paint.Style.FILL;line(c,cx,cy,cx,cy-r*0.7f,C_TEXT,2f.dp)}
    private fun drawMiniSlider(c:Canvas,r:RectF,value:Float,minV:Float,maxV:Float,label:String){text(c,label,r.left,r.centerY()+4f.dp,10f.dp,C_TEXT);val bar=RectF(r.left+50f.dp,r.centerY()-3f.dp,r.right-5f.dp,r.centerY()+3f.dp);paint.color=C_TRACK;c.drawRoundRect(bar,3f.dp,3f.dp,paint);val t=((value-minV)/(maxV-minV)).coerceIn(0f,1f);val x=bar.left+bar.width()*t;paint.color=C_ACCENT;c.drawRoundRect(RectF(bar.left,bar.top,x,bar.bottom),3f.dp,3f.dp,paint);paint.color=C_KNOB_LIGHT;c.drawCircle(x,bar.centerY(),6f.dp,paint)}
    private fun drawUpperMeter(c:Canvas,r:RectF,peak:Float){paint.color=C_TRACK;c.drawRoundRect(r,3f.dp,3f.dp,paint);val db=if(peak<=0.000001f)-60f else (20f*kotlin.math.log10(peak)).coerceIn(-60f,6f);val t=((db+60f)/66f).coerceIn(0f,1f);paint.color=when{db>-3f->C_METER_RED;db>-12f->C_METER_YELLOW;else->C_METER_GREEN};c.drawRoundRect(RectF(r.left,r.top,r.left+r.width()*t,r.bottom),3f.dp,3f.dp,paint)}
    private fun drawRangeBar(c:Canvas,r:RectF,low:Float,high:Float,minV:Float,maxV:Float){paint.color=C_TRACK;c.drawRoundRect(r,5f.dp,5f.dp,paint);val a=((low-minV)/(maxV-minV)).coerceIn(0f,1f);val b=((high-minV)/(maxV-minV)).coerceIn(0f,1f);paint.color=C_ACCENT;c.drawRoundRect(RectF(r.left+r.width()*a,r.top,r.left+r.width()*b,r.bottom),5f.dp,5f.dp,paint);paint.color=C_KNOB_LIGHT;c.drawCircle(r.left+r.width()*a,r.centerY(),7f.dp,paint);c.drawCircle(r.left+r.width()*b,r.centerY(),7f.dp,paint)}
    private fun mapX(x:Float,r:RectF,minV:Float,maxV:Float):Float=minV+(maxV-minV)*((x-r.left)/r.width()).coerceIn(0f,1f)
    private fun voiceModeName(m:Int)=when(m){1->"MONO";2->"LEGATO";else->"POLY"}
    private fun effectName(t:Int)=when(t){1->"DELAY";2->"CHORUS";3->"REVERB";else->"OFF"}
    private fun panText(p:Float)=when{p<-0.02f->"L${(-p*100).toInt()}";p>0.02f->"R${(p*100).toInt()}";else->"C"}
    private fun formatValue(v:Float,unit:String)=if(unit.isBlank())"${v.toInt()}" else if(unit=="ms")"${v.toInt()} $unit" else "%.1f %s".format(v,unit)
    private fun noteName(key:Int):String{val names=arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B");val k=key.coerceIn(0,127);return names[k%12]+(k/12-1)}
    private val Float.dp get()=this*resources.displayMetrics.density

    companion object{
        private val C_BG=Color.rgb(8,12,18); private val C_PANEL=Color.rgb(24,31,40); private val C_PANEL_DARK=Color.rgb(18,24,32)
        private val C_SUBPANEL=Color.rgb(25,33,43); private val C_ROW=Color.rgb(31,39,49); private val C_ROW_SELECTED=Color.rgb(38,55,70)
        private val C_NAV_BG=Color.rgb(17,23,31); private val C_BUTTON=Color.rgb(30,39,50); private val C_BUTTON_ACTIVE=Color.rgb(40,75,99)
        private val C_CHIP=Color.rgb(24,31,41); private val C_BORDER=Color.rgb(47,58,70); private val C_ACCENT=Color.rgb(87,191,255)
        private val C_ACCENT_DARK=Color.rgb(55,113,151); private val C_TEXT=Color.rgb(232,238,244); private val C_TEXT_DIM=Color.rgb(166,179,192)
        private val C_TEXT_MUTED=Color.rgb(99,112,126); private val C_TRACK=Color.rgb(13,20,27); private val C_KNOB=Color.rgb(32,40,50)
        private val C_KNOB_LIGHT=Color.rgb(127,185,221); private val C_PANIC=Color.rgb(255,86,96); private val C_METER_GREEN=Color.rgb(83,192,117)
        private val C_METER_YELLOW=Color.rgb(226,188,77); private val C_METER_RED=Color.rgb(224,83,83); private val C_WARN_BG=Color.rgb(61,29,31)
        private val C_WARN_TEXT=Color.rgb(255,187,191)
    }
}
