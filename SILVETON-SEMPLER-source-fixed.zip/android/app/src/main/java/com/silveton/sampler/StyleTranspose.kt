package com.silveton.sampler

/**
 * TRANSPOSE for the PA600 style: the style parts are generated inside the PA600
 * from the chords read on its own keys, so their notes never pass through the
 * app. They are moved by RPN 2 (Channel Coarse Tune, semitones) sent on the MIDI
 * IN channels the style parts are assigned to on the PA600 (Global > MIDI > MIDI
 * IN Channels: Ch05 Bass, Ch06..Ch10 Acc1..Acc5). Coarse Tune moves the part's
 * pitch without changing note numbers, so nothing can hang. Drums are never on
 * these channels and are never moved.
 */
object StyleTranspose {
    /** Zero-based MIDI channels 4..9 = MIDI 5..10. */
    val channels = intArrayOf(4, 5, 6, 7, 8, 9)

    /** RPN 2 (Coarse Tune) = semitones on one channel, then RPN closed. */
    fun coarseTune(ch: Int, semitones: Int): List<ByteArray> {
        val st = (0xB0 or (ch and 0x0F)).toByte()
        val msb = (64 + semitones.coerceIn(-12, 12)).toByte()
        return listOf(
            byteArrayOf(st, 101, 0), byteArrayOf(st, 100, 2),
            byteArrayOf(st, 6, msb), byteArrayOf(st, 38, 0),
            byteArrayOf(st, 101, 127), byteArrayOf(st, 100, 127)
        )
    }
}
