#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "android/app/src/main/cpp/SamplerAudioBridge.cpp"
CMAKE = ROOT / "android/app/src/main/cpp/CMakeLists.txt"

bridge = BRIDGE.read_text(encoding="utf-8")
cmake = CMAKE.read_text(encoding="utf-8")

required_bridge = {
    "ALSA UAPI header": "#include <sound/asound.h>",
    "exact SM-X130 PCM node": '"/dev/snd/pcmC0D0p"',
    "hardware parameter negotiation": "SNDRV_PCM_IOCTL_HW_PARAMS",
    "software parameter negotiation": "SNDRV_PCM_IOCTL_SW_PARAMS",
    "PCM prepare": "SNDRV_PCM_IOCTL_PREPARE",
    "interleaved PCM write": "SNDRV_PCM_IOCTL_WRITEI_FRAMES",
    "kernel queue latency read-back": "SNDRV_PCM_IOCTL_DELAY",
    "XRUN detection": "-EPIPE",
    "suspend/XRUN detection": "-ESTRPIPE",
    "XRUN counter": "xrunCount_.fetch_add",
    "no-resample hardware contract": "SNDRV_PCM_HW_PARAMS_NORESAMPLE",
    "S16 hardware format": "SNDRV_PCM_FORMAT_S16_LE",
    "realtime worker": "audioLoop() noexcept",
}

errors = []
for label, token in required_bridge.items():
    if token not in bridge:
        errors.append(f"missing {label}: {token}")

for forbidden in ("#include <aaudio/AAudio.h>", "AAudioStream_", "AAudioStream*", "AAudio_createStreamBuilder"):
    if forbidden in bridge:
        errors.append(f"AAudio runtime dependency returned: {forbidden}")

if " aaudio" in cmake.lower() or "aaudio)" in cmake.lower():
    errors.append("AAudio is still linked by android/app/src/main/cpp/CMakeLists.txt")

if "target_link_libraries(silveton_jni PRIVATE silveton_live_core log)" not in cmake:
    errors.append("JNI target link contract is not silveton_live_core + log only")

if errors:
    print("Direct-ALSA contract FAIL")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print("Direct-ALSA contract PASS: raw PCM backend present; AAudio runtime/link dependency absent")
