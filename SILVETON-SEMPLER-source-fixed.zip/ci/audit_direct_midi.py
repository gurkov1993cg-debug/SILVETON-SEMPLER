#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CPP = ROOT / "android/app/src/main/cpp/SamplerAudioBridge.cpp"
NATIVE = ROOT / "android/app/src/main/java/com/silveton/sampler/NativeSamplerEngine.kt"
STATUS = ROOT / "android/app/src/main/java/com/silveton/sampler/SamplerMidiController.kt"
APP = ROOT / "android/app/src/main/java/com/silveton/sampler/SamplerAppController.kt"

checks = []

def require(condition: bool, message: str) -> None:
    checks.append((condition, message))

cpp = CPP.read_text(encoding="utf-8")
native = NATIVE.read_text(encoding="utf-8")
status = STATUS.read_text(encoding="utf-8")
app = APP.read_text(encoding="utf-8")

require('kAlsaDeviceDirectory = "/dev/snd"' in cpp, "native MIDI scans /dev/snd")
require('std::strncmp(name, "midiC"' in cpp, "native MIDI identifies ALSA raw-MIDI nodes")
require("SNDRV_RAWMIDI_IOCTL_PARAMS" in cpp, "native MIDI configures ALSA raw-MIDI input")
require("SNDRV_RAWMIDI_STREAM_INPUT" in cpp, "raw-MIDI stream direction is input")
require("::poll(" in cpp and "::read(" in cpp, "MIDI bytes are read directly from kernel file descriptors")
require("directMidiLoop" in cpp and "midiThread_" in cpp, "native direct-MIDI worker exists")
require("feedRawMidiByte" in cpp and "runningStatus" in cpp, "native MIDI byte-stream parser handles running status")
require("nativeMidiDeviceCount" in cpp and "nativeMidiLastError" in cpp, "native direct-MIDI status JNI exists")
require("external fun nativeMidiDeviceCount(): Int" in native, "Kotlin declares native direct-MIDI port count")
require("external fun nativeMidiLastError(): Int" in native, "Kotlin declares native direct-MIDI error")
require("android.media.midi" not in status, "sampler MIDI runtime no longer imports Android MIDI framework")
require("nativeMidiDeviceCount()" in status, "UI MIDI indicator reads native raw-MIDI port count")
require("nativeMidiLastError()" in status, "UI status reads native raw-MIDI errors")
require("midi.start()" in app, "controller starts direct-MIDI status companion")

failed = [message for ok, message in checks if not ok]
for ok, message in checks:
    print(("PASS" if ok else "FAIL") + " - " + message)

if failed:
    print(f"Direct MIDI audit: {len(checks) - len(failed)}/{len(checks)} PASS", file=sys.stderr)
    sys.exit(1)

print(f"Direct MIDI audit: {len(checks)}/{len(checks)} PASS")
