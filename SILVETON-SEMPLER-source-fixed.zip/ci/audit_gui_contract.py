#!/usr/bin/env python3
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
view = (root / 'android/app/src/main/java/com/silveton/sampler/SilvetonSamplerView.kt').read_text(encoding='utf-8')
kt = (root / 'android/app/src/main/java/com/silveton/sampler/NativeSamplerEngine.kt').read_text(encoding='utf-8')
cpp = (root / 'android/app/src/main/cpp/SamplerAudioBridge.cpp').read_text(encoding='utf-8')

def require(needle: str, where: str = 'GUI') -> None:
    text = view if where == 'GUI' else cpp
    if needle not in text:
        raise SystemExit(f'MISSING {where} contract token: {needle}')

# Global tablet navigation: PROGRAM/SAMPLE/MIXER are intentionally absent as buttons.
for required in ['Page.LIST to "ЛИСТ"', 'Page.COMBI to "КОМБИ"', 'Page.EFFECTS to "ЕФЕКТИ"', 'page = Page.SETTINGS']:
    require(required)

# UPPER main row handlers.
for required in [
    'showSoundPicker(i)', 'commitMain(i, s.copy(enabled = !s.enabled))',
    'commitMain(i, s.copy(solo = !s.solo))', 'commitMain(i, s.copy(mute = !s.mute))',
    'commitMain(i, s.copy(levelDb = v))', 'commitMain(i, s.copy(pan = mapX',
    'showKeyRange(i, s)', 'voiceMode = (s.voiceMode + 1) % 3',
    'drawUpperMeter(c, meterR'
]: require(required)

# Selected-UPPER tabs must all be real update paths.
for required in [
    'sampler.updateUpperTune', 'sampler.updateUpperRange', 'sampler.updateUpperControl',
    'sampler.updateUpperTone', 'sampler.updateUpperFx'
]: require(required)

# Shared effects and global settings must be functional, not dead navigation pages.
for required in ['sampler.updateCombiFx(', 'sampler.updateCombiFxRouting(', 'sampler.updateGlobalUi(']:
    require(required)

# JNI declaration/implementation contract: exact 1:1 set.
extern = set(re.findall(r'external fun\s+(native\w+)\s*\(', kt))
impl = set(re.findall(r'Java_com_silveton_sampler_NativeSamplerEngine_(native\w+)\s*\(', cpp))
missing = sorted(extern - impl)
extra = sorted(impl - extern)
if missing or extra:
    print('Missing JNI:', missing)
    print('Extra JNI:', extra)
    sys.exit(1)

# Per-UPPER meters must originate from real DSP meter snapshot values.
for required in ['m.upperPeakLeft', 'm.upperPeakRight', 'nativeMeters']:
    require(required, 'CPP')

print(f'GUI/JNI contract PASS: {len(extern)}/{len(impl)} JNI methods; visible COMBI actions wired.')
