#!/usr/bin/env bash
set -euo pipefail

APK="${1:?usage: verify_apk.sh path/to.apk}"
BUILD_TOOLS_VERSION="${ANDROID_BUILD_TOOLS_VERSION:-35.0.0}"
: "${ANDROID_HOME:?ANDROID_HOME must be set}"
: "${ANDROID_NDK_HOME:?ANDROID_NDK_HOME must be set}"

AAPT="${ANDROID_HOME}/build-tools/${BUILD_TOOLS_VERSION}/aapt"
APKSIGNER="${ANDROID_HOME}/build-tools/${BUILD_TOOLS_VERSION}/apksigner"
ZIPALIGN="${ANDROID_HOME}/build-tools/${BUILD_TOOLS_VERSION}/zipalign"
READELF="${ANDROID_NDK_HOME}/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf"

for tool in "$AAPT" "$APKSIGNER" "$ZIPALIGN" "$READELF"; do
    [[ -x "$tool" ]] || { echo "Missing tool: $tool" >&2; exit 2; }
done
[[ -f "$APK" ]] || { echo "Missing APK: $APK" >&2; exit 2; }

BADGING="$($AAPT dump badging "$APK")"
grep -q "package: name='com.silveton.sampler'" <<<"$BADGING"
grep -q "sdkVersion:'26'" <<<"$BADGING"
grep -q "targetSdkVersion:'35'" <<<"$BADGING"

mapfile -t ABIS < <(unzip -Z1 "$APK" | awk -F/ '/^lib\/[^/]+\/[^/]+\.so$/ {print $2}' | sort -u)
[[ ${#ABIS[@]} -eq 1 && "${ABIS[0]}" == "arm64-v8a" ]] || {
    printf 'Unexpected packaged ABIs: %s\n' "${ABIS[*]:-none}" >&2
    exit 3
}

unzip -Z1 "$APK" | grep -qx 'lib/arm64-v8a/libsilveton_jni.so'
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
unzip -qq "$APK" 'lib/arm64-v8a/libsilveton_jni.so' -d "$TMP_DIR"
LIB="$TMP_DIR/lib/arm64-v8a/libsilveton_jni.so"
"$READELF" -h "$LIB" | grep -Eq 'Machine:[[:space:]]+AArch64'

# Modern Android packages containing native code must be page-aligned as well as zip-aligned.
"$ZIPALIGN" -c -P 16 -v 4 "$APK"
"$APKSIGNER" verify --verbose --print-certs "$APK"

printf '%s\n' "$BADGING" | grep -E "^(package:|sdkVersion:|targetSdkVersion:|application-label:)" || true
printf 'APK verification PASS: %s\n' "$APK"
