#pragma once

#include <cstdint>
#include <memory>
#include <string>

namespace silveton::sampler {

class SampleStream {
public:
    virtual ~SampleStream() = default;
    [[nodiscard]] virtual std::uint64_t frameCount() const noexcept = 0;
    [[nodiscard]] virtual std::uint16_t channels() const noexcept = 0;
    [[nodiscard]] virtual std::uint32_t sampleRate() const noexcept = 0;
    [[nodiscard]] virtual float readFrame(std::uint64_t frame, std::uint16_t channel) const noexcept = 0;
};

struct MappedPcmSpec {
    std::uint64_t dataOffset{0};
    std::uint64_t frameCount{0};
    std::uint32_t sampleRate{0};
    std::uint16_t channels{0};
    std::uint16_t bitDepth{0};
    std::uint16_t formatTag{0}; // WAV: 1 PCM, 3 IEEE float
    bool bigEndian{false};
};

class MappedPcmStream final : public SampleStream {
public:
    static std::shared_ptr<MappedPcmStream> open(const std::string& path, const MappedPcmSpec& spec, std::string& error);
    ~MappedPcmStream() override;

    [[nodiscard]] std::uint64_t frameCount() const noexcept override { return spec_.frameCount; }
    [[nodiscard]] std::uint16_t channels() const noexcept override { return spec_.channels; }
    [[nodiscard]] std::uint32_t sampleRate() const noexcept override { return spec_.sampleRate; }
    [[nodiscard]] float readFrame(std::uint64_t frame, std::uint16_t channel) const noexcept override;

private:
    MappedPcmStream() = default;
    MappedPcmSpec spec_{};
    int fd_{-1};
    void* mapping_{nullptr};
    std::uint64_t mappingSize_{0};
};

} // namespace silveton::sampler
