#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <cstddef>

namespace silveton::sampler {

enum class InterpolationQuality : int { Fast8 = 8, High16 = 16, Ultra32 = 32 };

class SincInterpolator {
public:
    explicit SincInterpolator(InterpolationQuality quality = InterpolationQuality::High16) noexcept;

    void setQuality(InterpolationQuality quality) noexcept { quality_ = quality; }
    [[nodiscard]] InterpolationQuality quality() const noexcept { return quality_; }

    [[nodiscard]] float read(const SampleData& sample,
                             double position,
                             std::uint16_t channel,
                             double playbackRatio,
                             bool looping) const noexcept;

private:
    [[nodiscard]] float readFrame(const SampleData& sample,
                                  long long frame,
                                  std::uint16_t channel,
                                  bool looping) const noexcept;
    [[nodiscard]] static double sinc(double x) noexcept;
    [[nodiscard]] static double blackman(double normalized) noexcept;

    InterpolationQuality quality_;
};

} // namespace silveton::sampler
