#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

namespace silveton::sampler {
namespace {

std::uint16_t le16(const std::uint8_t* p) noexcept {
    return static_cast<std::uint16_t>(p[0]) |
           static_cast<std::uint16_t>(static_cast<std::uint16_t>(p[1]) << 8U);
}

std::uint32_t le32(const std::uint8_t* p) noexcept {
    return static_cast<std::uint32_t>(p[0]) |
           (static_cast<std::uint32_t>(p[1]) << 8U) |
           (static_cast<std::uint32_t>(p[2]) << 16U) |
           (static_cast<std::uint32_t>(p[3]) << 24U);
}

std::uint16_t be16(const std::uint8_t* p) noexcept {
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(p[0]) << 8U) |
                                     static_cast<std::uint16_t>(p[1]));
}

std::uint32_t be32(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24U) |
           (static_cast<std::uint32_t>(p[1]) << 16U) |
           (static_cast<std::uint32_t>(p[2]) << 8U) |
           static_cast<std::uint32_t>(p[3]);
}

std::uint64_t be64(const std::uint8_t* p) noexcept {
    std::uint64_t v = 0U;
    for (int i = 0; i < 8; ++i) v = (v << 8U) | static_cast<std::uint64_t>(p[i]);
    return v;
}

std::uint64_t le64(const std::uint8_t* p) noexcept {
    std::uint64_t v = 0U;
    for (int i = 7; i >= 0; --i) v = (v << 8U) | static_cast<std::uint64_t>(p[i]);
    return v;
}

float clampF(double x) noexcept {
    return static_cast<float>(std::clamp(x, -1.0, 1.0));
}

} // namespace

std::shared_ptr<MappedPcmStream> MappedPcmStream::open(const std::string& path,
                                                       const MappedPcmSpec& spec,
                                                       std::string& error) {
    if (spec.channels == 0U || spec.channels > 2U || spec.sampleRate == 0U || spec.frameCount == 0U) {
        error = "Invalid mapped PCM specification";
        return nullptr;
    }
    const std::uint64_t bytesPerSample = spec.bitDepth / 8U;
    if (bytesPerSample == 0U) {
        error = "Invalid mapped PCM bit depth";
        return nullptr;
    }
    const std::uint64_t required = spec.dataOffset +
        spec.frameCount * static_cast<std::uint64_t>(spec.channels) * bytesPerSample;

    const int fd = ::open(path.c_str(), O_RDONLY);
    if (fd < 0) {
        error = "Cannot open mapped PCM file";
        return nullptr;
    }

    struct stat st {};
    if (fstat(fd, &st) != 0 || st.st_size < 0 || static_cast<std::uint64_t>(st.st_size) < required) {
        ::close(fd);
        error = "Mapped PCM file is shorter than declared data";
        return nullptr;
    }

    void* map = mmap(nullptr,
                     static_cast<std::size_t>(st.st_size),
                     PROT_READ,
                     MAP_PRIVATE,
                     fd,
                     0);
    if (map == MAP_FAILED) {
        ::close(fd);
        error = "mmap failed for PCM file";
        return nullptr;
    }
#ifdef MADV_SEQUENTIAL
    (void)madvise(map, static_cast<std::size_t>(st.st_size), MADV_SEQUENTIAL);
#endif

    auto out = std::shared_ptr<MappedPcmStream>(new MappedPcmStream());
    out->spec_ = spec;
    out->fd_ = fd;
    out->mapping_ = map;
    out->mappingSize_ = static_cast<std::uint64_t>(st.st_size);
    return out;
}

MappedPcmStream::~MappedPcmStream() {
    if (mapping_ != nullptr && mapping_ != MAP_FAILED) {
        munmap(mapping_, static_cast<std::size_t>(mappingSize_));
    }
    if (fd_ >= 0) ::close(fd_);
}

float MappedPcmStream::readFrame(std::uint64_t frame, std::uint16_t channel) const noexcept {
    if (mapping_ == nullptr || frame >= spec_.frameCount) return 0.0F;

    const std::uint16_t ch = std::min<std::uint16_t>(
        channel, static_cast<std::uint16_t>(spec_.channels - 1U));
    const std::uint64_t bps = spec_.bitDepth / 8U;
    const std::uint64_t offset = spec_.dataOffset +
        (frame * static_cast<std::uint64_t>(spec_.channels) + ch) * bps;
    if (offset + bps > mappingSize_) return 0.0F;
    const auto* p = static_cast<const std::uint8_t*>(mapping_) + offset;

    if (spec_.formatTag == 3U) {
        if (spec_.bitDepth == 32U) {
            const auto u = spec_.bigEndian ? be32(p) : le32(p);
            float f = 0.0F;
            std::memcpy(&f, &u, sizeof(f));
            return clampF(static_cast<double>(f));
        }
        if (spec_.bitDepth == 64U) {
            const auto u = spec_.bigEndian ? be64(p) : le64(p);
            double d = 0.0;
            std::memcpy(&d, &u, sizeof(d));
            return clampF(d);
        }
        return 0.0F;
    }
    if (spec_.formatTag != 1U) return 0.0F;

    if (spec_.bitDepth == 8U) {
        return spec_.bigEndian
            ? static_cast<float>(static_cast<std::int8_t>(p[0])) / 128.0F
            : (static_cast<float>(p[0]) - 128.0F) / 128.0F;
    }
    if (spec_.bitDepth == 16U) {
        const auto u = spec_.bigEndian ? be16(p) : le16(p);
        return static_cast<float>(static_cast<std::int16_t>(u)) / 32768.0F;
    }
    if (spec_.bitDepth == 24U) {
        std::int32_t v = spec_.bigEndian
            ? ((static_cast<std::int32_t>(p[0]) << 16) |
               (static_cast<std::int32_t>(p[1]) << 8) |
               static_cast<std::int32_t>(p[2]))
            : (static_cast<std::int32_t>(p[0]) |
               (static_cast<std::int32_t>(p[1]) << 8) |
               (static_cast<std::int32_t>(p[2]) << 16));
        if ((v & 0x00800000) != 0) v |= static_cast<std::int32_t>(0xFF000000U);
        return static_cast<float>(v) / 8388608.0F;
    }
    if (spec_.bitDepth == 32U) {
        const auto u = spec_.bigEndian ? be32(p) : le32(p);
        return static_cast<float>(static_cast<double>(static_cast<std::int32_t>(u)) / 2147483648.0);
    }
    return 0.0F;
}

} // namespace silveton::sampler
