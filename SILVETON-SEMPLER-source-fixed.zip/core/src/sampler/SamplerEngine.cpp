#include "silveton/sampler/SamplerEngine.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>

namespace silveton::sampler {
namespace {

constexpr double kPi = 3.14159265358979323846264338327950288;
constexpr float kInv127 = 1.0F / 127.0F;

float dbToGain(float db) noexcept {
    return std::pow(10.0F, db / 20.0F);
}

float gainToDb(float gain) noexcept {
    const float g = std::max(gain, 1.0e-12F);
    return 20.0F * std::log10(g);
}

float clamp01(float v) noexcept { return std::clamp(v, 0.0F, 1.0F); }

struct Envelope {
    enum class Stage : std::uint8_t { Idle, Attack, Decay, Sustain, Release };

    EnvelopeParams params{};
    Stage stage{Stage::Idle};
    float value{0.0F};
    float releaseStep{0.0F};

    void trigger() noexcept {
        stage = Stage::Attack;
        if (params.attackSec <= 0.0F) {
            value = 1.0F;
            stage = Stage::Decay;
        }
    }

    void release(double sr) noexcept {
        if (stage == Stage::Idle || stage == Stage::Release) return;
        stage = Stage::Release;
        const float frames = static_cast<float>(std::max(1.0, static_cast<double>(params.releaseSec) * sr));
        releaseStep = value / frames;
    }

    void forceOff() noexcept {
        value = 0.0F;
        stage = Stage::Idle;
        releaseStep = 0.0F;
    }

    [[nodiscard]] bool active() const noexcept { return stage != Stage::Idle; }

    float process(double sr) noexcept {
        const float srF = static_cast<float>(std::max(1.0, sr));
        switch (stage) {
            case Stage::Idle:
                value = 0.0F;
                break;
            case Stage::Attack: {
                if (params.attackSec <= 0.0F) {
                    value = 1.0F;
                    stage = Stage::Decay;
                } else {
                    value += 1.0F / (params.attackSec * srF);
                    if (value >= 1.0F) {
                        value = 1.0F;
                        stage = Stage::Decay;
                    }
                }
                break;
            }
            case Stage::Decay: {
                const float sus = clamp01(params.sustain);
                if (params.decaySec <= 0.0F) {
                    value = sus;
                    stage = Stage::Sustain;
                } else {
                    value -= (1.0F - sus) / (params.decaySec * srF);
                    if (value <= sus) {
                        value = sus;
                        stage = Stage::Sustain;
                    }
                }
                break;
            }
            case Stage::Sustain:
                value = clamp01(params.sustain);
                break;
            case Stage::Release:
                value -= releaseStep;
                if (value <= 0.0F || !std::isfinite(value)) {
                    value = 0.0F;
                    stage = Stage::Idle;
                }
                break;
        }
        return value;
    }
};

struct LfoState {
    double phase{0.0};
    double ageSec{0.0};
    std::uint32_t randomState{0x12345678U};
    float heldRandom{0.0F};

    void reset(bool keySync) noexcept {
        ageSec = 0.0;
        if (keySync) phase = 0.0;
    }

    float process(const LfoParams& p, double sr) noexcept {
        const double safeSr = std::max(1.0, sr);
        ageSec += 1.0 / safeSr;
        const double oldPhase = phase;
        phase += std::max(0.0F, p.frequencyHz) / safeSr;
        phase -= std::floor(phase);

        float v = 0.0F;
        switch (p.wave) {
            case LfoWave::Sine: v = static_cast<float>(std::sin(2.0 * kPi * phase)); break;
            case LfoWave::Triangle: v = static_cast<float>(1.0 - 4.0 * std::abs(phase - 0.5)); break;
            case LfoWave::SawUp: v = static_cast<float>(2.0 * phase - 1.0); break;
            case LfoWave::SawDown: v = static_cast<float>(1.0 - 2.0 * phase); break;
            case LfoWave::Square: v = phase < 0.5 ? 1.0F : -1.0F; break;
            case LfoWave::RandomHold:
                if (phase < oldPhase) {
                    randomState = randomState * 1664525U + 1013904223U;
                    heldRandom = static_cast<float>((static_cast<double>(randomState) / 4294967295.0) * 2.0 - 1.0);
                }
                v = heldRandom;
                break;
        }

        if (ageSec < static_cast<double>(std::max(0.0F, p.delaySec))) return 0.0F;
        const float fade = p.fadeSec <= 0.0F
            ? 1.0F
            : clamp01(static_cast<float>((ageSec - static_cast<double>(p.delaySec)) / static_cast<double>(p.fadeSec)));
        return v * fade;
    }
};

struct StateVariableFilter {
    float ic1eqL{0.0F};
    float ic2eqL{0.0F};
    float ic1eqR{0.0F};
    float ic2eqR{0.0F};

    void reset() noexcept { ic1eqL = ic2eqL = ic1eqR = ic2eqR = 0.0F; }

    float processOne(float x, float& ic1eq, float& ic2eq, FilterMode mode,
                     float cutoffHz, float resonance, double sampleRate) noexcept {
        if (mode == FilterMode::Bypass) return x;
        const float nyquistSafe = static_cast<float>(std::max(100.0, sampleRate * 0.45));
        const float cutoff = std::clamp(cutoffHz, 20.0F, nyquistSafe);
        const float g = std::tan(static_cast<float>(kPi) * cutoff / static_cast<float>(sampleRate));
        const float q = 0.5F + std::clamp(resonance, 0.0F, 1.0F) * 11.5F;
        const float k = 1.0F / q;
        const float a1 = 1.0F / (1.0F + g * (g + k));
        const float a2 = g * a1;
        const float a3 = g * a2;
        const float v3 = x - ic2eq;
        const float v1 = a1 * ic1eq + a2 * v3;
        const float v2 = ic2eq + a2 * ic1eq + a3 * v3;
        ic1eq = 2.0F * v1 - ic1eq;
        ic2eq = 2.0F * v2 - ic2eq;
        const float low = v2;
        const float band = v1;
        const float high = x - k * band - low;
        switch (mode) {
            case FilterMode::LowPass: return low;
            case FilterMode::HighPass: return high;
            case FilterMode::BandPass: return band;
            case FilterMode::Bypass: return x;
        }
        return x;
    }

    void process(float& l, float& r, FilterMode mode, float cutoffHz, float resonance, double sr) noexcept {
        l = processOne(l, ic1eqL, ic2eqL, mode, cutoffHz, resonance, sr);
        r = processOne(r, ic1eqR, ic2eqR, mode, cutoffHz, resonance, sr);
    }
};

struct Biquad {
    float b0{1.0F}, b1{0.0F}, b2{0.0F}, a1{0.0F}, a2{0.0F};
    float z1L{0.0F}, z2L{0.0F}, z1R{0.0F}, z2R{0.0F};

    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0F; }

    void setPeaking(double sr, float freq, float q, float gainDb) noexcept {
        const double A = std::pow(10.0, static_cast<double>(gainDb) / 40.0);
        const double w0 = 2.0 * kPi * static_cast<double>(freq) / sr;
        const double alpha = std::sin(w0) / (2.0 * std::max(0.1, static_cast<double>(q)));
        const double c = std::cos(w0);
        const double a0 = 1.0 + alpha / A;
        b0 = static_cast<float>((1.0 + alpha * A) / a0);
        b1 = static_cast<float>((-2.0 * c) / a0);
        b2 = static_cast<float>((1.0 - alpha * A) / a0);
        a1 = static_cast<float>((-2.0 * c) / a0);
        a2 = static_cast<float>((1.0 - alpha / A) / a0);
    }

    void setShelf(double sr, float freq, float gainDb, bool high) noexcept {
        const double A = std::pow(10.0, static_cast<double>(gainDb) / 40.0);
        const double w0 = 2.0 * kPi * static_cast<double>(freq) / sr;
        const double c = std::cos(w0);
        const double s = std::sin(w0);
        const double alpha = s / std::sqrt(2.0);
        const double beta = 2.0 * std::sqrt(A) * alpha;
        double B0, B1, B2, A0, A1, A2;
        if (high) {
            B0 = A * ((A + 1.0) + (A - 1.0) * c + beta);
            B1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * c);
            B2 = A * ((A + 1.0) + (A - 1.0) * c - beta);
            A0 = (A + 1.0) - (A - 1.0) * c + beta;
            A1 = 2.0 * ((A - 1.0) - (A + 1.0) * c);
            A2 = (A + 1.0) - (A - 1.0) * c - beta;
        } else {
            B0 = A * ((A + 1.0) - (A - 1.0) * c + beta);
            B1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * c);
            B2 = A * ((A + 1.0) - (A - 1.0) * c - beta);
            A0 = (A + 1.0) + (A - 1.0) * c + beta;
            A1 = -2.0 * ((A - 1.0) + (A + 1.0) * c);
            A2 = (A + 1.0) + (A - 1.0) * c - beta;
        }
        b0 = static_cast<float>(B0 / A0);
        b1 = static_cast<float>(B1 / A0);
        b2 = static_cast<float>(B2 / A0);
        a1 = static_cast<float>(A1 / A0);
        a2 = static_cast<float>(A2 / A0);
    }

    static float tick(float x, float& z1, float& z2, float b0, float b1, float b2, float a1, float a2) noexcept {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void process(float& l, float& r) noexcept {
        l = tick(l, z1L, z2L, b0, b1, b2, a1, a2);
        r = tick(r, z1R, z2R, b0, b1, b2, a1, a2);
    }
};

struct DelayFx {
    static constexpr std::size_t kMaxFrames = 192000U * 3U;
    std::array<float, kMaxFrames> left{};
    std::array<float, kMaxFrames> right{};
    std::size_t write{0U};
    double sampleRate{48000.0};

    void reset(double sr) noexcept {
        sampleRate = sr;
        std::fill(left.begin(), left.end(), 0.0F);
        std::fill(right.begin(), right.end(), 0.0F);
        write = 0U;
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        const double ms = std::clamp(static_cast<double>(p.timeMs), 1.0, 2500.0);
        const std::size_t delayFrames = std::min<std::size_t>(kMaxFrames - 1U,
            static_cast<std::size_t>(std::max(1.0, std::round(sampleRate * ms / 1000.0))));
        const std::size_t read = (write + kMaxFrames - delayFrames) % kMaxFrames;
        const float dl = left[read];
        const float dr = right[read];
        const float fb = std::clamp(p.feedback, 0.0F, 0.95F);
        left[write] = inL + dl * fb;
        right[write] = inR + dr * fb;
        write = (write + 1U) % kMaxFrames;
        wetL = dl;
        wetR = dr;
    }
};

struct ChorusFx {
    static constexpr std::size_t kMaxFrames = 192000U / 5U;
    std::array<float, kMaxFrames> left{};
    std::array<float, kMaxFrames> right{};
    std::size_t write{0U};
    double phase{0.0};
    double sampleRate{48000.0};

    void reset(double sr) noexcept {
        sampleRate = sr;
        std::fill(left.begin(), left.end(), 0.0F);
        std::fill(right.begin(), right.end(), 0.0F);
        write = 0U;
        phase = 0.0;
    }

    float interp(const std::array<float, kMaxFrames>& b, double delayFrames) const noexcept {
        double rp = static_cast<double>(write) - delayFrames;
        while (rp < 0.0) rp += static_cast<double>(kMaxFrames);
        const auto i0 = static_cast<std::size_t>(rp) % kMaxFrames;
        const auto i1 = (i0 + 1U) % kMaxFrames;
        const float frac = static_cast<float>(rp - std::floor(rp));
        return b[i0] + (b[i1] - b[i0]) * frac;
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        left[write] = inL;
        right[write] = inR;
        const double base = sampleRate * 0.012;
        const double depth = sampleRate * 0.008 * static_cast<double>(std::clamp(p.depth, 0.0F, 1.0F));
        const double lfoL = 0.5 + 0.5 * std::sin(2.0 * kPi * phase);
        const double lfoR = 0.5 + 0.5 * std::sin(2.0 * kPi * (phase + 0.25));
        wetL = interp(left, base + depth * lfoL);
        wetR = interp(right, base + depth * lfoR);
        write = (write + 1U) % kMaxFrames;
        phase += static_cast<double>(std::clamp(p.rateHz, 0.05F, 8.0F)) / sampleRate;
        phase -= std::floor(phase);
    }
};

struct ReverbFx {
    // Compact Schroeder network. Fixed arrays: no allocations in audio callback.
    std::array<float, 4096U> c1L{}, c1R{};
    std::array<float, 4608U> c2L{}, c2R{};
    std::array<float, 5120U> c3L{}, c3R{};
    std::array<float, 5632U> c4L{}, c4R{};
    std::array<std::size_t, 4U> pos{{0U,0U,0U,0U}};
    float dampL1{0.0F}, dampR1{0.0F}, dampL2{0.0F}, dampR2{0.0F};

    void reset(double) noexcept {
        c1L.fill(0.0F); c1R.fill(0.0F); c2L.fill(0.0F); c2R.fill(0.0F);
        c3L.fill(0.0F); c3R.fill(0.0F); c4L.fill(0.0F); c4R.fill(0.0F);
        pos = {{0U,0U,0U,0U}};
        dampL1 = dampR1 = dampL2 = dampR2 = 0.0F;
    }

    template<std::size_t N>
    static float comb(std::array<float,N>& b, std::size_t& p, float x, float feedback, float tone, float& damp) noexcept {
        const float y = b[p];
        damp += (y - damp) * std::clamp(tone, 0.05F, 0.95F);
        b[p] = x + damp * feedback;
        p = (p + 1U) % N;
        return y;
    }

    void process(float inL, float inR, const EffectSlot& p, float& wetL, float& wetR) noexcept {
        const float fb = std::clamp(0.55F + p.feedback * 0.35F, 0.4F, 0.92F);
        const float tone = 0.02F + std::clamp(p.tone, 0.0F, 1.0F) * 0.25F;
        const float mono = (inL + inR) * 0.35F;
        const float aL = comb(c1L, pos[0], mono, fb, tone, dampL1);
        const float aR = comb(c1R, pos[0], mono, fb * 0.997F, tone, dampR1);
        const float bL = comb(c2L, pos[1], mono, fb * 0.989F, tone, dampL2);
        const float bR = comb(c2R, pos[1], mono, fb * 0.983F, tone, dampR2);
        // The remaining two taps are written/read manually so their positions are independent.
        float cL = c3L[pos[2]], cR = c3R[pos[2]];
        c3L[pos[2]] = mono + cL * (fb * 0.971F);
        c3R[pos[2]] = mono + cR * (fb * 0.967F);
        pos[2] = (pos[2] + 1U) % c3L.size();
        float dL = c4L[pos[3]], dR = c4R[pos[3]];
        c4L[pos[3]] = mono + dL * (fb * 0.959F);
        c4R[pos[3]] = mono + dR * (fb * 0.953F);
        pos[3] = (pos[3] + 1U) % c4L.size();
        wetL = 0.25F * (aL + bL + cL + dL);
        wetR = 0.25F * (aR + bR + cR + dR);
    }
};

} // namespace

bool RealtimeEventQueue::push(const RealtimeEvent& event) noexcept {
    const std::size_t w = write_.load(std::memory_order_relaxed);
    const std::size_t next = (w + 1U) % kCapacity;
    if (next == read_.load(std::memory_order_acquire)) {
        dropped_.fetch_add(1U, std::memory_order_relaxed);
        return false;
    }
    data_[w] = event;
    write_.store(next, std::memory_order_release);
    return true;
}

bool RealtimeEventQueue::pop(RealtimeEvent& event) noexcept {
    const std::size_t r = read_.load(std::memory_order_relaxed);
    if (r == write_.load(std::memory_order_acquire)) return false;
    event = data_[r];
    read_.store((r + 1U) % kCapacity, std::memory_order_release);
    return true;
}

void RealtimeEventQueue::clear() noexcept {
    read_.store(write_.load(std::memory_order_acquire), std::memory_order_release);
}

struct SamplerEngine::Impl {
    struct ChannelState {
        float expression{1.0F};
        float breath{1.0F};
        float pressure{0.0F};
        std::array<float, 128U> cc{};
        bool sustain{false};
        std::int16_t pitchBend{0};
    };

    struct Voice {
        bool active{false};
        bool keyHeld{false};
        bool sustained{false};
        std::uint64_t age{0U};
        std::uint8_t channel{0U};
        std::uint8_t key{0U};
        std::uint8_t velocity{0U};
        int upperIndex{0};
        SamplePtr sample;
        const ProgramLayer* layer{nullptr};
        const SampleZone* zone{nullptr};
        const UpperPart* upper{nullptr};
        double position{0.0};
        double ratio{1.0};
        double targetRatio{1.0};
        double glideLogStep{0.0};
        std::uint32_t glideFramesRemaining{0U};
        std::uint32_t delayFramesRemaining{0U};
        float baseGain{1.0F};
        float basePan{0.0F};
        float leftGain{0.70710678F};
        float rightGain{0.70710678F};
        Envelope ampEnv{};
        Envelope filterEnv{};
        Envelope pitchEnv{};
        LfoState lfo1{};
        LfoState lfo2{};
        StateVariableFilter filter{};
    };

    double sampleRate{48000.0};
    std::uint32_t maxBlock{512U};
    std::array<Voice, kMaxVoices> voices{};
    std::array<ChannelState, 16U> channels{};
    std::uint64_t voiceAge{0U};
    float peakL{0.0F};
    float peakR{0.0F};
    float limiterGrDb{0.0F};
    std::array<float, kUpperCount> upperPeakL{};
    std::array<float, kUpperCount> upperPeakR{};
    Biquad lowEq{}, midEq{}, highEq{};
    std::array<Biquad, kUpperCount> upperLowEq{};
    std::array<Biquad, kUpperCount> upperMidEq{};
    std::array<Biquad, kUpperCount> upperHighEq{};
    DelayFx delay{};
    ChorusFx chorus{};
    ReverbFx reverb{};

    void reset(double sr) noexcept {
        sampleRate = sr;
        voiceAge = 0U;
        peakL = peakR = limiterGrDb = 0.0F;
        upperPeakL.fill(0.0F);
        upperPeakR.fill(0.0F);
        for (auto& c : channels) c = ChannelState{};
        for (auto& v : voices) v = Voice{};
        lowEq.reset(); midEq.reset(); highEq.reset();
        for (auto& q : upperLowEq) q.reset();
        for (auto& q : upperMidEq) q.reset();
        for (auto& q : upperHighEq) q.reset();
        delay.reset(sr); chorus.reset(sr); reverb.reset(sr);
    }
};

SamplerEngine::SamplerEngine()
    : impl_(std::make_unique<Impl>()), state_(std::make_shared<EngineState>()), interpolator_(InterpolationQuality::High16) {
    prepare(48000.0, 512U);
}
SamplerEngine::~SamplerEngine() = default;

void SamplerEngine::prepare(double sampleRate, std::uint32_t maximumBlockFrames) {
    const double sr = std::clamp(sampleRate, 8000.0, 384000.0);
    impl_->maxBlock = std::max<std::uint32_t>(16U, maximumBlockFrames);
    impl_->reset(sr);
}

void SamplerEngine::reset() noexcept {
    impl_->reset(impl_->sampleRate);
    events_.clear();
}

void SamplerEngine::setState(std::shared_ptr<const EngineState> state) noexcept {
    if (state == nullptr) return;
    // Voices keep raw pointers into the immutable state graph. State replacement
    // is therefore a hard graph boundary: caller stops audio, and we clear all
    // voice/DSP state before releasing the old graph so no dangling pointer can
    // survive a PROGRAM/COMBI/SET switch.
    impl_->reset(impl_->sampleRate);
    events_.clear();
    state_ = std::move(state);
    // Updating EQ coefficients here is safe because caller must stop audio first.
    const auto& g = state_->global;
    impl_->lowEq.setShelf(impl_->sampleRate, 120.0F, g.eqLowDb, false);
    impl_->midEq.setPeaking(impl_->sampleRate, 1200.0F, 0.75F, g.eqMidDb);
    impl_->highEq.setShelf(impl_->sampleRate, 7000.0F, g.eqHighDb, true);
    for (int i = 0; i < kUpperCount; ++i) {
        const auto& u = state_->combi.uppers[static_cast<std::size_t>(i)];
        impl_->upperLowEq[static_cast<std::size_t>(i)].setShelf(impl_->sampleRate, 120.0F, u.eqLowDb, false);
        impl_->upperMidEq[static_cast<std::size_t>(i)].setPeaking(impl_->sampleRate, 1200.0F, 0.75F, u.eqMidDb);
        impl_->upperHighEq[static_cast<std::size_t>(i)].setShelf(impl_->sampleRate, 7000.0F, u.eqHighDb, true);
    }
}

bool SamplerEngine::postNoteOn(std::uint8_t ch, std::uint8_t key, std::uint8_t vel) noexcept {
    return events_.push({EventType::NoteOn, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(key & 0x7FU), static_cast<std::uint8_t>(vel & 0x7FU), 0});
}
bool SamplerEngine::postNoteOff(std::uint8_t ch, std::uint8_t key, std::uint8_t vel) noexcept {
    return events_.push({EventType::NoteOff, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(key & 0x7FU), static_cast<std::uint8_t>(vel & 0x7FU), 0});
}
bool SamplerEngine::postControlChange(std::uint8_t ch, std::uint8_t cc, std::uint8_t value) noexcept {
    return events_.push({EventType::ControlChange, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(cc & 0x7FU), static_cast<std::uint8_t>(value & 0x7FU), 0});
}
bool SamplerEngine::postPitchBend(std::uint8_t ch, std::int16_t value) noexcept {
    RealtimeEvent e{}; e.type = EventType::PitchBend; e.channel = static_cast<std::uint8_t>(ch & 0x0FU); e.pitchBend = static_cast<std::int16_t>(std::clamp<int>(value, -8192, 8191));
    return events_.push(e);
}
bool SamplerEngine::postChannelPressure(std::uint8_t ch, std::uint8_t value) noexcept {
    return events_.push({EventType::ChannelPressure, static_cast<std::uint8_t>(ch & 0x0FU), static_cast<std::uint8_t>(value & 0x7FU), 0U, 0});
}
bool SamplerEngine::postPanic() noexcept { return events_.push({EventType::Panic,0U,0U,0U,0}); }

namespace {

SamplerEngine::Impl::Voice* chooseVoice(SamplerEngine::Impl& impl) noexcept {
    for (auto& v : impl.voices) if (!v.active) return &v;
    auto* oldest = &impl.voices.front();
    for (auto& v : impl.voices) if (v.age < oldest->age) oldest = &v;
    return oldest;
}

void startVoice(SamplerEngine::Impl& impl,
                SamplerEngine::Impl::Voice& v,
                const UpperPart& upper,
                const ProgramLayer& layer,
                const SampleZone& zone,
                int upperIndex,
                std::uint8_t channel,
                std::uint8_t key,
                std::uint8_t velocity,
                const GlobalState& global) noexcept {
    v = SamplerEngine::Impl::Voice{};
    v.active = true;
    v.keyHeld = true;
    v.sustained = false;
    v.age = ++impl.voiceAge;
    v.channel = channel;
    v.key = key;
    v.velocity = velocity;
    v.upperIndex = upperIndex;
    v.sample = zone.sample;
    v.layer = &layer;
    v.zone = &zone;
    v.upper = &upper;
    v.position = zone.reverse && zone.sample != nullptr ? static_cast<double>(zone.sample->frameCount() - 1U) : 0.0;

    const int keyTracking = zone.nonTranspose ? 0 : (static_cast<int>(key) - static_cast<int>(zone.rootKey));
    const int semitones = keyTracking +
                          static_cast<int>(zone.transposeSemitones) + static_cast<int>(layer.transposeSemitones) +
                          static_cast<int>(upper.transposeSemitones) + static_cast<int>(upper.octave) * 12 +
                          static_cast<int>(global.transposeSemitones);
    const int root = static_cast<int>(global.scaleRoot % 12U);
    const int pc = (static_cast<int>(key) - root + 120) % 12;
    const float scaleCents = std::clamp(global.scaleOffsetsCents[static_cast<std::size_t>(pc)], -100.0F, 100.0F);
    const float cents = zone.tuneCents + layer.tuneCents + upper.tuneCents + zone.sample->fineTuneCents + scaleCents;
    const double tuneHz = std::clamp(static_cast<double>(global.masterTuneHz), 400.0, 480.0);
    const double masterTuneSemis = 12.0 * std::log2(tuneHz / 440.0);
    const double pitch = static_cast<double>(semitones) + static_cast<double>(cents) / 100.0 + masterTuneSemis;
    v.ratio = (static_cast<double>(zone.sample->sampleRate) / impl.sampleRate) * std::pow(2.0, pitch / 12.0);
    v.targetRatio = v.ratio;

    const float velocityNorm = std::max(0.0F, static_cast<float>(velocity) * kInv127);
    float velGain = velocityNorm;
    switch (global.velocityCurve) {
        case 1U: velGain = std::sqrt(velocityNorm); break;
        case 2U: velGain = velocityNorm * velocityNorm; break;
        case 3U: velGain = 1.0F; break;
        default: break;
    }
    float layerVelocityGain = 1.0F;
    if (layer.velocityFadeIn > 0U) {
        const int fadeEnd = static_cast<int>(layer.velocityLow) + static_cast<int>(layer.velocityFadeIn);
        if (static_cast<int>(velocity) < fadeEnd) {
            layerVelocityGain *= std::clamp(
                static_cast<float>(static_cast<int>(velocity) - static_cast<int>(layer.velocityLow)) / static_cast<float>(layer.velocityFadeIn),
                0.0F, 1.0F);
        }
    }
    if (layer.velocityFadeOut > 0U) {
        const int fadeStart = static_cast<int>(layer.velocityHigh) - static_cast<int>(layer.velocityFadeOut);
        if (static_cast<int>(velocity) > fadeStart) {
            layerVelocityGain *= std::clamp(
                static_cast<float>(static_cast<int>(layer.velocityHigh) - static_cast<int>(velocity)) / static_cast<float>(layer.velocityFadeOut),
                0.0F, 1.0F);
        }
    }
    v.baseGain = dbToGain(zone.gainDb + layer.levelDb + upper.levelDb) * velGain * layerVelocityGain;
    const float pan = std::clamp(zone.pan + layer.pan + upper.pan, -1.0F, 1.0F);
    v.basePan = pan;
    const float angle = (pan + 1.0F) * static_cast<float>(kPi * 0.25);
    v.leftGain = std::cos(angle);
    v.rightGain = std::sin(angle);
    v.ampEnv.params = layer.ampEnvelope;
    v.ampEnv.params.attackSec = std::max(0.0F, v.ampEnv.params.attackSec * std::clamp(upper.ampAttackScale, 0.0F, 16.0F));
    v.ampEnv.params.decaySec = std::max(0.0F, v.ampEnv.params.decaySec * std::clamp(upper.ampDecayScale, 0.0F, 16.0F));
    v.ampEnv.params.releaseSec = std::max(0.0F, v.ampEnv.params.releaseSec * std::clamp(upper.ampReleaseScale, 0.0F, 16.0F));
    v.ampEnv.params.sustain = std::clamp(v.ampEnv.params.sustain * std::clamp(upper.ampSustainScale, 0.0F, 2.0F), 0.0F, 1.0F);
    v.filterEnv.params = layer.filterEnvelope;
    v.pitchEnv.params = layer.pitchEnvelope;
    v.ampEnv.trigger(); v.filterEnv.trigger(); v.pitchEnv.trigger();
    v.lfo1.reset(layer.lfo1.keySync); v.lfo2.reset(layer.lfo2.keySync);
    v.delayFramesRemaining = static_cast<std::uint32_t>(std::clamp(
        static_cast<double>(layer.delaySec) * impl.sampleRate, 0.0, static_cast<double>(std::numeric_limits<std::uint32_t>::max())));
    v.filter.reset();
}

float calibratedController(std::uint8_t value, float minValue, float maxValue, float curve) noexcept {
    const float x = static_cast<float>(value) * kInv127;
    const float lo = std::clamp(minValue, 0.0F, 1.0F);
    const float hi = std::clamp(maxValue, lo + 0.0001F, 1.0F);
    const float normalized = std::clamp((x - lo) / (hi - lo), 0.0F, 1.0F);
    return std::pow(normalized, std::clamp(curve, 0.1F, 8.0F));
}

float routeSourceValue(const UpperControllerRoute& route, const SamplerEngine::Impl::ChannelState& ch) noexcept {
    float value = 0.0F;
    bool inherentlyBipolar = false;
    switch (route.source) {
        case ControllerSource::Off: return 0.0F;
        case ControllerSource::Breath: value = ch.breath; break;
        case ControllerSource::Expression: value = ch.expression; break;
        case ControllerSource::Aftertouch: value = ch.pressure; break;
        case ControllerSource::JoystickX:
            value = std::clamp(static_cast<float>(ch.pitchBend) / 8192.0F, -1.0F, 1.0F);
            inherentlyBipolar = true;
            break;
        case ControllerSource::JoystickY:
        case ControllerSource::ControlChange:
            value = ch.cc[static_cast<std::size_t>(route.cc & 0x7FU)];
            break;
    }
    if (route.bipolar && !inherentlyBipolar) value = value * 2.0F - 1.0F;
    return std::clamp(value, -1.0F, 1.0F);
}

float controllerAmount(const UpperPart& upper, const SamplerEngine::Impl::ChannelState& ch,
                       ModDestination destination) noexcept {
    float sum = 0.0F;
    for (const auto& route : upper.controllerRoutes) {
        if (route.source == ControllerSource::Off || route.destination != destination || !std::isfinite(route.amount)) continue;
        sum += routeSourceValue(route, ch) * route.amount;
    }
    return sum;
}

void releaseMatching(SamplerEngine::Impl& impl, std::uint8_t channel, std::uint8_t key) noexcept {
    const bool sustain = impl.channels[channel].sustain;
    for (auto& v : impl.voices) {
        if (!v.active || v.channel != channel || v.key != key) continue;
        v.keyHeld = false;
        if (v.zone != nullptr && v.zone->oneShot) continue;
        if (sustain && v.upper != nullptr && v.upper->damperEnabled && v.layer != nullptr && v.layer->damperEnabled) {
            v.sustained = true;
        } else {
            v.ampEnv.release(impl.sampleRate);
            v.filterEnv.release(impl.sampleRate);
            v.pitchEnv.release(impl.sampleRate);
        }
    }
}

void releaseSustained(SamplerEngine::Impl& impl, std::uint8_t channel) noexcept {
    for (auto& v : impl.voices) {
        if (v.active && v.channel == channel && v.sustained && !v.keyHeld) {
            v.sustained = false;
            v.ampEnv.release(impl.sampleRate);
            v.filterEnv.release(impl.sampleRate);
            v.pitchEnv.release(impl.sampleRate);
        }
    }
}

void panic(SamplerEngine::Impl& impl) noexcept {
    for (auto& v : impl.voices) {
        v.ampEnv.forceOff(); v.filterEnv.forceOff(); v.pitchEnv.forceOff(); v.active = false;
    }
    for (auto& c : impl.channels) c = SamplerEngine::Impl::ChannelState{};
}

void processEvent(SamplerEngine::Impl& impl, const EngineState& state, const RealtimeEvent& e) noexcept {
    const std::uint8_t channel = static_cast<std::uint8_t>(e.channel & 0x0FU);
    if (e.type != EventType::Panic && (state.global.midiInputChannelMask & (1U << channel)) == 0U) return;
    auto& ch = impl.channels[channel];
    switch (e.type) {
        case EventType::NoteOn: {
            if (state.global.filterNotes) break;
            if (e.data2 == 0U) { releaseMatching(impl, e.channel, e.data1); break; }
            const bool anySolo = std::any_of(state.combi.uppers.begin(), state.combi.uppers.end(), [](const UpperPart& u) { return u.enabled && u.solo; });
            for (int ui = 0; ui < kUpperCount; ++ui) {
                const auto& upper = state.combi.uppers[static_cast<std::size_t>(ui)];
                if (upper.midiChannel != (e.channel & 0x0FU)) continue;
                if (anySolo && !upper.solo) continue;
                if (!upper.matches(e.data1, e.data2)) continue;
                const auto& program = *upper.program;
                bool hadMonoVoice = false;
                double previousRatio = 1.0;
                float previousAmp = 0.0F;
                const bool upperMono = upper.voiceMode != UpperVoiceMode::Poly;
                const bool upperLegato = upper.voiceMode == UpperVoiceMode::Legato;
                if (upperMono) {
                    for (auto& existing : impl.voices) {
                        if (existing.active && existing.upperIndex == ui) {
                            hadMonoVoice = true;
                            previousRatio = existing.ratio;
                            previousAmp = std::max(previousAmp, existing.ampEnv.value);
                            existing.active = false;
                        }
                    }
                }
                for (const auto& layer : program.layers) {
                    if (!layer.matches(e.data1, e.data2)) continue;
                    for (const auto& zone : layer.multisample->zones) {
                        if (!zone.matches(e.data1, e.data2) || !zone.sample->valid()) continue;
                        auto* v = chooseVoice(impl);
                        startVoice(impl, *v, upper, layer, zone, ui, e.channel, e.data1, e.data2, state.global);
                        const float portamentoSec = std::max(0.0F, upper.portamentoSec);
                        if (upperMono && hadMonoVoice && portamentoSec > 0.0F && previousRatio > 0.0) {
                            v->targetRatio = v->ratio;
                            v->ratio = previousRatio;
                            const auto glideFrames = static_cast<std::uint32_t>(std::max(1.0, static_cast<double>(portamentoSec) * impl.sampleRate));
                            v->glideFramesRemaining = glideFrames;
                            v->glideLogStep = std::log(v->targetRatio / v->ratio) / static_cast<double>(glideFrames);
                        }
                        if (upperLegato && hadMonoVoice) {
                            v->ampEnv.value = previousAmp;
                            v->ampEnv.stage = Envelope::Stage::Decay;
                        }
                    }
                }
            }
            break;
        }
        case EventType::NoteOff:
            if (!state.global.filterNotes) releaseMatching(impl, e.channel, e.data1);
            break;
        case EventType::ControlChange:
            // Safety CCs remain active even when ordinary CCs are filtered.
            if (e.data1 == 120U || e.data1 == 123U) {
                for (auto& v : impl.voices) if (v.active && v.channel == e.channel) { v.ampEnv.forceOff(); v.active = false; }
                break;
            }
            if (state.global.filterControlChange) break;
            ch.cc[static_cast<std::size_t>(e.data1 & 0x7FU)] = static_cast<float>(e.data2) * kInv127;
            if (e.data1 == state.global.breathCc) {
                ch.breath = calibratedController(e.data2, state.global.breathMin, state.global.breathMax, state.global.breathCurve);
            }
            else if (e.data1 == state.global.expressionCc) {
                ch.expression = calibratedController(e.data2, state.global.expressionMin, state.global.expressionMax, state.global.expressionCurve);
            }
            else if (e.data1 == state.global.damperCc) {
                const bool old = ch.sustain;
                const bool pressed = e.data2 >= 64U;
                ch.sustain = state.global.damperPolarityReversed ? !pressed : pressed;
                if (old && !ch.sustain) releaseSustained(impl, e.channel);
            }
            break;
        case EventType::PitchBend:
            if (!state.global.filterPitchBend && state.global.pitchBendEnabled) ch.pitchBend = e.pitchBend;
            break;
        case EventType::ChannelPressure:
            ch.pressure = (!state.global.filterAftertouch && state.global.aftertouchEnabled)
                              ? static_cast<float>(e.data1) * kInv127
                              : 0.0F;
            break;
        case EventType::Panic: panic(impl); break;
    }
}

float sampleWithLoopCrossfade(const SincInterpolator& interp, const SampleData& sample, double position,
                              std::uint16_t channel, double ratio, bool looping) noexcept {
    if (!looping || !sample.loop.enabled || sample.loop.crossfadeFrames == 0U ||
        sample.loop.endFrame <= sample.loop.startFrame) {
        return interp.read(sample, position, channel, ratio, looping);
    }
    const double xfade = static_cast<double>(sample.loop.crossfadeFrames);
    const double startFade = static_cast<double>(sample.loop.endFrame) - xfade;
    if (position < startFade || position >= static_cast<double>(sample.loop.endFrame)) {
        return interp.read(sample, position, channel, ratio, looping);
    }
    const double t = std::clamp((position - startFade) / xfade, 0.0, 1.0);
    const double headPos = static_cast<double>(sample.loop.startFrame) + (position - startFade);
    const float tail = interp.read(sample, position, channel, ratio, false);
    const float head = interp.read(sample, headPos, channel, ratio, true);
    const float a = static_cast<float>(std::cos(t * kPi * 0.5));
    const float b = static_cast<float>(std::sin(t * kPi * 0.5));
    return tail * a + head * b;
}

} // namespace

void SamplerEngine::render(float* out, std::uint32_t frames) noexcept {
    if (out == nullptr || frames == 0U) return;
    std::memset(out, 0, static_cast<std::size_t>(frames) * 2U * sizeof(float));
    const auto current = state_;
    if (current == nullptr) return;

    RealtimeEvent ev{};
    while (events_.pop(ev)) processEvent(*impl_, *current, ev);

    float peakL = 0.0F, peakR = 0.0F;
    float maxGr = 0.0F;
    std::array<float, kUpperCount> upperPeakL{};
    std::array<float, kUpperCount> upperPeakR{};
    const float masterGain = dbToGain(current->global.masterGainDb);
    const float limiterCeiling = dbToGain(current->global.limiterCeilingDb);

    for (std::uint32_t i = 0U; i < frames; ++i) {
        std::array<float, kUpperCount> upperL{};
        std::array<float, kUpperCount> upperR{};

        for (auto& v : impl_->voices) {
            if (!v.active || v.sample == nullptr || v.layer == nullptr || v.zone == nullptr || v.upper == nullptr) continue;
            if (v.delayFramesRemaining > 0U) {
                --v.delayFramesRemaining;
                continue;
            }
            const auto& sample = *v.sample;
            const bool looping = sample.loop.enabled && !v.zone->oneShot && !v.zone->reverse;

            const auto& ch = impl_->channels[v.channel & 0x0FU];
            LfoParams lfo1Params = v.layer->lfo1;
            LfoParams lfo2Params = v.layer->lfo2;
            const float lfoRateScale = std::clamp(v.upper->lfoRateScale, 0.0F, 16.0F);
            const float controllerLfoDepth = controllerAmount(*v.upper, ch, ModDestination::LfoDepth);
            const float lfoDepthScale = std::clamp(v.upper->lfoDepthScale * std::max(0.0F, 1.0F + controllerLfoDepth), 0.0F, 8.0F);
            lfo1Params.frequencyHz *= lfoRateScale;
            lfo2Params.frequencyHz *= lfoRateScale;
            lfo1Params.pitchCents *= lfoDepthScale;
            lfo2Params.pitchCents *= lfoDepthScale;
            lfo1Params.filterOctaves *= lfoDepthScale;
            lfo2Params.filterOctaves *= lfoDepthScale;
            lfo1Params.ampDepth *= lfoDepthScale;
            lfo2Params.ampDepth *= lfoDepthScale;
            const float lfo1 = v.lfo1.process(lfo1Params, impl_->sampleRate);
            const float lfo2 = v.lfo2.process(lfo2Params, impl_->sampleRate);
            const float pitchEnv = v.pitchEnv.process(impl_->sampleRate);
            const float ampEnv = v.ampEnv.process(impl_->sampleRate);
            const float filterEnv = v.filterEnv.process(impl_->sampleRate);
            if (!v.ampEnv.active()) { v.active = false; continue; }

            const float bendNorm = static_cast<float>(ch.pitchBend) / 8192.0F;
            const float bendSemis = bendNorm * static_cast<float>(v.upper->pitchBendRange);
            const float pressurePitch = v.upper->aftertouchEnabled ? ch.pressure * 0.0F : 0.0F;
            const float controllerPitchSemis = controllerAmount(*v.upper, ch, ModDestination::PitchSemitones);
            const float lfoPitchCents = lfo1 * lfo1Params.pitchCents + lfo2 * lfo2Params.pitchCents;
            const float envPitchCents = pitchEnv * v.layer->pitchEnvelopeCents;
            if (v.glideFramesRemaining > 0U) {
                v.ratio *= std::exp(v.glideLogStep);
                --v.glideFramesRemaining;
                if (v.glideFramesRemaining == 0U) v.ratio = v.targetRatio;
            }
            const double dynamicPitch = static_cast<double>(bendSemis + pressurePitch + controllerPitchSemis) + static_cast<double>(lfoPitchCents + envPitchCents) / 100.0;
            const double ratio = v.ratio * std::pow(2.0, dynamicPitch / 12.0);

            float sL = sampleWithLoopCrossfade(interpolator_, sample, v.position, 0U, ratio, looping);
            float sR = sample.channels > 1U
                ? sampleWithLoopCrossfade(interpolator_, sample, v.position, 1U, ratio, looping)
                : sL;

            const float controllerCutoff = controllerAmount(*v.upper, ch, ModDestination::FilterCutoffOctaves);
            float cutoff = v.layer->filter.cutoffHz * std::pow(2.0F, std::clamp(v.upper->filterCutoffOctaves + controllerCutoff, -10.0F, 10.0F));
            const float keyDelta = (static_cast<float>(v.key) - 60.0F) / 12.0F;
            const float velocityNorm = static_cast<float>(v.velocity) * kInv127;
            const float filterOct = keyDelta * v.layer->filter.keyTrack +
                                    velocityNorm * v.layer->filter.velocityAmount +
                                    filterEnv * v.layer->filter.envelopeAmount +
                                    lfo1 * v.layer->filter.lfoAmount +
                                    lfo1 * lfo1Params.filterOctaves +
                                    lfo2 * lfo2Params.filterOctaves;
            cutoff *= std::pow(2.0F, filterOct);
            const float controllerResonance = controllerAmount(*v.upper, ch, ModDestination::FilterResonance);
            const float resonance = std::clamp(v.layer->filter.resonance + v.upper->filterResonanceOffset + controllerResonance, 0.0F, 1.0F);
            v.filter.process(sL, sR, v.layer->filter.mode, cutoff, resonance, impl_->sampleRate);

            float modGain = ampEnv;
            modGain *= std::max(0.0F, 1.0F + lfo1 * lfo1Params.ampDepth + lfo2 * lfo2Params.ampDepth);
            if (v.upper->expressionEnabled) modGain *= ch.expression;
            if (v.upper->breathEnabled) modGain *= ch.breath;
            if (v.upper->aftertouchEnabled) modGain *= (0.5F + 0.5F * ch.pressure);
            const float controllerLevelDb = controllerAmount(*v.upper, ch, ModDestination::LevelDb);
            const float controllerPan = controllerAmount(*v.upper, ch, ModDestination::Pan);
            const float dynamicPan = std::clamp(v.basePan + controllerPan, -1.0F, 1.0F);
            const float panAngle = (dynamicPan + 1.0F) * static_cast<float>(kPi * 0.25);
            const float panLeft = std::cos(panAngle);
            const float panRight = std::sin(panAngle);
            const float g = v.baseGain * modGain * dbToGain(std::clamp(controllerLevelDb, -96.0F, 24.0F));
            const float oL = sL * g * panLeft;
            const float oR = sR * g * panRight;
            const auto ui = static_cast<std::size_t>(std::clamp(v.upperIndex, 0, kUpperCount - 1));
            upperL[ui] += oL;
            upperR[ui] += oR;

            if (v.zone->reverse) v.position -= ratio; else v.position += ratio;
            if (!v.zone->reverse && looping && v.position >= static_cast<double>(sample.loop.endFrame)) {
                const double len = static_cast<double>(sample.loop.endFrame - sample.loop.startFrame);
                if (len > 0.0) v.position = static_cast<double>(sample.loop.startFrame) + std::fmod(v.position - static_cast<double>(sample.loop.startFrame), len);
            }
            if (v.zone->reverse && v.position < 0.0) { v.ampEnv.forceOff(); v.active = false; }
            else if (!looping && v.position >= static_cast<double>(sample.frameCount())) { v.ampEnv.forceOff(); v.active = false; }
        }

        float dryL = 0.0F, dryR = 0.0F;
        float send1L = 0.0F, send1R = 0.0F, send2L = 0.0F, send2R = 0.0F;
        for (int ui = 0; ui < kUpperCount; ++ui) {
            const auto index = static_cast<std::size_t>(ui);
            float l = upperL[index];
            float r = upperR[index];
            impl_->upperLowEq[index].process(l, r);
            impl_->upperMidEq[index].process(l, r);
            impl_->upperHighEq[index].process(l, r);
            upperPeakL[index] = std::max(upperPeakL[index], std::abs(l));
            upperPeakR[index] = std::max(upperPeakR[index], std::abs(r));
            dryL += l;
            dryR += r;
            const auto& u = current->combi.uppers[index];
            const auto& upperChannel = impl_->channels[static_cast<std::size_t>(u.midiChannel & 0x0FU)];
            const float s1 = std::clamp(u.fxSend1 + controllerAmount(u, upperChannel, ModDestination::FxSend1), 0.0F, 1.0F);
            const float s2 = std::clamp(u.fxSend2 + controllerAmount(u, upperChannel, ModDestination::FxSend2), 0.0F, 1.0F);
            send1L += l * s1; send1R += r * s1;
            send2L += l * s2; send2R += r * s2;
        }

        float fx1L = 0.0F, fx1R = 0.0F, fx2L = 0.0F, fx2R = 0.0F;
        const auto processFx = [&](const EffectSlot& fx, float inL, float inR, float& wetL, float& wetR) noexcept {
            switch (fx.type) {
                case EffectType::Off: wetL = wetR = 0.0F; break;
                case EffectType::Delay: impl_->delay.process(inL, inR, fx, wetL, wetR); break;
                case EffectType::Chorus: impl_->chorus.process(inL, inR, fx, wetL, wetR); break;
                case EffectType::Reverb: impl_->reverb.process(inL, inR, fx, wetL, wetR); break;
            }
        };
        processFx(current->combi.fx1, send1L, send1R, fx1L, fx1R);
        if (current->combi.fxRouting == EffectRouting::Fx1IntoFx2) {
            const float chainGain = clamp01(current->combi.fx1.wet);
            processFx(current->combi.fx2, send2L + fx1L * chainGain, send2R + fx1R * chainGain, fx2L, fx2R);
        } else {
            processFx(current->combi.fx2, send2L, send2R, fx2L, fx2R);
        }
        float l = dryL + fx1L * clamp01(current->combi.fx1.wet) + fx2L * clamp01(current->combi.fx2.wet);
        float r = dryR + fx1R * clamp01(current->combi.fx1.wet) + fx2R * clamp01(current->combi.fx2.wet);

        impl_->lowEq.process(l, r); impl_->midEq.process(l, r); impl_->highEq.process(l, r);
        l *= masterGain; r *= masterGain;

        if (current->global.limiterEnabled) {
            const float absPeak = std::max(std::abs(l), std::abs(r));
            if (absPeak > limiterCeiling && absPeak > 0.0F) {
                const float gain = limiterCeiling / absPeak;
                maxGr = std::max(maxGr, -gainToDb(gain));
                l *= gain; r *= gain;
            }
        }
        if (!std::isfinite(l)) l = 0.0F;
        if (!std::isfinite(r)) r = 0.0F;
        out[static_cast<std::size_t>(i) * 2U] = l;
        out[static_cast<std::size_t>(i) * 2U + 1U] = r;
        peakL = std::max(peakL, std::abs(l));
        peakR = std::max(peakR, std::abs(r));
    }

    impl_->peakL = peakL;
    impl_->peakR = peakR;
    impl_->limiterGrDb = maxGr;
    impl_->upperPeakL = upperPeakL;
    impl_->upperPeakR = upperPeakR;
}

MeterSnapshot SamplerEngine::meters() const noexcept {
    MeterSnapshot out{};
    out.peakLeft = impl_->peakL;
    out.peakRight = impl_->peakR;
    out.limiterGainReductionDb = impl_->limiterGrDb;
    out.activeVoices = activeVoiceCount();
    out.droppedEvents = events_.droppedCount();
    out.upperPeakLeft = impl_->upperPeakL;
    out.upperPeakRight = impl_->upperPeakR;
    return out;
}

std::uint32_t SamplerEngine::activeVoiceCount() const noexcept {
    std::uint32_t count = 0U;
    for (const auto& v : impl_->voices) if (v.active) ++count;
    return count;
}

} // namespace silveton::sampler
