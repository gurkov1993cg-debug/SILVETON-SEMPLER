#include "silveton/sampler/SincInterpolator.h"
#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler {
namespace {
constexpr double kPi = 3.14159265358979323846264338327950288;
}

SincInterpolator::SincInterpolator(InterpolationQuality quality) noexcept : quality_(quality) {}

double SincInterpolator::sinc(double x) noexcept {
    if (std::abs(x) < 1.0e-12) return 1.0;
    const double px = kPi * x;
    return std::sin(px) / px;
}

double SincInterpolator::blackman(double normalized) noexcept {
    const double x = std::clamp(normalized, -1.0, 1.0);
    // Symmetric Blackman window over -1..+1.
    return 0.42 + 0.5 * std::cos(kPi * x) + 0.08 * std::cos(2.0 * kPi * x);
}

float SincInterpolator::readFrame(const SampleData& sample,
                                  long long frame,
                                  std::uint16_t channel,
                                  bool looping) const noexcept {
    const long long frames = static_cast<long long>(sample.frameCount());
    if (frames <= 0) return 0.0F;

    long long resolved = frame;
    if (looping && sample.loop.enabled && sample.loop.endFrame > sample.loop.startFrame) {
        const long long loopStart = static_cast<long long>(sample.loop.startFrame);
        const long long loopEnd = static_cast<long long>(sample.loop.endFrame);
        const long long loopLength = loopEnd - loopStart;
        if (resolved >= loopEnd && loopLength > 0) {
            resolved = loopStart + ((resolved - loopStart) % loopLength);
        }
        if (resolved < loopStart && frame >= 0) {
            resolved = loopStart;
        }
    }

    if (resolved < 0 || resolved >= frames) return 0.0F;
    const std::uint16_t actualChannel = std::min<std::uint16_t>(channel, static_cast<std::uint16_t>(sample.channels - 1U));
    const std::uint64_t resolvedFrame = static_cast<std::uint64_t>(resolved);
    if (resolvedFrame < sample.preloadedFrameCount()) {
        const std::size_t index = static_cast<std::size_t>(resolvedFrame) * static_cast<std::size_t>(sample.channels) + actualChannel;
        return sample.interleaved[index];
    }
    if (sample.stream != nullptr) return sample.stream->readFrame(resolvedFrame, actualChannel);
    return 0.0F;
}

float SincInterpolator::read(const SampleData& sample,
                             double position,
                             std::uint16_t channel,
                             double playbackRatio,
                             bool looping) const noexcept {
    if (!sample.valid()) return 0.0F;

    const int taps = static_cast<int>(quality_);
    const int half = taps / 2;
    const long long center = static_cast<long long>(std::floor(position));
    const double frac = position - static_cast<double>(center);

    // When reading faster than one source frame per output frame, the effective
    // interpolation kernel also acts as the reconstruction low-pass. Shrinking
    // the cutoff below Nyquist suppresses the aliases that otherwise appear on
    // large upward transpositions.
    const double ratio = std::max(1.0e-9, std::abs(playbackRatio));
    const double cutoff = std::min(1.0, 1.0 / ratio);

    double weighted = 0.0;
    double weightSum = 0.0;
    for (int i = -half + 1; i <= half; ++i) {
        const double distance = static_cast<double>(i) - frac;
        const double normalized = distance / static_cast<double>(half);
        const double window = blackman(normalized);
        const double weight = cutoff * sinc(distance * cutoff) * window;
        const float sampleValue = readFrame(sample, center + static_cast<long long>(i), channel, looping);
        weighted += static_cast<double>(sampleValue) * weight;
        weightSum += weight;
    }

    if (std::abs(weightSum) < 1.0e-12) return 0.0F;
    return static_cast<float>(weighted / weightSum);
}

} // namespace silveton::sampler
