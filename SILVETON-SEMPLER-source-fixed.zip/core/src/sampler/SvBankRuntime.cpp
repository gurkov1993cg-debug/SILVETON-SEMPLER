#include "silveton/sampler/SvBankRuntime.h"

#include "silveton/sampler/SampleStream.h"
#include "silveton/sampler/SvBankFormat.h"

#include <algorithm>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <memory>
#include <set>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace silveton::sampler {
namespace {

class SharedMappedBank {
public:
    static std::shared_ptr<SharedMappedBank> open(const std::string& path, std::string& error) {
        const int fd = ::open(path.c_str(), O_RDONLY);
        if (fd < 0) {
            error = "Cannot open SILVETON bank: " + path;
            return nullptr;
        }
        struct stat st {};
        if (fstat(fd, &st) != 0 || st.st_size < 0) {
            ::close(fd);
            error = "Cannot determine SILVETON bank size";
            return nullptr;
        }
        const auto size = static_cast<std::uint64_t>(st.st_size);
        if (size < kSvBankHeaderSize || size > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
            ::close(fd);
            error = "SILVETON bank size is invalid";
            return nullptr;
        }
        void* mapping = mmap(nullptr, static_cast<std::size_t>(size), PROT_READ, MAP_PRIVATE, fd, 0);
        if (mapping == MAP_FAILED) {
            ::close(fd);
            error = "mmap failed for SILVETON bank";
            return nullptr;
        }
#ifdef MADV_RANDOM
        (void)madvise(mapping, static_cast<std::size_t>(size), MADV_RANDOM);
#endif
        auto out = std::shared_ptr<SharedMappedBank>(new SharedMappedBank());
        out->fd_ = fd;
        out->data_ = static_cast<const std::uint8_t*>(mapping);
        out->size_ = size;
        error.clear();
        return out;
    }

    ~SharedMappedBank() {
        if (data_ != nullptr) munmap(const_cast<std::uint8_t*>(data_), static_cast<std::size_t>(size_));
        if (fd_ >= 0) ::close(fd_);
    }

    [[nodiscard]] const std::uint8_t* data() const noexcept { return data_; }
    [[nodiscard]] std::uint64_t size() const noexcept { return size_; }

private:
    SharedMappedBank() = default;
    int fd_{-1};
    const std::uint8_t* data_{nullptr};
    std::uint64_t size_{0U};
};

class BankPcmStream final : public SampleStream {
public:
    BankPcmStream(std::shared_ptr<const SharedMappedBank> bank,
                  std::uint64_t dataOffset,
                  std::uint64_t frames,
                  std::uint32_t sampleRate,
                  std::uint16_t channels,
                  std::uint8_t encoding,
                  std::uint8_t bitsPerSample) noexcept
        : bank_(std::move(bank)), dataOffset_(dataOffset), frames_(frames), sampleRate_(sampleRate),
          channels_(channels), encoding_(encoding), bitsPerSample_(bitsPerSample) {}

    [[nodiscard]] std::uint64_t frameCount() const noexcept override { return frames_; }
    [[nodiscard]] std::uint16_t channels() const noexcept override { return channels_; }
    [[nodiscard]] std::uint32_t sampleRate() const noexcept override { return sampleRate_; }

    [[nodiscard]] float readFrame(std::uint64_t frame, std::uint16_t channel) const noexcept override {
        if (bank_ == nullptr || frame >= frames_ || channels_ == 0U) return 0.0F;
        const std::uint16_t ch = std::min<std::uint16_t>(channel, static_cast<std::uint16_t>(channels_ - 1U));
        const std::uint64_t bytesPerSample = bitsPerSample_ / 8U;
        const std::uint64_t sampleIndex = frame * static_cast<std::uint64_t>(channels_) + ch;
        if (bytesPerSample == 0U || sampleIndex > (std::numeric_limits<std::uint64_t>::max() - dataOffset_) / bytesPerSample) return 0.0F;
        const std::uint64_t offset = dataOffset_ + sampleIndex * bytesPerSample;
        if (offset > bank_->size() || bytesPerSample > bank_->size() - offset) return 0.0F;
        const auto* p = bank_->data() + static_cast<std::size_t>(offset);

        if (encoding_ == 1U && bitsPerSample_ == 16U) {
            const std::uint16_t u = static_cast<std::uint16_t>(p[0]) |
                static_cast<std::uint16_t>(static_cast<std::uint16_t>(p[1]) << 8U);
            return static_cast<float>(static_cast<std::int16_t>(u)) / 32768.0F;
        }
        if (encoding_ == 2U && bitsPerSample_ == 24U) {
            std::int32_t v = static_cast<std::int32_t>(p[0]) |
                (static_cast<std::int32_t>(p[1]) << 8) |
                (static_cast<std::int32_t>(p[2]) << 16);
            if ((v & 0x00800000) != 0) v |= static_cast<std::int32_t>(0xFF000000U);
            return static_cast<float>(v) / 8388608.0F;
        }
        if (encoding_ == 3U && bitsPerSample_ == 32U) {
            const std::uint32_t u = static_cast<std::uint32_t>(p[0]) |
                (static_cast<std::uint32_t>(p[1]) << 8U) |
                (static_cast<std::uint32_t>(p[2]) << 16U) |
                (static_cast<std::uint32_t>(p[3]) << 24U);
            float f = 0.0F;
            std::memcpy(&f, &u, sizeof(f));
            return std::clamp(f, -1.0F, 1.0F);
        }
        return 0.0F;
    }

private:
    std::shared_ptr<const SharedMappedBank> bank_;
    std::uint64_t dataOffset_{0U};
    std::uint64_t frames_{0U};
    std::uint32_t sampleRate_{0U};
    std::uint16_t channels_{0U};
    std::uint8_t encoding_{0U};
    std::uint8_t bitsPerSample_{0U};
};

bool checkedRange(std::uint64_t offset, std::uint64_t size, std::uint64_t total) noexcept {
    return offset <= total && size <= total - offset;
}

bool sectionValid(const SvBankHeader& header, SvSection section) noexcept {
    const auto& d = header.sections[static_cast<std::size_t>(section)];
    return checkedRange(d.offset, d.size, header.fileSize);
}

bool recordSectionSize(const SvBankHeader& header, SvSection section,
                       std::uint32_t count, std::size_t recordSize) noexcept {
    const auto& d = header.sections[static_cast<std::size_t>(section)];
    return d.size == static_cast<std::uint64_t>(count) * static_cast<std::uint64_t>(recordSize);
}

bool readString(const SharedMappedBank& bank, const SvBankHeader& header,
                std::uint32_t offset, std::string& out) {
    const auto& strings = header.sections[static_cast<std::size_t>(SvSection::Strings)];
    if (offset >= strings.size) return false;
    const std::uint64_t begin64 = strings.offset + offset;
    const std::uint64_t end64 = strings.offset + strings.size;
    if (begin64 >= bank.size() || end64 > bank.size()) return false;
    const auto begin = static_cast<std::size_t>(begin64);
    const auto end = static_cast<std::size_t>(end64);
    std::size_t pos = begin;
    while (pos < end && bank.data()[pos] != 0U) ++pos;
    if (pos >= end) return false;
    out.assign(reinterpret_cast<const char*>(bank.data() + begin), pos - begin);
    return true;
}

std::uint64_t bytesPerSample(std::uint8_t encoding, std::uint8_t bits) noexcept {
    if (encoding == 1U && bits == 16U) return 2U;
    if (encoding == 2U && bits == 24U) return 3U;
    if (encoding == 3U && bits == 32U) return 4U;
    return 0U;
}

} // namespace

SvRuntimeLoadResult SvBankRuntime::load(const std::string& path,
                                       std::uint64_t attackPreloadFrames,
                                       bool verifyIntegrity) {
    SvRuntimeLoadResult out{};
    std::string error;
    auto bank = SharedMappedBank::open(path, error);
    if (bank == nullptr) { out.error = std::move(error); return out; }

    SvBankHeader header{};
    if (!deserializeHeader(bank->data(), static_cast<std::size_t>(bank->size()), header, out.error)) return out;
    if (header.fileSize != bank->size()) { out.error = "SV bank file-size mismatch"; return out; }
    for (std::size_t i = 0U; i < kSvSectionCount; ++i) {
        if (!sectionValid(header, static_cast<SvSection>(i))) {
            out.error = "SV bank section is outside file bounds";
            return out;
        }
    }
    if (!recordSectionSize(header, SvSection::Sounds, header.soundCount, kSvSoundRecordSize) ||
        !recordSectionSize(header, SvSection::SoundLayers, header.soundLayerCount, kSvSoundLayerRecordSize) ||
        !recordSectionSize(header, SvSection::Multisamples, header.multisampleCount, kSvMultisampleRecordSize) ||
        !recordSectionSize(header, SvSection::Samples, header.sampleCount, kSvSampleRecordSize) ||
        !recordSectionSize(header, SvSection::Zones, header.zoneCount, kSvZoneRecordSize)) {
        out.error = "SV bank record-section size mismatch";
        return out;
    }
    if (verifyIntegrity) {
        const auto digest = sha256(bank->data() + kSvBankHeaderSize,
                                   static_cast<std::size_t>(bank->size() - kSvBankHeaderSize));
        if (digest != header.payloadSha256) {
            out.error = "SV bank SHA-256 integrity mismatch";
            return out;
        }
    }

    if (!readString(*bank, header, header.bankNameOffset, out.data.name)) {
        out.error = "SV bank name string offset is invalid";
        return out;
    }

    const auto& sampleSec = header.sections[static_cast<std::size_t>(SvSection::Samples)];
    const auto& audioSec = header.sections[static_cast<std::size_t>(SvSection::Audio)];
    std::vector<SamplePtr> samples;
    samples.reserve(header.sampleCount);
    out.data.samples.reserve(header.sampleCount);
    for (std::uint32_t i = 0U; i < header.sampleCount; ++i) {
        SvSampleRecord r{};
        const std::uint64_t recordOffset = sampleSec.offset + static_cast<std::uint64_t>(i) * kSvSampleRecordSize;
        if (!checkedRange(recordOffset, kSvSampleRecordSize, bank->size()) ||
            !readSampleRecord(bank->data() + static_cast<std::size_t>(recordOffset), kSvSampleRecordSize, r)) {
            out.error = "Cannot decode SV sample record";
            return out;
        }
        const std::uint64_t bps = bytesPerSample(r.encoding, r.bitsPerSample);
        if (bps == 0U || r.sampleRate == 0U || r.channels == 0U || r.channels > 2U || r.totalFrames == 0U) {
            out.error = "SV sample encoding or metadata is unsupported";
            return out;
        }
        if (r.totalFrames > std::numeric_limits<std::uint64_t>::max() / static_cast<std::uint64_t>(r.channels) ||
            r.totalFrames * static_cast<std::uint64_t>(r.channels) > std::numeric_limits<std::uint64_t>::max() / bps) {
            out.error = "SV sample byte count overflow";
            return out;
        }
        const std::uint64_t expectedBytes = r.totalFrames * static_cast<std::uint64_t>(r.channels) * bps;
        if (r.audioSize != expectedBytes || !checkedRange(r.audioOffset, r.audioSize, audioSec.size)) {
            out.error = "SV sample audio range is invalid";
            return out;
        }
        if (r.loopEnabled != 0U && (r.loopStart >= r.loopEnd || r.loopEnd > r.totalFrames)) {
            out.error = "SV sample loop range is invalid";
            return out;
        }

        auto sample = std::make_shared<SampleData>();
        if (!readString(*bank, header, r.nameOffset, sample->name) ||
            !readString(*bank, header, r.sourceIdentityOffset, sample->sourceIdentity)) {
            out.error = "SV sample string offset is invalid";
            return out;
        }
        sample->sourcePath = path;
        sample->sampleRate = r.sampleRate;
        sample->channels = r.channels;
        sample->rootKey = r.rootKey;
        sample->fineTuneCents = r.fineTuneCents;
        sample->totalFrames = r.totalFrames;
        sample->loop.enabled = r.loopEnabled != 0U;
        sample->loop.startFrame = r.loopStart;
        sample->loop.endFrame = r.loopEnd;
        sample->loop.crossfadeFrames = r.loopCrossfadeFrames;
        const std::uint64_t absoluteAudioOffset = audioSec.offset + r.audioOffset;
        sample->stream = std::make_shared<BankPcmStream>(bank, absoluteAudioOffset, r.totalFrames,
                                                        r.sampleRate, r.channels, r.encoding, r.bitsPerSample);
        const std::uint64_t preloadFrames = std::min<std::uint64_t>(attackPreloadFrames, r.totalFrames);
        if (preloadFrames > 0U) {
            if (preloadFrames > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()) /
                                    static_cast<std::uint64_t>(r.channels)) {
                out.error = "SV sample preload size is too large";
                return out;
            }
            sample->interleaved.resize(static_cast<std::size_t>(preloadFrames * r.channels));
            for (std::uint64_t frame = 0U; frame < preloadFrames; ++frame) {
                for (std::uint16_t ch = 0U; ch < r.channels; ++ch) {
                    sample->interleaved[static_cast<std::size_t>(frame * r.channels + ch)] =
                        sample->stream->readFrame(frame, ch);
                }
            }
        }
        if (!sample->valid()) { out.error = "SV sample failed semantic validation"; return out; }
        samples.push_back(sample);
        out.data.samples.push_back({i + 1U, sample});
    }

    const auto& zoneSec = header.sections[static_cast<std::size_t>(SvSection::Zones)];
    std::vector<SampleZone> zones;
    zones.reserve(header.zoneCount);
    for (std::uint32_t i = 0U; i < header.zoneCount; ++i) {
        SvZoneRecord r{};
        const std::uint64_t recordOffset = zoneSec.offset + static_cast<std::uint64_t>(i) * kSvZoneRecordSize;
        if (!checkedRange(recordOffset, kSvZoneRecordSize, bank->size()) ||
            !readZoneRecord(bank->data() + static_cast<std::size_t>(recordOffset), kSvZoneRecordSize, r)) {
            out.error = "Cannot decode SV zone record";
            return out;
        }
        if (r.sampleIndex >= samples.size() || r.keyLow > r.keyHigh || r.velocityLow == 0U || r.velocityLow > r.velocityHigh) {
            out.error = "SV zone failed semantic validation";
            return out;
        }
        SampleZone z{};
        z.sample = samples[r.sampleIndex];
        z.keyLow = r.keyLow; z.keyHigh = r.keyHigh;
        z.velocityLow = r.velocityLow; z.velocityHigh = r.velocityHigh;
        z.rootKey = r.rootKey; z.transposeSemitones = r.transposeSemitones;
        z.oneShot = (r.flags & 1U) != 0U; z.reverse = (r.flags & 2U) != 0U; z.nonTranspose = (r.flags & 4U) != 0U;
        z.sourceLevelRaw = r.sourceLevelRaw; z.sourceFilterRaw = r.sourceFilterRaw;
        z.tuneCents = r.tuneCents; z.gainDb = r.gainDb; z.pan = r.pan;
        zones.push_back(std::move(z));
    }

    const auto& msSec = header.sections[static_cast<std::size_t>(SvSection::Multisamples)];
    std::vector<MultisamplePtr> multisamples;
    multisamples.reserve(header.multisampleCount);
    out.data.multisamples.reserve(header.multisampleCount);
    for (std::uint32_t i = 0U; i < header.multisampleCount; ++i) {
        SvMultisampleRecord r{};
        const std::uint64_t recordOffset = msSec.offset + static_cast<std::uint64_t>(i) * kSvMultisampleRecordSize;
        if (!checkedRange(recordOffset, kSvMultisampleRecordSize, bank->size()) ||
            !readMultisampleRecord(bank->data() + static_cast<std::size_t>(recordOffset), kSvMultisampleRecordSize, r)) {
            out.error = "Cannot decode SV multisample record";
            return out;
        }
        if (r.zoneCount == 0U || r.firstZone > zones.size() || r.zoneCount > zones.size() - r.firstZone) {
            out.error = "SV multisample zone range is invalid";
            return out;
        }
        auto ms = std::make_shared<Multisample>();
        if (!readString(*bank, header, r.nameOffset, ms->name) ||
            !readString(*bank, header, r.sourceIdentityOffset, ms->sourceIdentity)) {
            out.error = "SV multisample string offset is invalid";
            return out;
        }
        ms->zones.assign(zones.begin() + static_cast<std::ptrdiff_t>(r.firstZone),
                         zones.begin() + static_cast<std::ptrdiff_t>(r.firstZone + r.zoneCount));
        multisamples.push_back(ms);
        out.data.multisamples.push_back({i + 1U, ms});
    }

    const auto& layerSec = header.sections[static_cast<std::size_t>(SvSection::SoundLayers)];
    std::vector<ProgramLayer> layers;
    layers.reserve(header.soundLayerCount);
    for (std::uint32_t i = 0U; i < header.soundLayerCount; ++i) {
        SvSoundLayerRecord r{};
        const std::uint64_t recordOffset = layerSec.offset + static_cast<std::uint64_t>(i) * kSvSoundLayerRecordSize;
        if (!checkedRange(recordOffset, kSvSoundLayerRecordSize, bank->size()) ||
            !readSoundLayerRecord(bank->data() + static_cast<std::size_t>(recordOffset), kSvSoundLayerRecordSize, r)) {
            out.error = "Cannot decode SV SOUND layer record";
            return out;
        }
        if (r.multisampleIndex >= multisamples.size() || r.keyLow > r.keyHigh ||
            r.velocityLow == 0U || r.velocityLow > r.velocityHigh) {
            out.error = "SV SOUND layer failed semantic validation";
            return out;
        }
        ProgramLayer layer{};
        layer.multisample = multisamples[r.multisampleIndex];
        layer.enabled = r.enabled != 0U;
        layer.keyLow = r.keyLow; layer.keyHigh = r.keyHigh;
        layer.velocityLow = r.velocityLow; layer.velocityHigh = r.velocityHigh;
        layer.transposeSemitones = r.transposeSemitones;
        layer.tuneCents = r.tuneCents; layer.levelDb = r.levelDb; layer.pan = r.pan;
        layers.push_back(std::move(layer));
    }

    const auto& soundSec = header.sections[static_cast<std::size_t>(SvSection::Sounds)];
    out.data.programs.reserve(header.soundCount);
    std::set<std::tuple<std::uint16_t, std::uint16_t, std::uint16_t>> addresses;
    for (std::uint32_t i = 0U; i < header.soundCount; ++i) {
        SvSoundRecord r{};
        const std::uint64_t recordOffset = soundSec.offset + static_cast<std::uint64_t>(i) * kSvSoundRecordSize;
        if (!checkedRange(recordOffset, kSvSoundRecordSize, bank->size()) ||
            !readSoundRecord(bank->data() + static_cast<std::size_t>(recordOffset), kSvSoundRecordSize, r)) {
            out.error = "Cannot decode SV SOUND record";
            return out;
        }
        if (r.layerCount == 0U || r.firstLayer > layers.size() || r.layerCount > layers.size() - r.firstLayer) {
            out.error = "SV SOUND layer range is invalid";
            return out;
        }
        const auto key = std::make_tuple(r.bank, r.page, r.slot);
        if (!addresses.insert(key).second) {
            out.error = "SV bank contains duplicate SOUND slot address";
            return out;
        }
        auto program = std::make_shared<Program>();
        if (!readString(*bank, header, r.nameOffset, program->name)) {
            out.error = "SV SOUND name offset is invalid";
            return out;
        }
        program->layers.assign(layers.begin() + static_cast<std::ptrdiff_t>(r.firstLayer),
                               layers.begin() + static_cast<std::ptrdiff_t>(r.firstLayer + r.layerCount));
        out.data.programs.push_back({SlotAddress{r.bank, r.page, r.slot}, program});
    }

    if (out.data.programs.empty()) {
        out.error = "SV bank contains no playable SOUND records";
        return out;
    }
    out.error.clear();
    return out;
}

} // namespace silveton::sampler
