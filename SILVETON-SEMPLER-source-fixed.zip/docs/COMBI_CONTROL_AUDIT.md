# SILVETON SAMPLER — COMBI visible-control audit

Scope: approved COMBI visual language with the simplified tablet workflow.

## Global tablet navigation
- Gear → SETTINGS page → real GLOBAL state read/write.
- PANIC → nativePanic() → real engine panic.
- LIST → real SetList read/activate path.
- COMBI → real 7-UPPER state editor.
- EFFECTS → real shared COMBI FX1/FX2 editor.

PROGRAM, SAMPLE and MIXER are intentionally not visible tablet top-level menus.

## UPPER row (UPPER 1..7)
- SOUND → native sound catalog → nativeAssignUpperSound()/nativeClearUpperSound().
- ON/OFF → UpperPart.enabled → note routing/DSP gate.
- SOLO → UpperPart.solo → solo selection in note-on dispatch.
- MUTE → UpperPart.mute → UpperPart::matches() DSP gate.
- VOLUME → UpperPart.levelDb → voice base gain.
- PAN → UpperPart.pan → voice stereo pan.
- KEY RANGE → UpperPart.keyLow/keyHigh → note matching.
- MODE → UpperVoiceMode Poly/Mono/Legato → voice allocation/legato logic.
- Meter → real post-UPPER-EQ block peak; never animated decoratively.

## TUNE
- Portamento → UpperPart.portamentoSec → glide duration.
- Octave → UpperPart.octave → pitch ratio.
- Transpose → UpperPart.transposeSemitones → pitch ratio.
- Fine Tune → UpperPart.tuneCents → pitch ratio.
- Pitch Bend Range → UpperPart.pitchBendRange → realtime bend depth.

## RANGE
- Velocity Low/High → UpperPart.velocityLow/velocityHigh → note matching.
- Key Range is shown as read-only context here because it is already edited in the UPPER row; it is not duplicated as a second control.

## CONTROL
- Breath CC2 enable → UpperPart.breathEnabled → realtime gain expression.
- Expression CC11 enable → UpperPart.expressionEnabled → realtime gain expression.
- Aftertouch enable → UpperPart.aftertouchEnabled → realtime pressure shaping.
- Damper CC64 enable → UpperPart.damperEnabled → sustain/release behavior.
- MIDI Channel → UpperPart.midiChannel → per-UPPER input channel routing.

## TONE
All TONE controls are per-UPPER Easy Edit modifiers; the underlying prepared SOUND is not mutated.
- Amp Attack scale → amp envelope attack.
- Amp Decay scale → amp envelope decay.
- Amp Sustain scale → amp envelope sustain.
- Amp Release scale → amp envelope release.
- Filter Cutoff offset → filter cutoff in octaves.
- Filter Resonance offset → realtime filter resonance.
- LFO Rate scale → both layer LFO rates.
- LFO Depth scale → layer LFO pitch/filter/amp depths.
- EQ Low/Mid/High → real per-UPPER biquad EQ.

## FX
- FX1 Send → shared COMBI FX1 bus.
- FX2 Send → shared COMBI FX2 bus.
- Main EFFECTS page: FX1/FX2 type, wet, time, feedback, rate, depth, tone.
- Routing → Parallel or FX1→FX2.

## SETTINGS
Visible SETTINGS fields are wired to GlobalState: master tune, transpose, master gain, master EQ, limiter enable/ceiling, velocity curve, Breath/Expression/Damper CC numbers, global pitch-bend and aftertouch enable.

## Automated checks
- `ci/audit_gui_contract.py` verifies required visible-action handlers and exact Kotlin↔JNI method parity.
- `silveton_sampler_tests::testUpperVisibleControlContract()` verifies audible DSP changes for visible UPPER/TUNE/CONTROL/TONE/FX controls.
- Release core tests: 3/3 PASS.
- ASan+UBSan core tests: 3/3 PASS.

Full Android APK compilation/rendering still requires the Android SDK/NDK toolchain; this local environment does not contain android.jar.
