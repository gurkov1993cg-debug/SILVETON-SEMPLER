# SILVETON SAMPLER GUI BASELINE

Locked references:
- `APPROVED_LIST_UI.png` — LIST screen.
- `APPROVED_COMBI_UI.png` — COMBI screen and visual language.

Global tablet navigation is intentionally reduced to:
- LIST
- COMBI
- EFFECTS
- SETTINGS (gear)

PROGRAM, SAMPLE and MIXER are not tablet top-level menus. Sound preparation and multisample construction belong to SILVETON Manager; COMBI UPPER 1–7 select prepared sounds.

COMBI UPPER row owns the non-duplicated live controls:
- SOUND, ON/OFF, SOLO, MUTE, VOLUME, PAN, KEY RANGE, MODE.

Selected UPPER has only additional tabs:
- TUNE, RANGE, CONTROL, TONE, FX.

A control shown in the application must have a native state/DSP/action path. Decorative/dead controls are forbidden.
