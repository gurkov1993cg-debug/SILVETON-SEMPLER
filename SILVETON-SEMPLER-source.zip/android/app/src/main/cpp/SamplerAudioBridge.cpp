#ifdef __ANDROID__

#include <aaudio/AAudio.h>
#include <jni.h>
#include <android/log.h>
#include <time.h>

#include "silveton/sampler/AudioFileLoader.h"
#include "silveton/sampler/KorgImporter.h"
#include "silveton/sampler/MultisampleEditor.h"
#include "silveton/sampler/SampleEditor.h"
#include "silveton/sampler/ProgramEditor.h"
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SamplerLibrary.h"
#include "silveton/sampler/SetPackage.h"

#include <algorithm>
#include <vector>
#include <array>
#include <atomic>
#include <cstdint>
#include <cmath>
#include <filesystem>
#include <memory>
#include <mutex>
#include <optional>
#include <string>

namespace {
using namespace silveton::sampler;

constexpr const char* kTag = "SilvetonSampler";

std::string jstringToUtf8(JNIEnv* env, jstring s) {
    if (s == nullptr) return {};
    const char* raw = env->GetStringUTFChars(s, nullptr);
    if (raw == nullptr) return {};
    std::string out(raw);
    env->ReleaseStringUTFChars(s, raw);
    return out;
}

class AndroidSamplerAudio {
public:
    AndroidSamplerAudio() = default;
    ~AndroidSamplerAudio() { close(); }

    bool open() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        return openLocked();
    }

    bool start() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(true, std::memory_order_release);
        if (started_.load(std::memory_order_acquire)) return true;
        if (stream_ == nullptr && !openLocked()) return false;
        const aaudio_result_t r = AAudioStream_requestStart(stream_);
        if (r != AAUDIO_OK) {
            lastError_.store(r, std::memory_order_relaxed);
            return false;
        }
        started_.store(true, std::memory_order_release);
        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(false, std::memory_order_release);
        (void)stopLocked();
    }

    void close() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(false, std::memory_order_release);
        (void)stopLocked();
        if (stream_ != nullptr) {
            AAudioStream_close(stream_);
            stream_ = nullptr;
        }
    }

    bool recover() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        if (!recoverRequested_.load(std::memory_order_acquire)) return true;
        if (stream_ != nullptr) {
            (void)AAudioStream_requestStop(stream_);
            AAudioStream_close(stream_);
            stream_ = nullptr;
        }
        started_.store(false, std::memory_order_release);
        if (!openLocked()) return false;
        if (wantStarted_.load(std::memory_order_acquire)) {
            const aaudio_result_t r = AAudioStream_requestStart(stream_);
            if (r != AAUDIO_OK) { lastError_.store(r, std::memory_order_relaxed); return false; }
            started_.store(true, std::memory_order_release);
        }
        recoverRequested_.store(false, std::memory_order_release);
        return true;
    }

    bool loadAudioFile(const std::string& path) {
        // Two seconds at 48 kHz is preloaded for instant attack; the remainder
        // stays mmap-backed. Higher-rate files preload the same frame count,
        // still avoiding full-library RAM residency on the 4 GB target tablet.
        const auto loaded = AudioFileLoader::loadStreaming(path, 96000U);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        return installMultisample(makeSingleSampleMultisample(loaded.sample, loaded.sample->name), loaded.sample->name);
    }

    bool loadKmp(const std::string& path) {
        const auto imported = library_.importKmp(path);
        if (!imported.success || imported.multisampleIds.empty()) {
            setTextError(imported.error.empty() ? "KMP library import returned no multisample" : imported.error);
            return false;
        }
        const auto ms = library_.multisample(imported.multisampleIds.front());
        if (ms == nullptr) { setTextError("Imported KMP multisample is missing from library"); return false; }
        return installMultisample(ms, ms->name);
    }

    std::vector<int> importKmpToLibrary(const std::string& path) {
        const auto imported = library_.importKmp(path);
        if (!imported.success) { setTextError(imported.error); return {}; }
        std::vector<int> ids; ids.reserve(imported.multisampleIds.size());
        for (const auto id : imported.multisampleIds) ids.push_back(static_cast<int>(id));
        setTextError({});
        return ids;
    }

    std::vector<int> importKscToLibrary(const std::string& path) {
        const auto imported = library_.importKsc(path);
        if (!imported.success) { setTextError(imported.error); return {}; }
        std::vector<int> ids; ids.reserve(imported.multisampleIds.size());
        for (const auto id : imported.multisampleIds) ids.push_back(static_cast<int>(id));
        setTextError({});
        return ids;
    }

    std::vector<int> multisampleIds() const {
        const auto raw = library_.multisampleIds();
        std::vector<int> ids; ids.reserve(raw.size());
        for (const auto id : raw) ids.push_back(static_cast<int>(id));
        return ids;
    }

    std::vector<std::string> multisampleNames() const { return library_.multisampleNames(); }

    std::vector<std::string> kscNames(const std::string& path) {
        if (!ensureKscCache(path)) return {};
        std::vector<std::string> names;
        names.reserve(kscCache_.multisamples.size());
        for (const auto& ms : kscCache_.multisamples) names.push_back(ms != nullptr ? ms->name : std::string{});
        return names;
    }

    bool loadKscItem(const std::string& path, int index) {
        if (!ensureKscCache(path)) return false;
        if (index < 0 || static_cast<std::size_t>(index) >= kscCache_.multisamples.size()) {
            setTextError("KSC multisample index is out of range");
            return false;
        }
        const auto& ms = kscCache_.multisamples[static_cast<std::size_t>(index)];
        if (ms == nullptr) { setTextError("KSC multisample is empty"); return false; }
        return installMultisample(ms, ms->name);
    }

    bool loadSet(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        library_.replace(loaded.data);
        auto state = std::make_shared<EngineState>();
        state->global = loaded.data.global;
        if (!loaded.data.combis.empty()) {
            state->combi = loaded.data.combis.front().combi;
        } else if (!loaded.data.programs.empty() && loaded.data.programs.front().program != nullptr) {
            state->combi.name = loaded.data.programs.front().program->name;
            state->combi.uppers[0].enabled = true;
            state->combi.uppers[0].program = loaded.data.programs.front().program;
            state->combi.uppers[0].midiChannel = 0U;
        } else {
            setTextError("SET contains no playable COMBI or PROGRAM");
            return false;
        }
        return installState(std::move(state));
    }

    bool saveSet(const std::string& path) {
        syncCurrentStateToLibrary();
        const auto saved = SetPackage::save(path, library_.snapshot());
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool saveBank(const std::string& path, int bank) {
        if (bank < 0 || bank > 65535) { setTextError("Bank number is out of range"); return false; }
        syncCurrentStateToLibrary();
        const auto bankData = library_.snapshotBank(static_cast<std::uint16_t>(bank));
        if (bankData.programs.empty() && bankData.combis.empty() && bankData.lists.empty()) {
            setTextError("Selected bank is empty");
            return false;
        }
        const auto saved = SetPackage::save(path, bankData);
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool loadBank(const std::string& path, int targetBank, bool overwrite) {
        if (targetBank < 0 || targetBank > 65535) { setTextError("Target bank is out of range"); return false; }
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        const auto merged = library_.mergeBank(loaded.data, static_cast<std::uint16_t>(targetBank), overwrite);
        if (!merged.success) { setTextError(merged.error); return false; }
        setTextError({});
        return true;
    }

    bool writeCurrentProgram(const SlotAddress& address, int upperIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Program");
            return false;
        }
        const auto& source = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        if (source == nullptr) { setTextError("Selected Upper has no PROGRAM"); return false; }
        auto copy = std::make_shared<Program>(*source);
        copy->name = name.empty() ? source->name : name;
        if (!library_.writeProgram(address, copy)) { setTextError("Write Program failed"); return false; }
        setTextError({});
        return true;
    }

    bool updateProgramBasic(const SlotAddress& address, bool mono, bool legato, float portamentoSec) {
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateBasic(source, mono, legato, portamentoSec));
    }

    bool addProgramLayer(const SlotAddress& address, std::uint32_t multisampleId, const std::string& name) {
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        const auto ms = library_.multisample(multisampleId);
        if (ms == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::addLayer(source, name, ms));
    }

    bool removeProgramLayer(const SlotAddress& address, int layerIndex) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::removeLayer(source, static_cast<std::size_t>(layerIndex)));
    }

    bool moveProgramLayer(const SlotAddress& address, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::moveLayer(source, static_cast<std::size_t>(fromIndex), static_cast<std::size_t>(toIndex)));
    }

    bool assignProgramMultisample(const SlotAddress& address, int layerIndex, std::uint32_t multisampleId) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        const auto ms = library_.multisample(multisampleId);
        if (ms == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::assignMultisample(source, static_cast<std::size_t>(layerIndex), ms));
    }

    bool updateProgramLayerBasic(const SlotAddress& address, int layerIndex, bool enabled,
                                 int keyLow, int keyHigh, int velocityLow, int velocityHigh,
                                 int velocityFadeIn, int velocityFadeOut, int transposeSemitones,
                                 float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerBasic(
            source, static_cast<std::size_t>(layerIndex), enabled, keyLow, keyHigh, velocityLow, velocityHigh,
            velocityFadeIn, velocityFadeOut, transposeSemitones, tuneCents, levelDb, pan, delaySec, damperEnabled));
    }

    bool updateProgramAmpEnvelope(const SlotAddress& address, int layerIndex,
                                  float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerAmpEnvelope(
            source, static_cast<std::size_t>(layerIndex), EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramPitch(const SlotAddress& address, int layerIndex, float amountCents,
                            float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerPitch(
            source, static_cast<std::size_t>(layerIndex), amountCents, EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramFilter(const SlotAddress& address, int layerIndex, int mode,
                             float cutoffHz, float resonance, float keyTrack, float velocityAmount,
                             float envelopeAmount, float lfoAmount,
                             float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        if (mode < static_cast<int>(FilterMode::LowPass) || mode > static_cast<int>(FilterMode::Bypass)) {
            setTextError("PROGRAM FILTER mode is invalid"); return false;
        }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        FilterParams filter{};
        filter.mode = static_cast<FilterMode>(mode);
        filter.cutoffHz = cutoffHz;
        filter.resonance = resonance;
        filter.keyTrack = keyTrack;
        filter.velocityAmount = velocityAmount;
        filter.envelopeAmount = envelopeAmount;
        filter.lfoAmount = lfoAmount;
        return commitProgramEdit(address, source, ProgramEditor::updateLayerFilter(
            source, static_cast<std::size_t>(layerIndex), filter, EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramLfo(const SlotAddress& address, int layerIndex, int lfoIndex, int wave,
                          float frequencyHz, float delaySec, float fadeSec, bool keySync,
                          float pitchCents, float filterOctaves, float ampDepth) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        if (wave < static_cast<int>(LfoWave::Sine) || wave > static_cast<int>(LfoWave::RandomHold)) {
            setTextError("PROGRAM LFO waveform is invalid"); return false;
        }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        LfoParams lfo{};
        lfo.wave = static_cast<LfoWave>(wave);
        lfo.frequencyHz = frequencyHz;
        lfo.delaySec = delaySec;
        lfo.fadeSec = fadeSec;
        lfo.keySync = keySync;
        lfo.pitchCents = pitchCents;
        lfo.filterOctaves = filterOctaves;
        lfo.ampDepth = ampDepth;
        return commitProgramEdit(address, source, ProgramEditor::updateLayerLfo(
            source, static_cast<std::size_t>(layerIndex), lfoIndex, lfo));
    }

    bool writeCurrentSample(std::uint32_t id, int upperIndex, int layerIndex, int zoneIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Sample"); return false;
        }
        const auto& program = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        if (program == nullptr || layerIndex < 0 || static_cast<std::size_t>(layerIndex) >= program->layers.size()) {
            setTextError("Selected PROGRAM layer is invalid"); return false;
        }
        const auto& ms = program->layers[static_cast<std::size_t>(layerIndex)].multisample;
        if (ms == nullptr || zoneIndex < 0 || static_cast<std::size_t>(zoneIndex) >= ms->zones.size() || ms->zones[static_cast<std::size_t>(zoneIndex)].sample == nullptr) {
            setTextError("Selected MULTISAMPLE zone has no SAMPLE"); return false;
        }
        const auto source = ms->zones[static_cast<std::size_t>(zoneIndex)].sample;
        auto edited = SampleEditor::updateMetadata(*source, name.empty() ? source->name : name, source->rootKey, source->fineTuneCents);
        if (!edited.ok() || !library_.writeSample(id, edited.sample)) { setTextError(edited.error.empty() ? "Write Sample failed" : edited.error); return false; }
        setTextError({}); return true;
    }

    bool updateSampleMetadata(std::uint32_t id, const std::string& name, int rootKey, float fineTuneCents) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::updateMetadata(*source, name, static_cast<std::uint8_t>(std::clamp(rootKey,0,127)), fineTuneCents));
    }
    bool trimSample(std::uint32_t id, std::uint64_t startFrame, std::uint64_t endFrame) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::trim(*source, startFrame, endFrame));
    }
    bool normalizeSample(std::uint32_t id, float targetPeakDb) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::normalize(*source, targetPeakDb));
    }
    bool reverseSample(std::uint32_t id) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::reverse(*source));
    }
    bool fadeSample(std::uint32_t id, std::uint64_t fadeInFrames, std::uint64_t fadeOutFrames) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::fade(*source, fadeInFrames, fadeOutFrames));
    }
    bool setSampleLoop(std::uint32_t id, std::uint64_t startFrame, std::uint64_t endFrame, std::uint32_t crossfadeFrames) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::setLoop(*source, startFrame, endFrame, crossfadeFrames));
    }
    bool clearSampleLoop(std::uint32_t id) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::clearLoop(*source));
    }
    std::int64_t sampleNearestZeroCrossing(std::uint32_t id, std::uint64_t aroundFrame, std::uint64_t radius) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return -1; }
        setTextError({}); return static_cast<std::int64_t>(SampleEditor::nearestZeroCrossing(*source, aroundFrame, radius));
    }

    bool renameMultisample(std::uint32_t id, const std::string& name) {
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitMultisampleEdit(id, source, MultisampleEditor::rename(source, name));
    }
    bool addMultisampleZone(std::uint32_t id, std::uint32_t sampleId, int insertIndex,
                            int keyLow, int keyHigh, int velocityLow, int velocityHigh, int rootKey,
                            int transpose, float tuneCents, float gainDb, float pan,
                            bool oneShot, bool reverse, bool nonTranspose) {
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        const auto sample = library_.sample(sampleId); if (sample == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        SampleZone z{}; z.sample=sample; z.keyLow=static_cast<std::uint8_t>(std::clamp(keyLow,0,127)); z.keyHigh=static_cast<std::uint8_t>(std::clamp(keyHigh,0,127));
        z.velocityLow=static_cast<std::uint8_t>(std::clamp(velocityLow,1,127)); z.velocityHigh=static_cast<std::uint8_t>(std::clamp(velocityHigh,1,127)); z.rootKey=static_cast<std::uint8_t>(std::clamp(rootKey,0,127));
        z.transposeSemitones=static_cast<std::int8_t>(std::clamp(transpose,-64,63)); z.tuneCents=tuneCents; z.gainDb=gainDb; z.pan=pan; z.oneShot=oneShot; z.reverse=reverse; z.nonTranspose=nonTranspose;
        const auto result = insertIndex < 0 ? MultisampleEditor::addZone(source,z) : MultisampleEditor::insertZone(source,static_cast<std::size_t>(insertIndex),z);
        return commitMultisampleEdit(id, source, result);
    }
    bool updateMultisampleZone(std::uint32_t id, int zoneIndex, std::uint32_t sampleId,
                               int keyLow, int keyHigh, int velocityLow, int velocityHigh, int rootKey,
                               int transpose, float tuneCents, float gainDb, float pan,
                               bool oneShot, bool reverse, bool nonTranspose) {
        if (zoneIndex < 0) { setTextError("Zone index is out of range"); return false; }
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        const auto sample = library_.sample(sampleId); if (sample == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        SampleZone z{}; z.sample=sample; z.keyLow=static_cast<std::uint8_t>(std::clamp(keyLow,0,127)); z.keyHigh=static_cast<std::uint8_t>(std::clamp(keyHigh,0,127));
        z.velocityLow=static_cast<std::uint8_t>(std::clamp(velocityLow,1,127)); z.velocityHigh=static_cast<std::uint8_t>(std::clamp(velocityHigh,1,127)); z.rootKey=static_cast<std::uint8_t>(std::clamp(rootKey,0,127));
        z.transposeSemitones=static_cast<std::int8_t>(std::clamp(transpose,-64,63)); z.tuneCents=tuneCents; z.gainDb=gainDb; z.pan=pan; z.oneShot=oneShot; z.reverse=reverse; z.nonTranspose=nonTranspose;
        return commitMultisampleEdit(id, source, MultisampleEditor::updateZone(source,static_cast<std::size_t>(zoneIndex),z));
    }
    bool removeMultisampleZone(std::uint32_t id, int zoneIndex) {
        if (zoneIndex < 0) { setTextError("Zone index is out of range"); return false; }
        const auto source=library_.multisample(id); if(source==nullptr){setTextError("MULTISAMPLE id is not available");return false;}
        return commitMultisampleEdit(id,source,MultisampleEditor::removeZone(source,static_cast<std::size_t>(zoneIndex)));
    }
    bool moveMultisampleZone(std::uint32_t id, int fromIndex, int toIndex) {
        if(fromIndex<0||toIndex<0){setTextError("Zone index is out of range");return false;}
        const auto source=library_.multisample(id); if(source==nullptr){setTextError("MULTISAMPLE id is not available");return false;}
        return commitMultisampleEdit(id,source,MultisampleEditor::moveZone(source,static_cast<std::size_t>(fromIndex),static_cast<std::size_t>(toIndex)));
    }

    bool writeCurrentMultisample(std::uint32_t id, int upperIndex, int layerIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Multisample");
            return false;
        }
        const auto& program = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        if (program == nullptr || layerIndex < 0 || static_cast<std::size_t>(layerIndex) >= program->layers.size()) {
            setTextError("Selected PROGRAM layer has no MULTISAMPLE");
            return false;
        }
        const auto& source = program->layers[static_cast<std::size_t>(layerIndex)].multisample;
        if (source == nullptr) { setTextError("Selected PROGRAM layer has no MULTISAMPLE"); return false; }
        auto copy = std::make_shared<Multisample>(*source);
        if (!name.empty()) copy->name = name;
        if (!library_.writeMultisample(id, copy)) { setTextError("Write Multisample failed"); return false; }
        setTextError({});
        return true;
    }

    bool writeCurrentCombi(const SlotAddress& address, const std::string& name) {
        if (state_ == nullptr) { setTextError("No active COMBI"); return false; }
        Combi copy = state_->combi;
        if (!name.empty()) copy.name = name;
        if (!library_.writeCombi(address, copy)) { setTextError("Write Combi failed"); return false; }
        setTextError({});
        return true;
    }

    bool updateUpperFxSends(int upperIndex, float send1, float send2) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& upper = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        upper.fxSend1 = std::clamp(send1, 0.0F, 1.0F);
        upper.fxSend2 = std::clamp(send2, 0.0F, 1.0F);
        return installState(std::move(next));
    }

    bool updateUpperControllerRoute(int upperIndex, int routeIndex, int source, int destination,
                                    int cc, float amount, bool bipolar) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        if (routeIndex < 0 || routeIndex >= kMaxUpperControllerRoutes) { setTextError("Invalid controller route index"); return false; }
        if (source < static_cast<int>(ControllerSource::Off) || source > static_cast<int>(ControllerSource::ControlChange)) { setTextError("Invalid controller source"); return false; }
        if (destination < static_cast<int>(ModDestination::LevelDb) || destination > static_cast<int>(ModDestination::FxSend2)) { setTextError("Invalid modulation destination"); return false; }
        if (!std::isfinite(amount)) { setTextError("Controller route amount is not finite"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& route = next->combi.uppers[static_cast<std::size_t>(upperIndex)].controllerRoutes[static_cast<std::size_t>(routeIndex)];
        route.source = static_cast<ControllerSource>(source);
        route.destination = static_cast<ModDestination>(destination);
        route.cc = static_cast<std::uint8_t>(std::clamp(cc, 0, 127));
        route.amount = std::clamp(amount, -96.0F, 96.0F);
        route.bipolar = bipolar;
        return installState(std::move(next));
    }

    bool updateCombiFx(int slot, int type, float wet, float timeMs, float feedback,
                       float rateHz, float depth, float tone) {
        if (slot < 0 || slot > 1) { setTextError("Invalid COMBI FX slot"); return false; }
        if (type < static_cast<int>(EffectType::Off) || type > static_cast<int>(EffectType::Reverb)) { setTextError("Invalid COMBI FX type"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& fx = slot == 0 ? next->combi.fx1 : next->combi.fx2;
        fx.type = static_cast<EffectType>(type);
        fx.wet = std::clamp(wet, 0.0F, 1.0F);
        fx.timeMs = std::clamp(timeMs, 1.0F, 2500.0F);
        fx.feedback = std::clamp(feedback, 0.0F, 0.95F);
        fx.rateHz = std::clamp(rateHz, 0.05F, 8.0F);
        fx.depth = std::clamp(depth, 0.0F, 1.0F);
        fx.tone = std::clamp(tone, 0.0F, 1.0F);
        return installState(std::move(next));
    }

    bool updateCombiFxRouting(int routing) {
        if (routing < static_cast<int>(EffectRouting::Parallel) || routing > static_cast<int>(EffectRouting::Fx1IntoFx2)) { setTextError("Invalid COMBI FX routing"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        next->combi.fxRouting = static_cast<EffectRouting>(routing);
        return installState(std::move(next));
    }

    bool writeGlobal() {
        if (state_ == nullptr) { setTextError("No active GLOBAL state"); return false; }
        library_.setGlobal(state_->global);
        setTextError({});
        return true;
    }

    bool updateGlobal(float masterTuneHz, int transposeSemitones, float masterGainDb,
                      float eqLowDb, float eqMidDb, float eqHighDb, bool limiterEnabled,
                      float limiterCeilingDb, int velocityCurve, int breathCc, int expressionCc,
                      int damperCc, bool pitchBendEnabled, bool aftertouchEnabled) {
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& g = next->global;
        g.masterTuneHz = std::clamp(masterTuneHz, 400.0F, 480.0F);
        g.transposeSemitones = static_cast<std::int8_t>(std::clamp(transposeSemitones, -48, 48));
        g.masterGainDb = std::clamp(masterGainDb, -60.0F, 18.0F);
        g.eqLowDb = std::clamp(eqLowDb, -18.0F, 18.0F);
        g.eqMidDb = std::clamp(eqMidDb, -18.0F, 18.0F);
        g.eqHighDb = std::clamp(eqHighDb, -18.0F, 18.0F);
        g.limiterEnabled = limiterEnabled;
        g.limiterCeilingDb = std::clamp(limiterCeilingDb, -12.0F, 0.0F);
        g.velocityCurve = static_cast<std::uint8_t>(std::clamp(velocityCurve, 0, 4));
        g.breathCc = static_cast<std::uint8_t>(std::clamp(breathCc, 0, 127));
        g.expressionCc = static_cast<std::uint8_t>(std::clamp(expressionCc, 0, 127));
        g.damperCc = static_cast<std::uint8_t>(std::clamp(damperCc, 0, 127));
        g.pitchBendEnabled = pitchBendEnabled;
        g.aftertouchEnabled = aftertouchEnabled;
        library_.setGlobal(g);
        return installState(std::move(next));
    }

    bool updateGlobalAdvanced(int scaleRoot, const std::array<float, 12>& scaleOffsetsCents,
                              std::uint16_t midiInputChannelMask, bool filterNotes,
                              bool filterControlChange, bool filterPitchBend, bool filterAftertouch,
                              float breathMin, float breathMax, float breathCurve,
                              float expressionMin, float expressionMax, float expressionCurve,
                              bool damperPolarityReversed) {
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& g = next->global;
        g.scaleRoot = static_cast<std::uint8_t>(std::clamp(scaleRoot, 0, 11));
        for (std::size_t i = 0; i < g.scaleOffsetsCents.size(); ++i) {
            g.scaleOffsetsCents[i] = std::clamp(scaleOffsetsCents[i], -100.0F, 100.0F);
        }
        g.midiInputChannelMask = midiInputChannelMask;
        g.filterNotes = filterNotes;
        g.filterControlChange = filterControlChange;
        g.filterPitchBend = filterPitchBend;
        g.filterAftertouch = filterAftertouch;
        g.breathMin = std::clamp(breathMin, 0.0F, 0.9999F);
        g.breathMax = std::clamp(breathMax, g.breathMin + 0.0001F, 1.0F);
        g.breathCurve = std::clamp(breathCurve, 0.1F, 8.0F);
        g.expressionMin = std::clamp(expressionMin, 0.0F, 0.9999F);
        g.expressionMax = std::clamp(expressionMax, g.expressionMin + 0.0001F, 1.0F);
        g.expressionCurve = std::clamp(expressionCurve, 0.1F, 8.0F);
        g.damperPolarityReversed = damperPolarityReversed;
        library_.setGlobal(g);
        return installState(std::move(next));
    }

    bool writeList(const SlotAddress& address, const SetList& list) {
        if (!library_.writeList(address, list)) { setTextError("Write List failed"); return false; }
        setTextError({});
        return true;
    }

    bool setListEntry(const SlotAddress& listAddress, int index, int number, const std::string& name, const SlotAddress& combiAddress) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const auto combi = library_.combi(combiAddress);
        if (!combi.has_value()) { setTextError("LIST target COMBI slot is empty"); return false; }
        ListEntry entry{};
        entry.number = static_cast<std::uint16_t>(std::clamp(number, 0, 65535));
        entry.name = name.empty() ? combi->name : name;
        entry.combiBank = combiAddress.bank; entry.combiPage = combiAddress.page; entry.combiSlot = combiAddress.slot;
        if (!library_.setListEntry(listAddress, static_cast<std::size_t>(index), entry)) { setTextError("LIST entry update failed"); return false; }
        setTextError({}); return true;
    }

    bool insertListEntry(const SlotAddress& listAddress, int index, int number, const std::string& name, const SlotAddress& combiAddress) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const auto combi = library_.combi(combiAddress);
        if (!combi.has_value()) { setTextError("LIST target COMBI slot is empty"); return false; }
        ListEntry entry{};
        entry.number = static_cast<std::uint16_t>(std::clamp(number, 0, 65535));
        entry.name = name.empty() ? combi->name : name;
        entry.combiBank = combiAddress.bank; entry.combiPage = combiAddress.page; entry.combiSlot = combiAddress.slot;
        if (!library_.insertListEntry(listAddress, static_cast<std::size_t>(index), entry)) { setTextError("LIST entry insert failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress && activeListEntry_ >= index) ++activeListEntry_;
        setTextError({}); return true;
    }

    bool removeListEntry(const SlotAddress& listAddress, int index) {
        if (index < 0 || !library_.removeListEntry(listAddress, static_cast<std::size_t>(index))) { setTextError("LIST entry remove failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) {
            if (activeListEntry_ == index) activeListEntry_ = -1;
            else if (activeListEntry_ > index) --activeListEntry_;
        }
        setTextError({}); return true;
    }

    bool moveListEntry(const SlotAddress& listAddress, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < 0 || !library_.moveListEntry(listAddress, static_cast<std::size_t>(fromIndex), static_cast<std::size_t>(toIndex))) { setTextError("LIST entry move failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) {
            if (activeListEntry_ == fromIndex) activeListEntry_ = toIndex;
            else if (fromIndex < activeListEntry_ && activeListEntry_ <= toIndex) --activeListEntry_;
            else if (toIndex <= activeListEntry_ && activeListEntry_ < fromIndex) ++activeListEntry_;
        }
        setTextError({}); return true;
    }

    bool moveList(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
        if (!library_.moveList(from, to, overwrite)) { setTextError("LIST move failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == from) activeListAddress_ = to;
        setTextError({}); return true;
    }

    bool activateListEntry(const SlotAddress& listAddress, int index) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const auto list = library_.list(listAddress);
        if (!list.has_value() || static_cast<std::size_t>(index) >= list->entries.size()) { setTextError("LIST entry is not available"); return false; }
        const auto& entry = list->entries[static_cast<std::size_t>(index)];
        const SlotAddress combiAddress{entry.combiBank, entry.combiPage, entry.combiSlot};
        if (!activateCombi(combiAddress)) return false;
        activeListAddress_ = listAddress;
        activeListEntry_ = index;
        setTextError({}); return true;
    }

    int activeListEntry(const SlotAddress& listAddress) const noexcept {
        return activeListAddress_.has_value() && *activeListAddress_ == listAddress ? activeListEntry_ : -1;
    }

    std::vector<int> listEntryNumbers(const SlotAddress& address) const {
        std::vector<int> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()); for (const auto& e : list->entries) out.push_back(static_cast<int>(e.number)); return out;
    }

    std::vector<std::string> listEntryNames(const SlotAddress& address) const {
        std::vector<std::string> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()); for (const auto& e : list->entries) out.push_back(e.name); return out;
    }

    std::vector<int> listEntryCombiAddresses(const SlotAddress& address) const {
        std::vector<int> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()*3U); for (const auto& e : list->entries) { out.push_back(e.combiBank); out.push_back(e.combiPage); out.push_back(e.combiSlot); } return out;
    }

    bool clearProgram(const SlotAddress& address) { return library_.clearProgram(address); }
    bool clearCombi(const SlotAddress& address) { return library_.clearCombi(address); }
    bool clearList(const SlotAddress& address) {
        const bool ok = library_.clearList(address);
        if (ok && activeListAddress_.has_value() && *activeListAddress_ == address) { activeListAddress_.reset(); activeListEntry_ = -1; }
        return ok;
    }
    bool clearMultisample(std::uint32_t id) { return library_.clearMultisample(id); }

    bool programSlotOccupied(const SlotAddress& address) const { return library_.hasProgram(address); }
    bool combiSlotOccupied(const SlotAddress& address) const { return library_.hasCombi(address); }
    bool listSlotOccupied(const SlotAddress& address) const { return library_.hasList(address); }
    bool renameProgram(const SlotAddress& address, const std::string& name) { return library_.renameProgram(address, name); }
    bool renameCombi(const SlotAddress& address, const std::string& name) { return library_.renameCombi(address, name); }
    bool renameList(const SlotAddress& address, const std::string& name) { return library_.renameList(address, name); }
    bool copyProgram(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyProgram(from, to, overwrite); }
    bool copyCombi(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyCombi(from, to, overwrite); }
    bool copyList(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyList(from, to, overwrite); }

    bool activateProgram(const SlotAddress& address, int upperIndex) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        const auto program = library_.program(address);
        if (program == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& upper = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        upper.program = program;
        upper.enabled = true;
        if (upper.name.empty()) upper.name = "Upper " + std::to_string(upperIndex + 1);
        return installState(std::move(next));
    }

    bool activateCombi(const SlotAddress& address) {
        const auto combi = library_.combi(address);
        if (!combi.has_value()) { setTextError("COMBI slot is empty"); return false; }
        auto next = std::make_shared<EngineState>();
        next->global = state_ != nullptr ? state_->global : library_.global();
        next->combi = *combi;
        return installState(std::move(next));
    }

    bool setSetName(const std::string& name) {
        if (name.empty()) { setTextError("SET name cannot be empty"); return false; }
        library_.setSetName(name);
        return true;
    }

    bool midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
        const std::uint8_t kind = static_cast<std::uint8_t>(status & 0xF0U);
        const std::uint8_t ch = static_cast<std::uint8_t>(status & 0x0FU);
        switch (kind) {
            case 0x80U: return engine_.postNoteOff(ch, data1, data2);
            case 0x90U: return data2 == 0U ? engine_.postNoteOff(ch, data1, 0U) : engine_.postNoteOn(ch, data1, data2);
            case 0xB0U: return engine_.postControlChange(ch, data1, data2);
            case 0xD0U: return engine_.postChannelPressure(ch, data1);
            case 0xE0U: {
                const int raw = static_cast<int>(data1) | (static_cast<int>(data2) << 7);
                return engine_.postPitchBend(ch, static_cast<std::int16_t>(raw - 8192));
            }
            default: return true;
        }
    }

    bool panic() noexcept { return engine_.postPanic(); }

    MeterSnapshot meters() const noexcept { return engine_.meters(); }
    int sampleRate() const noexcept { return sampleRate_.load(std::memory_order_relaxed); }
    int framesPerBurst() const noexcept { return framesPerBurst_.load(std::memory_order_relaxed); }
    int bufferSizeFrames() const noexcept { return bufferSizeFrames_.load(std::memory_order_relaxed); }
    int xrunCount() const noexcept {
        if (stream_ == nullptr) return 0;
        const int32_t value = AAudioStream_getXRunCount(stream_);
        return value < 0 ? 0 : value;
    }
    int sharingMode() const noexcept {
        AAudioStream* s = stream_;
        return s == nullptr ? -1 : static_cast<int>(AAudioStream_getSharingMode(s));
    }
    int performanceMode() const noexcept {
        AAudioStream* s = stream_;
        return s == nullptr ? -1 : static_cast<int>(AAudioStream_getPerformanceMode(s));
    }
    int deviceId() const noexcept {
        AAudioStream* s = stream_;
        return s == nullptr ? -1 : AAudioStream_getDeviceId(s);
    }
    int lastError() const noexcept { return lastError_.load(std::memory_order_relaxed); }
    bool needsRecovery() const noexcept { return recoverRequested_.load(std::memory_order_acquire); }
    bool started() const noexcept { return started_.load(std::memory_order_acquire); }

    double estimatedOutputLatencyMs() const noexcept {
        AAudioStream* s = stream_;
        if (s == nullptr) return -1.0;
        int64_t framePosition = 0;
        int64_t timeNs = 0;
        const aaudio_result_t r = AAudioStream_getTimestamp(s, CLOCK_MONOTONIC, &framePosition, &timeNs);
        if (r != AAUDIO_OK) return -1.0;
        timespec ts{};
        if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return -1.0;
        const int64_t nowNs = static_cast<int64_t>(ts.tv_sec) * 1000000000LL + static_cast<int64_t>(ts.tv_nsec);
        const int sr = sampleRate();
        if (sr <= 0) return -1.0;
        const double elapsedFrames = static_cast<double>(nowNs - timeNs) * static_cast<double>(sr) / 1.0e9;
        const double predictedPresented = static_cast<double>(framePosition) + elapsedFrames;
        const int64_t written = AAudioStream_getFramesWritten(s);
        const double queued = std::max(0.0, static_cast<double>(written) - predictedPresented);
        return queued * 1000.0 / static_cast<double>(sr);
    }

    std::string textError() const {
        std::lock_guard<std::mutex> lock(errorMutex_);
        return textError_;
    }

private:
    static aaudio_data_callback_result_t dataCallback(AAudioStream*, void* user, void* audioData, int32_t numFrames) {
        auto* self = static_cast<AndroidSamplerAudio*>(user);
        self->engine_.render(static_cast<float*>(audioData), static_cast<std::uint32_t>(std::max(0, numFrames)));
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }

    static void errorCallback(AAudioStream*, void* user, aaudio_result_t error) {
        auto* self = static_cast<AndroidSamplerAudio*>(user);
        self->lastError_.store(error, std::memory_order_relaxed);
        self->started_.store(false, std::memory_order_release);
        self->recoverRequested_.store(true, std::memory_order_release);
        __android_log_print(ANDROID_LOG_ERROR, kTag, "AAudio error callback: %s", AAudio_convertResultToText(error));
    }

    bool openLocked() {
        if (stream_ != nullptr) return true;
        AAudioStreamBuilder* builder = nullptr;
        aaudio_result_t r = AAudio_createStreamBuilder(&builder);
        if (r != AAUDIO_OK || builder == nullptr) { lastError_.store(r, std::memory_order_relaxed); return false; }
        AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
        AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
        AAudioStreamBuilder_setChannelCount(builder, 2);
        AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
        AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_EXCLUSIVE);
        AAudioStreamBuilder_setDataCallback(builder, &AndroidSamplerAudio::dataCallback, this);
        AAudioStreamBuilder_setErrorCallback(builder, &AndroidSamplerAudio::errorCallback, this);
        r = AAudioStreamBuilder_openStream(builder, &stream_);
        AAudioStreamBuilder_delete(builder);
        if (r != AAUDIO_OK || stream_ == nullptr) {
            // Exclusive can legitimately be unavailable; retry shared while preserving low latency.
            builder = nullptr;
            r = AAudio_createStreamBuilder(&builder);
            if (r != AAUDIO_OK || builder == nullptr) { lastError_.store(r, std::memory_order_relaxed); return false; }
            AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
            AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
            AAudioStreamBuilder_setChannelCount(builder, 2);
            AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
            AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
            AAudioStreamBuilder_setDataCallback(builder, &AndroidSamplerAudio::dataCallback, this);
            AAudioStreamBuilder_setErrorCallback(builder, &AndroidSamplerAudio::errorCallback, this);
            r = AAudioStreamBuilder_openStream(builder, &stream_);
            AAudioStreamBuilder_delete(builder);
        }
        if (r != AAUDIO_OK || stream_ == nullptr) { lastError_.store(r, std::memory_order_relaxed); return false; }
        const int sr = AAudioStream_getSampleRate(stream_);
        const int burst = AAudioStream_getFramesPerBurst(stream_);
        sampleRate_.store(sr, std::memory_order_relaxed);
        framesPerBurst_.store(burst, std::memory_order_relaxed);
        if (burst > 0) {
            const int requested = burst * 2;
            const int actual = AAudioStream_setBufferSizeInFrames(stream_, requested);
            bufferSizeFrames_.store(actual > 0 ? actual : AAudioStream_getBufferSizeInFrames(stream_), std::memory_order_relaxed);
        } else {
            bufferSizeFrames_.store(AAudioStream_getBufferSizeInFrames(stream_), std::memory_order_relaxed);
        }
        engine_.prepare(static_cast<double>(std::max(8000, sr)), static_cast<std::uint32_t>(std::max(64, burst * 4)));
        if (state_ != nullptr) engine_.setState(state_);
        lastError_.store(AAUDIO_OK, std::memory_order_relaxed);
        recoverRequested_.store(false, std::memory_order_release);
        return true;
    }

    bool stopLocked() {
        if (stream_ == nullptr) {
            started_.store(false, std::memory_order_release);
            return true;
        }
        const auto before = AAudioStream_getState(stream_);
        if (before == AAUDIO_STREAM_STATE_STOPPED || before == AAUDIO_STREAM_STATE_OPEN) {
            started_.store(false, std::memory_order_release);
            return true;
        }
        const aaudio_result_t requested = AAudioStream_requestStop(stream_);
        if (requested != AAUDIO_OK) {
            lastError_.store(requested, std::memory_order_relaxed);
            return false;
        }
        aaudio_stream_state_t state = before;
        constexpr int64_t kWaitNs = 1000000000LL;
        for (int attempt = 0; attempt < 4; ++attempt) {
            aaudio_stream_state_t next = state;
            const aaudio_result_t waited = AAudioStream_waitForStateChange(stream_, state, &next, kWaitNs / 4LL);
            state = next;
            if (state == AAUDIO_STREAM_STATE_STOPPED || state == AAUDIO_STREAM_STATE_OPEN) {
                started_.store(false, std::memory_order_release);
                return true;
            }
            if (waited != AAUDIO_OK && waited != AAUDIO_ERROR_TIMEOUT) {
                lastError_.store(waited, std::memory_order_relaxed);
                return false;
            }
        }
        lastError_.store(AAUDIO_ERROR_TIMEOUT, std::memory_order_relaxed);
        return false;
    }

    bool commitSampleEdit(std::uint32_t id, const SamplePtr& previous, SampleEditResult result) {
        if (!result.ok()) { setTextError(result.error); return false; }
        if (!library_.writeSample(id, result.sample)) { setTextError("SAMPLE write-back failed"); return false; }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_); bool changed=false;
            for (auto& upper : next->combi.uppers) {
                if (upper.program == nullptr) continue;
                std::shared_ptr<Program> pc;
                for (std::size_t li=0U; li<upper.program->layers.size(); ++li) {
                    const auto& oldMs=upper.program->layers[li].multisample; if(oldMs==nullptr) continue;
                    std::shared_ptr<Multisample> mc;
                    for(std::size_t zi=0U; zi<oldMs->zones.size(); ++zi){
                        if(oldMs->zones[zi].sample!=previous) continue;
                        if(mc==nullptr) mc=std::make_shared<Multisample>(*oldMs);
                        mc->zones[zi].sample=result.sample;
                    }
                    if(mc!=nullptr){ if(pc==nullptr) pc=std::make_shared<Program>(*upper.program); pc->layers[li].multisample=mc; }
                }
                if(pc!=nullptr){ upper.program=pc; changed=true; }
            }
            if(changed && !installState(std::move(next))) return false;
        }
        setTextError({}); return true;
    }

    bool commitMultisampleEdit(std::uint32_t id, const MultisamplePtr& previous, MultisampleEditResult result) {
        if(!result.ok()){setTextError(result.error);return false;}
        if(!library_.writeMultisample(id,result.multisample)){setTextError("MULTISAMPLE write-back failed");return false;}
        if(state_!=nullptr){auto next=std::make_shared<EngineState>(*state_);bool changed=false;for(auto& upper:next->combi.uppers){if(upper.program==nullptr)continue;std::shared_ptr<Program> pc;for(std::size_t li=0U;li<upper.program->layers.size();++li){if(upper.program->layers[li].multisample!=previous)continue;if(pc==nullptr)pc=std::make_shared<Program>(*upper.program);pc->layers[li].multisample=result.multisample;}if(pc!=nullptr){upper.program=pc;changed=true;}}if(changed&&!installState(std::move(next)))return false;}
        setTextError({});return true;
    }

    bool commitProgramEdit(const SlotAddress& address, const ProgramPtr& previous, ProgramEditResult result) {
        if (!result.ok()) { setTextError(result.error); return false; }
        if (!library_.writeProgram(address, result.program)) { setTextError("PROGRAM write-back failed"); return false; }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_);
            bool activeChanged = false;
            for (auto& upper : next->combi.uppers) {
                if (upper.program == previous) {
                    upper.program = result.program;
                    activeChanged = true;
                }
            }
            if (activeChanged && !installState(std::move(next))) return false;
        }
        setTextError({});
        return true;
    }

    bool ensureKscCache(const std::string& path) {
        if (path == kscCachePath_ && kscCache_.ok()) return true;
        auto imported = KorgImporter::loadKsc(path);
        if (!imported.ok()) { setTextError(imported.error); return false; }
        kscCachePath_ = path;
        kscCache_ = std::move(imported);
        setTextError({});
        return true;
    }

    MultisamplePtr makeSingleSampleMultisample(const SamplePtr& sample, const std::string& name) {
        auto ms = std::make_shared<Multisample>();
        ms->name = name;
        SampleZone z{};
        z.sample = sample;
        z.keyLow = 0U; z.keyHigh = 127U; z.velocityLow = 1U; z.velocityHigh = 127U;
        z.rootKey = sample->rootKey;
        ms->zones.push_back(z);
        return ms;
    }

    bool installMultisample(const MultisamplePtr& ms, const std::string& name) {
        if (ms == nullptr) return false;
        auto program = std::make_shared<Program>();
        program->name = name;
        ProgramLayer layer{};
        layer.name = "Layer 1";
        layer.multisample = ms;
        program->layers.push_back(layer);
        auto state = std::make_shared<EngineState>();
        state->combi.name = name;
        auto& u = state->combi.uppers[0];
        u.name = "Upper 1";
        u.enabled = true;
        u.program = program;
        u.midiChannel = 0U;
        return installState(std::move(state));
    }

    bool installState(std::shared_ptr<const EngineState> state) {
        std::lock_guard<std::mutex> lock(controlMutex_);
        const bool resume = started_.load(std::memory_order_acquire);
        if (!stopLocked()) {
            setTextError("AAudio did not stop cleanly before state replacement");
            return false;
        }
        state_ = std::move(state);
        engine_.setState(state_);
        if (resume) {
            if (stream_ == nullptr && !openLocked()) return false;
            const aaudio_result_t r = AAudioStream_requestStart(stream_);
            if (r != AAUDIO_OK) { lastError_.store(r, std::memory_order_relaxed); return false; }
            started_.store(true, std::memory_order_release);
        }
        return true;
    }

    void syncCurrentStateToLibrary() {
        if (state_ == nullptr) return;
        library_.setGlobal(state_->global);
    }

    void setTextError(const std::string& s) {
        std::lock_guard<std::mutex> lock(errorMutex_);
        textError_ = s;
    }

    SamplerEngine engine_;
    SamplerLibrary library_{"SILVETON SET"};
    KorgCollectionResult kscCache_{};
    std::string kscCachePath_;
    std::shared_ptr<const EngineState> state_{std::make_shared<EngineState>()};
    std::optional<SlotAddress> activeListAddress_{};
    int activeListEntry_{-1};
    AAudioStream* stream_{nullptr};
    std::atomic<bool> started_{false};
    std::atomic<bool> wantStarted_{false};
    std::atomic<bool> recoverRequested_{false};
    std::atomic<int> sampleRate_{0};
    std::atomic<int> framesPerBurst_{0};
    std::atomic<int> bufferSizeFrames_{0};
    std::atomic<int> lastError_{AAUDIO_OK};
    mutable std::mutex controlMutex_;
    mutable std::mutex errorMutex_;
    std::string textError_;
};

std::unique_ptr<AndroidSamplerAudio> gSampler;
AndroidSamplerAudio& sampler() { if (!gSampler) gSampler = std::make_unique<AndroidSamplerAudio>(); return *gSampler; }

SlotAddress makeAddress(jint bank, jint page, jint slot) noexcept {
    SlotAddress a{};
    a.bank = static_cast<std::uint16_t>(std::clamp(bank, 0, 65535));
    a.page = static_cast<std::uint16_t>(std::clamp(page, 0, 65535));
    a.slot = static_cast<std::uint16_t>(std::clamp(slot, 0, 65535));
    return a;
}

jfloatArray metersArray(JNIEnv* env, const MeterSnapshot& m) {
    const std::array<jfloat,5> v{{m.peakLeft,m.peakRight,m.limiterGainReductionDb,static_cast<jfloat>(m.activeVoices),static_cast<jfloat>(m.droppedEvents)}};
    jfloatArray a=env->NewFloatArray(static_cast<jsize>(v.size()));
    if(a!=nullptr)env->SetFloatArrayRegion(a,0,static_cast<jsize>(v.size()),v.data());
    return a;
}

jintArray intVectorArray(JNIEnv* env, const std::vector<int>& values) {
    jintArray out = env->NewIntArray(static_cast<jsize>(values.size()));
    if (out == nullptr || values.empty()) return out;
    std::vector<jint> raw; raw.reserve(values.size());
    for (const int value : values) raw.push_back(static_cast<jint>(value));
    env->SetIntArrayRegion(out, 0, static_cast<jsize>(raw.size()), raw.data());
    return out;
}
}

extern "C" JNIEXPORT void JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSamplerInit(JNIEnv*,jobject){gSampler=std::make_unique<AndroidSamplerAudio>();}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioOpen(JNIEnv*,jobject){return sampler().open()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioStart(JNIEnv*,jobject){return sampler().start()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT void JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioStop(JNIEnv*,jobject){sampler().stop();}
extern "C" JNIEXPORT void JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioClose(JNIEnv*,jobject){sampler().close();}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioRecover(JNIEnv*,jobject){return sampler().recover()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioNeedsRecovery(JNIEnv*,jobject){return sampler().needsRecovery()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLoadAudio(JNIEnv* env,jobject,jstring path){return sampler().loadAudioFile(jstringToUtf8(env,path))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLoadKmp(JNIEnv* env,jobject,jstring path){return sampler().loadKmp(jstringToUtf8(env,path))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jintArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeImportKmpToLibrary(JNIEnv* env,jobject,jstring path){return intVectorArray(env,sampler().importKmpToLibrary(jstringToUtf8(env,path)));}
extern "C" JNIEXPORT jintArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeImportKscToLibrary(JNIEnv* env,jobject,jstring path){return intVectorArray(env,sampler().importKscToLibrary(jstringToUtf8(env,path)));}
extern "C" JNIEXPORT jintArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMultisampleIds(JNIEnv* env,jobject){return intVectorArray(env,sampler().multisampleIds());}
extern "C" JNIEXPORT jobjectArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMultisampleNames(JNIEnv* env,jobject){
    const auto names=sampler().multisampleNames();
    jclass stringClass=env->FindClass("java/lang/String");
    if(stringClass==nullptr)return nullptr;
    jobjectArray out=env->NewObjectArray(static_cast<jsize>(names.size()),stringClass,nullptr);
    if(out==nullptr)return nullptr;
    for(std::size_t i=0;i<names.size();++i){jstring v=env->NewStringUTF(names[i].c_str());env->SetObjectArrayElement(out,static_cast<jsize>(i),v);env->DeleteLocalRef(v);}
    return out;
}
extern "C" JNIEXPORT jobjectArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeKscNames(JNIEnv* env,jobject,jstring path){
    const auto names=sampler().kscNames(jstringToUtf8(env,path));
    jclass stringClass=env->FindClass("java/lang/String");
    if(stringClass==nullptr)return nullptr;
    jobjectArray out=env->NewObjectArray(static_cast<jsize>(names.size()),stringClass,nullptr);
    if(out==nullptr)return nullptr;
    for(std::size_t i=0;i<names.size();++i){jstring v=env->NewStringUTF(names[i].c_str());env->SetObjectArrayElement(out,static_cast<jsize>(i),v);env->DeleteLocalRef(v);}
    return out;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLoadKscItem(JNIEnv* env,jobject,jstring path,jint index){return sampler().loadKscItem(jstringToUtf8(env,path),index)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLoadSet(JNIEnv* env,jobject,jstring path){return sampler().loadSet(jstringToUtf8(env,path))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSaveBank(JNIEnv* env,jobject,jstring path,jint bank){return sampler().saveBank(jstringToUtf8(env,path),bank)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLoadBank(JNIEnv* env,jobject,jstring path,jint targetBank,jboolean overwrite){return sampler().loadBank(jstringToUtf8(env,path),targetBank,overwrite==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeWriteSample(JNIEnv* env,jobject,jint id,jint upper,jint layer,jint zone,jstring name){return sampler().writeCurrentSample(static_cast<std::uint32_t>(std::max(0,id)),upper,layer,zone,jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateSampleMetadata(JNIEnv* env,jobject,jint id,jstring name,jint rootKey,jfloat fineTune){return sampler().updateSampleMetadata(static_cast<std::uint32_t>(std::max(0,id)),jstringToUtf8(env,name),rootKey,fineTune)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeTrimSample(JNIEnv*,jobject,jint id,jlong start,jlong end){if(start<0||end<0)return JNI_FALSE;return sampler().trimSample(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(start),static_cast<std::uint64_t>(end))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeNormalizeSample(JNIEnv*,jobject,jint id,jfloat targetDb){return sampler().normalizeSample(static_cast<std::uint32_t>(std::max(0,id)),targetDb)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeReverseSample(JNIEnv*,jobject,jint id){return sampler().reverseSample(static_cast<std::uint32_t>(std::max(0,id)))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeFadeSample(JNIEnv*,jobject,jint id,jlong fadeIn,jlong fadeOut){if(fadeIn<0||fadeOut<0)return JNI_FALSE;return sampler().fadeSample(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(fadeIn),static_cast<std::uint64_t>(fadeOut))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSetSampleLoop(JNIEnv*,jobject,jint id,jlong start,jlong end,jint crossfade){if(start<0||end<0||crossfade<0)return JNI_FALSE;return sampler().setSampleLoop(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(start),static_cast<std::uint64_t>(end),static_cast<std::uint32_t>(crossfade))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeClearSampleLoop(JNIEnv*,jobject,jint id){return sampler().clearSampleLoop(static_cast<std::uint32_t>(std::max(0,id)))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jlong JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSampleNearestZeroCrossing(JNIEnv*,jobject,jint id,jlong around,jlong radius){if(around<0||radius<0)return static_cast<jlong>(-1);return static_cast<jlong>(sampler().sampleNearestZeroCrossing(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(around),static_cast<std::uint64_t>(radius)));}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeWriteMultisample(JNIEnv* env,jobject,jint id,jint upper,jint layer,jstring name){return sampler().writeCurrentMultisample(static_cast<std::uint32_t>(std::max(0,id)),upper,layer,jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRenameMultisample(JNIEnv* env,jobject,jint id,jstring name){return sampler().renameMultisample(static_cast<std::uint32_t>(std::max(0,id)),jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAddMultisampleZone(JNIEnv*,jobject,jint id,jint sampleId,jint insertIndex,jint keyLow,jint keyHigh,jint velLow,jint velHigh,jint rootKey,jint transpose,jfloat tune,jfloat gain,jfloat pan,jboolean oneShot,jboolean reverse,jboolean nonTranspose){return sampler().addMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint32_t>(std::max(0,sampleId)),insertIndex,keyLow,keyHigh,velLow,velHigh,rootKey,transpose,tune,gain,pan,oneShot==JNI_TRUE,reverse==JNI_TRUE,nonTranspose==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateMultisampleZone(JNIEnv*,jobject,jint id,jint zoneIndex,jint sampleId,jint keyLow,jint keyHigh,jint velLow,jint velHigh,jint rootKey,jint transpose,jfloat tune,jfloat gain,jfloat pan,jboolean oneShot,jboolean reverse,jboolean nonTranspose){return sampler().updateMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),zoneIndex,static_cast<std::uint32_t>(std::max(0,sampleId)),keyLow,keyHigh,velLow,velHigh,rootKey,transpose,tune,gain,pan,oneShot==JNI_TRUE,reverse==JNI_TRUE,nonTranspose==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRemoveMultisampleZone(JNIEnv*,jobject,jint id,jint zoneIndex){return sampler().removeMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),zoneIndex)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMoveMultisampleZone(JNIEnv*,jobject,jint id,jint fromIndex,jint toIndex){return sampler().moveMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),fromIndex,toIndex)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeClearMultisample(JNIEnv*,jobject,jint id){return sampler().clearMultisample(static_cast<std::uint32_t>(std::max(0,id)))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeProgramSlotOccupied(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().programSlotOccupied(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeCombiSlotOccupied(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().combiSlotOccupied(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeListSlotOccupied(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().listSlotOccupied(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRenameProgram(JNIEnv* env,jobject,jint bank,jint page,jint slot,jstring name){return sampler().renameProgram(makeAddress(bank,page,slot),jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRenameCombi(JNIEnv* env,jobject,jint bank,jint page,jint slot,jstring name){return sampler().renameCombi(makeAddress(bank,page,slot),jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRenameList(JNIEnv* env,jobject,jint bank,jint page,jint slot,jstring name){return sampler().renameList(makeAddress(bank,page,slot),jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeCopyProgram(JNIEnv*,jobject,jint fb,jint fp,jint fs,jint tb,jint tp,jint ts,jboolean overwrite){return sampler().copyProgram(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeCopyCombi(JNIEnv*,jobject,jint fb,jint fp,jint fs,jint tb,jint tp,jint ts,jboolean overwrite){return sampler().copyCombi(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeCopyList(JNIEnv*,jobject,jint fb,jint fp,jint fs,jint tb,jint tp,jint ts,jboolean overwrite){return sampler().copyList(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMidi(JNIEnv*,jobject,jint status,jint d1,jint d2){return sampler().midi(static_cast<std::uint8_t>(status&0xFF),static_cast<std::uint8_t>(d1&0x7F),static_cast<std::uint8_t>(d2&0x7F))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativePanic(JNIEnv*,jobject){return sampler().panic()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jfloatArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMeters(JNIEnv* env,jobject){return metersArray(env,sampler().meters());}
extern "C" JNIEXPORT jintArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAudioInfo(JNIEnv* env,jobject){const std::array<jint,7>v{{sampler().sampleRate(),sampler().framesPerBurst(),sampler().bufferSizeFrames(),sampler().xrunCount(),sampler().sharingMode(),sampler().performanceMode(),sampler().deviceId()}};jintArray a=env->NewIntArray(static_cast<jsize>(v.size()));if(a!=nullptr)env->SetIntArrayRegion(a,0,static_cast<jsize>(v.size()),v.data());return a;}
extern "C" JNIEXPORT jdouble JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLatencyMs(JNIEnv*,jobject){return sampler().estimatedOutputLatencyMs();}
extern "C" JNIEXPORT jint JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLastAudioError(JNIEnv*,jobject){return sampler().lastError();}
extern "C" JNIEXPORT jstring JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeLastTextError(JNIEnv* env,jobject){const auto s=sampler().textError();return env->NewStringUTF(s.c_str());}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSaveSet(JNIEnv* env,jobject,jstring path){return sampler().saveSet(jstringToUtf8(env,path))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSetSetName(JNIEnv* env,jobject,jstring name){return sampler().setSetName(jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeWriteProgram(JNIEnv* env,jobject,jint bank,jint page,jint slot,jint upper,jstring name){return sampler().writeCurrentProgram(makeAddress(bank,page,slot),upper,jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateProgramBasic(JNIEnv*,jobject,jint bank,jint page,jint slot,jboolean mono,jboolean legato,jfloat portamentoSec){return sampler().updateProgramBasic(makeAddress(bank,page,slot),mono==JNI_TRUE,legato==JNI_TRUE,portamentoSec)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAddProgramLayer(JNIEnv* env,jobject,jint bank,jint page,jint slot,jint multisampleId,jstring name){return sampler().addProgramLayer(makeAddress(bank,page,slot),static_cast<std::uint32_t>(std::max(0,multisampleId)),jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRemoveProgramLayer(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer){return sampler().removeProgramLayer(makeAddress(bank,page,slot),layer)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMoveProgramLayer(JNIEnv*,jobject,jint bank,jint page,jint slot,jint fromLayer,jint toLayer){return sampler().moveProgramLayer(makeAddress(bank,page,slot),fromLayer,toLayer)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeAssignProgramMultisample(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer,jint multisampleId){return sampler().assignProgramMultisample(makeAddress(bank,page,slot),layer,static_cast<std::uint32_t>(std::max(0,multisampleId)))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateProgramLayerBasic(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer,jboolean enabled,jint keyLow,jint keyHigh,jint velocityLow,jint velocityHigh,jint velocityFadeIn,jint velocityFadeOut,jint transpose,jfloat tuneCents,jfloat levelDb,jfloat pan,jfloat delaySec,jboolean damperEnabled){return sampler().updateProgramLayerBasic(makeAddress(bank,page,slot),layer,enabled==JNI_TRUE,keyLow,keyHigh,velocityLow,velocityHigh,velocityFadeIn,velocityFadeOut,transpose,tuneCents,levelDb,pan,delaySec,damperEnabled==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateProgramAmpEnvelope(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer,jfloat attack,jfloat decay,jfloat sustain,jfloat release){return sampler().updateProgramAmpEnvelope(makeAddress(bank,page,slot),layer,attack,decay,sustain,release)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateProgramPitch(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer,jfloat amountCents,jfloat attack,jfloat decay,jfloat sustain,jfloat release){return sampler().updateProgramPitch(makeAddress(bank,page,slot),layer,amountCents,attack,decay,sustain,release)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateProgramFilter(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer,jint mode,jfloat cutoffHz,jfloat resonance,jfloat keyTrack,jfloat velocityAmount,jfloat envelopeAmount,jfloat lfoAmount,jfloat attack,jfloat decay,jfloat sustain,jfloat release){return sampler().updateProgramFilter(makeAddress(bank,page,slot),layer,mode,cutoffHz,resonance,keyTrack,velocityAmount,envelopeAmount,lfoAmount,attack,decay,sustain,release)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateProgramLfo(JNIEnv*,jobject,jint bank,jint page,jint slot,jint layer,jint lfoIndex,jint wave,jfloat frequencyHz,jfloat delaySec,jfloat fadeSec,jboolean keySync,jfloat pitchCents,jfloat filterOctaves,jfloat ampDepth){return sampler().updateProgramLfo(makeAddress(bank,page,slot),layer,lfoIndex,wave,frequencyHz,delaySec,fadeSec,keySync==JNI_TRUE,pitchCents,filterOctaves,ampDepth)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeWriteCombi(JNIEnv* env,jobject,jint bank,jint page,jint slot,jstring name){return sampler().writeCurrentCombi(makeAddress(bank,page,slot),jstringToUtf8(env,name))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateUpperFxSends(JNIEnv*,jobject,jint upper,jfloat send1,jfloat send2){return sampler().updateUpperFxSends(upper,send1,send2)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateUpperControllerRoute(JNIEnv*,jobject,jint upper,jint route,jint source,jint destination,jint cc,jfloat amount,jboolean bipolar){return sampler().updateUpperControllerRoute(upper,route,source,destination,cc,amount,bipolar==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateCombiFx(JNIEnv*,jobject,jint slot,jint type,jfloat wet,jfloat timeMs,jfloat feedback,jfloat rateHz,jfloat depth,jfloat tone){return sampler().updateCombiFx(slot,type,wet,timeMs,feedback,rateHz,depth,tone)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateCombiFxRouting(JNIEnv*,jobject,jint routing){return sampler().updateCombiFxRouting(routing)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeWriteGlobal(JNIEnv*,jobject){return sampler().writeGlobal()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateGlobal(JNIEnv*,jobject,jfloat tune,jint transpose,jfloat gain,jfloat low,jfloat mid,jfloat high,jboolean limiter,jfloat ceiling,jint velocityCurve,jint breathCc,jint expressionCc,jint damperCc,jboolean pitchBend,jboolean aftertouch){return sampler().updateGlobal(tune,transpose,gain,low,mid,high,limiter==JNI_TRUE,ceiling,velocityCurve,breathCc,expressionCc,damperCc,pitchBend==JNI_TRUE,aftertouch==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeUpdateGlobalAdvanced(JNIEnv* env,jobject,jint scaleRoot,jfloatArray scaleOffsets,jint midiChannelMask,jboolean filterNotes,jboolean filterCc,jboolean filterPitchBend,jboolean filterAftertouch,jfloat breathMin,jfloat breathMax,jfloat breathCurve,jfloat expressionMin,jfloat expressionMax,jfloat expressionCurve,jboolean damperReverse){
    if(scaleOffsets==nullptr||env->GetArrayLength(scaleOffsets)<12)return JNI_FALSE;
    std::array<jfloat,12> raw{};env->GetFloatArrayRegion(scaleOffsets,0,12,raw.data());
    std::array<float,12> offsets{};for(std::size_t i=0;i<offsets.size();++i)offsets[i]=raw[i];
    return sampler().updateGlobalAdvanced(scaleRoot,offsets,static_cast<std::uint16_t>(midiChannelMask&0xFFFF),filterNotes==JNI_TRUE,filterCc==JNI_TRUE,filterPitchBend==JNI_TRUE,filterAftertouch==JNI_TRUE,breathMin,breathMax,breathCurve,expressionMin,expressionMax,expressionCurve,damperReverse==JNI_TRUE)?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeWriteList(JNIEnv* env,jobject,jint bank,jint page,jint slot,jstring listName,jintArray numbers,jobjectArray names,jintArray combiAddresses){
    if(numbers==nullptr||names==nullptr||combiAddresses==nullptr){return JNI_FALSE;}
    const jsize count=env->GetArrayLength(numbers);
    if(env->GetArrayLength(names)!=count||env->GetArrayLength(combiAddresses)!=count*3){return JNI_FALSE;}
    std::vector<jint> nums(static_cast<std::size_t>(count));
    std::vector<jint> addr(static_cast<std::size_t>(count)*3U);
    env->GetIntArrayRegion(numbers,0,count,nums.data());
    env->GetIntArrayRegion(combiAddresses,0,count*3,addr.data());
    SetList list; list.name=jstringToUtf8(env,listName); list.entries.reserve(static_cast<std::size_t>(count));
    for(jsize i=0;i<count;++i){
        auto js=static_cast<jstring>(env->GetObjectArrayElement(names,i));
        ListEntry e; e.number=static_cast<std::uint16_t>(std::clamp(nums[static_cast<std::size_t>(i)],0,65535)); e.name=jstringToUtf8(env,js);
        if(js!=nullptr)env->DeleteLocalRef(js);
        const std::size_t base=static_cast<std::size_t>(i)*3U;
        e.combiBank=static_cast<std::uint16_t>(std::clamp(addr[base],0,65535));
        e.combiPage=static_cast<std::uint16_t>(std::clamp(addr[base+1U],0,65535));
        e.combiSlot=static_cast<std::uint16_t>(std::clamp(addr[base+2U],0,65535));
        list.entries.push_back(std::move(e));
    }
    return sampler().writeList(makeAddress(bank,page,slot),list)?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeSetListEntry(JNIEnv* env,jobject,jint lb,jint lp,jint ls,jint index,jint number,jstring name,jint cb,jint cp,jint cs){return sampler().setListEntry(makeAddress(lb,lp,ls),index,number,jstringToUtf8(env,name),makeAddress(cb,cp,cs))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeInsertListEntry(JNIEnv* env,jobject,jint lb,jint lp,jint ls,jint index,jint number,jstring name,jint cb,jint cp,jint cs){return sampler().insertListEntry(makeAddress(lb,lp,ls),index,number,jstringToUtf8(env,name),makeAddress(cb,cp,cs))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeRemoveListEntry(JNIEnv*,jobject,jint lb,jint lp,jint ls,jint index){return sampler().removeListEntry(makeAddress(lb,lp,ls),index)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMoveListEntry(JNIEnv*,jobject,jint lb,jint lp,jint ls,jint fromIndex,jint toIndex){return sampler().moveListEntry(makeAddress(lb,lp,ls),fromIndex,toIndex)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeMoveList(JNIEnv*,jobject,jint fb,jint fp,jint fs,jint tb,jint tp,jint ts,jboolean overwrite){return sampler().moveList(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite==JNI_TRUE)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeActivateListEntry(JNIEnv*,jobject,jint lb,jint lp,jint ls,jint index){return sampler().activateListEntry(makeAddress(lb,lp,ls),index)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jint JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeActiveListEntry(JNIEnv*,jobject,jint lb,jint lp,jint ls){return static_cast<jint>(sampler().activeListEntry(makeAddress(lb,lp,ls)));}
extern "C" JNIEXPORT jintArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeListEntryNumbers(JNIEnv* env,jobject,jint lb,jint lp,jint ls){return intVectorArray(env,sampler().listEntryNumbers(makeAddress(lb,lp,ls)));}
extern "C" JNIEXPORT jobjectArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeListEntryNames(JNIEnv* env,jobject,jint lb,jint lp,jint ls){
    const auto names=sampler().listEntryNames(makeAddress(lb,lp,ls)); jclass stringClass=env->FindClass("java/lang/String"); if(stringClass==nullptr)return nullptr; jobjectArray out=env->NewObjectArray(static_cast<jsize>(names.size()),stringClass,nullptr); if(out==nullptr)return nullptr; for(std::size_t i=0;i<names.size();++i){jstring v=env->NewStringUTF(names[i].c_str());env->SetObjectArrayElement(out,static_cast<jsize>(i),v);env->DeleteLocalRef(v);} return out;
}
extern "C" JNIEXPORT jintArray JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeListEntryCombiAddresses(JNIEnv* env,jobject,jint lb,jint lp,jint ls){return intVectorArray(env,sampler().listEntryCombiAddresses(makeAddress(lb,lp,ls)));}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeActivateProgram(JNIEnv*,jobject,jint bank,jint page,jint slot,jint upper){return sampler().activateProgram(makeAddress(bank,page,slot),upper)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeActivateCombi(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().activateCombi(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeClearProgram(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().clearProgram(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeClearCombi(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().clearCombi(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_silveton_sampler_NativeSamplerEngine_nativeClearList(JNIEnv*,jobject,jint bank,jint page,jint slot){return sampler().clearList(makeAddress(bank,page,slot))?JNI_TRUE:JNI_FALSE;}

#endif
