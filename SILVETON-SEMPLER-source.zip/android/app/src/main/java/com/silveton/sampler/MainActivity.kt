package com.silveton.sampler

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Android lifecycle host for SILVETON SAMPLER.
 *
 * The final approved LIST/COMBI/PROGRAM/SAMPLE/GLOBAL/MEDIA GUI will replace
 * the temporary status surface below. There are intentionally no interactive
 * controls here, so there are no dead/fake controls while the GUI is not yet
 * wired. Audio, MIDI, storage and native state are owned by SamplerAppController.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var sampler: SamplerAppController
    private lateinit var statusView: TextView
    private var created = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        statusView = TextView(this).apply {
            text = "SILVETON SAMPLER"
            setTextColor(Color.rgb(225, 235, 245))
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(8, 14, 24))
            addView(
                statusView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
        setContentView(root)

        sampler = SamplerAppController(
            this,
            statusChanged = { warning ->
                runOnUiThread {
                    statusView.text = if (warning.isNullOrBlank()) {
                        "SILVETON SAMPLER"
                    } else {
                        "SILVETON SAMPLER\n$warning"
                    }
                }
            }
        )
        created = true
    }

    override fun onStart() {
        super.onStart()
        if (created && !sampler.start()) {
            val error = sampler.engine.nativeLastTextError().ifBlank { "Sampler start failed" }
            statusView.text = "SILVETON SAMPLER\n$error"
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemUi()
        if (created) sampler.resumeAudio()
    }

    override fun onPause() {
        if (created) sampler.pauseAudio()
        super.onPause()
    }

    override fun onDestroy() {
        if (created) sampler.close()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}
