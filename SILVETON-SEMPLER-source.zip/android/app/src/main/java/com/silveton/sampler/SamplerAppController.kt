package com.silveton.sampler

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Technical Android host for the SILVETON SAMPLER engine.
 *
 * This class intentionally contains no GUI. The final LIST/COMBI/PROGRAM/
 * SAMPLE/GLOBAL/MEDIA screens call this host, while audio and MIDI stay owned
 * by the native/runtime layer.
 */
class SamplerAppController(
    context: Context,
    private val statusChanged: (String?) -> Unit = {},
    private val midiConnectionChanged: (Int) -> Unit = {}
) : AutoCloseable {
    data class AudioStatus(
        val sampleRate: Int,
        val framesPerBurst: Int,
        val bufferSizeFrames: Int,
        val xrunCount: Int,
        val sharingMode: Int,
        val performanceMode: Int,
        val deviceId: Int,
        val estimatedLatencyMs: Double,
        val peakLeft: Float,
        val peakRight: Float,
        val limiterGainReductionDb: Float,
        val activeVoices: Int,
        val droppedRealtimeEvents: Int
    )

    private val appContext = context.applicationContext
    val engine = NativeSamplerEngine()
    val media = SamplerMediaStorage(appContext)
    private val runtime = SamplerRuntime(engine, statusChanged)
    private val midi = SamplerMidiController(
        appContext,
        engine,
        connectionChanged = midiConnectionChanged,
        statusChanged = statusChanged
    )
    private val started = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)

    /** Start low-latency output first, then accept MIDI. */
    fun start(): Boolean {
        if (closed.get()) return false
        if (started.get()) return true
        if (!runtime.start()) return false
        midi.start()
        started.set(true)
        return true
    }

    /**
     * Activity pause does not destroy engine state. It only suspends the
     * hardware stream; MIDI is kept attached so hot-plug bookkeeping is not
     * rebuilt on every transient window change.
     */
    fun pauseAudio() {
        if (!closed.get() && started.get()) runtime.suspendAudio()
    }

    fun resumeAudio(): Boolean {
        if (closed.get()) return false
        if (!started.get()) return start()
        val ok = runtime.resumeAudio()
        if (!ok) statusChanged(engine.nativeLastTextError().ifBlank { "Audio resume failed" })
        return ok
    }

    fun panic(): Boolean = !closed.get() && engine.nativePanic()

    fun loadAudioFile(path: File): Boolean = nativeResult(engine.nativeLoadAudio(path.absolutePath))
    fun loadKmp(path: File): Boolean = nativeResult(engine.nativeLoadKmp(path.absolutePath))
    fun loadSet(path: File): Boolean = nativeResult(engine.nativeLoadSet(path.absolutePath))

    fun importKmpToLibrary(path: File): IntArray {
        val ids = engine.nativeImportKmpToLibrary(path.absolutePath)
        if (ids.isEmpty()) statusChanged(engine.nativeLastTextError().ifBlank { "KMP import failed" }) else statusChanged(null)
        return ids
    }

    fun importKscToLibrary(path: File): IntArray {
        val ids = engine.nativeImportKscToLibrary(path.absolutePath)
        if (ids.isEmpty()) statusChanged(engine.nativeLastTextError().ifBlank { "KSC import failed" }) else statusChanged(null)
        return ids
    }

    fun multisampleCatalog(): List<Pair<Int, String>> {
        val ids = engine.nativeMultisampleIds()
        val names = engine.nativeMultisampleNames()
        val count = minOf(ids.size, names.size)
        return List(count) { index -> ids[index] to names[index] }
    }

    data class ListItem(
        val number: Int,
        val name: String,
        val combiBank: Int,
        val combiPage: Int,
        val combiSlot: Int
    )

    fun listItems(bank: Int, page: Int, slot: Int): List<ListItem> {
        val numbers = engine.nativeListEntryNumbers(bank, page, slot)
        val names = engine.nativeListEntryNames(bank, page, slot)
        val addresses = engine.nativeListEntryCombiAddresses(bank, page, slot)
        val count = minOf(numbers.size, names.size, addresses.size / 3)
        return List(count) { index ->
            val base = index * 3
            ListItem(numbers[index], names[index], addresses[base], addresses[base + 1], addresses[base + 2])
        }
    }

    fun activeListEntry(bank: Int, page: Int, slot: Int): Int =
        engine.nativeActiveListEntry(bank, page, slot)

    fun activateListEntry(bank: Int, page: Int, slot: Int, index: Int): Boolean =
        nativeResult(engine.nativeActivateListEntry(bank, page, slot, index))

    fun kscNames(path: File): List<String> = engine.nativeKscNames(path.absolutePath).toList()

    fun loadKscItem(path: File, index: Int): Boolean =
        nativeResult(engine.nativeLoadKscItem(path.absolutePath, index))

    /**
     * Materialize one ordinary standalone audio document. KMP/KSC should be
     * imported from a folder tree so their sibling KSF/KMP dependencies remain
     * beside them.
     */
    fun importAudioDocument(uri: Uri): Boolean {
        val local = media.materializeDocument(uri)
        return when (local.extension.lowercase()) {
            "wav", "wave", "aif", "aiff", "aifc" -> loadAudioFile(local)
            else -> fail("Unsupported standalone sample format: ${local.extension}")
        }
    }

    /** Copy a complete Korg folder first so relative KMP/KSF/KSC paths work. */
    fun importKorgTree(treeUri: Uri, folderName: String): File =
        media.materializeTree(treeUri, folderName)

    fun importSetTree(treeUri: Uri, setName: String): Boolean {
        val local = media.materializeSetTree(treeUri, setName)
        return loadSet(local)
    }

    /** Save atomically in app-owned storage. SetPackage performs the native validation. */
    fun saveInternalSet(setName: String): File? {
        val safe = media.safeSetDirectoryName(setName)
        val target = File(media.internalSetsDirectory(), safe)
        return if (nativeResult(engine.nativeSaveSet(target.absolutePath))) target else null
    }

    fun exportSet(source: File, destinationTree: Uri, folderName: String = source.name): Uri =
        media.exportSetDirectory(source, destinationTree, folderName)

    fun audioStatus(): AudioStatus {
        val info = engine.nativeAudioInfo()
        val meters = engine.nativeMeters()
        return AudioStatus(
            sampleRate = info.getOrElse(0) { 0 },
            framesPerBurst = info.getOrElse(1) { 0 },
            bufferSizeFrames = info.getOrElse(2) { 0 },
            xrunCount = info.getOrElse(3) { 0 },
            sharingMode = info.getOrElse(4) { -1 },
            performanceMode = info.getOrElse(5) { -1 },
            deviceId = info.getOrElse(6) { -1 },
            estimatedLatencyMs = engine.nativeLatencyMs(),
            peakLeft = meters.getOrElse(0) { 0f },
            peakRight = meters.getOrElse(1) { 0f },
            limiterGainReductionDb = meters.getOrElse(2) { 0f },
            activeVoices = meters.getOrElse(3) { 0f }.toInt(),
            droppedRealtimeEvents = meters.getOrElse(4) { 0f }.toInt()
        )
    }

    private fun nativeResult(ok: Boolean): Boolean {
        if (ok) {
            statusChanged(null)
            return true
        }
        statusChanged(engine.nativeLastTextError().ifBlank { "Native sampler operation failed" })
        return false
    }

    private fun fail(message: String): Boolean {
        statusChanged(message)
        return false
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        started.set(false)
        midi.close()
        runtime.close()
    }
}
