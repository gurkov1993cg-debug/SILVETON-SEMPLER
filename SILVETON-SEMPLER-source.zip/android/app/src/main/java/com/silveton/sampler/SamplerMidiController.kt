package com.silveton.sampler

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.HandlerThread
import android.os.Process

/**
 * MIDI input/merge layer for SILVETON SAMPLER.
 *
 * Every physical/virtual MIDI output port is accepted, so a keyboard and a
 * separate breath controller can be connected at the same time. All packets
 * are serialized onto one urgent-audio HandlerThread before entering the
 * native engine. This preserves the native realtime event queue's single
 * producer contract even when Android delivers several USB MIDI devices from
 * different Binder threads.
 */
class SamplerMidiController(
    context: Context,
    private val engine: NativeSamplerEngine,
    private val connectionChanged: (Int) -> Unit = {},
    private val statusChanged: (String?) -> Unit = {}
) : AutoCloseable {
    private val midiManager = context.getSystemService(MidiManager::class.java)
    private val thread = HandlerThread("SilvetonSamplerMidi", Process.THREAD_PRIORITY_URGENT_AUDIO).apply { start() }
    private val handler = Handler(thread.looper)
    private val connections = LinkedHashMap<Int, DeviceConnection>()
    @Volatile private var running = false
    @Volatile private var closed = false

    private data class PortConnection(
        val port: MidiOutputPort,
        val receiver: MidiReceiver,
        val parser: MidiByteStreamParser
    )

    private data class DeviceConnection(
        val device: MidiDevice,
        val ports: MutableList<PortConnection> = mutableListOf()
    )

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            handler.post { openDevice(info) }
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            handler.post { closeDevice(info.id) }
        }
    }

    fun start() {
        if (closed || running) return
        running = true
        midiManager.registerDeviceCallback(callback, handler)
        handler.post {
            midiManager.devices.forEach { openDevice(it) }
        }
    }

    private fun openDevice(info: MidiDeviceInfo) {
        if (!running || closed || connections.containsKey(info.id)) return
        val outputInfos = info.ports.filter { it.type == MidiDeviceInfo.PortInfo.TYPE_OUTPUT }
        if (outputInfos.isEmpty()) return
        midiManager.openDevice(info, { device ->
            if (device == null) {
                statusChanged("MIDI device ${info.id} could not be opened")
                return@openDevice
            }
            handler.post {
                if (!running || closed || connections.containsKey(info.id)) {
                    device.close()
                    return@post
                }
                val connection = DeviceConnection(device)
                outputInfos.forEach { portInfo ->
                    val port = device.openOutputPort(portInfo.portNumber) ?: return@forEach
                    lateinit var parser: MidiByteStreamParser
                    parser = MidiByteStreamParser { message -> dispatchMessage(message) }
                    val receiver = object : MidiReceiver() {
                        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
                            if (count <= 0 || closed) return
                            // Android may call this from Binder/MIDI service threads. Copy
                            // before posting because the source byte array is not ours.
                            val packet = data.copyOfRange(offset, offset + count)
                            handler.post {
                                if (running && !closed) parser.feed(packet, 0, packet.size)
                            }
                        }
                    }
                    port.connect(receiver)
                    connection.ports += PortConnection(port, receiver, parser)
                }
                if (connection.ports.isEmpty()) {
                    device.close()
                } else {
                    connections[info.id] = connection
                    connectionChanged(connections.size)
                    statusChanged(null)
                }
            }
        }, handler)
    }

    private fun dispatchMessage(message: ByteArray) {
        if (message.isEmpty()) return
        val status = message[0].toInt() and 0xFF
        if (status >= 0xF0) return // realtime/system/SysEx are not sampler-note events here
        val kind = status and 0xF0
        val data1 = if (message.size > 1) message[1].toInt() and 0x7F else 0
        val data2 = if (message.size > 2) message[2].toInt() and 0x7F else 0
        when (kind) {
            0x80, 0x90, 0xB0, 0xD0, 0xE0 -> {
                if (!engine.nativeMidi(status, data1, data2)) {
                    statusChanged("Sampler MIDI realtime queue overflow")
                }
            }
        }
    }

    private fun closeDevice(id: Int) {
        val connection = connections.remove(id) ?: return
        connection.ports.forEach { p ->
            try { p.port.disconnect(p.receiver) } catch (_: Throwable) {}
            try { p.port.close() } catch (_: Throwable) {}
            p.parser.reset()
        }
        try { connection.device.close() } catch (_: Throwable) {}
        connectionChanged(connections.size)
    }

    fun panic() {
        handler.post { engine.nativePanic() }
    }

    override fun close() {
        if (closed) return
        closed = true
        running = false
        try { midiManager.unregisterDeviceCallback(callback) } catch (_: Throwable) {}
        handler.post {
            connections.keys.toList().forEach { closeDevice(it) }
            thread.quitSafely()
        }
    }
}
