package com.silveton.sampler

import android.os.Handler
import android.os.Looper

/**
 * Small lifecycle owner for the native sampler audio stream.
 * Recovery never runs inside the AAudio callback; errors merely set a native
 * flag and this main-thread poll asks nativeAudioRecover() to reopen safely.
 */
class SamplerRuntime(
    val engine: NativeSamplerEngine = NativeSamplerEngine(),
    private val statusChanged: (String?) -> Unit = {}
) : AutoCloseable {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var closed = false

    private val recoveryPoll = object : Runnable {
        override fun run() {
            if (closed) return
            if (engine.nativeAudioNeedsRecovery()) {
                val error = engine.nativeLastAudioError()
                if (!engine.nativeAudioRecover()) {
                    statusChanged("Audio recovery failed: $error ${engine.nativeLastTextError()}")
                } else {
                    statusChanged(null)
                }
            }
            handler.postDelayed(this, 500L)
        }
    }

    fun start(): Boolean {
        if (closed) return false
        if (!engine.nativeAudioOpen()) {
            statusChanged(engine.nativeLastTextError().ifBlank { "Audio open failed (${engine.nativeLastAudioError()})" })
            return false
        }
        if (!engine.nativeAudioStart()) {
            statusChanged(engine.nativeLastTextError().ifBlank { "Audio start failed (${engine.nativeLastAudioError()})" })
            return false
        }
        if (!running) {
            running = true
            handler.post(recoveryPoll)
        }
        statusChanged(null)
        return true
    }

    fun suspendAudio() {
        if (closed) return
        engine.nativeAudioStop()
    }

    fun resumeAudio(): Boolean {
        if (closed) return false
        if (engine.nativeAudioNeedsRecovery() && !engine.nativeAudioRecover()) return false
        return engine.nativeAudioStart()
    }

    override fun close() {
        if (closed) return
        closed = true
        running = false
        handler.removeCallbacks(recoveryPoll)
        engine.nativePanic()
        engine.nativeAudioStop()
        engine.nativeAudioClose()
    }
}
