#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/SincInterpolator.h"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>

namespace silveton::sampler {

enum class EventType : std::uint8_t {
    NoteOn,
    NoteOff,
    ControlChange,
    PitchBend,
    ChannelPressure,
    Panic
};

struct RealtimeEvent {
    EventType type{EventType::NoteOn};
    std::uint8_t channel{0};
    std::uint8_t data1{0};
    std::uint8_t data2{0};
    std::int16_t pitchBend{0};
};

class RealtimeEventQueue {
public:
    static constexpr std::size_t kCapacity = 2048U;

    bool push(const RealtimeEvent& event) noexcept;
    bool pop(RealtimeEvent& event) noexcept;
    [[nodiscard]] std::uint64_t droppedCount() const noexcept { return dropped_.load(std::memory_order_relaxed); }
    void clear() noexcept;

private:
    std::array<RealtimeEvent, kCapacity> data_{};
    std::atomic<std::size_t> write_{0U};
    std::atomic<std::size_t> read_{0U};
    std::atomic<std::uint64_t> dropped_{0U};
};

struct MeterSnapshot {
    float peakLeft{0.0F};
    float peakRight{0.0F};
    float limiterGainReductionDb{0.0F};
    std::uint32_t activeVoices{0U};
    std::uint64_t droppedEvents{0U};
};

class SamplerEngine {
public:
    SamplerEngine();
    ~SamplerEngine();

    SamplerEngine(const SamplerEngine&) = delete;
    SamplerEngine& operator=(const SamplerEngine&) = delete;

    void prepare(double sampleRate, std::uint32_t maximumBlockFrames);
    void reset() noexcept;

    // State replacement is intentionally an out-of-audio-thread operation.
    // The Android wrapper stops the stream before replacing the immutable graph.
    void setState(std::shared_ptr<const EngineState> state) noexcept;
    [[nodiscard]] std::shared_ptr<const EngineState> state() const noexcept { return state_; }

    void setInterpolationQuality(InterpolationQuality quality) noexcept { interpolator_.setQuality(quality); }
    [[nodiscard]] InterpolationQuality interpolationQuality() const noexcept { return interpolator_.quality(); }

    bool postNoteOn(std::uint8_t channel, std::uint8_t key, std::uint8_t velocity) noexcept;
    bool postNoteOff(std::uint8_t channel, std::uint8_t key, std::uint8_t velocity = 0U) noexcept;
    bool postControlChange(std::uint8_t channel, std::uint8_t cc, std::uint8_t value) noexcept;
    bool postPitchBend(std::uint8_t channel, std::int16_t value) noexcept;
    bool postChannelPressure(std::uint8_t channel, std::uint8_t value) noexcept;
    bool postPanic() noexcept;

    // Stereo interleaved float output. No allocations or locks occur here.
    void render(float* interleavedStereo, std::uint32_t frames) noexcept;

    [[nodiscard]] MeterSnapshot meters() const noexcept;
    [[nodiscard]] std::uint32_t activeVoiceCount() const noexcept;
    [[nodiscard]] std::uint64_t droppedEventCount() const noexcept { return events_.droppedCount(); }

public:
    struct Impl; // internal DSP state; exposed only for translation-unit helpers

private:
    std::unique_ptr<Impl> impl_;
    std::shared_ptr<const EngineState> state_;
    RealtimeEventQueue events_;
    SincInterpolator interpolator_;
};

} // namespace silveton::sampler
