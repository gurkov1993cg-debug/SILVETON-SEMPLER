#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ "$(uname -s)" != "Darwin" ]; then
    echo "This command builds the Intel macOS application. Run it on your Mac."
    exit 1
fi
if [ -x /usr/bin/python ]; then
    sampler_python=/usr/bin/python
elif command -v python3 >/dev/null 2>&1; then
    sampler_python=$(command -v python3)
else
    echo "Python 2.7 or Python 3 is required. High Sierra includes /usr/bin/python."
    exit 1
fi
if "$sampler_python" scripts/build_mac.py; then
    echo "SILVETON SAMPLER.app was built successfully."
    open "build-mac/SILVETON SAMPLER.app"
else
    echo "Build stopped. The log is in build-mac/build.log."
    read -r -p "Press Enter to close this window..." unused
    exit 1
fi
