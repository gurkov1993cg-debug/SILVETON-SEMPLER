// Real production renderer; link only the current release build libraries.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;
#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct ViewTestAccess {
    static void live(View& v) { v.goPage(View::Page::COMBI, View::MODE_LIVE); v.selectedUpper_ = 0; v.stripSound[0] = 0; }
    static void quick(View& v, int sound) { v.goPage(View::Page::COMBI, View::MODE_EDIT); v.editGroup_ = View::EG_VOICE; v.selectedUpper_ = 0; v.stripSound[0] = sound; }
    static void setup(View& v) { v.editGroup_ = View::EG_PARTTUNE; v.invalidate(); }
};
}

int main(int argc, char** argv) {
    try {
        CHECK(argc == 4);
        setFontDirectory(argv[1]); CHECK(fontsReady());
        setFixedClockForTests(1000);
        char temp[] = "/tmp/silveton-release-preview-XXXXXX";
        CHECK(::mkdtemp(temp));
        ControllerEnv env; env.dataDir = temp;
        SamplerAppController controller(env);
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(!controller.loadSoloModelFile(0, argv[2], 0));
        auto source = controller.soundSource(0, 0);
        CHECK(source.soloModel);
        CHECK(controller.putSoundSource(0, 1, source));
        CHECK(controller.setLayerParam(0, 0, 0, 1));
        CHECK(controller.setLayerParam(0, 0, 5, 500));
        CHECK(controller.setLayerParam(0, 0, 10, 18));
        CHECK(controller.setLayerParam(0, 0, 11, 210));
        CHECK(controller.setLayerParam(0, 0, 12, .64F));
        CHECK(controller.setLayerParam(0, 0, 13, 440));
        CHECK(controller.assignUpperSound(1, {0, 0, 9002, "SAW"}));
        CHECK(controller.assignUpperSound(6, {0, 0, 9005, "SINE"}));
        auto state = *controller.upperState(0);
        state.voiceMode = 2;
        state.portamentoSec = .03F;
        CHECK(controller.updateUpperMain(0, state));
        CHECK(controller.updateUpperTune(0, state));
        CHECK(controller.setUpperParam(0, 48, 12));
        CHECK(controller.setUpperTone(0, 0, 8));
        CHECK(controller.setUpperTone(0, 1, 120));
        CHECK(controller.setUpperTone(0, 2, .8F));
        CHECK(controller.setUpperTone(0, 3, 180));
        CHECK(controller.writeCombiToList(0, "PROBA 10") == 0);
        CHECK(controller.activateListEntry(0, 0, 0, 0));
        View view(controller); view.setSoftKeyboard(true); view.refreshAllForTests();
        Canvas canvas(1340, 800);
        const std::string out = argv[3];
        const auto render = [&](const char* filename) { view.draw(canvas); CHECK(writePng(out + "/" + filename, canvas)); };
        std::int64_t time = 1000;
        const auto tap = [&](float x, float y) {
            time += 1000; setFixedClockForTests(time);
            view.pointer(View::PointerAction::Down, x, y);
            view.pointer(View::PointerAction::Up, x, y);
            view.draw(canvas);
        };
        classic::ViewTestAccess::live(view); render("01_LIVE.png");
        classic::ViewTestAccess::quick(view, 0); render("02_QUICK_MAIN.png");
        tap(895.8F, 190); CHECK(view.selectedSoloSound() == 1);
        render("03_QUICK_LAYER.png");
        tap(1200, 642); CHECK(controller.layerParams(0, 0).at(5) == 501);
        tap(900, 642); CHECK(controller.layerParams(0, 0).at(5) == 500);
        classic::ViewTestAccess::setup(view); render("05_DECAY_PORTA_SETUP.png");
        classic::ViewTestAccess::quick(view, 1); view.draw(canvas);
        tap(1052, 642); CHECK(view.dialogOpen()); render("04_TOUCH_KEYPAD.png");
        std::puts("PASS production release libraries rendered LIVE, MAIN, L1 Tune500, scoped touch keypad and unique decay/portamento setup");
    } catch (const std::exception& e) { std::fprintf(stderr, "FAIL %s\n", e.what()); return 1; }
}
