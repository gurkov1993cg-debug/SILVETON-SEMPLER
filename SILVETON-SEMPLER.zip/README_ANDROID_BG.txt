SILVETON SAMPLER 2.3.0 — Android / Samsung SM-X130
versionCode 5 / com.silveton.sampler / ARM64 / Android 8.0+

БИЛД ПРЕЗ GITHUB
1. Замени SILVETON-SEMPLER.zip в главната папка на репото и направи Commit.
   Архивът съдържа silveton_pro_payload и scripts директно на първото ниво.
   Когато ZIP присъства, workflow изгражда него, а не старата папка в репото.
2. За новата проверка на APK и постоянния ключ замени и файла в репото
   .github/workflows/silveton-apk.yml с този от архива. GitHub изпълнява
   workflow от репото; файлът вътре в ZIP не го заменя автоматично.
3. Отвори Actions → SILVETON Sampler APK. След успешен билд отвори
   Releases → latest и изтегли SILVETON-SAMPLER-SM-X130.apk.

Това е архив с изходния код за реален тест на таблета. Тук не се твърди,
че има локално изграден и подписан APK. Самият GitHub билд проверява
готовия пакет преди публикуване: пакет и версия, NativeActivity, ARM64
библиотека, шестте шрифта, 16 KiB подравняване и валиден подпис.
APK_RESULT.json описва проверката на пакета, а не тест с реален таблет.

За повторно пакетиране използвай scripts/package_source.py. ZIP използва
фиксирани часови отметки; новият workflow нормализира и разархивираните
файлове, за да не се получава „build.ninja still dirty after 100 tries“.

ПОДПИС И ОБНОВЯВАНЕ НА ИНСТАЛИРАНАТА ПРОГРАМА
Android изисква същия ключ за обновяване върху инсталиран APK.
За постоянен ключ добави четирите Repository secrets в GitHub:

SILVETON_ANDROID_KEYSTORE_BASE64 — Base64 на съществуващия частен keystore
SILVETON_ANDROID_KEYSTORE_PASSWORD — парола на keystore
SILVETON_ANDROID_KEY_ALIAS — alias на ключа
SILVETON_ANDROID_KEY_PASSWORD — парола на ключа

Всичките четири стойности трябва да са зададени заедно. Непълна настройка
спира билда. Ключът се декодира временно на runner-а и се изтрива след
билда; не влиза в изходния ZIP, APK, кеша или публикуваните файлове.
Не качвай keystore или пароли в репото или в този архив.

Без тези secrets остава CI debug подпис за тест. Workflow показва изрично
предупреждение, защото следващ runner може да използва различен ключ.
Такъв APK може да бъде отказан като обновяване на вече инсталирана версия.
Оригиналният ключ на стар APK не може да бъде възстановен от сертификата
или от APK файла. В тази задача не е създаван и не е сменян частен ключ.
Преди обновяване запази SET и копие на важните файлове в обща папка.

НА ТАБЛЕТА
Запазен е съществуващият Direct ALSA режим за рутнатия SM-X130.
Разреши root и достъп до всички файлове при първото пускане.
Компилация и проверка на пакет не доказват звук, MIDI, root достъп или
латентност на устройството — тези проверки се правят на самия таблет.

ЗВУЦИ И SET
Подробното управление, зареждането на обучен .svsolo модел, записът на
цял SET и вносът на отделна бленда от друг SET са описани в WORKFLOW_BG.txt.
Записвай SET след промените и запазвай копие извън личната папка на app-а.

АЛТЕРНАТИВЕН ЛОКАЛЕН БИЛД
Gradle проектът е silveton_pro_payload/android. Използва SDK 35,
Build Tools 35.0.0, NDK 27.2.12479018, CMake 3.22.1 и Java 17.
scripts/build_android.py изгражда същата C++ NativeActivity без Gradle
или javac. Нужни са SDK, NDK, Python 3, CMake, Java за apksigner и твоят
съществуващ частен ключ. Скриптът не генерира ключ.

python3 scripts/build_android.py --sdk /path/to/sdk --ndk /path/to/ndk \
  --keystore /private/silveton-android.p12 \
  --password-file /private/password.txt

При този пример alias е silveton, а паролата на ключа трябва да съвпада
с паролата на keystore. За друг alias добави --alias YOUR_ALIAS.
Скриптът записва APK_RESULT.json след успешна проверка на готовия пакет.
