SILVETON SAMPLER 2.3.0 — ИЗХОДЕН ПРОЕКТ ЗА ТЕСТ НА ТАБЛЕТ

Билд: README_ANDROID_BG.txt. Пълен текущ отчет: EVIDENCE/RELEASE_AUDIT/.
GitHub изгражда SILVETON-SEMPLER.zip от главната папка на репото.
За новия workflow замени и .github/workflows/silveton-apk.yml в репото
с файла от архива. Самият ZIP не променя автоматично GitHub workflow.

Избери UPPER/LOWER и MAIN/L1–L4 → SOUND EDIT → QUICK CONTROLS.
На един екран са ADSR, POLY/MONO/LEGATO, PORTAMENTO, OCTAVE,
TRANSPOSE, TUNE и PITCH BEND. Големи +/− и точен цифров вход.
SOURCE / WAVE е за звука/синта и CHARACTER / STEREO с точката.
Името на звука отваря един общ списък; LOAD .svsolo… е в него.
Няма втори engine или втори комплект ADSR/Tune/Bend за SOLO.
MIXER пази ниво/панорама/FX/insert/routing и явния LINK.
DECAY / PORTA SETUP пази Even Decay и глобалните Balance/Near Note.

SAVE → UPDATE CURRENT LIST POSITION записва редакциите в блендата.
SAVE TO LIST записва на избрана позиция. SAVE SET FILE пази целия SET.
Моделите се вграждат в SET; банковите семпли остават в банката.
LIST → IMPORT FROM SET внася избрани бленди с избор на цел и потвърждение.

Ръководство: WORKFLOW_BG.txt. Реален тест: TABLET_TEST_BG.txt.
Актуалните изображения от C++ renderer са в EVIDENCE/RELEASE_AUDIT/.
UI_PREVIEW съдържа текущите екрани; другите EVIDENCE папки са исторически.
Тук няма нов подписан APK или твърдение за тест на физически таблет,
RME или измерена латентност. GitHub изгражда APK за реалния тест.
Mac: BUILD_SILVETON_MAC.command; x86_64/macOS10.13/Xcode10.1.
