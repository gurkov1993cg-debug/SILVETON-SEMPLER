SILVETON SAMPLER — iMac 2011
macOS 10.13.6 High Sierra / Intel x86_64 / Xcode 10.1

1. Разархивирай SILVETON-SEMPLER.zip в отделна папка.
2. Стартирай BUILD_SILVETON_MAC.command с двоен клик.
   При блокиране от macOS: десен бутон → Open / Отвори.
3. След успешен build се отваря SILVETON SAMPLER.app.
   После можеш да пускаш директно build-mac/SILVETON SAMPLER.app.
4. Избери UPPER/LOWER → M/L1–L4 → името на звука.
   Отваря се директно общият списък. Избери звук и OK.
   За обучен файл натисни LOAD .svsolo… в същия списък.
5. SOUND EDIT редактира това място. SAVE → SAVE TO LIST записва блендата;
   SAVE SET FILE запазва всички бленди и вградените обучени модели.

Необходими са Xcode 10.1 и неговите command-line tools.
Не се изтеглят зависимости. Не трябват Homebrew, CMake, JUCE или Metal.
Приложението е standalone. Това не е VST3 плъгин.

При грешка съобщението остава в Terminal; пълният лог е build-mac/build.log.
Последното успешно изградено .app се пази до успешен нов build.
Нативната компилация и RME не са проверени в Linux средата.
Старият готов SET в PRESETS може да се отвори и неговите SOLO места да
се прехвърлят чрез MOVE SOLO FROM OLD SET… от SOUND MENU на избраното място.
Преди LOAD SET запиши текущата си работа.

PITCH BEND: SOUND EDIT → VOICE / PORTA → RANGE. Натисни числото
и въведи 0–24 полутона; 0 е OFF. Запиши блендата и SET след промяната.
