SILVETON SAMPLER 2.1.0 — Android / Samsung Galaxy Tab A11 SM-X130

ГОТОВИЯТ ФАЙЛ ЗА ИНСТАЛИРАНЕ
SILVETON-SAMPLER-SM-X130.apk — ARM64, Android 8.0 или по-нов.
Тази версия използва съществуващия Direct ALSA режим за рутнатия SM-X130.
Разреши root и достъп до всички файлове при първото пускане.

ПРЕДИ СМЯНА НА СТАРАТА ВЕРСИЯ
Запази SET от старата програма в обща папка на таблета и направи копие.
Този APK е с нов постоянен ключ за подписване. Старият ключ не беше наличен.
Обновяване върху стар APK с друг подпис може да бъде отказано от Android.
Не изтривай старата програма, преди SET и важните файлове да са копирани
извън личната ѝ папка. Изтриването на приложението изтрива личните му данни.

ОБУЧЕНА БЛЕНДА
1. Копирай .svsolo файла в Download на таблета.
2. Избери Upper и мястото за звук: MAIN или L1–L4.
3. В избора на звук натисни LOAD TRAINED .svsolo и избери файла.
   Папките се отварят с [+], връщането нагоре е с [..].
4. Отваря се редакторът на същото място с CHARACTER / STEREO.
   Настройките за bend, гласове, portamento, филтри и ефекти са в Upper.
5. Моделът се включва в SET при запис. При грешка в автоматичния запис
   програмата показва съобщение; запази SET ръчно.

В Upper има един общ списък за избор на звук. Запазени са текущият изглед,
съществуващите осцилатори, CHARACTER и поправката за общия pitch bend.
Обработката на звуковите места и зареждането на .svsolo са общ код за Mac
и Android: host/src/SoundSourceHost.inc и SoundSourceFacade.inc.
Direct ALSA, root настройките и raw MIDI остават в Android host.

ПРОВЕРЕНО ПРИ ИЗРАБОТКАТА
Реална NDK r27c ARM64 компилация и свързване, подпис на APK v2/v3,
16 KiB подравняване, налични NativeActivity библиотека и шрифтове.
Петте проверки за звукови места, модели, workflow и bend преминаха.
Не е извършен тест със звук, MIDI или измерване на латентност на таблет.

ПОВТОРЕН БИЛД
Обичайният Android Gradle проект остава в silveton_pro_payload/android.
Алтернативният scripts/build_android.py изгражда и подписва същата
NativeActivity с CMake, NDK r27c, SDK Platform 35, Build Tools 35.0.0,
Python 3 и Java runtime за apksigner. Не изисква javac или Gradle.
Пример (пътищата към SDK/NDK/ключа са локални):

python3 scripts/build_android.py --sdk /path/to/sdk --ndk /path/to/ndk \
  --keystore /private/silveton-android.p12 \
  --password-file /private/password.txt

Ключът и паролата не се намират в изходния код или APK.
Пази отделния SILVETON-ANDROID-SIGNING-PRIVATE.zip за следващи обновявания.
Не го публикувай. CI с временен debug ключ няма същия подпис като този APK.
