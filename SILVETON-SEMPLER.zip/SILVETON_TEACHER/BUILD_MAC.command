#!/bin/bash
# SILVETON TEACHER - builds the window (.app) and the Terminal tool (teach) on the iMac 2011 / macOS 10.13 with Xcode 10.
set -e
cd "$(dirname "$0")"
echo "=============================================="
echo " SILVETON TEACHER - iMac 2011 / macOS 10.13"
echo "=============================================="
if ! xcrun --find clang++ >/dev/null 2>&1; then
 echo "ГРЕШКА: Няма Xcode Command Line Tools. Инсталирай Xcode 10.1 или Command Line Tools." >&2
 exit 1
fi
APP="$PWD/SILVETON TEACHER.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>SILVETON TEACHER</string>
<key>CFBundleExecutable</key><string>SilvetonTeacher</string>
<key>CFBundleIdentifier</key><string>bg.silveton.teacher</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.0.0</string>
<key>CFBundleVersion</key><string>1</string>
<key>LSMinimumSystemVersion</key><string>10.13</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
echo "1/2 прозорецът ..."
xcrun clang++ -std=c++14 -O2 -arch x86_64 -mmacosx-version-min=10.13 -stdlib=libc++ -fobjc-arc \
  -I"$PWD/source" "$PWD/source/MacApp.mm" "$PWD/source/Teacher.cpp" \
  -framework Cocoa -framework AppKit -framework AudioToolbox -framework CoreAudio -framework CoreMIDI -framework CoreFoundation \
  -o "$APP/Contents/MacOS/SilvetonTeacher"
echo "2/2 teach за Терминала ..."
xcrun clang++ -std=c++14 -O2 -arch x86_64 -mmacosx-version-min=10.13 -stdlib=libc++ \
  -I"$PWD/source" "$PWD/source/teach_cli.cpp" "$PWD/source/Teacher.cpp" -o "$PWD/teach"
echo "ГОТОВО: $APP   и   $PWD/teach"
open "$APP"
