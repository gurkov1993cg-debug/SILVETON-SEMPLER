// SILVETON TEACHER - the window on the Mac (Cocoa, Objective-C++). Everything it knows is in Teacher.cpp; this file shows it,
// and plays it: the MIDI keyboard (CoreMIDI) drives the LivePlayer, the sound card (CoreAudio) asks it for samples.
// Built for macOS 10.13 (iMac 2011): no API newer than that.
#import <Cocoa/Cocoa.h>
#import <AudioToolbox/AudioToolbox.h>
#import <CoreMIDI/CoreMIDI.h>
#include "Teacher.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstring>
#include <exception>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

static NSColor* panelColor() { return [NSColor colorWithCalibratedRed:.115 green:.14 blue:.19 alpha:1]; }
static NSColor* windowColor() { return [NSColor colorWithCalibratedRed:.075 green:.095 blue:.135 alpha:1]; }
static NSColor* accent() { return [NSColor colorWithCalibratedRed:.32 green:.78 blue:.81 alpha:1]; }
static NSColor* warm() { return [NSColor colorWithCalibratedRed:.99 green:.69 blue:.36 alpha:1]; }
static NSColor* bad() { return [NSColor colorWithCalibratedRed:1 green:.54 blue:.50 alpha:1]; }
static NSString* S(const std::string& s) { return [NSString stringWithUTF8String:s.c_str()]; }
static NSTextField* textLabel(NSString* s, NSRect rect, CGFloat size, BOOL strong) {
    NSTextField* f = [[NSTextField alloc] initWithFrame:rect];
    [f setStringValue:s]; [f setBordered:NO]; [f setEditable:NO]; [f setSelectable:NO]; [f setDrawsBackground:NO];
    [f setTextColor:strong ? [NSColor whiteColor] : [NSColor colorWithCalibratedWhite:.73 alpha:1]];
    [f setFont:strong ? [NSFont boldSystemFontOfSize:size] : [NSFont systemFontOfSize:size]];
    return f;
}
static NSButton* actionButton(NSString* title, NSRect rect, id target, SEL action) {
    NSButton* b = [[NSButton alloc] initWithFrame:rect]; [b setTitle:title]; [b setTarget:target]; [b setAction:action];
    [b setBezelStyle:NSBezelStyleRounded]; [b setFont:[NSFont boldSystemFontOfSize:13]];
    return b;
}

// ---------------------------------------------------------------- the live sound: one player for the whole program
static silveton::teacher::LivePlayer* gLive = nullptr;
static const double kLiveRate = 48000.0;

static OSStatus audioRender(void* inRefCon, AudioUnitRenderActionFlags* flags, const AudioTimeStamp* ts, UInt32 bus, UInt32 frames, AudioBufferList* io) {
    (void)inRefCon; (void)flags; (void)ts; (void)bus;
    float* l = io->mNumberBuffers > 0 ? (float*)io->mBuffers[0].mData : nullptr;
    float* r = io->mNumberBuffers > 1 ? (float*)io->mBuffers[1].mData : nullptr;
    if (!l) return noErr;
    if (gLive) gLive->render(l, r, (int)frames);
    else { std::memset(l, 0, frames * sizeof(float)); if (r) std::memset(r, 0, frames * sizeof(float)); }
    return noErr;
}
// the keys from the MIDI thread: note on / off, pitch bend (+-2 semitones), all notes off
static void midiRead(const MIDIPacketList* list, void* refCon, void* srcRefCon) {
    (void)refCon; (void)srcRefCon;
    if (!gLive) return;
    const MIDIPacket* p = &list->packet[0];
    for (UInt32 i = 0; i < list->numPackets; ++i) {
        int status = 0; int data[2] = {0, 0}; int have = 0;
        for (UInt16 j = 0; j < p->length; ++j) {
            const Byte b = p->data[j];
            if (b >= 0xF8) continue;                 // clock and the like
            if (b >= 0x80) { status = b; have = 0; if (b >= 0xF0) status = 0; continue; }
            if (status == 0) continue;
            data[have++] = b;
            const int type = status & 0xF0;
            const int need = (type == 0xC0 || type == 0xD0) ? 1 : 2;
            if (have < need) continue;
            have = 0;
            if (type == 0x90 && data[1] > 0) gLive->noteOn(data[0], data[1]);
            else if (type == 0x80 || type == 0x90) gLive->noteOff(data[0]);
            else if (type == 0xE0) gLive->pitchBend(((data[1] << 7) | data[0]) / 8192.0 * 2.0 - 2.0);
            else if (type == 0xB0 && (data[0] == 123 || data[0] == 120)) gLive->allNotesOff();
        }
        p = MIDIPacketNext(p);
    }
}

// ---------------------------------------------------------------- the harmonics of the steady part, as bars
@interface TeachBarsView : NSView { std::vector<float> db; }
- (void)setBars:(const std::vector<float>&)values;
@end
@implementation TeachBarsView
- (void)setBars:(const std::vector<float>&)values { db = values; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [[NSColor colorWithCalibratedRed:.085 green:.11 blue:.155 alpha:1] setFill]; NSRectFill(self.bounds);
    const CGFloat w = self.bounds.size.width, h = self.bounds.size.height;
    [[NSColor colorWithCalibratedWhite:.28 alpha:.8] setStroke];
    for (int k = 1; k < 4; k++) { NSBezierPath* p = [NSBezierPath bezierPath]; [p moveToPoint:NSMakePoint(0, h * k / 4.)]; [p lineToPoint:NSMakePoint(w, h * k / 4.)]; [p setLineWidth:.45]; [p stroke]; }
    if (db.empty()) return;
    const CGFloat bw = w / (CGFloat)db.size();
    for (size_t i = 0; i < db.size(); ++i) {
        const CGFloat v = std::max(0.0F, std::min(1.0F, (db[i] + 60.0F) / 60.0F));
        NSRect r = NSMakeRect(bw * i + 1, 0, std::max((CGFloat)1, bw - 2), h * v);
        [(i % 2 == 0 ? accent() : [NSColor colorWithCalibratedRed:.22 green:.58 blue:.62 alpha:1]) setFill]; NSRectFill(r);
    }
}
@end

// ---------------------------------------------------------------- the loudness (dB) and the pitch (cents) in time
@interface TeachCurveView : NSView { std::vector<float> level; std::vector<float> pitch; }
- (void)setLevel:(const std::vector<float>&)l pitch:(const std::vector<float>&)p;
@end
@implementation TeachCurveView
- (void)setLevel:(const std::vector<float>&)l pitch:(const std::vector<float>&)p { level = l; pitch = p; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [[NSColor colorWithCalibratedRed:.085 green:.11 blue:.155 alpha:1] setFill]; NSRectFill(self.bounds);
    const CGFloat w = self.bounds.size.width, h = self.bounds.size.height;
    [[NSColor colorWithCalibratedWhite:.28 alpha:.8] setStroke];
    { NSBezierPath* axis = [NSBezierPath bezierPath]; [axis moveToPoint:NSMakePoint(0, h / 2)]; [axis lineToPoint:NSMakePoint(w, h / 2)]; [axis setLineWidth:.45]; [axis stroke]; }
    if (level.empty()) return;
    const size_t n = level.size();
    [warm() setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath]; [p setLineWidth:1.2];
    for (size_t i = 0; i < n; i++) {
        const CGFloat x = w * i / std::max<size_t>(1, n - 1);
        const CGFloat y = h * std::max(0.0F, std::min(1.0F, (level[i] + 60.0F) / 60.0F));
        if (i == 0) [p moveToPoint:NSMakePoint(x, y)]; else [p lineToPoint:NSMakePoint(x, y)];
    }
    [p stroke];
    if (pitch.size() != n) return;
    [accent() setStroke];
    NSBezierPath* q = [NSBezierPath bezierPath]; [q setLineWidth:1.0]; bool pen = false;
    for (size_t i = 0; i < n; i++) {
        if (pitch[i] == 0.0F && (i == 0 || pitch[i - 1] == 0.0F)) { pen = false; continue; }
        const CGFloat x = w * i / std::max<size_t>(1, n - 1);
        const CGFloat y = h / 2 + (h * .45) * std::max(-1.0F, std::min(1.0F, pitch[i] / 50.0F));
        if (!pen) { [q moveToPoint:NSMakePoint(x, y)]; pen = true; } else [q lineToPoint:NSMakePoint(x, y)];
    }
    [q stroke];
}
@end

// ---------------------------------------------------------------- the window
struct ListRow {
    silveton::teacher::Input input;
    std::string name;
    std::string slot;                 // the player's own word for what this is
    int zones = 1;
    bool on = true;
    bool studied = false;
    std::shared_ptr<silveton::teacher::Sound> sound;
    std::shared_ptr<silveton::teacher::SoundStudy> study;
    std::string error;
};
static const CGFloat L = 360;

@interface TeachController : NSObject<NSApplicationDelegate, NSTableViewDataSource, NSTableViewDelegate> {
    NSWindow* window;
    NSTableView* table;
    NSTextField* listInfo;
    NSTextField* fileInfo;
    NSTextField* statusInfo;
    NSTextField* zoneInfo;
    NSTextField* midiInfo;
    NSTextField* slotField;
    NSPopUpButton* zoneMenu;
    NSPopUpButton* keyMenu;
    NSPopUpButton* liveMenu;
    TeachBarsView* bars;
    TeachCurveView* curves;
    NSTextView* reportView;
    NSSlider* brightSlider;
    NSSlider* breathSlider;
    NSTextField* brightInfo;
    NSTextField* breathInfo;
    NSButton* vibratoBox;
    NSButton* lifeBox;
    NSSound* sound;
    std::vector<ListRow> rows;
    NSInteger current;
    // live
    AudioComponentInstance audioUnit;
    MIDIClientRef midiClient;
    MIDIPortRef midiPort;
    std::set<MIDIEndpointRef> midiConnected;
}
- (void)browse:(id)sender;
- (void)studyAll:(id)sender;
- (void)exportAll:(id)sender;
- (void)playOriginal:(id)sender;
- (void)playLearned:(id)sender;
- (void)stop:(id)sender;
- (void)zoneChanged:(id)sender;
- (void)knobChanged:(id)sender;
- (void)liveModeChanged:(id)sender;
- (void)connectMidi:(id)sender;
- (void)slotEntered:(id)sender;
- (void)tickAll:(id)sender;
- (void)tickNone:(id)sender;
- (void)clearList:(id)sender;
- (void)fillZoneMenu;
- (void)showCurrent;
- (void)studyRow:(ListRow&)r;
- (void)handToLive;
@end

static void midiNotify(const MIDINotification* message, void* refCon) {
    if (message->messageID != kMIDIMsgSetupChanged) return;
    TeachController* c = (__bridge TeachController*)refCon;
    dispatch_async(dispatch_get_main_queue(), ^{ [c connectMidi:nil]; });
}

@implementation TeachController
- (void)setStatus:(NSString*)s error:(BOOL)isError { [statusInfo setStringValue:s]; [statusInfo setTextColor:isError ? bad() : accent()]; }
- (void)showError:(NSString*)message {
    [self setStatus:message error:YES];
    NSAlert* alert = [[NSAlert alloc] init]; [alert setMessageText:@"SILVETON TEACHER"]; [alert setInformativeText:message]; [alert addButtonWithTitle:@"OK"]; [alert runModal];
}
- (int)tickedCount { int n = 0; for (const ListRow& r : rows) if (r.on) ++n; return n; }
- (void)refreshList {
    [table reloadData];
    int learned = 0; for (const ListRow& r : rows) if (r.studied && r.study && r.study->okZones > 0) ++learned;
    [listInfo setStringValue:[NSString stringWithFormat:@"СПИСЪК · %d · отметнати %d · научени %d", (int)rows.size(), [self tickedCount], learned]];
}
// ---- the sound card and the MIDI keyboard
- (void)startAudio {
    AudioComponentDescription d; std::memset(&d, 0, sizeof d);
    d.componentType = kAudioUnitType_Output; d.componentSubType = kAudioUnitSubType_DefaultOutput; d.componentManufacturer = kAudioUnitManufacturer_Apple;
    AudioComponent comp = AudioComponentFindNext(NULL, &d);
    if (!comp) { [self setStatus:@"Няма изход за звук (AudioUnit)." error:YES]; return; }
    if (AudioComponentInstanceNew(comp, &audioUnit) != noErr) { [self setStatus:@"Звуковият изход не се отвори." error:YES]; return; }
    AudioStreamBasicDescription f; std::memset(&f, 0, sizeof f);
    f.mSampleRate = kLiveRate; f.mFormatID = kAudioFormatLinearPCM; f.mFormatFlags = kAudioFormatFlagsNativeFloatPacked | kAudioFormatFlagIsNonInterleaved;
    f.mChannelsPerFrame = 2; f.mBitsPerChannel = 32; f.mBytesPerFrame = 4; f.mBytesPerPacket = 4; f.mFramesPerPacket = 1;
    AudioUnitSetProperty(audioUnit, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Input, 0, &f, sizeof f);
    AURenderCallbackStruct cb; cb.inputProc = audioRender; cb.inputProcRefCon = NULL;
    AudioUnitSetProperty(audioUnit, kAudioUnitProperty_SetRenderCallback, kAudioUnitScope_Input, 0, &cb, sizeof cb);
    if (AudioUnitInitialize(audioUnit) != noErr || AudioOutputUnitStart(audioUnit) != noErr) { [self setStatus:@"Звуковият изход не тръгна." error:YES]; return; }
}
- (void)connectMidi:(id)sender {
    (void)sender;
    if (midiClient == 0) {
        if (MIDIClientCreate(CFSTR("SILVETON TEACHER"), midiNotify, (__bridge void*)self, &midiClient) != noErr) { [midiInfo setStringValue:@"MIDI: не се отвори"]; return; }
        if (MIDIInputPortCreate(midiClient, CFSTR("вход"), midiRead, NULL, &midiPort) != noErr) { [midiInfo setStringValue:@"MIDI: няма вход"]; return; }
    }
    NSMutableString* names = [NSMutableString string];
    const ItemCount n = MIDIGetNumberOfSources();
    for (ItemCount i = 0; i < n; ++i) {
        MIDIEndpointRef src = MIDIGetSource(i);
        if (src == 0) continue;
        if (midiConnected.find(src) == midiConnected.end()) { if (MIDIPortConnectSource(midiPort, src, NULL) == noErr) midiConnected.insert(src); }
        CFStringRef name = NULL;
        if (MIDIObjectGetStringProperty(src, kMIDIPropertyDisplayName, &name) == noErr && name) { if ([names length] > 0) [names appendString:@"  ·  "]; [names appendString:(__bridge_transfer NSString*)name]; }
    }
    if (n == 0) [midiInfo setStringValue:@"MIDI: няма клавиатура (включи я и натисни СВЪРЖИ)"];
    else [midiInfo setStringValue:[NSString stringWithFormat:@"MIDI: %@", names]];
}
// the live player gets the chosen sound and the knobs
- (void)handToLive {
    if (!gLive) return;
    if (current < 0 || (size_t)current >= rows.size() || !rows[(size_t)current].studied || !rows[(size_t)current].study || rows[(size_t)current].study->okZones == 0) { gLive->setSound(nullptr, nullptr); return; }
    const ListRow& r = rows[(size_t)current];
    gLive->setSound(r.study, r.sound);
    silveton::teacher::PreviewKnobs k;
    k.brightDbPerOctave = [brightSlider floatValue]; k.breathDb = [breathSlider floatValue];
    k.vibrato = [vibratoBox state] == NSOnState; k.life = [lifeBox state] == NSOnState;
    gLive->setKnobs(k);
    gLive->setOriginal([liveMenu indexOfSelectedItem] == 1);
}
- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification; current = -1; audioUnit = NULL; midiClient = 0; midiPort = 0;
    NSRect r = NSMakeRect(0, 0, 980 + L, 800);
    window = [[NSWindow alloc] initWithContentRect:r styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable) backing:NSBackingStoreBuffered defer:NO];
    [window center]; [window setTitle:@"SILVETON TEACHER — учителят на SILVETON SOLO"];
    [window setBackgroundColor:windowColor()]; [window makeKeyAndOrderFront:nil];
    NSView* c = [window contentView]; [c setWantsLayer:YES];
    [c addSubview:textLabel(@"SILVETON   /   TEACHER", NSMakeRect(28, 746, 690, 37), 26, YES)];
    [c addSubview:textLabel(@"Слуша всеки семпъл на всеки KMP и записва какво е чул: SILVETON_OSC.sv за таблета + SILVETON_OSC.txt за теб. Цъкни в СЛОТ и напиши какво е.", NSMakeRect(30, 722, 1280, 23), 13, NO)];

    // the LIST (left)
    listInfo = textLabel(@"СПИСЪК · 0", NSMakeRect(20, 672, L - 30, 22), 12, YES); [c addSubview:listInfo];
    NSScrollView* sv = [[NSScrollView alloc] initWithFrame:NSMakeRect(20, 134, L - 30, 534)];
    [sv setHasVerticalScroller:YES]; [sv setBorderType:NSBezelBorder];
    table = [[NSTableView alloc] initWithFrame:NSMakeRect(0, 0, L - 34, 534)];
    NSTableColumn* cOn = [[NSTableColumn alloc] initWithIdentifier:@"on"]; [cOn setWidth:24]; [[cOn headerCell] setStringValue:@"✓"];
    NSButtonCell* box = [[NSButtonCell alloc] init]; [box setButtonType:NSButtonTypeSwitch]; [box setTitle:@""]; [cOn setDataCell:box];
    NSTableColumn* cName = [[NSTableColumn alloc] initWithIdentifier:@"name"]; [cName setWidth:118]; [[cName headerCell] setStringValue:@"ЗВУК"]; [cName setEditable:NO];
    NSTableColumn* cSlot = [[NSTableColumn alloc] initWithIdentifier:@"slot"]; [cSlot setWidth:96]; [[cSlot headerCell] setStringValue:@"СЛОТ (пиши)"]; [cSlot setEditable:YES];
    NSTableColumn* cInfo = [[NSTableColumn alloc] initWithIdentifier:@"info"]; [cInfo setWidth:78]; [[cInfo headerCell] setStringValue:@"СЪСТОЯНИЕ"]; [cInfo setEditable:NO];
    [table addTableColumn:cOn]; [table addTableColumn:cName]; [table addTableColumn:cSlot]; [table addTableColumn:cInfo];
    [table setBackgroundColor:panelColor()]; [table setRowHeight:20];
    [table setDataSource:self]; [table setDelegate:self];
    [sv setDocumentView:table]; [c addSubview:sv];
    // the SLOT of the chosen row: type here and press Enter (the cell in the list can be edited with a double click too)
    [c addSubview:textLabel(@"СЛОТ на избрания (пиши + Enter):", NSMakeRect(20, 106, L - 30, 20), 12, YES)];
    slotField = [[NSTextField alloc] initWithFrame:NSMakeRect(20, 80, L - 30, 24)];
    [slotField setEditable:YES]; [slotField setBezeled:YES]; [slotField setFont:[NSFont systemFontOfSize:13]];
    [slotField setPlaceholderString:@"напр. ЦИГУЛКА, СИНТ ЛИЙД, КАВАЛ"];
    [slotField setTarget:self]; [slotField setAction:@selector(slotEntered:)]; [c addSubview:slotField];
    [c addSubview:actionButton(@"ВСИЧКИ", NSMakeRect(20, 44, 96, 33), self, @selector(tickAll:))];
    [c addSubview:actionButton(@"НИТО ЕДИН", NSMakeRect(120, 44, 108, 33), self, @selector(tickNone:))];
    [c addSubview:actionButton(@"ИЗЧИСТИ", NSMakeRect(232, 44, L - 242, 33), self, @selector(clearList:))];

    // the three steps
    [c addSubview:actionButton(@"1. ДОБАВИ KMP / WAV / ПАПКА", NSMakeRect(L + 28, 671, 230, 34), self, @selector(browse:))];
    [c addSubview:actionButton(@"2. ИЗСЛЕДВАЙ", NSMakeRect(L + 266, 671, 150, 34), self, @selector(studyAll:))];
    [c addSubview:actionButton(@"3. ЗАПИШИ SILVETON_OSC.sv", NSMakeRect(L + 740, 671, 212, 34), self, @selector(exportAll:))];
    fileInfo = textLabel(@"Добави файлове или цяла папка - излизат в списъка", NSMakeRect(L + 428, 675, 300, 29), 12, NO); [c addSubview:fileInfo];

    // the chosen sound: which sample, its harmonics, its loudness and pitch in time
    [c addSubview:textLabel(@"СЕМПЪЛ", NSMakeRect(L + 29, 636, 70, 22), 12, YES)];
    zoneMenu = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(L + 96, 631, 420, 29) pullsDown:NO];
    [zoneMenu setTarget:self]; [zoneMenu setAction:@selector(zoneChanged:)]; [c addSubview:zoneMenu];
    zoneInfo = textLabel(@"", NSMakeRect(L + 528, 636, 424, 22), 12, NO); [c addSubview:zoneInfo];
    [c addSubview:textLabel(@"ХАРМОНИЦИ НА УСТОЙЧИВАТА ЧАСТ (0 .. -60 dB)", NSMakeRect(L + 29, 602, 450, 22), 12, YES)];
    bars = [[TeachBarsView alloc] initWithFrame:NSMakeRect(L + 28, 508, 452, 92)]; [c addSubview:bars];
    [c addSubview:textLabel(@"СИЛА (оранжево, dB) И ВИСОЧИНА (синьо, ±50 цента) ВЪВ ВРЕМЕТО", NSMakeRect(L + 500, 602, 452, 22), 12, YES)];
    curves = [[TeachCurveView alloc] initWithFrame:NSMakeRect(L + 500, 508, 452, 92)]; [c addSubview:curves];

    // the report
    [c addSubview:textLabel(@"КАКВО ЧУХ И РАЗБРАХ", NSMakeRect(L + 29, 480, 450, 22), 12, YES)];
    NSScrollView* rs = [[NSScrollView alloc] initWithFrame:NSMakeRect(L + 28, 190, 924, 288)];
    [rs setHasVerticalScroller:YES]; [rs setBorderType:NSBezelBorder];
    reportView = [[NSTextView alloc] initWithFrame:NSMakeRect(0, 0, 900, 288)];
    [reportView setEditable:NO]; [reportView setBackgroundColor:panelColor()]; [reportView setTextColor:[NSColor colorWithCalibratedWhite:.9 alpha:1]];
    [reportView setFont:[NSFont fontWithName:@"Menlo" size:11] ?: [NSFont systemFontOfSize:11]];
    [reportView setMinSize:NSMakeSize(0, 288)]; [reportView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)]; [reportView setVerticallyResizable:YES]; [reportView setHorizontallyResizable:NO];
    [[reportView textContainer] setWidthTracksTextView:YES];
    [rs setDocumentView:reportView]; [c addSubview:rs];

    // hearing it from buttons
    [c addSubview:actionButton(@"▶ ОРИГИНАЛЪТ", NSMakeRect(L + 28, 140, 140, 33), self, @selector(playOriginal:))];
    [c addSubview:actionButton(@"▶ НАУЧЕНОТО", NSMakeRect(L + 172, 140, 140, 33), self, @selector(playLearned:))];
    [c addSubview:actionButton(@"■ СПРИ", NSMakeRect(L + 316, 140, 80, 33), self, @selector(stop:))];
    [c addSubview:textLabel(@"клавиш", NSMakeRect(L + 410, 145, 56, 22), 12, NO)];
    keyMenu = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(L + 464, 141, 150, 29) pullsDown:NO];
    [keyMenu addItemsWithTitles:@[@"нотата на семпъла", @"C2", @"G2", @"C3", @"G3", @"C4", @"G4", @"C5", @"G5", @"C6"]];
    [c addSubview:keyMenu];
    vibratoBox = [[NSButton alloc] initWithFrame:NSMakeRect(L + 630, 144, 110, 24)]; [vibratoBox setButtonType:NSButtonTypeSwitch]; [vibratoBox setTitle:@"вибратото"]; [vibratoBox setState:NSOnState];
    [vibratoBox setTarget:self]; [vibratoBox setAction:@selector(knobChanged:)]; [c addSubview:vibratoBox];
    lifeBox = [[NSButton alloc] initWithFrame:NSMakeRect(L + 744, 144, 110, 24)]; [lifeBox setButtonType:NSButtonTypeSwitch]; [lifeBox setTitle:@"животът"]; [lifeBox setState:NSOnState];
    [lifeBox setTarget:self]; [lifeBox setAction:@selector(knobChanged:)]; [c addSubview:lifeBox];
    [c addSubview:textLabel(@"BRIGHT", NSMakeRect(L + 28, 106, 60, 22), 12, YES)];
    brightSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(L + 90, 104, 260, 24)]; [brightSlider setMinValue:-12]; [brightSlider setMaxValue:12]; [brightSlider setFloatValue:0];
    [brightSlider setContinuous:YES]; [brightSlider setTarget:self]; [brightSlider setAction:@selector(knobChanged:)]; [c addSubview:brightSlider];
    brightInfo = textLabel(@"+0.0 dB/окт", NSMakeRect(L + 356, 106, 100, 22), 12, NO); [c addSubview:brightInfo];
    [c addSubview:textLabel(@"BREATH", NSMakeRect(L + 470, 106, 60, 22), 12, YES)];
    breathSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(L + 534, 104, 260, 24)]; [breathSlider setMinValue:-24]; [breathSlider setMaxValue:24]; [breathSlider setFloatValue:0];
    [breathSlider setContinuous:YES]; [breathSlider setTarget:self]; [breathSlider setAction:@selector(knobChanged:)]; [c addSubview:breathSlider];
    breathInfo = textLabel(@"+0 dB", NSMakeRect(L + 800, 106, 100, 22), 12, NO); [c addSubview:breathInfo];

    // the MIDI keyboard: plays the sound chosen in the list, live
    [c addSubview:textLabel(@"MIDI КЛАВИАТУРА СВИРИ", NSMakeRect(L + 28, 66, 180, 22), 12, YES)];
    liveMenu = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(L + 206, 61, 170, 29) pullsDown:NO];
    [liveMenu addItemsWithTitles:@[@"НАУЧЕНОТО", @"ОРИГИНАЛЪТ"]]; [liveMenu setTarget:self]; [liveMenu setAction:@selector(liveModeChanged:)]; [c addSubview:liveMenu];
    [c addSubview:actionButton(@"СВЪРЖИ MIDI", NSMakeRect(L + 386, 60, 120, 33), self, @selector(connectMidi:))];
    midiInfo = textLabel(@"MIDI: ...", NSMakeRect(L + 516, 66, 440, 22), 12, NO); [c addSubview:midiInfo];
    statusInfo = textLabel(@"Добави KMP-та (или цяла папка), ИЗСЛЕДВАЙ, цъкни звук - чуй го от бутоните или свири го с клавиатурата.", NSMakeRect(L + 28, 24, 924, 29), 12, NO);
    [c addSubview:statusInfo];
    [self refreshList];
    gLive = new silveton::teacher::LivePlayer(); gLive->prepare(kLiveRate);
    [self startAudio];
    [self connectMidi:nil];
    [NSApp activateIgnoringOtherApps:YES];
}
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }
- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    if (audioUnit) { AudioOutputUnitStop(audioUnit); AudioUnitUninitialize(audioUnit); AudioComponentInstanceDispose(audioUnit); audioUnit = NULL; }
    silveton::teacher::LivePlayer* p = gLive; gLive = nullptr; delete p;
}

// ---- the list
- (NSInteger)numberOfRowsInTableView:(NSTableView*)tv { (void)tv; return (NSInteger)rows.size(); }
- (id)tableView:(NSTableView*)tv objectValueForTableColumn:(NSTableColumn*)col row:(NSInteger)row {
    (void)tv;
    if (row < 0 || (size_t)row >= rows.size()) return nil;
    const ListRow& r = rows[(size_t)row];
    NSString* ident = [col identifier];
    if ([ident isEqualToString:@"on"]) return [NSNumber numberWithBool:r.on];
    if ([ident isEqualToString:@"name"]) return S(r.name);
    if ([ident isEqualToString:@"slot"]) return S(r.slot);
    if (!r.studied) return r.input.kmp ? [NSString stringWithFormat:@"KMP · %d", r.zones] : @"WAV";
    if (!r.error.empty() || !r.study) return @"ГРЕШКА";
    if (r.study->okZones == 0) return @"ПРОПУСНАТ";
    return [NSString stringWithFormat:@"НАУЧЕН %d/%d", r.study->okZones, (int)r.study->zones.size()];
}
- (void)tableView:(NSTableView*)tv setObjectValue:(id)value forTableColumn:(NSTableColumn*)col row:(NSInteger)row {
    (void)tv;
    if (row < 0 || (size_t)row >= rows.size()) return;
    if ([[col identifier] isEqualToString:@"on"]) { rows[(size_t)row].on = [value boolValue]; [self refreshList]; }
    else if ([[col identifier] isEqualToString:@"slot"]) {
        rows[(size_t)row].slot = value ? [[value description] UTF8String] : "";
        if (rows[(size_t)row].study) { rows[(size_t)row].study->slot = rows[(size_t)row].slot; rows[(size_t)row].study->report = silveton::teacher::reportOf(*rows[(size_t)row].study); }
        if (row == current) [self showCurrent];
    }
}
- (void)tableView:(NSTableView*)tv willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)col row:(NSInteger)row {
    (void)tv;
    if ([[col identifier] isEqualToString:@"on"] || row < 0 || (size_t)row >= rows.size()) return;
    const ListRow& r = rows[(size_t)row];
    NSColor* ink = [NSColor whiteColor];
    if ([[col identifier] isEqualToString:@"slot"]) ink = warm();
    if ([[col identifier] isEqualToString:@"info"]) ink = !r.studied ? [NSColor colorWithCalibratedWhite:.73 alpha:1] : ((r.error.empty() && r.study && r.study->okZones > 0) ? accent() : bad());
    [(NSTextFieldCell*)cell setTextColor:ink];
}
- (void)tableViewSelectionDidChange:(NSNotification*)n {
    (void)n; current = [table selectedRow];
    [slotField setStringValue:(current >= 0 && (size_t)current < rows.size()) ? S(rows[(size_t)current].slot) : @""];
    [self fillZoneMenu]; [self showCurrent]; [self handToLive];
}
- (BOOL)tableView:(NSTableView*)tv shouldEditTableColumn:(NSTableColumn*)col row:(NSInteger)row { (void)tv; (void)row; return [[col identifier] isEqualToString:@"slot"]; }
- (void)slotEntered:(id)sender {
    (void)sender;
    if (current < 0 || (size_t)current >= rows.size()) { [self setStatus:@"Първо цъкни звук в списъка, после пиши слота." error:YES]; return; }
    ListRow& r = rows[(size_t)current];
    r.slot = [[slotField stringValue] UTF8String];
    if (r.study) { r.study->slot = r.slot; r.study->report = silveton::teacher::reportOf(*r.study); }
    [table reloadData]; [self showCurrent];
    [self setStatus:[NSString stringWithFormat:@"СЛОТ на %@: %@", S(r.name), S(r.slot)] error:NO];
}
- (void)tickAll:(id)sender { (void)sender; for (ListRow& r : rows) r.on = true; [self refreshList]; }
- (void)tickNone:(id)sender { (void)sender; for (ListRow& r : rows) r.on = false; [self refreshList]; }
- (void)clearList:(id)sender {
    (void)sender; [sound stop]; if (gLive) gLive->setSound(nullptr, nullptr); rows.clear(); current = -1;
    [zoneMenu removeAllItems]; [bars setBars:std::vector<float>()]; [curves setLevel:std::vector<float>() pitch:std::vector<float>()];
    [reportView setString:@""]; [zoneInfo setStringValue:@""];
    [self refreshList]; [self setStatus:@"Списъкът е празен." error:NO];
}
- (void)fillZoneMenu {
    [zoneMenu removeAllItems];
    if (current < 0 || (size_t)current >= rows.size()) return;
    const ListRow& r = rows[(size_t)current];
    if (!r.studied || !r.study) return;
    for (size_t i = 0; i < r.study->zones.size(); ++i) {
        const silveton::teacher::ZoneStudy& z = r.study->zones[i];
        std::string t = std::to_string(i + 1) + ".  " + silveton::teacher::keyName(z.lowKey) + ".." + silveton::teacher::keyName(z.topKey) + "  ·  нота " + silveton::teacher::keyName(z.rootKey) + "  ·  " + z.file + (z.ok ? "" : "  ·  пропуснат");
        [zoneMenu addItemWithTitle:S(t)];
    }
    int pick = silveton::teacher::zoneForKey(*r.study, 60); if (pick < 0) pick = 0;
    if ([zoneMenu numberOfItems] > pick) [zoneMenu selectItemAtIndex:pick];
}
- (int)currentZone { const NSInteger i = [zoneMenu indexOfSelectedItem]; return i < 0 ? 0 : (int)i; }
- (void)showCurrent {
    if (current < 0 || (size_t)current >= rows.size()) return;
    const ListRow& r = rows[(size_t)current];
    if (!r.studied) {
        [bars setBars:std::vector<float>()]; [curves setLevel:std::vector<float>() pitch:std::vector<float>()];
        [reportView setString:[NSString stringWithFormat:@"%@: още не е изследван. Натисни ИЗСЛЕДВАЙ.", S(r.name)]]; [zoneInfo setStringValue:@""];
        return;
    }
    if (!r.error.empty() || !r.study) { [reportView setString:[NSString stringWithFormat:@"%@: ГРЕШКА - %@", S(r.name), S(r.error)]]; return; }
    [reportView setString:S(r.study->report)];
    const int zi = [self currentZone];
    if (zi >= 0 && (size_t)zi < r.study->zones.size()) {
        const silveton::teacher::ZoneStudy& z = r.study->zones[(size_t)zi];
        [bars setBars:z.harmonicDb]; [curves setLevel:z.levelCurveDb pitch:z.pitchCurveCents];
        if (z.ok) [zoneInfo setStringValue:[NSString stringWithFormat:@"%.1f Hz (%+.0f c)  ·  атака %.0f ms  ·  яркост %.1f  ·  дъх %.0f dB  ·  %@", z.f0Hz, z.tuneCents, z.attackMs, z.centroidHarmonic, z.breathDb, z.vibratoCents > 0 ? [NSString stringWithFormat:@"вибрато %.1f Hz ±%.0f c", z.vibratoHz, z.vibratoCents] : @"без вибрато"]];
        else [zoneInfo setStringValue:[NSString stringWithFormat:@"пропуснат: %@", S(z.why)]];
    }
}
- (void)zoneChanged:(id)sender { (void)sender; [self showCurrent]; }
- (void)knobChanged:(id)sender {
    (void)sender;
    [brightInfo setStringValue:[NSString stringWithFormat:@"%+.1f dB/окт", [brightSlider floatValue]]];
    [breathInfo setStringValue:[NSString stringWithFormat:@"%+.0f dB", [breathSlider floatValue]]];
    if (gLive) {
        silveton::teacher::PreviewKnobs k;
        k.brightDbPerOctave = [brightSlider floatValue]; k.breathDb = [breathSlider floatValue];
        k.vibrato = [vibratoBox state] == NSOnState; k.life = [lifeBox state] == NSOnState;
        gLive->setKnobs(k);
    }
}
- (void)liveModeChanged:(id)sender { (void)sender; if (gLive) gLive->setOriginal([liveMenu indexOfSelectedItem] == 1); }
// "ДОБАВИ" adds to the list: files and whole folders (a folder: every .KMP in it, three levels deep)
- (void)browse:(id)sender {
    (void)sender; NSOpenPanel* p = [NSOpenPanel openPanel]; [p setAllowedFileTypes:@[@"wav", @"wave", @"WAV", @"kmp", @"KMP"]];
    [p setAllowsOtherFileTypes:NO]; [p setCanChooseFiles:YES]; [p setCanChooseDirectories:YES]; [p setAllowsMultipleSelection:YES];
    [p setPrompt:@"Добави в списъка"];
    if ([p runModal] != NSModalResponseOK) return;
    try {
        std::vector<std::string> paths;
        for (NSURL* u in [p URLs]) paths.push_back([[u path] UTF8String]);
        const std::vector<silveton::teacher::Input> found = silveton::teacher::collectInputs(paths);
        int added = 0;
        for (const silveton::teacher::Input& it : found) {
            bool have = false; for (const ListRow& r : rows) if (r.input.path == it.path) have = true;
            if (have) continue;
            ListRow row; row.input = it;
            const silveton::teacher::InputInfo info = silveton::teacher::describeInput(it); row.name = info.name; row.zones = info.zones;
            rows.push_back(row); ++added;
        }
        if (found.empty()) throw std::runtime_error("Не намерих KMP или WAV (в папка се вземат само .KMP файловете)");
        [self refreshList];
        [fileInfo setStringValue:[NSString stringWithFormat:@"Добавени: %d   ·   в списъка: %d", added, (int)rows.size()]];
        if (added > 0) { current = (NSInteger)rows.size() - added; [table selectRowIndexes:[NSIndexSet indexSetWithIndex:(NSUInteger)current] byExtendingSelection:NO]; }
        [self setStatus:@"Напиши СЛОТ на всеки (цъкни в колоната), отметни кои искаш и натисни ИЗСЛЕДВАЙ." error:NO];
    } catch (const std::exception& e) { [self showError:S(e.what())]; }
}
- (void)studyRow:(ListRow&)r {
    r.studied = true; r.error.clear();
    try {
        r.sound = std::make_shared<silveton::teacher::Sound>(r.input.kmp ? silveton::teacher::readKmp(r.input.path) : silveton::teacher::readWavSound(r.input.path));
        silveton::teacher::Settings set;
        silveton::teacher::SoundStudy st = silveton::teacher::study(*r.sound, set);
        st.slot = r.slot; st.report = silveton::teacher::reportOf(st);
        r.study = std::make_shared<silveton::teacher::SoundStudy>(st);
        if (!r.sound->name.empty()) r.name = r.sound->name;
    } catch (const std::exception& e) { r.error = e.what(); r.study.reset(); r.sound.reset(); }
}
- (void)studyAll:(id)sender {
    (void)sender;
    if ([self tickedCount] == 0) { [self showError:@"Няма отметнат звук в списъка."]; return; }
    if (gLive) gLive->setSound(nullptr, nullptr);
    int done = 0, learned = 0, skipped = 0; const int total = [self tickedCount];
    for (size_t i = 0; i < rows.size(); ++i) {
        ListRow& r = rows[i];
        if (!r.on) continue;
        [self setStatus:[NSString stringWithFormat:@"Изследвам %d от %d: %@ ...", done + 1, total, S(r.name)] error:NO];
        [statusInfo displayIfNeeded]; [window displayIfNeeded];
        [self studyRow:r];
        ++done; if (r.error.empty() && r.study && r.study->okZones > 0) ++learned; else ++skipped;
        [table reloadData];
    }
    [self refreshList];
    if (current < 0 || (size_t)current >= rows.size() || !rows[(size_t)current].on)
        for (size_t i = 0; i < rows.size(); i++) if (rows[i].on && rows[i].studied) { current = (NSInteger)i; break; }
    if (current >= 0) [table selectRowIndexes:[NSIndexSet indexSetWithIndex:(NSUInteger)current] byExtendingSelection:NO];
    [self fillZoneMenu]; [self showCurrent]; [self handToLive];
    [self setStatus:[NSString stringWithFormat:@"Научени %d, пропуснати %d. Цъкни звук - чуй го, свири го с клавиатурата, после ЗАПИШИ.", learned, skipped] error:(learned == 0)];
}
- (int)playKey:(const ListRow&)r {
    const NSInteger i = [keyMenu indexOfSelectedItem];
    if (i <= 0) { const int zi = [self currentZone]; return (r.study && zi >= 0 && (size_t)zi < r.study->zones.size()) ? r.study->zones[(size_t)zi].rootKey : 60; }
    static const int keys[] = {60, 36, 43, 48, 55, 60, 67, 72, 79, 84};
    return keys[std::min<NSInteger>(i, 9)];
}
- (void)playBuffer:(const std::vector<float>&)buf what:(NSString*)what {
    [sound stop];
    NSString* path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"silveton_teacher_preview.wav"];
    silveton::teacher::writePcm16Wav([path UTF8String], buf, 48000);
    sound = [[NSSound alloc] initWithContentsOfFile:path byReference:NO];
    if (!sound || ![sound play]) throw std::runtime_error("Звукът не тръгна");
    [self setStatus:what error:NO];
}
- (void)playOriginal:(id)sender {
    (void)sender;
    if (current < 0 || (size_t)current >= rows.size()) { [self showError:@"Цъкни звук от списъка."]; return; }
    ListRow& r = rows[(size_t)current];
    if (!r.studied) [self studyRow:r];
    if (!r.error.empty() || !r.study || r.study->okZones == 0) { [self showError:@"Този звук не е научен."]; return; }
    try {
        const int key = [self playKey:r];
        [self playBuffer:silveton::teacher::previewOriginal(*r.sound, *r.study, key, 3.0, 48000) what:[NSString stringWithFormat:@"Оригиналът: %@ на %@", S(r.name), S(silveton::teacher::keyName(key))]];
    } catch (const std::exception& e) { [self showError:S(e.what())]; }
}
- (void)playLearned:(id)sender {
    (void)sender;
    if (current < 0 || (size_t)current >= rows.size()) { [self showError:@"Цъкни звук от списъка."]; return; }
    ListRow& r = rows[(size_t)current];
    if (!r.studied) [self studyRow:r];
    if (!r.error.empty() || !r.study || r.study->okZones == 0) { [self showError:@"Този звук не е научен."]; return; }
    try {
        silveton::teacher::PreviewKnobs k;
        k.brightDbPerOctave = [brightSlider floatValue]; k.breathDb = [breathSlider floatValue];
        k.vibrato = [vibratoBox state] == NSOnState; k.life = [lifeBox state] == NSOnState;
        const int key = [self playKey:r];
        [self playBuffer:silveton::teacher::previewLearned(*r.study, key, 3.0, 48000, k) what:[NSString stringWithFormat:@"Наученото: %@ на %@  (BRIGHT %+.1f, BREATH %+.0f)", S(r.name), S(silveton::teacher::keyName(key)), k.brightDbPerOctave, k.breathDb]];
    } catch (const std::exception& e) { [self showError:S(e.what())]; }
}
- (void)stop:(id)sender { (void)sender; [sound stop]; if (gLive) gLive->allNotesOff(); [self setStatus:@"Спряно." error:NO]; }
- (void)exportAll:(id)sender {
    (void)sender;
    if ([self tickedCount] == 0) { [self showError:@"Няма отметнат звук в списъка."]; return; }
    bool need = false; for (const ListRow& r : rows) if (r.on && !r.studied) need = true;
    if (need) [self studyAll:nil];
    std::vector<silveton::teacher::SoundStudy> all;
    for (const ListRow& r : rows) if (r.on && r.studied && r.error.empty() && r.study && r.study->okZones > 0) { silveton::teacher::SoundStudy s = *r.study; s.slot = r.slot; all.push_back(s); }
    if (all.empty()) { [self showError:@"Нито един отметнат звук не е научен."]; return; }
    NSOpenPanel* p = [NSOpenPanel openPanel]; [p setCanChooseDirectories:YES]; [p setCanChooseFiles:NO];
    [p setCanCreateDirectories:YES]; [p setPrompt:@"Тук да е SILVETON_OSC.sv"];
    if ([p runModal] != NSModalResponseOK) return;
    try {
        const std::string file = silveton::teacher::writeLearned(all, [[[p URL] path] UTF8String]);
        const std::vector<silveton::teacher::SoundStudy> now = silveton::teacher::readLearned(file);
        [self setStatus:[NSString stringWithFormat:@"Записано: %d нови/обновени, във файла общо %d звука. SILVETON_OSC.sv + SILVETON_OSC.txt - прати ги, или .sv до SILVETON_BANK.sv.", (int)all.size(), (int)now.size()] error:NO];
        [[NSWorkspace sharedWorkspace] openFile:[[p URL] path]];
    } catch (const std::exception& e) { [self showError:S(e.what())]; }
}
@end

int main(int argc, const char** argv) {
    (void)argc; (void)argv;
    @autoreleasepool {
        [NSApplication sharedApplication];
        TeachController* app = [[TeachController alloc] init];
        [NSApp setDelegate:app];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        [NSApp run];
    }
    return 0;
}
