// SILVETON TEACHER - the listening (see Teacher.h). Our own calculation throughout.
#include "Teacher.h"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <sys/stat.h>

namespace silveton {
namespace teacher {
namespace {

const double PI = 3.14159265358979323846264338327950288;

void expect(bool ok, const char* why) { if (!ok) throw std::runtime_error(why); }
uint16_t u16(const unsigned char* p) { return uint16_t(p[0]) | (uint16_t(p[1]) << 8); }
uint32_t u32(const unsigned char* p) { return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24); }
uint32_t be32(const unsigned char* p) { return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | uint32_t(p[3]); }
uint32_t be24(const unsigned char* p) { return (uint32_t(p[0]) << 16) | (uint32_t(p[1]) << 8) | uint32_t(p[2]); }
void put16(std::ostream& o, uint16_t x) { char p[2] = {(char)x, (char)(x >> 8)}; o.write(p, 2); }
void put32(std::ostream& o, uint32_t x) { char p[4] = {(char)x, (char)(x >> 8), (char)(x >> 16), (char)(x >> 24)}; o.write(p, 4); }
void putF(std::ostream& o, float f) { uint32_t x; std::memcpy(&x, &f, 4); put32(o, x); }
float getF(const unsigned char* p) { uint32_t x = u32(p); float f; std::memcpy(&f, &x, 4); return f; }
double dbOf(double a) { return 20.0 * std::log10(std::max(a, 1e-9)); }
double keyHz(double key) { return 440.0 * std::pow(2.0, (key - 69.0) / 12.0); }

bool fileExists(const std::string& p) { struct stat st; return ::stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode); }
bool dirExists(const std::string& p) { struct stat st; return ::stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode); }
std::string dirOf(const std::string& p) { const size_t s = p.find_last_of('/'); return s == std::string::npos ? std::string(".") : p.substr(0, s); }
std::string lower(std::string s) { for (char& c : s) c = (char)std::tolower((unsigned char)c); return s; }
std::string extOf(const std::string& p) { const size_t d = p.find_last_of('.'); const size_t s = p.find_last_of('/'); if (d == std::string::npos || (s != std::string::npos && d < s)) return ""; return lower(p.substr(d + 1)); }

// ---------------------------------------------------------------------------------------------------- FFT
void fft(std::vector<std::complex<double> >& a) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= n; len <<= 1) {
        const double ang = -2.0 * PI / (double)len;
        const std::complex<double> wl(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (size_t j = 0; j < len / 2; ++j) {
                const std::complex<double> u = a[i + j], v = a[i + j + len / 2] * w;
                a[i + j] = u + v; a[i + j + len / 2] = u - v; w *= wl;
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------- files: WAV
std::vector<unsigned char> readBytes(const std::string& path) {
    std::ifstream in(path.c_str(), std::ios::binary); expect(bool(in), "Cannot open file");
    in.seekg(0, std::ios::end); const std::streamoff n = in.tellg(); expect(n > 0 && n < (std::streamoff(1) << 31), "Empty or too large file");
    std::vector<unsigned char> b((size_t)n); in.seekg(0, std::ios::beg); in.read((char*)b.data(), n); expect(in.gcount() == n, "Cannot read file");
    return b;
}

}  // namespace

std::vector<float> readWavMono(const std::string& path, int& sampleRate) {
    std::ifstream in(path.c_str(), std::ios::binary); expect(bool(in), "Cannot open WAV");
    unsigned char hdr[12]; in.read((char*)hdr, 12); expect(in.gcount() == 12, "WAV header too short");
    expect(std::memcmp(hdr, "RIFF", 4) == 0 && std::memcmp(hdr + 8, "WAVE", 4) == 0, "Not a RIFF WAVE file");
    uint16_t format = 0, ch = 0, bits = 0; uint32_t sr = 0, block = 0; bool gotFmt = false, gotData = false;
    std::streamoff dataOffset = 0; uint32_t dataSize = 0;
    while (in && !(gotFmt && gotData)) {
        unsigned char h[8]; in.read((char*)h, 8); if (in.gcount() != 8) break;
        const uint32_t size = u32(h + 4); const std::streamoff begin = in.tellg();
        if (std::memcmp(h, "fmt ", 4) == 0) {
            expect(size >= 16 && size < 4096, "Unsupported fmt chunk");
            std::vector<unsigned char> fmt(size); in.read((char*)fmt.data(), size); expect(uint32_t(in.gcount()) == size, "Incomplete WAV fmt");
            format = u16(fmt.data()); ch = u16(fmt.data() + 2); sr = u32(fmt.data() + 4); block = u16(fmt.data() + 12); bits = u16(fmt.data() + 14);
            if (format == 0xFFFE && size >= 40) { const uint32_t sub = u32(fmt.data() + 24); if (sub == 1 || sub == 3) format = (uint16_t)sub; }
            gotFmt = true;
        } else if (std::memcmp(h, "data", 4) == 0) { dataOffset = begin; dataSize = size; gotData = true; }
        in.clear(); in.seekg(begin + std::streamoff(size) + std::streamoff(size & 1), std::ios::beg);
    }
    expect(gotFmt && gotData, "WAV without fmt or data");
    expect(ch >= 1 && ch <= 8 && sr >= 8000 && sr <= 384000, "Unsupported WAV channels or sample rate");
    expect((format == 1 && (bits == 8 || bits == 16 || bits == 24 || bits == 32)) || (format == 3 && bits == 32), "WAV: PCM 8/16/24/32 or float 32 only");
    const int bps = bits / 8; expect(block == uint32_t(ch) * uint32_t(bps), "WAV block alignment");
    const uint64_t total = dataSize / block;
    const size_t toRead = (size_t)std::min<uint64_t>(total, uint64_t(sr) * 60U);   // up to a minute
    expect(toRead >= 128, "WAV too short");
    std::vector<float> out(toRead);
    in.clear(); in.seekg(dataOffset, std::ios::beg);
    std::vector<unsigned char> frame(block);
    for (size_t i = 0; i < toRead; ++i) {
        in.read((char*)frame.data(), block); expect(uint32_t(in.gcount()) == block, "Truncated WAV");
        double sum = 0;
        for (unsigned c = 0; c < ch; ++c) {
            const unsigned char* p = &frame[c * bps]; double v = 0;
            if (format == 3) { v = getF(p); if (!std::isfinite(v)) v = 0; }
            else if (bits == 8) v = (int(p[0]) - 128) / 128.0;
            else if (bits == 16) v = (int16_t)u16(p) / 32768.0;
            else if (bits == 24) { int32_t x = int32_t(p[0]) | (int32_t(p[1]) << 8) | (int32_t(p[2]) << 16); if (x & 0x800000) x |= ~0xFFFFFF; v = x / 8388608.0; }
            else v = (int32_t)u32(p) / 2147483648.0;
            sum += v;
        }
        out[i] = (float)(sum / ch);
    }
    sampleRate = (int)sr;
    return out;
}

void writePcm16Wav(const std::string& path, const std::vector<float>& mono, int sampleRate) {
    std::ofstream out(path.c_str(), std::ios::binary); expect(bool(out), "Cannot create WAV");
    const uint32_t dataBytes = (uint32_t)mono.size() * 2U;
    out.write("RIFF", 4); put32(out, 36 + dataBytes); out.write("WAVEfmt ", 8); put32(out, 16); put16(out, 1); put16(out, 1);
    put32(out, (uint32_t)sampleRate); put32(out, (uint32_t)sampleRate * 2U); put16(out, 2); put16(out, 16); out.write("data", 4); put32(out, dataBytes);
    for (float x : mono) { const int v = (int)std::lround(std::max(-1.0, std::min(1.0, (double)x)) * 32767.0); put16(out, (uint16_t)(int16_t)v); }
    expect(bool(out), "Failed writing WAV");
}

// ---------------------------------------------------------------------------------------------------- files: KMP / KSF
namespace {
struct KChunk { std::string id; const unsigned char* data = nullptr; size_t size = 0; };
std::vector<KChunk> korgChunks(const std::vector<unsigned char>& b) {
    std::vector<KChunk> out; size_t pos = 0;
    while (pos + 8 <= b.size()) {
        KChunk c; c.id.assign((const char*)b.data() + pos, 4); c.size = be32(b.data() + pos + 4);
        expect(c.size <= b.size() - pos - 8, "Corrupt KORG chunk");
        c.data = b.data() + pos + 8; out.push_back(c); pos += 8 + c.size;
    }
    return out;
}
const KChunk* findK(const std::vector<KChunk>& cs, const char* id) { for (const auto& c : cs) if (c.id == id) return &c; return nullptr; }
std::string fixedName(const unsigned char* p, size_t n) { size_t l = 0; while (l < n && p[l] != 0 && p[l] != ' ') ++l; return std::string((const char*)p, l); }
std::string paddedName(const unsigned char* p, size_t n) { size_t l = 0; while (l < n && p[l] != 0) ++l; while (l > 0 && p[l - 1] == ' ') --l; return std::string((const char*)p, l); }

// the whole KSF, from its start point, with the loop (in samples of the result)
Sample readKsf(const std::string& path) {
    const std::vector<unsigned char> b = readBytes(path);
    const std::vector<KChunk> cs = korgChunks(b);
    const KChunk* smp = findK(cs, "SMP1"); const KChunk* smd = findK(cs, "SMD1");
    expect(smp && smp->size >= 32 && smd && smd->size >= 12, "KSF without SMP1 / SMD1");
    const uint32_t sr = be32(smd->data); const unsigned ch = smd->data[6], bits = smd->data[7]; const uint32_t points = be32(smd->data + 8);
    expect(sr >= 8000 && sr <= 384000 && ch >= 1 && ch <= 2 && (bits == 8 || bits == 16), "Unsupported KSF format");
    expect(smd->size - 12 == size_t(points) * ch * (bits / 8), "Compressed or divided KSF is not supported");
    const uint32_t modernStart = be32(smp->data + 16);
    const bool oldLayout = smp->data[16] <= 3 && modernStart > points;
    uint32_t start = oldLayout ? be24(smp->data + 17) : modernStart;
    uint32_t loopStart = be32(smp->data + 24), loopEnd = be32(smp->data + 28);
    if (start >= points) start = 0;
    loopStart = loopStart >= start ? loopStart - start : 0; loopEnd = loopEnd >= start ? loopEnd - start : 0;
    const size_t frames = points - start;
    const size_t limit = size_t(sr) * 20U;   // twenty seconds are plenty
    Sample s; s.sampleRate = (int)sr; s.file = path;
    s.mono.resize(std::min(frames, limit));
    const unsigned char* pcm = smd->data + 12;
    for (size_t i = 0; i < s.mono.size(); ++i) {
        double v = 0;
        for (unsigned c = 0; c < ch; ++c) {
            const size_t k = (size_t(start) + i) * ch + c;
            v += bits == 8 ? (signed char)pcm[k] / 128.0 : (int16_t)(uint16_t((pcm[2 * k] << 8) | pcm[2 * k + 1])) / 32768.0;
        }
        s.mono[i] = (float)(v / ch);
    }
    if (loopEnd > s.mono.size()) { loopStart = 0; loopEnd = 0; }
    s.loopStart = loopStart; s.loopEnd = loopEnd;
    return s;
}
}  // namespace

std::string stemOf(const std::string& p) { std::string n = p.substr(p.find_last_of('/') == std::string::npos ? 0 : p.find_last_of('/') + 1); const size_t d = n.rfind('.'); return d == std::string::npos ? n : n.substr(0, d); }
std::string keyName(int k) { static const char* n[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"}; return std::string(n[((k % 12) + 12) % 12]) + std::to_string(k / 12 - 1); }

Sound readKmp(const std::string& path) {
    const std::vector<unsigned char> b = readBytes(path);
    const std::vector<KChunk> cs = korgChunks(b);
    const KChunk* msp = findK(cs, "MSP1"); const KChunk* rlp = findK(cs, "RLP1");
    expect(msp && msp->size >= 18 && rlp, "Not a KMP (no MSP1 / RLP1)");
    const int count = msp->data[16];
    expect(count > 0 && rlp->size >= size_t(count) * 18, "KMP zone count does not match");
    Sound k; k.kmp = true; k.path = path; k.name = paddedName(msp->data, 16); if (k.name.empty()) k.name = stemOf(path);
    int low = 0;
    for (int i = 0; i < count; i++) {
        const unsigned char* r = rlp->data + size_t(i) * 18;
        Zone z; z.rootKey = r[0] & 0x7F; z.topKey = std::min(127, int(r[1])); z.lowKey = std::min(low, z.topKey); z.tuneCents = (signed char)r[2];
        z.file = fixedName(r + 6, 12);
        low = std::min(127, z.topKey + 1);
        if (z.file.empty() || z.file == "SKIPPEDSAMPL" || z.file.compare(0, 8, "INTERNAL") == 0) { z.error = "no sample (internal or skipped)"; k.zones.push_back(z); continue; }
        std::string p;
        const std::string cands[3] = {dirOf(path) + "/" + stemOf(path) + "/" + z.file, dirOf(path) + "/" + k.name + "/" + z.file, dirOf(path) + "/" + z.file};
        for (int c = 0; c < 3; ++c) if (fileExists(cands[c])) { p = cands[c]; break; }
        if (p.empty()) { z.error = "the sample file is missing"; k.zones.push_back(z); continue; }
        try { z.sample = readKsf(p); } catch (const std::exception& e) { z.error = e.what(); }
        k.zones.push_back(z);
    }
    return k;
}

Sound readWavSound(const std::string& path) {
    Sound s; s.kmp = false; s.path = path; s.name = stemOf(path);
    Zone z; z.lowKey = 0; z.topKey = 127; z.rootKey = -1; z.file = path;   // -1: the note is found by listening
    z.sample.file = path;
    z.sample.mono = readWavMono(path, z.sample.sampleRate);
    s.zones.push_back(z);
    return s;
}

namespace {
void collectDir(const std::string& dir, int depth, std::vector<Input>& out) {
    DIR* d = ::opendir(dir.c_str()); if (!d) return;
    std::vector<std::string> names;
    while (dirent* e = ::readdir(d)) { const std::string n = e->d_name; if (n == "." || n == "..") continue; names.push_back(n); }
    ::closedir(d);
    std::sort(names.begin(), names.end());
    for (const std::string& n : names) {
        const std::string p = dir + "/" + n;
        if (dirExists(p)) { if (depth < 3) collectDir(p, depth + 1, out); continue; }
        if (extOf(p) == "kmp") { Input in; in.path = p; in.kmp = true; out.push_back(in); }
    }
}
}  // namespace

std::vector<Input> collectInputs(const std::vector<std::string>& paths) {
    std::vector<Input> out; std::set<std::string> seen;
    for (const std::string& p : paths) {
        std::vector<Input> here;
        if (dirExists(p)) collectDir(p, 0, here);
        else if (fileExists(p)) { const std::string e = extOf(p); if (e == "kmp" || e == "wav" || e == "wave") { Input in; in.path = p; in.kmp = e == "kmp"; here.push_back(in); } }
        for (const Input& in : here) if (seen.insert(in.path).second) out.push_back(in);
    }
    return out;
}

InputInfo describeInput(const Input& in) {
    InputInfo info; info.name = stemOf(in.path); info.zones = 1;
    if (!in.kmp) return info;
    try {
        const std::vector<unsigned char> b = readBytes(in.path);
        const std::vector<KChunk> cs = korgChunks(b);
        const KChunk* msp = findK(cs, "MSP1");
        if (msp && msp->size >= 18) { const std::string n = paddedName(msp->data, 16); if (!n.empty()) info.name = n; info.zones = std::max(1, (int)msp->data[16]); }
    } catch (...) {}
    return info;
}

// ---------------------------------------------------------------------------------------------------- the listening
namespace {

struct Frame {
    double levelDb = -120;            // RMS of 20 ms around the centre, dBFS
    double f0 = 0;                    // 0 = unvoiced
    double voicing = 0;               // harmonic power / total power (0..1)
    std::vector<float> amp;           // per harmonic, linear amplitude of the sinusoid (0 = below the noise / not there)
    std::vector<float> peakHz;        // where every harmonic was really found
    double noiseBand[kNoiseBands] = {}; // equivalent sinusoid amplitude^2 / 2 (= variance) of what is not a harmonic, per band
    double harmonicPower = 0, noisePower = 0;
};

const double kBandEdges[kNoiseBands + 1] = {0, 200, 500, 1000, 2000, 4000, 8000, 12000, 1e9};
double bandCentre(int b) { const double lo = std::max(kBandEdges[b], 60.0), hi = std::min(kBandEdges[b + 1], 16000.0); return std::sqrt(lo * hi); }

struct Analyzer {
    const std::vector<float>& x;
    double sr;
    int N;                // FFT size
    int hop;
    std::vector<double> win;
    double winSumSq = 0;
    std::vector<std::complex<double> > buf;
    std::vector<double> mag;   // |X_k| of the current frame
    std::vector<double> pw;    // |X_k|^2

    Analyzer(const std::vector<float>& a, double rate) : x(a), sr(rate) {
        N = rate > 50000.0 ? 8192 : 4096;
        hop = std::max(1, (int)std::lround(rate * (kFrameMs / 1000.0)));
        win.resize((size_t)N); for (int i = 0; i < N; ++i) { win[(size_t)i] = 0.5 - 0.5 * std::cos(2.0 * PI * (i + 0.5) / N); winSumSq += win[(size_t)i] * win[(size_t)i]; }
        buf.resize((size_t)N); mag.resize((size_t)N / 2 + 1); pw.resize((size_t)N / 2 + 1);
    }
    int frameCount() const { return (int)(x.size() / (size_t)hop) + 1; }
    double binHz() const { return sr / N; }
    // the spectrum of frame i (centred on i * hop)
    void load(int i) {
        const long centre = (long)i * hop;
        for (int n = 0; n < N; ++n) {
            const long idx = centre - N / 2 + n;
            const double v = idx >= 0 && idx < (long)x.size() ? x[(size_t)idx] : 0.0;
            buf[(size_t)n] = std::complex<double>(v * win[(size_t)n], 0.0);
        }
        fft(buf);
        for (int k = 0; k <= N / 2; ++k) { const double m = std::abs(buf[(size_t)k]); mag[(size_t)k] = m; pw[(size_t)k] = m * m; }
    }
    double levelDbAt(int i) const {
        const long centre = (long)i * hop; const long half = (long)std::lround(sr * 0.010);
        double e = 0; long n = 0;
        for (long idx = centre - half; idx <= centre + half; ++idx) { if (idx < 0 || idx >= (long)x.size()) continue; e += (double)x[(size_t)idx] * x[(size_t)idx]; ++n; }
        return n > 0 ? dbOf(std::sqrt(e / n)) : -120.0;
    }
    double magAt(double hz) const {   // linear between bins
        const double b = hz / binHz(); if (b < 0 || b >= N / 2) return 0;
        const int i = (int)b; const double f = b - i;
        return mag[(size_t)i] + (mag[(size_t)std::min(i + 1, N / 2)] - mag[(size_t)i]) * f;
    }
    // the exact place and amplitude of a peak near `hz` (within +- tolHz): parabolic interpolation on the log magnitude
    bool peakNear(double hz, double tolHz, double& peakHz, double& ampLinear) const {
        const double bh = binHz();
        int lo = std::max(1, (int)std::floor((hz - tolHz) / bh)), hi = std::min(N / 2 - 1, (int)std::ceil((hz + tolHz) / bh));
        if (hi <= lo) return false;
        int best = -1; double bm = 0;
        for (int k = lo; k <= hi; ++k) if (mag[(size_t)k] > bm && mag[(size_t)k] >= mag[(size_t)k - 1] && mag[(size_t)k] >= mag[(size_t)k + 1]) { bm = mag[(size_t)k]; best = k; }
        if (best < 0) return false;
        const double a = std::log(std::max(mag[(size_t)best - 1], 1e-12)), b = std::log(std::max(mag[(size_t)best], 1e-12)), c = std::log(std::max(mag[(size_t)best + 1], 1e-12));
        const double den = a - 2 * b + c;
        const double d = std::fabs(den) > 1e-12 ? 0.5 * (a - c) / den : 0.0;
        const double dd = std::max(-0.5, std::min(0.5, d));
        peakHz = (best + dd) * bh;
        ampLinear = std::exp(b - 0.25 * (a - c) * dd) * 4.0 / N;   // Hann: a sinusoid of amplitude A peaks at A N / 4
        return true;
    }
    // the pitch near a prior (within +- 2 semitones): the harmonic sum, then the harmonics' own peaks make it exact
    double pitchNear(double prior, double& voicing) const {
        const double lo = prior * std::pow(2.0, -2.0 / 12.0), hi = prior * std::pow(2.0, 2.0 / 12.0);
        double bestF = prior, bestS = -1;
        const int steps = 160;
        for (int s = 0; s <= steps; ++s) {
            const double f = lo * std::pow(hi / lo, (double)s / steps);
            double sum = 0;
            for (int k = 1; k <= 8; ++k) { if (k * f > sr * 0.45) break; sum += magAt(k * f) / std::sqrt((double)k); }
            if (sum > bestS) { bestS = sum; bestF = f; }
        }
        // refine with the peaks of the first harmonics
        double num = 0, den = 0;
        for (int k = 1; k <= 10; ++k) {
            if (k * bestF > sr * 0.45) break;
            double ph, am;
            if (peakNear(k * bestF, std::max(binHz() * 0.75, k * bestF * 0.012), ph, am) && am > 0) { const double w = am * am; num += w * ph / k; den += w; }
        }
        const double f0 = den > 0 ? num / den : bestF;
        // voicing: the power at the harmonics against everything up to 8 kHz
        double hp = 0, tp = 0;
        const int kMax = std::min(N / 2 - 2, (int)(8000.0 / binHz()));
        for (int k = 1; k <= kMax; ++k) tp += pw[(size_t)k];
        for (int h = 1; h <= 24; ++h) {
            const double c = h * f0 / binHz(); if (c >= kMax) break;
            const int ci = (int)std::lround(c);
            for (int k = std::max(1, ci - 2); k <= std::min(kMax, ci + 2); ++k) hp += pw[(size_t)k];
        }
        voicing = tp > 0 ? hp / tp : 0;
        return f0;
    }
    // a free search of the pitch (a WAV: no note is known): the most periodic part of the sound, by autocorrelation
    double pitchFree(int frame) const {
        const long centre = (long)frame * hop; const int len = std::min((int)x.size(), (int)(sr * 0.08));
        const long start = std::max(0L, std::min((long)x.size() - len, centre - len / 2));
        const int minLag = (int)(sr / 2000.0), maxLag = (int)(sr / 30.0);
        double best = 0; int bestLag = 0;
        double e0 = 0; for (int i = 0; i < len; ++i) e0 += (double)x[(size_t)(start + i)] * x[(size_t)(start + i)];
        if (e0 <= 0) return 0;
        for (int lag = minLag; lag <= maxLag && lag < len / 2; ++lag) {
            double r = 0, e1 = 0;
            for (int i = 0; i + lag < len; ++i) { r += (double)x[(size_t)(start + i)] * x[(size_t)(start + i + lag)]; e1 += (double)x[(size_t)(start + i + lag)] * x[(size_t)(start + i + lag)]; }
            const double nr = r / std::sqrt(std::max(e0 * e1, 1e-18));
            if (nr > best + 1e-6) { best = nr; bestLag = lag; }
        }
        if (bestLag <= 0 || best < 0.5) return 0;
        // the first strong peak, not a multiple of the period: walk down from the best lag to its divisors
        for (int div = 4; div >= 2; --div) {
            const int lag = bestLag / div; if (lag < minLag) continue;
            double r = 0, e1 = 0;
            for (int i = 0; i + lag < len; ++i) { r += (double)x[(size_t)(start + i)] * x[(size_t)(start + i + lag)]; e1 += (double)x[(size_t)(start + i + lag)] * x[(size_t)(start + i + lag)]; }
            const double nr = r / std::sqrt(std::max(e0 * e1, 1e-18));
            if (nr > best * 0.9) { bestLag = lag; break; }
        }
        return sr / bestLag;
    }
};

double median(std::vector<double> v) { if (v.empty()) return 0; std::sort(v.begin(), v.end()); return v[v.size() / 2]; }
double meanOf(const std::vector<double>& v) { if (v.empty()) return 0; double s = 0; for (double d : v) s += d; return s / (double)v.size(); }

std::string brightnessWord(double ch) { return ch < 1.8 ? "тъмен" : ch < 3.2 ? "топъл" : ch < 6.0 ? "ярък" : "рязък"; }
std::string breathWord(double db) { return db < -35 ? "чист" : db < -22 ? "леко дъхав" : db < -12 ? "дъхав" : "шумен"; }
std::string attackWord(double ms) { return ms < 8 ? "мигновена" : ms < 35 ? "бърза" : ms < 120 ? "мека" : "бавна"; }

// priorHz > 0: the pitch is searched near this frequency instead of the KMP's note (a second pass, when the first showed the
// sample really sounds an octave or two away from its note); depth guards the recursion
ZoneStudy studyZone(const Zone& zone, int zoneIndex, const Settings& settings, double priorHz = 0.0, int depth = 0) {
    ZoneStudy st; st.file = zone.file; st.lowKey = zone.lowKey; st.topKey = zone.topKey; st.rootKey = zone.rootKey;
    if (!zone.error.empty()) { st.why = zone.error; return st; }
    const Sample& s = zone.sample;
    if (s.mono.size() < (size_t)(s.sampleRate / 20)) { st.why = "the sample is shorter than 50 ms"; return st; }
    const double sr = s.sampleRate;
    st.lengthMs = (float)(1000.0 * (double)s.mono.size() / sr);
    st.looped = s.looped(); st.loopStartMs = (float)(1000.0 * s.loopStart / sr); st.loopLengthMs = st.looped ? (float)(1000.0 * (s.loopEnd - s.loopStart) / sr) : 0.0F;
    // the sound as the sampler plays it: a looped sample goes on and on - the loop is repeated until there is at least 1.5 s of
    // steady sound (a short Korg loop of 40 ms would otherwise leave nothing to listen to, and the end of the data would read as noise)
    std::vector<float> work(s.mono.begin(), s.mono.begin() + (std::ptrdiff_t)(st.looped ? s.loopEnd : s.mono.size()));
    const size_t loopLen = st.looped ? (size_t)(s.loopEnd - s.loopStart) : 0U;
    if (st.looped) {
        // how much the seam itself clicks (the jump from the loop's end back to its start, against the sound's size)
        { double rms = 0; for (size_t i = s.loopStart; i < s.loopEnd; ++i) rms += (double)s.mono[i] * s.mono[i]; rms = std::sqrt(rms / (double)loopLen);
          const double jump = std::fabs((double)s.mono[s.loopEnd - 1] - (double)s.mono[s.loopStart]) + std::fabs(((double)s.mono[s.loopEnd - 1] - s.mono[s.loopEnd - 2]) - ((double)s.mono[s.loopStart + 1] - s.mono[s.loopStart]));
          st.seamDb = (float)std::max(-120.0, dbOf(jump / std::max(rms * 2.0, 1e-9))); }
        const size_t want = (size_t)s.loopEnd + std::max<size_t>((size_t)(sr * 1.5), loopLen * 4U);
        // the seam is crossfaded the way a good player does it: the last `fade` samples of a pass blend into the material that
        // leads into the loop start (what is before loopStart), so the jump back is continuous
        const size_t fade = std::min<size_t>(std::min<size_t>(loopLen / 3U, (size_t)(sr * 0.020)), (size_t)s.loopStart);
        while (work.size() < want) {
            const size_t at = work.size();
            for (size_t k = 0; k < fade; ++k) { const float t = (float)(k + 1) / (float)(fade + 1); work[at - fade + k] = work[at - fade + k] * (1.0F - t) + s.mono[s.loopStart - fade + k] * t; }
            work.insert(work.end(), s.mono.begin() + (std::ptrdiff_t)s.loopStart, s.mono.begin() + (std::ptrdiff_t)s.loopEnd);
        }
    }
    Analyzer an(work, sr);
    const int H = std::max(16, std::min(kMaxHarmonics, settings.harmonics));
    const int frames = an.frameCount();
    const int origFrames = std::min(frames, (int)(s.mono.size() / (size_t)an.hop) + 1);   // the frames of the sample itself (its attack and decay live here)
    std::vector<Frame> fr((size_t)frames);

    // 1) the loudness and the onset (within the sample itself)
    double peakDb = -120; int peakFrame = 0;
    for (int i = 0; i < frames; ++i) { fr[(size_t)i].levelDb = an.levelDbAt(i); if (i < origFrames && fr[(size_t)i].levelDb > peakDb) { peakDb = fr[(size_t)i].levelDb; peakFrame = i; } }
    if (peakDb < -70) { st.why = "the sample is silent"; return st; }
    int onset = 0; for (int i = peakFrame; i >= 0; --i) { if (fr[(size_t)i].levelDb < peakDb - 40) { onset = i; break; } }
    int a10 = onset, a90 = peakFrame;
    for (int i = onset; i <= peakFrame; ++i) { if (fr[(size_t)i].levelDb >= peakDb - 20) { a10 = i; break; } }
    for (int i = onset; i <= peakFrame; ++i) { if (fr[(size_t)i].levelDb >= peakDb - 0.92) { a90 = i; break; } }
    st.attackMs = (float)std::max((double)(a90 - a10) * kFrameMs, (double)kFrameMs * 0.5);
    st.peakMs = (float)((peakFrame - onset) * kFrameMs);

    // 2) the pitch, frame by frame (first a prior: the note of the KMP, or a free search in the loudest steady part)
    double prior = priorHz > 0 ? priorHz : (zone.rootKey >= 0 ? keyHz(zone.rootKey + zone.tuneCents / 100.0) : 0.0);
    const auto freePrior = [&]() {
        std::vector<double> cands;
        for (int i = peakFrame; i < frames; i += std::max(1, frames / 12)) { if (fr[(size_t)i].levelDb < peakDb - 30) continue; const double f = an.pitchFree(i); if (f > 0) cands.push_back(f); }
        return median(cands);
    };
    if (prior <= 0) {
        prior = freePrior();
        if (prior <= 0) { st.why = "no clear pitch (noise / drum)"; return st; }
    }
    int lastVoiced = -1;
    for (int i = 0; i < frames; ++i) {
        Frame& f = fr[(size_t)i];
        if (f.levelDb < peakDb - 60) continue;
        an.load(i);
        double voicing = 0;
        const double f0 = an.pitchNear(prior, voicing);
        f.voicing = voicing;
        if (voicing < 0.35 || f0 <= 0) continue;
        f.f0 = f0; lastVoiced = i;
        // the harmonics of this frame
        f.amp.assign((size_t)H, 0.0F); f.peakHz.assign((size_t)H, 0.0F);
        std::vector<int> usedBins;
        for (int k = 1; k <= H; ++k) {
            const double hz = k * f0; if (hz > sr * 0.47) break;
            double ph, am;
            if (an.peakNear(hz, std::max(an.binHz() * 0.75, hz * (k <= 8 ? 0.012 : 0.02)), ph, am)) {
                f.amp[(size_t)k - 1] = (float)am; f.peakHz[(size_t)k - 1] = (float)ph;
                f.harmonicPower += am * am * 0.5;
                const int c = (int)std::lround(ph / an.binHz());
                const int half = 3 + (int)std::ceil(ph * 0.02 / an.binHz());   // +- 3 bins and +- 2 % (about +- 35 cents): a unison stays with its harmonic
                for (int b = c - half; b <= c + half; ++b) usedBins.push_back(b);
            }
        }
        // what is not a harmonic, per band
        std::sort(usedBins.begin(), usedBins.end());
        const double scale = 16.0 / (3.0 * (double)an.N * an.N);   // |X|^2 sums -> variance, Hann
        int binsAll[kNoiseBands] = {}, binsFree[kNoiseBands] = {};
        for (int b = 1; b < an.N / 2; ++b) {
            const double hz = b * an.binHz();
            int band = 0; while (band < kNoiseBands - 1 && hz >= kBandEdges[band + 1]) ++band;
            ++binsAll[band];
            if (std::binary_search(usedBins.begin(), usedBins.end(), b)) continue;
            ++binsFree[band];
            f.noiseBand[band] += an.pw[(size_t)b] * scale;
        }
        // the noise goes on under the harmonics too: what was measured between them stands for the whole band
        for (int b = 0; b < kNoiseBands; ++b) { if (binsFree[b] > 0) f.noiseBand[b] *= std::min(4.0, (double)binsAll[b] / binsFree[b]); f.noisePower += f.noiseBand[b]; }
    }
    int voicedCount = 0; double bestVoicing = 0; for (const Frame& f : fr) { if (f.f0 > 0) ++voicedCount; bestVoicing = std::max(bestVoicing, f.voicing); }
    if (voicedCount < 6) {
        // nothing near the KMP's note: maybe the note in the KMP is simply wrong - listen freely once
        if (depth == 0 && priorHz <= 0 && zone.rootKey >= 0) { const double f = freePrior(); if (f > 0 && std::fabs(1200.0 * std::log2(f / prior)) > 150.0) return studyZone(zone, zoneIndex, settings, f, 1); }
        char why[160]; std::snprintf(why, sizeof why, "no clear pitch (noise / drum): the harmonics hold at most %.0f %% of the sound", bestVoicing * 100.0); st.why = why; return st;
    }

    // 3) the steady part
    int s0, s1;
    if (st.looped && loopLen >= (size_t)(sr * 0.3)) {   // a long loop: the steady part is the loop itself, inside the sample (no seams in it)
        const int margin = (int)((double)an.N / 2.0 / an.hop);
        s0 = (int)(s.loopStart / (size_t)an.hop) + margin; s1 = std::max(s0 + 1, (int)(s.loopEnd / (size_t)an.hop) - margin);
    } else if (st.looped) {   // a short loop: the repeated loop, from its second pass on (the first may still carry the decay)
        s0 = std::min(frames - 2, (int)((s.loopEnd + loopLen) / (size_t)an.hop)); s1 = std::max(s0 + 1, frames - 1 - (int)((double)an.N / 2.0 / an.hop));
    } else {
        // the level the sound settles at: the middle of the later part; the steady part begins where the fall reaches it
        s1 = std::max(peakFrame + 1, (int)(std::min(lastVoiced, origFrames - 1) * 0.9));
        std::vector<double> later; for (int i = peakFrame + (int)((s1 - peakFrame) * 0.4); i <= s1; ++i) if (fr[(size_t)i].f0 > 0) later.push_back(fr[(size_t)i].levelDb);
        const double settled = later.empty() ? fr[(size_t)s1].levelDb : median(later);
        s0 = s1;
        for (int i = peakFrame; i <= s1; ++i) if (fr[(size_t)i].levelDb <= settled + 1.0) { s0 = i; break; }
    }
    if (s1 - s0 < 10) { s0 = std::max(peakFrame, (int)(lastVoiced * 0.55)); s1 = std::max(s0 + 1, lastVoiced); }
    std::vector<int> steady; for (int i = s0; i <= s1 && i < frames; ++i) if (fr[(size_t)i].f0 > 0) steady.push_back(i);
    if (steady.size() < 4) { for (int i = 0; i < frames; ++i) if (fr[(size_t)i].f0 > 0) steady.push_back(i); }
    {
        std::vector<double> lv; for (int i : steady) lv.push_back(fr[(size_t)i].levelDb);
        st.sustainDb = (float)(meanOf(lv) - peakDb);
    }
    // decay: from the peak to within 2 dB of the steady level
    {
        const double target = peakDb + 0.8 * st.sustainDb; int d = peakFrame;   // 80 % of the way down to the steady level
        for (int i = peakFrame; i <= s0 && i < frames; ++i) { d = i; if (fr[(size_t)i].levelDb <= target) break; }
        st.decayMs = (float)((d - peakFrame) * kFrameMs);
    }
    // release: only a sample that fades out by itself shows one (a looped one does not)
    st.releaseMs = -1;
    if (!st.looped) {
        const double startDb = fr[(size_t)std::min(s1, frames - 1)].levelDb;
        int e = -1; for (int i = s1; i < origFrames; ++i) if (fr[(size_t)i].levelDb <= startDb - 30) { e = i; break; }
        if (e > s1) st.releaseMs = (float)((e - s1) * kFrameMs * 2.0);   // to -60 dB
        else { const double endDb = fr[(size_t)origFrames - 1].levelDb; if (startDb - endDb > 12) st.releaseMs = (float)((origFrames - 1 - s1) * kFrameMs * 60.0 / (startDb - endDb)); }
    }

    // 4) the pitch: tuning, the scoop, vibrato, life
    std::vector<double> f0s; for (int i : steady) f0s.push_back(fr[(size_t)i].f0);
    st.f0Hz = (float)median(f0s);
    if (zone.rootKey < 0) { st.rootKey = std::max(0, std::min(127, (int)std::lround(69.0 + 12.0 * std::log2(st.f0Hz / 440.0)))); }
    const double expected = zone.rootKey >= 0 ? keyHz(zone.rootKey + zone.tuneCents / 100.0) : keyHz(st.rootKey);
    st.tuneCents = (float)(1200.0 * std::log2(st.f0Hz / expected));
    st.pitchCurveCents.assign((size_t)frames, 0.0F);
    for (int i = 0; i < frames; ++i) if (fr[(size_t)i].f0 > 0) st.pitchCurveCents[(size_t)i] = (float)(1200.0 * std::log2(fr[(size_t)i].f0 / st.f0Hz));
    {
        std::vector<double> early; for (int i = onset; i < frames && i < onset + 12; ++i) if (fr[(size_t)i].f0 > 0) early.push_back(st.pitchCurveCents[(size_t)i]);
        st.scoopCents = (float)(early.empty() ? 0.0 : meanOf(early));
    }
    {
        // the cents of the steady part, the slow drift removed, then a spectrum of them: a vibrato is a peak at 2.5 .. 9 Hz
        std::vector<double> c; for (int i : steady) c.push_back(st.pitchCurveCents[(size_t)i]);
        const int n = (int)c.size();
        const double fps = 1000.0 / kFrameMs;
        std::vector<double> d(c.size());
        const int half = (int)(fps * 0.3);
        for (int i = 0; i < n; ++i) { double sm = 0; int m = 0; for (int j = std::max(0, i - half); j <= std::min(n - 1, i + half); ++j) { sm += c[(size_t)j]; ++m; } d[(size_t)i] = c[(size_t)i] - sm / m; }
        double rms = 0; for (double v : d) rms += v * v; rms = std::sqrt(rms / std::max(1, n));
        st.vibratoHz = 0; st.vibratoCents = 0;
        if (n >= (int)(fps * 0.6)) {
            size_t m = 1; while (m < (size_t)n * 2) m <<= 1;
            std::vector<std::complex<double> > sp(m);
            for (int i = 0; i < n; ++i) sp[(size_t)i] = std::complex<double>(d[(size_t)i] * (0.5 - 0.5 * std::cos(2.0 * PI * (i + 0.5) / n)), 0.0);
            fft(sp);
            const double bh = fps / (double)m;
            int best = -1; double bm = 0, mean = 0; int cnt = 0;
            for (size_t k = 1; k < m / 2; ++k) { const double hz = k * bh; if (hz < 1.0 || hz > 20.0) continue; const double v = std::abs(sp[k]); mean += v; ++cnt; if (hz >= 2.5 && hz <= 9.0 && v > bm) { bm = v; best = (int)k; } }
            mean = cnt > 0 ? mean / cnt : 0;
            if (best > 0 && bm > 3.0 * mean) {
                const double depth = 2.0 * bm / (0.5 * n);   // Hann on the series halves the sum
                if (depth >= 3.0) {
                    st.vibratoHz = (float)(best * bh); st.vibratoCents = (float)depth;
                    // the life = what is left in 1 .. 20 Hz once the vibrato's own bins are taken out
                    double pAll = 0, pRest = 0;
                    for (size_t k = 1; k < m / 2; ++k) { const double hz = k * bh; if (hz < 1.0 || hz > 20.0) continue; const double v = std::abs(sp[k]) * std::abs(sp[k]); pAll += v; if (std::fabs((double)k - best) > 3.0) pRest += v; }
                    rms = pAll > 0 ? rms * std::sqrt(pRest / pAll) : 0.0;
                }
            }
        }
        st.lifeCents = (float)rms;
    }

    // 5) the spectrum of the steady part
    st.harmonics = H;
    std::vector<double> meanAmp((size_t)H, 0.0), meanHz((size_t)H, 0.0); std::vector<int> cnt((size_t)H, 0);
    for (int i : steady) { const Frame& f = fr[(size_t)i]; for (int k = 0; k < H; ++k) { meanAmp[(size_t)k] += f.amp[(size_t)k]; if (f.amp[(size_t)k] > 0) { meanHz[(size_t)k] += f.peakHz[(size_t)k]; ++cnt[(size_t)k]; } } }
    double maxMean = 1e-12; for (int k = 0; k < H; ++k) { meanAmp[(size_t)k] /= (double)steady.size(); if (cnt[(size_t)k] > 0) meanHz[(size_t)k] /= cnt[(size_t)k]; maxMean = std::max(maxMean, meanAmp[(size_t)k]); }
    st.harmonicDb.assign((size_t)H, -120.0F);
    for (int k = 0; k < H; ++k) st.harmonicDb[(size_t)k] = (float)std::max(-120.0, dbOf(meanAmp[(size_t)k] / maxMean));
    // the real pitch may be a whole multiple of the note's: then only every m-th "harmonic" is there (the sample sounds m x higher
    // than the KMP says - an octave-shifted multisample, or a wrong note in the KMP). Listen again at m x the pitch.
    if (depth == 0) {
        int kmax = 0; for (int k = 0; k < H; ++k) if (st.harmonicDb[(size_t)k] >= st.harmonicDb[(size_t)kmax]) kmax = k;
        const int m = kmax + 1;
        if (m >= 2 && m <= 4) {
            bool othersSilent = true;
            for (int k = 1; k <= std::min(H, 4 * m); ++k) if (k % m != 0 && st.harmonicDb[(size_t)k - 1] > -32.0F) othersSilent = false;
            if (othersSilent) return studyZone(zone, zoneIndex, settings, st.f0Hz * m, 1);
        }
    }
    {
        double num = 0, den = 0, numH = 0;
        for (int k = 0; k < H; ++k) { const double p = meanAmp[(size_t)k] * meanAmp[(size_t)k]; num += (k + 1) * st.f0Hz * p; numH += (k + 1) * p; den += p; }
        st.centroidHz = (float)(den > 0 ? num / den : st.f0Hz); st.centroidHarmonic = (float)(den > 0 ? numH / den : 1.0);
        // the attack's centroid: the first 60 ms of voice
        double na = 0, da = 0; int got = 0;
        for (int i = onset; i < frames && got < 12; ++i) { const Frame& f = fr[(size_t)i]; if (f.f0 <= 0) continue; ++got; for (int k = 0; k < H; ++k) { const double p = (double)f.amp[(size_t)k] * f.amp[(size_t)k]; na += (k + 1) * f.f0 * p; da += p; } }
        st.attackCentroidHz = (float)(da > 0 ? na / da : st.centroidHz);
        // the tilt: dB against log2(k), up to 8 kHz
        double sx = 0, sy = 0, sxx = 0, sxy = 0; int m = 0;
        for (int k = 0; k < H; ++k) { if ((k + 1) * st.f0Hz > 8000.0 || st.harmonicDb[(size_t)k] < -60) continue; const double xx = std::log2((double)(k + 1)), yy = st.harmonicDb[(size_t)k]; sx += xx; sy += yy; sxx += xx * xx; sxy += xx * yy; ++m; }
        st.tiltDbPerOctave = (float)(m >= 3 && (m * sxx - sx * sx) > 1e-9 ? (m * sxy - sx * sy) / (m * sxx - sx * sx) : -6.0);
        double odd = 0, even = 0;
        for (int k = 2; k < H; ++k) { const double p = meanAmp[(size_t)k] * meanAmp[(size_t)k]; if ((k + 1) % 2 == 1) odd += p; else even += p; }
        st.oddEvenDb = (float)std::max(-40.0, std::min(40.0, 10.0 * std::log10((odd + 1e-18) / (even + 1e-18))));
        // the inharmonicity (strings): the harmonics sit a little above k f0
        std::vector<double> bs;
        for (int k = 2; k <= std::min(12, H); ++k) { if (cnt[(size_t)k - 1] < (int)steady.size() / 2 || st.harmonicDb[(size_t)k - 1] < -40) continue; const double r = meanHz[(size_t)k - 1] / (k * st.f0Hz); const double b = (r * r - 1.0) / (k * k); bs.push_back(b); }
        const double B = median(bs);
        st.inharmonicity = (float)(B > 5e-5 && B < 0.02 ? B : 0.0);
        // the formants: the envelope of the harmonics on a log scale, smoothed by a third of an octave, its peaks
        const int perOct = 24; const double fLo = st.f0Hz, fHi = std::min(10000.0, sr * 0.45);
        const int gridN = std::max(8, (int)(std::log2(fHi / fLo) * perOct));
        std::vector<double> env((size_t)gridN, -120.0);
        for (int g = 0; g < gridN; ++g) {
            const double hz = fLo * std::pow(2.0, (double)g / perOct);
            const double kf = hz / st.f0Hz; const int k0 = std::max(1, std::min(H - 1, (int)std::floor(kf))); const int k1 = std::min(H, k0 + 1);
            const double t = std::max(0.0, std::min(1.0, kf - k0));
            env[(size_t)g] = st.harmonicDb[(size_t)k0 - 1] * (1 - t) + st.harmonicDb[(size_t)k1 - 1] * t;
        }
        // the trend (the tilt) is taken out first: a formant is a hill above the general fall of the harmonics
        { double meanRes = 0; int mm = 0; for (int g = 0; g < gridN; ++g) { if (env[(size_t)g] < -70) continue; meanRes += env[(size_t)g] - st.tiltDbPerOctave * ((double)g / perOct); ++mm; } meanRes = mm > 0 ? meanRes / mm : 0;
          for (int g = 0; g < gridN; ++g) env[(size_t)g] = env[(size_t)g] - st.tiltDbPerOctave * ((double)g / perOct) - meanRes; }
        std::vector<double> sm((size_t)gridN, -120.0);
        for (int g = 0; g < gridN; ++g) { double acc = 0, wsum = 0; for (int j = -6; j <= 6; ++j) { const int gg = g + j; if (gg < 0 || gg >= gridN) continue; const double w = 7.0 - std::fabs((double)j); acc += env[(size_t)gg] * w; wsum += w; } sm[(size_t)g] = acc / wsum; }
        struct Cand { double hz, bw, prom, db; };
        std::vector<Cand> cands;
        for (int g = 2; g < gridN - 2; ++g) {
            if (!(sm[(size_t)g] > sm[(size_t)g - 1] && sm[(size_t)g] >= sm[(size_t)g + 1])) continue;
            double lmin = sm[(size_t)g], rmin = sm[(size_t)g];
            for (int j = g; j >= std::max(0, g - perOct); --j) lmin = std::min(lmin, sm[(size_t)j]);
            for (int j = g; j <= std::min(gridN - 1, g + perOct); ++j) rmin = std::min(rmin, sm[(size_t)j]);
            const double prom = sm[(size_t)g] - std::max(lmin, rmin);
            if (prom < 3.0) continue;
            int l = g, r = g; while (l > 0 && sm[(size_t)l] > sm[(size_t)g] - 3.0) --l; while (r < gridN - 1 && sm[(size_t)r] > sm[(size_t)g] - 3.0) ++r;
            const double hz = fLo * std::pow(2.0, (double)g / perOct);
            if (hz < 150.0 || hz > 6000.0) continue;
            Cand c; c.hz = hz; c.bw = fLo * std::pow(2.0, (double)r / perOct) - fLo * std::pow(2.0, (double)l / perOct); c.prom = prom; c.db = sm[(size_t)g];
            cands.push_back(c);
        }
        std::sort(cands.begin(), cands.end(), [](const Cand& a, const Cand& b) { return a.db > b.db; });
        for (size_t i = 0; i < cands.size() && st.formants.size() < 3; ++i) { Formant f; f.hz = (float)cands[i].hz; f.bandwidthHz = (float)cands[i].bw; f.db = (float)cands[i].prom; st.formants.push_back(f); }
    }

    // 5b) a chorus / unison inside the recording: with a long window the cluster around a harmonic shows its width in cents
    st.unisonCents = 0;
    {
        const size_t from = (size_t)steady.front() * (size_t)an.hop, to = std::min(work.size(), (size_t)steady.back() * (size_t)an.hop);
        size_t M = 1; while (M * 2 <= to - from && M < 65536U) M *= 2;
        if (M >= 8192U) {
            std::vector<std::complex<double> > sp(M);
            for (size_t i = 0; i < M; ++i) sp[i] = std::complex<double>(work[from + i] * (0.5 - 0.5 * std::cos(2.0 * PI * (i + 0.5) / M)), 0.0);
            fft(sp);
            const double bh = sr / (double)M;
            std::vector<double> widths;
            for (int k = 2; k <= std::min(10, H); ++k) {
                if (st.harmonicDb[(size_t)k - 1] < -30) continue;
                const double fc = k * st.f0Hz; const int lo = (int)(fc * std::pow(2.0, -45.0 / 1200.0) / bh), hi = (int)(fc * std::pow(2.0, 45.0 / 1200.0) / bh);
                if (lo < 1 || hi >= (int)M / 2) continue;
                double mx = 0; for (int b = lo; b <= hi; ++b) mx = std::max(mx, std::abs(sp[(size_t)b]));
                if (mx <= 0) continue;
                int l = lo, r = hi;   // the outermost bins within 12 dB of the cluster's top
                while (l < hi && std::abs(sp[(size_t)l]) < mx * 0.25) ++l;
                while (r > lo && std::abs(sp[(size_t)r]) < mx * 0.25) --r;
                const double widthHz = (r - l + 1) * bh - 4.0 * bh;   // minus the window's own main lobe
                if (widthHz > 0) widths.push_back(1200.0 * std::log2((fc + widthHz / 2.0) / (fc - widthHz / 2.0)) / 2.0);
                else widths.push_back(0.0);
            }
            const double u = median(widths);
            st.unisonCents = (float)(u >= 3.0 ? u : 0.0);
        }
    }

    // 6) the breath
    {
        double hp = 0, np = 0, bands[kNoiseBands] = {};
        for (int i : steady) { const Frame& f = fr[(size_t)i]; hp += f.harmonicPower; np += f.noisePower; for (int b = 0; b < kNoiseBands; ++b) bands[b] += f.noiseBand[b]; }
        st.breathDb = (float)std::max(-80.0, std::min(20.0, 10.0 * std::log10((np + 1e-18) / (hp + 1e-18))));
        double cn = 0, cd = 0, bmax = 1e-18;
        for (int b = 0; b < kNoiseBands; ++b) { cn += bandCentre(b) * bands[b]; cd += bands[b]; bmax = std::max(bmax, bands[b]); }
        st.breathColourHz = (float)(cd > 0 ? cn / cd : 1000.0);
        for (int b = 0; b < kNoiseBands; ++b) st.breathBandsDb[b] = (float)std::max(-80.0, 10.0 * std::log10((bands[b] + 1e-18) / bmax));
        double early = 0; int ec = 0; for (int i = onset; i < frames && i < onset + 8; ++i) { if (fr[(size_t)i].f0 <= 0) continue; early += fr[(size_t)i].noisePower; ++ec; }
        const double steadyNoise = np / std::max<size_t>(1, steady.size());
        st.chiffDb = (float)(ec > 0 ? std::max(-30.0, std::min(40.0, 10.0 * std::log10((early / ec + 1e-18) / (steadyNoise + 1e-18)))) : 0.0);
    }

    // 7) the model: the attack frame by frame, the steady part as kLoopFrames spread over it
    double maxA = 1e-12; for (const Frame& f : fr) for (float a : f.amp) maxA = std::max(maxA, (double)a);
    st.peakDb = (float)dbOf(maxA);
    const int attackEnd = std::min(std::min(frames - 1, s0), onset + 120);
    st.attackFrames = std::max(1, attackEnd - onset);
    const int rows = st.attackFrames + kLoopFrames;
    st.harmonicTrack.assign((size_t)rows * H, 255U); st.noiseTrack.assign((size_t)rows * kNoiseBands, 255U); st.pitchTrack.assign((size_t)st.attackFrames, 0);
    const auto q = [](double db) { return (uint8_t)std::max(0.0, std::min(255.0, std::round(-2.0 * db))); };
    const auto putRow = [&](int row, const Frame& f) {
        for (int k = 0; k < H && k < (int)f.amp.size(); ++k) if (f.amp[(size_t)k] > 0) st.harmonicTrack[(size_t)row * H + k] = q(dbOf(f.amp[(size_t)k] / maxA));
        for (int b = 0; b < kNoiseBands; ++b) st.noiseTrack[(size_t)row * kNoiseBands + b] = q(dbOf(std::sqrt(2.0 * f.noiseBand[b]) / maxA));
    };
    for (int r = 0; r < st.attackFrames; ++r) {
        const Frame& f = fr[(size_t)(onset + r)];
        if (f.f0 > 0) { putRow(r, f); st.pitchTrack[(size_t)r] = (int8_t)std::max(-127.0, std::min(127.0, (double)st.pitchCurveCents[(size_t)(onset + r)])); }
    }
    for (int j = 0; j < kLoopFrames; ++j) {   // each loop frame = the average of its neighbourhood (less noise)
        const size_t at = (size_t)std::min<double>((double)steady.size() - 1, (j + 0.5) * (double)steady.size() / kLoopFrames);
        Frame avg; avg.amp.assign((size_t)H, 0.0F); int m = 0;
        for (long jj = (long)at - 2; jj <= (long)at + 2; ++jj) {
            if (jj < 0 || jj >= (long)steady.size()) continue;
            const Frame& f = fr[(size_t)steady[(size_t)jj]];
            for (int k = 0; k < H; ++k) avg.amp[(size_t)k] += f.amp[(size_t)k];
            for (int b = 0; b < kNoiseBands; ++b) avg.noiseBand[b] += f.noiseBand[b];
            ++m;
        }
        for (int k = 0; k < H; ++k) avg.amp[(size_t)k] /= (float)std::max(1, m);
        for (int b = 0; b < kNoiseBands; ++b) avg.noiseBand[b] /= std::max(1, m);
        putRow(st.attackFrames + j, avg);
    }
    if (!st.looped) { st.loopStartMs = (float)(s0 * kFrameMs); st.loopLengthMs = (float)std::max(40.0, (double)steady.size() * (double)kFrameMs); }   // not looped: the steady part the 32 frames cover
    st.levelCurveDb.assign((size_t)origFrames, -120.0F); for (int i = 0; i < origFrames; ++i) st.levelCurveDb[(size_t)i] = (float)fr[(size_t)i].levelDb;
    st.pitchCurveCents.resize((size_t)origFrames);
    st.ok = true;
    (void)zoneIndex;
    return st;
}

std::string fmt(const char* f, double v) { char b[64]; std::snprintf(b, sizeof b, f, v); return b; }

}  // namespace

int zoneForKey(const SoundStudy& s, int key) {
    int best = -1; int bestDist = 1 << 20;
    for (size_t i = 0; i < s.zones.size(); ++i) {
        const ZoneStudy& z = s.zones[i]; if (!z.ok) continue;
        if (key >= z.lowKey && key <= z.topKey) return (int)i;
        const int d = key < z.lowKey ? z.lowKey - key : key - z.topKey;
        if (d < bestDist) { bestDist = d; best = (int)i; }
    }
    return best;
}

std::string reportOf(const SoundStudy& s) {
    std::ostringstream o;
    o << "=== " << s.name << (s.slot.empty() ? std::string() : "  [СЛОТ: " + s.slot + "]") << (s.kmp ? "  (KMP)" : "  (WAV)") << "  -  " << s.okZones << " от " << s.zones.size() << " семпъла изслушани\n";
    if (s.okZones == 0) { o << "    нищо не е научено\n"; for (const ZoneStudy& z : s.zones) o << "    " << z.file << ": " << z.why << "\n"; return o.str(); }
    o << "    Строй общо: " << fmt("%+.1f", s.tuneCentsMean) << " цента спрямо нотите на KMP-то\n";
    o << "    По клавиатурата: яркост (хармоник) " << fmt("%.1f", s.centroidHarmonicLow) << " долу -> " << fmt("%.1f", s.centroidHarmonicHigh) << " горе;  дъх "
      << fmt("%.0f", s.breathDbLow) << " dB долу -> " << fmt("%.0f", s.breathDbHigh) << " dB горе;  атака " << fmt("%.0f", s.attackMsLow) << " ms долу -> " << fmt("%.0f", s.attackMsHigh) << " ms горе\n";
    for (const std::string& w : s.warnings) o << "    ! " << w << "\n";
    for (const ZoneStudy& z : s.zones) {
        o << "  - " << keyName(z.lowKey) << ".." << keyName(z.topKey) << "  нота " << keyName(z.rootKey) << "  " << z.file << "\n";
        if (!z.ok) { o << "      пропуснат: " << z.why << "\n"; continue; }
        o << "      височина " << fmt("%.2f", z.f0Hz) << " Hz (" << fmt("%+.1f", z.tuneCents) << " c)"
          << (std::fabs(z.tuneCents) >= 600.0F ? " - ЗВУЧИ " + fmt("%.1f", std::fabs(z.tuneCents) / 1200.0) + " ОКТАВИ " + (z.tuneCents > 0 ? "НАД" : "ПОД") + " НОТАТА НА KMP-ТО (така ще свири и на този клавиш)" : std::string())
          << ", атаката почва " << fmt("%+.0f", z.scoopCents) << " c;  "
          << (z.vibratoCents > 0 ? "вибрато " + fmt("%.1f", z.vibratoHz) + " Hz ±" + fmt("%.0f", z.vibratoCents) + " c;  " : std::string("без вибрато;  "))
          << "живот ±" << fmt("%.1f", z.lifeCents) << " c" << (z.inharmonicity > 0 ? ",  струнна разстройка B=" + fmt("%.5f", z.inharmonicity) : "")
          << (z.unisonCents > 0 ? ",  унисон / хор в записа ±" + fmt("%.0f", z.unisonCents) + " c" : std::string(",  един чист глас")) << "\n";
        o << "      обвивка: атака " << fmt("%.0f", z.attackMs) << " ms (" << attackWord(z.attackMs) << "), връх на " << fmt("%.0f", z.peakMs) << " ms, затихване " << fmt("%.0f", z.decayMs)
          << " ms до " << fmt("%.1f", z.sustainDb) << " dB, " << (z.releaseMs >= 0 ? "отпускане " + fmt("%.0f", z.releaseMs) + " ms" : std::string("отпускане: няма в записа"))
          << ";  " << (z.looped ? "примка " + fmt("%.0f", z.loopStartMs) + " ms + " + fmt("%.0f", z.loopLengthMs) + " ms" + (z.seamDb > -30 ? " (шевът ѝ щрака " + fmt("%.0f", z.seamDb) + " dB)" : " (чист шев)") : std::string("без примка")) << ",  дължина " << fmt("%.0f", z.lengthMs) << " ms, връх " << fmt("%.1f", z.peakDb) << " dBFS\n";
        o << "      тембър: " << brightnessWord(z.centroidHarmonic) << " (център " << fmt("%.0f", z.centroidHz) << " Hz = " << fmt("%.1f", z.centroidHarmonic) << "-ти хармоник; в атаката " << fmt("%.0f", z.attackCentroidHz)
          << " Hz), наклон " << fmt("%.1f", z.tiltDbPerOctave) << " dB/окт, нечетни/четни " << fmt("%+.1f", z.oddEvenDb) << " dB\n";
        o << "      форманти:";
        if (z.formants.empty()) o << " няма ясни";
        for (const Formant& f : z.formants) o << "  " << fmt("%.0f", f.hz) << " Hz (" << fmt("%+.0f", f.db) << " dB, ширина " << fmt("%.0f", f.bandwidthHz) << ")";
        o << "\n";
        o << "      дъх: " << breathWord(z.breathDb) << " (" << fmt("%.0f", z.breathDb) << " dB под хармониците), цвят " << fmt("%.0f", z.breathColourHz) << " Hz, чиф в атаката " << fmt("%+.0f", z.chiffDb) << " dB\n";
        o << "      хармоници (dB):";
        for (int k = 0; k < std::min(16, (int)z.harmonicDb.size()); ++k) o << " " << fmt("%.0f", z.harmonicDb[(size_t)k]);
        o << "  ...\n";
    }
    return o.str();
}

std::string shortReport(const SoundStudy& s) {
    std::ostringstream o;
    o << s.name << ": " << s.okZones << "/" << s.zones.size() << " семпъла";
    if (s.okZones > 0) o << "  ·  яркост " << fmt("%.1f", s.centroidHarmonicLow) << "→" << fmt("%.1f", s.centroidHarmonicHigh) << "  ·  дъх " << fmt("%.0f", s.breathDbLow) << "→" << fmt("%.0f", s.breathDbHigh) << " dB  ·  строй " << fmt("%+.1f", s.tuneCentsMean) << " c";
    return o.str();
}

SoundStudy study(const Sound& sound, const Settings& settings) {
    SoundStudy s; s.name = sound.name; s.path = sound.path; s.kmp = sound.kmp;
    for (size_t i = 0; i < sound.zones.size(); ++i) s.zones.push_back(studyZone(sound.zones[i], (int)i, settings));
    std::vector<const ZoneStudy*> ok; for (const ZoneStudy& z : s.zones) if (z.ok) ok.push_back(&z);
    s.okZones = (int)ok.size();
    if (!ok.empty()) {
        std::vector<double> tunes; for (const ZoneStudy* z : ok) tunes.push_back(z->tuneCents - 1200.0 * std::round(z->tuneCents / 1200.0));
        s.tuneCentsMean = (float)meanOf(tunes);
        const ZoneStudy* lo = ok.front(); const ZoneStudy* hi = ok.back();
        s.breathDbLow = lo->breathDb; s.breathDbHigh = hi->breathDb; s.centroidHarmonicLow = lo->centroidHarmonic; s.centroidHarmonicHigh = hi->centroidHarmonic;
        s.attackMsLow = lo->attackMs; s.attackMsHigh = hi->attackMs;
        double peakMean = 0; for (const ZoneStudy* z : ok) peakMean += z->peakDb; peakMean /= (double)ok.size();
        for (const ZoneStudy* z : ok) {
            if (std::fabs(z->tuneCents) >= 600) s.warnings.push_back(keyName(z->rootKey) + " (" + z->file + "): семпълът звучи " + fmt("%.1f", std::fabs(z->tuneCents) / 1200.0) + " октави " + (z->tuneCents > 0 ? "над" : "под") + " нотата, записана в KMP-то");
            else if (std::fabs(z->tuneCents) > 35) s.warnings.push_back(keyName(z->rootKey) + " (" + z->file + "): височината е " + fmt("%+.0f", z->tuneCents) + " цента от нотата - вярна ли е нотата в KMP-то?");
            if (std::fabs(z->peakDb - peakMean) > 8) s.warnings.push_back(keyName(z->rootKey) + " (" + z->file + "): " + fmt("%+.0f", z->peakDb - peakMean) + " dB спрямо другите семпли");
        }
    }
    s.report = reportOf(s);
    return s;
}

// ---------------------------------------------------------------------------------------------------- hearing it
namespace {
struct Biquad {
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    void bandpass(double hz, double q, double sr) {
        const double w = 2.0 * PI * hz / sr, al = std::sin(w) / (2.0 * q), cw = std::cos(w);
        const double a0 = 1.0 + al;
        b0 = al / a0; b1 = 0; b2 = -al / a0; a1 = -2.0 * cw / a0; a2 = (1.0 - al) / a0;
    }
    double run(double x) { const double y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y; }
};
struct Rng { uint32_t s = 22222U; double next() { s = s * 1664525U + 1013904223U; return (double)(s >> 8) / 8388608.0 - 1.0; } };
double trackDb(const ZoneStudy&, int row, int col, int cols, const std::vector<uint8_t>& t) {
    const uint8_t q = t[(size_t)row * cols + col]; return q >= 255 ? -200.0 : -0.5 * (double)q;
}
}  // namespace

namespace {
const float* liveSine() {
    static float t[4097];
    static bool made = false;
    if (!made) { for (int i = 0; i <= 4096; ++i) t[i] = (float)std::sin(2.0 * PI * i / 4096.0); made = true; }
    return t;
}
inline float sinL(double ph) { ph -= std::floor(ph); const double x = ph * 4096.0; const int i = (int)x; const float f = (float)(x - i); const float* t = liveSine(); return t[i] + (t[i + 1] - t[i]) * f; }
// the loudness of a zone's model: its harmonics add up, so a bright zone must play quieter than a sine for the same peak
double zoneGain(const ZoneStudy& z) {
    const int H = z.harmonics; if (H <= 0 || z.harmonicTrack.empty()) return 0.0;
    const int rows = z.attackFrames + kLoopFrames;
    double rmsMax = 1e-6;
    for (int r = 0; r < rows; ++r) { double e = 0; for (int k = 0; k < H; ++k) { const double db = trackDb(z, r, k, H, z.harmonicTrack); if (db > -100) { const double a = std::pow(10.0, db / 20.0); e += a * a * 0.5; } } rmsMax = std::max(rmsMax, std::sqrt(e)); }
    return 0.24 / rmsMax;   // with Schroeder phases the peak is about 2.5 x the RMS: a peak near -4 dBFS
}
inline double schroederPhase(int k, int H) { return std::fmod((double)k * (k + 1) / (2.0 * H), 1.0); }   // spreads the harmonics' peaks in time
}  // namespace

std::vector<float> previewLearned(const SoundStudy& s, int key, double seconds, int sr, const PreviewKnobs& knobs) {
    std::vector<float> out((size_t)(seconds * sr), 0.0F);
    const int zi = zoneForKey(s, key); if (zi < 0) return out;
    const ZoneStudy& z = s.zones[(size_t)zi];
    const int H = z.harmonics; if (H <= 0 || z.harmonicTrack.empty()) return out;
    const double f0 = keyHz(key) * std::pow(2.0, std::round(z.tuneCents / 1200.0));   // a sample that sounds octaves away from its note plays that way
    const double ref = zoneGain(z);
    // a chorus / unison the recording had: two copies, a little apart
    const int copies = z.unisonCents >= 3.0F ? 2 : 1;
    const double uni[2] = {copies == 2 ? -0.7 * z.unisonCents : 0.0, 0.7 * z.unisonCents};
    // the noise: eight band-passes, each calibrated to unit RMS
    Biquad bp[kNoiseBands]; double bpGain[kNoiseBands];
    Rng rng;
    for (int b = 0; b < kNoiseBands; ++b) {
        const double lo = std::max(kBandEdges[b], 40.0), hi = std::min(kBandEdges[b + 1], sr * 0.45);
        const double c = std::sqrt(lo * hi); bp[b].bandpass(c, c / std::max(hi - lo, 10.0), sr);
        double e = 0; const int n = sr / 2; for (int i = 0; i < n; ++i) { const double y = bp[b].run(rng.next()); if (i > n / 4) e += y * y; }
        bpGain[b] = 1.0 / std::sqrt(std::max(e / (n * 0.75), 1e-12)); bp[b].z1 = bp[b].z2 = 0;
    }
    std::vector<double> ph((size_t)H * 2, 0.0);
    for (int c = 0; c < copies; ++c) for (int k = 0; k < H; ++k) ph[(size_t)(c * H + k)] = schroederPhase(k, H) + 0.37 * c;
    const double rows = z.attackFrames + kLoopFrames;
    const double loopFrameSec = std::max(0.25, (double)z.loopLengthMs / 1000.0) / kLoopFrames;
    const double gateOff = seconds * 0.72;
    const double relSec = z.releaseMs > 0 ? z.releaseMs / 1000.0 / 3.0 : 0.15;   // to -60 dB over releaseMs = a time constant of a third
    double lifeState = 0; const double lifeCoef = std::exp(-2.0 * PI * 6.0 / sr); const double lifeGain = std::sqrt(3.0 * (1.0 + lifeCoef) / (1.0 - lifeCoef));   // unit RMS
    double relGain = 1.0;
    std::vector<double> amp((size_t)H, 0.0), nz(kNoiseBands, 0.0);
    for (size_t i = 0; i < out.size(); ++i) {
        const double t = (double)i / sr;
        // which row of the model, and the one after it
        double row;
        if (t < z.attackFrames * kFrameMs / 1000.0) row = t * 1000.0 / kFrameMs;
        else { const double u = (t - z.attackFrames * kFrameMs / 1000.0) / loopFrameSec; const double period = 2.0 * (kLoopFrames - 1); double m = std::fmod(u, period); if (m > kLoopFrames - 1) m = period - m; row = z.attackFrames + m; }
        const int r0 = std::max(0, std::min((int)rows - 1, (int)row)), r1 = std::min((int)rows - 1, r0 + 1); const double fr = row - r0;
        if (i % 16 == 0) {
            for (int k = 0; k < H; ++k) {
                const double d0 = trackDb(z, r0, k, H, z.harmonicTrack), d1 = trackDb(z, r1, k, H, z.harmonicTrack);
                const double db = d0 * (1 - fr) + d1 * fr + knobs.brightDbPerOctave * std::log2((double)(k + 1));
                amp[(size_t)k] = db < -100 ? 0.0 : std::pow(10.0, db / 20.0) * ref;
            }
            for (int b = 0; b < kNoiseBands; ++b) {
                const double d0 = trackDb(z, r0, b, kNoiseBands, z.noiseTrack), d1 = trackDb(z, r1, b, kNoiseBands, z.noiseTrack);
                const double db = d0 * (1 - fr) + d1 * fr + knobs.breathDb;
                nz[(size_t)b] = db < -100 ? 0.0 : std::pow(10.0, db / 20.0) * ref / std::sqrt(2.0);   // the equivalent sinusoid -> RMS
            }
        }
        // the pitch: the scoop of the attack, the vibrato, the life
        double cents = 0;
        if (r0 < z.attackFrames) cents += z.pitchTrack[(size_t)r0] * (1 - fr) + (r1 < z.attackFrames ? z.pitchTrack[(size_t)r1] : 0) * fr;
        if (knobs.vibrato && z.vibratoCents > 0) cents += z.vibratoCents * std::sin(2.0 * PI * z.vibratoHz * t);
        if (knobs.life && z.lifeCents > 0) { lifeState = lifeState * lifeCoef + rng.next() * (1.0 - lifeCoef); cents += lifeState * lifeGain * z.lifeCents; }
        if (t > gateOff) relGain *= std::exp(-1.0 / (relSec * sr));
        double y = 0;
        for (int c = 0; c < copies; ++c) {
            const double f = f0 * std::pow(2.0, (cents + uni[c]) / 1200.0);
            for (int k = 0; k < H; ++k) {
                const double fk = f * (k + 1) * std::sqrt(1.0 + z.inharmonicity * (k + 1) * (k + 1));
                if (fk > sr * 0.47) break;
                double& p = ph[(size_t)(c * H + k)];
                p += fk / sr; if (p >= 1.0) p -= 1.0;
                if (amp[(size_t)k] > 0) y += amp[(size_t)k] * sinL(p) * (copies == 2 ? 0.7071 : 1.0);
            }
        }
        const double white = rng.next();
        for (int b = 0; b < kNoiseBands; ++b) if (nz[(size_t)b] > 0) y += bp[b].run(white) * bpGain[b] * nz[(size_t)b];
        y *= relGain;
        out[i] = (float)std::max(-1.0, std::min(1.0, y));
        if (t > gateOff && relGain < 1e-4) break;
    }
    return out;
}

std::vector<float> previewOriginal(const Sound& sound, const SoundStudy& s, int key, double seconds, int sr) {
    std::vector<float> out((size_t)(seconds * sr), 0.0F);
    const int zi = zoneForKey(s, key); if (zi < 0 || (size_t)zi >= sound.zones.size()) return out;
    const Zone& z = sound.zones[(size_t)zi]; const Sample& smp = z.sample; if (smp.mono.size() < 2) return out;
    const double root = s.zones[(size_t)zi].rootKey;
    const double step = std::pow(2.0, (key - root - s.zones[(size_t)zi].tuneCents / 100.0) / 12.0) * (double)smp.sampleRate / sr;
    double pos = 0; const double fadeStart = seconds * 0.85;
    for (size_t i = 0; i < out.size(); ++i) {
        const size_t p0 = (size_t)pos; if (p0 + 1 >= smp.mono.size()) break;
        const double fr = pos - (double)p0;
        double v = smp.mono[p0] * (1 - fr) + smp.mono[p0 + 1] * fr;
        const double t = (double)i / sr; if (t > fadeStart) v *= std::max(0.0, 1.0 - (t - fadeStart) / (seconds - fadeStart));
        out[i] = (float)v;
        pos += step;
        if (smp.looped() && pos >= (double)smp.loopEnd) pos -= (double)(smp.loopEnd - smp.loopStart);
    }
    return out;
}

// ---------------------------------------------------------------------------------------------------- the files
namespace {
void fillNumbers(const ZoneStudy& z, float n[kNumCount]) {
    for (int i = 0; i < kNumCount; ++i) n[i] = 0;
    n[kNumF0] = z.f0Hz; n[kNumTune] = z.tuneCents; n[kNumScoop] = z.scoopCents; n[kNumVibHz] = z.vibratoHz; n[kNumVibCents] = z.vibratoCents; n[kNumLife] = z.lifeCents;
    n[kNumInharm] = z.inharmonicity; n[kNumAttack] = z.attackMs; n[kNumPeak] = z.peakMs; n[kNumDecay] = z.decayMs; n[kNumSustain] = z.sustainDb; n[kNumRelease] = z.releaseMs;
    n[kNumPeakDb] = z.peakDb; n[kNumCentroidHz] = z.centroidHz; n[kNumCentroidHarm] = z.centroidHarmonic; n[kNumTilt] = z.tiltDbPerOctave; n[kNumOddEven] = z.oddEvenDb;
    n[kNumBreath] = z.breathDb; n[kNumBreathColour] = z.breathColourHz; n[kNumChiff] = z.chiffDb;
    for (size_t f = 0; f < 3; ++f) { if (f < z.formants.size()) { n[kNumF1Hz + 3 * f] = z.formants[f].hz; n[kNumF1Bw + 3 * f] = z.formants[f].bandwidthHz; n[kNumF1Db + 3 * f] = z.formants[f].db; } }
    n[kNumLength] = z.lengthMs; n[kNumLoopStart] = z.loopStartMs; n[kNumLoopLen] = z.loopLengthMs;
    n[kNumUnison] = z.unisonCents; n[kNumSeam] = z.seamDb;
}
void takeNumbers(ZoneStudy& z, const float n[kNumCount]) {
    z.f0Hz = n[kNumF0]; z.tuneCents = n[kNumTune]; z.scoopCents = n[kNumScoop]; z.vibratoHz = n[kNumVibHz]; z.vibratoCents = n[kNumVibCents]; z.lifeCents = n[kNumLife];
    z.inharmonicity = n[kNumInharm]; z.attackMs = n[kNumAttack]; z.peakMs = n[kNumPeak]; z.decayMs = n[kNumDecay]; z.sustainDb = n[kNumSustain]; z.releaseMs = n[kNumRelease];
    z.peakDb = n[kNumPeakDb]; z.centroidHz = n[kNumCentroidHz]; z.centroidHarmonic = n[kNumCentroidHarm]; z.tiltDbPerOctave = n[kNumTilt]; z.oddEvenDb = n[kNumOddEven];
    z.breathDb = n[kNumBreath]; z.breathColourHz = n[kNumBreathColour]; z.chiffDb = n[kNumChiff];
    z.formants.clear(); for (size_t f = 0; f < 3; ++f) if (n[kNumF1Hz + 3 * f] > 0) { Formant fm; fm.hz = n[kNumF1Hz + 3 * f]; fm.bandwidthHz = n[kNumF1Bw + 3 * f]; fm.db = n[kNumF1Db + 3 * f]; z.formants.push_back(fm); }
    z.lengthMs = n[kNumLength]; z.loopStartMs = n[kNumLoopStart]; z.loopLengthMs = n[kNumLoopLen];
    z.unisonCents = n[kNumUnison]; z.seamDb = n[kNumSeam];
}
}  // namespace

std::string writeLearned(const std::vector<SoundStudy>& fresh, const std::string& directory) {
    expect(dirExists(directory), "The chosen place is not a folder");
    const std::string file = directory + "/SILVETON_OSC.sv";
    // what is already there stays; a sound with the same name and slot is replaced by the new one
    std::vector<SoundStudy> sounds;
    if (fileExists(file)) { try { sounds = readLearned(file); } catch (...) { sounds.clear(); } }
    for (const SoundStudy& f : fresh) {
        bool replaced = false;
        for (SoundStudy& old : sounds) if (old.name == f.name && old.slot == f.slot) { old = f; replaced = true; break; }
        if (!replaced) sounds.push_back(f);
    }
    {
        const std::string tmp = file + ".tmp";
        std::ofstream o(tmp.c_str(), std::ios::binary); expect(bool(o), "Cannot create SILVETON_OSC.sv");
        o.write("SVOSC003", 8); put32(o, (uint32_t)sounds.size());
        for (const SoundStudy& s : sounds) {
            put16(o, (uint16_t)std::min<size_t>(s.name.size(), 65535)); o.write(s.name.data(), (std::streamsize)std::min<size_t>(s.name.size(), 65535));
            put16(o, (uint16_t)std::min<size_t>(s.slot.size(), 65535)); o.write(s.slot.data(), (std::streamsize)std::min<size_t>(s.slot.size(), 65535));
            put16(o, (uint16_t)s.zones.size());
            for (const ZoneStudy& z : s.zones) {
                o.put((char)z.lowKey); o.put((char)z.topKey); o.put((char)std::max(0, z.rootKey)); o.put((char)((z.ok ? 1 : 0) | (z.looped ? 2 : 0)));
                float n[kNumCount]; fillNumbers(z, n); for (int i = 0; i < kNumCount; ++i) putF(o, n[i]);
                const int H = z.ok ? z.harmonics : 0, A = z.ok ? z.attackFrames : 0, L = z.ok ? kLoopFrames : 0;
                put16(o, (uint16_t)H); put16(o, (uint16_t)A); put16(o, (uint16_t)L); putF(o, kFrameMs);
                if (z.ok) { o.write((const char*)z.harmonicTrack.data(), (std::streamsize)z.harmonicTrack.size()); o.write((const char*)z.noiseTrack.data(), (std::streamsize)z.noiseTrack.size()); o.write((const char*)z.pitchTrack.data(), (std::streamsize)z.pitchTrack.size()); }
            }
        }
        o.write("SVOSCEND", 8);
        expect(bool(o), "Failed writing SILVETON_OSC.sv");
        o.close();
        std::remove(file.c_str());
        expect(std::rename(tmp.c_str(), file.c_str()) == 0, "Cannot replace SILVETON_OSC.sv");
    }
    {
        std::ofstream t((directory + "/SILVETON_OSC.txt").c_str(), std::ios::binary); expect(bool(t), "Cannot create SILVETON_OSC.txt");
        t << "SILVETON TEACHER - какво чух и разбрах (" << sounds.size() << " звука)\n";
        t << "Този файл е за човек. Таблетът чете само SILVETON_OSC.sv - копирай го до SILVETON_BANK.sv.\n\n";
        int n = 0;
        for (const SoundStudy& s : sounds) { t << "SAMPLE " << ++n << (s.slot.empty() ? std::string() : "   СЛОТ: " + s.slot) << "\n" << (s.report.empty() ? reportOf(s) : s.report) << "\n"; }
    }
    return file;
}

std::vector<SoundStudy> readLearned(const std::string& file) {
    const std::vector<unsigned char> b = readBytes(file);
    expect(b.size() >= 20 && (std::memcmp(b.data(), "SVOSC003", 8) == 0 || std::memcmp(b.data(), "SVOSC002", 8) == 0), "Not a SILVETON_OSC.sv of the teacher (SVOSC002 / SVOSC003)");
    const int numCount = std::memcmp(b.data(), "SVOSC003", 8) == 0 ? (int)kNumCount : (int)kNumCountV2;
    size_t p = 8; const auto need = [&](size_t n) { expect(p + n <= b.size(), "SILVETON_OSC.sv is cut short"); };
    need(4); const uint32_t count = u32(&b[p]); p += 4;
    std::vector<SoundStudy> out;
    for (uint32_t i = 0; i < count; ++i) {
        SoundStudy s; need(2); const uint16_t nl = u16(&b[p]); p += 2; need(nl); s.name.assign((const char*)&b[p], nl); p += nl;
        need(2); const uint16_t sl = u16(&b[p]); p += 2; need(sl); s.slot.assign((const char*)&b[p], sl); p += sl;
        need(2); const uint16_t zc = u16(&b[p]); p += 2;
        for (uint16_t zi = 0; zi < zc; ++zi) {
            ZoneStudy z; need(4); z.lowKey = b[p]; z.topKey = b[p + 1]; z.rootKey = b[p + 2]; const unsigned flags = b[p + 3]; p += 4;
            z.ok = (flags & 1U) != 0; z.looped = (flags & 2U) != 0;
            float n[kNumCount]; for (int k = 0; k < kNumCount; ++k) n[k] = 0; n[kNumSeam] = -120.0F;
            need(4 * (size_t)numCount); for (int k = 0; k < numCount; ++k) { n[k] = getF(&b[p]); p += 4; } takeNumbers(z, n);
            need(10); const int H = u16(&b[p]), A = u16(&b[p + 2]), L = u16(&b[p + 4]); p += 6; p += 4;   // frameMs
            z.harmonics = H; z.attackFrames = A;
            if (z.ok) {
                expect(L == kLoopFrames && H >= 1 && H <= kMaxHarmonics, "SILVETON_OSC.sv: a zone of another size");
                const size_t rows = (size_t)(A + L);
                need(rows * H + rows * kNoiseBands + (size_t)A);
                z.harmonicTrack.assign(&b[p], &b[p] + rows * H); p += rows * H;
                z.noiseTrack.assign(&b[p], &b[p] + rows * kNoiseBands); p += rows * kNoiseBands;
                z.pitchTrack.assign((const int8_t*)&b[p], (const int8_t*)&b[p] + A); p += (size_t)A;
                ++s.okZones;
            }
            s.zones.push_back(z);
        }
        s.report = reportOf(s);
        out.push_back(s);
    }
    need(8); expect(std::memcmp(&b[p], "SVOSCEND", 8) == 0, "SILVETON_OSC.sv has no end mark");
    return out;
}

// ---------------------------------------------------------------------------------------------------- playing it live
namespace {

struct LiveVoice {
    bool active = false, held = false, original = false;
    int key = 60, age = 0;
    float gain = 1.0F;
    double relGain = 1.0, relCoef = 1.0;
    // learned
    const ZoneStudy* z = nullptr;
    int H = 0, copies = 1;
    double gainRef = 0.4, uni[2] = {0.0, 0.0};
    double ph[kMaxHarmonics * 2];
    float amp[kMaxHarmonics], ampT[kMaxHarmonics];
    float nz[kNoiseBands], nzT[kNoiseBands];
    Biquad bp[kNoiseBands];
    double t = 0, lifeState = 0;
    int ctl = 0;
    // original
    const Sample* smp = nullptr;
    double pos = 0, step = 1.0;
};
}  // namespace

struct LivePlayer::Impl {
    std::mutex m;
    double sr = 48000.0;
    std::shared_ptr<const SoundStudy> learned;
    std::shared_ptr<const Sound> original;
    PreviewKnobs knobs;
    bool playOriginal = false;
    double bend = 0.0;
    LiveVoice v[kVoices];
    Rng rng;
    double bpGain[kNoiseBands] = {};
    int ageCounter = 0;
    void calibrate() {
        for (int b = 0; b < kNoiseBands; ++b) {
            Biquad f; const double lo = std::max(kBandEdges[b], 40.0), hi = std::min(kBandEdges[b + 1], sr * 0.45);
            const double c = std::sqrt(lo * hi); f.bandpass(c, c / std::max(hi - lo, 10.0), sr);
            double e = 0; const int n = (int)(sr / 2); Rng r; for (int i = 0; i < n; ++i) { const double y = f.run(r.next()); if (i > n / 4) e += y * y; }
            bpGain[b] = 1.0 / std::sqrt(std::max(e / (n * 0.75), 1e-12));
        }
    }
    void setBands(LiveVoice& vo) {
        for (int b = 0; b < kNoiseBands; ++b) { const double lo = std::max(kBandEdges[b], 40.0), hi = std::min(kBandEdges[b + 1], sr * 0.45); const double c = std::sqrt(lo * hi); vo.bp[b] = Biquad(); vo.bp[b].bandpass(c, c / std::max(hi - lo, 10.0), sr); }
    }
};

LivePlayer::LivePlayer() : impl_(new Impl) { impl_->calibrate(); }
LivePlayer::~LivePlayer() { delete impl_; }
void LivePlayer::prepare(double sampleRate) { std::lock_guard<std::mutex> g(impl_->m); impl_->sr = sampleRate; impl_->calibrate(); for (LiveVoice& vo : impl_->v) vo.active = false; }
void LivePlayer::setSound(std::shared_ptr<const SoundStudy> learned, std::shared_ptr<const Sound> original) {
    std::lock_guard<std::mutex> g(impl_->m);
    for (LiveVoice& vo : impl_->v) vo.active = false;   // the old pointers go with the old sound
    impl_->learned = learned; impl_->original = original;
}
void LivePlayer::setKnobs(const PreviewKnobs& knobs) { std::lock_guard<std::mutex> g(impl_->m); impl_->knobs = knobs; }
void LivePlayer::setOriginal(bool playOriginal) { std::lock_guard<std::mutex> g(impl_->m); impl_->playOriginal = playOriginal; }
void LivePlayer::pitchBend(double semitones) { std::lock_guard<std::mutex> g(impl_->m); impl_->bend = std::max(-24.0, std::min(24.0, semitones)); }
void LivePlayer::allNotesOff() { std::lock_guard<std::mutex> g(impl_->m); for (LiveVoice& vo : impl_->v) if (vo.active) { vo.held = false; } }
int LivePlayer::activeNotes() const { std::lock_guard<std::mutex> g(impl_->m); int n = 0; for (const LiveVoice& vo : impl_->v) if (vo.active) ++n; return n; }
void LivePlayer::noteOff(int key) { std::lock_guard<std::mutex> g(impl_->m); for (LiveVoice& vo : impl_->v) if (vo.active && vo.held && vo.key == key) vo.held = false; }
void LivePlayer::noteOn(int key, int velocity) {
    std::lock_guard<std::mutex> g(impl_->m);
    Impl& I = *impl_;
    if (velocity <= 0) { for (LiveVoice& vo : I.v) if (vo.active && vo.held && vo.key == key) vo.held = false; return; }
    if (!I.learned) return;
    const int zi = zoneForKey(*I.learned, key); if (zi < 0) return;
    // a free voice, else the oldest
    LiveVoice* pick = nullptr;
    for (LiveVoice& vo : I.v) if (!vo.active) { pick = &vo; break; }
    if (!pick) { int oldest = 1 << 30; for (LiveVoice& vo : I.v) if (vo.age < oldest) { oldest = vo.age; pick = &vo; } }
    LiveVoice& vo = *pick;
    vo = LiveVoice();
    vo.active = true; vo.held = true; vo.key = key; vo.age = ++I.ageCounter;
    const float vel = std::max(0.0F, std::min(1.0F, velocity / 127.0F));
    vo.gain = 0.25F + 0.75F * vel;
    vo.original = I.playOriginal && I.original && (size_t)zi < I.original->zones.size() && I.original->zones[(size_t)zi].sample.mono.size() > 2;
    const ZoneStudy& z = I.learned->zones[(size_t)zi];
    vo.z = &z; vo.H = std::min(z.harmonics, kMaxHarmonics);
    const double relSec = z.releaseMs > 0 ? z.releaseMs / 1000.0 / 3.0 : 0.15;
    vo.relCoef = std::exp(-1.0 / (relSec * I.sr));
    if (vo.original) {
        vo.smp = &I.original->zones[(size_t)zi].sample;
        vo.step = std::pow(2.0, (key - z.rootKey - z.tuneCents / 100.0) / 12.0) * (double)vo.smp->sampleRate / I.sr;
        vo.relCoef = std::exp(-1.0 / (0.12 * I.sr));
    } else {
        vo.gainRef = zoneGain(z);
        vo.copies = z.unisonCents >= 3.0F ? 2 : 1;
        vo.uni[0] = vo.copies == 2 ? -0.7 * z.unisonCents : 0.0; vo.uni[1] = 0.7 * z.unisonCents;
        for (int c = 0; c < 2; ++c) for (int k = 0; k < kMaxHarmonics; ++k) vo.ph[c * kMaxHarmonics + k] = schroederPhase(k, std::max(1, vo.H)) + 0.37 * c;
        for (int k = 0; k < kMaxHarmonics; ++k) { vo.amp[k] = vo.ampT[k] = 0.0F; }
        for (int b = 0; b < kNoiseBands; ++b) { vo.nz[b] = vo.nzT[b] = 0.0F; }
        I.setBands(vo);
    }
}

void LivePlayer::render(float* left, float* right, int frames) {
    for (int i = 0; i < frames; ++i) { left[i] = 0.0F; if (right) right[i] = 0.0F; }
    std::unique_lock<std::mutex> g(impl_->m, std::try_to_lock);
    if (!g.owns_lock()) return;
    Impl& I = *impl_;
    const double sr = I.sr;
    const double bendMul = std::pow(2.0, I.bend / 12.0);
    for (LiveVoice& vo : I.v) {
        if (!vo.active) continue;
        if (vo.original) {
            const Sample& smp = *vo.smp;
            for (int i = 0; i < frames; ++i) {
                const size_t p0 = (size_t)vo.pos; if (p0 + 1 >= smp.mono.size()) { vo.active = false; break; }
                const double fr = vo.pos - (double)p0;
                double y = (smp.mono[p0] * (1 - fr) + smp.mono[p0 + 1] * fr) * vo.gain;
                if (!vo.held) { vo.relGain *= vo.relCoef; y *= vo.relGain; }
                left[i] += (float)y; if (right) right[i] += (float)y;
                vo.pos += vo.step * bendMul;
                if (smp.looped() && vo.pos >= (double)smp.loopEnd) vo.pos -= (double)(smp.loopEnd - smp.loopStart);
            }
            if (!vo.held && vo.relGain < 1e-4) vo.active = false;
            continue;
        }
        const ZoneStudy& z = *vo.z;
        const int H = vo.H;
        const double f0 = keyHz(vo.key) * bendMul * std::pow(2.0, std::round(z.tuneCents / 1200.0));
        const double rows = z.attackFrames + kLoopFrames;
        const double loopFrameSec = std::max(0.25, (double)z.loopLengthMs / 1000.0) / kLoopFrames;
        const double lifeCoef = std::exp(-2.0 * PI * 6.0 / sr), lifeGain = std::sqrt(3.0 * (1.0 + lifeCoef) / (1.0 - lifeCoef));
        for (int i = 0; i < frames; ++i) {
            const double t = vo.t; vo.t += 1.0 / sr;
            if (vo.ctl == 0) {   // every 64 samples: the row of the model and the targets of the amplitudes
                double row;
                if (t < z.attackFrames * kFrameMs / 1000.0) row = t * 1000.0 / kFrameMs;
                else { const double u = (t - z.attackFrames * kFrameMs / 1000.0) / loopFrameSec; const double period = 2.0 * (kLoopFrames - 1); double mm = std::fmod(u, period); if (mm > kLoopFrames - 1) mm = period - mm; row = z.attackFrames + mm; }
                const int r0 = std::max(0, std::min((int)rows - 1, (int)row)), r1 = std::min((int)rows - 1, r0 + 1); const double fr = row - r0;
                const double ref = vo.gainRef;
                for (int k = 0; k < H; ++k) {
                    const double d0 = trackDb(z, r0, k, H, z.harmonicTrack), d1 = trackDb(z, r1, k, H, z.harmonicTrack);
                    const double db = d0 * (1 - fr) + d1 * fr + I.knobs.brightDbPerOctave * std::log2((double)(k + 1));
                    vo.ampT[k] = db < -100 ? 0.0F : (float)(std::pow(10.0, db / 20.0) * ref);
                }
                for (int b = 0; b < kNoiseBands; ++b) {
                    const double d0 = trackDb(z, r0, b, kNoiseBands, z.noiseTrack), d1 = trackDb(z, r1, b, kNoiseBands, z.noiseTrack);
                    const double db = d0 * (1 - fr) + d1 * fr + I.knobs.breathDb;
                    vo.nzT[b] = db < -100 ? 0.0F : (float)(std::pow(10.0, db / 20.0) * ref / std::sqrt(2.0) * I.bpGain[b]);
                }
            }
            vo.ctl = (vo.ctl + 1) & 63;
            double cents = 0;
            if (t < z.attackFrames * kFrameMs / 1000.0) { const double row = t * 1000.0 / kFrameMs; const int r0 = std::min(z.attackFrames - 1, (int)row), r1 = std::min(z.attackFrames - 1, r0 + 1); const double fr = row - r0; cents += z.pitchTrack[(size_t)r0] * (1 - fr) + z.pitchTrack[(size_t)r1] * fr; }
            if (I.knobs.vibrato && z.vibratoCents > 0) cents += z.vibratoCents * std::sin(2.0 * PI * z.vibratoHz * t);
            if (I.knobs.life && z.lifeCents > 0) { vo.lifeState = vo.lifeState * lifeCoef + I.rng.next() * (1.0 - lifeCoef); cents += vo.lifeState * lifeGain * z.lifeCents; }
            double y = 0;
            for (int k = 0; k < H; ++k) vo.amp[k] += (vo.ampT[k] - vo.amp[k]) * 0.02F;
            const double copyGain = vo.copies == 2 ? 0.7071 : 1.0;
            for (int c = 0; c < vo.copies; ++c) {
                const double f = f0 * std::pow(2.0, (cents + vo.uni[c]) / 1200.0);
                for (int k = 0; k < H; ++k) {
                    const double fk = f * (k + 1) * std::sqrt(1.0 + z.inharmonicity * (k + 1) * (k + 1));
                    if (fk > sr * 0.47) break;
                    double& p = vo.ph[c * kMaxHarmonics + k];
                    p += fk / sr; if (p >= 1.0) p -= 1.0;
                    if (vo.amp[k] > 1e-6F) y += vo.amp[k] * sinL(p) * copyGain;
                }
            }
            const double white = I.rng.next();
            for (int b = 0; b < kNoiseBands; ++b) { vo.nz[b] += (vo.nzT[b] - vo.nz[b]) * 0.02F; if (vo.nz[b] > 1e-7F) y += vo.bp[b].run(white) * vo.nz[b]; }
            y *= vo.gain;
            if (!vo.held) { vo.relGain *= vo.relCoef; y *= vo.relGain; }
            left[i] += (float)y; if (right) right[i] += (float)y;
        }
        if (!vo.held && vo.relGain < 1e-4) vo.active = false;
    }
    // many keys at once: a soft knee instead of a hard clip
    const auto softLimit = [](float x) { const float a = std::fabs(x); if (a <= 0.8F) return x; const float y = 0.8F + 0.2F * std::tanh((a - 0.8F) * 5.0F); return x < 0.0F ? -y : y; };
    for (int i = 0; i < frames; ++i) { left[i] = softLimit(left[i]); if (right) right[i] = softLimit(right[i]); }
}

} // namespace teacher
} // namespace silveton
