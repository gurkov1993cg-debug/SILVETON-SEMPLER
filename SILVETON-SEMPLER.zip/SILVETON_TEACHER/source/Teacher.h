#pragma once
// SILVETON TEACHER (Цветомир, 03.11.2026) - the program of the Mac that LISTENS to a sound and writes down, in detail, what it
// heard: so that the SAMPLE oscillator of SILVETON SOLO on the tablet can play that sound anew, from what was learned, and the
// player can turn its knobs away from it while it keeps the character of its teacher.
//
// A sound = a KMP (a Korg multisample: one KSF sample for every zone of keys) or a single WAV. For EVERY sample of the sound
// the teacher measures, frame by frame (5 ms): the pitch (tuning, the scoop of the attack, vibrato, the small trembling = life),
// the first 64 harmonics (how each one starts, stays and dies), the breath (what is not a harmonic: how much, what colour,
// the chiff of the attack), the envelope (attack, decay, sustain, release, the loop of the KSF), the formants (the vowels of
// the instrument), the inharmonicity (strings); and how all of that changes from the lowest sample to the highest.
//
// Two outputs: SILVETON_OSC.sv (compact, for the tablet, next to SILVETON_BANK.sv) and SILVETON_OSC.txt (the report, for a person).
// Plain C++ (C++14-compatible; no <filesystem>, no <optional>): it must build with the clang of Xcode 10 on macOS 10.13.
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace silveton {
namespace teacher {

// ---------------------------------------------------------------------------------------------------- the sound
struct Sample {
    int sampleRate = 0;
    std::vector<float> mono;          // the WHOLE sample from its start point, mono
    uint32_t loopStart = 0, loopEnd = 0;   // in samples of `mono`; looped when loopEnd > loopStart + 15
    bool looped() const { return loopEnd > loopStart + 15 && loopEnd <= mono.size(); }
    std::string file;                 // where it came from
};
struct Zone {
    int lowKey = 0, topKey = 127, rootKey = 60, tuneCents = 0;
    std::string file;                 // the KSF name written in the KMP (or the WAV)
    std::string error;                // why there is no sample ("" = loaded)
    Sample sample;
};
struct Sound {
    std::string name;
    std::string path;
    bool kmp = false;
    std::vector<Zone> zones;
};
Sound readKmp(const std::string& path);                 // the KMP and all its KSF samples (looked for as Korg writes them)
Sound readWavSound(const std::string& path);            // one WAV = one zone over the whole keyboard; its note is found by listening
std::vector<float> readWavMono(const std::string& path, int& sampleRate);
void writePcm16Wav(const std::string& path, const std::vector<float>& mono, int sampleRate);
// chosen files (.KMP / .WAV) and folders (every .KMP inside, three levels deep)
struct Input { std::string path; bool kmp = false; };
std::vector<Input> collectInputs(const std::vector<std::string>& paths);
struct InputInfo { std::string name; int zones = 1; };
InputInfo describeInput(const Input& in);               // for the list, before any study
std::string keyName(int key);                           // 60 -> "C4"
std::string stemOf(const std::string& path);

// ---------------------------------------------------------------------------------------------------- what was heard
constexpr int kMaxHarmonics = 64;
constexpr int kNoiseBands = 8;                           // 0-200, 200-500, 500-1k, 1-2k, 2-4k, 4-8k, 8-12k, 12k+ Hz
constexpr float kFrameMs = 5.0F;                         // the step of every track
constexpr int kLoopFrames = 32;                          // the sustain, kept as 32 frames spread over the steady part

struct Formant { float hz = 0, bandwidthHz = 0, db = 0; };   // db: how much it stands out of the envelope

struct ZoneStudy {
    bool ok = false;
    std::string why;                  // when not ok: "no sample", "no clear pitch (noise / drum)", ...
    std::string file;
    int lowKey = 0, topKey = 127, rootKey = 60;
    // level and time
    float lengthMs = 0, peakDb = 0;   // peakDb: the loudest frame, dBFS
    bool looped = false; float loopStartMs = 0, loopLengthMs = 0;
    // pitch
    float f0Hz = 0;                   // the steady pitch
    float tuneCents = 0;              // against the note the KMP says (plus its tune)
    float scoopCents = 0;             // the attack: how far below (-) or above (+) the pitch starts
    float vibratoHz = 0, vibratoCents = 0;   // a vibrato in the recording itself (0 = none)
    float lifeCents = 0;              // the small trembling of the pitch that is not vibrato
    float inharmonicity = 0;          // B of f_k = k f0 sqrt(1 + B k^2); 0 = exact harmonics
    float unisonCents = 0;            // a chorus / unison inside the recording: the harmonics are spread +- this many cents (0 = one clean voice)
    float seamDb = -120;              // how much the loop seam clicks (dB against the sound; above -30 it is heard)
    // envelope (of the loudness)
    float attackMs = 0, peakMs = 0, decayMs = 0, sustainDb = 0, releaseMs = -1;   // sustainDb against the peak; release -1 = not in the sample (looped)
    // the spectrum of the steady part
    int harmonics = 0;
    std::vector<float> harmonicDb;    // per harmonic, dB against the strongest harmonic (<= 0)
    float centroidHz = 0, centroidHarmonic = 0, attackCentroidHz = 0;
    float tiltDbPerOctave = 0;        // how fast the harmonics fall: -6 = like a saw, -12 = dull, 0 = buzzing
    float oddEvenDb = 0;              // odd harmonics against the even ones (a clarinet / a square: high)
    std::vector<Formant> formants;    // up to 3, by strength
    // the breath
    float breathDb = 0;               // noise against harmonics in the steady part (dB; -40 = clean, -15 = airy)
    float breathColourHz = 0;         // where the noise sits
    float chiffDb = 0;                // noise of the first 40 ms against the steady noise (the "chiff" of a flute)
    float breathBandsDb[kNoiseBands] = {};   // the colour of the noise, per band, against its loudest band
    // ---- the model the tablet plays from
    int attackFrames = 0;             // frames of kFrameMs from the onset until the steady part (<= 120)
    std::vector<uint8_t> harmonicTrack;   // (attackFrames + kLoopFrames) x harmonics, 0.5 dB steps below the zone's strongest harmonic (255 = silence)
    std::vector<uint8_t> noiseTrack;      // (attackFrames + kLoopFrames) x kNoiseBands, 0.5 dB steps below the zone's strongest harmonic
    std::vector<int8_t> pitchTrack;       // attackFrames, cents against f0 (the scoop)
    // for the window
    std::vector<float> levelCurveDb;      // one value per frame, dBFS
    std::vector<float> pitchCurveCents;   // one value per frame (0 where unvoiced)
};

struct SoundStudy {
    std::string name;
    std::string slot;                 // the slot the player put it in (his own word: what instrument this is)
    std::string path;
    bool kmp = false;
    std::vector<ZoneStudy> zones;     // one per zone of the sound, in order
    int okZones = 0;
    // across the keyboard (from the zones that are ok)
    float tuneCentsMean = 0, breathDbLow = 0, breathDbHigh = 0, centroidHarmonicLow = 0, centroidHarmonicHigh = 0, attackMsLow = 0, attackMsHigh = 0;
    std::vector<std::string> warnings; // a zone whose pitch is not its note, a zone much louder than the others ...
    std::string report;               // the text for a person (Bulgarian)
};

struct Settings {
    int harmonics = kMaxHarmonics;    // 16..64
};
SoundStudy study(const Sound& sound, const Settings& settings);
std::string reportOf(const SoundStudy& s);               // (study() already fills s.report with this)
std::string shortReport(const SoundStudy& s);            // a few lines for the window
int zoneForKey(const SoundStudy& s, int key);            // the zone that plays this key (-1 = none that is ok)

// ---------------------------------------------------------------------------------------------------- hearing it
// what the tablet will do with what was learned: the sound played anew from the model, at any key, with the two first knobs
struct PreviewKnobs {
    float brightDbPerOctave = 0;      // BRIGHT: a tilt added to the harmonics (+ = brighter)
    float breathDb = 0;               // BREATH: the noise louder (+) or quieter (-)
    bool vibrato = true;              // the vibrato the recording had
    bool life = true;                 // the trembling the recording had
};
std::vector<float> previewLearned(const SoundStudy& s, int key, double seconds, int sampleRate, const PreviewKnobs& knobs);
std::vector<float> previewOriginal(const Sound& sound, const SoundStudy& s, int key, double seconds, int sampleRate);   // the sample itself, on that key

// ---------------------------------------------------------------------------------------------------- the files
// SILVETON_OSC.sv ("SVOSC003", little-endian; "SVOSC002" with 32 numbers is still read): u32 sounds | per sound: u16 name bytes, name UTF-8,
//   u16 slot bytes, slot UTF-8, u16 zones | per zone:
//   u8 low, u8 top, u8 root, u8 flags (1 = ok, 2 = looped), f32 numbers[32] (see kNumber*), u16 harmonics, u16 attackFrames,
//   u16 loopFrames, f32 frameMs, u8 harmonicTrack[], u8 noiseTrack[], i8 pitchTrack[] | "SVOSCEND"
enum NumberIndex : int {
    kNumF0 = 0, kNumTune, kNumScoop, kNumVibHz, kNumVibCents, kNumLife, kNumInharm, kNumAttack, kNumPeak, kNumDecay, kNumSustain,
    kNumRelease, kNumPeakDb, kNumCentroidHz, kNumCentroidHarm, kNumTilt, kNumOddEven, kNumBreath, kNumBreathColour, kNumChiff,
    kNumF1Hz, kNumF1Bw, kNumF1Db, kNumF2Hz, kNumF2Bw, kNumF2Db, kNumF3Hz, kNumF3Bw, kNumF3Db, kNumLength, kNumLoopStart, kNumLoopLen,
    kNumUnison, kNumSeam,
    kNumCount = 40
};
enum { kNumCountV2 = 32
};
// Writes <directory>/SILVETON_OSC.sv and SILVETON_OSC.txt. When a SILVETON_OSC.sv is already there it is ADDED TO: its sounds stay, a sound
// with the same name and slot is replaced - so the file can be filled over several sittings and sent once. Returns the path of the .sv.
std::string writeLearned(const std::vector<SoundStudy>& sounds, const std::string& directory);
std::vector<SoundStudy> readLearned(const std::string& file);                                   // (the tablet reads the same way; here for the tests)

// ---------------------------------------------------------------------------------------------------- playing it live
// A MIDI keyboard plays what was learned (or the original sample) in real time: the window hands the player a sound, the MIDI thread
// sends keys, the audio thread asks for samples. Ten notes at once; a note that is let go fades with the learned release.
class LivePlayer {
public:
    static constexpr int kVoices = 10;
    LivePlayer();
    ~LivePlayer();
    void prepare(double sampleRate);
    void setSound(std::shared_ptr<const SoundStudy> learned, std::shared_ptr<const Sound> original);   // nullptr = silence
    void setKnobs(const PreviewKnobs& knobs);
    void setOriginal(bool playOriginal);                     // true = the sample itself, false = what was learned
    void noteOn(int key, int velocity);
    void noteOff(int key);
    void allNotesOff();
    void pitchBend(double semitones);
    void render(float* left, float* right, int frames);      // right may be nullptr (mono)
    int activeNotes() const;
private:
    struct Impl;
    Impl* impl_;
};

} // namespace teacher
} // namespace silveton
