// SILVETON TEACHER - the same work from the Terminal, without the window:
//   teach --out ПАПКА файл1.kmp файл2.wav ПАПКА_С_KMP ...   -> ПАПКА/SILVETON_OSC.sv + SILVETON_OSC.txt (and the report on the screen)
//   teach файл.kmp                                           -> only the report on the screen
#include "Teacher.h"
#include <cstdio>
#include <cstring>
#include <exception>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    std::string out; std::vector<std::string> paths;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--out") == 0 && i + 1 < argc) { out = argv[++i]; continue; }
        paths.push_back(argv[i]);
    }
    if (paths.empty()) { std::printf("teach [--out ПАПКА] файлове / папки (.kmp .wav)\n"); return 2; }
    try {
        const std::vector<silveton::teacher::Input> ins = silveton::teacher::collectInputs(paths);
        if (ins.empty()) { std::printf("Не намерих KMP или WAV.\n"); return 1; }
        std::vector<silveton::teacher::SoundStudy> all;
        silveton::teacher::Settings set;
        for (const silveton::teacher::Input& in : ins) {
            std::printf("Изследвам %s ...\n", in.path.c_str()); std::fflush(stdout);
            try {
                const silveton::teacher::Sound snd = in.kmp ? silveton::teacher::readKmp(in.path) : silveton::teacher::readWavSound(in.path);
                const silveton::teacher::SoundStudy st = silveton::teacher::study(snd, set);
                std::printf("%s\n", st.report.c_str());
                if (st.okZones > 0) all.push_back(st);
            } catch (const std::exception& e) { std::printf("  ГРЕШКА: %s\n", e.what()); }
        }
        if (!out.empty()) {
            if (all.empty()) { std::printf("Нищо не е научено - няма какво да се запише.\n"); return 1; }
            const std::string f = silveton::teacher::writeLearned(all, out);
            std::printf("Записано: %s (%d звука) + SILVETON_OSC.txt\n", f.c_str(), (int)all.size());
        }
    } catch (const std::exception& e) { std::printf("ГРЕШКА: %s\n", e.what()); return 1; }
    return 0;
}
