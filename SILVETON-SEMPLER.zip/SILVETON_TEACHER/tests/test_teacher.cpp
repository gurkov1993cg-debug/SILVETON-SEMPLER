// SILVETON TEACHER - the listening is checked on sounds MADE with known numbers: the teacher must hear those numbers back.
#include "Teacher.h"

#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <memory>
#include <string>
#include <sys/stat.h>
#include <vector>

using namespace silveton::teacher;

static int g_checks = 0, g_fail = 0;
#define CHECK(cond, ...) do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("FAIL line %d: %s  ", __LINE__, #cond); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

namespace {
const double PI = 3.14159265358979323846;
struct Rng { uint32_t s = 777U; double next() { s = s * 1664525U + 1013904223U; return (double)(s >> 8) / 8388608.0 - 1.0; } };

struct Recipe {
    double f0 = 440.0, tuneCents = 0, seconds = 3.0, sr = 48000;
    double tiltPow = 1.3;            // amplitude 1/k^tiltPow
    bool oddOnly = false;
    double formantHz = 0, formantDb = 0;
    double vibHz = 0, vibCents = 0, vibAfter = 0.3;
    double lifeCents = 0;
    double breathDb = -200, breathLoHz = 2000, breathHiHz = 6000;
    double attackSec = 0.06, decaySec = 0.3, sustainDb = -3, releaseAt = 2.4, releaseTau = 0.2;
    double scoopCents = 0, scoopSec = 0.08;
    double inharmonicity = 0;
    int harmonics = 40;
};
std::vector<float> synth(const Recipe& r) {
    const int n = (int)(r.seconds * r.sr);
    std::vector<float> x((size_t)n, 0.0F);
    const double f0 = r.f0 * std::pow(2.0, r.tuneCents / 1200.0);
    std::vector<double> amp((size_t)r.harmonics), ph((size_t)r.harmonics, 0.0);
    for (int k = 1; k <= r.harmonics; ++k) {
        if (r.oddOnly && k % 2 == 0) { amp[(size_t)k - 1] = 0; continue; }
        double a = std::pow((double)k, -r.tiltPow);
        if (r.formantHz > 0) { const double d = std::log2(k * f0 / r.formantHz); a *= std::pow(10.0, r.formantDb / 20.0 * std::exp(-d * d / (2 * 0.25 * 0.25))); }
        amp[(size_t)k - 1] = a;
    }
    Rng rng; double life = 0; const double lifeCoef = std::exp(-2.0 * PI * 6.0 / r.sr); const double lifeGain = std::sqrt(3.0 * (1.0 + lifeCoef) / (1.0 - lifeCoef));
    // the breath: noise through a crude band-pass (two one-poles)
    const double lpc = std::exp(-2.0 * PI * r.breathHiHz / r.sr), hpc = std::exp(-2.0 * PI * r.breathLoHz / r.sr);
    struct Band { double l1 = 0, l2 = 0, h1 = 0, h2 = 0; double run(double w, double lpc, double hpc) { l1 = l1 * lpc + (1 - lpc) * w; l2 = l2 * lpc + (1 - lpc) * l1; const double a = l2 - h1; h1 = h1 * hpc + (1 - hpc) * l2; const double b = a - h2; h2 = h2 * hpc + (1 - hpc) * a; return b; } };
    Band band;
    double harmPower = 0; for (double a : amp) harmPower += a * a * 0.5;
    const double breathGain = r.breathDb > -100 ? std::sqrt(harmPower * std::pow(10.0, r.breathDb / 10.0)) : 0.0;
    double noiseRms = 0; { double e = 0; Band b2; Rng r2; for (int i = 0; i < 48000; ++i) { const double y = b2.run(r2.next(), lpc, hpc); if (i > 4800) e += y * y; } noiseRms = std::sqrt(e / 43200.0); }
    for (int i = 0; i < n; ++i) {
        const double t = i / r.sr;
        double env = 1.0;
        if (t < r.attackSec) env = t / r.attackSec;
        else if (t < r.attackSec + r.decaySec) { const double u = (t - r.attackSec) / r.decaySec; env = std::pow(10.0, r.sustainDb / 20.0 * u); }
        else env = std::pow(10.0, r.sustainDb / 20.0);
        if (t > r.releaseAt) env *= std::exp(-(t - r.releaseAt) / r.releaseTau);
        double cents = 0;
        if (r.scoopCents != 0 && t < r.scoopSec) cents += r.scoopCents * (1.0 - t / r.scoopSec);
        if (r.vibCents > 0 && t > r.vibAfter) cents += r.vibCents * std::sin(2 * PI * r.vibHz * (t - r.vibAfter)) * std::min(1.0, (t - r.vibAfter) / 0.3);
        if (r.lifeCents > 0) { life = life * lifeCoef + rng.next() * (1 - lifeCoef); cents += life * lifeGain * r.lifeCents; }
        const double f = f0 * std::pow(2.0, cents / 1200.0);
        double y = 0;
        for (int k = 1; k <= r.harmonics; ++k) {
            const double fk = f * k * std::sqrt(1.0 + r.inharmonicity * k * k); if (fk > r.sr * 0.47) break;
            ph[(size_t)k - 1] += fk / r.sr; if (ph[(size_t)k - 1] >= 1) ph[(size_t)k - 1] -= 1;
            y += amp[(size_t)k - 1] * std::sin(2 * PI * ph[(size_t)k - 1]);
        }
        if (breathGain > 0) y += band.run(rng.next(), lpc, hpc) / noiseRms * breathGain;
        x[(size_t)i] = (float)(y * env * 0.4);
    }
    return x;
}
Sound soundOf(const std::vector<float>& x, int sr, int rootKey, int lo = 0, int hi = 127, uint32_t loopStart = 0, uint32_t loopEnd = 0) {
    Sound s; s.name = "TEST"; s.kmp = true;
    Zone z; z.lowKey = lo; z.topKey = hi; z.rootKey = rootKey; z.file = "test"; z.sample.mono = x; z.sample.sampleRate = sr; z.sample.loopStart = loopStart; z.sample.loopEnd = loopEnd;
    s.zones.push_back(z); return s;
}
bool allFinite(const std::vector<float>& v) { for (float f : v) if (!std::isfinite(f)) return false; return true; }
double peakOf(const std::vector<float>& v) { double p = 0; for (float f : v) p = std::max(p, (double)std::fabs(f)); return p; }
double acfHz(const std::vector<float>& x, size_t from, size_t len, double lo, double hi, double sr) {
    double best = -1; int bestLag = 1;
    for (int lag = (int)(sr / hi); lag <= (int)(sr / lo); ++lag) { double r = 0; for (size_t i = from; i + (size_t)lag < from + len && i + (size_t)lag < x.size(); ++i) r += (double)x[i] * x[i + (size_t)lag]; if (r > best) { best = r; bestLag = lag; } }
    return sr / bestLag;
}
// writing a small KMP + KSF set, the way Korg does (big-endian chunks)
void putBe32(std::ofstream& o, uint32_t v) { char p[4] = {(char)(v >> 24), (char)(v >> 16), (char)(v >> 8), (char)v}; o.write(p, 4); }
void writeKsf(const std::string& path, const std::vector<float>& x, int sr, uint32_t loopStart, uint32_t loopEnd) {
    std::ofstream o(path.c_str(), std::ios::binary);
    o.write("SMP1", 4); putBe32(o, 32); char name[16] = "zone"; o.write(name, 16); putBe32(o, 0); putBe32(o, 0); putBe32(o, loopStart); putBe32(o, loopEnd);
    o.write("SMD1", 4); putBe32(o, (uint32_t)(12 + x.size() * 2)); putBe32(o, (uint32_t)sr); o.put(0); o.put(0); o.put(1); o.put(16); putBe32(o, (uint32_t)x.size());
    for (float f : x) { const int v = (int)std::lround(std::max(-1.0, std::min(1.0, (double)f)) * 32767.0); o.put((char)((v >> 8) & 255)); o.put((char)(v & 255)); }
}
void writeKmp(const std::string& path, const std::string& name, const std::vector<std::string>& files, const std::vector<int>& roots, const std::vector<int>& tops) {
    std::ofstream o(path.c_str(), std::ios::binary);
    o.write("MSP1", 4); putBe32(o, 18); char nm[16]; std::memset(nm, ' ', 16); std::memcpy(nm, name.data(), std::min<size_t>(16, name.size())); o.write(nm, 16); o.put((char)files.size()); o.put(0);
    o.write("RLP1", 4); putBe32(o, (uint32_t)(18 * files.size()));
    for (size_t i = 0; i < files.size(); ++i) { unsigned char r[18] = {}; r[0] = (unsigned char)roots[i]; r[1] = (unsigned char)tops[i]; r[2] = 0; std::memset(r + 6, ' ', 12); std::memcpy(r + 6, files[i].data(), std::min<size_t>(12, files[i].size())); o.write((const char*)r, 18); }
}
}  // namespace

int main() {
    Settings set;
    // ---- 1) a kaval-like tone with known numbers
    {
        Recipe r; r.f0 = 440.0; r.tuneCents = 7; r.formantHz = 1500; r.formantDb = 8; r.vibHz = 5.5; r.vibCents = 15; r.lifeCents = 4; r.breathDb = -22; r.scoopCents = -40;
        const std::vector<float> x = synth(r);
        const SoundStudy s = study(soundOf(x, 48000, 69), set);
        CHECK(s.okZones == 1, "the tone is heard (%s)", s.zones[0].why.c_str());
        const ZoneStudy& z = s.zones[0];
        std::printf("  kaval: tune %+.1f c  vib %.2f Hz +-%.1f c  life %.1f c  attack %.0f ms  decay %.0f ms  sustain %.1f dB  release %.0f ms  breath %.1f dB @ %.0f Hz  tilt %.1f  centroid %.1f  scoop %+.0f  formants:", z.tuneCents, z.vibratoHz, z.vibratoCents, z.lifeCents, z.attackMs, z.decayMs, z.sustainDb, z.releaseMs, z.breathDb, z.breathColourHz, z.tiltDbPerOctave, z.centroidHarmonic, z.scoopCents);
        for (const Formant& f : z.formants) std::printf(" %.0f(%+.0f)", f.hz, f.db);
        std::printf("\n");
        CHECK(std::fabs(z.tuneCents - 7.0) < 3.0, "tuning %+.1f c (made +7)", z.tuneCents);
        CHECK(std::fabs(z.vibratoHz - 5.5) < 0.4, "vibrato %.2f Hz (made 5.5)", z.vibratoHz);
        CHECK(std::fabs(z.vibratoCents - 15.0) < 5.0, "vibrato depth %.1f c (made 15)", z.vibratoCents);
        CHECK(z.lifeCents > 1.0 && z.lifeCents < 9.0, "life %.1f c (made about 4)", z.lifeCents);
        CHECK(z.attackMs > 30 && z.attackMs < 95, "attack %.0f ms (made 60)", z.attackMs);
        CHECK(std::fabs(z.sustainDb + 3.0) < 1.5, "sustain %.1f dB (made -3)", z.sustainDb);
        CHECK(z.decayMs > 140 && z.decayMs < 420, "decay %.0f ms (made 300; measured to 80 %% of the way)", z.decayMs);
        CHECK(std::fabs(z.breathDb + 22.0) < 4.0, "breath %.1f dB (made -22)", z.breathDb);
        CHECK(z.breathColourHz > 1500 && z.breathColourHz < 7000, "breath colour %.0f Hz (made 2-6 kHz)", z.breathColourHz);
        CHECK(z.tiltDbPerOctave < -5.0 && z.tiltDbPerOctave > -11.0, "tilt %.1f dB/oct (made about -7.8)", z.tiltDbPerOctave);
        bool f1500 = false; for (const Formant& f : z.formants) if (std::fabs(f.hz - 1500) < 300) f1500 = true;
        CHECK(f1500, "a formant near 1500 Hz is found");
        CHECK(z.scoopCents < -12.0, "the attack starts below the pitch (%+.0f c, made -40 fading)", z.scoopCents);
        CHECK(z.releaseMs > 500 && z.releaseMs < 3000, "release %.0f ms (made tau 200 ms -> about 1400 to -60 dB)", z.releaseMs);
        CHECK(z.inharmonicity == 0.0F, "no inharmonicity (%.6f)", z.inharmonicity);
        CHECK(!z.looped && z.harmonics >= 16 && z.attackFrames >= 4 && z.harmonicTrack.size() == (size_t)(z.attackFrames + kLoopFrames) * z.harmonics, "the model has its rows");
        CHECK(s.report.find("вибрато") != std::string::npos && s.report.find("форманти") != std::string::npos, "the report speaks");
        // what was learned, played anew: the same pitch, a similar colour and breath; BRIGHT and BREATH move them
        PreviewKnobs k;
        const std::vector<float> p = previewLearned(s, 69, 2.0, 48000, k);
        CHECK(allFinite(p) && peakOf(p) > 0.1 && peakOf(p) <= 1.0, "the preview sounds (peak %.2f)", peakOf(p));
        const double hz = acfHz(p, 24000, 8192, 400, 480, 48000);
        CHECK(std::fabs(1200 * std::log2(hz / 440.0)) < 25.0, "the preview is at A4 (%.1f Hz; vibrato and life move it a little)", hz);
        Sound ps = soundOf(p, 48000, 69); SoundStudy pst = study(ps, set);
        CHECK(pst.okZones == 1, "the preview is a clear tone");
        if (pst.okZones == 1) {
            std::printf("  preview: centroid %.1f (orig %.1f)  breath %.1f (orig %.1f)  vib %.1f Hz\n", pst.zones[0].centroidHarmonic, z.centroidHarmonic, pst.zones[0].breathDb, z.breathDb, pst.zones[0].vibratoHz);
            CHECK(std::fabs(pst.zones[0].centroidHarmonic - z.centroidHarmonic) < 0.6 * z.centroidHarmonic, "the preview keeps the colour");
            CHECK(std::fabs(pst.zones[0].breathDb - z.breathDb) < 6.0, "the preview keeps the breath");
            k.brightDbPerOctave = 6.0F; const std::vector<float> pb = previewLearned(s, 69, 2.0, 48000, k); SoundStudy sb = study(soundOf(pb, 48000, 69), set);
            CHECK(sb.okZones == 1 && sb.zones[0].centroidHarmonic > pst.zones[0].centroidHarmonic * 1.25, "BRIGHT +6 dB/oct makes it brighter (%.1f -> %.1f)", pst.zones[0].centroidHarmonic, sb.okZones ? sb.zones[0].centroidHarmonic : 0.0F);
            k.brightDbPerOctave = 0; k.breathDb = 12.0F; const std::vector<float> pn = previewLearned(s, 69, 2.0, 48000, k); SoundStudy sn = study(soundOf(pn, 48000, 69), set);
            CHECK(sn.okZones == 1 && sn.zones[0].breathDb > pst.zones[0].breathDb + 6.0, "BREATH +12 dB makes it airier (%.1f -> %.1f)", pst.zones[0].breathDb, sn.okZones ? sn.zones[0].breathDb : 0.0F);
        }
        // at another key the preview plays that key
        const std::vector<float> p2 = previewLearned(s, 57, 1.0, 48000, PreviewKnobs());
        const double hz2 = acfHz(p2, 12000, 8192, 200, 240, 48000);
        CHECK(std::fabs(1200 * std::log2(hz2 / 220.0)) < 25.0, "the preview at A3 is at 220 Hz (%.1f)", hz2);
    }
    // ---- 2) a WAV: the note is found by listening
    {
        Recipe r; r.f0 = 261.6256; r.vibCents = 0; r.lifeCents = 0; r.breathDb = -30;
        Sound s0 = soundOf(synth(r), 48000, -1); s0.kmp = false;
        const SoundStudy s = study(s0, set);
        CHECK(s.okZones == 1 && s.zones[0].rootKey == 60, "a WAV at middle C is heard as C4 (key %d)", s.zones[0].rootKey);
        CHECK(s.okZones == 1 && std::fabs(s.zones[0].tuneCents) < 3.0, "and in tune (%+.1f c)", s.zones[0].tuneCents);
    }
    // ---- 3) odd harmonics only (a clarinet / a square)
    {
        Recipe r; r.f0 = 196.0; r.oddOnly = true; r.vibCents = 0; r.lifeCents = 0; r.tiltPow = 1.0;
        const SoundStudy s = study(soundOf(synth(r), 48000, 55), set);
        CHECK(s.okZones == 1 && s.zones[0].oddEvenDb > 12.0, "odd harmonics stand out (%+.1f dB)", s.okZones ? s.zones[0].oddEvenDb : 0.0F);
        CHECK(s.okZones == 1 && std::fabs(s.zones[0].tiltDbPerOctave + 6.0) < 2.5, "a 1/k spectrum tilts about -6 dB/oct (%.1f)", s.okZones ? s.zones[0].tiltDbPerOctave : 0.0F);
    }
    // ---- 4) a string: the harmonics sit above k f0
    {
        Recipe r; r.f0 = 110.0; r.inharmonicity = 0.0004; r.vibCents = 0; r.lifeCents = 0; r.harmonics = 30;
        const SoundStudy s = study(soundOf(synth(r), 48000, 45), set);
        CHECK(s.okZones == 1 && s.zones[0].inharmonicity > 0.00025 && s.zones[0].inharmonicity < 0.0006, "inharmonicity %.5f (made 0.0004)", s.okZones ? s.zones[0].inharmonicity : 0.0F);
    }
    // ---- 4b) a low note at 96 kHz: the resolution still holds
    {
        Recipe r; r.f0 = 55.0; r.sr = 96000; r.vibHz = 4.5; r.vibCents = 12; r.lifeCents = 2; r.breathDb = -28; r.harmonics = 60; r.tiltPow = 1.0;
        const SoundStudy s = study(soundOf(synth(r), 96000, 33), set);
        CHECK(s.okZones == 1, "A1 at 96 kHz is heard (%s)", s.zones[0].why.c_str());
        if (s.okZones == 1) {
            CHECK(std::fabs(s.zones[0].tuneCents) < 4.0, "A1: tuning %+.1f c", s.zones[0].tuneCents);
            CHECK(std::fabs(s.zones[0].vibratoHz - 4.5) < 0.5 && std::fabs(s.zones[0].vibratoCents - 12.0) < 5.0, "A1: vibrato %.2f Hz +-%.1f c (made 4.5 / 12)", s.zones[0].vibratoHz, s.zones[0].vibratoCents);
            CHECK(std::fabs(s.zones[0].breathDb + 28.0) < 5.0, "A1: breath %.1f dB (made -28)", s.zones[0].breathDb);
            const std::vector<float> p = previewLearned(s, 45, 1.0, 48000, PreviewKnobs());
            CHECK(allFinite(p) && peakOf(p) > 0.1, "A1 learned plays at A2");
        }
    }
    // ---- 4c) the note in the KMP is two octaves below what the sample sounds (an octave-shifted multisample)
    {
        Recipe r; r.f0 = 261.6256; r.vibCents = 0; r.lifeCents = 0; r.breathDb = -30; r.seconds = 1.5; r.releaseAt = 99;
        const SoundStudy s = study(soundOf(synth(r), 48000, 36, 0, 127, 48000 * 0.8, 48000 * 1.4), set);   // the KMP says C2, it sounds C4
        CHECK(s.okZones == 1, "the octave-shifted sample is heard (%s)", s.zones[0].why.c_str());
        if (s.okZones == 1) {
            CHECK(std::fabs(s.zones[0].tuneCents - 2400.0) < 8.0, "it is two octaves above its note (%+.0f c)", s.zones[0].tuneCents);
            CHECK(std::fabs(s.zones[0].f0Hz - 261.6) < 1.5 && s.zones[0].harmonicDb[0] > -3.0F && s.zones[0].harmonicDb[1] < -3.0F, "and its real harmonics are read (%.1f Hz, h1 %.0f, h2 %.0f)", s.zones[0].f0Hz, s.zones[0].harmonicDb[0], s.zones[0].harmonicDb[1]);
            CHECK(s.report.find("ОКТАВИ НАД") != std::string::npos && !s.warnings.empty(), "the report says so");
            const std::vector<float> p = previewLearned(s, 36, 1.0, 48000, PreviewKnobs());
            const double hz = acfHz(p, 12000, 8192, 240, 290, 48000);
            CHECK(std::fabs(1200 * std::log2(hz / 261.6)) < 20.0, "on the key C2 the learned sound plays C4, as the sampler would (%.1f Hz)", hz);
        }
    }
    // ---- 5) noise is not a tone
    {
        Rng rng; std::vector<float> x(48000); for (float& f : x) f = (float)(rng.next() * 0.3);
        const SoundStudy s = study(soundOf(x, 48000, 60), set);
        CHECK(s.okZones == 0 && s.zones[0].why.find("pitch") != std::string::npos, "white noise is skipped (%s)", s.zones[0].why.c_str());
    }
    // ---- 6) a looped sample: the steady part is the loop, no release
    {
        Recipe r; r.f0 = 330.0; r.vibCents = 0; r.lifeCents = 0; r.releaseAt = 99; r.seconds = 2.0;
        const std::vector<float> x = synth(r);
        const SoundStudy s = study(soundOf(x, 48000, 64, 0, 127, 48000, 90000), set);
        CHECK(s.okZones == 1 && s.zones[0].looped && s.zones[0].releaseMs < 0, "a looped sample: loop seen, no release");
        CHECK(s.okZones == 1 && std::fabs(s.zones[0].loopStartMs - 1000.0F) < 1.0F, "loop start %.0f ms", s.zones[0].loopStartMs);
    }
    // ---- 7) KMP + KSF on disk, three zones, the file for the tablet and back
    {
        const std::string dir = "/tmp/SILVETON_TEACHER_TEST"; ::mkdir(dir.c_str(), 0755); ::mkdir((dir + "/sub").c_str(), 0755); ::mkdir((dir + "/sub/KAVAL").c_str(), 0755);
        const int roots[3] = {57, 69, 81}; const int tops[3] = {63, 75, 127};
        std::vector<std::string> files;
        for (int i = 0; i < 3; ++i) {
            Recipe r; r.f0 = 440.0 * std::pow(2.0, (roots[i] - 69) / 12.0); r.vibCents = 10; r.vibHz = 5; r.breathDb = -30 + 4 * i; r.seconds = 2.0; r.releaseAt = 99;
            const std::string f = "MS00000" + std::to_string(i + 1) + ".KSF"; files.push_back(f);
            writeKsf(dir + "/sub/KAVAL/" + f, synth(r), 48000, 24000, 90000);
        }
        writeKmp(dir + "/sub/KAVAL.KMP", "KAVAL", files, std::vector<int>(roots, roots + 3), std::vector<int>(tops, tops + 3));
        const std::vector<Input> ins = collectInputs({dir});
        CHECK(ins.size() == 1 && ins[0].kmp, "the folder search finds the KMP (%d)", (int)ins.size());
        const InputInfo info = describeInput(ins[0]);
        CHECK(info.name == "KAVAL" && info.zones == 3, "the list knows the name and the zones (%s, %d)", info.name.c_str(), info.zones);
        const Sound k = readKmp(dir + "/sub/KAVAL.KMP");
        CHECK(k.zones.size() == 3 && k.zones[0].error.empty() && k.zones[2].lowKey == 76 && k.zones[2].topKey == 127, "the KMP and its KSF files are read");
        CHECK(k.zones[1].sample.looped() && k.zones[1].sample.loopStart == 24000, "the loop of the KSF is read");
        const SoundStudy s = study(k, set);
        CHECK(s.okZones == 3, "all three zones are heard");
        CHECK(zoneForKey(s, 60) == 0 && zoneForKey(s, 70) == 1 && zoneForKey(s, 100) == 2, "the zones by key");
        CHECK(s.breathDbHigh > s.breathDbLow + 4.0, "the breath grows up the keyboard (%.1f -> %.1f)", s.breathDbLow, s.breathDbHigh);
        std::vector<SoundStudy> all; all.push_back(s);
        const std::string file = writeLearned(all, dir);
        CHECK(file == dir + "/SILVETON_OSC.sv", "the file is written (%s)", file.c_str());
        const std::vector<SoundStudy> back = readLearned(file);
        CHECK(back.size() == 1 && back[0].name == "KAVAL" && back[0].zones.size() == 3 && back[0].okZones == 3, "and read back");
        if (back.size() == 1 && back[0].zones.size() == 3) {
            CHECK(back[0].zones[1].harmonicTrack == s.zones[1].harmonicTrack && back[0].zones[1].noiseTrack == s.zones[1].noiseTrack && back[0].zones[1].pitchTrack == s.zones[1].pitchTrack, "the tracks are the same");
            CHECK(std::fabs(back[0].zones[1].vibratoHz - s.zones[1].vibratoHz) < 1e-4 && back[0].zones[1].formants.size() == s.zones[1].formants.size(), "the numbers are the same");
            const std::vector<float> p = previewLearned(back[0], 72, 1.0, 48000, PreviewKnobs());
            CHECK(allFinite(p) && peakOf(p) > 0.1, "what was read back plays");
        }
        std::ifstream t((dir + "/SILVETON_OSC.txt").c_str()); std::string txt((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
        CHECK(txt.find("KAVAL") != std::string::npos && txt.find("A4") != std::string::npos, "the report names the sound and its notes");
        const std::vector<float> o = previewOriginal(k, s, 69, 1.0, 48000);
        CHECK(allFinite(o) && peakOf(o) > 0.1, "the original plays");
    }
    // ---- 8) slots, a file that is added to, and the live player (a MIDI keyboard)
    {
        const std::string dir = "/tmp/SILVETON_TEACHER_TEST2"; ::mkdir(dir.c_str(), 0755); std::remove((dir + "/SILVETON_OSC.sv").c_str());
        Recipe r; r.f0 = 440.0; r.vibCents = 0; r.lifeCents = 0; r.breathDb = -30; r.seconds = 2.0; r.releaseAt = 99;
        SoundStudy a = study(soundOf(synth(r), 48000, 69), set); a.name = "KAVAL A"; a.slot = "КАВАЛ";
        r.f0 = 330.0; SoundStudy b = study(soundOf(synth(r), 48000, 64), set); b.name = "VIOLIN"; b.slot = "ЦИГУЛКА";
        writeLearned(std::vector<SoundStudy>(1, a), dir);
        writeLearned(std::vector<SoundStudy>(1, b), dir);                 // a second sitting: added, not overwritten
        std::vector<SoundStudy> both = readLearned(dir + "/SILVETON_OSC.sv");
        CHECK(both.size() == 2 && both[0].slot == "КАВАЛ" && both[1].slot == "ЦИГУЛКА", "two sittings = two sounds with their slots (%d)", (int)both.size());
        a.slot = "КАВАЛ"; a.zones[0].attackMs = 123.0F;
        writeLearned(std::vector<SoundStudy>(1, a), dir);                 // the same name and slot again: replaced
        both = readLearned(dir + "/SILVETON_OSC.sv");
        CHECK(both.size() == 2 && both[0].zones[0].attackMs == 123.0F, "the same sound again replaces the old one (%d, attack %.0f)", (int)both.size(), both.empty() ? 0.0F : both[0].zones[0].attackMs);
        std::ifstream t((dir + "/SILVETON_OSC.txt").c_str()); std::string txt((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
        CHECK(txt.find("СЛОТ: ЦИГУЛКА") != std::string::npos && txt.find("СЛОТ: КАВАЛ") != std::string::npos, "the report names the slots");

        LivePlayer live; live.prepare(48000.0);
        std::shared_ptr<const SoundStudy> ls = std::make_shared<SoundStudy>(both[0]);
        Sound orig = soundOf(synth(Recipe()), 48000, 69); std::shared_ptr<const Sound> os = std::make_shared<Sound>(orig);
        live.setSound(ls, os);
        std::vector<float> L(24000), R(24000);
        live.noteOn(69, 100);
        for (int blk = 0; blk < 24000 / 512; ++blk) live.render(&L[(size_t)blk * 512], &R[(size_t)blk * 512], 512);
        CHECK(allFinite(L) && peakOf(L) > 0.05 && peakOf(L) <= 1.0, "the live learned note sounds (peak %.2f)", peakOf(L));
        CHECK(std::fabs(1200 * std::log2(acfHz(L, 12000, 8192, 400, 480, 48000) / 440.0)) < 15.0, "the live note is at A4 (%.1f Hz)", acfHz(L, 12000, 8192, 400, 480, 48000));
        CHECK(live.activeNotes() == 1, "one note");
        live.noteOn(64, 90); live.noteOn(76, 90);
        for (int blk = 0; blk < 10; ++blk) live.render(&L[(size_t)blk * 512], &R[(size_t)blk * 512], 512);
        CHECK(live.activeNotes() == 3, "three notes at once");
        live.noteOff(69); live.noteOff(64); live.noteOff(76);
        for (int blk = 0; blk < 48000 * 3 / 512; ++blk) live.render(L.data(), R.data(), 512);
        CHECK(live.activeNotes() == 0 && peakOf(std::vector<float>(L.begin(), L.begin() + 512)) < 1e-3, "let go, the notes fade out and end");
        live.pitchBend(12.0); live.noteOn(57, 100);
        std::vector<float> B(24000);
        for (int blk = 0; blk < 24000 / 512; ++blk) live.render(&B[(size_t)blk * 512], nullptr, 512);
        CHECK(std::fabs(1200 * std::log2(acfHz(B, 12000, 8192, 400, 480, 48000) / 440.0)) < 15.0, "bend +12 on A3 sounds A4 (%.1f Hz)", acfHz(B, 12000, 8192, 400, 480, 48000));
        live.allNotesOff(); live.pitchBend(0.0);
        for (int blk = 0; blk < 48000 * 2 / 512; ++blk) live.render(B.data(), nullptr, 512);
        live.setOriginal(true); live.noteOn(69, 100);
        for (int blk = 0; blk < 24000 / 512; ++blk) live.render(&B[(size_t)blk * 512], nullptr, 512);
        CHECK(allFinite(B) && peakOf(B) > 0.05, "the original plays live too (peak %.2f)", peakOf(B));
        CHECK(std::fabs(1200 * std::log2(acfHz(B, 12000, 8192, 400, 480, 48000) / 440.0)) < 15.0, "the live original is at A4 (%.1f Hz)", acfHz(B, 12000, 8192, 400, 480, 48000));
        live.setSound(nullptr, nullptr);
        CHECK(live.activeNotes() == 0, "no sound = silence");
        // twelve notes at once: no voice is lost without a sound, nothing explodes
        live.setSound(ls, os); live.setOriginal(false);
        for (int k = 48; k < 60; ++k) live.noteOn(k, 100);
        for (int blk = 0; blk < 20; ++blk) live.render(&B[(size_t)blk * 512], nullptr, 512);
        CHECK(live.activeNotes() == LivePlayer::kVoices && allFinite(B) && peakOf(B) <= 1.0, "twelve keys: the ten voices play, the sum stays below 1 (peak %.2f)", peakOf(B));
    }
    // ---- 9) a short Korg-style sample: 306 ms, a loop of 45 ms at its end (what a Pa multisample really looks like)
    {
        for (const int key : {60, 62, 64, 67, 81, 93}) {
            Recipe r; r.f0 = 440.0 * std::pow(2.0, (key - 69) / 12.0); r.seconds = 0.306; r.attackSec = 0.02; r.decaySec = 0.12; r.sustainDb = -1.0; r.releaseAt = 99;
            r.vibCents = 0; r.lifeCents = 0; r.breathDb = -30; r.harmonics = 40;
            std::vector<float> x = synth(r);
            // the loop: a whole number of periods, 45 ms from the end
            const double period = 48000.0 / r.f0; const uint32_t loopEnd = 48000 * 0.300; const uint32_t loopStart = loopEnd - (uint32_t)(std::round(0.045 * 48000 / period) * period);
            const SoundStudy s = study(soundOf(x, 48000, key, 0, 127, loopStart, loopEnd), set);
            CHECK(s.okZones == 1, "short looped sample at key %d is heard (%s)", key, s.zones[0].why.c_str());
            if (s.okZones == 1) {
                CHECK(std::fabs(s.zones[0].tuneCents) < 4.0, "key %d: tuning %+.1f c", key, s.zones[0].tuneCents);
                CHECK(s.zones[0].breathDb < -20.0, "key %d: breath %.1f dB (made -30) - a short loop must not read as noise", key, s.zones[0].breathDb);
                CHECK(s.zones[0].looped && std::fabs(s.zones[0].loopLengthMs - 45.0) < 6.0, "key %d: the loop is %.0f ms (made 45)", key, s.zones[0].loopLengthMs);
                CHECK(s.zones[0].attackMs < 40.0, "key %d: attack %.0f ms (made 20)", key, s.zones[0].attackMs);
            }
        }
    }
    std::printf("%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
