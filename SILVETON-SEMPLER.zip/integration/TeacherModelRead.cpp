// Minimal cross-project consumer: compile with core/src/sampler/ModelBank.cpp.
#include "silveton/sampler/ModelBank.h"
#include <cstdio>
int main(int argc, char** argv) {
    if (argc != 2) return 2;
    const auto bank = silveton::sampler::model::loadLearnedModels(argv[1]);
    if (!bank->error.empty() || bank->models.empty()) {
        std::fprintf(stderr, "FAILED: %s\n", bank->error.c_str()); return 1;
    }
    unsigned valid = 0;
    for (const auto& model : bank->models) for (const auto& z : model.zones) {
        if (z.ok) {
            if (z.trackRows <= 0 || z.trackH <= 0) return 3;
            ++valid;
        }
    }
    std::printf("PASS: %zu model(s), %u valid zone(s)\n", bank->models.size(), valid);
    return valid ? 0 : 4;
}
