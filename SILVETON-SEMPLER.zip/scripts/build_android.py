#!/usr/bin/env python3
"""Build the C++ NativeActivity APK with the Android SDK/NDK; no Gradle or javac needed.

Use the same private keystore for every update. Passwords are read from a file,
never printed or put on the command line. This script never generates a key.
"""
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', default=os.environ.get('ANDROID_SDK_ROOT', os.environ.get('ANDROID_HOME')))
    parser.add_argument('--ndk', default=os.environ.get('ANDROID_NDK_HOME'))
    parser.add_argument('--cmake', default='cmake')
    parser.add_argument('--build-dir', type=Path, default=root / 'build-android')
    parser.add_argument('--output', type=Path, default=root / 'SILVETON-SAMPLER-SM-X130.apk')
    parser.add_argument('--keystore', type=Path, required=True)
    parser.add_argument('--password-file', type=Path, required=True)
    parser.add_argument('--alias', default='silveton')
    parser.add_argument('--jobs', type=int, default=4)
    args = parser.parse_args()
    if not args.sdk or not args.ndk:
        parser.error('Provide --sdk and --ndk, or ANDROID_SDK_ROOT and ANDROID_NDK_HOME.')
    sdk, ndk = Path(args.sdk).resolve(), Path(args.ndk).resolve()
    bt = sdk / 'build-tools' / '35.0.0'
    platform = sdk / 'platforms' / 'android-35' / 'android.jar'
    hosts = {'linux': 'linux-x86_64', 'darwin': 'darwin-x86_64'}
    if sys.platform not in hosts:
        parser.error('This builder supports Linux and macOS; use Gradle on Windows.')
    strip = ndk / 'toolchains' / 'llvm' / 'prebuilt' / hosts[sys.platform] / 'bin' / 'llvm-strip'
    for f in [bt / 'aapt2', bt / 'zipalign', bt / 'apksigner', platform, strip,
              args.keystore, args.password_file]:
        if not f.is_file():
            parser.error('Missing required file: ' + str(f))
    src = root / 'silveton_pro_payload'
    build = args.build_dir.resolve()
    build.mkdir(parents=True, exist_ok=True)
    stage = build / 'apk'
    stage.mkdir(exist_ok=True)

    def run(*command):
        subprocess.run([str(x) for x in command], check=True)

    run(args.cmake, '-S', src, '-B', build,
        '-DCMAKE_TOOLCHAIN_FILE=' + str(ndk / 'build/cmake/android.toolchain.cmake'),
        '-DANDROID_ABI=arm64-v8a', '-DANDROID_PLATFORM=android-26', '-DANDROID_STL=c++_static',
        '-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON', '-DCMAKE_BUILD_TYPE=Release', '-DIMAK_BUILD_TESTS=OFF')
    run(args.cmake, '--build', build, '--target', 'silveton_sampler', '-j', str(args.jobs))

    # Keep version and package identical to the regular Gradle build.
    gradle = (src / 'android/app/build.gradle.kts').read_text()
    package = re.search(r'applicationId\s*=\s*"([^"]+)"', gradle).group(1)
    code = re.search(r'versionCode\s*=\s*(\d+)', gradle).group(1)
    version = re.search(r'versionName\s*=\s*"([^"]+)"', gradle).group(1)
    ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
    manifest = ET.parse(src / 'android/app/src/main/AndroidManifest.xml')
    manifest.getroot().set('package', package)
    # Gradle sets this through packaging.jniLibs; the direct aapt2 path must set it here.
    manifest.getroot().find('application').set('{http://schemas.android.com/apk/res/android}extractNativeLibs', 'false')
    manifest.write(stage / 'AndroidManifest.xml', encoding='utf-8', xml_declaration=True)
    run(bt / 'aapt2', 'compile', '--dir', src / 'android/app/src/main/res', '-o', stage / 'resources.zip')
    unsigned = stage / 'unsigned.apk'
    run(bt / 'aapt2', 'link', '-I', platform, '--manifest', stage / 'AndroidManifest.xml',
        '--min-sdk-version', '26', '--target-sdk-version', '35', '--version-code', code,
        '--version-name', version, '-A', src / 'resources', '-o', unsigned, stage / 'resources.zip')
    native = stage / 'libsilveton_sampler.so'
    shutil.copyfile(build / 'libsilveton_sampler.so', native)
    run(strip, '--strip-unneeded', native)
    with zipfile.ZipFile(unsigned, 'a') as apk:
        apk.write(native, 'lib/arm64-v8a/libsilveton_sampler.so', compress_type=zipfile.ZIP_STORED)
    aligned = stage / 'aligned.apk'
    run(bt / 'zipalign', '-f', '-P', '16', '4', unsigned, aligned)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    password = 'file:' + str(args.password_file.resolve())
    run(bt / 'apksigner', 'sign', '--ks', args.keystore.resolve(), '--ks-key-alias', args.alias,
        '--ks-pass', password, '--v4-signing-enabled', 'false',
        '--out', output, aligned)
    run(bt / 'zipalign', '-c', '-P', '16', '4', output)
    run(bt / 'apksigner', 'verify', '--verbose', output)
    run(bt / 'aapt2', 'dump', 'badging', output)
    print('Signed APK:', output)
    print('Build and package verified. Device audio/MIDI testing is still required.')


if __name__ == '__main__':
    main()
