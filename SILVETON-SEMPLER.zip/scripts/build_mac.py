#!/usr/bin/env python
# Python 2.7 (built into High Sierra) and Python 3. No downloaded packages, CMake or Homebrew needed.
from __future__ import print_function
import hashlib
import json
import os
import platform
import plistlib
import shutil
import subprocess
import sys
import tempfile
from multiprocessing.pool import ThreadPool

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCE = os.path.join(ROOT, 'silveton_pro_payload')
BUILD = os.path.join(ROOT, 'build-mac')

def output(argv):
    return subprocess.check_output(argv, stderr=subprocess.STDOUT).decode('utf-8', 'replace').strip()

def show_diagnostic(message):
    """Keep the complete diagnostic in Terminal, including Python 2.7 on macOS."""
    if not message:
        return
    text = message.decode('utf-8', 'replace')
    if sys.version_info[0] < 3:
        sys.stdout.write(text.encode('utf-8'))
    else:
        sys.stdout.write(text)
    if not text.endswith('\n'):
        sys.stdout.write('\n')
    sys.stdout.flush()

def source_files():
    files = []
    for folder in ('core/src', 'ui/src', 'host/src/mac'):
        for parent, dirs, names in os.walk(os.path.join(SOURCE, folder)):
            dirs.sort()
            for name in sorted(names):
                if name.endswith('.cpp'):
                    files.append(os.path.join(parent, name))
    files.extend([os.path.join(SOURCE, 'host/src/SamplerHost.cpp'), os.path.join(SOURCE, 'app/mac/main.mm')])
    return files

def main():
    if '--list-sources' in sys.argv:
        for path in source_files(): print(os.path.relpath(path, SOURCE))
        return 0
    if platform.system() != 'Darwin':
        raise RuntimeError('Run this build on macOS with Xcode 10.1 or newer Apple command-line tools.')
    if not os.path.isdir(BUILD): os.makedirs(BUILD)
    try:
        compiler = output(['/usr/bin/xcrun', '--find', 'clang++'])
        sdk = output(['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-path'])
    except subprocess.CalledProcessError:
        raise RuntimeError('Xcode command-line tools are not ready. Open Xcode 10.1 once and complete its setup.')
    flags = ['-std=c++17', '-stdlib=libc++', '-arch', 'x86_64', '-mmacosx-version-min=10.13',
             '-isysroot', sdk, '-O2', '-DNDEBUG', '-pthread', '-fvisibility=hidden',
             '-Werror=unguarded-availability-new']
    for folder in ('core/include', 'core/src/sampler', 'host/include', 'ui/include', 'ui/src', 'third_party/stb'):
        flags += ['-I', os.path.join(SOURCE, folder)]
    # Invalidate all objects if the compiler, flags or any source/header changed. Subsequent unchanged builds are fast.
    digest = hashlib.sha256()
    digest.update((output([compiler, '--version']) + repr(flags)).encode('utf-8'))
    for parent, dirs, names in os.walk(SOURCE):
        dirs[:] = sorted(d for d in dirs if d not in ('android', '.git'))
        for name in sorted(names):
            if name.endswith(('.h', '.hpp', '.inc', '.cpp', '.mm')):
                path = os.path.join(parent, name)
                digest.update(os.path.relpath(path, SOURCE).encode('utf-8'))
                with open(path, 'rb') as handle: digest.update(handle.read())
    fingerprint = digest.hexdigest()
    cache = os.path.join(BUILD, 'objects-' + fingerprint[:16])
    if not os.path.isdir(cache): os.makedirs(cache)
    files = source_files()
    if not all(os.path.isfile(path) for path in files): raise RuntimeError('Incomplete source archive')
    jobs = min(2, max(1, int(os.environ.get('SILVETON_BUILD_JOBS', '2'))))
    logpath = os.path.join(BUILD, 'build.log')
    print('Building Intel x86_64 / macOS 10.13; %d source files, %d jobs.' % (len(files), jobs))
    sys.stdout.flush()

    def compile_one(path):
        rel = os.path.relpath(path, SOURCE)
        obj = os.path.join(cache, rel.replace('/', '_') + '.o')
        if os.path.isfile(obj): return (rel, obj, 0, b'')
        extra = ['-fobjc-arc'] if path.endswith('.mm') else []
        proc = subprocess.Popen([compiler] + flags + extra + ['-c', path, '-o', obj + '.tmp'],
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        message = proc.communicate()[0]
        if proc.returncode == 0: os.rename(obj + '.tmp', obj)
        return (rel, obj, proc.returncode, message)

    objects, errors = [], []
    pool = ThreadPool(jobs)
    with open(logpath, 'wb') as log:
        try:
            for index, (rel, obj, rc, message) in enumerate(pool.imap(compile_one, files), 1):
                print('[%d/%d] %s%s' % (index, len(files), rel, ' FAILED' if rc else ''))
                sys.stdout.flush()
                log.write(('\nSOURCE: ' + rel + '\n').encode('utf-8')); log.write(message); log.flush()
                if rc:
                    errors.append(rel)
                    show_diagnostic(message)
                objects.append(obj)
        finally:
            pool.close(); pool.join()
        if errors: raise RuntimeError('Compilation failed: %s. Read %s' % (', '.join(errors), logpath))
        stage = tempfile.mkdtemp(prefix='app-stage-', dir=BUILD)
        app = os.path.join(stage, 'SILVETON SAMPLER.app')
        contents = os.path.join(app, 'Contents')
        executable = os.path.join(contents, 'MacOS', 'SILVETON SAMPLER')
        os.makedirs(os.path.dirname(executable))
        os.makedirs(os.path.join(contents, 'Resources'))
        link = [compiler] + flags + objects + ['-o', executable]
        for framework in ('Cocoa', 'CoreAudio', 'AudioToolbox', 'AudioUnit', 'CoreMIDI', 'CoreGraphics', 'QuartzCore'):
            link += ['-framework', framework]
        proc = subprocess.Popen(link, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        message = proc.communicate()[0]; log.write(message)
        if proc.returncode:
            show_diagnostic(message)
            raise RuntimeError('Linking failed. Read ' + logpath)
        shutil.copytree(os.path.join(SOURCE, 'resources', 'fonts'), os.path.join(contents, 'Resources', 'fonts'))
        info = dict(CFBundleExecutable='SILVETON SAMPLER', CFBundleName='SILVETON SAMPLER',
                    CFBundleIdentifier='com.silveton.sampler.mac', CFBundlePackageType='APPL',
                    CFBundleShortVersionString='1.0.0', CFBundleVersion='20261113',
                    LSMinimumSystemVersion='10.13', NSHighResolutionCapable=True, NSAppSleepDisabled=True,
                    LSArchitecturePriority=['x86_64'])
        plist = os.path.join(contents, 'Info.plist')
        if hasattr(plistlib, 'dump'):
            with open(plist, 'wb') as f: plistlib.dump(info, f)
        else:
            plistlib.writePlist(info, plist)
        arch = output(['/usr/bin/lipo', '-archs', executable])
        if arch != 'x86_64': raise RuntimeError('Unexpected architecture: ' + arch)
        load = output(['/usr/bin/otool', '-l', executable])
        libs = output(['/usr/bin/otool', '-L', executable])
        log.write(('\nARCH: ' + arch + '\n' + load + '\n' + libs).encode('utf-8'))
        # The availability warning above is a hard error. Also check the binary deployment metadata.
        if 'version 10.13' not in load and 'minos 10.13' not in load:
            raise RuntimeError('The linked application does not report the macOS 10.13 target')
        signing = subprocess.Popen(['/usr/bin/codesign', '--force', '--sign', '-', '--timestamp=none', app],
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        signed = signing.communicate()[0]; log.write(signed)
        if signing.returncode:
            show_diagnostic(signed)
            raise RuntimeError('Ad-hoc signing failed. Read ' + logpath)
        target = os.path.join(BUILD, 'SILVETON SAMPLER.app')
        # Keep the last successful app if any; a failed compilation never replaces it.
        backup = os.path.join(BUILD, 'Previous SILVETON SAMPLER.app')
        if os.path.isdir(target):
            if os.path.isdir(backup): shutil.rmtree(backup)
            os.rename(target, backup)
        os.rename(app, target); os.rmdir(stage)
        with open(os.path.join(BUILD, 'BUILD_RESULT.json'), 'w') as f:
            json.dump(dict(source_sha256=fingerprint, architecture=arch, minimum_macos='10.13',
                           app=target, sdk=sdk, status='compiled_and_signed_not_runtime_tested'), f, indent=2)
    print('Built: ' + target)
    return 0

if __name__ == '__main__':
    try: sys.exit(main())
    except Exception as error:
        print('ERROR: ' + str(error), file=sys.stderr); sys.exit(1)
