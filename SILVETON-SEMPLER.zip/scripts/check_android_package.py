#!/usr/bin/env python3
"""Check an installable NativeActivity APK; does not claim a device/audio test."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess
import zipfile

FONTS = ('Roboto-Regular.ttf', 'Roboto-Bold.ttf', 'DejaVuSans.ttf',
         'DejaVuSans-Bold.ttf', 'DejaVuSansMono.ttf', 'DejaVuSansMono-Bold.ttf')
NATIVE_ENTRY = 'lib/arm64-v8a/libsilveton_sampler.so'


def native_contract(data):
    if len(data) < 64 or data[:6] != b'\x7fELF\x02\x01':
        raise ValueError('Native library is not a 64-bit little-endian ELF')
    if struct.unpack_from('<H', data, 18)[0] != 183:
        raise ValueError('Native library is not AArch64')
    offset = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    if size < 56 or count == 0 or offset + size * count > len(data):
        raise ValueError('Invalid native program headers')
    alignments = []
    for index in range(count):
        header = struct.unpack_from('<IIQQQQQQ', data, offset + index * size)
        if header[0] != 1:  # PT_LOAD
            continue
        file_offset, address, file_size, alignment = header[2], header[3], header[5], header[7]
        if alignment < 16384 or alignment & (alignment - 1):
            raise ValueError('Native LOAD segment is not 16 KiB-page compatible')
        if file_offset % alignment != address % alignment or file_offset + file_size > len(data):
            raise ValueError('Invalid native LOAD segment')
        alignments.append(alignment)
    if not alignments:
        raise ValueError('Native library has no LOAD segments')
    return alignments


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk', type=Path)
    parser.add_argument('--build-tools', type=Path, required=True)
    parser.add_argument('--package')
    parser.add_argument('--version-code')
    parser.add_argument('--version-name')
    parser.add_argument('--gradle-file', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.gradle_file:
        source = args.gradle_file.read_text()
        config = {'package': re.search(r'applicationId\s*=\s*"([^"]+)"', source).group(1),
                  'version_code': re.search(r'versionCode\s*=\s*(\d+)', source).group(1),
                  'version_name': re.search(r'versionName\s*=\s*"([^"]+)"', source).group(1)}
        for key, value in config.items():
            if getattr(args, key) not in (None, value):
                raise ValueError('Expected package/version conflicts with the source Gradle file')
            setattr(args, key, value)
    if not args.package or not args.version_code or not args.version_name:
        parser.error('Provide --gradle-file, or --package, --version-code and --version-name.')
    apk = args.apk.resolve()
    tools = args.build_tools.resolve()
    if not apk.is_file() or apk.stat().st_size == 0:
        raise ValueError('APK is missing or empty')
    badging = subprocess.check_output([str(tools / 'aapt2'), 'dump', 'badging', str(apk)], text=True)
    package_line = next((line for line in badging.splitlines() if line.startswith('package: ')), '')
    fields = dict(re.findall(r"(\w+)='([^']*)'", package_line))
    expected = {'name': args.package, 'versionCode': args.version_code, 'versionName': args.version_name}
    if any(fields.get(key) != value for key, value in expected.items()):
        raise ValueError('APK package/version differs from the selected source')
    abi_line = next((line for line in badging.splitlines() if line.startswith('native-code:')), '')
    if re.findall(r"'([^']+)'", abi_line) != ['arm64-v8a']:
        raise ValueError('APK must contain only arm64-v8a code')
    if "launchable-activity: name='android.app.NativeActivity'" not in badging:
        raise ValueError('APK does not launch the NativeActivity')
    with zipfile.ZipFile(apk) as package:
        native = package.getinfo(NATIVE_ENTRY)
        if native.compress_type != zipfile.ZIP_STORED:
            raise ValueError('Native library must be uncompressed for direct APK loading')
        alignments = native_contract(package.read(native))
        for name in FONTS:
            if package.getinfo('assets/fonts/' + name).file_size == 0:
                raise ValueError('APK font is empty: ' + name)
    subprocess.run([str(tools / 'zipalign'), '-c', '-P', '16', '4', str(apk)], check=True)
    signature = subprocess.check_output([str(tools / 'apksigner'), 'verify', '--verbose', '--print-certs', str(apk)], text=True)
    report = dict(package=args.package, version_code=int(args.version_code), version_name=args.version_name,
                  abi='arm64-v8a', load_alignments=alignments, fonts=list(FONTS),
                  package_alignment='16 KiB', signature_verified=True, device_runtime_tested=False,
                  certificate_details=signature.strip())
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print('PASS APK package/version, NativeActivity, ARM64 ELF, fonts, 16 KiB alignment and signature')
    print(signature.strip())


if __name__ == '__main__':
    main()
