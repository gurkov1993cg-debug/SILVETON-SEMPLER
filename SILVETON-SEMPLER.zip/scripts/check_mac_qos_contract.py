#!/usr/bin/env python3
"""Linux-only contract regression, not an Apple SDK build or Mac runtime test.

Compile the real SamplerEngine.cpp with its Apple branches selected and a
minimal declaration shim. Also execute the actual verifyThread function with
controlled success/failure results from the three-argument Apple QoS API.
"""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1] / 'silveton_pro_payload'
SOURCE = ROOT / 'core/src/sampler/SamplerEngine.cpp'
SHIM = '''#pragma once
#include <pthread.h>
typedef unsigned int qos_class_t;
enum { QOS_CLASS_UNSPECIFIED=0, QOS_CLASS_USER_INTERACTIVE=0x21 };
extern "C" int pthread_get_qos_class_np(pthread_t, qos_class_t*, int*);
extern "C" int pthread_set_qos_class_self_np(qos_class_t, int);
inline int pthread_setname_np(const char*) { return 0; }
'''

def main():
    compiler = os.environ.get('CXX', 'g++')
    with tempfile.TemporaryDirectory(prefix='silveton-mac-qos-') as folder:
        temp = Path(folder)
        (temp / 'pthread').mkdir()
        (temp / 'pthread/qos.h').write_text(SHIM)
        flags = [compiler, '-std=c++17', '-D__APPLE__', '-U__linux__',
                 '-I' + str(temp), '-I' + str(ROOT / 'core/include'),
                 '-I' + str(ROOT / 'core/src/sampler')]
        subprocess.check_call(flags + ['-fsyntax-only', str(SOURCE)])
        source = SOURCE.read_text()
        start = source.index('    static bool verifyThread(int index) noexcept {')
        body_start = source.index('{', start)
        depth = 1
        end = body_start + 1
        while depth:
            depth += (source[end] == '{') - (source[end] == '}')
            end += 1
        method = source[start:end]
        fixture = '''#include <pthread/qos.h>
#include <cassert>
static int apiError=0;
static qos_class_t reportedQos=QOS_CLASS_UNSPECIFIED;
extern "C" int pthread_get_qos_class_np(pthread_t, qos_class_t* qos, int*) {
    assert(qos != nullptr); *qos=reportedQos; return apiError;
}
struct ActualMethod {
''' + method + '''
};
int main() {
    reportedQos=QOS_CLASS_USER_INTERACTIVE;
    assert(ActualMethod::verifyThread(0));
    reportedQos=QOS_CLASS_UNSPECIFIED;
    assert(!ActualMethod::verifyThread(0));
    reportedQos=QOS_CLASS_USER_INTERACTIVE; apiError=1;
    assert(!ActualMethod::verifyThread(0));
}
'''
        test = temp / 'check.cpp'
        test.write_text(fixture)
        executable = temp / 'check'
        subprocess.check_call(flags + [str(test), '-pthread', '-o', str(executable)])
        subprocess.check_call([str(executable)])
    print('PASS Mac API contract: full translation unit + success, wrong QoS, API failure')

if __name__ == '__main__':
    main()
