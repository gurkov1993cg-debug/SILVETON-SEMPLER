#!/usr/bin/env python3
"""Package the GitHub build input with a flat root and timezone-safe timestamps."""
from pathlib import Path
import argparse
import os
import stat
import zipfile

# ZIP DOS timestamps contain no timezone; never copy local wall time into them.
# This fixed past date remains in the past on runners in every timezone.
ZIP_DATE = (2020, 1, 1, 0, 0, 0)
EXCLUDE_DIRS = {'.git', '.gradle', '.cxx', '.idea', '__pycache__', 'build', 'build-mac', 'build-android'}
EXCLUDE_SUFFIXES = {'.apk', '.aab', '.p12', '.jks', '.keystore', '.pyc'}


def package(root, output):
    root, output = root.resolve(), output.resolve()
    required = ('silveton_pro_payload/CMakeLists.txt',
                'silveton_pro_payload/android/app/build.gradle.kts',
                '.github/workflows/silveton-apk.yml')
    for name in required:
        if not (root / name).is_file():
            raise RuntimeError('Missing source: ' + name)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + '.new')
    try:
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for directory, dirs, names in os.walk(root):
                dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('build-'))
                for name in sorted(names):
                    path = Path(directory) / name
                    if path in (output, temporary) or path.is_symlink() or path.suffix.lower() in EXCLUDE_SUFFIXES:
                        continue
                    if name in {'.DS_Store', 'local.properties'}:
                        continue
                    info = zipfile.ZipInfo(path.relative_to(root).as_posix(), ZIP_DATE)
                    info.create_system = 3
                    mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
                    info.external_attr = (stat.S_IFREG | mode) << 16
                    info.compress_type = zipfile.ZIP_DEFLATED
                    archive.writestr(info, path.read_bytes())
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('Archive integrity check failed')
            for name in required:
                archive.getinfo(name)
        temporary.replace(output)
    finally:
        if temporary.exists():
            temporary.unlink()
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=Path, default=Path.cwd() / 'SILVETON-SEMPLER.zip')
    args = parser.parse_args()
    package(args.root, args.output)
