# SILVETON SAMPLER

Target: Intel iMac 2011, macOS 10.13, Xcode 10.1. The root Mac launcher builds the standalone application. Android sources are retained; this delivery does not build or validate Android.

| Directory | Purpose |
| --- | --- |
| core | Sample and SOLO sources, common voice processing, MIDI, portamento, effects, bank and SET readers |
| host | Shared source assignment, state publication and platform audio/MIDI adapters |
| ui | Controller, Canvas screens and the common UPPER editor |
| app/mac | AppKit application with CoreAudio/CoreMIDI |
| app/android | Existing native Android application |
| resources/fonts | Bundled fonts and licenses |
| third_party/stb | Font rasterizer |

`SoundAssignment` in `SamplerTypes.h` is the source shared by `UpperPart` (MAIN) and `UpperLayer` (L1–L4). It holds a bank program or the existing SOLO source and optional learned model. Assignment, bank selection, model loading, sound clipboard and drag/drop use the same host assignment operation. They preserve destination processing; whole-part copy also copies that processing.

`commonProcessing` routes new SOLO assignments through the existing sound envelope, filter, velocity and UPPER voice/controller/effect path. `SoloVoice` supplies the source without applying a second amplitude envelope or velocity scaling. No new oscillator algorithm is introduced. The existing preallocated pool supports all 35 source positions; this is functional capacity, not a measured hardware performance guarantee.

`View_Solo.cpp` only edits source colour in SOURCE / WAVE. Tuning, envelopes, filters, modulation, ranges, velocity, voice/portamento, MIDI and effects use existing editor pages. The separate ENGINE navigation item and its duplicate controls have been removed. `View_Engine.cpp` forwards old page entry points to the shared editor.

Old SET engine-slot records and their playback remain readable. MOVE SOLO FROM OLD SET explicitly moves a source into MAIN/L1–L4 and adopts destination processing. Retired synth IDs remain disabled. Existing old SOLO assignments keep legacy processing until moved; compatibility does not silently rewrite them.

`SetPackage.cpp` retains existing model and engine blocks and appends the SVSS version-1 extension for layer source parameters/models and common-processing flags. Models are embedded, including LIST and open-performance entries. Older applications may discard this extension when saving; retain an original SET for older software.

Optional portable build: `cmake -S . -B build -DIMAK_BUILD_TESTS=ON`, then `cmake --build build`. The normal Mac `.command` needs no CMake and does not run offline tests. Current evidence is in `../EVIDENCE/UPPER_SOURCES/`; older evidence folders describe previous changes. Linux validation does not establish native Cocoa/RME operation, hardware latency or Android compatibility.

Sound selection opens the existing picker directly. Its local source entries include STAVROS/DRUGO/MORPH, alongside bank sounds and existing oscillator programs; the native .svsolo file request is in the picker header. There is no type-selection dialog. Both selection and LINK use the shared assignment operation. The old SET move action is in SOUND MENU. DSP and serialization are unchanged by this navigation update.
