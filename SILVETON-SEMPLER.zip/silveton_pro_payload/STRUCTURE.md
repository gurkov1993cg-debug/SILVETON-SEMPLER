# SILVETON SAMPLER — STRUCTURE

Updated: 2026-10-03

## Current package
- Baseline source package used for this revision: `SILVETON-SEMPLER-CURRENT-2026-10-03-R2.zip`.
- New package name for this revision: `SILVETON-SEMPLER-CURRENT-2026-10-03-R3-DIRECT-ALSA.zip`.
- Current successor package after the Direct-MIDI cutover: `SILVETON-SEMPLER-CURRENT-2026-10-03-R4-DIRECT-ALSA-MIDI.zip`. R3 remains preserved and is not overwritten.
- Contains the current source tree plus the preserved COMBI implementation/audit and the new Direct-ALSA bridge work from this session.
- Temporary local `build-*` directories and `.bak-combi` backup files are intentionally excluded from the distributed ZIP.

## Truth / baseline status
- `docs/APPROVED_COMBI_UI.png` — current approved COMBI visual reference.
- `docs/APPROVED_LIST_UI.png` — current approved LIST visual reference.
- `docs/APPROVED_UI.png` — legacy SILVETON LIVE MIDI image; NOT the current sampler GUI baseline.
- This working tree preserves the latest COMBI code/audit work from the R2 baseline.
- `SamplerAudioBridge.cpp` has now been migrated from AAudio to a direct ALSA PCM path targeting `/dev/snd/pcmC0D0p`.
- The Direct-ALSA code performs real kernel `hw_params` negotiation, S16_LE stereo output, period/buffer selection, XRUN recovery, controlled-stop filtering so DROP is not counted as an XRUN, and `SNDRV_PCM_IOCTL_DELAY` latency read-back.
- Android APK build and physical SM-X130 open/play verification of this new Direct-ALSA revision are still required before host/device compatibility may be claimed.

## Android application
- `android/app/src/main/java/com/silveton/sampler/SilvetonSamplerView.kt` — sampler GUI view with current COMBI navigation/layout/control handlers.
- `android/app/src/main/java/com/silveton/sampler/SamplerAppController.kt` — GUI/application control layer.
- `android/app/src/main/java/com/silveton/sampler/NativeSamplerEngine.kt` — Kotlin native sampler contract.
- `android/app/src/main/java/com/silveton/sampler/SamplerRuntime.kt` — lifecycle/recovery owner for the Direct-ALSA stream; recovery is polled on the main thread and never performed inside the realtime audio thread.
- `android/app/src/main/cpp/SamplerAudioBridge.cpp` — JNI sampler bridge plus Direct-ALSA PCM output backend for `/dev/snd/pcmC0D0p`; probes 96/48 kHz and 2/3/4 periods, selects the successful configuration with the smallest queue capacity, converts the engine float stream to S16_LE, reports kernel delay and recovers XRUNs.
- `android/app/src/main/cpp/CMakeLists.txt` — JNI target now links `silveton_live_core` + Android `log` only; the previous AAudio library dependency has been removed.
- `android/app/src/main/cpp/NativeBridge.cpp` — native MIDI bridge.

## Sampler DSP/core
- `core/include/silveton/sampler/SamplerTypes.h` — sampler/COMBI/program/state structures.
- `core/include/silveton/sampler/SamplerEngine.h` — sampler engine public interface.
- `core/src/sampler/SamplerEngine.cpp` — voice rendering, Upper processing, EQ, sends, COMBI FX/master path and meters.
- `core/src/sampler/SamplerLibrary.cpp` — library/state management.
- `core/src/sampler/SampleStream.cpp` — sample streaming.
- `core/src/sampler/SincInterpolator.cpp` — interpolation.
- `core/src/sampler/AudioFileLoader.cpp` — audio file loading.
- `core/src/sampler/KorgImporter.cpp` — Korg import logic in the historical architecture.
- `core/src/sampler/SampleEditor.cpp`, `MultisampleEditor.cpp`, `ProgramEditor.cpp` — historical tablet-side editor code retained; global PROGRAM/SAMPLE menus are no longer part of the approved tablet navigation.

## COMBI contract
Approved global tablet navigation:
- LIST
- COMBI
- EFFECTS
- SETTINGS

Removed as global tablet menus:
- PROGRAM
- SAMPLE
- MIXER

UPPER main row owns these controls once only:
- SOUND
- ON
- SOLO
- MUTE
- VOLUME
- PAN
- KEY RANGE
- MODE (POLY / MONO / LEGATO)
- real DSP meter

Selected UPPER detail tabs:
- TUNE
- RANGE
- CONTROL
- TONE
- FX

No lower-page duplication of controls already present on the UPPER row.

## Current verification
- Release core tests: 3/3 PASS.
- ASan + UBSan tests: 3/3 PASS.
- GUI/JNI contract audit: 101/101 PASS.
- `ci/audit_gui_contract.py` verifies the current GUI/native contract.
- `ci/audit_direct_alsa.py` enforces the Direct-ALSA source/build contract and fails if AAudio runtime/link dependencies return or required PCM/XRUN/latency paths disappear.
- Direct-ALSA `SamplerAudioBridge.cpp` host-side strict syntax/warnings check: PASS (`-Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror`).
- Android APK build is not claimed as locally verified in this environment.
- Physical `/dev/snd/pcmC0D0p` permission/open/play test on the SM-X130 is not yet claimed for this revision.

## Audit documentation
- `docs/SILVETON_SAMPLER_CURRENT_STATE_BG.txt` — preserved R2/pre-Direct-ALSA Bulgarian snapshot. Its statements that Direct-ALSA is missing describe the earlier baseline and are superseded for R3 by this `STRUCTURE.md` plus the actual source.
- `docs/COMBI_CONTROL_AUDIT.md` — mapping of visible COMBI controls to handlers/native/DSP paths.
- `docs/GUI_BASELINE.md` — GUI baseline notes.

## R4 Direct-ALSA MIDI — completed software block
- `android/app/src/main/cpp/SamplerAudioBridge.cpp` now contains a native Direct-ALSA raw-MIDI input backend.
- It scans `/dev/snd/midiC*D*`, opens raw-MIDI input nodes directly with nonblocking file descriptors, applies `SNDRV_RAWMIDI_IOCTL_PARAMS`, merges up to 16 raw-MIDI ports on one native urgent-priority thread, parses running status/SysEx boundaries/system realtime safely, and posts Note On/Off, CC, Channel Pressure and Pitch Bend directly to `SamplerEngine` without `android.media.midi` in the data path.
- Hot-plug is handled by periodic `/dev/snd` rescan and poll/read on attached raw-MIDI nodes.
- Native readback methods `nativeMidiDeviceCount()` and `nativeMidiLastError()` are wired through Kotlin and feed the real GUI MIDI connection/error status.
- `android/app/src/main/java/com/silveton/sampler/NativeSamplerEngine.kt` now declares `nativeMidiDeviceCount()` and `nativeMidiLastError()` so the tablet UI can report the real native raw-MIDI backend instead of Android MIDI-framework connection state.
- `android/app/src/main/java/com/silveton/sampler/SamplerMidiController.kt` no longer imports or opens `android.media.midi` devices. It is now status-only: MIDI bytes stay entirely in the native Direct-ALSA raw-MIDI path, while this class polls the real native raw-port count/error for the existing GUI MIDI indicator.
- `ci/audit_direct_midi.py` is the automated R4 contract check for the native raw-MIDI path. It fails if Android `android.media.midi` returns to the sampler runtime or if the `/dev/snd` raw-MIDI scan/config/poll/read/status contract disappears.
- `TEST_STATUS.md` now records the completed R4 Direct-ALSA MIDI software verification: direct-MIDI audit 14/14, Direct-ALSA audio audit PASS, GUI/JNI 103/103, Release 3/3 and ASan+UBSan 3/3. Physical SM-X130 raw-MIDI node access remains explicitly unproven until device testing.


## FINAL SAMPLER RUNTIME ADDITIONS — 2026-10-04

- Added native reader for Manager-produced single-file `SILVETON_BANK.sv` v1.0.
- Bank audio remains one shared mmap; samples do not duplicate the full audio payload in RAM.
- Each sample keeps only a 4096-frame attack prefix in RAM; sustain/tail reads from the mapped bank.
- SOUND records become native PROGRAM slots using the exact bank/page/slot address written by Manager.
- MULTISAMPLE/zone/sample references are rebuilt as immutable native objects before state installation.
- Header/section/record/range/loop/encoding validation is mandatory; optional full SHA-256 verification is available without forcing a multi-gigabyte scan at every startup.
- Android startup now searches for `SILVETON_BANK.sv` in internal app storage, app external storage, then `/storage/emulated/0/SILVETON_BANK.sv`.
- Loading is transactional: the live library/state is replaced only after the entire bank has parsed successfully.

## SOUND BY NAME — SILVETON_SOUND_BY_NAME_V1 — 2026-10-15

- A BLEND (and the saved LIST/BLENDS sets) now finds its sounds again by the sound's NAME in the bank, not by the 1..500 place number. The place is only the first guess and is updated when the sound sits elsewhere now.
- Applies to bank replacement (update), loading the saved state at start, LOAD of a saved set and activating a BLEND (`rebindUpper` in `SamplerAudioBridge.cpp`).
- Pure rule in `core/include/silveton/sampler/SoundResolve.h` (`resolveSoundByName`), tested by `testSoundFoundByName`.
- A sound that is not in the new bank is never replaced by the sound that sits on its old place; its part goes off. Two sounds with the same name: the one still on the remembered place wins, else the lowest place.
- Built-in waves (9001..) keep fixed places. Engine placeholder names ("Upper N", "Layer N") use the place only.
- Existing saved BLENDS need no conversion: they already store the sound name.
