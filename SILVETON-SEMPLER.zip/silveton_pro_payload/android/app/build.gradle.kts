// SILVETON SAMPLER for the Samsung Galaxy Tab A11 (SM-X130): a NativeActivity made only of C++ (no Kotlin, no Java).
// The C++ is the repository's top CMakeLists.txt (ANDROID branch): the sound core, the tablet's own sound / MIDI engine,
// the screens and the NativeActivity shell. The fonts of the screens travel as assets (resources/fonts).
plugins {
    id("com.android.application")
}

android {
    namespace = "com.silveton.sampler"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.silveton.sampler"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17")
                // NDK r27 needs this explicitly for 16 KiB page-size compatible native libs.
                arguments += listOf("-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON")
            }
        }
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("../../CMakeLists.txt")
            version = "3.22.1"
        }
    }

    ndkVersion = "27.2.12479018"

    sourceSets {
        getByName("main") {
            // resources/fonts -> assets/fonts inside the APK
            assets.srcDir("../../resources")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // GitHub Actions test releases are installable on the SM-X130.
            // Production signing stays separate and must use the real release key.
            if (System.getenv("CI") == "true") {
                signingConfig = signingConfigs.getByName("debug")
            }
        }
    }
}
