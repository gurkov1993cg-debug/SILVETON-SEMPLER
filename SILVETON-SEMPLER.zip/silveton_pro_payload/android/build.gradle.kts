// The tablet program has no Kotlin and no Java: only the Android plugin is needed.
plugins {
    id("com.android.application") version "8.7.3" apply false
}
