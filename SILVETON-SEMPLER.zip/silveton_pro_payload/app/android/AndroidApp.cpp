// SILVETON_ANDROID_APP_V1 - the SILVETON SAMPLER on the tablet WITHOUT Kotlin or Java.
//
// A NativeActivity (android_native_app_glue) that does what MainActivity.kt + SilvetonSamplerView.kt did around the screens:
//   * the screens are the same C++ screens as on the Mac (ui/). Every picture they draw is written to a list of operations
//     (FrameRenderer::record). SILVETON_GPU_DRAW_V1: the list is drawn on the tablet's video card (GlRenderer, EGL + OpenGL ES 3),
//     the whole list for every changed picture - the way Android draws a View. The processor does not draw the picture;
//   * touch (one finger = the mouse, a second finger on a - / + pair = reset), volume keys = MASTER, Back = close the dialog;
//   * the sound, MIDI and bank engine is the tablet's own (Direct ALSA, raw MIDI, realtime threads), reached through the plain
//     C++ facade NativeSamplerEngine; the root set-up is AndroidRoot.cpp;
//   * Android's Toast and keyboard are replaced by a pill and an on-screen keyboard inside the picture.
//
// Threads: the main thread of the app (android_main) owns the screens and the drawing. "SilvetonAudioLifecycle" starts /
// resumes / pauses / closes the sound (root calls take seconds). "SilvetonHousekeeping" is the tablet's two 250 ms polls
// (audio recovery + MIDI status). Nothing else touches the screens except through the queue to the main thread.

#include <android/api-level.h>
#include <android/asset_manager.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <android/looper.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <android/window.h>
#include <android_native_app_glue.h>
#include <jni.h>
#include <pthread.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "AndroidRoot.h"
#include "GlRenderer.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/Support.h"

namespace {

using silveton::ui::Canvas;
using silveton::ui::ControllerEnv;
using silveton::ui::FrameRenderer;
using silveton::ui::SamplerAppController;
using silveton::ui::SilvetonSamplerView;

constexpr const char* kTag = "SILVETON";

void logInfo(const std::string& text) { __android_log_print(ANDROID_LOG_INFO, kTag, "%s", text.c_str()); }
void logError(const std::string& text) { __android_log_print(ANDROID_LOG_ERROR, kTag, "%s", text.c_str()); }

void nameThisThread(const char* name) { ::pthread_setname_np(::pthread_self(), name); }

// ---------------------------------------------------------------- a thread that runs jobs one after the other
// (the tablet's single-thread executor "SilvetonAudioLifecycle"). It keeps itself alive until its last job is done, so the
// sound can be closed after the screens are gone.
class JobThread {
public:
    explicit JobThread(const char* name) : state_(std::make_shared<State>()) {
        const std::shared_ptr<State> state = state_;
        const std::string threadName = name;
        std::thread([state, threadName] {
            nameThisThread(threadName.c_str());
            for (;;) {
                std::function<void()> job;
                {
                    std::unique_lock<std::mutex> lock(state->mutex);
                    state->wake.wait(lock, [&] { return state->stop || !state->jobs.empty(); });
                    if (state->jobs.empty()) return;   // stop and nothing left
                    job = std::move(state->jobs.front());
                    state->jobs.pop_front();
                }
                job();
            }
        }).detach();
    }
    void post(std::function<void()> job) {
        {
            std::lock_guard<std::mutex> lock(state_->mutex);
            if (state_->stop) return;
            state_->jobs.push_back(std::move(job));
        }
        state_->wake.notify_one();
    }
    // Runs what is queued, then the thread ends. Does not wait.
    void finish() {
        {
            std::lock_guard<std::mutex> lock(state_->mutex);
            state_->stop = true;
        }
        state_->wake.notify_one();
    }

private:
    struct State {
        std::mutex mutex;
        std::condition_variable wake;
        std::deque<std::function<void()>> jobs;
        bool stop{false};
    };
    std::shared_ptr<State> state_;
};

// ---------------------------------------------------------------- what the sound / MIDI threads may reach
// They never touch the screens directly: they go through here. `view` is only set while the screens exist.
struct SharedState {
    std::mutex viewMutex;
    SilvetonSamplerView* view{nullptr};
    std::mutex queueMutex;
    std::deque<std::function<void()>> mainQueue;
    ALooper* looper{nullptr};

    void postMain(std::function<void()> job) {
        {
            std::lock_guard<std::mutex> lock(queueMutex);
            mainQueue.push_back(std::move(job));
        }
        if (looper != nullptr) ::ALooper_wake(looper);
    }
    void withView(const std::function<void(SilvetonSamplerView&)>& use) {
        std::lock_guard<std::mutex> lock(viewMutex);
        if (view != nullptr) use(*view);
    }
};

// ---------------------------------------------------------------- full screen (the tablet's hideSystemUi)
// The system bars are hidden and come back for a moment by a swipe from the edge. Made through JNI without any Java code of
// our own; every call may fail on some firmware, then the bars simply stay.
void hideSystemUi(ANativeActivity* activity) {
    if (activity == nullptr || activity->vm == nullptr) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (activity->vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (activity->vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    if (env != nullptr) {
        const auto clear = [&]() -> bool {
            if (env->ExceptionCheck()) { env->ExceptionClear(); return true; }
            return false;
        };
        jobject activityObject = activity->clazz;
        jclass activityClass = env->GetObjectClass(activityObject);
        jmethodID getWindow = activityClass != nullptr ? env->GetMethodID(activityClass, "getWindow", "()Landroid/view/Window;") : nullptr;
        jobject window = (getWindow != nullptr && !clear()) ? env->CallObjectMethod(activityObject, getWindow) : nullptr;
        clear();
        if (window != nullptr) {
            jclass windowClass = env->GetObjectClass(window);
            // Android 11 and newer: the insets controller (hide the bars, show them again by a swipe)
            if (::android_get_device_api_level() >= 30 && windowClass != nullptr) {
                jmethodID getController = env->GetMethodID(windowClass, "getInsetsController", "()Landroid/view/WindowInsetsController;");
                jobject controller = (getController != nullptr && !clear()) ? env->CallObjectMethod(window, getController) : nullptr;
                clear();
                jclass typeClass = env->FindClass("android/view/WindowInsets$Type");
                jmethodID systemBars = (typeClass != nullptr && !clear()) ? env->GetStaticMethodID(typeClass, "systemBars", "()I") : nullptr;
                clear();
                if (controller != nullptr && systemBars != nullptr) {
                    const jint bars = env->CallStaticIntMethod(typeClass, systemBars);
                    if (!clear()) {
                        jclass controllerClass = env->GetObjectClass(controller);
                        jmethodID hide = env->GetMethodID(controllerClass, "hide", "(I)V");
                        jmethodID behavior = env->GetMethodID(controllerClass, "setSystemBarsBehavior", "(I)V");
                        clear();
                        if (behavior != nullptr) { env->CallVoidMethod(controller, behavior, 2); clear(); }   // BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        if (hide != nullptr) { env->CallVoidMethod(controller, hide, bars); clear(); }
                        env->DeleteLocalRef(controllerClass);
                    }
                }
                if (controller != nullptr) env->DeleteLocalRef(controller);
                if (typeClass != nullptr) env->DeleteLocalRef(typeClass);
            }
            // every version: the old flags (stable layout, hide navigation + status bar, sticky immersive)
            jmethodID getDecor = windowClass != nullptr ? env->GetMethodID(windowClass, "getDecorView", "()Landroid/view/View;") : nullptr;
            jobject decor = (getDecor != nullptr && !clear()) ? env->CallObjectMethod(window, getDecor) : nullptr;
            clear();
            if (decor != nullptr) {
                jclass viewClass = env->GetObjectClass(decor);
                jmethodID setVisibility = env->GetMethodID(viewClass, "setSystemUiVisibility", "(I)V");
                clear();
                if (setVisibility != nullptr) {
                    env->CallVoidMethod(decor, setVisibility, static_cast<jint>(0x100 | 0x200 | 0x400 | 0x2 | 0x4 | 0x1000));
                    clear();
                }
                env->DeleteLocalRef(viewClass);
                env->DeleteLocalRef(decor);
            }
            if (windowClass != nullptr) env->DeleteLocalRef(windowClass);
            env->DeleteLocalRef(window);
        }
        if (activityClass != nullptr) env->DeleteLocalRef(activityClass);
    }
    if (attached) activity->vm->DetachCurrentThread();
}

// ---------------------------------------------------------------- the fonts travel inside the APK (assets/fonts)
// The text drawer reads ordinary files, so they are copied once into the app's own folder (again when a size differs).
std::string prepareFonts(ANativeActivity* activity) {
    const std::string directory = std::string(activity->internalDataPath != nullptr ? activity->internalDataPath : "/data/local/tmp") + "/fonts";
    ::mkdir(directory.c_str(), 0700);
    AAssetManager* assets = activity->assetManager;
    AAssetDir* dir = assets != nullptr ? ::AAssetManager_openDir(assets, "fonts") : nullptr;
    if (dir == nullptr) return directory;
    while (const char* name = ::AAssetDir_getNextFileName(dir)) {
        const std::string fileName = name;
        AAsset* asset = ::AAssetManager_open(assets, ("fonts/" + fileName).c_str(), AASSET_MODE_STREAMING);
        if (asset == nullptr) continue;
        const std::string target = directory + "/" + fileName;
        const off64_t size = ::AAsset_getLength64(asset);
        struct stat st {};
        const bool same = ::stat(target.c_str(), &st) == 0 && static_cast<off64_t>(st.st_size) == size;
        if (!same) {
            const std::string temporary = target + ".tmp";
            std::FILE* out = std::fopen(temporary.c_str(), "wb");
            bool ok = out != nullptr;
            char buffer[16384];
            for (;;) {
                const int n = ::AAsset_read(asset, buffer, sizeof(buffer));
                if (n <= 0) break;
                if (ok && std::fwrite(buffer, 1U, static_cast<std::size_t>(n), out) != static_cast<std::size_t>(n)) ok = false;
            }
            if (out != nullptr) std::fclose(out);
            if (ok) std::rename(temporary.c_str(), target.c_str());
            else std::remove(temporary.c_str());
        }
        ::AAsset_close(asset);
    }
    ::AAssetDir_close(dir);
    return directory;
}

// ---------------------------------------------------------------- the program
class SilvetonApp {
public:
    explicit SilvetonApp(android_app* app) : app_(app), shared_(std::make_shared<SharedState>()) {}

    void run() {
        nameThisThread("SilvetonMain");
        shared_->looper = app_->looper;   // the glue prepared it for this thread
        ::ANativeActivity_setWindowFlags(app_->activity, AWINDOW_FLAG_KEEP_SCREEN_ON | AWINDOW_FLAG_FULLSCREEN, 0);

        silveton::ui::setFontDirectory(prepareFonts(app_->activity));
        if (!silveton::ui::fontsReady()) logError("the font files were not found: the text cannot be drawn");

        create();
        app_->userData = this;
        app_->onAppCmd = &SilvetonApp::onCommand;
        app_->onInputEvent = &SilvetonApp::onInput;

        loop();
        destroy();
    }

private:
    // ------------------------------------------------------------ set-up and tear-down
    void create() {
        const char* internal = app_->activity->internalDataPath != nullptr ? app_->activity->internalDataPath : "/data/local/tmp";
        const char* external = app_->activity->externalDataPath;

        platform_ = std::make_shared<silveton::android::AndroidPlatform>();
        ControllerEnv env;
        env.dataDir = internal;
        env.bankCandidates = {"/storage/emulated/0/SILVETON_BANK.sv", "/storage/emulated/0/Download/SILVETON_BANK.sv"};
        if (external != nullptr) env.bankCandidates.push_back(std::string(external) + "/SILVETON_BANK.sv");
        env.bankCandidates.push_back(std::string(internal) + "/SILVETON_BANK.sv");
        env.olderStateCopies = {"/storage/emulated/0/SILVETON/SILVETON_USER_STATE.SVSET", "/storage/emulated/0/SILVETON/SILVETON_USER_STATE.SVSET.BAK"};
        env.platform = platform_;
        const std::shared_ptr<SharedState> shared = shared_;
        env.statusChanged = [shared](const std::string& message) {
            if (!message.empty()) logInfo("status: " + message);
            shared->withView([&](SilvetonSamplerView& v) { v.setWarning(message); });   // thread safe
        };
        env.midiConnectionChanged = [shared](int count) {
            shared->postMain([shared, count] { shared->withView([count](SilvetonSamplerView& v) { v.setMidiConnections(count); }); });
        };
        controller_ = std::make_shared<SamplerAppController>(env);

        view_ = std::make_unique<SilvetonSamplerView>(*controller_);
        view_->setSoftKeyboard(true);   // no keyboard of Android: the text and number pages bring their own
        {
            std::lock_guard<std::mutex> lock(shared_->viewMutex);
            shared_->view = view_.get();
        }

        lifecycle_ = std::make_unique<JobThread>("SilvetonAudioLifecycle");
        housekeepingStop_ = false;
        housekeeping_ = std::thread([this] { housekeepingLoop(); });
    }

    void destroy() {
        {
            std::lock_guard<std::mutex> lock(housekeepingMutex_);
            housekeepingStop_ = true;
        }
        housekeepingWake_.notify_all();
        if (housekeeping_.joinable()) housekeeping_.join();
        {
            std::lock_guard<std::mutex> lock(shared_->viewMutex);
            shared_->view = nullptr;
        }
        view_.reset();
        gpu_.reset();
        renderer_.reset();
        // The sound is closed on its own thread: the root call that gives the cores back may take a few seconds and must not hold
        // up the end of the activity. The thread keeps the controller alive until it is done.
        const std::shared_ptr<SamplerAppController> controller = controller_;
        const std::shared_ptr<silveton::android::AndroidPlatform> platform = platform_;
        lifecycle_->post([controller, platform] { controller->close(); });
        lifecycle_->finish();
        lifecycle_.reset();
        controller_.reset();
        platform_.reset();
    }

    // The tablet's two 250 ms polls (SamplerRuntime.recoveryPoll and SamplerMidiController.statusPoll).
    void housekeepingLoop() {
        nameThisThread("SilvetonHousekeeping");
        std::unique_lock<std::mutex> lock(housekeepingMutex_);
        while (!housekeepingStop_) {
            housekeepingWake_.wait_for(lock, std::chrono::milliseconds(250), [this] { return housekeepingStop_; });
            if (housekeepingStop_) break;
            lock.unlock();
            controller_->housekeeping();
            lock.lock();
        }
    }

    // ------------------------------------------------------------ Android life cycle (MainActivity.onStart / onResume / onPause)
    static void onCommand(android_app* app, int32_t command) { static_cast<SilvetonApp*>(app->userData)->handleCommand(command); }
    static int32_t onInput(android_app* app, AInputEvent* event) { return static_cast<SilvetonApp*>(app->userData)->handleInput(event); }

    void handleCommand(int32_t command) {
        switch (command) {
            case APP_CMD_INIT_WINDOW:
                if (app_->window != nullptr) {
                    windowReady_ = true;
                    startGpu();
                    useWindowSize();
                    hideSystemUi(app_->activity);
                }
                break;
            case APP_CMD_TERM_WINDOW:
                gpu_.reset();   // (the video card's surface must go before the window does)
                windowReady_ = false;
                break;
            case APP_CMD_WINDOW_RESIZED:
            case APP_CMD_CONTENT_RECT_CHANGED:
            case APP_CMD_CONFIG_CHANGED:
                if (windowReady_) useWindowSize();
                break;
            case APP_CMD_GAINED_FOCUS:
                hideSystemUi(app_->activity);
                if (renderer_) renderer_->invalidate();
                break;
            case APP_CMD_START: {
                visible_ = true;
                const std::shared_ptr<SamplerAppController> controller = controller_;
                lifecycle_->post([controller] { controller->start(); });
                break;
            }
            case APP_CMD_RESUME: {
                visible_ = true;
                hideSystemUi(app_->activity);
                const std::shared_ptr<SamplerAppController> controller = controller_;
                lifecycle_->post([controller] { controller->resumeAudio(); });
                if (renderer_) renderer_->invalidate();
                break;
            }
            case APP_CMD_PAUSE: {
                const std::shared_ptr<SamplerAppController> controller = controller_;
                lifecycle_->post([controller] { controller->pauseAudio(); });
                break;
            }
            case APP_CMD_STOP:
                visible_ = false;
                break;
            default:
                break;
        }
    }

    // SILVETON_GPU_DRAW_V1: the size of what is drawn into (the video card's surface, or the window for the software renderer).
    bool drawingSize(int& w, int& h) {
        if (app_->window == nullptr) return false;
        if (gpu_) return gpu_->querySize(w, h) && w > 0 && h > 0;
        w = ::ANativeWindow_getWidth(app_->window);
        h = ::ANativeWindow_getHeight(app_->window);
        return w > 0 && h > 0;
    }

    // The picture has the size of the window (the screens scale the 1340 x 800 design to it and keep its shape).
    void useWindowSize() {
        int w = 0, h = 0;
        if (!drawingSize(w, h)) return;
        if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
            renderer_ = std::make_unique<FrameRenderer>(w, h);
            logInfo("picture " + std::to_string(w) + " x " + std::to_string(h));
        } else {
            renderer_->invalidate();
        }
    }

    // The video card's drawing (see GlRenderer.h). If it cannot be made, it is tried again a little later (see frame()).
    void startGpu() {
        gpu_.reset();
        if (app_->window == nullptr) return;
        silveton::gl::GlRenderer::Options options;
        options.nativeWindow = app_->window;
        ANativeWindow* window = app_->window;
        options.onNativeVisual = [window](int visual) { ::ANativeWindow_setBuffersGeometry(window, 0, 0, visual); };
        std::string error;
        gpu_ = silveton::gl::GlRenderer::create(options, error);
        if (gpu_) logInfo("graphics: video card - " + gpu_->info());
        else logError("graphics: the video card could not be started - " + error);
        if (renderer_) renderer_->invalidate();
    }

    // ------------------------------------------------------------ touch and keys
    int32_t handleInput(AInputEvent* event) {
        if (!view_) return 0;
        const int32_t type = ::AInputEvent_getType(event);
        if (type == AINPUT_EVENT_TYPE_MOTION) return handleMotion(event);
        if (type == AINPUT_EVENT_TYPE_KEY) return handleKey(event);
        return 0;
    }

    // MainActivity's touch: the first finger is the mouse; a second finger on the partner of a - / + pair resets it
    // (SilvetonSamplerView.handleTouch); moves follow the first finger only.
    int32_t handleMotion(AInputEvent* event) {
        if ((::AInputEvent_getSource(event) & AINPUT_SOURCE_CLASS_POINTER) == 0) return 0;
        const int32_t action = ::AMotionEvent_getAction(event);
        const int32_t masked = action & AMOTION_EVENT_ACTION_MASK;
        const int32_t index = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        switch (masked) {
            case AMOTION_EVENT_ACTION_DOWN:
                primaryPointer_ = ::AMotionEvent_getPointerId(event, 0);
                view_->pointer(SilvetonSamplerView::PointerAction::Down, ::AMotionEvent_getX(event, 0), ::AMotionEvent_getY(event, 0));
                return 1;
            case AMOTION_EVENT_ACTION_POINTER_DOWN:
                view_->secondPointerDown(::AMotionEvent_getX(event, static_cast<size_t>(index)), ::AMotionEvent_getY(event, static_cast<size_t>(index)));
                return 1;
            case AMOTION_EVENT_ACTION_MOVE: {
                if (primaryPointer_ < 0) return 1;
                const size_t count = ::AMotionEvent_getPointerCount(event);
                for (size_t i = 0U; i < count; ++i) {
                    if (::AMotionEvent_getPointerId(event, i) != primaryPointer_) continue;
                    view_->pointer(SilvetonSamplerView::PointerAction::Move, ::AMotionEvent_getX(event, i), ::AMotionEvent_getY(event, i));
                    break;
                }
                return 1;
            }
            case AMOTION_EVENT_ACTION_UP:
                primaryPointer_ = -1;
                view_->pointer(SilvetonSamplerView::PointerAction::Up, ::AMotionEvent_getX(event, 0), ::AMotionEvent_getY(event, 0));
                return 1;
            case AMOTION_EVENT_ACTION_CANCEL:
                primaryPointer_ = -1;
                view_->pointer(SilvetonSamplerView::PointerAction::Cancel, ::AMotionEvent_getX(event, 0), ::AMotionEvent_getY(event, 0));
                return 1;
            default:
                return 1;   // pointer up of one of two fingers, hover ...: nothing to do
        }
    }

    // The tablet's volume keys change SILVETON's own MASTER level and stay away from Android: Android's volume change and
    // its click sound went through the tablet's own audio system and broke the direct sound.
    int32_t handleKey(AInputEvent* event) {
        const int32_t code = ::AKeyEvent_getKeyCode(event);
        const bool down = ::AKeyEvent_getAction(event) == AKEY_EVENT_ACTION_DOWN;
        float step = 0.0F;
        switch (code) {
            case AKEYCODE_VOLUME_UP: step = 2.0F; break;
            case AKEYCODE_VOLUME_DOWN: step = -2.0F; break;
            case AKEYCODE_VOLUME_MUTE: break;
            case AKEYCODE_BACK:
                // the tablet's dialogs closed with Back; without a dialog Back leaves the program as on any Android app
                if (view_->dialogOpen()) {
                    if (down) view_->keyDown(SilvetonSamplerView::Key::Escape);
                    return 1;
                }
                return 0;
            default:
                return 0;
        }
        if (down && step != 0.0F) {
            const std::optional<float> db = controller_->nudgeMasterGain(step);
            if (db) {
                view_->globalChangedOutside();
                char text[48];
                std::snprintf(text, sizeof(text), "MASTER %s%.0f dB", *db > 0.0F ? "+" : "", static_cast<double>(*db));
                view_->showToast(text);
            }
        }
        return 1;
    }

    // ------------------------------------------------------------ the loop
    void loop() {
        for (;;) {
            const std::int64_t now = silveton::ui::nowMs();
            int timeout = timeoutMs(now);
            for (;;) {
                int events = 0;
                android_poll_source* source = nullptr;
                const int ident = ::ALooper_pollOnce(timeout, nullptr, &events, reinterpret_cast<void**>(&source));
                if (ident >= 0) {
                    if (source != nullptr) source->process(app_, source);
                    timeout = 0;   // more may be waiting
                    if (app_->destroyRequested != 0) return;
                    continue;
                }
                if (ident == ALOOPER_POLL_WAKE) { timeout = 0; continue; }
                break;   // time is up
            }
            if (app_->destroyRequested != 0) return;
            runQueue();
            frame();
        }
    }

    int timeoutMs(std::int64_t now) const {
        if (!windowReady_ || !visible_ || !view_ || !renderer_) return -1;   // nothing to draw: sleep until something happens
        std::int64_t due = std::max(view_->nextWorkMs(), lastFrameMs_ + 12);   // not faster than about 80 pictures a second
        {
            std::lock_guard<std::mutex> lock(shared_->queueMutex);
            if (!shared_->mainQueue.empty()) due = now;
        }
        const std::int64_t wait = due - now;
        return wait <= 0 ? 0 : static_cast<int>(std::min<std::int64_t>(wait, 1000));
    }

    void runQueue() {
        for (;;) {
            std::function<void()> job;
            {
                std::lock_guard<std::mutex> lock(shared_->queueMutex);
                if (shared_->mainQueue.empty()) return;
                job = std::move(shared_->mainQueue.front());
                shared_->mainQueue.pop_front();
            }
            job();
        }
    }

    void frame() {
        if (!windowReady_ || !visible_ || !view_) return;
        const std::int64_t now = silveton::ui::nowMs();
        view_->tick(now);
        if (now < lastFrameMs_ + 12 || !view_->redrawDue(now)) return;
        if (!gpu_) {
            if (now < nextGpuTryMs_) return;
            nextGpuTryMs_ = now + 2000;
            startGpu();
            if (!gpu_) return;
        }
        int w = 0, h = 0;
        if (!drawingSize(w, h)) return;
        if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
            useWindowSize();
            if (!renderer_) return;
        }
        lastFrameMs_ = now;
        // the whole list goes to the video card whenever it differs from the picture that is showing
        const bool changed = renderer_->record([this](Canvas& canvas) { view_->draw(canvas); });
        if (changed && !gpu_->render(renderer_->lastList(), true)) {
            logError("graphics: drawing on the video card failed - " + gpu_->lastError());
            gpu_.reset();   // made again on the next picture
            nextGpuTryMs_ = 0;
            if (renderer_) renderer_->invalidate();
        }
    }

    android_app* app_;
    std::shared_ptr<SharedState> shared_;
    std::shared_ptr<silveton::android::AndroidPlatform> platform_;
    std::shared_ptr<SamplerAppController> controller_;
    std::unique_ptr<SilvetonSamplerView> view_;
    std::unique_ptr<FrameRenderer> renderer_;
    std::unique_ptr<silveton::gl::GlRenderer> gpu_;   // the video card's drawing
    std::int64_t nextGpuTryMs_{0};
    std::unique_ptr<JobThread> lifecycle_;
    std::thread housekeeping_;
    std::mutex housekeepingMutex_;
    std::condition_variable housekeepingWake_;
    bool housekeepingStop_{false};
    bool windowReady_{false};
    bool visible_{false};
    std::int32_t primaryPointer_{-1};
    std::int64_t lastFrameMs_{0};
};

} // namespace

// The entry point of android_native_app_glue.
extern "C" void android_main(android_app* app) {
    SilvetonApp program(app);
    program.run();
}
