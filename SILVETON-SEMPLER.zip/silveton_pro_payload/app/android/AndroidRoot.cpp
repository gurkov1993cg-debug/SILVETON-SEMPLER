// SILVETON_ANDROID_ROOT_V1 - see AndroidRoot.h
#include "AndroidRoot.h"
#include <android/log.h>

#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstring>
#include <thread>
#include <vector>

#include <fcntl.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "RootScripts.inc"

namespace silveton::android {
namespace {

// "@UID@" / "@PID@" of the generated scripts = the tablet's Process.myUid() / Process.myPid()
std::string filled(const char* script) {
    std::string text(script);
    const std::string uid = std::to_string(static_cast<long long>(::getuid()));
    const std::string pid = std::to_string(static_cast<long long>(::getpid()));
    const struct { const char* key; const std::string* value; } keys[] = {{"@UID@", &uid}, {"@PID@", &pid}};
    for (const auto& k : keys) {
        const std::string key = k.key;
        for (std::size_t at = text.find(key); at != std::string::npos; at = text.find(key, at + k.value->size())) {
            text.replace(at, key.size(), *k.value);
        }
    }
    return text;
}

std::string trimmedText(std::string s) {
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ' || s.back() == '\t')) s.pop_back();
    std::size_t begin = 0U;
    while (begin < s.size() && (s[begin] == '\n' || s[begin] == '\r' || s[begin] == ' ' || s[begin] == '\t')) ++begin;
    return s.substr(begin);
}

void setNonBlocking(int fd) {
    const int flags = ::fcntl(fd, F_GETFL, 0);
    if (flags >= 0) ::fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

} // namespace

// ---------------------------------------------------------------- su
// The tablet's runSu: start `su`, write the script into it, never read before the process ends or the time is up
// (a hanging command must not make the timeout useless), kill it when the time is up.
RootRuntime::Result RootRuntime::runSu(const std::string& script, int timeoutSeconds) {
    ::signal(SIGPIPE, SIG_IGN);
    int in[2] = {-1, -1};
    int out[2] = {-1, -1};
    int failed[2] = {-1, -1};   // the child reports a failed exec through this one (errno), it closes by itself when exec worked
    if (::pipe2(in, O_CLOEXEC) != 0 || ::pipe2(out, O_CLOEXEC) != 0 || ::pipe2(failed, O_CLOEXEC) != 0) {
        const std::string why = std::strerror(errno);
        for (int fd : {in[0], in[1], out[0], out[1], failed[0], failed[1]}) if (fd >= 0) ::close(fd);
        return {false, "Root unavailable: " + why};
    }
    const pid_t child = ::fork();
    if (child < 0) {
        const std::string why = std::strerror(errno);
        for (int fd : {in[0], in[1], out[0], out[1], failed[0], failed[1]}) ::close(fd);
        return {false, "Root unavailable: " + why};
    }
    if (child == 0) {
        // only calls that are safe between fork and exec
        ::dup2(in[0], 0);
        ::dup2(out[1], 1);
        ::dup2(out[1], 2);
        char* const argv[] = {const_cast<char*>("su"), nullptr};
        ::execvp("su", argv);
        const int err = errno;
        const ssize_t ignored = ::write(failed[1], &err, sizeof(err));
        (void)ignored;
        ::_exit(127);
    }
    ::close(in[0]);
    ::close(out[1]);
    ::close(failed[1]);

    // exec failed? ("Cannot run program su")
    int execError = 0;
    const ssize_t got = ::read(failed[0], &execError, sizeof(execError));
    ::close(failed[0]);
    if (got == static_cast<ssize_t>(sizeof(execError))) {
        ::close(in[1]);
        ::close(out[0]);
        int st = 0;
        ::waitpid(child, &st, 0);
        return {false, std::string("Root unavailable: Cannot run program \"su\": error=") + std::to_string(execError) + ", " + std::strerror(execError)};
    }

    // the script (a few kilobytes: it fits into the pipe at once)
    {
        const std::string text = script + "\n";
        std::size_t done = 0U;
        setNonBlocking(in[1]);
        const auto writeDeadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
        while (done < text.size() && std::chrono::steady_clock::now() < writeDeadline) {
            const ssize_t n = ::write(in[1], text.data() + done, text.size() - done);
            if (n > 0) { done += static_cast<std::size_t>(n); continue; }
            if (n < 0 && errno == EINTR) continue;
            if (n < 0 && errno == EAGAIN) { std::this_thread::sleep_for(std::chrono::milliseconds(5)); continue; }
            break;
        }
        ::close(in[1]);
    }

    setNonBlocking(out[0]);
    std::string output;
    bool eof = false;
    bool exited = false;
    int status = 0;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeoutSeconds);
    while (true) {
        if (!eof) {
            struct pollfd p;
            p.fd = out[0];
            p.events = POLLIN;
            p.revents = 0;
            const int ready = ::poll(&p, 1, 25);
            if (ready > 0) {
                char buffer[1024];
                for (;;) {
                    const ssize_t n = ::read(out[0], buffer, sizeof(buffer));
                    if (n > 0) { output.append(buffer, static_cast<std::size_t>(n)); continue; }
                    if (n == 0) eof = true;
                    break;
                }
            }
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        const pid_t w = ::waitpid(child, &status, WNOHANG);
        if (w == child) { exited = true; break; }
        if (std::chrono::steady_clock::now() >= deadline) break;
    }
    if (!exited) {
        ::kill(child, SIGKILL);
        for (int i = 0; i < 100; ++i) {   // up to one second for the end
            if (::waitpid(child, &status, WNOHANG) == child) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        ::close(out[0]);
        return {false, "Root setup timed out"};
    }
    // what is left in the pipe
    for (;;) {
        char buffer[1024];
        const ssize_t n = ::read(out[0], buffer, sizeof(buffer));
        if (n > 0) { output.append(buffer, static_cast<std::size_t>(n)); continue; }
        break;
    }
    ::close(out[0]);
    const int code = WIFEXITED(status) ? WEXITSTATUS(status) : (128 + (WIFSIGNALED(status) ? WTERMSIG(status) : 0));
    if (code == 0) return {};
    return {false, "Root setup failed (" + std::to_string(code) + "): " + trimmedText(output)};
}

// ---------------------------------------------------------------- the calls of SilvetonRootRuntime
RootRuntime::Result RootRuntime::enter() {
    std::lock_guard<std::mutex> guard(lock_);
    if (active_) return {};
    const Result r = runSu(filled(kScript_enter), 15);
    if (r.ok) active_ = true;
    return r;
}

RootRuntime::Result RootRuntime::promoteRealtimeThreads() { return runSu(filled(kScript_promoteRealtimeThreads), 5); }
RootRuntime::Result RootRuntime::refreshBankStorageAccess() { return runSu(filled(kScript_refreshBankStorageAccess), 5); }
RootRuntime::Result RootRuntime::refreshAudioPermissions() { return runSu(filled(kScript_refreshAudioPermissions), 8); }
RootRuntime::Result RootRuntime::refreshMidiPermissions() { return runSu(filled(kScript_refreshMidiPermissions), 5); }

RootRuntime::Result RootRuntime::leave() {
    std::lock_guard<std::mutex> guard(lock_);
    if (!active_) return {};
    const Result r = runSu(filled(kScript_leave), 10);
    if (r.ok) active_ = false;
    return r;
}

// ---------------------------------------------------------------- the controller's view of it
AndroidPlatform::AndroidPlatform() : shared_(std::make_shared<Shared>()) {}

AndroidPlatform::Result AndroidPlatform::enter() { return shared_->root.enter(); }
AndroidPlatform::Result AndroidPlatform::refreshAudioPermissions() { return shared_->root.refreshAudioPermissions(); }
AndroidPlatform::Result AndroidPlatform::refreshMidiPermissions() { return shared_->root.refreshMidiPermissions(); }
AndroidPlatform::Result AndroidPlatform::refreshBankStorageAccess() { return shared_->root.refreshBankStorageAccess(); }

// SamplerRuntime.promoteThreadsAsync(): the sound threads are lifted 80 ms after they were started, away from the sound start itself.
void AndroidPlatform::audioStarted() {
    const std::shared_ptr<Shared> shared = shared_;
    std::thread([shared] {
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
        if (!shared->closed.load()) {
            const auto result = shared->root.promoteRealtimeThreads();
            if (!result.ok) __android_log_print(ANDROID_LOG_WARN, "SILVETON", "%s", result.message.c_str());
        }
    }).detach();
}

void AndroidPlatform::leave() {
    shared_->closed.store(true);
    shared_->root.leave();
}

std::string AndroidPlatform::bankNotFoundMessage(const Result& storageAccess) const {
    const std::string detail = storageAccess.ok ? "all-files access granted" : storageAccess.message;
    return "SILVETON_BANK.sv is not readable (" + detail + "). Expected /storage/emulated/0/SILVETON_BANK.sv";
}

} // namespace silveton::android
