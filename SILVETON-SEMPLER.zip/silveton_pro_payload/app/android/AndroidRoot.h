#pragma once
// SILVETON_ANDROID_ROOT_V1 - the root part of the tablet's start-up, carried over from SilvetonRootRuntime.kt and the
// parts of SamplerRuntime.kt that belong to it: the already approved root service (Magisk "su") grants only the access and
// tuning the sampler needs (SELinux rule for the sound devices, device permissions, CPU cores, realtime threads).
// The scripts themselves are generated from the Kotlin source (tools/gen_root_scripts.py), not retyped.
// Every call may take seconds: the controller makes them only on the thread that starts / recovers the sound.

#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "silveton/ui/SamplerAppController.h"

namespace silveton::android {

class RootRuntime {
public:
    using Result = silveton::ui::PlatformRuntime::Result;

    Result enter();                      // once: SELinux, device permissions, cores, governor, IRQ
    Result promoteRealtimeThreads();     // after the engine threads exist
    Result refreshBankStorageAccess();
    Result refreshAudioPermissions();
    Result refreshMidiPermissions();
    Result leave();                      // gives the cores / governor / device owners back

    // Runs one script as root (`su`), waits at most timeoutSeconds. Output of the script ends up in Result::message.
    static Result runSu(const std::string& script, int timeoutSeconds);

private:
    std::mutex lock_;
    bool active_{false};
};

// The PlatformRuntime of the tablet: the controller calls it, it calls the root scripts.
class AndroidPlatform : public silveton::ui::PlatformRuntime {
public:
    AndroidPlatform();
    Result enter() override;
    Result refreshAudioPermissions() override;
    Result refreshMidiPermissions() override;
    Result refreshBankStorageAccess() override;
    void audioStarted() override;
    void leave() override;
    std::string bankNotFoundMessage(const Result& storageAccess) const override;

private:
    struct Shared {
        RootRuntime root;
        std::atomic<bool> closed{false};
    };
    std::shared_ptr<Shared> shared_;
};

} // namespace silveton::android
