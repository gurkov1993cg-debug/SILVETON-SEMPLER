// SILVETON_GPU_DRAW_V1 - see GlRenderer.h.
#include "GlRenderer.h"

#include <dlfcn.h>

#include <initializer_list>

#include <algorithm>
#include <array>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <utility>

namespace silveton::gl {
namespace {

using ui::detail::DisplayList;
using ui::detail::RasterOp;

// ============================================================================ EGL / OpenGL ES 3.0 without headers
using EGLDisplay = void*;
using EGLConfig = void*;
using EGLContext = void*;
using EGLSurface = void*;
using EGLint = std::int32_t;
using EGLBoolean = unsigned int;
using EGLenum = unsigned int;
using GLenum = unsigned int;
using GLuint = unsigned int;
using GLint = std::int32_t;
using GLsizei = std::int32_t;
using GLboolean = unsigned char;
using GLfloat = float;
using GLchar = char;
using GLbitfield = unsigned int;
using GLsizeiptr = std::ptrdiff_t;
using GLintptr = std::ptrdiff_t;

constexpr EGLint EGL_SURFACE_TYPE = 0x3033, EGL_WINDOW_BIT = 0x0004, EGL_PBUFFER_BIT = 0x0001, EGL_RENDERABLE_TYPE = 0x3040,
                 EGL_OPENGL_ES3_BIT = 0x0040, EGL_RED_SIZE = 0x3024, EGL_GREEN_SIZE = 0x3023, EGL_BLUE_SIZE = 0x3022,
                 EGL_ALPHA_SIZE = 0x3021, EGL_DEPTH_SIZE = 0x3025, EGL_STENCIL_SIZE = 0x3026, EGL_NONE = 0x3038,
                 EGL_CONTEXT_CLIENT_VERSION = 0x3098, EGL_WIDTH = 0x3057, EGL_HEIGHT = 0x3056, EGL_NATIVE_VISUAL_ID = 0x302E;
constexpr EGLenum EGL_OPENGL_ES_API = 0x30A0;
constexpr EGLenum EGL_PLATFORM_SURFACELESS_MESA = 0x31DD;

constexpr GLenum GL_VENDOR = 0x1F00, GL_RENDERER = 0x1F01, GL_VERSION = 0x1F02, GL_MAX_TEXTURE_SIZE = 0x0D33;
constexpr GLenum GL_COLOR_BUFFER_BIT = 0x4000, GL_BLEND = 0x0BE2, GL_ONE = 1, GL_ONE_MINUS_SRC_ALPHA = 0x0303;
constexpr GLenum GL_DEPTH_TEST = 0x0B71, GL_SCISSOR_TEST = 0x0C11, GL_CULL_FACE = 0x0B44, GL_DITHER = 0x0BD0;
constexpr GLenum GL_TEXTURE_2D = 0x0DE1, GL_TEXTURE0 = 0x84C0, GL_TEXTURE_MIN_FILTER = 0x2801, GL_TEXTURE_MAG_FILTER = 0x2800;
constexpr GLenum GL_TEXTURE_WRAP_S = 0x2802, GL_TEXTURE_WRAP_T = 0x2803, GL_NEAREST = 0x2600, GL_LINEAR = 0x2601, GL_CLAMP_TO_EDGE = 0x812F;
constexpr GLenum GL_R8 = 0x8229, GL_R32F = 0x822E, GL_RED = 0x1903, GL_RGBA = 0x1908, GL_RGBA8 = 0x8058, GL_UNSIGNED_BYTE = 0x1401;
constexpr GLenum GL_UNPACK_ALIGNMENT = 0x0CF5, GL_PACK_ALIGNMENT = 0x0D05;
constexpr GLenum GL_ARRAY_BUFFER = 0x8892, GL_STREAM_DRAW = 0x88E0, GL_FLOAT = 0x1406, GL_TRIANGLE_STRIP = 0x0005;
constexpr GLenum GL_VERTEX_SHADER = 0x8B31, GL_FRAGMENT_SHADER = 0x8B30, GL_COMPILE_STATUS = 0x8B81, GL_LINK_STATUS = 0x8B82, GL_INFO_LOG_LENGTH = 0x8B84;

#define SV_EGL_FUNCTIONS(X)                                                                                              \
    X(EGLDisplay, eglGetDisplay, (void*))                                                                                \
    X(EGLBoolean, eglInitialize, (EGLDisplay, EGLint*, EGLint*))                                                         \
    X(EGLBoolean, eglChooseConfig, (EGLDisplay, const EGLint*, EGLConfig*, EGLint, EGLint*))                             \
    X(EGLBoolean, eglGetConfigAttrib, (EGLDisplay, EGLConfig, EGLint, EGLint*))                                          \
    X(EGLSurface, eglCreateWindowSurface, (EGLDisplay, EGLConfig, void*, const EGLint*))                                 \
    X(EGLSurface, eglCreatePbufferSurface, (EGLDisplay, EGLConfig, const EGLint*))                                       \
    X(EGLBoolean, eglDestroySurface, (EGLDisplay, EGLSurface))                                                           \
    X(EGLContext, eglCreateContext, (EGLDisplay, EGLConfig, EGLContext, const EGLint*))                                  \
    X(EGLBoolean, eglDestroyContext, (EGLDisplay, EGLContext))                                                           \
    X(EGLBoolean, eglMakeCurrent, (EGLDisplay, EGLSurface, EGLSurface, EGLContext))                                      \
    X(EGLBoolean, eglSwapBuffers, (EGLDisplay, EGLSurface))                                                              \
    X(EGLBoolean, eglSwapInterval, (EGLDisplay, EGLint))                                                                 \
    X(EGLBoolean, eglQuerySurface, (EGLDisplay, EGLSurface, EGLint, EGLint*))                                            \
    X(EGLBoolean, eglBindAPI, (EGLenum))                                                                                 \
    X(EGLint, eglGetError, ())                                                                                           \
    X(void*, eglGetProcAddress, (const char*))

#define SV_GL_FUNCTIONS(X)                                                                                               \
    X(const unsigned char*, glGetString, (GLenum))                                                                       \
    X(GLenum, glGetError, ())                                                                                            \
    X(void, glGetIntegerv, (GLenum, GLint*))                                                                             \
    X(GLuint, glCreateShader, (GLenum))                                                                                  \
    X(void, glShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*))                                       \
    X(void, glCompileShader, (GLuint))                                                                                   \
    X(void, glGetShaderiv, (GLuint, GLenum, GLint*))                                                                     \
    X(void, glGetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*))                                                    \
    X(GLuint, glCreateProgram, ())                                                                                       \
    X(void, glAttachShader, (GLuint, GLuint))                                                                            \
    X(void, glLinkProgram, (GLuint))                                                                                     \
    X(void, glGetProgramiv, (GLuint, GLenum, GLint*))                                                                    \
    X(void, glGetProgramInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*))                                                   \
    X(void, glUseProgram, (GLuint))                                                                                      \
    X(void, glDeleteShader, (GLuint))                                                                                    \
    X(void, glDeleteProgram, (GLuint))                                                                                   \
    X(GLint, glGetUniformLocation, (GLuint, const GLchar*))                                                              \
    X(void, glUniform1i, (GLint, GLint))                                                                                 \
    X(void, glUniform1f, (GLint, GLfloat))                                                                               \
    X(void, glUniform2f, (GLint, GLfloat, GLfloat))                                                                      \
    X(void, glGenBuffers, (GLsizei, GLuint*))                                                                            \
    X(void, glBindBuffer, (GLenum, GLuint))                                                                              \
    X(void, glBufferData, (GLenum, GLsizeiptr, const void*, GLenum))                                                     \
    X(void, glDeleteBuffers, (GLsizei, const GLuint*))                                                                   \
    X(void, glGenVertexArrays, (GLsizei, GLuint*))                                                                       \
    X(void, glBindVertexArray, (GLuint))                                                                                 \
    X(void, glDeleteVertexArrays, (GLsizei, const GLuint*))                                                              \
    X(void, glEnableVertexAttribArray, (GLuint))                                                                         \
    X(void, glVertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*))                             \
    X(void, glVertexAttribDivisor, (GLuint, GLuint))                                                                     \
    X(void, glDrawArraysInstanced, (GLenum, GLint, GLsizei, GLsizei))                                                    \
    X(void, glGenTextures, (GLsizei, GLuint*))                                                                           \
    X(void, glBindTexture, (GLenum, GLuint))                                                                             \
    X(void, glTexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*))                  \
    X(void, glTexSubImage2D, (GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void*))               \
    X(void, glTexParameteri, (GLenum, GLenum, GLint))                                                                    \
    X(void, glDeleteTextures, (GLsizei, const GLuint*))                                                                  \
    X(void, glActiveTexture, (GLenum))                                                                                   \
    X(void, glPixelStorei, (GLenum, GLint))                                                                              \
    X(void, glViewport, (GLint, GLint, GLsizei, GLsizei))                                                                \
    X(void, glClearColor, (GLfloat, GLfloat, GLfloat, GLfloat))                                                          \
    X(void, glClear, (GLbitfield))                                                                                       \
    X(void, glEnable, (GLenum))                                                                                          \
    X(void, glDisable, (GLenum))                                                                                         \
    X(void, glBlendFunc, (GLenum, GLenum))                                                                               \
    X(void, glReadPixels, (GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void*))                                       \
    X(void, glFinish, ())

struct Api {
#define SV_DECLARE(ret, name, args) ret(*name) args = nullptr;
    SV_EGL_FUNCTIONS(SV_DECLARE)
    SV_GL_FUNCTIONS(SV_DECLARE)
#undef SV_DECLARE
    EGLDisplay (*eglGetPlatformDisplayEXT)(EGLenum, void*, const EGLint*) = nullptr;
    bool loaded{false};
};

void* openFirst(std::initializer_list<const char*> names) {
    for (const char* n : names) {
        if (void* h = ::dlopen(n, RTLD_NOW | RTLD_LOCAL)) return h;
    }
    return nullptr;
}

// Loaded once and kept for the life of the program.
Api* loadApi(std::string& error) {
    static Api api;
    static bool tried = false;
    static std::string failure;
    if (tried) {
        if (!api.loaded) error = failure;
        return api.loaded ? &api : nullptr;
    }
    tried = true;
    void* egl = openFirst({"libEGL.so", "libEGL.so.1"});
    void* gles = openFirst({"libGLESv3.so", "libGLESv2.so", "libGLESv2.so.2"});
    if (egl == nullptr || gles == nullptr) {
        failure = egl == nullptr ? "no libEGL" : "no libGLESv3 / libGLESv2";
        error = failure;
        return nullptr;
    }
    bool ok = true;
    std::string missing;
#define SV_LOAD_EGL(ret, name, args)                                                                                     \
    api.name = reinterpret_cast<decltype(api.name)>(::dlsym(egl, #name));                                                \
    if (api.name == nullptr) { ok = false; missing += " " #name; }
    SV_EGL_FUNCTIONS(SV_LOAD_EGL)
#undef SV_LOAD_EGL
#define SV_LOAD_GL(ret, name, args)                                                                                      \
    api.name = reinterpret_cast<decltype(api.name)>(::dlsym(gles, #name));                                               \
    if (api.name == nullptr && api.eglGetProcAddress != nullptr) api.name = reinterpret_cast<decltype(api.name)>(api.eglGetProcAddress(#name)); \
    if (api.name == nullptr) { ok = false; missing += " " #name; }
    SV_GL_FUNCTIONS(SV_LOAD_GL)
#undef SV_LOAD_GL
    if (api.eglGetProcAddress != nullptr) {
        api.eglGetPlatformDisplayEXT = reinterpret_cast<decltype(api.eglGetPlatformDisplayEXT)>(api.eglGetProcAddress("eglGetPlatformDisplayEXT"));
    }
    if (!ok) {
        failure = "missing functions:" + missing;
        error = failure;
        return nullptr;
    }
    api.loaded = true;
    return &api;
}

// ============================================================================ the shaders
const char* const kVertexShader = R"GLSL(#version 300 es
precision highp float;
layout(location = 0) in vec4 aArea;
layout(location = 1) in vec4 aGeom;
layout(location = 2) in vec4 aColor;
layout(location = 3) in vec4 aParam;
layout(location = 4) in vec4 aXf0;
layout(location = 5) in vec4 aXf1;
uniform vec2 uSize;
flat out vec4 vArea;
flat out vec4 vGeom;
flat out vec4 vColor;
flat out vec4 vParam;
flat out vec4 vXf0;
flat out vec4 vXf1;
void main() {
    vec2 corner = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));
    vec2 p = mix(aArea.xy, aArea.zw, corner);
    gl_Position = vec4(p.x * 2.0 / uSize.x - 1.0, 1.0 - p.y * 2.0 / uSize.y, 0.0, 1.0);
    vArea = aArea; vGeom = aGeom; vColor = aColor; vParam = aParam; vXf0 = aXf0; vXf1 = aXf1;
}
)GLSL";

// param.x: 0 rectangle, 1 shape (coverage from the atlas), 2 image    param.y: 0 plain colour, 1 linear, 2 radial, 3 sweep
// param.z: row of the gradient table    param.w: 1 = the gradient repeats
const char* const kFragmentShader = R"GLSL(#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
flat in vec4 vArea;
flat in vec4 vGeom;
flat in vec4 vColor;
flat in vec4 vParam;
flat in vec4 vXf0;
flat in vec4 vXf1;
uniform sampler2D uMask;
uniform sampler2D uLut;
uniform sampler2D uImage;
uniform sampler2D uDir;
uniform float uHeight;
uniform float uLutRows;
uniform int uTprShift;
uniform int uTprMask;
out vec4 oColor;
void main() {
    vec2 dev = vec2(gl_FragCoord.x, uHeight - gl_FragCoord.y);
    int kind = int(vParam.x + 0.5);
    if (kind == 2) {
        vec2 st = (dev - vGeom.xy) / (vGeom.zw - vGeom.xy);
        oColor = textureLod(uImage, st, 0.0) * vColor.a;
        return;
    }
    float cov = 1.0;
    if (kind == 0) {
        vec2 f = floor(dev);
        float cx = min(f.x + 1.0, vGeom.z) - max(f.x, vGeom.x);
        float cy = min(f.y + 1.0, vGeom.w) - max(f.y, vGeom.y);
        cov = clamp(cx, 0.0, 1.0) * clamp(cy, 0.0, 1.0);
    } else {
        // the shape's coverage is kept in tiles of 16 x 16: vGeom.x = first entry of its directory, vGeom.y = tiles per row.
        // A directory entry: 0 = nothing in the tile, 1 = all covered, n + 2 = the tile n of the mask texture.
        ivec2 p = ivec2(floor(dev)) - ivec2(vArea.xy);
        int d = int(vGeom.x + 0.5) + (p.y >> 4) * int(vGeom.y + 0.5) + (p.x >> 4);
        float code = texelFetch(uDir, ivec2(d & 2047, d >> 11), 0).r;
        if (code < 0.5) discard;
        if (code < 1.5) {
            cov = 1.0;
        } else {
            int k = int(code + 0.5) - 2;
            cov = texelFetch(uMask, ivec2((k & uTprMask) * 16, (k >> uTprShift) * 16) + (p & 15), 0).r;
        }
    }
    int mode = int(vParam.y + 0.5);
    vec4 src = vColor;
    if (mode != 0) {
        float t;
        if (mode == 1) {
            t = vXf0.x * dev.x + vXf0.y * dev.y + vXf0.z;
        } else {
            vec2 l = vec2(vXf0.x * dev.x + vXf0.z * dev.y + vXf1.x, vXf0.y * dev.x + vXf0.w * dev.y + vXf1.y);
            if (mode == 2) {
                t = length(l) * vXf1.z;
            } else {
                t = atan(l.y, l.x) * 0.15915494309189535;
                if (t < 0.0) t += 1.0;
            }
        }
        if (vParam.w > 0.5 && mode != 3) t = fract(t); else t = clamp(t, 0.0, 1.0);
        src = textureLod(uLut, vec2((t * 255.0 + 0.5) / 256.0, (vParam.z + 0.5) / uLutRows), 0.0);
    }
    oColor = src * cov;
}
)GLSL";

struct Instance {
    float area[4];
    float geom[4];
    float color[4];
    float param[4];
    float xf0[4];
    float xf1[4];
};
static_assert(sizeof(Instance) == 96U, "the vertex attributes expect 24 floats");

constexpr int kLutRows = 256;
constexpr int kMaxImageTextures = 6;

struct Cmd {
    enum class Type { Draw, Clear, Image } type{Type::Draw};
    int first{0};
    int count{0};
    std::uint32_t color{0U};   // Clear
    GLuint texture{0U};        // Image
};

float byteF(std::uint32_t v, unsigned shift) { return static_cast<float>((v >> shift) & 255U) / 255.0F; }

// a small hash of the colour stops of a gradient (and the paint alpha): the same gradient shares a row of the table
std::uint64_t gradientKey(const ui::Shader& s, int alpha255) {
    std::uint64_t h = 0x243F6A8885A308D3ULL ^ static_cast<std::uint64_t>(alpha255);
    auto mix = [&h](std::uint32_t v) {
        h = (h ^ v) * 0x9E3779B185EBCA87ULL;
        h ^= h >> 29U;
    };
    mix(static_cast<std::uint32_t>(s.colors.size()));
    for (const auto c : s.colors) mix(c);
    mix(static_cast<std::uint32_t>(s.positions.size()));
    for (const float f : s.positions) {
        std::uint32_t u;
        std::memcpy(&u, &f, sizeof u);
        mix(u);
    }
    return h;
}

} // namespace

// ============================================================================ the renderer
struct GlRenderer::Impl {
    Api* gl{nullptr};
    EGLDisplay display{nullptr};
    EGLConfig config{nullptr};
    EGLContext context{nullptr};
    EGLSurface surface{nullptr};
    bool windowSurface{false};
    int width{0};
    int height{0};
    std::string info;
    std::string error;
    bool current{false};   // the context is current on this thread

    GLuint program{0U};
    GLuint vao{0U};
    GLuint buffer{0U};
    GLuint maskTex{0U};       // the tiles (16 x 16 bytes of coverage each) of all shapes
    GLuint dirTex{0U};        // for every shape one float per tile: 0 empty, 1 all covered, n + 2 = tile n of maskTex
    GLuint lutTex{0U};        // gradients: one row of 256 colours each
    GLuint dummyImageTex{0U};
    GLint uSize{-1}, uHeight{-1}, uLutRows{-1};

    // The coverage of a shape is cut into tiles of 16 x 16. Tiles with nothing in them or all covered cost no memory (the directory
    // says so); only the tiles on the edge of a shape are kept. The textures are filled from CPU copies in a few big uploads per picture.
    static constexpr int kTile = 16;
    static constexpr int kDirW = 2048;       // directory entries per row of dirTex
    static constexpr int kDirRows = 256;
    int atlasW{0};
    int atlasH{0};
    int tilesPerRow{0};
    int tprShift{0};
    int tileCapacity{0};
    int tileNext{0};
    std::vector<std::uint8_t> maskMirror;
    int dirtyTileLo{INT_MAX}, dirtyTileHi{-1};     // rows of tiles that must go to the texture
    std::vector<float> dirMirror;
    int dirNext{0};
    int dirtyDirLo{INT_MAX}, dirtyDirHi{-1};       // directory entries
    struct MaskPlace { int dir; int tilesX; int w; int h; std::uint64_t used; };
    std::unordered_map<std::uint64_t, MaskPlace> masks;
    std::vector<std::uint8_t> maskScratch;
    // gradient table
    std::unordered_map<std::uint64_t, int> lutRows;
    int lutNext{0};
    std::vector<std::uint8_t> lutMirror;
    int dirtyLutLo{INT_MAX}, dirtyLutHi{-1};
    // images
    struct ImageTex { std::uint64_t key{0U}; GLuint tex{0U}; std::uint64_t used{0U}; };
    std::vector<ImageTex> images;
    std::uint64_t frameNo{0U};

    std::vector<Instance> instances;
    std::vector<Cmd> cmds;
    int newMasks{0};
    double buildMs{0.0};
    int lastInstances{0};
    std::size_t bufferBytes{0U};

    enum class Build { Ok, Reset, Fail };
    bool lutWasFull{false};    // why the last build asked for room: the gradient table (true) or the shape tiles / directory

    ~Impl() { teardown(); }

    void teardown() {
        if (gl == nullptr || display == nullptr) return;
        if (context != nullptr && surface != nullptr && gl->eglMakeCurrent(display, surface, surface, context) != 0U) {
            if (program != 0U) gl->glDeleteProgram(program);
            if (buffer != 0U) gl->glDeleteBuffers(1, &buffer);
            if (vao != 0U) gl->glDeleteVertexArrays(1, &vao);
            if (maskTex != 0U) gl->glDeleteTextures(1, &maskTex);
            if (dirTex != 0U) gl->glDeleteTextures(1, &dirTex);
            if (lutTex != 0U) gl->glDeleteTextures(1, &lutTex);
            if (dummyImageTex != 0U) gl->glDeleteTextures(1, &dummyImageTex);
            for (const auto& t : images) if (t.tex != 0U) gl->glDeleteTextures(1, &t.tex);
        }
        gl->eglMakeCurrent(display, nullptr, nullptr, nullptr);
        current = false;
        if (surface != nullptr) gl->eglDestroySurface(display, surface);
        if (context != nullptr) gl->eglDestroyContext(display, context);
        surface = nullptr;
        context = nullptr;
        program = vao = buffer = maskTex = dirTex = lutTex = dummyImageTex = 0U;
        images.clear();
    }

    bool fail(const std::string& text) {
        error = text;
        return false;
    }

    // ---------------------------------------------------------------- set-up
    bool compile(GLenum type, const char* source, GLuint& out) {
        out = gl->glCreateShader(type);
        gl->glShaderSource(out, 1, &source, nullptr);
        gl->glCompileShader(out);
        GLint ok = 0;
        gl->glGetShaderiv(out, GL_COMPILE_STATUS, &ok);
        if (ok != 0) return true;
        GLint len = 0;
        gl->glGetShaderiv(out, GL_INFO_LOG_LENGTH, &len);
        std::string log(static_cast<std::size_t>(std::max(len, 1)), '\0');
        gl->glGetShaderInfoLog(out, len, nullptr, &log[0]);
        return fail(std::string(type == GL_VERTEX_SHADER ? "vertex" : "fragment") + " shader: " + log.c_str());
    }

    bool buildProgram() {
        GLuint vs = 0U, fs = 0U;
        if (!compile(GL_VERTEX_SHADER, kVertexShader, vs)) return false;
        if (!compile(GL_FRAGMENT_SHADER, kFragmentShader, fs)) return false;
        program = gl->glCreateProgram();
        gl->glAttachShader(program, vs);
        gl->glAttachShader(program, fs);
        gl->glLinkProgram(program);
        gl->glDeleteShader(vs);
        gl->glDeleteShader(fs);
        GLint ok = 0;
        gl->glGetProgramiv(program, GL_LINK_STATUS, &ok);
        if (ok == 0) {
            GLint len = 0;
            gl->glGetProgramiv(program, GL_INFO_LOG_LENGTH, &len);
            std::string log(static_cast<std::size_t>(std::max(len, 1)), '\0');
            gl->glGetProgramInfoLog(program, len, nullptr, &log[0]);
            return fail(std::string("link: ") + log.c_str());
        }
        gl->glUseProgram(program);
        uSize = gl->glGetUniformLocation(program, "uSize");
        uHeight = gl->glGetUniformLocation(program, "uHeight");
        uLutRows = gl->glGetUniformLocation(program, "uLutRows");
        gl->glUniform1i(gl->glGetUniformLocation(program, "uMask"), 0);
        gl->glUniform1i(gl->glGetUniformLocation(program, "uLut"), 1);
        gl->glUniform1i(gl->glGetUniformLocation(program, "uImage"), 2);
        gl->glUniform1i(gl->glGetUniformLocation(program, "uDir"), 3);
        gl->glUniform1f(uLutRows, static_cast<float>(kLutRows));
        return true;
    }

    GLuint makeTexture(GLenum filter) {
        GLuint t = 0U;
        gl->glGenTextures(1, &t);
        gl->glBindTexture(GL_TEXTURE_2D, t);
        gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, static_cast<GLint>(filter));
        gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, static_cast<GLint>(filter));
        gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, static_cast<GLint>(GL_CLAMP_TO_EDGE));
        gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, static_cast<GLint>(GL_CLAMP_TO_EDGE));
        return t;
    }

    bool buildResources() {
        GLint maxTex = 2048;
        gl->glGetIntegerv(GL_MAX_TEXTURE_SIZE, &maxTex);
        if (maxTex < 2048) return fail("textures are too small");
        atlasW = maxTex >= 4096 ? 4096 : 2048;
        atlasH = 2048;
        tilesPerRow = atlasW / kTile;
        tprShift = 0;
        while ((1 << tprShift) < tilesPerRow) ++tprShift;
        tileCapacity = tilesPerRow * (atlasH / kTile);
        maskMirror.assign(static_cast<std::size_t>(atlasW) * static_cast<std::size_t>(atlasH), 0U);
        dirMirror.assign(static_cast<std::size_t>(kDirW) * static_cast<std::size_t>(kDirRows), 0.0F);
        lutMirror.assign(256U * 4U * static_cast<std::size_t>(kLutRows), 0U);
        gl->glUniform1i(gl->glGetUniformLocation(program, "uTprShift"), tprShift);
        gl->glUniform1i(gl->glGetUniformLocation(program, "uTprMask"), tilesPerRow - 1);
        gl->glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        gl->glPixelStorei(GL_PACK_ALIGNMENT, 1);
        gl->glActiveTexture(GL_TEXTURE0);
        maskTex = makeTexture(GL_NEAREST);
        gl->glTexImage2D(GL_TEXTURE_2D, 0, static_cast<GLint>(GL_R8), atlasW, atlasH, 0, GL_RED, GL_UNSIGNED_BYTE, nullptr);
        gl->glActiveTexture(GL_TEXTURE0 + 1U);
        lutTex = makeTexture(GL_LINEAR);
        gl->glTexImage2D(GL_TEXTURE_2D, 0, static_cast<GLint>(GL_RGBA8), 256, kLutRows, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        gl->glActiveTexture(GL_TEXTURE0 + 3U);
        dirTex = makeTexture(GL_NEAREST);
        gl->glTexImage2D(GL_TEXTURE_2D, 0, static_cast<GLint>(GL_R32F), kDirW, kDirRows, 0, GL_RED, GL_FLOAT, nullptr);
        gl->glActiveTexture(GL_TEXTURE0 + 2U);
        dummyImageTex = makeTexture(GL_LINEAR);
        const std::uint8_t px[4] = {0U, 0U, 0U, 0U};
        gl->glTexImage2D(GL_TEXTURE_2D, 0, static_cast<GLint>(GL_RGBA8), 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
        gl->glGenVertexArrays(1, &vao);
        gl->glBindVertexArray(vao);
        gl->glGenBuffers(1, &buffer);
        gl->glBindBuffer(GL_ARRAY_BUFFER, buffer);
        for (GLuint i = 0U; i < 6U; ++i) {
            gl->glEnableVertexAttribArray(i);
            gl->glVertexAttribDivisor(i, 1U);
        }
        gl->glDisable(GL_DEPTH_TEST);
        gl->glDisable(GL_SCISSOR_TEST);
        gl->glDisable(GL_CULL_FACE);
        gl->glDisable(GL_DITHER);
        gl->glEnable(GL_BLEND);
        gl->glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        return gl->glGetError() == 0U ? true : fail("GL error while setting up");
    }

    bool setUp(const Options& o) {
        std::string apiError;
        gl = loadApi(apiError);
        if (gl == nullptr) return fail(apiError);
        if (o.surfaceless && gl->eglGetPlatformDisplayEXT != nullptr) display = gl->eglGetPlatformDisplayEXT(EGL_PLATFORM_SURFACELESS_MESA, nullptr, nullptr);
        else display = gl->eglGetDisplay(nullptr);
        if (display == nullptr) return fail("no EGL display");
        EGLint major = 0, minor = 0;
        if (gl->eglInitialize(display, &major, &minor) == 0U) return fail("eglInitialize failed");
        gl->eglBindAPI(EGL_OPENGL_ES_API);
        windowSurface = o.nativeWindow != nullptr;
        const EGLint attribs[] = {EGL_SURFACE_TYPE, windowSurface ? EGL_WINDOW_BIT : EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
                                  EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0, EGL_NONE};
        std::array<EGLConfig, 64> configs{};
        EGLint count = 0;
        if (gl->eglChooseConfig(display, attribs, configs.data(), static_cast<EGLint>(configs.size()), &count) == 0U || count <= 0) return fail("no EGL configuration (ES 3, 8888)");
        config = configs[0];
        for (EGLint i = 0; i < count; ++i) {   // the plain 8-8-8-8 one when there is one
            EGLint r = 0, g = 0, b = 0, a = 0, d = 0;
            gl->eglGetConfigAttrib(display, configs[static_cast<std::size_t>(i)], EGL_RED_SIZE, &r);
            gl->eglGetConfigAttrib(display, configs[static_cast<std::size_t>(i)], EGL_GREEN_SIZE, &g);
            gl->eglGetConfigAttrib(display, configs[static_cast<std::size_t>(i)], EGL_BLUE_SIZE, &b);
            gl->eglGetConfigAttrib(display, configs[static_cast<std::size_t>(i)], EGL_ALPHA_SIZE, &a);
            gl->eglGetConfigAttrib(display, configs[static_cast<std::size_t>(i)], EGL_DEPTH_SIZE, &d);
            if (r == 8 && g == 8 && b == 8 && a == 8 && d == 0) { config = configs[static_cast<std::size_t>(i)]; break; }
        }
        const EGLint ctxAttribs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
        context = gl->eglCreateContext(display, config, nullptr, ctxAttribs);
        if (context == nullptr) return fail("eglCreateContext failed (0x" + hex(gl->eglGetError()) + ")");
        if (windowSurface) {
            EGLint visual = 0;
            if (gl->eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &visual) != 0U && o.onNativeVisual) o.onNativeVisual(visual);
            surface = gl->eglCreateWindowSurface(display, config, o.nativeWindow, nullptr);
        } else {
            const EGLint pb[] = {EGL_WIDTH, std::max(1, o.width), EGL_HEIGHT, std::max(1, o.height), EGL_NONE};
            surface = gl->eglCreatePbufferSurface(display, config, pb);
        }
        if (surface == nullptr) return fail("cannot make the surface (0x" + hex(gl->eglGetError()) + ")");
        if (gl->eglMakeCurrent(display, surface, surface, context) == 0U) return fail("eglMakeCurrent failed (0x" + hex(gl->eglGetError()) + ")");
        current = true;
        if (windowSurface) gl->eglSwapInterval(display, 1);
        const auto* version = gl->glGetString(GL_VERSION);
        const auto* renderer = gl->glGetString(GL_RENDERER);
        const std::string v = version != nullptr ? reinterpret_cast<const char*>(version) : "?";
        info = std::string(renderer != nullptr ? reinterpret_cast<const char*>(renderer) : "?") + " | " + v;
        if (v.find("OpenGL ES 3") == std::string::npos) return fail("not OpenGL ES 3: " + v);
        if (!querySize(width, height)) return fail("cannot read the surface size");
        if (!buildProgram()) return false;
        return buildResources();
    }

    static std::string hex(EGLint v) {
        char text[16];
        std::snprintf(text, sizeof text, "%X", static_cast<unsigned>(v));
        return text;
    }

    bool querySize(int& w, int& h) {
        EGLint ew = 0, eh = 0;
        if (gl->eglQuerySurface(display, surface, EGL_WIDTH, &ew) == 0U || gl->eglQuerySurface(display, surface, EGL_HEIGHT, &eh) == 0U || ew <= 0 || eh <= 0) return false;
        w = ew;
        h = eh;
        return true;
    }

    // ---------------------------------------------------------------- caches
    void resetCaches() {
        masks.clear();
        tileNext = 0;
        dirNext = 0;
        lutRows.clear();
        lutNext = 0;
    }

    // Room for new shapes: what the last two pictures used is kept (the tiles are moved together inside the CPU copy - nothing is worked
    // out again), the rest is dropped. This is what makes dragging something (the EQ curve makes new shapes every picture) cheap.
    void compact() {
        std::vector<std::pair<std::uint64_t, MaskPlace>> keep;
        std::size_t entriesKept = 0U;
        for (const auto& m : masks) {
            if (m.second.used + 1U < frameNo) continue;   // not used in this picture or the one before
            keep.emplace_back(m.first, m.second);
            entriesKept += static_cast<std::size_t>(m.second.tilesX) * static_cast<std::size_t>((m.second.h + kTile - 1) / kTile);
        }
        std::vector<std::uint8_t> tilesTmp;
        tilesTmp.reserve(static_cast<std::size_t>(std::min(tileNext, tileCapacity)) * static_cast<std::size_t>(kTile * kTile));
        std::vector<float> dirTmp(entriesKept, 0.0F);
        std::size_t dirAt = 0U;
        for (auto& k : keep) {
            MaskPlace& m = k.second;
            const int entries = m.tilesX * ((m.h + kTile - 1) / kTile);
            for (int e = 0; e < entries; ++e) {
                float code = dirMirror[static_cast<std::size_t>(m.dir + e)];
                if (code >= 1.5F) {
                    const int oldK = static_cast<int>(code + 0.5F) - 2;
                    const int oldCol = oldK & (tilesPerRow - 1);
                    const int oldRow = oldK >> tprShift;
                    const std::size_t at = tilesTmp.size();
                    tilesTmp.resize(at + static_cast<std::size_t>(kTile * kTile));
                    for (int r = 0; r < kTile; ++r) {
                        std::memcpy(tilesTmp.data() + at + static_cast<std::size_t>(r * kTile),
                                    maskMirror.data() + static_cast<std::size_t>(oldRow * kTile + r) * static_cast<std::size_t>(atlasW) + static_cast<std::size_t>(oldCol * kTile),
                                    static_cast<std::size_t>(kTile));
                    }
                    code = static_cast<float>(static_cast<int>(at / static_cast<std::size_t>(kTile * kTile)) + 2);
                }
                dirTmp[dirAt + static_cast<std::size_t>(e)] = code;
            }
            m.dir = static_cast<int>(dirAt);
            dirAt += static_cast<std::size_t>(entries);
        }
        const int tiles = static_cast<int>(tilesTmp.size() / static_cast<std::size_t>(kTile * kTile));
        for (int k = 0; k < tiles; ++k) {
            const int col = k & (tilesPerRow - 1);
            const int row = k >> tprShift;
            for (int r = 0; r < kTile; ++r) {
                std::memcpy(maskMirror.data() + static_cast<std::size_t>(row * kTile + r) * static_cast<std::size_t>(atlasW) + static_cast<std::size_t>(col * kTile),
                            tilesTmp.data() + static_cast<std::size_t>(k * kTile * kTile + r * kTile), static_cast<std::size_t>(kTile));
            }
        }
        std::copy(dirTmp.begin(), dirTmp.end(), dirMirror.begin());
        masks.clear();
        for (const auto& k : keep) masks[k.first] = k.second;
        tileNext = tiles;
        dirNext = static_cast<int>(dirAt);
        if (tiles > 0) {
            dirtyTileLo = 0;
            dirtyTileHi = std::max(dirtyTileHi, (tiles - 1) >> tprShift);
        }
        if (dirAt > 0U) {
            dirtyDirLo = 0;
            dirtyDirHi = std::max(dirtyDirHi, static_cast<int>(dirAt) - 1);
        }
    }

    enum class Got { Ok, Full, Fail };

    // The directory of the coverage tiles of a shape (made once, then found by the hash of its geometry).
    Got maskFor(const RasterOp& op, int& dirBase, int& tilesX) {
        const int w = op.areaR - op.areaL;
        const int h = op.areaB - op.areaT;
        const int tx = (w + kTile - 1) / kTile;
        const int ty = (h + kTile - 1) / kTile;
        const auto found = masks.find(op.geomHash);
        if (found != masks.end() && found->second.w == w && found->second.h == h) {
            found->second.used = frameNo;
            dirBase = found->second.dir;
            tilesX = found->second.tilesX;
            return Got::Ok;
        }
        const int need = tx * ty;
        if (need <= 0) return Got::Fail;
        if (dirNext + need > kDirW * kDirRows) return Got::Full;
        ui::detail::polysCoverageMask(op, maskScratch);
        const int dir0 = dirNext;
        for (int j = 0; j < ty; ++j) {
            for (int i = 0; i < tx; ++i) {
                const int x0 = i * kTile;
                const int y0 = j * kTile;
                const int tw = std::min(kTile, w - x0);
                const int th = std::min(kTile, h - y0);
                bool any = false;
                bool all = true;
                for (int r = 0; r < th && (!any || all); ++r) {
                    const std::uint8_t* row = maskScratch.data() + static_cast<std::size_t>(y0 + r) * static_cast<std::size_t>(w) + static_cast<std::size_t>(x0);
                    for (int c = 0; c < tw; ++c) {
                        any = any || row[c] != 0U;
                        all = all && row[c] == 255U;
                    }
                }
                float code = 0.0F;
                if (!any) {
                    code = 0.0F;
                } else if (all) {
                    code = 1.0F;
                } else {
                    if (tileNext >= tileCapacity) return Got::Full;
                    const int k = tileNext++;
                    const int col = k & (tilesPerRow - 1);
                    const int tileRow = k >> tprShift;
                    for (int r = 0; r < th; ++r) {
                        std::memcpy(maskMirror.data() + static_cast<std::size_t>(tileRow * kTile + r) * static_cast<std::size_t>(atlasW) + static_cast<std::size_t>(col * kTile),
                                    maskScratch.data() + static_cast<std::size_t>(y0 + r) * static_cast<std::size_t>(w) + static_cast<std::size_t>(x0), static_cast<std::size_t>(tw));
                    }
                    dirtyTileLo = std::min(dirtyTileLo, tileRow);
                    dirtyTileHi = std::max(dirtyTileHi, tileRow);
                    code = static_cast<float>(k + 2);
                }
                dirMirror[static_cast<std::size_t>(dir0 + j * tx + i)] = code;
            }
        }
        dirtyDirLo = std::min(dirtyDirLo, dir0);
        dirtyDirHi = std::max(dirtyDirHi, dir0 + need - 1);
        dirNext += need;
        masks[op.geomHash] = {dir0, tx, w, h, frameNo};
        ++newMasks;
        dirBase = dir0;
        tilesX = tx;
        return Got::Ok;
    }

    // What was written to the CPU copies goes to the textures: one upload for each of them.
    void flushUploads() {
        if (dirtyTileHi >= 0) {
            gl->glActiveTexture(GL_TEXTURE0);
            gl->glBindTexture(GL_TEXTURE_2D, maskTex);
            gl->glTexSubImage2D(GL_TEXTURE_2D, 0, 0, dirtyTileLo * kTile, atlasW, (dirtyTileHi - dirtyTileLo + 1) * kTile, GL_RED, GL_UNSIGNED_BYTE,
                                maskMirror.data() + static_cast<std::size_t>(dirtyTileLo * kTile) * static_cast<std::size_t>(atlasW));
            dirtyTileLo = INT_MAX;
            dirtyTileHi = -1;
        }
        if (dirtyDirHi >= 0) {
            const int rowLo = dirtyDirLo / kDirW;
            const int rowHi = dirtyDirHi / kDirW;
            gl->glActiveTexture(GL_TEXTURE0 + 3U);
            gl->glBindTexture(GL_TEXTURE_2D, dirTex);
            gl->glTexSubImage2D(GL_TEXTURE_2D, 0, 0, rowLo, kDirW, rowHi - rowLo + 1, GL_RED, GL_FLOAT, dirMirror.data() + static_cast<std::size_t>(rowLo) * static_cast<std::size_t>(kDirW));
            dirtyDirLo = INT_MAX;
            dirtyDirHi = -1;
        }
        if (dirtyLutHi >= 0) {
            gl->glActiveTexture(GL_TEXTURE0 + 1U);
            gl->glBindTexture(GL_TEXTURE_2D, lutTex);
            gl->glTexSubImage2D(GL_TEXTURE_2D, 0, 0, dirtyLutLo, 256, dirtyLutHi - dirtyLutLo + 1, GL_RGBA, GL_UNSIGNED_BYTE,
                                lutMirror.data() + static_cast<std::size_t>(dirtyLutLo) * 256U * 4U);
            dirtyLutLo = INT_MAX;
            dirtyLutHi = -1;
        }
    }

    Got lutRowFor(const RasterOp& op, int& row) {
        const std::uint64_t key = gradientKey(*op.shader, op.alpha255);
        const auto found = lutRows.find(key);
        if (found != lutRows.end()) {
            row = found->second;
            return Got::Ok;
        }
        if (lutNext >= kLutRows) return Got::Full;
        std::uint32_t table[256];
        ui::detail::gradientTable(*op.shader, op.alpha255, table);
        std::uint8_t bytes[256 * 4];
        for (int i = 0; i < 256; ++i) {
            const std::uint32_t p = table[i];
            bytes[i * 4 + 0] = static_cast<std::uint8_t>((p >> 16U) & 255U);
            bytes[i * 4 + 1] = static_cast<std::uint8_t>((p >> 8U) & 255U);
            bytes[i * 4 + 2] = static_cast<std::uint8_t>(p & 255U);
            bytes[i * 4 + 3] = static_cast<std::uint8_t>((p >> 24U) & 255U);
        }
        std::memcpy(lutMirror.data() + static_cast<std::size_t>(lutNext) * 256U * 4U, bytes, sizeof bytes);
        dirtyLutLo = std::min(dirtyLutLo, lutNext);
        dirtyLutHi = std::max(dirtyLutHi, lutNext);
        lutRows[key] = lutNext;
        row = lutNext++;
        return Got::Ok;
    }

    GLuint imageTexture(const RasterOp& op) {
        const std::uint64_t key = op.imageHash ^ (static_cast<std::uint64_t>(op.image->width) << 40U);
        for (auto& t : images) {
            if (t.key == key) {
                t.used = frameNo;
                return t.tex;
            }
        }
        const ui::Image& img = *op.image;
        std::vector<std::uint8_t> bytes(img.pixels.size() * 4U);
        for (std::size_t i = 0U; i < img.pixels.size(); ++i) {
            const std::uint32_t p = img.pixels[i];
            bytes[i * 4U + 0U] = static_cast<std::uint8_t>((p >> 16U) & 255U);
            bytes[i * 4U + 1U] = static_cast<std::uint8_t>((p >> 8U) & 255U);
            bytes[i * 4U + 2U] = static_cast<std::uint8_t>(p & 255U);
            bytes[i * 4U + 3U] = static_cast<std::uint8_t>((p >> 24U) & 255U);
        }
        if (static_cast<int>(images.size()) >= kMaxImageTextures) {
            auto oldest = images.begin();
            for (auto it = images.begin(); it != images.end(); ++it) if (it->used < oldest->used) oldest = it;
            gl->glDeleteTextures(1, &oldest->tex);
            images.erase(oldest);
        }
        gl->glActiveTexture(GL_TEXTURE0 + 2U);
        const GLuint tex = makeTexture(GL_LINEAR);
        gl->glTexImage2D(GL_TEXTURE_2D, 0, static_cast<GLint>(GL_RGBA8), img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, bytes.data());
        images.push_back({key, tex, frameNo});
        return tex;
    }

    // ---------------------------------------------------------------- list -> instances
    Build build(const DisplayList& list) {
        instances.clear();
        cmds.clear();
        std::size_t pending = 0U;
        auto flush = [&]() {
            if (instances.size() > pending) {
                Cmd c;
                c.type = Cmd::Type::Draw;
                c.first = static_cast<int>(pending);
                c.count = static_cast<int>(instances.size() - pending);
                cmds.push_back(c);
            }
            pending = instances.size();
        };
        if (list.empty() || list.front().kind != RasterOp::Kind::Clear) {
            Cmd c;
            c.type = Cmd::Type::Clear;
            c.color = 0xFF000000U;
            cmds.push_back(c);
        }
        for (const RasterOp& op : list) {
            if (op.kind == RasterOp::Kind::Clear) {
                flush();
                Cmd c;
                c.type = Cmd::Type::Clear;
                c.color = op.solid;
                cmds.push_back(c);
                continue;
            }
            if (op.areaR <= op.areaL || op.areaB <= op.areaT) continue;
            Instance in{};
            in.area[0] = static_cast<float>(op.areaL);
            in.area[1] = static_cast<float>(op.areaT);
            in.area[2] = static_cast<float>(op.areaR);
            in.area[3] = static_cast<float>(op.areaB);
            if (op.kind == RasterOp::Kind::Image) {
                if (op.image == nullptr || op.image->width <= 0 || op.image->height <= 0 || op.image->pixels.empty()) continue;
                in.param[0] = 2.0F;
                in.geom[0] = op.rx0; in.geom[1] = op.ry0; in.geom[2] = op.rx1; in.geom[3] = op.ry1;
                in.color[3] = static_cast<float>(op.alpha255) / 255.0F;
                flush();
                Cmd c;
                c.type = Cmd::Type::Image;
                c.texture = imageTexture(op);
                c.first = static_cast<int>(instances.size());
                c.count = 1;
                instances.push_back(in);
                cmds.push_back(c);
                pending = instances.size();
                continue;
            }
            // colour source
            if (op.useShader && op.shader != nullptr && !op.shader->colors.empty()) {
                const ui::Shader& s = *op.shader;
                int row = 0;
                const Got got = lutRowFor(op, row);
                if (got == Got::Full) {
                    lutWasFull = true;
                    return Build::Reset;
                }
                in.param[1] = s.kind == ui::Shader::Kind::Linear ? 1.0F : (s.kind == ui::Shader::Kind::Radial ? 2.0F : 3.0F);
                in.param[2] = static_cast<float>(row);
                in.param[3] = s.tile == ui::TileMode::Repeat ? 1.0F : 0.0F;
                const auto& m = op.inverse;
                if (s.kind == ui::Shader::Kind::Linear) {
                    const float dx = s.x1 - s.x0;
                    const float dy = s.y1 - s.y0;
                    const float len2 = dx * dx + dy * dy;
                    if (len2 > 0.0F) {
                        in.xf0[0] = (m.a * dx + m.b * dy) / len2;
                        in.xf0[1] = (m.c * dx + m.d * dy) / len2;
                        in.xf0[2] = ((m.e - s.x0) * dx + (m.f - s.y0) * dy) / len2;
                    }
                } else {
                    in.xf0[0] = m.a; in.xf0[1] = m.b; in.xf0[2] = m.c; in.xf0[3] = m.d;
                    in.xf1[0] = m.e - s.cx;
                    in.xf1[1] = m.f - s.cy;
                    in.xf1[2] = s.radius > 0.0F ? 1.0F / s.radius : 0.0F;
                }
            } else {
                if ((op.solid >> 24U) == 0U) continue;   // fully transparent: nothing to draw
                in.color[0] = byteF(op.solid, 16U);
                in.color[1] = byteF(op.solid, 8U);
                in.color[2] = byteF(op.solid, 0U);
                in.color[3] = byteF(op.solid, 24U);
            }
            if (op.kind == RasterOp::Kind::Rect) {
                in.param[0] = 0.0F;
                in.geom[0] = std::max(op.rx0, static_cast<float>(op.clipL));
                in.geom[1] = std::max(op.ry0, static_cast<float>(op.clipT));
                in.geom[2] = std::min(op.rx1, static_cast<float>(op.clipR));
                in.geom[3] = std::min(op.ry1, static_cast<float>(op.clipB));
            } else {
                if (op.polys.empty()) continue;
                int dirBase = 0, tilesX = 0;
                const Got got = maskFor(op, dirBase, tilesX);
                if (got == Got::Full) {
                    lutWasFull = false;
                    return Build::Reset;
                }
                if (got == Got::Fail) {
                    fail("a shape is larger than the texture");
                    return Build::Fail;
                }
                in.param[0] = 1.0F;
                in.geom[0] = static_cast<float>(dirBase);
                in.geom[1] = static_cast<float>(tilesX);
            }
            instances.push_back(in);
        }
        flush();
        return Build::Ok;
    }

    // ---------------------------------------------------------------- one picture
    bool render(const DisplayList& list, bool present) {
        if (!current) {
            if (gl->eglMakeCurrent(display, surface, surface, context) == 0U) return fail("eglMakeCurrent failed (0x" + hex(gl->eglGetError()) + ")");
            current = true;
        }
        ++frameNo;
        newMasks = 0;
        if (!querySize(width, height)) return fail("cannot read the surface size");
        const auto buildStart = std::chrono::steady_clock::now();
        Build result = build(list);
        for (int attempt = 0; attempt < 2 && result == Build::Reset; ++attempt) {   // no room: make some, start the picture again
            if (attempt == 0) {
                if (lutWasFull) { lutRows.clear(); lutNext = 0; }
                else compact();
            } else {
                resetCaches();   // (compaction was not enough: only what this picture needs is made again)
            }
            newMasks = 0;
            result = build(list);
        }
        if (result == Build::Reset) {
            return fail("one picture needs more than the textures hold (shapes " + std::to_string(masks.size()) + ", tiles " + std::to_string(tileNext) + " of " +
                        std::to_string(tileCapacity) + ", directory " + std::to_string(dirNext) + ", gradient rows " + std::to_string(lutNext) + ")");
        }
        if (result == Build::Fail) return false;
        lastInstances = static_cast<int>(instances.size());
        buildMs = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - buildStart).count();
        flushUploads();

        gl->glUseProgram(program);
        gl->glUniform2f(uSize, static_cast<float>(width), static_cast<float>(height));
        gl->glUniform1f(uHeight, static_cast<float>(height));
        gl->glViewport(0, 0, width, height);
        gl->glActiveTexture(GL_TEXTURE0);
        gl->glBindTexture(GL_TEXTURE_2D, maskTex);
        gl->glActiveTexture(GL_TEXTURE0 + 1U);
        gl->glBindTexture(GL_TEXTURE_2D, lutTex);
        gl->glActiveTexture(GL_TEXTURE0 + 3U);
        gl->glBindTexture(GL_TEXTURE_2D, dirTex);
        gl->glBindVertexArray(vao);
        gl->glBindBuffer(GL_ARRAY_BUFFER, buffer);
        const std::size_t bytes = std::max<std::size_t>(instances.size(), 1U) * sizeof(Instance);
        gl->glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(bytes), instances.data(), GL_STREAM_DRAW);
        bufferBytes = bytes;
        for (const Cmd& c : cmds) {
            if (c.type == Cmd::Type::Clear) {
                gl->glClearColor(byteF(c.color, 16U), byteF(c.color, 8U), byteF(c.color, 0U), byteF(c.color, 24U));
                gl->glClear(GL_COLOR_BUFFER_BIT);
                continue;
            }
            if (c.type == Cmd::Type::Image) {
                gl->glActiveTexture(GL_TEXTURE0 + 2U);
                gl->glBindTexture(GL_TEXTURE_2D, c.texture);
            }
            const auto base = static_cast<std::size_t>(c.first) * sizeof(Instance);
            for (GLuint a = 0U; a < 6U; ++a) {
                gl->glVertexAttribPointer(a, 4, GL_FLOAT, 0U, static_cast<GLsizei>(sizeof(Instance)),
                                          reinterpret_cast<const void*>(base + static_cast<std::size_t>(a) * 4U * sizeof(float)));
            }
            gl->glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, c.count);
        }
        if (present) {
            if (gl->eglSwapBuffers(display, surface) == 0U) return fail("eglSwapBuffers failed (0x" + hex(gl->eglGetError()) + ")");
        }
        return true;
    }

    bool readPixels(std::vector<std::uint32_t>& argb) {
        std::vector<std::uint8_t> raw(static_cast<std::size_t>(width) * static_cast<std::size_t>(height) * 4U);
        gl->glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, raw.data());
        argb.assign(static_cast<std::size_t>(width) * static_cast<std::size_t>(height), 0U);
        for (int y = 0; y < height; ++y) {
            const std::uint8_t* from = raw.data() + static_cast<std::size_t>(height - 1 - y) * static_cast<std::size_t>(width) * 4U;
            std::uint32_t* to = argb.data() + static_cast<std::size_t>(y) * static_cast<std::size_t>(width);
            for (int x = 0; x < width; ++x) {
                to[x] = (static_cast<std::uint32_t>(from[x * 4 + 3]) << 24U) | (static_cast<std::uint32_t>(from[x * 4 + 0]) << 16U) |
                        (static_cast<std::uint32_t>(from[x * 4 + 1]) << 8U) | static_cast<std::uint32_t>(from[x * 4 + 2]);
            }
        }
        return gl->glGetError() == 0U;
    }

    // ---------------------------------------------------------------- the small test drawing made when the renderer is created
    // A plain colour, a rectangle with a half-pixel edge, a shape from the atlas and a gradient: if the video card gives wrong
    // pixels for any of them the renderer is not used (the software renderer keeps drawing).
    bool selfTest() {
        if (width < 100 || height < 100) return true;   // (a window is never this small; nothing to look at)
        DisplayList list;
        auto base = [](RasterOp::Kind kind, int l, int t, int r, int b) {
            RasterOp op;
            op.kind = kind;
            op.clipL = 0; op.clipT = 0; op.clipR = 4096; op.clipB = 4096;
            op.areaL = l; op.areaT = t; op.areaR = r; op.areaB = b;
            return op;
        };
        RasterOp clear = base(RasterOp::Kind::Clear, 0, 0, 0, 0);
        clear.solid = 0xFF204060U;
        list.push_back(clear);
        RasterOp rect = base(RasterOp::Kind::Rect, 10, 10, 31, 30);   // x 10..30.5 (the last column is half covered), y 10..30
        rect.rx0 = 10.0F; rect.ry0 = 10.0F; rect.rx1 = 30.5F; rect.ry1 = 30.0F;
        rect.solid = 0xFFFF0000U;
        list.push_back(rect);
        RasterOp shape = base(RasterOp::Kind::Polys, 40, 10, 60, 30);
        ui::detail::Poly poly;
        poly.xy = {40.0F, 10.0F, 60.0F, 10.0F, 60.0F, 30.0F, 40.0F, 30.0F};
        shape.polys.push_back(poly);
        shape.solid = 0xFF00FF00U;
        shape.geomHash = 0x1234ABCDULL;
        list.push_back(shape);
        RasterOp tri = base(RasterOp::Kind::Polys, 40, 40, 60, 60);   // a corner: its tiles are partly covered (the tile texture is read)
        ui::detail::Poly tp;
        tp.xy = {40.0F, 40.0F, 60.0F, 40.0F, 40.0F, 60.0F};
        tri.polys.push_back(tp);
        tri.solid = 0xFF0000FFU;
        tri.geomHash = 0x5678EF01ULL;
        list.push_back(tri);
        RasterOp grad = base(RasterOp::Kind::Rect, 70, 10, 90, 30);
        grad.rx0 = 70.0F; grad.ry0 = 10.0F; grad.rx1 = 90.0F; grad.ry1 = 30.0F;
        grad.useShader = true;
        grad.shader = ui::linearGradient(70.0F, 0.0F, 90.0F, 0.0F, ui::Color::rgb(0, 0, 0), ui::Color::rgb(255, 255, 255));
        grad.inverse = ui::detail::Matrix{};
        list.push_back(grad);
        if (!render(list, false)) return false;
        std::vector<std::uint32_t> px;
        if (!readPixels(px)) return fail("self-test: cannot read the pixels");
        auto at = [&](int x, int y) { return px[static_cast<std::size_t>(y) * static_cast<std::size_t>(width) + static_cast<std::size_t>(x)]; };
        auto near = [](std::uint32_t got, std::uint32_t want, int tol) {
            for (unsigned s = 0U; s <= 24U; s += 8U) {
                const int d = static_cast<int>((got >> s) & 255U) - static_cast<int>((want >> s) & 255U);
                if (d > tol || d < -tol) return false;
            }
            return true;
        };
        char text[96];
        if (!near(at(5, 5), 0xFF204060U, 1)) { std::snprintf(text, sizeof text, "self-test: background is %08X", at(5, 5)); return fail(text); }
        if (!near(at(20, 20), 0xFFFF0000U, 1)) { std::snprintf(text, sizeof text, "self-test: rectangle is %08X", at(20, 20)); return fail(text); }
        // the half-covered last column: 50 % red over the background (0x20,0x40,0x60) = (0x90,0x20,0x30)
        if (!near(at(30, 20), 0xFF902030U, 3)) { std::snprintf(text, sizeof text, "self-test: rectangle edge is %08X", at(30, 20)); return fail(text); }
        if (!near(at(50, 20), 0xFF00FF00U, 1)) { std::snprintf(text, sizeof text, "self-test: shape is %08X", at(50, 20)); return fail(text); }
        if (!near(at(42, 42), 0xFF0000FFU, 1)) { std::snprintf(text, sizeof text, "self-test: corner shape is %08X", at(42, 42)); return fail(text); }
        if (!near(at(58, 58), 0xFF204060U, 1)) { std::snprintf(text, sizeof text, "self-test: outside the corner shape is %08X", at(58, 58)); return fail(text); }
        if (!near(at(80, 20), 0xFF868686U, 4)) { std::snprintf(text, sizeof text, "self-test: gradient is %08X", at(80, 20)); return fail(text); }
        resetCaches();   // (the test shape's mask was made without a real hash)
        return true;
    }
};

// ============================================================================ public part
GlRenderer::GlRenderer() : impl_(std::make_unique<Impl>()) {}
GlRenderer::~GlRenderer() = default;

std::unique_ptr<GlRenderer> GlRenderer::create(const Options& options, std::string& error) {
    std::unique_ptr<GlRenderer> r(new GlRenderer());
    if (!r->impl_->setUp(options) || !r->impl_->selfTest()) {
        error = r->impl_->error.empty() ? std::string("unknown error") : r->impl_->error;
        return nullptr;
    }
    return r;
}

bool GlRenderer::querySize(int& width, int& height) { return impl_->querySize(width, height); }
bool GlRenderer::render(const ui::detail::DisplayList& list, bool present) { return impl_->render(list, present); }
bool GlRenderer::readPixels(std::vector<std::uint32_t>& argb) { return impl_->readPixels(argb); }
const std::string& GlRenderer::info() const { return impl_->info; }
const std::string& GlRenderer::lastError() const { return impl_->error; }
int GlRenderer::lastInstanceCount() const { return impl_->lastInstances; }
int GlRenderer::lastNewMasks() const { return impl_->newMasks; }
double GlRenderer::lastBuildMs() const { return impl_->buildMs; }
int GlRenderer::tilesInUse() const { return impl_->tileNext; }
int GlRenderer::tileCapacity() const { return impl_->tileCapacity; }

} // namespace silveton::gl
