#pragma once
// SILVETON_GPU_DRAW_V1 - draws the list of raster operations of the screens (ui/Gfx.h, FrameRenderer::record) on the video card.
//
// The picture is the same as the software renderer's; only who works it out changes:
//   * rectangles: the video card works out the edge coverage per pixel (the same formula as rasterRect);
//   * shapes and letters (Polys): the exact coverage bytes of the software renderer are made once, kept in one big texture
//     (an atlas) and reused every picture - so a shape that does not change costs nothing but its quad;
//   * gradients: the 256-colour table of the software renderer, one row of a texture per gradient;
//   * images: bilinear, like the software renderer.
// Everything is drawn in list order with premultiplied "over" blending, in ONE draw call (one instance per operation).
//
// EGL and OpenGL ES 3.0 are loaded with dlopen at run time: no GL headers or libraries are needed to build, and when the
// device has no usable GL, create() just fails and the caller keeps drawing with the software renderer.

#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "silveton/ui/Gfx.h"

namespace silveton::gl {

class GlRenderer {
public:
    struct Options {
        void* nativeWindow{nullptr};                 // ANativeWindow*; nullptr = off-screen surface (the tests)
        int width{0};                                // off-screen size
        int height{0};
        bool surfaceless{false};                     // tests on Linux: Mesa's surfaceless platform (no display needed)
        std::function<void(int)> onNativeVisual;     // called with the window format (EGL_NATIVE_VISUAL_ID) before the surface is made
    };

    // nullptr when anything fails (then `error` says what). Includes a small test drawing that is checked pixel by pixel.
    static std::unique_ptr<GlRenderer> create(const Options& options, std::string& error);
    ~GlRenderer();
    GlRenderer(const GlRenderer&) = delete;
    GlRenderer& operator=(const GlRenderer&) = delete;

    // The size of the drawing surface now (a window can change its size).
    bool querySize(int& width, int& height);
    // Draws the whole list; with `present` the picture is shown (buffer swap). false = it failed (see lastError()).
    bool render(const ui::detail::DisplayList& list, bool present);
    // The pixels of the last render (before the swap), 0xAARRGGBB, first row at the top.
    bool readPixels(std::vector<std::uint32_t>& argb);
    [[nodiscard]] const std::string& info() const;          // GL renderer / version text
    [[nodiscard]] const std::string& lastError() const;
    // for the measurements
    [[nodiscard]] int lastInstanceCount() const;
    [[nodiscard]] int lastNewMasks() const;
    [[nodiscard]] int tilesInUse() const;         // coverage tiles in the atlas (of tileCapacity())
    [[nodiscard]] int tileCapacity() const;
    [[nodiscard]] double lastBuildMs() const;     // CPU time of the last render before the GL calls (instances, new shape tiles)

private:
    GlRenderer();
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton::gl
