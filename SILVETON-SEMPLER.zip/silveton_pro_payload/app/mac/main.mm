// Standalone Intel/High Sierra shell. The instrument and every screen are the shared C++ implementation.
#import <Cocoa/Cocoa.h>
#include "silveton/host/MacAudioOptions.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/Support.h"
#include <algorithm>
#include <memory>
#include <string>

using namespace silveton::ui;
static std::string utf8(NSString* s) { return s && s.UTF8String ? s.UTF8String : ""; }
static NSString* text(const std::string& s) { return [NSString stringWithUTF8String:s.c_str()] ?: @""; }

@interface SamplerPicture : NSView {
    SilvetonSamplerView* screens_;
    std::unique_ptr<FrameRenderer> renderer_;
}
@property(nonatomic) BOOL inputEnabled;
- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens;
- (void)refresh;
- (void)tick;
@end

@implementation SamplerPicture
- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens {
    self = [super initWithFrame:frame];
    if (self) { screens_ = screens; _inputEnabled = YES; }
    return self;
}
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }
- (NSMenu*)menuForEvent:(NSEvent*)event { (void)event; return nil; }
- (NSPoint)picturePoint:(NSEvent*)event {
    const NSPoint p = [self convertPointToBacking:[self convertPoint:event.locationInWindow fromView:nil]];
    return NSMakePoint(p.x, [self convertRectToBacking:self.bounds].size.height - p.y);
}
- (void)refresh {
    if (!self.window || !screens_) return;
    NSSize size = [self convertRectToBacking:self.bounds].size;
    const int w = (int)(size.width + 0.5), h = (int)(size.height + 0.5);
    if (w < 1 || h < 1) return;
    if (!renderer_ || renderer_->width() != w || renderer_->height() != h)
        renderer_ = std::make_unique<FrameRenderer>(w, h);
    auto* screen = screens_;
    for (const auto& r : renderer_->update([screen](Canvas& c) { screen->draw(c); })) {
        NSRect rect = NSMakeRect(r.left, h - r.bottom, r.width(), r.height());
        [self setNeedsDisplayInRect:NSInsetRect([self convertRectFromBacking:rect], -1, -1)];
    }
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    if (!renderer_) [self refresh];
    if (!renderer_) return;
    const Canvas& pixels = renderer_->picture();
    const size_t w = (size_t)renderer_->width(), h = (size_t)renderer_->height();
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGDataProviderRef data = CGDataProviderCreateWithData(nullptr, pixels.pixels(), w * h * 4, nullptr);
    CGImageRef image = CGImageCreate(w, h, 8, 32, w * 4, space,
        (CGBitmapInfo)(kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst), data, nullptr, false, kCGRenderingIntentDefault);
    if (image) {
        CGContextRef context = NSGraphicsContext.currentContext.CGContext;
        CGContextSetInterpolationQuality(context, kCGInterpolationNone);
        CGContextDrawImage(context, NSRectToCGRect(self.bounds), image);
        CGImageRelease(image);
    }
    CGDataProviderRelease(data); CGColorSpaceRelease(space);
}
- (void)setFrameSize:(NSSize)size { [super setFrameSize:size]; if (self.inputEnabled) [self refresh]; }
- (void)tick {
    if (!self.inputEnabled) return;
    const auto now = nowMs();
    screens_->tick(now);
    if (screens_->redrawDue(now)) [self refresh];
}
- (void)mouseDown:(NSEvent*)event {
    if (!self.inputEnabled) return;
    [self.window makeFirstResponder:self];
    NSPoint p = [self picturePoint:event];
    if (event.modifierFlags & NSEventModifierFlagControl) screens_->secondaryClick(p.x, p.y);
    else screens_->pointer(SilvetonSamplerView::PointerAction::Down, p.x, p.y);
    [self refresh];
}
- (void)mouseDragged:(NSEvent*)event {
    if (!self.inputEnabled || (event.modifierFlags & NSEventModifierFlagControl)) return;
    NSPoint p = [self picturePoint:event];
    screens_->pointer(SilvetonSamplerView::PointerAction::Move, p.x, p.y); [self refresh];
}
- (void)mouseUp:(NSEvent*)event {
    if (!self.inputEnabled) return;
    NSPoint p = [self picturePoint:event];
    screens_->pointer((event.modifierFlags & NSEventModifierFlagControl) ?
        SilvetonSamplerView::PointerAction::Cancel : SilvetonSamplerView::PointerAction::Up, p.x, p.y);
    [self refresh];
}
- (void)rightMouseDown:(NSEvent*)event {
    if (!self.inputEnabled) return;
    NSPoint p = [self picturePoint:event]; screens_->secondaryClick(p.x, p.y); [self refresh];
}
- (void)scrollWheel:(NSEvent*)event {
    if (!self.inputEnabled) return;
    NSPoint p = [self picturePoint:event];
    CGFloat dy = event.hasPreciseScrollingDeltas ? -event.scrollingDeltaY * self.window.backingScaleFactor : -event.deltaY * 24.0;
    screens_->wheel(p.x, p.y, dy); [self refresh];
}
- (void)keyDown:(NSEvent*)event {
    if (!self.inputEnabled) return;
    auto key = SilvetonSamplerView::Key::None;
    switch (event.keyCode) {
        case 36: case 76: key = SilvetonSamplerView::Key::Enter; break;
        case 53: key = SilvetonSamplerView::Key::Escape; break;
        case 51: key = SilvetonSamplerView::Key::Backspace; break;
        case 117: key = SilvetonSamplerView::Key::Delete; break;
        case 123: key = SilvetonSamplerView::Key::Left; break;
        case 124: key = SilvetonSamplerView::Key::Right; break;
        case 125: key = SilvetonSamplerView::Key::Down; break;
        case 126: key = SilvetonSamplerView::Key::Up; break;
        case 48: key = SilvetonSamplerView::Key::Tab; break;
        default: break;
    }
    if (key != SilvetonSamplerView::Key::None) screens_->keyDown(key);
    else if (!(event.modifierFlags & (NSEventModifierFlagCommand | NSEventModifierFlagControl))) [self interpretKeyEvents:@[event]];
    [self refresh];
}
- (void)insertText:(id)value {
    if (!self.inputEnabled) return;
    screens_->typeText(utf8([value isKindOfClass:NSAttributedString.class] ? [value string] : value)); [self refresh];
}
- (void)doCommandBySelector:(SEL)selector { (void)selector; }
@end

@interface SamplerDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate, NSMenuItemValidation> {
    NSWindow* window_;
    SamplerPicture* picture_;
    std::unique_ptr<SamplerAppController> controller_;
    std::unique_ptr<SilvetonSamplerView> screens_;
    dispatch_queue_t lifecycle_;
    NSTimer* timer_;
    id activity_;
    BOOL busy_, closing_, pollPending_;
    NSString* lastStatus_;
    NSInteger midiCount_, frames_, rate_;
    std::int64_t lastPoll_;
}
- (void)chooseSoloModelForUpper:(int)upper sound:(int)sound;
@end

@implementation SamplerDelegate
- (void)addItem:(NSMenu*)menu title:(NSString*)title action:(SEL)action key:(NSString*)key tag:(NSInteger)tag {
    NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:title action:action keyEquivalent:key];
    item.target = self; item.tag = tag; [menu addItem:item];
}
- (void)makeMenus {
    NSMenu* bar = [[NSMenu alloc] initWithTitle:@""];
    NSMenuItem* appItem = [[NSMenuItem alloc] initWithTitle:@"SILVETON" action:nil keyEquivalent:@""];
    NSMenu* app = [[NSMenu alloc] initWithTitle:@"SILVETON"];
    NSMenuItem* quit = [[NSMenuItem alloc] initWithTitle:@"Изход от SILVETON" action:@selector(terminate:) keyEquivalent:@"q"];
    [app addItem:quit]; appItem.submenu = app; [bar addItem:appItem];
    NSMenuItem* fileItem = [[NSMenuItem alloc] initWithTitle:@"Файл" action:nil keyEquivalent:@""];
    NSMenu* file = [[NSMenu alloc] initWithTitle:@"Файл"];
    [self addItem:file title:@"Отвори банка…" action:@selector(openBank:) key:@"o" tag:0];
    [self addItem:file title:@"Зареди обучен SOLO модел…" action:@selector(openSoloModel:) key:@"m" tag:0];
    [file addItem:NSMenuItem.separatorItem];
    [self addItem:file title:@"Папка за звуци" action:@selector(openData:) key:@"" tag:0];
    fileItem.submenu = file; [bar addItem:fileItem];
    NSMenuItem* audioItem = [[NSMenuItem alloc] initWithTitle:@"Аудио" action:nil keyEquivalent:@""];
    NSMenu* audio = [[NSMenu alloc] initWithTitle:@"Аудио"];
    [self addItem:audio title:@"Аудио и MIDI информация" action:@selector(showInfo:) key:@"i" tag:0];
    [self addItem:audio title:@"Спри всички ноти (Panic)" action:@selector(panic:) key:@"." tag:0];
    [self addItem:audio title:@"Проба на текущата бленда — C4" action:@selector(audition:) key:@"" tag:0];
    [self addItem:audio title:@"Рестартирай аудиото" action:@selector(restartAudio:) key:@"" tag:0];
    [audio addItem:NSMenuItem.separatorItem];
    for (NSNumber* n in @[@128, @256, @512]) [self addItem:audio title:[NSString stringWithFormat:@"Буфер %@ кадъра", n]
        action:@selector(changeFrames:) key:@"" tag:n.integerValue];
    [audio addItem:NSMenuItem.separatorItem];
    for (NSNumber* n in @[@48000, @96000]) [self addItem:audio title:[NSString stringWithFormat:@"Честота %ld kHz", (long)n.integerValue / 1000]
        action:@selector(changeRate:) key:@"" tag:n.integerValue];
    audioItem.submenu = audio; [bar addItem:audioItem]; NSApp.mainMenu = bar;
}
- (NSString*)soundFolder {
    return [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject]
        stringByAppendingPathComponent:@"SILVETON"];
}
- (void)applicationDidFinishLaunching:(NSNotification*)note {
    (void)note;
    [self makeMenus]; busy_ = YES;
    frames_ = [NSUserDefaults.standardUserDefaults integerForKey:@"AudioFrames"];
    if (frames_ != 128 && frames_ != 256 && frames_ != 512) frames_ = 256;
    rate_ = [NSUserDefaults.standardUserDefaults integerForKey:@"AudioRate"];
    if (rate_ != 48000 && rate_ != 96000) rate_ = 48000;
    silveton::host::setMacAudioPreferences(rate_, (std::uint32_t)frames_);
    window_ = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 1340, 800)
        styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable)
        backing:NSBackingStoreBuffered defer:NO];
    window_.releasedWhenClosed = NO; window_.delegate = self;
    window_.title = @"SILVETON SAMPLER — стартиране…";
    window_.contentMinSize = NSMakeSize(1005, 600);
    [window_ center]; [window_ makeKeyAndOrderFront:nil]; [NSApp activateIgnoringOtherApps:YES];
    NSString* support = [[NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject]
        stringByAppendingPathComponent:@"SILVETON SAMPLER"];
    NSError* error = nil;
    if (![NSFileManager.defaultManager createDirectoryAtPath:support withIntermediateDirectories:YES attributes:nil error:&error]) {
        [self alert:error.localizedDescription]; [NSApp terminate:nil]; return;
    }
    [NSFileManager.defaultManager createDirectoryAtPath:[self soundFolder] withIntermediateDirectories:YES attributes:nil error:nil];
    setFontDirectory(utf8([NSBundle.mainBundle.resourcePath stringByAppendingPathComponent:@"fonts"]));
    ControllerEnv env; env.dataDir = utf8(support);
    for (NSString* dir in @[[self soundFolder], [NSHomeDirectory() stringByAppendingPathComponent:@"SILVETON"],
        [NSHomeDirectory() stringByAppendingPathComponent:@"Downloads"], [NSHomeDirectory() stringByAppendingPathComponent:@"Desktop"]])
        env.bankCandidates.push_back(utf8([dir stringByAppendingPathComponent:@"SILVETON_BANK.sv"]));
    __weak SamplerDelegate* weak = self;
    env.chooseSoloModel = [weak](int upper, int sound) {
        dispatch_async(dispatch_get_main_queue(), ^{ [weak chooseSoloModelForUpper:upper sound:sound]; });
    };
    env.statusChanged = [weak](const std::string& value) {
        NSString* s = text(value);
        dispatch_async(dispatch_get_main_queue(), ^{ [weak status:s]; });
    };
    env.midiConnectionChanged = [weak](int count) {
        dispatch_async(dispatch_get_main_queue(), ^{ [weak midi:count]; });
    };
    controller_ = std::make_unique<SamplerAppController>(env);
    lifecycle_ = dispatch_queue_create("com.silveton.sampler.lifecycle", DISPATCH_QUEUE_SERIAL);
    activity_ = [NSProcessInfo.processInfo beginActivityWithOptions:(NSActivityUserInitiatedAllowingIdleSystemSleep | NSActivityLatencyCritical)
        reason:@"SILVETON audio and MIDI"];
    auto* controller = controller_.get();
    dispatch_async(lifecycle_, ^{
        controller->start(); controller->waitForBankLoad();
        dispatch_async(dispatch_get_main_queue(), ^{ [weak finishStartup]; });
    });
}
- (void)finishStartup {
    if (closing_) return;
    screens_ = std::make_unique<SilvetonSamplerView>(*controller_);
    screens_->setSoftKeyboard(false); screens_->setMidiConnections((int)midiCount_);
    screens_->setWarning(utf8(lastStatus_));
    picture_ = [[SamplerPicture alloc] initWithFrame:window_.contentView.bounds screens:screens_.get()];
    picture_.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    window_.contentView = picture_; [window_ makeFirstResponder:picture_];
    window_.title = @"SILVETON SAMPLER"; busy_ = NO;
    timer_ = [NSTimer timerWithTimeInterval:1.0 / 30.0 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
    [NSRunLoop.mainRunLoop addTimer:timer_ forMode:NSRunLoopCommonModes]; [picture_ refresh];
}
- (void)status:(NSString*)value { if (!closing_) { lastStatus_ = value; if (screens_) screens_->setWarning(utf8(value)); } }
- (void)midi:(int)count { if (!closing_) { midiCount_ = count; if (screens_) screens_->setMidiConnections(count); } }
- (void)tick:(NSTimer*)timer {
    (void)timer;
    if (closing_ || busy_) return;
    [picture_ tick];
    if (!pollPending_ && nowMs() - lastPoll_ >= 250) {
        pollPending_ = YES; lastPoll_ = nowMs();
        auto* c = controller_.get(); __weak SamplerDelegate* weak = self;
        dispatch_async(lifecycle_, ^{
            c->housekeeping();
            dispatch_async(dispatch_get_main_queue(), ^{ [weak pollFinished]; });
        });
    }
}
- (void)pollFinished { pollPending_ = NO; }
- (void)alert:(NSString*)message {
    NSAlert* a = [[NSAlert alloc] init]; a.messageText = @"SILVETON SAMPLER";
    a.informativeText = message ?: @""; [a runModal];
}
- (void)runWork:(NSString* (^)(void))work {
    if (busy_ || closing_) return;
    busy_ = YES; picture_.inputEnabled = NO;
    window_.title = @"SILVETON SAMPLER — зареждане…";
    auto* c = controller_.get(); __weak SamplerDelegate* weak = self;
    dispatch_async(lifecycle_, ^{
        c->waitForBankLoad();
        NSString* error = work();
        dispatch_async(dispatch_get_main_queue(), ^{ [weak workFinished:error]; });
    });
}
- (void)workFinished:(NSString*)error {
    if (closing_) return;
    busy_ = NO; picture_.inputEnabled = YES; window_.title = @"SILVETON SAMPLER";
    if (screens_) screens_->globalChangedOutside(); [picture_ refresh];
    if (error.length) [self alert:error];
}
- (NSString*)chooseFile:(NSString*)title {
    NSOpenPanel* p = [NSOpenPanel openPanel]; p.title = title;
    p.canChooseDirectories = NO; p.allowsMultipleSelection = NO; p.allowedFileTypes = @[@"sv"];
    return [p runModal] == NSModalResponseOK ? p.URL.path : nil;
}
- (void)openSoloModel:(id)sender {
    (void)sender;if(screens_)[self chooseSoloModelForUpper:screens_->selectedSoloPart() sound:screens_->selectedSoloSound()];
}
- (void)chooseSoloModelForUpper:(int)upper sound:(int)sound {
    if(busy_||closing_||upper<0||upper>=7||sound<0||sound>4)return;
    NSOpenPanel* p=[NSOpenPanel openPanel];
    p.title=[NSString stringWithFormat:@"Зареди обучен звук · %@ · %@",upper==6?@"LOWER":[NSString stringWithFormat:@"UPPER %d",upper+1],sound==0?@"MAIN":[NSString stringWithFormat:@"L%d",sound]];
    p.allowedFileTypes=@[@"svsolo"];p.allowsMultipleSelection=NO;p.canChooseDirectories=NO;
    if([p runModal]!=NSModalResponseOK)return;
    const std::string path=utf8(p.URL.path);auto*c=controller_.get();__weak SamplerDelegate* weak=self;
    [self runWork:^NSString*{
        const auto error=c->loadSoloModelFile(upper,path,sound);
        if(!error)dispatch_async(dispatch_get_main_queue(), ^{
            SamplerDelegate* strong=weak;if(strong&&!strong->closing_&&strong->screens_)strong->screens_->showSoloPart(upper,sound);
        });
        return error?text(*error):nil;
    }];
}
- (void)openBank:(id)sender {
    (void)sender; NSString* file = [self chooseFile:@"Отвори SILVETON_BANK.sv"];
    if (!file) return;
    auto* c = controller_.get(); const std::string path = utf8(file);
    [self runWork:^NSString* { return c->useBankFile(path) ? nil : text(c->bankLoadError()); }];
}


- (void)openData:(id)sender { (void)sender; [NSWorkspace.sharedWorkspace openURL:[NSURL fileURLWithPath:[self soundFolder]]]; }
- (void)panic:(id)sender { (void)sender; if (controller_) controller_->panic(); }
- (void)audition:(id)sender {
    (void)sender; controller_->engine.nativeMidi(0x90, 60, 90);
    __weak SamplerDelegate* weak = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 750 * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{ [weak endAudition]; });
}
- (void)endAudition { if (!closing_ && controller_) controller_->engine.nativeMidi(0x80, 60, 0); }
- (void)restartAudio:(id)sender {
    (void)sender; auto* c = controller_.get();
    [self runWork:^NSString* {
        c->panic();
        const bool ok = c->engine.nativeAudioRecover() && c->resumeAudio();
        return ok ? nil : text(c->engine.nativeLastTextError());
    }];
}
- (void)changeFrames:(NSMenuItem*)item {
    frames_ = item.tag; [NSUserDefaults.standardUserDefaults setInteger:frames_ forKey:@"AudioFrames"];
    silveton::host::setMacAudioPreferences(rate_, (std::uint32_t)frames_); [self restartAudio:nil];
}
- (void)changeRate:(NSMenuItem*)item {
    rate_ = item.tag; [NSUserDefaults.standardUserDefaults setInteger:rate_ forKey:@"AudioRate"];
    silveton::host::setMacAudioPreferences(rate_, (std::uint32_t)frames_); [self restartAudio:nil];
}
- (void)showInfo:(id)sender {
    (void)sender; const auto a = controller_->audioStatus();
    std::string devices;
    for (const auto& n : controller_->engine.midiSourceNames()) devices += n + "\n";
    NSString* latency = a.estimatedLatencyMs >= 0 ? [NSString stringWithFormat:@"%.2f ms (драйверна оценка)", a.estimatedLatencyMs] : @"неизвестна";
    [self alert:[NSString stringWithFormat:@"Изход: %@\nАудио: %@\nРеална честота: %d Hz\nРеален блок: %d кадъра\nИзходна латентност: %@\nПретоварвания: %d\n\nMIDI входове:\n%@\n\nИзходното устройство се избира от macOS → Sound или Audio MIDI Setup.",
        text(controller_->engine.audioDeviceName()), controller_->audioRunning() ? @"работи" : @"спряно", a.sampleRate,
        a.framesPerBurst, latency, a.xrunCount, text(devices)]];
}
- (BOOL)validateMenuItem:(NSMenuItem*)item {
    if (item.action == @selector(changeFrames:)) item.state = item.tag == frames_ ? NSControlStateValueOn : NSControlStateValueOff;
    if (item.action == @selector(changeRate:)) item.state = item.tag == rate_ ? NSControlStateValueOn : NSControlStateValueOff;
    return !busy_ && !closing_;
}
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)app { (void)app; return YES; }
- (BOOL)windowShouldClose:(NSWindow*)window { (void)window; [NSApp terminate:nil]; return NO; }
- (void)applicationWillTerminate:(NSNotification*)note {
    (void)note; closing_ = YES; [timer_ invalidate]; timer_ = nil; picture_.inputEnabled = NO;
    // Drain startup/file/recovery tasks before destroying the controller. Audio stays independent of the window focus.
    if (lifecycle_) dispatch_sync(lifecycle_, ^{ if (controller_) controller_->close(); });
    window_.contentView = nil; picture_ = nil; screens_.reset(); controller_.reset();
    if (activity_) [NSProcessInfo.processInfo endActivity:activity_]; activity_ = nil;
}
@end

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    @autoreleasepool {
        [NSApplication sharedApplication]; [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        __attribute__((objc_precise_lifetime)) SamplerDelegate* delegate = [[SamplerDelegate alloc] init];
        NSApp.delegate = delegate; [NSApp run];
    }
    return 0;
}
