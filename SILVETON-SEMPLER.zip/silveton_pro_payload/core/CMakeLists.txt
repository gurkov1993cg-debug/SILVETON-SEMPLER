cmake_minimum_required(VERSION 3.16)
project(SilvetonLiveMidiCore LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(SILVETON_LIVE_BUILD_TESTS "Build core tests" OFF)
option(SILVETON_LIVE_ENABLE_SANITIZERS "Enable ASan and UBSan" OFF)
option(SILVETON_WERROR "Treat compiler warnings as errors" OFF)
set(SILVETON_WERROR_FLAG "$<$<BOOL:${SILVETON_WERROR}>:-Werror>")

add_library(silveton_live_core STATIC
    src/Portamento.cpp
    src/PitchCoordinator.cpp
    src/ThirdModule.cpp
    src/Ribbon.cpp
    src/MidiRouter.cpp
    src/sampler/SincInterpolator.cpp
    src/sampler/SampleStream.cpp
    src/sampler/SampleStreamPrefetcher.cpp
    src/sampler/SvBankFormat.cpp
    src/sampler/SvBankRuntime.cpp
    src/sampler/SampleEditor.cpp
    src/sampler/AudioFileLoader.cpp
    src/sampler/SamplerEngine.cpp
    src/sampler/EngineDefs.cpp
    
    src/sampler/SoloDefs.cpp
    src/sampler/SoloVoice.cpp 
    src/sampler/ModelBank.cpp
    
    
    src/sampler/KorgImporter.cpp
    src/sampler/SetPackage.cpp
    src/sampler/WaveTable.cpp
    src/sampler/UserWaves.cpp
    src/sampler/SamplerLibrary.cpp
    src/sampler/ProgramEditor.cpp
    src/sampler/MultisampleEditor.cpp
    src/sampler/SampleRecorder.cpp
)
set_target_properties(silveton_live_core PROPERTIES POSITION_INDEPENDENT_CODE ON)
target_include_directories(silveton_live_core PUBLIC include)
target_include_directories(silveton_live_core PRIVATE src/sampler)


if(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
 target_compile_options(silveton_live_core PRIVATE -Wall -Wextra -Wpedantic -Wconversion -Wshadow ${SILVETON_WERROR_FLAG})
endif()
if(SILVETON_LIVE_ENABLE_SANITIZERS AND CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
 target_compile_options(silveton_live_core PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)
 target_link_options(silveton_live_core PUBLIC -fsanitize=address,undefined)
endif()
add_library(silveton_test_models STATIC EXCLUDE_FROM_ALL tests/fixtures/ModelFixtures.cpp)
target_link_libraries(silveton_test_models PUBLIC silveton_live_core)
target_include_directories(silveton_test_models PUBLIC tests/fixtures)
if(NOT ANDROID)
 add_executable(silveton_personal_solo_render EXCLUDE_FROM_ALL tools/PersonalSoloRender.cpp)
 target_link_libraries(silveton_personal_solo_render PRIVATE silveton_live_core)
endif()
if(SILVETON_LIVE_BUILD_TESTS)
 add_executable(silveton_solo_model_tests tests/SoloModelTests.cpp)
 target_link_libraries(silveton_solo_model_tests PRIVATE silveton_live_core)
 target_include_directories(silveton_solo_model_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_model_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_model_tests COMMAND silveton_solo_model_tests)
 enable_testing()
 add_executable(silveton_solo_tuning_tests tests/SoloTuningTests.cpp)
 target_link_libraries(silveton_solo_tuning_tests PRIVATE silveton_live_core)
 target_include_directories(silveton_solo_tuning_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_tuning_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_tuning_tests COMMAND silveton_solo_tuning_tests)
 add_executable(silveton_pitch_mapping_tests tests/PitchMappingTests.cpp)
 target_link_libraries(silveton_pitch_mapping_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_pitch_mapping_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_pitch_mapping_tests COMMAND silveton_pitch_mapping_tests)
 add_executable(silveton_combi_independent_tests tests/CombiIndependentSmoke.cpp)
 target_link_libraries(silveton_combi_independent_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_combi_independent_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_combi_independent_tests COMMAND silveton_combi_independent_tests)
 add_executable(silveton_velocity_shape_tests tests/VelocityShapeSmoke.cpp)
 target_link_libraries(silveton_velocity_shape_tests PRIVATE silveton_live_core)
 target_compile_options(silveton_velocity_shape_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_velocity_shape_tests COMMAND silveton_velocity_shape_tests)
 add_executable(silveton_solo_source_tests tests/SoloSourceTests.cpp)
 target_link_libraries(silveton_solo_source_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_solo_source_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_source_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_source_tests COMMAND silveton_solo_source_tests)
 add_executable(silveton_solo_bend_transitions_tests tests/SoloBendTransitionsTests.cpp)
 target_link_libraries(silveton_solo_bend_transitions_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_solo_bend_transitions_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_bend_transitions_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_bend_transitions_tests COMMAND silveton_solo_bend_transitions_tests)
 add_executable(silveton_solo_compatibility_tests tests/SoloCompatibilityTests.cpp)
 target_link_libraries(silveton_solo_compatibility_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_solo_compatibility_tests PRIVATE src/sampler)
 target_compile_options(silveton_solo_compatibility_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_solo_compatibility_tests COMMAND silveton_solo_compatibility_tests)
 add_executable(silveton_core_audio_fix_tests tests/CoreAudioFixTests.cpp)
 target_link_libraries(silveton_core_audio_fix_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_core_audio_fix_tests PRIVATE src/sampler)
 target_compile_options(silveton_core_audio_fix_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_core_audio_fix_tests COMMAND silveton_core_audio_fix_tests)
 add_executable(silveton_realtime_safety_tests tests/RealtimeSafetyTests.cpp)
 target_link_libraries(silveton_realtime_safety_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_realtime_safety_tests PRIVATE src/sampler)
 target_compile_options(silveton_realtime_safety_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_realtime_safety_tests COMMAND silveton_realtime_safety_tests)
 add_executable(silveton_portamento_regression_tests tests/PortamentoRegressionTests.cpp)
 target_link_libraries(silveton_portamento_regression_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_portamento_regression_tests PRIVATE src/sampler)
 target_compile_options(silveton_portamento_regression_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_portamento_regression_tests COMMAND silveton_portamento_regression_tests)
 add_executable(silveton_live_core_tests tests/CoreTests.cpp)
 target_link_libraries(silveton_live_core_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_live_core_tests PRIVATE src/sampler)
 target_compile_options(silveton_live_core_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_live_core_tests COMMAND silveton_live_core_tests)
 add_executable(silveton_live_fuzz_tests tests/FuzzTests.cpp)
 target_link_libraries(silveton_live_fuzz_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_live_fuzz_tests PRIVATE src/sampler)
 target_compile_options(silveton_live_fuzz_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_live_fuzz_tests COMMAND silveton_live_fuzz_tests)
 add_executable(silveton_sampler_tests tests/SamplerTests.cpp)
 target_link_libraries(silveton_sampler_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_sampler_tests PRIVATE src/sampler)
 target_compile_options(silveton_sampler_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_sampler_tests COMMAND silveton_sampler_tests)
 add_executable(silveton_fsx_tests tests/FsCompatTests.cpp)
 target_link_libraries(silveton_fsx_tests PRIVATE silveton_live_core silveton_test_models)
 target_include_directories(silveton_fsx_tests PRIVATE src/sampler)
 target_compile_options(silveton_fsx_tests PRIVATE -UNDEBUG)
 add_test(NAME silveton_fsx_tests COMMAND silveton_fsx_tests)
endif()
