#pragma once
#include <algorithm>
#include <cstdint>

namespace silveton {

// RIBBON — performance ribbon.
//
//  * ABSOLUTE: the finger position on the strip IS the pitch offset
//    (centre = 0, ends = +/-RANGE), with a small centre dead zone.
//  * RETURN: after lifting the finger it springs back to 0 with its own
//    return time.
//  * Curve (sensitivity) changes only the feel, never the end range.
//  * Movement is smoothed with a critically damped follow (no overshoot).
// The module only produces a smoothed semitone value; the router sends it on
// the Pitch Bend lane.
class Ribbon {
public:
    enum class Output : int { PitchBend = 0 };   // the ribbon always rides Pitch Bend

    struct Settings {
        Output output{Output::PitchBend};
        int rangeSemitones{2};      // 1..24
        double sensitivity{1.0};    // 0.25..2.0 response curve (end range unchanged)
        int smoothMs{36};           // finger-follow settle time, 0..200
        int returnMs{60};           // spring-back settle time, 0..2000
    };

    struct Update {
        bool valid{false};
        double semitones{0.0};
    };

    const Settings& settings() const { return s_; }
    void setSettings(const Settings& settings);

    void setSensitivity(double sensitivity) { s_.sensitivity = std::clamp(sensitivity, 0.25, 2.0); }
    double sensitivity() const { return s_.sensitivity; }
    void setRangeSemitones(int semitones) { s_.rangeSemitones = std::clamp(semitones, 1, 24); }
    int rangeSemitones() const { return s_.rangeSemitones; }

    // Touch interface. position: -1 (left end) .. +1 (right end) of the strip.
    void touchDown(double position, std::int64_t nowUs);
    void touchMove(double position, std::int64_t nowUs);
    void touchUp(std::int64_t nowUs);
    bool touching() const { return touching_; }

    // Single-value form: a position of exactly 0 is treated as release.
    void setTarget(double normalizedPosition, std::int64_t nowUs);

    Update advance(std::int64_t nowUs);
    void reset();

    double targetSemitoneOffset() const { return target_; }
    double currentSemitoneOffset() const { return output_; }
    bool active() const { return target_ != 0.0 || output_ != 0.0 || touching_; }

private:
    double shape(double x) const;                 // curve for a -1..1 value
    double absoluteTarget(double position) const;

    Settings s_{};
    bool touching_{false};
    double target_{0.0};       // requested semitones (before smoothing)
    double value_{0.0};        // smoothed semitones
    double velocity_{0.0};
    double output_{0.0};
    std::int64_t lastUs_{0};
};

} // namespace silveton
