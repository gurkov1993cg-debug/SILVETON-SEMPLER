#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <memory>
#include <string>

namespace silveton::sampler {

struct AudioLoadResult {
    SamplePtr sample;
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return sample != nullptr && error.empty(); }
};

class AudioFileLoader {
public:
    [[nodiscard]] static AudioLoadResult load(const std::string& path);
    [[nodiscard]] static AudioLoadResult loadStreaming(const std::string& path, std::uint64_t preloadFrames = 96000U);
    [[nodiscard]] static AudioLoadResult loadWav(const std::string& path);
    [[nodiscard]] static AudioLoadResult loadAiff(const std::string& path);
    [[nodiscard]] static AudioLoadResult loadWavStreaming(const std::string& path, std::uint64_t preloadFrames = 96000U);
    [[nodiscard]] static AudioLoadResult loadAiffStreaming(const std::string& path, std::uint64_t preloadFrames = 96000U);
};

} // namespace silveton::sampler
