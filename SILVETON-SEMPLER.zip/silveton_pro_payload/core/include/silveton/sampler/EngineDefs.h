#pragma once
// SILVETON_ENGINES_V1 - the nine sound engines of the sampler, in the spirit of the Korg Kronos engines, built on
// the sampler's own recordings (no separate synth without samples). One ENGINE per Upper; it works on every voice of
// the Upper (ОСНОВЕН + L1..L4) like a real synthesizer (per note), and a small per-Upper stage after the sum (Leslie,
// ensemble, tremolo, cabinet, string resonance).
//
// This header is shared by the sound core (what the knobs do), the host (one id, one value) and the screens (labels,
// ranges, pages). The ids never change once released: a blend saved with them keeps its sound.
//
// Our own models of the original instruments - nothing of Korg's code is in here.

#include <array>
#include <cstdint>

namespace silveton::sampler {

enum class EngineType : std::uint8_t { Off, HD1, Polysix, MS20, AL1, Mod7, Str1, CX3, SGX, EP };
constexpr int kEngineTypeCount = 10;
constexpr int kEngineParamCount = 48;

// ---- the ids. 0..23 are the same in every engine (the ФИЛТЪР and МОД pages), 24.. belong to the engine (its ЗВУК page).
enum EngineId : int {
    E_FILT_TYPE = 0,   // 0 OFF, 1 LP24 (4-pole ladder: Polysix / SSM family), 2 KORG35 (MS-20), 3 LP12, 4 HP12, 5 BP12
    E_CUTOFF = 1,      // Hz
    E_RESO = 2,        // 0..1
    E_KEYTRACK = 3,    // -1..1 (1 = the cutoff follows the key fully)
    E_FEG_AMT = 4,     // octaves, bipolar: the filter envelope
    E_FEG_A = 5, E_FEG_D = 6, E_FEG_S = 7, E_FEG_R = 8,   // ms, ms, 0..1, ms
    E_VEL_CUT = 9,     // octaves the cutoff rises with velocity
    E_DRIVE = 10,      // 0..1 soft saturation before the filter
    E_F2_TYPE = 11,    // 0 OFF 1 LP 2 HP 3 BP 4 BR (12 dB)
    E_F2_CUT = 12, E_F2_RES = 13, E_F2_PAR = 14,   // Hz, 0..1, 0 = after filter 1 / 1 = beside it
    E_LFO_RATE = 15, E_LFO_PITCH = 16, E_LFO_CUT = 17, E_LFO_AMP = 18, E_LFO_WAVE = 19,   // Hz, cents, oct, 0..1, 0 sine 1 tri 2 saw 3 square 4 S&H
    E_UNISON = 20, E_UNI_DET = 21, E_UNI_SPREAD = 22,   // 1..4 voices, cents, 0..1
    E_ANALOG = 23,     // 0..1 small random differences per note
    E_X0 = 24          // the first id of the engine's own page
};

// POLYSIX
enum : int { P6_PWM_WIDTH = 24, P6_PWM_DEPTH, P6_PWM_RATE, P6_SUB_LEVEL, P6_SUB_OCT, P6_FX_TYPE, P6_FX_SPEED, P6_FX_DEPTH, P6_FX_MIX };
// MS-20
enum : int { MS_HPF_CUT = 24, MS_HPF_PEAK, MS_EG1_DELAY, MS_EG1_ATTACK, MS_EG1_RELEASE, MS_EG1_PITCH, MS_EG1_HPF, MS_MG_HPF, MS_WHEEL_TO, MS_WHEEL_AMT };
// AL-1
enum : int { AL_FM_AMT = 24, AL_FM_RATIO, AL_RING_LEVEL, AL_RING_RATIO, AL_SYNC, AL_SYNC_RATIO, AL_SUB_LEVEL, AL_SUB_OCT, AL_NOISE_LEVEL, AL_NOISE_COLOR, AL_FM_EG, AL_SHAPE };
// MOD-7
enum : int { M7_OP2_RATIO = 24, M7_OP2_LEVEL, M7_OP3_RATIO, M7_OP3_LEVEL, M7_OP3_TARGET, M7_FEEDBACK, M7_FM_EG, M7_FM_VEL, M7_WS_TYPE, M7_WS_DRIVE, M7_WS_MIX, M7_BRIGHT, M7_RING };
// STR-1
enum : int { ST_STRING = 24, ST_EXCITE, ST_DECAY, ST_DAMP, ST_DISP, ST_PICK, ST_PICKUP, ST_EXC_LEN, ST_FEEDBACK, ST_NONLIN, ST_TUNE, ST_KEY_DECAY };
// CX-3
enum : int { CX_DB16 = 24, CX_DB513, CX_DB8, CX_DB4, CX_DB223, CX_DB2, CX_DB135, CX_DB113, CX_DB1,
             CX_PERC = 33, CX_PERC_DECAY, CX_PERC_LEVEL, CX_CLICK, CX_LEAK, CX_VIBCHO, CX_ROTARY, CX_SLOW, CX_FAST, CX_HORN, CX_AMP_DRIVE, CX_SAMPLE, CX_WHEEL_ROT };
// SGX
enum : int { SG_STRING_RES = 24, SG_DAMPER_RES, SG_UNA_CORDA, SG_KEYOFF, SG_KEYOFF_TONE, SG_HAMMER, SG_LID, SG_VEL_BRIGHT, SG_RES_RELEASE, SG_WIDTH };
// EP
enum : int { EP_TYPE = 24, EP_BELL, EP_BARK, EP_PRE_DRIVE, EP_BASS, EP_TREBLE, EP_TREM, EP_TREM_SPEED, EP_TREM_DEPTH, EP_TREM_STEREO, EP_CAB, EP_CAB_DRIVE, EP_KEYOFF };
// HD-1
enum : int { HD_BOOST = 24, HD_PEG_CENTS, HD_PEG_TIME };

struct EngineParams {
    EngineType type{EngineType::Off};
    std::array<float, kEngineParamCount> p{};
    [[nodiscard]] bool on() const noexcept { return type != EngineType::Off; }
};

// ---- what the screens need: one line per knob / key of a page
enum class EngineKind : std::uint8_t {
    Lin,      // plain number, shown with `decimals`
    Pct,      // 0..1 shown as %
    Hz,       // logarithmic Hz
    Ms,       // logarithmic ms (lo may be 0 = OFF)
    Sec,      // logarithmic seconds
    Oct,      // octaves, bipolar
    Cents,    // cents, bipolar when lo < 0
    Semis,    // semitones, bipolar
    Db,       // dB, bipolar
    Choice,   // a key that cycles through `names`
    Switch,   // ON / OFF key
    Drawbar   // CX-3 drawbar 0..8 (drawn as a slider)
};

struct EngineParamDef {
    int id;
    const char* label;        // on the knob
    const char* hint;         // one short line (Bulgarian), shown in the number window
    EngineKind kind;
    float lo, hi, def, step;
    int decimals;
    const char* names;        // Choice: names separated by '|'
};

// The three pages of the ENGINE tab: 0 ЗВУК (the engine's own), 1 ФИЛТЪР, 2 МОД.
struct EngineParamPage {
    const EngineParamDef* items;
    int count;
};

[[nodiscard]] const char* engineName(EngineType t) noexcept;
[[nodiscard]] const char* engineLine(EngineType t) noexcept;      // one line about the engine (Bulgarian)
[[nodiscard]] EngineParamPage enginePage(EngineType t, int page) noexcept;
[[nodiscard]] const EngineParamDef* engineParamDef(EngineType t, int id) noexcept;   // nullptr = the id is not used by this engine
[[nodiscard]] EngineParams engineDefaults(EngineType t) noexcept;
// Clamps one value into the range of its definition (unknown ids: just finite).
[[nodiscard]] float engineClamp(EngineType t, int id, float v) noexcept;

} // namespace silveton::sampler
