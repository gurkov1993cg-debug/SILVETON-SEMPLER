#pragma once
// Only SOLO is executable. Retired numeric IDs remain unassigned so old sets
// cannot accidentally select a different algorithm.
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace silveton::sampler {
enum class EngineType : std::uint8_t { Off=0, Solo=13 };
constexpr int kEngineTypeCount=14;
constexpr int kEngineChoiceCount=2;
constexpr int kEngineParamCount=64;
constexpr int kEngineParamCountLegacy=64;
constexpr int kEngineParamCountV1=48;
constexpr int kEngineMaxPages=1;
constexpr int kUserWaveCount=16;
constexpr int kTableWaveCount=0;
enum : int { E_SOURCE=60,E_BYPASS=61,E_BEND_UP=62,E_BEND_DOWN=63 };
constexpr EngineType engineTypeOf(int n) noexcept {return n==13?EngineType::Solo:EngineType::Off;}
struct EngineParams {
 EngineType type{EngineType::Off};std::array<float,kEngineParamCount> p{};
 bool chosen() const noexcept {return type==EngineType::Solo;}
 bool on() const noexcept {return chosen()&&p[E_BYPASS]<.5F;}
};
enum class EngineKind : std::uint8_t {
    Lin,      // plain number, shown with `decimals`
    Pct,      // 0..1 shown as %
    Hz,       // logarithmic Hz
    Ms,       // logarithmic ms (lo may be 0 = OFF)
    Sec,      // logarithmic seconds
    Oct,      // octaves, bipolar
    Cents,    // cents, bipolar when lo < 0
    Semis,    // semitones, bipolar
    Db,       // dB, bipolar
    Choice,   // a key that cycles through `names`
    Switch,   // ON / OFF key
    Drawbar,  // CX-3 drawbar 0..8 (drawn as a slider)
    Bend      // pitch bend range: -1 OFF, 0 UPPER, 1..24 semitones
};

struct EngineParamDef {
    int id;
    const char* label;        // on the knob
    const char* hint;         // one short line (Bulgarian), shown in the number window
    EngineKind kind;
    float lo, hi, def, step;
    int decimals;
    const char* names;        // Choice: names separated by '|'
};


struct EngineParamPage {const EngineParamDef* items;int count;};
int engineStoredCount(const EngineParams&) noexcept;
EngineType engineChoice(int) noexcept;
const char* engineName(EngineType) noexcept;
const char* engineLine(EngineType) noexcept;
int engineOscPage(EngineType) noexcept;
int enginePageCount(EngineType) noexcept;
const char* enginePageName(EngineType,int,int=0) noexcept;
EngineParamPage enginePage(EngineType,int,int=0) noexcept;
const EngineParamDef* engineParamDef(EngineType,int) noexcept;
EngineParams engineDefaults(EngineType) noexcept;
float engineClamp(EngineType,int,float) noexcept;
bool engineMakesOwnSound(const EngineParams&) noexcept;
void engineSanitizeLoaded(EngineParams&) noexcept;
}
