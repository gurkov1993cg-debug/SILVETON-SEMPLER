#pragma once
// SILVETON_ENGINES_V1 / V2 - the nine sound engines of the sampler, in the spirit of the Korg Kronos engines, built on
// the sampler's own recordings AND on their own generators (SILVETON_ENGINES_V2: band-limited oscillators, six FM
// operators, a shared tonewheel bank, a tine model, a plucked string - so every engine makes a sound of its own as well).
// One ENGINE per Upper; it works on every voice of the Upper (ОСНОВЕН + L1..L4) like a real synthesizer (per note), and
// a small per-Upper stage after the sum (Leslie, ensemble, tremolo, cabinet, string and body resonance).
//
// This header is shared by the sound core (what the knobs do), the host (one id, one value) and the screens (labels,
// ranges, pages). The ids never change once released: a blend saved with them keeps its sound. V2 only ADDS ids
// (36.. of an engine's own range and 48..63); a V1 blend reads with the V2 defaults for the new ids, which keep its sound.
//
// Our own models of the original instruments - nothing of Korg's code is in here.

#include <array>
#include <cstdint>

namespace silveton::sampler {

enum class EngineType : std::uint8_t { Off, HD1, Polysix, MS20, AL1, Mod7, Str1, CX3, SGX, EP };
constexpr int kEngineTypeCount = 10;
constexpr int kEngineParamCount = 64;        // SILVETON_ENGINES_V2: 48 -> 64 (a V1 set holds 48; the rest take the defaults)
constexpr int kEngineParamCountV1 = 48;
constexpr int kEngineMaxPages = 4;

// ---- the ids. 0..23 are the same in every engine (the ФИЛТЪР and МОД pages), 24.. belong to the engine (its ЗВУК pages).
enum EngineId : int {
    E_FILT_TYPE = 0,   // 0 OFF, 1 LP24 (4-pole ladder: Polysix / SSM family), 2 KORG35 (MS-20), 3 LP12, 4 HP12, 5 BP12
    E_CUTOFF = 1,      // Hz
    E_RESO = 2,        // 0..1
    E_KEYTRACK = 3,    // -1..1 (1 = the cutoff follows the key fully)
    E_FEG_AMT = 4,     // octaves, bipolar: the filter envelope
    E_FEG_A = 5, E_FEG_D = 6, E_FEG_S = 7, E_FEG_R = 8,   // ms, ms, 0..1, ms
    E_VEL_CUT = 9,     // octaves the cutoff rises with velocity
    E_DRIVE = 10,      // 0..1 soft saturation before the filter
    E_F2_TYPE = 11,    // 0 OFF 1 LP 2 HP 3 BP 4 BR (12 dB)
    E_F2_CUT = 12, E_F2_RES = 13, E_F2_PAR = 14,   // Hz, 0..1, 0 = after filter 1 / 1 = beside it
    E_LFO_RATE = 15, E_LFO_PITCH = 16, E_LFO_CUT = 17, E_LFO_AMP = 18, E_LFO_WAVE = 19,   // Hz, cents, oct, 0..1, 0 sine 1 tri 2 saw 3 square 4 S&H
    E_UNISON = 20, E_UNI_DET = 21, E_UNI_SPREAD = 22,   // 1..4 voices, cents, 0..1
    E_ANALOG = 23,     // 0..1 small random differences per note
    E_X0 = 24          // the first id of the engine's own pages
};

// POLYSIX  (V2: the real band-limited oscillator of the Polysix next to the recording, the saturation of the ladder)
enum : int { P6_PWM_WIDTH = 24, P6_PWM_DEPTH, P6_PWM_RATE, P6_SUB_LEVEL, P6_SUB_OCT, P6_FX_TYPE, P6_FX_SPEED, P6_FX_DEPTH, P6_FX_MIX,
             P6_OSC = 33, P6_OSC_LEVEL, P6_REC_LEVEL, P6_FILT_SAT, P6_SUB_WAVE };
// MS-20  (V2: the two VCOs, the patch panel with three cables, ESP envelope follower, sample & hold, noise, HP/LP routing)
enum : int { MS_HPF_CUT = 24, MS_HPF_PEAK, MS_EG1_DELAY, MS_EG1_ATTACK, MS_EG1_RELEASE, MS_EG1_PITCH, MS_EG1_HPF, MS_MG_HPF, MS_WHEEL_TO, MS_WHEEL_AMT,
             MS_P1_SRC = 34, MS_P1_DST, MS_P1_AMT, MS_P2_SRC, MS_P2_DST, MS_P2_AMT, MS_P3_SRC, MS_P3_DST, MS_P3_AMT,
             MS_SH_RATE = 43, MS_ESP_SENS, MS_MODEL, MS_ROUTE, MS_FB_SAT,
             MS_VCO1_WAVE = 48, MS_VCO1_LEVEL, MS_VCO2_WAVE, MS_VCO2_LEVEL, MS_VCO2_PITCH, MS_PW, MS_REC_LEVEL };
// AL-1  (V2: two band-limited oscillators, their sync / ring / FM, the recording as a third source)
enum : int { AL_FM_AMT = 24, AL_FM_RATIO, AL_RING_LEVEL, AL_RING_RATIO, AL_SYNC, AL_SYNC_RATIO, AL_SUB_LEVEL, AL_SUB_OCT, AL_NOISE_LEVEL, AL_NOISE_COLOR, AL_FM_EG, AL_SHAPE,
             AL_OSC1_WAVE = 36, AL_OSC1_LEVEL, AL_OSC2_WAVE, AL_OSC2_LEVEL, AL_OSC2_SEMI, AL_OSC2_FINE, AL_PW, AL_PWM, AL_OSC_SYNC, AL_OSC_FM, AL_OSC_RING, AL_REC_LEVEL };
// MOD-7  (V2: six operators with a 6 x 6 routing matrix chosen by ALGORITHM, the modulator envelope, pitch EG, oversampling)
enum : int { M7_OP2_RATIO = 24, M7_OP2_LEVEL, M7_OP3_RATIO, M7_OP3_LEVEL, M7_OP3_TARGET, M7_FEEDBACK, M7_FM_EG, M7_FM_VEL, M7_WS_TYPE, M7_WS_DRIVE, M7_WS_MIX, M7_BRIGHT, M7_RING,
             M7_OP4_RATIO = 37, M7_OP4_LEVEL, M7_OP5_RATIO, M7_OP5_LEVEL, M7_OP6_RATIO, M7_OP6_LEVEL, M7_ALGO,
             M7_ENV_A = 44, M7_ENV_D, M7_ENV_S, M7_ENV_R, M7_ENV_AMT = 48, M7_PEG, M7_PEG_TIME, M7_OVERSAMPLE, M7_PCM_LEVEL, M7_OP_LEVEL, M7_FINE };
// STR-1  (V2: the body of the instrument, a pluck of its own)
enum : int { ST_STRING = 24, ST_EXCITE, ST_DECAY, ST_DAMP, ST_DISP, ST_PICK, ST_PICKUP, ST_EXC_LEN, ST_FEEDBACK, ST_NONLIN, ST_TUNE, ST_KEY_DECAY,
             ST_BODY = 36, ST_BODY_TYPE, ST_PLUCK, ST_PLUCK_COLOR };
// CX-3  (V2: the shared tonewheel generator with the real gear ratios and foldback, the Leslie's horn and drum apart)
enum : int { CX_DB16 = 24, CX_DB513, CX_DB8, CX_DB4, CX_DB223, CX_DB2, CX_DB135, CX_DB113, CX_DB1,
             CX_PERC = 33, CX_PERC_DECAY, CX_PERC_LEVEL, CX_CLICK, CX_LEAK, CX_VIBCHO, CX_ROTARY, CX_SLOW, CX_FAST, CX_HORN, CX_AMP_DRIVE, CX_SAMPLE, CX_WHEEL_ROT,
             CX_TUNING = 48, CX_FOLDBACK, CX_TAPER, CX_DRUM_SLOW, CX_DRUM_FAST, CX_HORN_ACCEL, CX_DRUM_ACCEL, CX_MIC_DIST };
// SGX  (V2: the body (modal resonators), the half pedal and the damper time, the energy limit of the sympathetic strings)
enum : int { SG_STRING_RES = 24, SG_DAMPER_RES, SG_UNA_CORDA, SG_KEYOFF, SG_KEYOFF_TONE, SG_HAMMER, SG_LID, SG_VEL_BRIGHT, SG_RES_RELEASE, SG_WIDTH,
             SG_BODY = 34, SG_BODY_TYPE, SG_HALF_PEDAL, SG_DAMPER_TIME, SG_SYMP_LIMIT };
// EP  (V2: the tine / reed model of its own - three damped partials - and the nonlinear pickup)
enum : int { EP_TYPE = 24, EP_BELL, EP_BARK, EP_PRE_DRIVE, EP_BASS, EP_TREBLE, EP_TREM, EP_TREM_SPEED, EP_TREM_DEPTH, EP_TREM_STEREO, EP_CAB, EP_CAB_DRIVE, EP_KEYOFF,
             EP_MODEL = 37, EP_TINE_DECAY, EP_INHARM, EP_PICKUP_DRIVE, EP_PICKUP_SYM, EP_HAMMER, EP_REC_LEVEL };
// HD-1  (V2: the interpolation of the recording, velocity to the pitch EG)
enum : int { HD_BOOST = 24, HD_PEG_CENTS, HD_PEG_TIME, HD_INTERP, HD_PEG_VEL };

struct EngineParams {
    EngineType type{EngineType::Off};
    std::array<float, kEngineParamCount> p{};
    [[nodiscard]] bool on() const noexcept { return type != EngineType::Off; }
};

// ---- what the screens need: one line per knob / key of a page
enum class EngineKind : std::uint8_t {
    Lin,      // plain number, shown with `decimals`
    Pct,      // 0..1 shown as %
    Hz,       // logarithmic Hz
    Ms,       // logarithmic ms (lo may be 0 = OFF)
    Sec,      // logarithmic seconds
    Oct,      // octaves, bipolar
    Cents,    // cents, bipolar when lo < 0
    Semis,    // semitones, bipolar
    Db,       // dB, bipolar
    Choice,   // a key that cycles through `names`
    Switch,   // ON / OFF key
    Drawbar   // CX-3 drawbar 0..8 (drawn as a slider)
};

struct EngineParamDef {
    int id;
    const char* label;        // on the knob
    const char* hint;         // one short line (Bulgarian), shown in the number window
    EngineKind kind;
    float lo, hi, def, step;
    int decimals;
    const char* names;        // Choice: names separated by '|'
};

// The pages of the ENGINE tab: 0 ЗВУК (the engine's own), 1 ФИЛТЪР, 2 МОД, 3 the engine's second own page (some engines).
struct EngineParamPage {
    const EngineParamDef* items;
    int count;
};

[[nodiscard]] const char* engineName(EngineType t) noexcept;
[[nodiscard]] const char* engineLine(EngineType t) noexcept;      // one line about the engine (Bulgarian)
[[nodiscard]] int enginePageCount(EngineType t) noexcept;         // 3 or 4
[[nodiscard]] const char* enginePageName(EngineType t, int page) noexcept;
[[nodiscard]] EngineParamPage enginePage(EngineType t, int page) noexcept;
[[nodiscard]] const EngineParamDef* engineParamDef(EngineType t, int id) noexcept;   // nullptr = the id is not used by this engine
[[nodiscard]] EngineParams engineDefaults(EngineType t) noexcept;
// Clamps one value into the range of its definition (unknown ids: just finite).
[[nodiscard]] float engineClamp(EngineType t, int id, float v) noexcept;
// A set / blend written before V2 holds only the first 48 values: the new ids take their defaults.
void engineFillV2Defaults(EngineParams& e) noexcept;

} // namespace silveton::sampler
