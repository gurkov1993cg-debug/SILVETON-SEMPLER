#pragma once
// SILVETON_ENGINES_V1 / V2 - the nine sound engines of the sampler, in the spirit of the Korg Kronos engines, built on
// the sampler's own recordings AND on their own generators (SILVETON_ENGINES_V2: band-limited oscillators, six FM
// operators, a shared tonewheel bank, a tine model, a plucked string - so every engine makes a sound of its own as well).
// One ENGINE per Upper; it works on every voice of the Upper (ОСНОВЕН + L1..L4) like a real synthesizer (per note), and
// a small per-Upper stage after the sum (Leslie, ensemble, tremolo, cabinet, string and body resonance).
//
// This header is shared by the sound core (what the knobs do), the host (one id, one value) and the screens (labels,
// ranges, pages). The ids never change once released: a blend saved with them keeps its sound. V2 only ADDS ids
// (36.. of an engine's own range and 48..63); a V1 blend reads with the V2 defaults for the new ids, which keep its sound.
//
// Our own models of the original instruments - nothing of Korg's code is in here.

#include "silveton/sampler/SuseDefs.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::sampler {

// SILVETON_SUSE_V1: SILVETON SYNTH (Suse) is the one engine of the engine places. The nine engines before it stay in the code (a blend
// that holds one still plays), but the screens no longer offer them.
// SILVETON_MODEL_V1 (Цветомир, 03.11.2026): SILVETON MODEL (Model) is THE engine of the sampler - it has no sound of its own: a blend of
// the bank is put into it and the knobs CHANGE that blend towards a model the teacher learned from samples (ModelDefs.h). The older
// types stay in the list only so that an old set still opens (such a place opens empty); no screen offers them.
enum class EngineType : std::uint8_t { Off, HD1, Polysix, MS20, AL1, Mod7, Str1, CX3, SGX, EP, Suse, Model, Synth };   // SILVETON_SYNTH_V1: Synth = the sound calculated from the learned model
constexpr int kEngineTypeCount = 13;
constexpr int kEngineParamCountLegacy = 64;  // SILVETON_ENGINES_V2: 48 -> 64 (a V1 set holds 48; the rest take the defaults): the nine old engines
constexpr int kEngineParamCount = suse::kParamCount;   // SILVETON SYNTH: the whole graph is one row of 960 numbers
constexpr int kEngineParamCountV1 = 48;
constexpr int kEngineMaxPages = 5;   // SILVETON_ENGINES_PAGE_V2: 4 -> 5 (the ОСЦ page)

// ---- the ids. 0..23 are the same in every engine (the ФИЛТЪР and МОД pages), 24.. belong to the engine (its ЗВУК pages).
enum EngineId : int {
    E_FILT_TYPE = 0,   // 0 OFF, 1 LP24 (4-pole ladder: Polysix / SSM family), 2 KORG35 (MS-20), 3 LP12, 4 HP12, 5 BP12
    E_CUTOFF = 1,      // Hz
    E_RESO = 2,        // 0..1
    E_KEYTRACK = 3,    // -1..1 (1 = the cutoff follows the key fully)
    E_FEG_AMT = 4,     // octaves, bipolar: the filter envelope
    E_FEG_A = 5, E_FEG_D = 6, E_FEG_S = 7, E_FEG_R = 8,   // ms, ms, 0..1, ms
    E_VEL_CUT = 9,     // octaves the cutoff rises with velocity
    E_DRIVE = 10,      // 0..1 soft saturation before the filter
    E_F2_TYPE = 11,    // 0 OFF 1 LP 2 HP 3 BP 4 BR (12 dB)
    E_F2_CUT = 12, E_F2_RES = 13, E_F2_PAR = 14,   // Hz, 0..1, 0 = after filter 1 / 1 = beside it
    E_LFO_RATE = 15, E_LFO_PITCH = 16, E_LFO_CUT = 17, E_LFO_AMP = 18, E_LFO_WAVE = 19,   // Hz, cents, oct, 0..1, 0 sine 1 tri 2 saw 3 square 4 S&H
    E_UNISON = 20, E_UNI_DET = 21, E_UNI_SPREAD = 22,   // 1..4 voices, cents, 0..1
    E_ANALOG = 23,     // 0..1 small random differences per note
    E_X0 = 24          // the first id of the engine's own pages
};

// POLYSIX  (V2: the real band-limited oscillator of the Polysix next to the recording, the saturation of the ladder)
enum : int { P6_PWM_WIDTH = 24, P6_PWM_DEPTH, P6_PWM_RATE, P6_SUB_LEVEL, P6_SUB_OCT, P6_FX_TYPE, P6_FX_SPEED, P6_FX_DEPTH, P6_FX_MIX,
             P6_OSC = 33, P6_OSC_LEVEL, P6_REC_LEVEL, P6_FILT_SAT, P6_SUB_WAVE };
// MS-20  (V2: the two VCOs, the patch panel with three cables, ESP envelope follower, sample & hold, noise, HP/LP routing)
enum : int { MS_HPF_CUT = 24, MS_HPF_PEAK, MS_EG1_DELAY, MS_EG1_ATTACK, MS_EG1_RELEASE, MS_EG1_PITCH, MS_EG1_HPF, MS_MG_HPF, MS_WHEEL_TO, MS_WHEEL_AMT,
             MS_P1_SRC = 34, MS_P1_DST, MS_P1_AMT, MS_P2_SRC, MS_P2_DST, MS_P2_AMT, MS_P3_SRC, MS_P3_DST, MS_P3_AMT,
             MS_SH_RATE = 43, MS_ESP_SENS, MS_MODEL, MS_ROUTE, MS_FB_SAT,
             MS_VCO1_WAVE = 48, MS_VCO1_LEVEL, MS_VCO2_WAVE, MS_VCO2_LEVEL, MS_VCO2_PITCH, MS_PW, MS_REC_LEVEL };
// AL-1  (V2: two band-limited oscillators, their sync / ring / FM, the recording as a third source)
enum : int { AL_FM_AMT = 24, AL_FM_RATIO, AL_RING_LEVEL, AL_RING_RATIO, AL_SYNC, AL_SYNC_RATIO, AL_SUB_LEVEL, AL_SUB_OCT, AL_NOISE_LEVEL, AL_NOISE_COLOR, AL_FM_EG, AL_SHAPE,
             AL_OSC1_WAVE = 36, AL_OSC1_LEVEL, AL_OSC2_WAVE, AL_OSC2_LEVEL, AL_OSC2_SEMI, AL_OSC2_FINE, AL_PW, AL_PWM, AL_OSC_SYNC, AL_OSC_FM, AL_OSC_RING, AL_REC_LEVEL };
// MOD-7  (V2: six operators with a 6 x 6 routing matrix chosen by ALGORITHM, the modulator envelope, pitch EG, oversampling)
enum : int { M7_OP2_RATIO = 24, M7_OP2_LEVEL, M7_OP3_RATIO, M7_OP3_LEVEL, M7_OP3_TARGET, M7_FEEDBACK, M7_FM_EG, M7_FM_VEL, M7_WS_TYPE, M7_WS_DRIVE, M7_WS_MIX, M7_BRIGHT, M7_RING,
             M7_OP4_RATIO = 37, M7_OP4_LEVEL, M7_OP5_RATIO, M7_OP5_LEVEL, M7_OP6_RATIO, M7_OP6_LEVEL, M7_ALGO,
             M7_ENV_A = 44, M7_ENV_D, M7_ENV_S, M7_ENV_R, M7_ENV_AMT = 48, M7_PEG, M7_PEG_TIME, M7_OVERSAMPLE, M7_PCM_LEVEL, M7_OP_LEVEL, M7_FINE,
             M7_OP2_WAVE = 55, M7_OP3_WAVE, M7_OP4_WAVE, M7_OP5_WAVE, M7_OP6_WAVE };   // SILVETON_ENGINES_V3: 0 = SINE, 1.. = the table waves
// STR-1  (V2: the body of the instrument, a pluck of its own; V3: ST_BODY_TYPE is the INSTRUMENT, its STYLE and the bow)
enum : int { ST_STRING = 24, ST_EXCITE, ST_DECAY, ST_DAMP, ST_DISP, ST_PICK, ST_PICKUP, ST_EXC_LEN, ST_FEEDBACK, ST_NONLIN, ST_TUNE, ST_KEY_DECAY,
             ST_BODY = 36, ST_BODY_TYPE, ST_PLUCK, ST_PLUCK_COLOR,
             ST_STYLE = 40, ST_BOW_PRESS, ST_BOW_SPEED, ST_BOW_POS, ST_BOW_ATTACK, ST_BOW_RELEASE, ST_VEL_BOW, ST_BOW_NOISE, ST_TREM_RATE,
             ST_VIBRATO, ST_VIB_RATE, ST_VIB_DELAY, ST_GROWL };
// the INSTRUMENT (ST_BODY_TYPE) and the STYLE (ST_STYLE) of STR-1:
//   GUITAR  PICK  | FINGER | MUTE    | HARMONIC
//   VIOLIN  ARCO  | PIZZ   | TREMOLO | SPICCATO     (ARCO / TREMOLO / SPICCATO = the bow)
//   CELLO   ARCO  | PIZZ   | TREMOLO | SPICCATO
//   HARP    NORMAL| HARMONIC | MUTED | PRES TABLE
//   (V3 winds - a reed / lips / jet that blows into a bore; the ДЪХ page uses the ids of the ЛЪК page: BREATH = ST_BOW_SPEED,
//    EMBOUCHURE = ST_BOW_PRESS, ATTACK / RELEASE, VEL→BREATH, AIR = ST_BOW_NOISE, the vibrato, and GROWL)
//   SAX ALTO / SAX TENOR / CLARINET / GAIDA  NORMAL | SOFT | GROWL | STACCATO
//   TRUMPET  NORMAL | MUTE | GROWL | STACCATO        KAVAL  NORMAL | BREATHY | GROWL | STACCATO
enum : int { ST_GUITAR = 0, ST_VIOLIN = 1, ST_CELLO = 2, ST_HARP = 3,
             ST_SAX_ALTO = 4, ST_SAX_TENOR = 5, ST_CLARINET = 6, ST_TRUMPET = 7, ST_KAVAL = 8, ST_GAIDA = 9 };
constexpr int kStr1Instruments = 10;
// CX-3  (V2: the shared tonewheel generator with the real gear ratios and foldback, the Leslie's horn and drum apart)
enum : int { CX_DB16 = 24, CX_DB513, CX_DB8, CX_DB4, CX_DB223, CX_DB2, CX_DB135, CX_DB113, CX_DB1,
             CX_PERC = 33, CX_PERC_DECAY, CX_PERC_LEVEL, CX_CLICK, CX_LEAK, CX_VIBCHO, CX_ROTARY, CX_SLOW, CX_FAST, CX_HORN, CX_AMP_DRIVE, CX_SAMPLE, CX_WHEEL_ROT,
             CX_TUNING = 48, CX_FOLDBACK, CX_TAPER, CX_DRUM_SLOW, CX_DRUM_FAST, CX_HORN_ACCEL, CX_DRUM_ACCEL, CX_MIC_DIST };
// SGX  (V2: the body (modal resonators), the half pedal and the damper time, the energy limit of the sympathetic strings)
enum : int { SG_STRING_RES = 24, SG_DAMPER_RES, SG_UNA_CORDA, SG_KEYOFF, SG_KEYOFF_TONE, SG_HAMMER, SG_LID, SG_VEL_BRIGHT, SG_RES_RELEASE, SG_WIDTH,
             SG_BODY = 34, SG_BODY_TYPE, SG_HALF_PEDAL, SG_DAMPER_TIME, SG_SYMP_LIMIT };
// EP  (V2: the tine / reed model of its own - three damped partials - and the nonlinear pickup)
enum : int { EP_TYPE = 24, EP_BELL, EP_BARK, EP_PRE_DRIVE, EP_BASS, EP_TREBLE, EP_TREM, EP_TREM_SPEED, EP_TREM_DEPTH, EP_TREM_STEREO, EP_CAB, EP_CAB_DRIVE, EP_KEYOFF,
             EP_MODEL = 37, EP_TINE_DECAY, EP_INHARM, EP_PICKUP_DRIVE, EP_PICKUP_SYM, EP_HAMMER, EP_REC_LEVEL };
// HD-1  (V2: the interpolation of the recording, velocity to the pitch EG)
enum : int { HD_BOOST = 24, HD_PEG_CENTS, HD_PEG_TIME, HD_INTERP, HD_PEG_VEL };
// SILVETON_OCTAVE_V1: ОКТАВА -2..+2 (0 = as before) - of each oscillator (AL-1 OSC 1/2, MS-20 VCO 1/2, POLYSIX OSC), or of the
// whole engine where there is no oscillator (HD-1, SGX, EP, STR-1, CX-3). MOD-7: the RATIO of its operators are its octaves.
enum : int { AL_OSC1_OCT = 48, AL_OSC2_OCT = 49, MS_VCO1_OCT = 55, MS_VCO2_OCT = 56, P6_OSC_OCT = 38,
             HD_OCTAVE = 29, SG_OCTAVE = 39, EP_OCTAVE = 44, ST_OCTAVE = 53, CX_OCTAVE = 56 };
// SILVETON_ENGINE_WAVE_V1: HD-1, SGX, EP, STR-1 and CX-3 get an oscillator of their own (ВЪЛНА: OFF, the 32 table waves, USER 1..16)
// with its level and octave - so the user's waves are in all nine engines. It sounds next to the engine's sound.
enum : int { HD_OSC_WAVE = 30, HD_OSC_LEVEL, HD_OSC_OCT, SG_OSC_WAVE = 40, SG_OSC_LEVEL, SG_OSC_OCT, EP_OSC_WAVE = 45, EP_OSC_LEVEL, EP_OSC_OCT,
             ST_OSC_WAVE = 54, ST_OSC_LEVEL, ST_OSC_OCT, CX_OSC_WAVE = 57, CX_OSC_LEVEL, CX_OSC_OCT };

// SILVETON_ENGINES_V2: the same three ids in every engine (the last ones of the block)
//   E_BYPASS    0 = the engine works, 1 = ENGINE OFF: the plain recording, every setting kept (to hear the difference)
//   E_BEND_UP / E_BEND_DOWN   pitch bend range of the engine: 0 = as the Upper (VOICE page), -1 = OFF, 1..24 semitones
enum : int { E_BYPASS = 61, E_BEND_UP = 62, E_BEND_DOWN = 63 };
// SILVETON_ENGINES_V3: where the sound of an engine with a generator of its own comes from
//   E_SOURCE  0 = BOTH (its own generator and the recording, as V2), 1 = OWN (only the generator), 2 = SAMPLE (only the recording)
enum : int { E_SOURCE = 60 };
enum : int { E_SRC_BOTH = 0, E_SRC_OWN = 1, E_SRC_SAMPLE = 2 };
// SILVETON_MODEL_CLEAN_V1 (Цветомир, 03.11.2026: "искам само моделите"): the 32 own table waves of the old oscillators (ORGAN, VOX ...)
// are REMOVED. The count stays as a number so the old engines' indices still add up; the user's waves follow at once.
constexpr int kTableWaveCount = 0;
// SILVETON_USER_WAVES_V1: after the old engines' own choices, 16 places for the user's own single-cycle waves (made with SILVETON
// OSCILLATOR LAB, read from the folder SILVETON_OSC next to SILVETON_BANK.sv - see UserWaves.h). An empty place is silent.
constexpr int kUserWaveCount = 16;
#define SILVETON_USER_WAVE_NAMES "USER 1|USER 2|USER 3|USER 4|USER 5|USER 6|USER 7|USER 8|USER 9|USER 10|USER 11|USER 12|USER 13|USER 14|USER 15|USER 16"
constexpr int kOscOwnWaves = 5;   // AL-1 / POLYSIX / MS-20: their own choices 0..4, then USER 1..16 (5..20)

struct EngineParams {
    EngineType type{EngineType::Off};
    std::array<float, kEngineParamCount> p{};
    [[nodiscard]] bool chosen() const noexcept { return type != EngineType::Off; }                 // an engine is picked (on or bypassed)
    [[nodiscard]] bool on() const noexcept { return type != EngineType::Off && p[E_BYPASS] < 0.5F; }   // ... and it works
};

// ---- what the screens need: one line per knob / key of a page
enum class EngineKind : std::uint8_t {
    Lin,      // plain number, shown with `decimals`
    Pct,      // 0..1 shown as %
    Hz,       // logarithmic Hz
    Ms,       // logarithmic ms (lo may be 0 = OFF)
    Sec,      // logarithmic seconds
    Oct,      // octaves, bipolar
    Cents,    // cents, bipolar when lo < 0
    Semis,    // semitones, bipolar
    Db,       // dB, bipolar
    Choice,   // a key that cycles through `names`
    Switch,   // ON / OFF key
    Drawbar,  // CX-3 drawbar 0..8 (drawn as a slider)
    Bend      // pitch bend range: -1 OFF, 0 UPPER, 1..24 semitones
};

struct EngineParamDef {
    int id;
    const char* label;        // on the knob
    const char* hint;         // one short line (Bulgarian), shown in the number window
    EngineKind kind;
    float lo, hi, def, step;
    int decimals;
    const char* names;        // Choice: names separated by '|'
};

// The pages of the ENGINE tab: 0 ЗВУК (the engine's own), 1 ФИЛТЪР, 2 МОД, 3 the engine's second own page (some engines).
struct EngineParamPage {
    const EngineParamDef* items;
    int count;
};

// SILVETON_SUSE_V1: how many numbers of `e` a SET writes (0 = no engine, 64 for the nine old ones, 960 for SILVETON SYNTH)
[[nodiscard]] int engineStoredCount(const EngineParams& e) noexcept;
// the engine types a screen offers, in the order of its key: OFF, SILVETON MODEL
constexpr int kEngineChoiceCount = 2;
[[nodiscard]] EngineType engineChoice(int index) noexcept;
[[nodiscard]] const char* engineName(EngineType t) noexcept;
[[nodiscard]] const char* engineLine(EngineType t) noexcept;      // one line about the engine (Bulgarian)
[[nodiscard]] int engineOscPage(EngineType t) noexcept;   // SILVETON_ENGINES_PAGE_V2: the page of the oscillators (an engine opens on it)
[[nodiscard]] int enginePageCount(EngineType t) noexcept;         // 3 or 4
[[nodiscard]] const char* enginePageName(EngineType t, int page, int instrument = 0) noexcept;
[[nodiscard]] EngineParamPage enginePage(EngineType t, int page, int instrument = 0) noexcept;   // instrument: STR-1 (the winds have the ДЪХ page)
[[nodiscard]] const EngineParamDef* engineParamDef(EngineType t, int id) noexcept;   // nullptr = the id is not used by this engine
[[nodiscard]] EngineParams engineDefaults(EngineType t) noexcept;
// Clamps one value into the range of its definition (unknown ids: just finite).
[[nodiscard]] float engineClamp(EngineType t, int id, float v) noexcept;
// A set / blend written before V2 holds only the first 48 values: the new ids take their defaults.
void engineFillV2Defaults(EngineParams& e) noexcept;
// SILVETON_ENGINES_V2: the engine makes a sound of its own (oscillators, operators, wheels, pluck, tine): an Upper with this engine
// plays even when it has no recording.
[[nodiscard]] bool engineMakesOwnSound(const EngineParams& e) noexcept;
// SILVETON_ENGINES_V3
// A set written before V3 (SVEN version 1 / 2) holds 0 where V3 added a knob: those take their defaults.
void engineFillV3Defaults(EngineParams& e) noexcept;
void engineFillV4Defaults(EngineParams& e) noexcept;   // SILVETON_BODY_V1
void engineFillV5Defaults(EngineParams& e) noexcept;   // SILVETON_STR1_REAL_V1
// the names of the STR-1 STYLE key for an INSTRUMENT (0 GUITAR 1 VIOLIN 2 CELLO 3 HARP)
[[nodiscard]] const char* str1StyleNames(int instrument) noexcept;
// STR-1 plays with the bow (VIOLIN / CELLO with ARCO, TREMOLO or SPICCATO)
[[nodiscard]] bool str1Bowed(const EngineParams& e) noexcept;
// STR-1 is a wind (SAX ALTO .. GAIDA)
[[nodiscard]] bool str1Wind(const EngineParams& e) noexcept;
// STR-1: choosing an INSTRUMENT loads its typical BODY / DECAY / DAMPING / PICK / colour and STYLE 1 (the host calls it)
void str1InstrumentDefaults(EngineParams& e, int instrument) noexcept;
// the engine's own generator is heard / the recording is heard (E_SOURCE)
[[nodiscard]] inline bool engineOwnOn(const EngineParams& e) noexcept { return e.p[E_SOURCE] < 1.5F; }
// SILVETON_MUSICAL_V1: the RATIO keys keep the sound in its key - 0.25, 0.5 (octaves down), then whole numbers only
// (a ratio like 1.37 put the sound into another key)
[[nodiscard]] inline float engineMusicalRatio(float r, float hi) noexcept {
    if (!std::isfinite(r)) return 1.0F;
    r = std::clamp(r, 0.25F, hi);
    if (r < 0.375F) return 0.25F;
    if (r < 0.75F) return 0.5F;
    return std::round(r);
}
[[nodiscard]] inline bool engineIsRatio(EngineType t, int id) noexcept {
    return (t == EngineType::AL1 && (id == AL_FM_RATIO || id == AL_RING_RATIO)) ||
           (t == EngineType::Mod7 && (id == M7_OP2_RATIO || id == M7_OP3_RATIO || id == M7_OP4_RATIO || id == M7_OP5_RATIO || id == M7_OP6_RATIO));
}
// SILVETON_OCTAVE_V1: the octave key `id` as a multiplier of the pitch (1 = none)
[[nodiscard]] inline double engineOctaveMul(const EngineParams& e, int id) noexcept {
    return std::exp2(static_cast<double>(std::clamp(std::round(e.p[static_cast<std::size_t>(id)]), -2.0F, 2.0F)));
}
// SILVETON_ENGINE_WAVE_V1: the ids of the ВЪЛНА oscillator of HD-1 / SGX / EP / STR-1 / CX-3 (false = the engine has none)
[[nodiscard]] inline bool engineWaveIds(EngineType t, int& wave, int& level, int& octave) noexcept {
    switch (t) {
        case EngineType::HD1: wave = HD_OSC_WAVE; level = HD_OSC_LEVEL; octave = HD_OSC_OCT; return true;
        case EngineType::SGX: wave = SG_OSC_WAVE; level = SG_OSC_LEVEL; octave = SG_OSC_OCT; return true;
        case EngineType::EP: wave = EP_OSC_WAVE; level = EP_OSC_LEVEL; octave = EP_OSC_OCT; return true;
        case EngineType::Str1: wave = ST_OSC_WAVE; level = ST_OSC_LEVEL; octave = ST_OSC_OCT; return true;
        case EngineType::CX3: wave = CX_OSC_WAVE; level = CX_OSC_LEVEL; octave = CX_OSC_OCT; return true;
        default: return false;
    }
}
// SILVETON_OSC_KEY_V2: where the ОСЦ key puts a user wave in each of the nine engines (its first oscillator) and the value of
// USER 1 there: AL-1 OSC 1, POLYSIX OSC, MS-20 VCO 1, MOD-7 OP2 WAVE, the others their ВЪЛНА
[[nodiscard]] inline bool engineOscTarget(EngineType t, int& wave, int& level, int& user1) noexcept {
    switch (t) {
        case EngineType::AL1: wave = AL_OSC1_WAVE; level = AL_OSC1_LEVEL; user1 = kOscOwnWaves + kTableWaveCount; return true;
        case EngineType::Polysix: wave = P6_OSC; level = P6_OSC_LEVEL; user1 = kOscOwnWaves + kTableWaveCount; return true;
        case EngineType::MS20: wave = MS_VCO1_WAVE; level = MS_VCO1_LEVEL; user1 = kOscOwnWaves + kTableWaveCount; return true;
        case EngineType::Mod7: wave = M7_OP2_WAVE; level = M7_OP2_LEVEL; user1 = 1 + kTableWaveCount; return true;
        default: {
            int oct = 0;
            if (!engineWaveIds(t, wave, level, oct)) return false;
            user1 = 1 + kTableWaveCount;
            return true;
        }
    }
}
// ... is it playing (a wave chosen, a level, the engine's own sound on)
[[nodiscard]] inline bool engineWaveOn(const EngineParams& e) noexcept {
    int w = 0, l = 0, o = 0;
    if (!engineWaveIds(e.type, w, l, o) || !engineOwnOn(e)) return false;
    return e.p[static_cast<std::size_t>(w)] >= 0.5F && e.p[static_cast<std::size_t>(l)] > 0.0F;
}
// the octave of the whole engine (HD-1, SGX, EP, STR-1, CX-3) in semitones
[[nodiscard]] inline float engineOctaveSemis(const EngineParams& e) noexcept {
    int id = -1;
    switch (e.type) {
        case EngineType::HD1: id = HD_OCTAVE; break;
        case EngineType::SGX: id = SG_OCTAVE; break;
        case EngineType::EP: id = EP_OCTAVE; break;
        case EngineType::Str1: id = ST_OCTAVE; break;
        case EngineType::CX3: id = CX_OCTAVE; break;
        default: return 0.0F;
    }
    return 12.0F * std::clamp(std::round(e.p[static_cast<std::size_t>(id)]), -2.0F, 2.0F);
}
[[nodiscard]] inline bool engineRecOn(const EngineParams& e) noexcept { return e.p[E_SOURCE] < 0.5F || e.p[E_SOURCE] >= 1.5F; }

} // namespace silveton::sampler
