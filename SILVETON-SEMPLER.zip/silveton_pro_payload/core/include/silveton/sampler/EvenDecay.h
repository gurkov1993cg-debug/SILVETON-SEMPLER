#pragma once
// SILVETON_EVEN_DECAY_LIVE_V1 (only in the Manager's copy of the sampler): НАСТРОЙКИ > ЗАТИХВАНЕ.
// While the sampler plays, the echo of every frequency band dies away in the same time (the chosen ms to -60 dB):
// a band that dies away slower is pulled down to that speed, a faster one stays as it is. No delay at all.
//
// The signal of one Upper is split into 8 bands with lowpasses (band k = lowpass k - lowpass k-1, the last one = the
// rest), so with every gain at 0 dB the sum is EXACTLY the input. The level of every band is followed and a decay is
// recognised without looking ahead: the band is 8 dB under its recent peak and has been falling for 120 ms without
// coming back up (beating, tremolo and the fall after an attack do not do that). From then on the band may not be
// louder than a ceiling that goes down at the target speed - but only while the band itself is still going down
// (over the last 20 ms), so a held sound after the fall is not pulled under; when it stops falling for good (150 ms)
// the gain goes back to 0 dB at 100 dB/s; a new note (6 dB up) brings it back twice as fast as it rises.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::sampler {

class EvenDecayLive {
public:
    static constexpr int kBands = 8;
    static constexpr int kTick = 32;          // samples per control step
    static constexpr int kHistory = 32;       // band level every 8 steps -> about 170 ms at 48 kHz
    static constexpr int kRecent = 32;        // band level of the last 32 steps -> about 20 ms at 48 kHz

    void prepare(double sampleRate) noexcept {
        sr_ = std::max(8000.0, sampleRate);
        static constexpr std::array<double, kBands - 1> cut{{125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0}};
        for (int k = 0; k < kBands - 1; ++k) {
            const double fc = std::min(cut[static_cast<std::size_t>(k)], 0.45 * sr_);
            const double g = std::tan(3.14159265358979323846 * fc / sr_);
            const double q = 0.70710678118654752;
            const double k2 = 1.0 / q;
            lp_[static_cast<std::size_t>(k)].a1 = static_cast<float>(1.0 / (1.0 + g * (g + k2)));
            lp_[static_cast<std::size_t>(k)].a2 = static_cast<float>(g * static_cast<double>(lp_[static_cast<std::size_t>(k)].a1));
            lp_[static_cast<std::size_t>(k)].a3 = static_cast<float>(g * static_cast<double>(lp_[static_cast<std::size_t>(k)].a2));
        }
        static constexpr std::array<double, kBands> centre{{70.0, 177.0, 354.0, 707.0, 1414.0, 2828.0, 5657.0, 11000.0}};
        const double tickSec = static_cast<double>(kTick) / sr_;
        for (int b = 0; b < kBands; ++b) {
            const double tau = std::max(0.003, 3.0 / centre[static_cast<std::size_t>(b)]);
            envCoef_[static_cast<std::size_t>(b)] = static_cast<float>(1.0 - std::exp(-tickSec / tau));
        }
        gainSmooth_ = static_cast<float>(1.0 - std::exp(-1.0 / (0.002 * sr_)));
        startTicks_ = static_cast<int>(0.120 / tickSec);
        releaseDb_ = static_cast<float>(100.0 * tickSec);
        peakLeakDb_ = static_cast<float>(5.0 * tickSec);
        setTimeMs(timeMs_);
        reset();
    }

    void setTimeMs(float ms) noexcept {
        timeMs_ = std::clamp(ms, 30.0F, 10000.0F);
        stepDb_ = static_cast<float>(-60.0 / (static_cast<double>(timeMs_) / 1000.0) * static_cast<double>(kTick) / sr_);
    }

    void reset() noexcept {
        for (auto& f : lp_) { f.l1 = f.l2 = f.r1 = f.r2 = 0.0F; }
        for (auto& s : band_) s = BandState{};
        count_ = 0;
        quiet_ = 0;
    }

    // true = nothing is happening (silence in, every gain back at 0 dB): the caller may skip it
    [[nodiscard]] bool idle() const noexcept { return quiet_ > static_cast<int>(sr_); }

    void process(float& l, float& r) noexcept {
        // split
        std::array<float, kBands> bl{}, br{};
        float prevL = 0.0F, prevR = 0.0F;
        for (int k = 0; k < kBands - 1; ++k) {
            Lp& f = lp_[static_cast<std::size_t>(k)];
            const float yl = f.run(l, f.l1, f.l2);
            const float yr = f.run(r, f.r1, f.r2);
            bl[static_cast<std::size_t>(k)] = yl - prevL;
            br[static_cast<std::size_t>(k)] = yr - prevR;
            prevL = yl; prevR = yr;
        }
        bl[kBands - 1] = l - prevL;
        br[kBands - 1] = r - prevR;
        // gains + level
        float ol = 0.0F, orr = 0.0F;
        bool moving = false;
        for (int b = 0; b < kBands; ++b) {
            BandState& s = band_[static_cast<std::size_t>(b)];
            s.gain += (s.target - s.gain) * gainSmooth_;
            if (s.gain < 0.9999F) moving = true;
            const float xl = bl[static_cast<std::size_t>(b)], xr = br[static_cast<std::size_t>(b)];
            ol += xl * s.gain;
            orr += xr * s.gain;
            s.acc += 0.5F * (xl * xl + xr * xr);
        }
        if (++count_ >= kTick) { count_ = 0; control(); }
        if (l == 0.0F && r == 0.0F && !moving) ++quiet_; else quiet_ = 0;
        l = ol;
        r = orr;
    }

private:
    struct Lp {   // TPT state variable lowpass, 12 dB / octave
        float a1{0.0F}, a2{0.0F}, a3{0.0F};
        float l1{0.0F}, l2{0.0F}, r1{0.0F}, r2{0.0F};
        float run(float x, float& ic1, float& ic2) const noexcept {
            const float v3 = x - ic2;
            const float v1 = a1 * ic1 + a2 * v3;
            const float v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2.0F * v1 - ic1;
            ic2 = 2.0F * v2 - ic2;
            return v2;
        }
    };
    enum class Mode : std::uint8_t { Free, Decay, Recover, Release };
    struct BandState {
        float acc{0.0F};
        float env{0.0F};
        float level{-200.0F};
        float peak{-200.0F};
        float lowest{-200.0F};      // since the fall began (Free) / since the decay began (Decay)
        int falling{0};             // control steps the band has been falling without coming back up
        float gDb{0.0F};
        float ceiling{0.0F};
        float target{1.0F};
        float gain{1.0F};
        Mode mode{Mode::Free};
        std::array<float, kHistory> history{};
        int historyAt{0};
        int historyStep{0};
        std::array<float, kRecent> recent{};
        int recentAt{0};
    };

    void control() noexcept {
        for (int b = 0; b < kBands; ++b) {
            BandState& s = band_[static_cast<std::size_t>(b)];
            const float meanPower = s.acc / static_cast<float>(kTick);
            s.acc = 0.0F;
            s.env += (meanPower - s.env) * envCoef_[static_cast<std::size_t>(b)];
            const float before = s.level;
            s.level = 10.0F * std::log10(s.env + 1.0e-20F);
            const float l = s.level;
            const float delta = l - before;
            // the level about 150 ms ago (is it still falling?)
            if (++s.historyStep >= 8) {
                s.historyStep = 0;
                s.history[static_cast<std::size_t>(s.historyAt)] = l;
                s.historyAt = (s.historyAt + 1) % kHistory;
            }
            const float longAgo = s.history[static_cast<std::size_t>(s.historyAt)];
            const bool stillFalling = longAgo - l >= 1.5F;
            const float shortAgo = s.recent[static_cast<std::size_t>(s.recentAt)];
            s.recent[static_cast<std::size_t>(s.recentAt)] = l;
            s.recentAt = (s.recentAt + 1) % kRecent;
            const bool goingDown = shortAgo - l >= 0.3F;
            s.peak = std::max(l, s.peak - peakLeakDb_);
            switch (s.mode) {
                case Mode::Free:
                case Mode::Release: {
                    if (l > s.lowest + 1.0F) { s.lowest = l; s.falling = 0; }
                    else { s.lowest = std::min(s.lowest, l); ++s.falling; }
                    if (s.mode == Mode::Release) {
                        s.gDb = std::min(0.0F, s.gDb + releaseDb_);
                        if (s.gDb >= 0.0F) s.mode = Mode::Free;
                    } else {
                        s.gDb = 0.0F;
                    }
                    if (l > -90.0F && s.peak - l >= 8.0F && s.falling >= startTicks_ && stillFalling) {
                        s.mode = Mode::Decay;
                        s.lowest = l;
                        s.ceiling = l + s.gDb;   // from where the sound is now (a gain still coming back included)
                    }
                    break;
                }
                case Mode::Decay:
                    s.lowest = std::min(s.lowest, l);
                    if (l - s.lowest >= 6.0F && delta > 0.0F) {
                        s.mode = Mode::Recover;
                        s.gDb = std::min(0.0F, s.gDb + 2.0F * delta);
                    } else if (!stillFalling) {
                        s.mode = Mode::Release;
                        s.lowest = l;
                        s.falling = 0;
                    } else {
                        if (goingDown) s.ceiling += stepDb_;   // the ceiling goes down only while the band does
                        s.gDb = std::min(0.0F, s.ceiling - l);
                    }
                    break;
                case Mode::Recover:
                    s.gDb = std::min(0.0F, s.gDb + 2.0F * std::max(0.0F, delta));
                    if (s.gDb >= 0.0F) { s.gDb = 0.0F; s.mode = Mode::Free; s.lowest = l; s.falling = 0; }
                    else if (delta <= 0.0F && !stillFalling) { s.mode = Mode::Release; s.lowest = l; s.falling = 0; }
                    break;
            }
            s.gDb = std::max(s.gDb, -60.0F);
            s.target = std::pow(10.0F, s.gDb / 20.0F);
        }
    }

    double sr_{48000.0};
    float timeMs_{300.0F};
    float stepDb_{-0.13F};
    float gainSmooth_{0.01F};
    float releaseDb_{0.07F};
    float peakLeakDb_{0.003F};
    int startTicks_{180};
    std::array<float, kBands> envCoef_{};
    std::array<Lp, kBands - 1> lp_{};
    std::array<BandState, kBands> band_{};
    int count_{0};
    int quiet_{0};
};

} // namespace silveton::sampler
