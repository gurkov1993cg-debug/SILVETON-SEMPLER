#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <string>
#include <vector>

namespace silveton::sampler {

struct KorgImportResult {
    MultisamplePtr multisample;
    std::vector<SamplePtr> samples;
    std::string error;
    std::vector<std::string> warnings;
    [[nodiscard]] bool ok() const noexcept { return multisample != nullptr && error.empty(); }
};

struct KorgCollectionResult {
    std::vector<MultisamplePtr> multisamples;
    std::vector<SamplePtr> samples;
    std::string error;
    std::vector<std::string> warnings;
    [[nodiscard]] bool ok() const noexcept { return !multisamples.empty() && error.empty(); }
};

struct KorgSampleResult {
    SamplePtr sample;
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return sample != nullptr && error.empty(); }
};

class KorgImporter {
public:
    // Official KORG chunked PCM formats: KSF sample, KMP multisample, KSC script.
    [[nodiscard]] static KorgSampleResult loadKsf(const std::string& path);
    [[nodiscard]] static KorgSampleResult loadKsfStreaming(const std::string& path, std::uint64_t preloadFrames = 96000U);
    [[nodiscard]] static KorgImportResult loadKmp(const std::string& path);
    [[nodiscard]] static std::vector<std::string> parseKsc(const std::string& path, std::string& error);
    [[nodiscard]] static KorgCollectionResult loadKsc(const std::string& path);
};

} // namespace silveton::sampler
