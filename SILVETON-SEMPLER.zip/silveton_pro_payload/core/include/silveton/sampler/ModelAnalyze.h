#pragma once
// SILVETON_MODEL_V1 - measuring a blend of the bank the way the teacher measured its sounds: so the engine knows where the blend
// stands (its tone, its loudness in time, its pitch) and can move it towards a model. Not on the audio thread: it is done when the
// blend is put into the engine (a few milliseconds a sample).
#include "silveton/sampler/ModelBank.h"
#include "silveton/sampler/SamplerTypes.h"

#include <memory>
#include <vector>

namespace silveton::sampler::model {

struct BlendShape {
    struct Entry { const SampleData* sample = nullptr; ZoneShape shape; };
    const Program* program = nullptr;      // the program it was measured from (the host measures again when the place gets another)
    std::vector<Entry> entries;            // one per sample of the program (the layers' multisamples)
    [[nodiscard]] const ZoneShape* shapeOf(const SampleData* sample) const noexcept;
};

// measures every sample of the program (up to 1.5 s of each); a sample without a clear pitch gets ok = false
[[nodiscard]] std::shared_ptr<const BlendShape> analyzeBlend(const Program& program);
// one sample alone (the tests, and a sample that is not in a program)
[[nodiscard]] ZoneShape analyzeSample(const SampleData& sample, int rootKey, float tuneCents);

} // namespace silveton::sampler::model
