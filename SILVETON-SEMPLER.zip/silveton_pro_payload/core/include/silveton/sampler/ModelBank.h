#pragma once
// SILVETON_MODEL_V1 - what SILVETON TEACHER learned, as SILVETON SYNTH uses it.
//
// A learned model holds, for every studied sound and every sample of it: the harmonics frame by frame (the attack, then the steady part),
// the pitch of the attack, and the numbers (vibrato, life, unison, attack, release ...). Here that becomes a ModelShape: per zone of
// keys the harmonic rows (what SILVETON SYNTH plays), a tone curve on 32 bands, a loudness curve in time, a pitch curve of the attack.
// (SILVETON MODEL, which bent a recording of the bank towards these curves, was removed on 03.11.2026; the models stay. Since 04.11.2026 the models
// are only those of SILVETON_OSC.sv - nothing is built into the sampler.)
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::sampler::model {

constexpr int kBands = 32;                 // the tone curve: 32 bands, a third of an octave each, from 50 Hz up (see bandHz)
constexpr int kLevelFrames = 120;          // the loudness curve: 10 ms a frame, 1.2 s
constexpr float kLevelFrameMs = 10.0F;
constexpr int kScoopFrames = 60;           // the pitch of the attack: 5 ms a frame, 300 ms
constexpr float kScoopFrameMs = 5.0F;
constexpr int kNoiseBands = 4;             // the breath, as the engine makes it: low / mid / high / air
constexpr int kHarmonics = 48;             // the harmonics kept as they are (the tone curve is their smooth picture)
[[nodiscard]] float bandHz(int band) noexcept;            // the centre of a tone band
[[nodiscard]] float bandOfHz(float hz) noexcept;          // the (fractional) band a frequency falls in

// one zone of keys of a learned sound, or of a blend measured here (the same shape, so the two can be compared)
struct ZoneShape {
    int lowKey = 0, topKey = 127, rootKey = 60;
    int octaveShift = 0;                   // the sample sounds this many octaves away from its note (a learned sound only)
    float f0Hz = 0;                        // the pitch it was measured at
    float tone[kBands] = {};               // dB against the strongest band (<= 0), the steady part
    float harmDb[kHarmonics] = {};         // the harmonics themselves, dB against the strongest (-120 = not there / not measured), the steady part
    float level[kLevelFrames] = {};        // dB against the steady loudness, from the start of the note (0 after the attack settles)
    float scoop[kScoopFrames] = {};        // cents against the steady pitch, the start of the note
    float steadyRms = 0;                   // the loudness of the steady part, linear (a blend: absolute; a model: against its strongest harmonic)
    float attackMs = 0, releaseMs = -1;
    // the breath (a learned sound): the steady noise and the attack's extra noise, per engine band, dB against the strongest harmonic
    float breathDb[kNoiseBands] = {-120, -120, -120, -120};
    float chiffDb[kNoiseBands] = {-120, -120, -120, -120};
    float unisonCents = 0, lifeCents = 0, vibratoHz = 0, vibratoCents = 0;
    bool ok = false;
    // SILVETON_MODEL_CLEAN_V1: the learned pitch is not in the harmonics (the first three are all 40 dB under the strongest - the
    // recording sounds in another octave than its note, the teacher measured it at the note). The tone of such a zone is NOT laid
    // over the blend (it would be a comb that makes the sound nasty); its attack, breath and movement still are.
    bool pitchDoubt = false;
    // SILVETON_SYNTH_V1: the harmonics frame by frame as the teacher heard them, for SILVETON SYNTH (which plays them, no recording):
    // trackRows rows of trackH values, quantized dB (0.5 dB a step, 255 = none); the first attackRows rows are the attack, 5 ms each,
    // the rest the steady part (cycled while the note holds)
    std::vector<std::uint8_t> harmTrack;
    int trackRows = 0, attackRows = 0, trackH = 0;
    // SILVETON_FULLTRACK_V1 (Цветомир, 04.11.2026: "искам звукът да излезе както го е направил тийчър"): TEACHER 2.1 writes the whole sound -
    // the first attackRows rows run from the start of the sound to its END, 5 ms each (the 32 rows after them are the steady snapshots).
    // The file does not say so; it is recognised by its length (parseLearnedModels): a file with a track longer than the 0.6 s TEACHER 2.0
    // kept is a full-track file, and then every zone in it is. Such a zone is played from its first row to its last (SynthVoice.cpp);
    // zones of older files are played as before (the steady spectrum).
    bool fullTrack = false;
    bool looped = false;                   // the sample of the zone has a loop (flag bit 1 of the file)
    float loopMs = 0.0F;                   // the length of that loop
    float peakDb[kHarmonics] = {};         // fullTrack: the harmonics of the loudest 100 ms (by ear), dB (-200 = not there) - the loudness reference
};
constexpr int kOldMaxAttackRows = 120;     // TEACHER 2.0 never wrote more than 0.6 s of attack
constexpr float kLongLoopMs = 300.0F;      // a loop this long is replayed with its own movement; a shorter one holds the steady snapshot
[[nodiscard]] inline double harmTrackDb(std::uint8_t q) noexcept { return q >= 255U ? -200.0 : -0.5 * static_cast<double>(q); }

struct ModelShape {
    std::string name;                      // the sound's name in the teacher
    std::string slot;                      // the player's word for it
    std::vector<ZoneShape> zones;
    [[nodiscard]] int zoneFor(int key) const noexcept;   // -1 = none
    [[nodiscard]] bool anyPitchDoubt() const noexcept { for (const auto& z : zones) if (z.ok && z.pitchDoubt) return true; return false; }
};

struct LearnedModels {
    std::string path;
    std::string error;                     // "" = loaded
    std::vector<ModelShape> models;        // MODEL 1 = models[0]
    std::size_t total = 0;                 // SILVETON_MODELS_FROM_FILE_V1: how many sounds the file holds (models may be fewer: the first kMaxModels are used)
    [[nodiscard]] const ModelShape* model(int oneBased) const noexcept { return oneBased >= 1 && oneBased <= static_cast<int>(models.size()) ? &models[static_cast<std::size_t>(oneBased - 1)] : nullptr; }
};

// Reads SILVETON_OSC.sv of the teacher ("SVOSC002" / "SVOSC003"). Never throws: the error is in the result. An old wave file of the
// LAB ("SVOSC001") is not a model file and gives an error that says so.
[[nodiscard]] std::shared_ptr<const LearnedModels> loadLearnedModels(const std::string& file);
[[nodiscard]] std::shared_ptr<const LearnedModels> parseLearnedModels(const std::vector<std::uint8_t>& bytes, const std::string& path);
// SILVETON_MODELS_FROM_FILE_V1 (Цветомир, 04.11.2026: "махни моделите, които са вградени в семплера ... да мога да ги трия и да не се появяват след като
// включа семплера"): NO model is built into the sampler. The models are exactly the sounds of SILVETON_OSC.sv next to the bank, in the order of the file
// (MODEL 1 = the first sound of the file). No file = no models.
//
// Takes sounds out of SILVETON_OSC.sv for good. `indices` are 0-based places in the file (= MODEL n - 1). The file is written anew beside itself
// (name + ".new"), read back (every sound in its place, nothing else), and only then takes the old file's place; any failure leaves the old file as it was.
// Returns "" when done, else the reason.
[[nodiscard]] std::string removeLearnedSounds(const std::string& file, const std::vector<int>& indices);
// the same on bytes (for the tests): the new file's bytes; false = the reason is in `why`
[[nodiscard]] bool removeSoundsFromBytes(const std::vector<std::uint8_t>& bytes, const std::vector<int>& indices, std::vector<std::uint8_t>& out, std::string& why);

} // namespace silveton::sampler::model
