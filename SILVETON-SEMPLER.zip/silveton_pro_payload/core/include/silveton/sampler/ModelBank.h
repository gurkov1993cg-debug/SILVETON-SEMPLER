#pragma once
// SILVETON_MODEL_V1 - what SILVETON TEACHER learned, as the engine uses it.
//
// SILVETON_OSC.sv (next to SILVETON_BANK.sv) holds, for every studied sound and every sample of it: the harmonics frame by frame
// (the attack, then the steady part), the noise in eight bands, the pitch of the attack, and the numbers (breath, chiff, vibrato,
// life, unison, attack, release ...). Here that becomes a ModelShape: per zone of keys a tone curve on 32 bands, a loudness curve
// in time, a pitch curve of the attack, the breath - the things the engine lays over a blend. A blend put into the engine gets the
// same kind of curves measured from its own samples (ModelAnalyze), so the engine can move it from its own shape towards the model's.
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::sampler::model {

constexpr int kBands = 32;                 // the tone curve: 32 bands, a third of an octave each, from 50 Hz up (see bandHz)
constexpr int kLevelFrames = 120;          // the loudness curve: 10 ms a frame, 1.2 s
constexpr float kLevelFrameMs = 10.0F;
constexpr int kScoopFrames = 60;           // the pitch of the attack: 5 ms a frame, 300 ms
constexpr float kScoopFrameMs = 5.0F;
constexpr int kNoiseBands = 4;             // the breath, as the engine makes it: low / mid / high / air
constexpr int kHarmonics = 48;             // the harmonics kept as they are (the tone curve is their smooth picture)
[[nodiscard]] float bandHz(int band) noexcept;            // the centre of a tone band
[[nodiscard]] float bandOfHz(float hz) noexcept;          // the (fractional) band a frequency falls in

// one zone of keys of a learned sound, or of a blend measured here (the same shape, so the two can be compared)
struct ZoneShape {
    int lowKey = 0, topKey = 127, rootKey = 60;
    int octaveShift = 0;                   // the sample sounds this many octaves away from its note (a learned sound only)
    float f0Hz = 0;                        // the pitch it was measured at
    float tone[kBands] = {};               // dB against the strongest band (<= 0), the steady part
    float harmDb[kHarmonics] = {};         // the harmonics themselves, dB against the strongest (-120 = not there / not measured), the steady part
    float level[kLevelFrames] = {};        // dB against the steady loudness, from the start of the note (0 after the attack settles)
    float scoop[kScoopFrames] = {};        // cents against the steady pitch, the start of the note
    float steadyRms = 0;                   // the loudness of the steady part, linear (a blend: absolute; a model: against its strongest harmonic)
    float attackMs = 0, releaseMs = -1;
    // the breath (a learned sound): the steady noise and the attack's extra noise, per engine band, dB against the strongest harmonic
    float breathDb[kNoiseBands] = {-120, -120, -120, -120};
    float chiffDb[kNoiseBands] = {-120, -120, -120, -120};
    float unisonCents = 0, lifeCents = 0, vibratoHz = 0, vibratoCents = 0;
    bool ok = false;
    // SILVETON_MODEL_CLEAN_V1: the learned pitch is not in the harmonics (the first three are all 40 dB under the strongest - the
    // recording sounds in another octave than its note, the teacher measured it at the note). The tone of such a zone is NOT laid
    // over the blend (it would be a comb that makes the sound nasty); its attack, breath and movement still are.
    bool pitchDoubt = false;
    // SILVETON_SYNTH_V1: the harmonics frame by frame as the teacher heard them, for SILVETON SYNTH (which plays them, no recording):
    // trackRows rows of trackH values, quantized dB (0.5 dB a step, 255 = none); the first attackRows rows are the attack, 5 ms each,
    // the rest the steady part (cycled while the note holds)
    std::vector<std::uint8_t> harmTrack;
    int trackRows = 0, attackRows = 0, trackH = 0;
};
[[nodiscard]] inline double harmTrackDb(std::uint8_t q) noexcept { return q >= 255U ? -200.0 : -0.5 * static_cast<double>(q); }

struct ModelShape {
    std::string name;                      // the sound's name in the teacher
    std::string slot;                      // the player's word for it
    std::vector<ZoneShape> zones;
    [[nodiscard]] int zoneFor(int key) const noexcept;   // -1 = none
    [[nodiscard]] bool anyPitchDoubt() const noexcept { for (const auto& z : zones) if (z.ok && z.pitchDoubt) return true; return false; }
};

struct LearnedModels {
    std::string path;
    std::string error;                     // "" = loaded
    std::vector<ModelShape> models;        // MODEL 1 = models[0]
    [[nodiscard]] const ModelShape* model(int oneBased) const noexcept { return oneBased >= 1 && oneBased <= static_cast<int>(models.size()) ? &models[static_cast<std::size_t>(oneBased - 1)] : nullptr; }
};

// Reads SILVETON_OSC.sv of the teacher ("SVOSC002" / "SVOSC003"). Never throws: the error is in the result. An old wave file of the
// LAB ("SVOSC001") is not a model file and gives an error that says so.
[[nodiscard]] std::shared_ptr<const LearnedModels> loadLearnedModels(const std::string& file);
[[nodiscard]] std::shared_ptr<const LearnedModels> parseLearnedModels(const std::vector<std::uint8_t>& bytes, const std::string& path);
// The models built into the sampler (ModelBuiltin.cpp): MODEL 1 = Radi Pa5x Sound, MODEL 2 = Radi Taksim 2024 - always there.
[[nodiscard]] std::shared_ptr<const LearnedModels> builtinLearnedModels();
// the built-in ones first, then the models of a file next to the bank (MODEL 3 ...); a file that failed leaves its error in the result
[[nodiscard]] std::shared_ptr<const LearnedModels> mergeLearnedModels(const std::shared_ptr<const LearnedModels>& builtin, const std::shared_ptr<const LearnedModels>& file);

} // namespace silveton::sampler::model
