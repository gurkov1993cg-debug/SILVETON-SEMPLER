#pragma once
// Data-file metadata retained for reading existing Teacher bank containers.
// No model audio engine, oscillator parameters or renderer are defined here.
namespace silveton::sampler::model {constexpr int kMaxModels=255;}
