#pragma once
// SILVETON_MODEL_V1 / SILVETON_SYNTH_V1 (Цветомир, 03.11.2026) - the numbers of a place's engine row that SILVETON SYNTH reads.
//
// SILVETON SYNTH has no recording: its sound is CALCULATED from a MODEL - what SILVETON TEACHER learned from another instrument. The
// learned models are built into the program (ModelBuiltin.cpp). SILVETON MODEL, the engine that bent a recording of the bank towards a
// model, was removed on 03.11.2026 ("силветон модел го махаш"); the ids and the filter block below stay because SILVETON SYNTH uses them.
//
// The numbers live in the 64-value engine row of a part (EngineParams::p): 0..23 the common block (the filter), 24.. the knobs,
// 60..63 the keys every engine has. All our own calculation: nothing of any other instrument is in here.
#include "silveton/sampler/EngineDefs.h"

namespace silveton::sampler::model {

enum ModelId : int {
    MO_MODEL = 24,     // 0 = none, 1..kMaxModels = MODEL n
    MO_AMOUNT = 25,    // (retired with SILVETON MODEL: SYNTH keeps it at 100 %)
    MO_TUNE = 26,      // SYNTH: (retired 03.11.2026 18:26 - the old FORMANT SHIFT; the sampler's own TUNE moves the timbre now)
    MO_BRIGHT = 27,    // dB per octave
    MO_SCOOP = 28,     // % of the model's attack pitch (how far below / above it starts)
    MO_CHIFF = 29,     // (retired: no noise)
    MO_BREATH = 30,    // (retired: no noise)
    MO_LIFE = 31,      // % of the model's trembling
    MO_UNISON = 32,    // % of the model's unison spread
    MO_VIBRATO = 33,   // % of the model's own vibrato
    MO_SHAPE = 34,     // % how much the attack of the harmonics follows the model
    MO_FORMANT = 35    // SYNTH: HARMONICS - how many harmonics are calculated
};

constexpr int kMaxModels = 255;   // SILVETON_MODELS_255_V1 (Цветомир, 04.11.2026): the teacher studied 200 sounds, 32 cut them off

[[nodiscard]] EngineParamPage filterPage() noexcept;                  // the FILTER page both pages of SYNTH end with
void setDefaults(float* p) noexcept;                                   // the filter + the common block of the 64-value row
[[nodiscard]] inline int modelIndex(const float* p) noexcept { const int m = static_cast<int>(p[MO_MODEL] + 0.5F); return m < 1 || m > kMaxModels ? 0 : m; }   // 0 = none

} // namespace silveton::sampler::model

// SILVETON_SYNTH_V1 - SILVETON SYNTH: the sound is CALCULATED from the learned model (its harmonics frame by frame, its pitch curve, its
// life and vibrato) - no recording at all. One id means something special here: HARMONICS (the FORMANT id: how many harmonics are
// calculated). (The old FORMANT SHIFT, the TUNE id, is retired: the TUNE of the place moves the timbre - SamplerEngine.cpp synthTuneKeys.)
namespace silveton::sampler::synth {
constexpr int SY_MODEL = model::MO_MODEL, SY_SHIFT = model::MO_TUNE, SY_BRIGHT = model::MO_BRIGHT, SY_HARMONICS = model::MO_FORMANT,
              SY_SHAPE = model::MO_SHAPE, SY_SCOOP = model::MO_SCOOP, SY_UNISON = model::MO_UNISON, SY_LIFE = model::MO_LIFE, SY_VIBRATO = model::MO_VIBRATO;
constexpr int kPages = 2;   // ВРЪТКИ · FILTER
[[nodiscard]] const char* pageName(int page) noexcept;
[[nodiscard]] EngineParamPage page(int page) noexcept;
void setDefaults(float* p) noexcept;
} // namespace silveton::sampler::synth
