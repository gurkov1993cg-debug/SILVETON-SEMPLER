#pragma once
// SILVETON_MODEL_V1 (Цветомир, 03.11.2026) - SILVETON MODEL, the one engine of the sampler. It has NO sound of its own: a sound of
// the bank (a blend, with all its samples) is put into it, and a MODEL - what SILVETON TEACHER learned from another instrument -
// is laid over that sound: not mixed with it, but CHANGING it. The blend keeps playing as itself; the model bends its tone towards
// the learned tone (the formants, the brightness), starts its attack the way the teacher's sound starts (the scoop of the pitch,
// the chiff), reshapes its loudness in time (the pluck or the swell), detunes copies of it (the unison), makes it tremble (life,
// vibrato), adds the breath. The AMOUNT knob says how far from itself towards the model the blend goes. TUNE here is the special
// one: it moves only the timbre (the vowel of the sound), never the pitch. Nothing a knob does makes the sound quieter: the engine
// levels itself (the old engine's fault).
//
// The learned models come from SILVETON_OSC.sv next to SILVETON_BANK.sv (SILVETON TEACHER writes it): MODEL 1, 2, 3 ... in the
// order of the file. The numbers live in the 64-value engine row of a part (EngineParams::p): 0..23 the common block (the filter),
// 24.. the model knobs, 60..63 the keys every engine has. All our own calculation: nothing of any other instrument is in here.
#include "silveton/sampler/EngineDefs.h"

namespace silveton::sampler::model {

enum ModelId : int {
    MO_MODEL = 24,     // 0 = none, 1..kMaxModels = MODEL n of the file
    MO_AMOUNT = 25,    // % how far towards the model
    MO_TUNE = 26,      // semitones: the timbre (the formants) moves, the pitch does not
    MO_BRIGHT = 27,    // dB per octave, on top of the model
    MO_SCOOP = 28,     // % of the model's attack pitch (how far below / above it starts)
    MO_CHIFF = 29,     // dB, the noise of the attack against the model's
    MO_BREATH = 30,    // dB, the steady breath against the model's
    MO_LIFE = 31,      // % of the model's trembling
    MO_UNISON = 32,    // % of the model's unison spread
    MO_VIBRATO = 33,   // % of the model's own vibrato
    MO_SHAPE = 34,     // % how much the loudness in time follows the model (the pluck / the swell)
    MO_FORMANT = 35    // % how strongly the model's formants are pressed on (the EQ depth)
};

constexpr int kMaxModels = 32;
constexpr int kPages = 2;                 // MODEL · FILTER (ENV and PLAY are the part's own pages)

[[nodiscard]] const char* pageName(int page) noexcept;
[[nodiscard]] EngineParamPage page(int page) noexcept;
[[nodiscard]] int firstRow(int page) noexcept;
void setDefaults(float* p) noexcept;
[[nodiscard]] inline int modelIndex(const float* p) noexcept { const int m = static_cast<int>(p[MO_MODEL] + 0.5F); return m < 1 || m > kMaxModels ? 0 : m; }   // 0 = none
[[nodiscard]] inline float amount(const float* p) noexcept { const float a = p[MO_AMOUNT]; return a < 0.0F ? 0.0F : (a > 1.0F ? 1.0F : a); }
// the special TUNE in whole semitones (Korg "pitch stretch"): the sampler chooses the recording of the key + stretch and plays it
// stretch semitones lower - the same pitch, another recording, so only the timbre moves
[[nodiscard]] inline int stretchSemis(const float* p) noexcept { const float t = p[MO_TUNE]; const int s = static_cast<int>(t < 0.0F ? t - 0.5F : t + 0.5F); return s < -12 ? -12 : (s > 12 ? 12 : s); }

} // namespace silveton::sampler::model
