#pragma once

#include "silveton/sampler/ModelBank.h"        // SILVETON_MODEL_V1
#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/SincInterpolator.h"
#include "silveton/sampler/WaveTable.h"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>

namespace silveton::sampler {

enum class EventType : std::uint8_t {
    NoteOn,
    NoteOff,
    ControlChange,
    PitchBend,
    ChannelPressure,
    Panic
};

struct RealtimeEvent {
    EventType type{EventType::NoteOn};
    std::uint8_t channel{0};
    std::uint8_t data1{0};
    std::uint8_t data2{0};
    std::int16_t pitchBend{0};
};

// SILVETON_MIDI_MPSC_V1: the events of the players to the audio thread. Several threads post into it (the MIDI input thread,
// the screen: PANIC, test notes, a host's own MIDI) and only the audio thread reads - a bounded multi-producer / single-consumer
// ring (a sequence number per slot), no lock, no allocation, no waiting on either side.
//   - Inside one producer the order is kept exactly; between producers the order is the order in which they took a slot.
//   - The last kReserve slots are kept for the events that must never be lost: NOTE OFF, SUSTAIN (CC64), ALL NOTES / SOUND OFF
//     (CC120 / CC123), PANIC. The other events (NOTE ON, the other CCs, pitch bend, pressure) are refused when only the reserve is
//     left, and counted (droppedCount).
//   - If even the reserve is full, a NOTE OFF / SUSTAIN OFF / ALL OFF / PANIC is not lost: it is noted in a bit (per channel and
//     key) that the audio thread turns back into the event after the queue (deferredCount). A later NOTE ON of the same key
//     (or SUSTAIN ON of the channel) first puts the noted OFF into the queue, so the order OFF -> ON stays right; if that is
//     impossible the NOTE ON is refused (the key is not left stuck).
class RealtimeEventQueue {
public:
    static constexpr std::size_t kCapacity = 2048U;   // a power of two
    static constexpr std::size_t kReserve = 256U;

    RealtimeEventQueue() noexcept;
    bool push(const RealtimeEvent& event) noexcept;   // any thread
    bool pop(RealtimeEvent& event) noexcept;          // the audio thread only
    [[nodiscard]] std::uint64_t droppedCount() const noexcept { return dropped_.load(std::memory_order_relaxed); }
    [[nodiscard]] std::uint64_t deferredCount() const noexcept { return deferred_.load(std::memory_order_relaxed); }
    // the audio thread only (or while it does not run): forget what is queued; the noted OFFs stay (they free keys)
    void clear() noexcept;

private:
    struct Slot {
        std::atomic<std::size_t> seq{0U};
        RealtimeEvent event{};
    };
    static bool critical(const RealtimeEvent& e) noexcept;
    bool pushRing(const RealtimeEvent& e, bool mayUseReserve) noexcept;
    void notePending(const RealtimeEvent& e) noexcept;
    bool resolvePending(const RealtimeEvent& e) noexcept;   // before a NOTE ON / SUSTAIN ON: the noted OFF first
    bool popPending(RealtimeEvent& event) noexcept;

    std::array<Slot, kCapacity> slots_{};
    alignas(64) std::atomic<std::size_t> enqueue_{0U};
    alignas(64) std::atomic<std::size_t> dequeue_{0U};
    std::atomic<std::uint64_t> dropped_{0U};
    std::atomic<std::uint64_t> deferred_{0U};
    // the noted OFFs: 16 channels x 128 keys, sustain off / all off per channel, panic
    std::array<std::atomic<std::uint64_t>, 32> offBits_{};
    std::atomic<std::uint32_t> sustainOffBits_{0U};
    std::atomic<std::uint32_t> allOffBits_{0U};
    std::atomic<bool> panicPending_{false};
    std::atomic<bool> pendingHint_{false};
};

struct MeterSnapshot {
    float peakLeft{0.0F};
    float peakRight{0.0F};
    float limiterGainReductionDb{0.0F};
    std::uint32_t activeVoices{0U};
    std::uint64_t droppedEvents{0U};
    std::array<float, kPartCount> upperPeakLeft{};
    std::array<float, kPartCount> upperPeakRight{};
    // SILVETON_CPU_METER_V1: DSP time of the last block / block length, percent
    // (set by the caller of render() that measures the time; the engine keeps it).
    float cpuLoadPercent{0.0F};
    // SILVETON_MULTICORE_V1: how many cores shared the last block (1 = only the audio thread)
    std::uint8_t coresWorking{1U};
};

// Values the TONE page shows for an Upper (its own or the PROGRAM default).
struct UpperToneValues {
    float attackMs{5.0F};
    float decayMs{80.0F};
    float sustain{1.0F};
    float releaseMs{120.0F};
    float cutoffHz{kToneCutoffOpenHz};
    float resonance{0.0F};
};
[[nodiscard]] UpperToneValues effectiveUpperTone(const UpperPart& upper) noexcept;
// Same for a layer of an Upper (0..3).
[[nodiscard]] UpperToneValues effectiveLayerTone(const UpperLayer& layer) noexcept;
// SILVETON_TONE_V2: the basic sound of an Upper as one SoundTone (its six legacy
// values plus toneExtra), so the engine treats it exactly like a layer.
[[nodiscard]] SoundTone basicSoundTone(const UpperPart& upper) noexcept;
// SILVETON_POLYSIX_V1: built-in single-cycle waves (SAW, SQUARE, PULSE 25, TRIANGLE, SINE,
// SAW WARM) as ordinary multisample PROGRAMs: one band-limited table per octave, so the
// sampler plays them like any recording (and PWM / SUB / UNISON / filters apply the same).
// index 0..kBuiltinWaveCount-1; nullptr for others. Built once, shared.
[[nodiscard]] ProgramPtr builtinWaveProgram(int index);
[[nodiscard]] const char* builtinWaveName(int index) noexcept;
// SILVETON_OFS_V1: the velocity layers of a sound - the lowest velocity of each, hardest first (MS1, MS2 ...)
[[nodiscard]] std::vector<int> velocityZoneBottoms(const Program& program);
// ... and which of them (0 = MS1 .. kOfsZones - 1) a zone of a layer of that sound is
[[nodiscard]] int velocityZoneIndex(const Program& program, const ProgramLayer& layer, const SampleZone& zone) noexcept;

class SamplerEngine {
public:
    // Bank memory range a playing voice will read soon (published by the audio
    // thread, read by SampleStreamPrefetcher; lock-free).
    struct StreamWindow {
        std::uintptr_t begin{0U};
        std::size_t bytes{0U};
    };
    // Spare voices used only to let a voice that was taken over (voice limit)
    // fade out for 4 ms; they never start new notes, so polyphony stays 128.
    static constexpr std::size_t kTakeoverTailVoices = 16U;
    static constexpr std::size_t kMaxStreamWindows =
        (static_cast<std::size_t>(kMaxVoices) + kTakeoverTailVoices) * 2U;

    SamplerEngine();
    ~SamplerEngine();

    SamplerEngine(const SamplerEngine&) = delete;
    SamplerEngine& operator=(const SamplerEngine&) = delete;

    void prepare(double sampleRate, std::uint32_t maximumBlockFrames);
    void reset() noexcept;

    // PORTA BALANCE of the SILVETON keyboard processor (3..40, default 11):
    // how its Korg glide model turns TIME into a glide for each interval.
    // SILVETON_VOICE_CEILING_V1: how many notes may sound at once (8...128; 128 = as before).
    // At the ceiling the quietest note fades out and gives its place away.
    void setVoiceCeiling(int voices) noexcept;
    [[nodiscard]] int voiceCeiling() const noexcept;

    // SILVETON_MULTICORE_V1: how many cores render the voices (1 = one core, as before).
    void setRenderThreads(int threads) noexcept;
    [[nodiscard]] int renderThreads() const noexcept;
    void setPortamentoBalance(float balance) noexcept;
    // SILVETON_TERCA_V1: TERCA of the SILVETON processor. upperMask = the Uppers
    // with their T key on (bit 0 = Upper 1), 0 = off. cell 0..5 = MajorUp,
    // MajorDown, MinorUp, MinorDown, PhrygianUp, HijazUp (the SCAN result);
    // root 0..11 = tonic. Those Uppers play the diatonic third of every key.
    void setTerca(int upperMask, int root, int cell) noexcept;
    // SILVETON_SCALE_V1: the Uppers with their Q key on use the GLOBAL scale cents.
    void setScaleUppers(int upperMask) noexcept;
    // Third of `key` for a tonality (exactly the processor's rule), -1 = none.
    [[nodiscard]] static int tercaHarmony(int root, int cell, int key) noexcept;
    [[nodiscard]] float portamentoBalance() const noexcept;
    void setPortamentoNear(float ms) noexcept;            // SILVETON_PORTA_NEAR_V1
    [[nodiscard]] float portamentoNear() const noexcept;

    // Control thread publishes a fully prepared immutable graph. The audio thread
    // adopts it at a block boundary; Direct ALSA is never stopped for SOUND/COMBI changes.
    void setState(std::shared_ptr<const EngineState> state) noexcept;
    // SILVETON_TRANSWAVE_V1: the wave tables made for the sounds of the state (control thread; give them BEFORE the state).
    // nullptr = no sound uses a table. The caller keeps older maps alive for a while, so nothing big is freed in the audio callback.
    void setWaveTables(std::shared_ptr<const WaveTableMap> tables) noexcept;
    // SILVETON_SYNTH_V1: the learned models of SILVETON SYNTH (built into the program), adopted at a block boundary; the
    // caller keeps the set before alive for a while (the notes that sound look their model up again in the new set). nullptr = none.
    void setLearnedModels(std::shared_ptr<const model::LearnedModels> models) noexcept;
    [[nodiscard]] std::shared_ptr<const model::LearnedModels> learnedModels() const noexcept;   // (control thread) the newest set given
    [[nodiscard]] std::shared_ptr<const EngineState> state() const noexcept {
        return std::atomic_load_explicit(&state_, std::memory_order_acquire);
    }

    void setInterpolationQuality(InterpolationQuality quality) noexcept { interpolator_.setQuality(quality); }
    [[nodiscard]] InterpolationQuality interpolationQuality() const noexcept { return interpolator_.quality(); }

    bool postNoteOn(std::uint8_t channel, std::uint8_t key, std::uint8_t velocity) noexcept;
    bool postNoteOff(std::uint8_t channel, std::uint8_t key, std::uint8_t velocity = 0U) noexcept;
    bool postControlChange(std::uint8_t channel, std::uint8_t cc, std::uint8_t value) noexcept;
    bool postPitchBend(std::uint8_t channel, std::int16_t value) noexcept;
    bool postChannelPressure(std::uint8_t channel, std::uint8_t value) noexcept;
    bool postPanic() noexcept;

    // Stereo interleaved float output. No allocations or locks occur here.
    void render(float* interleavedStereo, std::uint32_t frames) noexcept;

    [[nodiscard]] MeterSnapshot meters() const noexcept;
    [[nodiscard]] std::uint32_t activeVoiceCount() const noexcept;
    [[nodiscard]] std::uint64_t droppedEventCount() const noexcept { return events_.droppedCount(); }

    // Any thread, no locks. false = slot changed while reading (try next pass).
    bool readStreamWindow(std::size_t slot, StreamWindow& out) const noexcept;
    // How far ahead of each voice the bank is brought into memory (seconds).
    void setStreamLookaheadSeconds(double seconds) noexcept;
    // SILVETON_ANALYZER_V1: the screen analyzer taps one Upper (mono, before or
    // after its common EQ). upper < 0 = off (costs nothing). readAnalyzer copies
    // the newest `frames` samples (oldest first); display only, no locks.
    void setAnalyzerTap(int upper, bool afterEq) noexcept;
    void readAnalyzer(float* out, std::size_t frames) const noexcept;
    static constexpr std::size_t kAnalyzerRing = 16384U;

public:
    struct Impl; // internal DSP state; exposed only for translation-unit helpers

private:
    std::unique_ptr<Impl> impl_;
    std::shared_ptr<const EngineState> state_;
    std::shared_ptr<const EngineState> pendingState_;
    std::shared_ptr<const WaveTableMap> pendingWave_;
    std::atomic<bool> wavePending_{false};
    std::shared_ptr<const model::LearnedModels> pendingModels_;   // SILVETON_MODEL_V1
    std::atomic<bool> modelsPending_{false};
    RealtimeEventQueue events_;
    SincInterpolator interpolator_;
    SincInterpolator subInterpolator_{InterpolationQuality::LiveCubic4};   // SILVETON_SYNTH_LIGHT_V1: SUB read
    SincInterpolator sinc16Interpolator_{InterpolationQuality::High16};    // SILVETON_ENGINES_V2: HD-1 INTERP choices
    SincInterpolator sinc32Interpolator_{InterpolationQuality::Ultra32};
};

} // namespace silveton::sampler
