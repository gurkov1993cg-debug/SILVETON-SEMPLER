#pragma once

#include "silveton/sampler/SetPackage.h"
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace silveton::sampler {

struct BankMergeResult {
    bool success{false};
    std::string error;
};


struct ProgramCatalogItem {
    SlotAddress address{};
    std::string name;
};

struct KorgLibraryImportResult {
    bool success{false};
    std::vector<std::uint32_t> sampleIds;
    std::vector<std::uint32_t> multisampleIds;
    std::vector<std::string> warnings;
    std::string error;
};

class SamplerLibrary {
public:
    explicit SamplerLibrary(std::string setName = "SILVETON SET") : setName_(std::move(setName)) {}

    void setSetName(std::string name) { setName_ = std::move(name); }
    [[nodiscard]] const std::string& setName() const noexcept { return setName_; }

    void setGlobal(const GlobalState& state) noexcept { global_ = state; }
    [[nodiscard]] const GlobalState& global() const noexcept { return global_; }

    bool writeSample(std::uint32_t id, SamplePtr sample);
    bool writeMultisample(std::uint32_t id, MultisamplePtr multisample);
    bool writeProgram(const SlotAddress& address, ProgramPtr program);
    bool writeCombi(const SlotAddress& address, const Combi& combi);
    bool writeList(const SlotAddress& address, const SetList& list);

    [[nodiscard]] KorgLibraryImportResult importKmp(const std::string& path);
    [[nodiscard]] KorgLibraryImportResult importKsc(const std::string& path);
    [[nodiscard]] std::vector<std::uint32_t> multisampleIds() const;
    [[nodiscard]] std::vector<std::string> multisampleNames() const;

    [[nodiscard]] bool hasProgram(const SlotAddress& address) const;
    [[nodiscard]] bool hasCombi(const SlotAddress& address) const;
    [[nodiscard]] bool hasList(const SlotAddress& address) const;
    bool renameProgram(const SlotAddress& address, const std::string& name);
    bool renameCombi(const SlotAddress& address, const std::string& name);
    bool renameList(const SlotAddress& address, const std::string& name);
    bool copyProgram(const SlotAddress& from, const SlotAddress& to, bool overwrite);
    bool copyCombi(const SlotAddress& from, const SlotAddress& to, bool overwrite);
    bool copyList(const SlotAddress& from, const SlotAddress& to, bool overwrite);
    bool moveList(const SlotAddress& from, const SlotAddress& to, bool overwrite);
    bool setListEntry(const SlotAddress& address, std::size_t index, const ListEntry& entry);
    bool insertListEntry(const SlotAddress& address, std::size_t index, const ListEntry& entry);
    bool removeListEntry(const SlotAddress& address, std::size_t index);
    bool moveListEntry(const SlotAddress& address, std::size_t fromIndex, std::size_t toIndex);

    [[nodiscard]] SamplePtr sample(std::uint32_t id) const;
    [[nodiscard]] MultisamplePtr multisample(std::uint32_t id) const;
    [[nodiscard]] ProgramPtr program(const SlotAddress& address) const;
    [[nodiscard]] std::vector<ProgramCatalogItem> programCatalog() const;
    [[nodiscard]] std::optional<Combi> combi(const SlotAddress& address) const;
    [[nodiscard]] std::optional<SetList> list(const SlotAddress& address) const;

    bool clearSample(std::uint32_t id);
    bool clearMultisample(std::uint32_t id);
    bool clearProgram(const SlotAddress& address);
    bool clearCombi(const SlotAddress& address);
    bool clearList(const SlotAddress& address);

    [[nodiscard]] SetData snapshot() const;
    [[nodiscard]] SetData snapshotBank(std::uint16_t bank) const;
    [[nodiscard]] BankMergeResult mergeBank(const SetData& data, std::uint16_t targetBank, bool overwrite);
    void replace(const SetData& data);

private:
    [[nodiscard]] KorgLibraryImportResult importKorgResources(
        const std::vector<MultisamplePtr>& multisamples,
        const std::vector<SamplePtr>& samples,
        std::vector<std::string> warnings);
    struct AddressLess {
        bool operator()(const SlotAddress& a, const SlotAddress& b) const noexcept {
            if (a.bank != b.bank) return a.bank < b.bank;
            if (a.page != b.page) return a.page < b.page;
            return a.slot < b.slot;
        }
    };

    std::string setName_;
    GlobalState global_{};
    std::map<std::uint32_t, SamplePtr> samples_;
    std::map<std::uint32_t, MultisamplePtr> multisamples_;
    std::map<SlotAddress, ProgramPtr, AddressLess> programs_;
    std::map<SlotAddress, Combi, AddressLess> combis_;
    std::map<SlotAddress, SetList, AddressLess> lists_;
};

} // namespace silveton::sampler
