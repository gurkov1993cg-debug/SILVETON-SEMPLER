#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace silveton::sampler {

struct SlotAddress {
    std::uint16_t bank{0};
    std::uint16_t page{0};
    std::uint16_t slot{0};
    [[nodiscard]] bool operator==(const SlotAddress& o) const noexcept {
        return bank == o.bank && page == o.page && slot == o.slot;
    }
};

struct SampleCatalogEntry { std::uint32_t id{0}; SamplePtr sample; };
struct MultisampleCatalogEntry { std::uint32_t id{0}; MultisamplePtr multisample; };
struct ProgramSlot { SlotAddress address{}; ProgramPtr program; };
struct CombiSlot { SlotAddress address{}; Combi combi{}; };
struct ListSlot { SlotAddress address{}; SetList list{}; };

// The open performance is independent of the COMBIs stored by WRITE. Saving a
// SET must preserve edits without silently replacing any stored LIST blend.
struct PerformanceSnapshot {
    Combi combi{};
    std::optional<SlotAddress> activeListAddress;
    int activeListEntry{-1};
    bool edited{false};
};

struct SetData {
    std::string name;
    GlobalState global{};
    std::vector<SampleCatalogEntry> samples;
    std::vector<MultisampleCatalogEntry> multisamples;
    std::vector<ProgramSlot> programs;
    std::vector<CombiSlot> combis;
    std::vector<ListSlot> lists;
    std::string extra;   // SILVETON_SET_ONE_FILE_V1: the T / Q text of the app - it travels inside the set, no side file
    std::optional<PerformanceSnapshot> performance; // optional extension; absent in older SETs
};

struct SetPackageResult {
    bool success{false};
    std::string error;
};

struct SetLoadResult {
    SetData data{};
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return error.empty(); }
};

class SetPackage {
public:
    // A reference-only .SVSET is one file. A package with embedded audio is a
    // directory containing manifest.svs and audio/ with original source bytes.
    [[nodiscard]] static SetPackageResult save(const std::string& packageDirectory, const SetData& data);
    [[nodiscard]] static SetLoadResult load(const std::string& packageDirectory);
};

} // namespace silveton::sampler
