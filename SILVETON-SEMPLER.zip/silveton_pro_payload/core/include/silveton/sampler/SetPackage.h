#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::sampler {

struct SlotAddress {
    std::uint16_t bank{0};
    std::uint16_t page{0};
    std::uint16_t slot{0};
    [[nodiscard]] bool operator==(const SlotAddress& o) const noexcept {
        return bank == o.bank && page == o.page && slot == o.slot;
    }
};

struct SampleCatalogEntry { std::uint32_t id{0}; SamplePtr sample; };
struct MultisampleCatalogEntry { std::uint32_t id{0}; MultisamplePtr multisample; };
struct ProgramSlot { SlotAddress address{}; ProgramPtr program; };
struct CombiSlot { SlotAddress address{}; Combi combi{}; };
struct ListSlot { SlotAddress address{}; SetList list{}; };

struct SetData {
    std::string name;
    GlobalState global{};
    std::vector<SampleCatalogEntry> samples;
    std::vector<MultisampleCatalogEntry> multisamples;
    std::vector<ProgramSlot> programs;
    std::vector<CombiSlot> combis;
    std::vector<ListSlot> lists;
};

struct SetPackageResult {
    bool success{false};
    std::string error;
};

struct SetLoadResult {
    SetData data{};
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return error.empty(); }
};

class SetPackage {
public:
    // A .SVSET package is a directory containing manifest.svs and an audio/
    // folder with original source files. Original source bytes are copied,
    // avoiding forced sample-rate or bit-depth conversion during Save Set.
    [[nodiscard]] static SetPackageResult save(const std::string& packageDirectory, const SetData& data);
    [[nodiscard]] static SetLoadResult load(const std::string& packageDirectory);
};

} // namespace silveton::sampler
