#pragma once
#include "silveton/sampler/EngineDefs.h"
namespace silveton::sampler::solo {
enum Param:int {MorphX=0,MorphY,Brightness,Hollow,Formant,Focus,Air,Response,
 AttackMs,ReleaseMs,VibratoCents,VibratoHz,VibratoDelayMs,LevelDb,
 BreathDepth,Retrigger,Priority,BreathMode,Count};
constexpr int kPresets=3;
void defaults(float*) noexcept;
void learnedDefaults(float*,float releaseMs) noexcept;void factory(int,float*) noexcept;
const char* presetName(int) noexcept;float clamp(int,float) noexcept;
const EngineParamDef* parameter(int) noexcept;
}
