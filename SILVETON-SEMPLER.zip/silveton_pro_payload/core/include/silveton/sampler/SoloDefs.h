#pragma once
// SILVETON_SOLO_V1 (Цветомир, 02.11.2026) - SILVETON SOLO, the one engine of the sampler: a solo / lead synthesizer in the spirit of the
// classic solo machines of the Balkans (a fat, fast, singing lead): two band-limited oscillators (saw, pulse with PWM, triangle, sine and
// four phase-distorted waves whose shape an envelope opens - the "CZ" way), a sub and noise, sync, unison 1..4 with detune and width,
// a resonant filter (24 dB ladder with saturation, 12 dB low / high / band) with its envelope, key tracking and velocity, an amplifier
// envelope, vibrato from a delayed LFO, the wheel and aftertouch, soft drive, and the playing: glide time with four styles of the
// curve (CZ / DX / JS1 / JS2), legato fingered or always, pitch bend range. Everything it sounds is calculated: no recordings.
//
// The numbers live in the 64-value engine row of an Upper (EngineParams::p), in the units the screens show (Hz, ms, %, cents ...).
// The ids 0..23 are the common block of the engine row (filter, filter envelope, LFO, unison), 24..57 are its own, 60..63 the
// three keys every engine has (E_SOURCE, E_BYPASS, E_BEND_UP / DOWN). All our own code: nothing of any other instrument is in here.
#include "silveton/sampler/EngineDefs.h"

namespace silveton::sampler::solo {

enum SoloId : int {
    SO_OSC1_WAVE = 24, SO_OSC1_LEVEL = 25, SO_OSC1_OCT = 26, SO_PW = 27, SO_PWM_DEPTH = 28, SO_PWM_RATE = 29,
    SO_OSC2_WAVE = 30, SO_OSC2_LEVEL = 31, SO_OSC2_OCT = 32, SO_OSC2_SEMI = 33, SO_OSC2_FINE = 34, SO_SYNC = 35,
    SO_SUB_LEVEL = 36, SO_NOISE_LEVEL = 37,
    SO_DCW = 38, SO_DCW_KEY = 39, SO_DCW_VEL = 40, SO_DCW_A = 41, SO_DCW_D = 42, SO_DCW_S = 43, SO_DCW_R = 44,
    SO_AMP_A = 45, SO_AMP_D = 46, SO_AMP_S = 47, SO_AMP_R = 48, SO_VEL_AMP = 49,
    SO_GLIDE = 50, SO_GLIDE_STYLE = 51, SO_LEGATO = 52, SO_VIB_DELAY = 53, SO_VIB_WHEEL = 54, SO_VIB_AT = 55,
    SO_OUT_DRIVE = 56, SO_WIDTH = 57
};
// the waves of an oscillator
enum Wave : int { W_SAW = 0, W_PULSE, W_TRI, W_SINE, W_CZ_SAW, W_CZ_PULSE, W_CZ_RES1, W_CZ_RES2, kWaves };
// the curve of the glide: CZ = every interval takes the same time; DX = a time per octave (a big jump takes longer);
// JS1 = our silk curve (neighbouring keys softer and a little longer); JS2 = our musical curve (firmer start, exact arrival)
enum GlideStyle : int { GL_CZ = 0, GL_DX, GL_JS1, GL_JS2, kGlideStyles };
enum Legato : int { LG_ALWAYS = 0, LG_FINGERED, kLegatos };
// the filter of the common block, as this engine names its types
enum Filter : int { FL_OFF = 0, FL_LADDER24, FL_LP12, FL_HP12, FL_BP12, kFilters };

constexpr int kPages = 4;                 // ОСЦИЛ. · ФИЛТЪР · ОБВИВКИ · СВИРЕНЕ
constexpr int kPresets = 8;

[[nodiscard]] const char* pageName(int page) noexcept;
[[nodiscard]] EngineParamPage page(int page) noexcept;
// every value of the row at its start (the sound that plays when the engine is placed)
void setDefaults(float* p) noexcept;
// the eight built-in sounds (name, and the 64 values into `p`; the three common keys E_SOURCE / E_BYPASS / E_BEND are left as they are)
[[nodiscard]] const char* presetName(int i) noexcept;
void preset(int i, float* p) noexcept;
// a glide: the seconds for an interval of `semis` at the style of the row, from the engine's own GLIDE time (0 = no glide)
[[nodiscard]] float glideSeconds(const float* p, double semis) noexcept;
[[nodiscard]] inline bool glideOn(const float* p) noexcept { return p[SO_GLIDE] > 0.5F; }
[[nodiscard]] inline bool fingered(const float* p) noexcept { return p[SO_LEGATO] >= 0.5F; }
[[nodiscard]] inline bool musicalCurve(const float* p) noexcept { return static_cast<int>(p[SO_GLIDE_STYLE] + 0.5F) == GL_JS2; }

} // namespace silveton::sampler::solo
