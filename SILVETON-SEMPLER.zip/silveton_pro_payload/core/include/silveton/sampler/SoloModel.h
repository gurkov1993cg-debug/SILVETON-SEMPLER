#pragma once
// Shared Teacher/SOLO contract. Measurements only: no audio, phase tables or PCM.
// Immutable after prepare(); query is allocation/lock free. IO only off audio thread.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <memory>
#include <string>
#include <vector>
namespace silveton { namespace sampler { namespace solo {
constexpr int ModelHarmonics=48, MaxModelCells=4096;
enum class Phase : unsigned { Attack, Sustain, Legato, Release };
struct Condition {
 float key=60, ageMs=0, velocity=1, breath=0, expression=1, wheel=0, pressure=0, interval=0;
 Phase phase=Phase::Attack;
};
struct Spectrum {
 std::array<float,ModelHarmonics> db{};
 float sub=0, rmsDb=-90, pitchCents=0;
};
struct Cell { Condition at; Spectrum sound; std::uint32_t count=0; float ageCoordinate=0; };
struct Quality {
 std::uint32_t phrases=0, frames=0;
 float spectralDb=0, levelDb=0, pitchCents=0;
 bool approved=false;
};
struct Model {
 std::string name="LIVE SOLO";
 std::vector<Cell> cells;
 std::array<std::array<std::uint32_t,4>,128> observations{};
 Quality validation;
 float releaseMs=25;
 // Lookup references nearest measured register only. Missing registers remain unknown in the report.
 std::array<std::array<std::vector<unsigned>,4>,128> lookup;
 void prepare() {
  for(auto&c:cells)c.ageCoordinate=std::log1p(c.at.ageMs/20);
  for(int k=0;k<128;++k) for(unsigned p=0;p<4;++p) {
   auto& ix=lookup[k][p];ix.clear();float closest=128;
   for(const auto& c:cells)if(static_cast<unsigned>(c.at.phase)==p)closest=std::min(closest,std::abs(c.at.key-static_cast<float>(k)));
   if(closest==128) { // An unobserved phase falls back to sustain; it is never counted as learned.
    for(const auto&c:cells)if(c.at.phase==Phase::Sustain)closest=std::min(closest,std::abs(c.at.key-static_cast<float>(k)));
    for(unsigned i=0;i<cells.size();++i)if(cells[i].at.phase==Phase::Sustain&&std::abs(cells[i].at.key-static_cast<float>(k))<=closest+.01F)ix.push_back(i);
   } else for(unsigned i=0;i<cells.size();++i)if(static_cast<unsigned>(cells[i].at.phase)==p&&std::abs(cells[i].at.key-static_cast<float>(k))<=closest+.01F)ix.push_back(i);
  }
 }
 static float distance(const Condition& a,const Condition& b) noexcept {
  const auto sq=[](float x){return x*x;};
  return sq((a.key-b.key)/2)+sq((std::log1p(a.ageMs/20)-std::log1p(b.ageMs/20))*2)+
   4*(sq(a.velocity-b.velocity)+sq(a.breath-b.breath)+sq(a.expression-b.expression)+sq(a.wheel-b.wheel)+sq(a.pressure-b.pressure))+
   sq((a.interval-b.interval)/12);
 }
 bool predict(const Condition& q,Spectrum& out) const noexcept {
  const auto& ix=lookup[std::clamp(static_cast<int>(std::lround(q.key)),0,127)][static_cast<unsigned>(q.phase)];
  if(ix.empty())return false;
  std::array<float,4>d{{1e30F,1e30F,1e30F,1e30F}};std::array<unsigned,4>best{};unsigned n=0;
  const float age=std::log1p(q.ageMs/20);const auto sq=[](float x){return x*x;};
  for(unsigned i:ix){const auto&c=cells[i];const auto&a=c.at;
   const float v=sq((q.key-a.key)/2)+sq((age-c.ageCoordinate)*2)+4*(sq(q.velocity-a.velocity)+sq(q.breath-a.breath)+sq(q.expression-a.expression)+sq(q.wheel-a.wheel)+sq(q.pressure-a.pressure))+sq((q.interval-a.interval)/12);for(unsigned j=0;j<4;++j)if(v<d[j]){for(unsigned l=3;l>j;--l){d[l]=d[l-1];best[l]=best[l-1];}d[j]=v;best[j]=i;n=std::min(n+1,4U);break;}}
  out=Spectrum{};out.rmsDb=0;float sum=0;
  for(unsigned i=0;i<n;++i){const float w=1/(.03F+d[i]);sum+=w;const auto&s=cells[best[i]].sound;
   for(int h=0;h<ModelHarmonics;++h){out.db[h]+=w*s.db[h];}
   out.sub+=w*s.sub;out.rmsDb+=w*s.rmsDb;out.pitchCents+=w*s.pitchCents;}
  for(auto& v:out.db){v/=sum;}
  out.sub/=sum;out.rmsDb/=sum;out.pitchCents/=sum;return true;
 }
};
namespace model_io {
inline void u32(std::vector<std::uint8_t>& b,std::uint32_t v){for(int i=0;i<4;++i)b.push_back(static_cast<std::uint8_t>(v>>(i*8)));}
inline void f32(std::vector<std::uint8_t>& b,float f){std::uint32_t v;std::memcpy(&v,&f,4);u32(b,v);}
inline std::uint32_t hash(const std::uint8_t* p,std::size_t n){std::uint32_t h=2166136261U;while(n--)h=(h^*p++)*16777619U;return h;}
struct Reader {const std::vector<std::uint8_t>& b;std::size_t p=0;bool ok=true;
 std::uint32_t u(){if(p+4>b.size()){ok=false;return 0;}std::uint32_t v=0;for(int i=0;i<4;++i)v|=static_cast<std::uint32_t>(b[p++])<<(8*i);return v;}
 float f(float lo,float hi){auto v=u();float f;std::memcpy(&f,&v,4);if(!std::isfinite(f)||f<lo||f>hi)ok=false;return f;}
};
}
inline std::vector<std::uint8_t> encodeModel(const Model& m){
 using namespace model_io;std::vector<std::uint8_t>b{'S','V','S','O','L','O','0','1'};u32(b,1);u32(b,static_cast<std::uint32_t>(m.name.size()));b.insert(b.end(),m.name.begin(),m.name.end());
 f32(b,m.releaseMs);u32(b,m.validation.phrases);u32(b,m.validation.frames);f32(b,m.validation.spectralDb);f32(b,m.validation.levelDb);f32(b,m.validation.pitchCents);u32(b,m.validation.approved?1:0);
 for(const auto& k:m.observations){for(auto v:k){u32(b,v);}}
 u32(b,static_cast<std::uint32_t>(m.cells.size()));
 for(const auto&c:m.cells){const auto&q=c.at;u32(b,static_cast<unsigned>(q.phase));for(float v:{q.key,q.ageMs,q.velocity,q.breath,q.expression,q.wheel,q.pressure,q.interval})f32(b,v);
  u32(b,c.count);for(float v:c.sound.db)f32(b,v);f32(b,c.sound.sub);f32(b,c.sound.rmsDb);f32(b,c.sound.pitchCents);}
 u32(b,hash(b.data(),b.size()));return b;
}
inline std::shared_ptr<Model> decodeModel(const std::vector<std::uint8_t>& b,std::string& error){
 using namespace model_io;error.clear();auto bad=[&](){error="Invalid or unsupported SVSOLO model";return std::shared_ptr<Model>{};};
 if(b.size()<64||b.size()>1500000||std::memcmp(b.data(),"SVSOLO01",8))return bad();
 Reader tail{b,b.size()-4};if(tail.u()!=hash(b.data(),b.size()-4))return bad();
 Reader r{b,8};if(r.u()!=1)return bad();auto len=r.u();if(len>255||r.p+len>b.size())return bad();auto m=std::make_shared<Model>();m->name.assign(reinterpret_cast<const char*>(b.data()+r.p),len);r.p+=len;
 if(m->name.find('\0')!=std::string::npos)return bad();
 m->releaseMs=r.f(5,2000);m->validation.phrases=r.u();m->validation.frames=r.u();m->validation.spectralDb=r.f(0,180);m->validation.levelDb=r.f(0,180);m->validation.pitchCents=r.f(0,4800);auto approved=r.u();if(approved>1)return bad();m->validation.approved=approved!=0;
 for(auto&k:m->observations){for(auto&v:k){v=r.u();}}
 auto n=r.u();if(n==0||n>MaxModelCells)return bad();m->cells.resize(n);
 for(auto&c:m->cells){auto p=r.u();if(p>3)return bad();c.at.phase=static_cast<Phase>(p);c.at.key=r.f(0,127);c.at.ageMs=r.f(0,30000);c.at.velocity=r.f(0,1);c.at.breath=r.f(0,1);c.at.expression=r.f(0,1);c.at.wheel=r.f(0,1);c.at.pressure=r.f(0,1);c.at.interval=r.f(-127,127);c.count=r.u();if(!c.count)return bad();for(auto&v:c.sound.db)v=r.f(-100,24);c.sound.sub=r.f(0,2);c.sound.rmsDb=r.f(-120,0);c.sound.pitchCents=r.f(-2400,2400);}
 if(!r.ok||r.p!=b.size()-4)return bad();
 m->prepare();return m;
}
inline std::shared_ptr<Model> loadModel(const std::string& path,std::string&error){std::ifstream f(path,std::ios::binary|std::ios::ate);if(!f){error="Cannot open model";return {};}
 auto n=f.tellg();if(n<0||n>1500000){error="Model size is invalid";return {};}std::vector<std::uint8_t>b(static_cast<std::size_t>(n));f.seekg(0);if(!f.read(reinterpret_cast<char*>(b.data()),n)){error="Cannot read model";return {};}return decodeModel(b,error);}
}}}
