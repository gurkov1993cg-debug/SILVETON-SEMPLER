#pragma once
#include "SoloDefs.h"
#include "SamplerTypes.h"
namespace silveton::sampler::solo {
inline void preset(UpperPart& u,int index) {
    u.soloModel.reset();u.engine.type=EngineType::Solo;factory(index,u.engine.p.data());u.name=presetName(index);
    u.enabled=true;u.mute=false;u.voiceMode=UpperVoiceMode::Legato;
    u.portaMode=PortamentoMode::Kronos;u.portaTime=12;u.portaFingered=true;u.portaRateMode=false;u.portamentoSec=.025F;
    u.octave=0;u.transposeSemitones=0;u.tuneCents=0;u.pitchBendRange=2;
    u.toneAttackMs=1;u.toneDecayMs=0;u.toneSustain=1;u.toneReleaseMs=60;
}


}
