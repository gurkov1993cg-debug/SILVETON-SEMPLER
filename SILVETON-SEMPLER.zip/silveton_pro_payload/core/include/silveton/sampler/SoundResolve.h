#pragma once

// SILVETON_SOUND_BY_NAME_V1
// A BLEND remembers its sounds by the NAME of the sound (and by the bank place, 1..500, only
// as a hint). When the bank is replaced (update) or the saved BLENDS are loaded, the sound is
// found again by its name wherever it sits now - so a bank with re-ordered sounds never makes a
// BLEND play a different sound. A sound that is not in the bank any more is reported as missing
// (the part goes off) - it is never replaced by whatever happens to sit on the old place.

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::sampler {

struct SoundCandidate {
    std::uint16_t slot{0};
    std::string name;
};

struct SoundResolveResult {
    bool found{false};
    bool moved{false};          // found, but not on the remembered place
    std::uint16_t slot{0};      // the place the sound has now (valid when found)
};

// The engine names a part "Upper 3" / "Layer 2" before any sound is put on it. Such a name says
// nothing about a sound, so for it only the remembered place can be used.
[[nodiscard]] inline bool isPlaceholderSoundName(const std::string& name) {
    if (name.empty()) return true;
    for (const char* prefix : {"Upper ", "Layer "}) {
        const std::string p(prefix);
        if (name.size() > p.size() && name.compare(0U, p.size(), p) == 0) {
            bool digits = true;
            for (std::size_t i = p.size(); i < name.size(); ++i) {
                if (name[i] < '0' || name[i] > '9') { digits = false; break; }
            }
            if (digits) return true;
        }
    }
    return false;
}

// bankSounds: every sound of the current bank with the place it has now.
[[nodiscard]] inline SoundResolveResult resolveSoundByName(std::uint16_t savedSlot,
                                                           const std::string& savedName,
                                                           const std::vector<SoundCandidate>& bankSounds) {
    SoundResolveResult out;
    if (isPlaceholderSoundName(savedName)) {
        for (const auto& c : bankSounds) {
            if (c.slot == savedSlot) { out.found = true; out.slot = c.slot; return out; }
        }
        return out;
    }
    const SoundCandidate* first = nullptr;
    for (const auto& c : bankSounds) {
        if (c.name != savedName) continue;
        if (c.slot == savedSlot) { out.found = true; out.slot = c.slot; return out; }   // still on its place
        if (first == nullptr || c.slot < first->slot) first = &c;                         // else the lowest place
    }
    if (first != nullptr) { out.found = true; out.moved = true; out.slot = first->slot; }
    return out;
}

} // namespace silveton::sampler
