#pragma once
// SILVETON_SUSE_V1 - SILVETON SYNTH (the SILVETON Universal Synthesis Engine, SUSE).
// ONE engine that takes the place of the nine old ones on the ENGINES page. Everything it sounds is calculated: no recordings.
// The whole sound (the graph of six generators, their links, the filters, envelopes, LFOs, the step modulator, the modulation
// matrix, the controllers, the tuning and the drawn waves) is ONE flat row of numbers - EngineParams::p of the engine place -
// so a blend, a SET, an undo and a preset keep every setting.  All the numbers of the knobs are stored 0..1 (the screens show
// them in Hz, ms, dB ...); whole-number choices (method, wave, filter type ...) are stored as the number itself.
//
// This header is shared by the sound core, the host (one id, one value) and the screens. The ids never change once released.

#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>

namespace silveton::sampler::suse {

// ------------------------------------------------------------------------------------------------- sizes
constexpr int kGens = 6;                 // generators of the graph
constexpr int kMathWaves = 64;           // the starter library: 64 different calculated waves (ids 0..63)
constexpr int kDrawnWaves = 4;           // waves drawn / built in the editor, stored inside the preset (ids 64..67)
constexpr int kDrawLen = 64;             // points of a drawn wave
constexpr int kFileWaves = 16;           // the user's own USER 1..16 of SILVETON_OSC (ids 68..83)
constexpr int kWaveChoices = kMathWaves + kDrawnWaves + kFileWaves;
constexpr int kWaveDrawn0 = kMathWaves;
constexpr int kWaveFile0 = kMathWaves + kDrawnWaves;

// ------------------------------------------------------------------------------------------------- methods of a generator
enum Method : int { M_OFF = 0, M_WAVE, M_ADD, M_STRING, M_WIND, M_MODAL, M_NOISE, M_GRAIN, M_SPECTRAL, kMethods };

// ------------------------------------------------------------------------------------------------- the global block (0..63)
enum GlobalId : int {
    G_LEVEL = 0,        // master level of the engine place (0..1 = -36..+6 dB)
    G_QUALITY = 1,      // reserved (2x oversampling is not built)
    G_FILTER_LINK = 2,  // 0 PARALLEL, 1 SERIES (filter A feeds filter B)
    G_PRIORITY = 3,     // MONO note priority: 0 LAST, 1 HIGHEST, 2 LOWEST
    G_RETRIG = 4,       // LEGATO: 1 = the envelopes start again with each new note, 0 = they run on
    G_KEEP_RES = 5,     // LEGATO: 1 = the strings / tubes / modes keep ringing (their state is kept), 0 = they start again
    G_VOICES = 6,       // most notes this place may sound (1..24)
    G_VIB_RATE = 7, G_VIB_DEPTH = 8, G_VIB_DELAY = 9, G_VIB_WHEEL = 10,   // vibrato: Hz, cents, delay, 1 = the mod wheel opens it
    G_TREM_RATE = 11, G_TREM_DEPTH = 12,
    G_WIDTH = 13,       // stereo width
    G_VEL_CURVE = 14,   // velocity curve (0.5 = straight)
    G_DRIVE = 15,       // soft saturation of the output
    G_MONO_GLIDE = 16,  // reserved for the part's own portamento (not used)
    E_SOURCE_ID = 60, E_BYPASS_ID = 61, E_BEND_UP_ID = 62, E_BEND_DOWN_ID = 63   // the same ids as the old engines
};

// ------------------------------------------------------------------------------------------------- layout
constexpr int kGenBase = 64;
constexpr int kGenStride = 48;
constexpr int kLinkBase = kGenBase + kGens * kGenStride;          // 352: for (dst, src): type, amount
constexpr int kLinkCount = kGens * kGens;
constexpr int kFilterBase = kLinkBase + kLinkCount * 2;           // 424
constexpr int kFilters = 2;
constexpr int kFilterStride = 16;
constexpr int kEnvBase = kFilterBase + kFilters * kFilterStride;  // 456
constexpr int kEnvs = 4;
constexpr int kEnvStride = 16;
constexpr int kLfoBase = kEnvBase + kEnvs * kEnvStride;           // 520
constexpr int kLfos = 4;
constexpr int kLfoStride = 8;
constexpr int kStepBase = kLfoBase + kLfos * kLfoStride;          // 552
constexpr int kStepCount = 16;
constexpr int kStepStride = 20;
constexpr int kModBase = kStepBase + kStepStride;                 // 572
constexpr int kMods = 16;
constexpr int kModStride = 3;
constexpr int kCtlBase = kModBase + kMods * kModStride;           // 620
constexpr int kCtls = 8;
constexpr int kCtlStride = 8;
constexpr int kTuneBase = kCtlBase + kCtls * kCtlStride;          // 684
constexpr int kTuneStride = 16;
constexpr int kDrawBase = kTuneBase + kTuneStride;                // 700
constexpr int kParamCount = 960;                                   // 700 + 4*64 = 956, rounded up
static_assert(kDrawBase + kDrawnWaves * kDrawLen <= kParamCount, "layout");

// ------------------------------------------------------------------------------------------------- one generator (offsets inside its block)
enum GenId : int {
    GN_METHOD = 0, GN_ROUTE = 1, GN_FTYPE = 2, GN_SEL1 = 3, GN_SEL2 = 4, GN_SEL3 = 5, GN_SEL4 = 6,
    GN_OCT = 7, GN_SEMI = 8, GN_UNISON = 9, GN_SYNC = 10, GN_FIXED = 11, GN_AMPENV = 12, GN_FENV = 13, GN_PENV = 14,
    GN_LEVEL = 15, GN_PAN = 16, GN_FINE = 17, GN_RATIO = 18, GN_FIXHZ = 19, GN_PHASE = 20, GN_FCUT = 21, GN_FRES = 22,
    GN_VELLEV = 23, GN_UNIDET = 24, GN_UNISPR = 25, GN_SYNCR = 26, GN_FENVAMT = 27, GN_PENVAMT = 28, GN_FKEY = 29,
    GN_F0 = 30,            // GN_F0 .. GN_F0 + 13: the method's own knobs
    GN_MUTE = 44
};
constexpr int kGenFloats = 14;
enum Route : int { R_DRY = 0, R_A, R_B, R_AB, kRoutes };
enum OwnFilter : int { OF_OFF = 0, OF_LP, OF_HP, OF_BP, OF_NOTCH, kOwnFilters };
// the method's own choices (GN_SEL1 / GN_SEL2 / GN_SEL3 / GN_SEL4)
//   WAVE      SEL1 wave A, SEL2 wave B, SEL3 shaper (SH_*), SEL4 phase distortion (PD_*)
//   ADDITIVE  SEL1 spectrum (AS_*), SEL2 partial window
//   STRING    SEL1 exciter (EX_*), SEL2 external exciter (0 = own, 1..6 = generator)
//   WIND      SEL1 instrument (WI_*)
//   MODAL     SEL1 material (MA_*), SEL2 external exciter
//   NOISE     SEL1 colour (NC_*)
//   GRANULAR  SEL1 source generator (1..6), SEL2 grain window
//   SPECTRAL  SEL1 source generator (1..6), SEL2 operation (SP_*)
enum Shaper : int { SH_OFF = 0, SH_TANH, SH_ATAN, SH_CHEBY3, SH_SINE, SH_POWER, SH_CRUSH, SH_RECT, kShapers };
enum PhaseDist : int { PD_OFF = 0, PD_SAWBEND, PD_PULSEBEND, PD_RESONANT, PD_TWIST, PD_DOUBLE, kPhaseDists };
enum AddSeries : int { AS_SAW = 0, AS_SQUARE, AS_TRIANGLE, AS_EQUAL, AS_PRIME, AS_ROOT, kAddSeries };
enum Exciter : int { EX_PLUCK = 0, EX_HAMMER, EX_BOW, EX_NOISE, EX_IMPULSE, kExciters };
enum Wind : int { WI_CLARINET = 0, WI_SAX, WI_ZURNA, WI_KAVAL, WI_BRASS, kWinds };
enum Material : int { MA_BAR = 0, MA_PLATE, MA_BELL, MA_TUBE, MA_WOOD, MA_GLASS, kMaterials };
enum NoiseColor : int { NC_WHITE = 0, NC_PINK, NC_BROWN, NC_BLUE, NC_CRACKLE, NC_STEPS, kNoiseColors };
enum SpectralOp : int { SP_FREEZE = 0, SP_BLUR, SP_SHIFT, SP_STRETCH, SP_GATE, SP_TILT, SP_COMB, SP_WHISPER, kSpectralOps };

constexpr int genBase(int g) noexcept { return kGenBase + g * kGenStride; }
constexpr int genId(int g, int off) noexcept { return kGenBase + g * kGenStride + off; }

// ------------------------------------------------------------------------------------------------- the links between generators
enum LinkType : int { L_OFF = 0, L_PM, L_FM, L_AM, L_RING, L_SYNC, L_WARP, L_FILTFM, kLinkTypes };
constexpr int linkType(int dst, int src) noexcept { return kLinkBase + (dst * kGens + src) * 2; }
constexpr int linkAmt(int dst, int src) noexcept { return kLinkBase + (dst * kGens + src) * 2 + 1; }

// ------------------------------------------------------------------------------------------------- shared filters A and B
enum FilterId : int { FL_TYPE = 0, FL_CUT = 1, FL_RES = 2, FL_DRIVE = 3, FL_KEY = 4, FL_VEL = 5, FL_ENV = 6, FL_ENVAMT = 7, FL_VOWEL = 8, FL_MORPH = 9 };
enum FilterType : int { FT_OFF = 0, FT_LP, FT_HP, FT_BP, FT_NOTCH, FT_LADDER, FT_SVF, FT_RESONANT, FT_FORMANT, kFilterTypes };
constexpr int filterId(int f, int off) noexcept { return kFilterBase + f * kFilterStride + off; }

// ------------------------------------------------------------------------------------------------- envelopes: start, five points (time, level), sustain point, release, curve, loop, key time
enum EnvId : int { EV_START = 0, EV_SUS = 11, EV_REL = 12, EV_CURVE = 13, EV_LOOP = 14, EV_KEYT = 15 };
constexpr int kEnvPoints = 5;
constexpr int envT(int p) noexcept { return 1 + 2 * p; }
constexpr int envL(int p) noexcept { return 2 + 2 * p; }
constexpr int envId(int e, int off) noexcept { return kEnvBase + e * kEnvStride + off; }

// ------------------------------------------------------------------------------------------------- LFOs
enum LfoId : int { LF_WAVE = 0, LF_RATE = 1, LF_DELAY = 2, LF_FADE = 3, LF_PHASE = 4, LF_UNI = 5, LF_FREE = 6, LF_KEYF = 7 };
enum LfoWave : int { LW_SINE = 0, LW_TRI, LW_SAW, LW_RSAW, LW_SQUARE, LW_SH, LW_SMOOTH, kLfoWaves };
constexpr int lfoId(int l, int off) noexcept { return kLfoBase + l * kLfoStride + off; }

// ------------------------------------------------------------------------------------------------- step modulator
enum StepId : int { ST_LEN = 0, ST_RATE = 1, ST_GLIDE = 2, ST_DIR = 3, ST_STEPS = 4 };
constexpr int stepId(int off) noexcept { return kStepBase + off; }

// ------------------------------------------------------------------------------------------------- the free modulation matrix and the controllers
enum ModSource : int {
    MS_NONE = 0, MS_ENV1, MS_ENV2, MS_ENV3, MS_ENV4, MS_LFO1, MS_LFO2, MS_LFO3, MS_LFO4, MS_STEP,
    MS_VELOCITY, MS_KEY, MS_BREATH, MS_EXPRESSION, MS_WHEEL, MS_AFTERTOUCH, MS_POLYAT, MS_BEND, MS_RANDOM, kModSources
};
constexpr int modId(int m, int off) noexcept { return kModBase + m * kModStride + off; }   // off 0 source, 1 destination, 2 amount
// A controller route (MIDI learn): source 0 = off, 1..128 = CC 0..127, 129 = channel aftertouch, 130 = pitch bend.
// Curve 0 straight, 1 slow start, 2 fast start. Three destinations (+ amount each).
enum CtlId : int { CT_SRC = 0, CT_CURVE = 1, CT_D1 = 2, CT_A1 = 3, CT_D2 = 4, CT_A2 = 5, CT_D3 = 6, CT_A3 = 7 };
constexpr int ctlId(int c, int off) noexcept { return kCtlBase + c * kCtlStride + off; }
constexpr int kCtlSrcAftertouch = 129;
constexpr int kCtlSrcBend = 130;

// ------------------------------------------------------------------------------------------------- tuning (microtonal)
enum TuneId : int { TN_ON = 0, TN_ROOT = 1, TN_MASTER = 2, TN_CENTS = 3 };   // TN_CENTS .. +11: the 12 notes above the root, +-100 cents
constexpr int tuneId(int off) noexcept { return kTuneBase + off; }

constexpr int drawId(int wave, int point) noexcept { return kDrawBase + wave * kDrawLen + point; }

// ------------------------------------------------------------------------------------------------- targets of the modulation
// A destination is a number 0..kDestCount-1. Per generator 22 targets (LEVEL, PAN, PITCH, FINE, FILTER CUT, FILTER RES, UNISON DETUNE,
// PHASE and the method's 14 own knobs), then the shared filters, the LFO rates, the global ones and ALL PITCH.
constexpr int kDestPerGen = 22;
constexpr int kDestFilterBase = kGens * kDestPerGen;            // 132: 4 per filter (CUT, RES, DRIVE, VOWEL)
constexpr int kDestLfoBase = kDestFilterBase + kFilters * 4;    // 140: 4 LFO rates
constexpr int kDestGlobalBase = kDestLfoBase + kLfos;           // 144: LEVEL, VIBRATO DEPTH, TREMOLO DEPTH, WIDTH
constexpr int kDestAllPitch = kDestGlobalBase + 4;              // 148
constexpr int kDestCount = kDestAllPitch + 1;                   // 149

struct Dest {
    int id;        // index into p (-1 for a pitch target)
    int gen;       // pitch target: 0..5 one generator, 6 all (otherwise -1)
};
[[nodiscard]] Dest destOf(int k) noexcept;
// which of the 22 per-generator target slots (0..21, 2 = PITCH is separate) an offset inside a generator has, or -1 when it is no target
[[nodiscard]] int destSlotOfOffset(int off) noexcept;
[[nodiscard]] const char* methodName(int m) noexcept;
[[nodiscard]] const char* waveName(int w) noexcept;     // 0..kWaveChoices-1

// What a parameter is: for the host's clamp, the sound core's smoothing and the screens.
struct ParamInfo {
    float lo, hi, def;
    bool whole;          // a whole-number choice (never glided)
};
[[nodiscard]] ParamInfo paramInfo(int id) noexcept;
[[nodiscard]] float clampParam(int id, float v) noexcept;
// Sets every number of the patch to the start sound (generator 1 = a saw, filter A open, envelope 1 = organ-like).
void setDefaults(float* p) noexcept;
// A generator takes another method: the method's own knobs and choices take the start values of that method (so no knob keeps a
// number that meant something else). Called by the host when GN_METHOD changes.
void setMethod(float* p, int gen, int method) noexcept;
// the number of the knob's names (Choice) of a whole-number parameter, for the screens: how many choices GN_SEL1 / GN_SEL2 has
[[nodiscard]] int selChoices(int method, int sel) noexcept;
// the 64 calculated waves: one cycle of the wave `w` (0..kMathWaves-1) in n points, peak 1, no DC (for the screens and the tests)
void waveCycle(int w, float* out, int n) noexcept;

// ------------------------------------------------------------------------------------------------- how a 0..1 knob becomes a value
inline float mapLin(float t, float lo, float hi) noexcept { return lo + t * (hi - lo); }
inline float mapLog(float t, float lo, float hi) noexcept { return lo * std::pow(hi / lo, t); }
inline float unmapLin(float v, float lo, float hi) noexcept { return (v - lo) / (hi - lo); }
inline float unmapLog(float v, float lo, float hi) noexcept { return std::log(v / lo) / std::log(hi / lo); }
namespace rng {
constexpr float kLevelDbLo = -36.0F, kLevelDbHi = 6.0F;        // G_LEVEL
constexpr float kGenDbLo = -60.0F, kGenDbHi = 6.0F;            // GN_LEVEL (0 = silence)
constexpr float kRatioLo = 0.125F, kRatioHi = 16.0F;            // GN_RATIO (log)
constexpr float kFixHzLo = 1.0F, kFixHzHi = 20000.0F;           // GN_FIXHZ (log)
constexpr float kFineCents = 100.0F;                            // GN_FINE +-
constexpr float kCutLo = 20.0F, kCutHi = 20000.0F;              // filters (log)
constexpr float kTimeLo = 0.001F, kTimeHi = 10.0F;              // envelope times (log; 0 = at once)
constexpr float kLfoLo = 0.02F, kLfoHi = 40.0F;                 // LFO rate (log)
constexpr float kLfoTimeHi = 5.0F;                              // LFO delay / fade (s)
constexpr float kStepLo = 0.1F, kStepHi = 40.0F;                // step rate (log)
constexpr float kFenvOct = 6.0F;                                // filter envelope +- octaves
constexpr float kPenvSemis = 24.0F;                             // pitch envelope +- semitones
constexpr float kUniDetCents = 50.0F;
constexpr float kVibRateLo = 0.1F, kVibRateHi = 12.0F;
constexpr float kVibDepthCents = 200.0F;
constexpr float kModPitchSemis = 24.0F;                         // a pitch target at full amount
}
inline float levelDbOf(float t) noexcept { return t <= 0.002F ? -120.0F : mapLin(t, rng::kGenDbLo, rng::kGenDbHi); }
inline float genGainOf(float t) noexcept { return t <= 0.002F ? 0.0F : std::pow(10.0F, mapLin(t, rng::kGenDbLo, rng::kGenDbHi) / 20.0F); }
inline float envTimeOf(float t) noexcept { return t <= 0.001F ? 0.0F : rng::kTimeLo * std::pow(10.0F, 4.0F * t); }   // seconds
inline float qOf(float t) noexcept { return 0.5F + t * t * 19.5F; }

} // namespace silveton::sampler::suse
