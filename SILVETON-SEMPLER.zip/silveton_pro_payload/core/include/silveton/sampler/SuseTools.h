#pragma once
// SILVETON_SUSE_V1 - the helpers of SILVETON SYNTH that the screens, the preset store and the tests share:
//   * the NAMES and the DISPLAY of every number (so the screen can only show what the sound really does),
//   * the maths of the WAVE EDITOR (harmonics and phases, symmetry, morph / combine of two waves),
//   * the SHAPE of an envelope (for the drawing),
//   * the PRESET text format (versioned, with a check sum) and the FACTORY presets,
//   * the LOUDNESS of a patch (for the A / B compare of the SOUND LAB).
// Nothing here runs in the audio thread (the preset text, the loudness and the drawing allocate).

#include "silveton/sampler/SuseDefs.h"

#include <string>
#include <vector>

namespace silveton::sampler::suse {

// ------------------------------------------------------------------------------------------------- how a number is shown
struct Disp {
    enum Kind : int { Pct = 0, PctBi, Lin, Log, Db, Whole, Switch, Time };
    Kind kind{Pct};
    float lo{0.0F}, hi{1.0F};   // the shown range (Lin / Log / Db / Whole); Pct and PctBi show 0..100 and -100..+100
    const char* unit{""};
    int decimals{0};
};
// What a number of the patch is called and how it is shown. `p` (the whole patch) is needed because the 14 own knobs of a
// generator change their meaning with its method. name == nullptr: this number is not used by the method (hide it).
[[nodiscard]] const char* paramName(int id, const float* p) noexcept;
[[nodiscard]] Disp paramDisp(int id, const float* p) noexcept;
[[nodiscard]] std::string dispText(const Disp& d, float norm);
[[nodiscard]] float dispFromNorm(const Disp& d, float norm) noexcept;      // the shown number of a stored 0..1 number
[[nodiscard]] float dispToNorm(const Disp& d, float shown) noexcept;        // and back (clamped)
// the name of the own knob i (0..13) of a method; nullptr when the method does not use it
[[nodiscard]] const char* methodKnobName(int method, int i) noexcept;
// the choice keys of a generator: label (nullptr = the method has no such choice) and the name of a choice
[[nodiscard]] const char* selLabel(int method, int sel) noexcept;           // sel = GN_SEL1 .. GN_SEL4
[[nodiscard]] std::string selChoiceName(int method, int sel, int choice);
[[nodiscard]] const char* linkTypeName(int t) noexcept;
[[nodiscard]] const char* routeName(int r) noexcept;
[[nodiscard]] const char* ownFilterName(int t) noexcept;
[[nodiscard]] const char* filterTypeName(int t) noexcept;
[[nodiscard]] const char* lfoWaveName(int w) noexcept;
[[nodiscard]] const char* modSourceName(int s) noexcept;
[[nodiscard]] const char* priorityName(int p) noexcept;
// the name of a modulation target (0..kDestCount-1); empty when the target does nothing for the generator's current method
[[nodiscard]] std::string destName(int k, const float* p);
[[nodiscard]] bool destUsable(int k, const float* p) noexcept;
// a short summary of what the patch uses, e.g. "WAVE · STRING"
[[nodiscard]] std::string patchSummary(const float* p);

// ------------------------------------------------------------------------------------------------- the wave editor
// A wave is kDrawLen points of one cycle, -1..1 (the patch keeps them as 0.5 + 0.5 * v).
constexpr int kEditHarmonics = 31;   // what 64 points can hold (harmonic 1 .. 31)
enum WaveOp : int { WO_MIRROR = 0, WO_INVERT, WO_SYM_EVEN, WO_SYM_ODD, WO_ODD_HARM, WO_EVEN_HARM, WO_SMOOTH, WO_NORMALIZE, kWaveOps };
enum Combine : int { CM_MORPH = 0, CM_SPECTRUM, CM_MULTIPLY, CM_ADD, kCombines };
[[nodiscard]] const char* waveOpName(int op) noexcept;
[[nodiscard]] const char* combineName(int c) noexcept;
// amp[k-1] and phase[k-1] of harmonic k: x(t) = sum amp * cos(2 pi k t + phase)
void waveHarmonics(const float* pts, float* amp, float* phase) noexcept;
void waveFromHarmonics(const float* amp, const float* phase, float* pts) noexcept;   // the peak is brought to 1 when it is larger
void waveApplyOp(int op, float* pts) noexcept;
void waveCombine(int mode, const float* a, const float* b, float t, float* out) noexcept;   // t = 0 is a, 1 is b
void waveNormalize(float* pts) noexcept;                                                    // no DC, peak 1
// The 64 points of any wave choice (math wave, drawn wave of the patch); user file waves give zeros.
void waveChoicePoints(int choice, const float* patch, float* pts) noexcept;

// ------------------------------------------------------------------------------------------------- the shape of an envelope
// n points of envelope `env` (0..3): attack to the sustain point, a short hold, the release. totalSec / releaseAtSec = the time axis.
void envelopePreview(const float* patch, int env, int n, float* out, float* totalSec, float* releaseAtSec);
// the cumulative time (s) at which point `pt` of the envelope is reached (for the drawing of the points)
[[nodiscard]] float envelopePointTime(const float* patch, int env, int pt) noexcept;

// ------------------------------------------------------------------------------------------------- presets (versioned text with a check sum)
constexpr int kPresetVersion = 1;
constexpr std::size_t kPresetNameMax = 40;
[[nodiscard]] std::uint32_t crc32(const void* data, std::size_t n) noexcept;
// "SUSP 1" ... one preset.  The name is cleaned (no new lines, at most 40 letters).
[[nodiscard]] std::string encodePreset(const std::string& name, const float* patch);
// false + a reason in `error` when the text is not a preset, is newer than this program knows, or the check sum does not agree.
// `patch` gets kParamCount numbers, every one clamped; a preset that holds fewer numbers keeps the start values for the rest.
[[nodiscard]] bool decodePreset(const std::string& text, std::string& name, float* patch, std::string& error);
// "SUSB 1": a bank of presets (one file for export / import)
struct PresetEntry { std::string name; std::vector<float> patch; };
[[nodiscard]] std::string encodeBank(const std::vector<PresetEntry>& presets);
[[nodiscard]] bool decodeBank(const std::string& text, std::vector<PresetEntry>& out, std::string& error);
// one wave (64 points) as a small file "SUSW 1"
[[nodiscard]] std::string encodeWave(const std::string& name, const float* points);
[[nodiscard]] bool decodeWave(const std::string& text, std::string& name, float* points, std::string& error);

// the factory presets
[[nodiscard]] int factoryPresetCount() noexcept;
[[nodiscard]] const char* factoryPresetName(int i) noexcept;
[[nodiscard]] const char* factoryPresetGroup(int i) noexcept;
void factoryPreset(int i, float* patch) noexcept;

// ------------------------------------------------------------------------------------------------- loudness (SOUND LAB)
// The level (dB, RMS of both channels) of the patch playing a held middle C at velocity 0.8 for one second, rendered with the real
// voice. Allocates; call it from the screen thread only.
[[nodiscard]] float referenceLoudnessDb(const float* patch);

} // namespace silveton::sampler::suse
