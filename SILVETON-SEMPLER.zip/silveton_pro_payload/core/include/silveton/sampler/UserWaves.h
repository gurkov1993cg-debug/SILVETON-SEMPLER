#pragma once
// SILVETON_USER_WAVES_V1 - the user's own oscillator waves.
// SILVETON OSCILLATOR LAB (a Mac program) turns recorded notes / KMP multisamples into single-cycle waves. Its export
// is ONE file next to SILVETON_BANK.sv, like the bank:
//   SILVETON_OSC.sv                 every wave with its zones (the layout: readOscFile in UserWaves.cpp); it wins over the folder
// or (older LAB versions, by hand) the folder SILVETON_OSC next to SILVETON_BANK.sv:
//   SILVETON_OSC/<name>/            a folder from the LAB (wavetable_2048.wav or single_cycle.wav inside) = the wave <name>
//   SILVETON_OSC/<name>/zones.txt   a KMP made into waves by the LAB: one wave per zone, each plays its own keys
//                                   (lines "low-key top-key original-key file"; the zone is chosen by the key at note-on)
//   SILVETON_OSC/<name>.wav         one cycle (2048 samples, or 16..4096 samples = one whole cycle) = the wave <name>
// Up to 16 waves, in the order of their names: USER 1 .. USER 16 in AL-1 OSC 1/2, POLYSIX OSC, MS-20 VCO 1/2 and the MOD-7
// operators (after the 32 table waves). Of a LAB wavetable only its first frame is used (= its single_cycle.wav).
// The waves are made on the control thread, never in the audio callback.

#include "silveton/sampler/EngineDefs.h"

#include <array>
#include <atomic>
#include <cstddef>
#include <string>
#include <vector>

namespace silveton::sampler {

// The waves in the form the engines read: ten versions of each, with fewer and fewer harmonics (as the table waves).
constexpr int kUserTabSize = 1024;   // = the table waves' kTabSize (EngineDsp.h checks it)
constexpr int kUserTabLevels = 10;   // = kTabLevels
constexpr int kUserWaveMaxZones = 64;   // zones of one wave (a KMP)
struct UserWaveTables {
    std::vector<float> t;   // [table][level][kUserTabSize + 1] - every zone of every wave has a table of its own
    struct Zone { int low{0}; int top{127}; int table{0}; };
    std::array<std::vector<Zone>, kUserWaveCount> zones;   // per wave, by key (a plain wave = one zone 0..127)
    std::array<bool, kUserWaveCount> present{};
    [[nodiscard]] const float* table(int idx, int lvl) const noexcept {
        return t.data() + (static_cast<std::size_t>(idx) * kUserTabLevels + static_cast<std::size_t>(lvl)) * (kUserTabSize + 1U);
    }
    // the table of wave k for a note on `key` (-1 = the place is empty); below / above / between the zones the nearest one
    [[nodiscard]] int tableFor(int k, int key) const noexcept {
        if (k < 0 || k >= kUserWaveCount) return -1;
        const auto& z = zones[static_cast<std::size_t>(k)];
        if (z.empty()) return -1;
        for (const Zone& x : z) if (key <= x.top) return x.table;
        return z.back().table;
    }
};
// The set the engines read (nullptr = no user waves). A set that was handed over is never freed while the program runs.
std::atomic<const UserWaveTables*>& userWaveTables() noexcept;

struct UserWaveReport {
    std::string folder;                 // the folder that was read
    bool folderFound{false};
    std::vector<std::string> names;     // USER 1, USER 2 ... in this order
    std::vector<int> zoneCounts;        // per name: 1 for a plain wave, the zones of a KMP
    std::vector<std::string> skipped;   // "<name> - why" for what is not a single wave
};

// Reads `folder` (the file SILVETON_OSC.sv, or the folder SILVETON_OSC) and hands its waves to the engines (missing = none). When nothing in the folder changed
// since the last call the waves are not made again. Control thread only.
UserWaveReport loadUserWaves(const std::string& folder);

// What the last loadUserWaves() found (any thread except the audio thread).
UserWaveReport userWaveReport();

// The name of USER k+1 (k = 0..15), "" when that place is empty (any thread except the audio thread).
std::string userWaveName(int k);

} // namespace silveton::sampler
