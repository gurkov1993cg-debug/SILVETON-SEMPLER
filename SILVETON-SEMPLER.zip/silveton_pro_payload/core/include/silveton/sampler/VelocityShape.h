#pragma once
// SILVETON_VELOCITY_V1 - how the strength of a key press (velocity 1..127) is shaped for ONE sound of an Upper
// (the basic sound ОСНОВЕН or one of the layers L1..L4). Header only, no allocation: the engine (on every note),
// the screens (the graph) and the tests all use these same functions.
//
// Everything has a default that leaves the old playing bit for bit the same:
//   curve LINEAR, compress 0, toAttack 0, crossfade off.

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::sampler {

enum class VelocityCurveType : std::uint8_t {
    Linear = 0,        // as played
    Soft = 1,          // a light touch is already fairly loud
    Hard = 2,          // you have to play hard to get loud
    Exponential = 3,   // very quiet at first, then it rises fast
    Logarithmic = 4,   // very loud at first, then it flattens
    SCurve = 5,        // quiet and loud ends are held, the middle is steeper
    Custom = 6         // the 9 points drawn by the user
};
constexpr int kVelocityCurveTypes = 7;
constexpr int kVelocityCustomPoints = 9;   // the curve is drawn through 9 points: input 0, 1/8, 2/8 ... 1

struct VelocityShape {
    std::uint8_t curve{0};   // VelocityCurveType
    // CUSTOM: the output 0..127 at the inputs 0, 16, 32 ... 127 (straight lines between the points)
    std::array<std::uint8_t, kVelocityCustomPoints> custom{{0, 16, 32, 48, 64, 79, 95, 111, 127}};
    float compress{0.0F};    // -1 (expand: soft gets softer, loud louder) .. 0 (off) .. +1 (compress: everything near the middle)
    float toAttack{0.0F};    // 0 (off) .. 1: a soft key press gets a longer attack (up to +kVelocityAttackMaxMs at the softest)
    bool crossfade{false};   // the gains of the sounds that have this on never add up above 1 (see velocityFadeGain)

    [[nodiscard]] bool isDefault() const noexcept {
        return curve == 0U && compress == 0.0F;
    }
    bool operator==(const VelocityShape& o) const noexcept {
        return curve == o.curve && custom == o.custom && compress == o.compress && toAttack == o.toAttack && crossfade == o.crossfade;
    }
    bool operator!=(const VelocityShape& o) const noexcept { return !(*this == o); }
};

constexpr float kVelocityAttackMaxMs = 400.0F;

// The curve alone: input 0..1 -> output 0..1.
[[nodiscard]] inline float velocityCurveValue(std::uint8_t curve, const std::array<std::uint8_t, kVelocityCustomPoints>& custom, float x) noexcept {
    x = std::clamp(x, 0.0F, 1.0F);
    switch (curve) {
        case 1U: return std::pow(x, 0.6F);
        case 2U: return std::pow(x, 1.7F);
        case 3U: return (std::exp(3.0F * x) - 1.0F) / (std::exp(3.0F) - 1.0F);
        case 4U: return std::log(1.0F + 9.0F * x) / std::log(10.0F);
        case 5U: return x * x * (3.0F - 2.0F * x);
        case 6U: {
            const float p = x * static_cast<float>(kVelocityCustomPoints - 1);
            const int i = std::min(static_cast<int>(p), kVelocityCustomPoints - 2);
            const float t = p - static_cast<float>(i);
            const float a = static_cast<float>(std::min<std::uint8_t>(custom[static_cast<std::size_t>(i)], 127U)) * (1.0F / 127.0F);
            const float b = static_cast<float>(std::min<std::uint8_t>(custom[static_cast<std::size_t>(i + 1)], 127U)) * (1.0F / 127.0F);
            return a + (b - a) * t;
        }
        default: return x;
    }
}

// Curve + compress / expand: input 0..1 -> output 0..1. With the default shape the input comes back unchanged (the same bits).
[[nodiscard]] inline float velocityShaped(const VelocityShape& s, float x) noexcept {
    if (s.isDefault()) return x;
    float y = velocityCurveValue(s.curve, s.custom, x);
    if (s.compress != 0.0F) y = std::clamp(0.5F + (y - 0.5F) * (1.0F - std::clamp(s.compress, -1.0F, 1.0F)), 0.0F, 1.0F);
    return y;
}

// The time added to the attack of a note of this (shaped) strength: 0 at the hardest, toAttack * kVelocityAttackMaxMs at the softest.
[[nodiscard]] inline float velocityAttackExtraMs(const VelocityShape& s, float shapedNorm) noexcept {
    if (s.toAttack <= 0.0F) return 0.0F;
    return std::clamp(s.toAttack, 0.0F, 1.0F) * kVelocityAttackMaxMs * (1.0F - std::clamp(shapedNorm, 0.0F, 1.0F));
}

// The gain of a sound's FADE IN / FADE OUT at one velocity: the sound's range is lo..hi, it comes in over `fadeIn` steps from lo
// and goes out over `fadeOut` steps up to hi (0 = no fade). 1 = full, 0 = nothing.
[[nodiscard]] inline float velocityFadeGain(int lo, int hi, int fadeIn, int fadeOut, int velocity) noexcept {
    float g = 1.0F;
    if (fadeIn > 0) g *= std::clamp((static_cast<float>(velocity) - static_cast<float>(lo) + 1.0F) / static_cast<float>(fadeIn), 0.0F, 1.0F);
    if (fadeOut > 0) g *= std::clamp((static_cast<float>(hi) - static_cast<float>(velocity) + 1.0F) / static_cast<float>(fadeOut), 0.0F, 1.0F);
    return g;
}

} // namespace silveton::sampler
