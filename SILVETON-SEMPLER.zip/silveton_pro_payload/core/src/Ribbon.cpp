#include "silveton/Ribbon.h"
#include <cmath>

namespace silveton {

namespace {
constexpr double kCenterDeadZone = 0.008;    // centre dead zone (old HQ feel)
constexpr double kMaxDtSeconds = 0.010;      // robust after scheduler stalls
constexpr std::int64_t kMinUpdateUs = 2000;  // <= 500 Hz
constexpr double kSnapSemitones = 0.0005;
constexpr double kSnapVelocity = 0.003;
} // namespace

void Ribbon::setSettings(const Settings& settings) {
    s_ = settings;
    s_.rangeSemitones = std::clamp(s_.rangeSemitones, 1, 24);
    s_.sensitivity = std::clamp(s_.sensitivity, 0.25, 2.0);
    s_.smoothMs = std::clamp(s_.smoothMs, 0, 200);
    s_.returnMs = std::clamp(s_.returnMs, 0, 2000);
}

double Ribbon::shape(double x) const {
    const double a = std::min(std::abs(x), 1.0);
    const double gamma = 1.0 / std::sqrt(s_.sensitivity); // 2.0 .. ~0.707
    return std::copysign(std::pow(a, gamma), x);
}

double Ribbon::absoluteTarget(double position) const {
    const double pos = std::clamp(position, -1.0, 1.0);
    const double a = std::abs(pos);
    if (a <= kCenterDeadZone) return 0.0;
    const double n = (a - kCenterDeadZone) / (1.0 - kCenterDeadZone);
    return shape(std::copysign(n, pos)) * static_cast<double>(s_.rangeSemitones);
}

void Ribbon::touchDown(double position, std::int64_t nowUs) {
    touching_ = true;
    if (lastUs_ == 0) lastUs_ = nowUs;
    target_ = absoluteTarget(position);
}

void Ribbon::touchMove(double position, std::int64_t nowUs) {
    if (!touching_) {
        touchDown(position, nowUs);
        return;
    }
    target_ = absoluteTarget(position);
}

void Ribbon::touchUp(std::int64_t /*nowUs*/) {
    if (!touching_) return;
    touching_ = false;
    target_ = 0.0;
}

void Ribbon::setTarget(double normalizedPosition, std::int64_t nowUs) {
    if (normalizedPosition == 0.0) {
        if (touching_) touchUp(nowUs);
        else target_ = 0.0;
        return;
    }
    if (!touching_) touchDown(normalizedPosition, nowUs);
    else touchMove(normalizedPosition, nowUs);
}

Ribbon::Update Ribbon::advance(std::int64_t nowUs) {
    if (lastUs_ == 0) {
        lastUs_ = nowUs;
        return {};
    }
    const std::int64_t deltaUs = nowUs - lastUs_;
    if (deltaUs < kMinUpdateUs) return {};
    lastUs_ = nowUs;
    const double dt = std::min(static_cast<double>(deltaUs) * 1.0e-6, kMaxDtSeconds);

    // Critically damped follow (no overshoot). Touching uses the smooth time,
    // springing back uses the return time.
    const bool returning = !touching_ && target_ == 0.0;
    const double smoothSec = std::max(0.0005, (returning ? s_.returnMs : s_.smoothMs) * 1.0e-3 / 3.0);
    if ((returning ? s_.returnMs : s_.smoothMs) == 0) {
        value_ = target_;
        velocity_ = 0.0;
    } else {
        const double omega = 2.0 / smoothSec;
        const double x = omega * dt;
        const double expTerm = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x);
        const double change = value_ - target_;
        const double temp = (velocity_ + omega * change) * dt;
        velocity_ = (velocity_ - omega * temp) * expTerm;
        value_ = target_ + (change + temp) * expTerm;
    }
    const double range = static_cast<double>(s_.rangeSemitones);
    value_ = std::clamp(value_, -range, range);
    if (std::abs(target_ - value_) < kSnapSemitones && std::abs(velocity_) < kSnapVelocity) {
        value_ = target_;
        velocity_ = 0.0;
    }

    const double out = value_;
    const double snapped = (std::abs(out) < kSnapSemitones && target_ == 0.0 && !touching_) ? 0.0 : out;
    output_ = snapped;
    return {true, output_};
}

void Ribbon::reset() {
    touching_ = false;
    target_ = value_ = velocity_ = output_ = 0.0;
    lastUs_ = 0;
}

} // namespace silveton
