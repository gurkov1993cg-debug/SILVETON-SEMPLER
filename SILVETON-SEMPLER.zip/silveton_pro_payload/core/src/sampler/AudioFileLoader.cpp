#include "silveton/sampler/AudioFileLoader.h"
#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <limits>
#include <string>
#include <vector>

namespace silveton::sampler {
namespace {

std::uint16_t le16(const std::uint8_t* p) noexcept {
    return static_cast<std::uint16_t>(p[0]) |
           static_cast<std::uint16_t>(static_cast<std::uint16_t>(p[1]) << 8U);
}
std::uint32_t le32(const std::uint8_t* p) noexcept {
    return static_cast<std::uint32_t>(p[0]) |
           (static_cast<std::uint32_t>(p[1]) << 8U) |
           (static_cast<std::uint32_t>(p[2]) << 16U) |
           (static_cast<std::uint32_t>(p[3]) << 24U);
}
std::uint64_t le64(const std::uint8_t* p) noexcept {
    std::uint64_t v = 0U;
    for (int i = 7; i >= 0; --i) v = (v << 8U) | static_cast<std::uint64_t>(p[i]);
    return v;
}
std::uint16_t be16(const std::uint8_t* p) noexcept {
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(p[0]) << 8U) |
                                     static_cast<std::uint16_t>(p[1]));
}
std::uint32_t be32(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24U) |
           (static_cast<std::uint32_t>(p[1]) << 16U) |
           (static_cast<std::uint32_t>(p[2]) << 8U) |
           static_cast<std::uint32_t>(p[3]);
}
std::uint64_t be64(const std::uint8_t* p) noexcept {
    std::uint64_t v = 0U;
    for (int i = 0; i < 8; ++i) v = (v << 8U) | static_cast<std::uint64_t>(p[i]);
    return v;
}

float clampAudio(double v) noexcept {
    if (!std::isfinite(v)) return 0.0F;
    return static_cast<float>(std::clamp(v, -1.0, 1.0));
}

std::string basenameNoExt(const std::string& path) {
    const std::size_t slash = path.find_last_of("/\\");
    const std::size_t begin = slash == std::string::npos ? 0U : slash + 1U;
    const std::size_t dot = path.find_last_of('.');
    const std::size_t end = (dot == std::string::npos || dot < begin) ? path.size() : dot;
    return path.substr(begin, end - begin);
}

bool readAll(const std::string& path, std::vector<std::uint8_t>& bytes, std::string& error) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { error = "Cannot open audio file: " + path; return false; }
    const std::streamsize size = f.tellg();
    if (size <= 0) { error = "Audio file is empty: " + path; return false; }
    f.seekg(0, std::ios::beg);
    bytes.resize(static_cast<std::size_t>(size));
    if (!f.read(reinterpret_cast<char*>(bytes.data()), size)) {
        error = "Failed to read audio file: " + path; return false;
    }
    return true;
}

float decodePcmLE(const std::uint8_t* p, int bits) noexcept {
    switch (bits) {
        case 8: return (static_cast<float>(p[0]) - 128.0F) / 128.0F;
        case 16: {
            const auto u = le16(p);
            const auto s = static_cast<std::int16_t>(u);
            return static_cast<float>(s) / 32768.0F;
        }
        case 24: {
            std::int32_t v = static_cast<std::int32_t>(p[0]) |
                             (static_cast<std::int32_t>(p[1]) << 8) |
                             (static_cast<std::int32_t>(p[2]) << 16);
            if ((v & 0x00800000) != 0) v |= static_cast<std::int32_t>(0xFF000000U);
            return static_cast<float>(v) / 8388608.0F;
        }
        case 32: {
            const auto u = le32(p);
            const auto s = static_cast<std::int32_t>(u);
            return static_cast<float>(static_cast<double>(s) / 2147483648.0);
        }
        default: return 0.0F;
    }
}

float decodePcmBE(const std::uint8_t* p, int bits) noexcept {
    switch (bits) {
        case 8: return static_cast<float>(static_cast<std::int8_t>(p[0])) / 128.0F;
        case 16: {
            const auto s = static_cast<std::int16_t>(be16(p));
            return static_cast<float>(s) / 32768.0F;
        }
        case 24: {
            std::int32_t v = (static_cast<std::int32_t>(p[0]) << 16) |
                             (static_cast<std::int32_t>(p[1]) << 8) |
                             static_cast<std::int32_t>(p[2]);
            if ((v & 0x00800000) != 0) v |= static_cast<std::int32_t>(0xFF000000U);
            return static_cast<float>(v) / 8388608.0F;
        }
        case 32: {
            const auto s = static_cast<std::int32_t>(be32(p));
            return static_cast<float>(static_cast<double>(s) / 2147483648.0);
        }
        default: return 0.0F;
    }
}

double extended80ToDouble(const std::uint8_t* p) noexcept {
    const std::uint16_t expRaw = be16(p);
    const bool negative = (expRaw & 0x8000U) != 0U;
    const int exp = static_cast<int>(expRaw & 0x7FFFU);
    const std::uint64_t mantissa = be64(p + 2);
    if (exp == 0 && mantissa == 0U) return 0.0;
    if (exp == 0x7FFF) return std::numeric_limits<double>::infinity();
    const long double fraction = static_cast<long double>(mantissa) /
                                 static_cast<long double>(std::uint64_t{1} << 63U);
    long double value = std::ldexp(fraction, exp - 16383);
    if (negative) value = -value;
    return static_cast<double>(value);
}

void parseWavSmpl(const std::uint8_t* data, std::size_t size, SampleData& out) {
    if (size < 36U) return;
    const std::uint32_t unity = le32(data + 12U);
    if (unity <= 127U) out.rootKey = static_cast<std::uint8_t>(unity);
    const std::uint32_t pitchFraction = le32(data + 16U);
    out.fineTuneCents = static_cast<float>((static_cast<double>(pitchFraction) / 4294967296.0) * 100.0);
    const std::uint32_t loopCount = le32(data + 28U);
    if (loopCount == 0U || size < 60U) return;
    const std::uint32_t type = le32(data + 40U);
    const std::uint32_t start = le32(data + 44U);
    const std::uint32_t endInclusive = le32(data + 48U);
    if (type == 0U && endInclusive >= start) {
        out.loop.enabled = true;
        out.loop.startFrame = start;
        out.loop.endFrame = static_cast<std::uint64_t>(endInclusive) + 1U;
    }
}

} // namespace

AudioLoadResult AudioFileLoader::load(const std::string& path) {
    const std::size_t dot = path.find_last_of('.');
    std::string ext = dot == std::string::npos ? std::string{} : path.substr(dot + 1U);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (ext == "wav" || ext == "wave") return loadWav(path);
    if (ext == "aif" || ext == "aiff" || ext == "aifc") return loadAiff(path);
    return {nullptr, "Unsupported audio file extension: " + ext};
}

AudioLoadResult AudioFileLoader::loadStreaming(const std::string& path, std::uint64_t preloadFrames) {
    const std::size_t dot = path.find_last_of('.');
    std::string ext = dot == std::string::npos ? std::string{} : path.substr(dot + 1U);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (ext == "wav" || ext == "wave") return loadWavStreaming(path, preloadFrames);
    if (ext == "aif" || ext == "aiff" || ext == "aifc") return loadAiffStreaming(path, preloadFrames);
    return load(path);
}

AudioLoadResult AudioFileLoader::loadWav(const std::string& path) {
    std::vector<std::uint8_t> bytes;
    std::string error;
    if (!readAll(path, bytes, error)) return {nullptr, error};
    if (bytes.size() < 12U || std::memcmp(bytes.data(), "RIFF", 4U) != 0 ||
        std::memcmp(bytes.data() + 8U, "WAVE", 4U) != 0) {
        return {nullptr, "Not a RIFF/WAVE file"};
    }

    std::uint16_t format = 0U;
    std::uint16_t channels = 0U;
    std::uint32_t sampleRate = 0U;
    std::uint16_t bits = 0U;
    const std::uint8_t* pcm = nullptr;
    std::size_t pcmSize = 0U;
    SampleData metadata;

    std::size_t pos = 12U;
    while (pos + 8U <= bytes.size()) {
        const std::uint8_t* h = bytes.data() + pos;
        const std::uint32_t chunkSize = le32(h + 4U);
        const std::size_t dataPos = pos + 8U;
        if (dataPos > bytes.size() || static_cast<std::size_t>(chunkSize) > bytes.size() - dataPos) {
            return {nullptr, "Corrupt WAV chunk size"};
        }
        if (std::memcmp(h, "fmt ", 4U) == 0 && chunkSize >= 16U) {
            format = le16(bytes.data() + dataPos);
            channels = le16(bytes.data() + dataPos + 2U);
            sampleRate = le32(bytes.data() + dataPos + 4U);
            bits = le16(bytes.data() + dataPos + 14U);
            if (format == 0xFFFEU && chunkSize >= 40U) {
                // WAVE_FORMAT_EXTENSIBLE: first 16 bits of the sub-format GUID are the base format.
                format = le16(bytes.data() + dataPos + 24U);
            }
        } else if (std::memcmp(h, "data", 4U) == 0) {
            pcm = bytes.data() + dataPos;
            pcmSize = static_cast<std::size_t>(chunkSize);
        } else if (std::memcmp(h, "smpl", 4U) == 0) {
            parseWavSmpl(bytes.data() + dataPos, static_cast<std::size_t>(chunkSize), metadata);
        }
        pos = dataPos + static_cast<std::size_t>(chunkSize) + (static_cast<std::size_t>(chunkSize) & 1U);
    }

    if (pcm == nullptr || channels == 0U || channels > 2U || sampleRate == 0U) {
        return {nullptr, "WAV is missing supported format/data chunks"};
    }
    if (format != 1U && format != 3U) return {nullptr, "Unsupported WAV encoding"};
    if ((format == 1U && bits != 8U && bits != 16U && bits != 24U && bits != 32U) ||
        (format == 3U && bits != 32U && bits != 64U)) {
        return {nullptr, "Unsupported WAV bit depth"};
    }

    const std::size_t bytesPerSample = static_cast<std::size_t>(bits / 8U);
    const std::size_t frameBytes = bytesPerSample * channels;
    if (frameBytes == 0U || pcmSize % frameBytes != 0U) return {nullptr, "WAV data is not frame aligned"};
    const std::size_t samples = pcmSize / bytesPerSample;

    auto out = std::make_shared<SampleData>();
    out->name = basenameNoExt(path);
    out->sourcePath = path;
    out->sampleRate = sampleRate;
    out->channels = channels;
    out->rootKey = metadata.rootKey;
    out->fineTuneCents = metadata.fineTuneCents;
    out->loop = metadata.loop;
    out->interleaved.resize(samples);
    for (std::size_t i = 0U; i < samples; ++i) {
        const std::uint8_t* p = pcm + i * bytesPerSample;
        if (format == 1U) {
            out->interleaved[i] = decodePcmLE(p, static_cast<int>(bits));
        } else if (bits == 32U) {
            std::uint32_t u = le32(p);
            float f = 0.0F;
            std::memcpy(&f, &u, sizeof(f));
            out->interleaved[i] = clampAudio(static_cast<double>(f));
        } else {
            std::uint64_t u = static_cast<std::uint64_t>(p[0]) |
                              (static_cast<std::uint64_t>(p[1]) << 8U) |
                              (static_cast<std::uint64_t>(p[2]) << 16U) |
                              (static_cast<std::uint64_t>(p[3]) << 24U) |
                              (static_cast<std::uint64_t>(p[4]) << 32U) |
                              (static_cast<std::uint64_t>(p[5]) << 40U) |
                              (static_cast<std::uint64_t>(p[6]) << 48U) |
                              (static_cast<std::uint64_t>(p[7]) << 56U);
            double d = 0.0;
            std::memcpy(&d, &u, sizeof(d));
            out->interleaved[i] = clampAudio(d);
        }
    }
    if (out->loop.endFrame > out->frameCount()) out->loop.enabled = false;
    return {out, {}};
}

AudioLoadResult AudioFileLoader::loadAiff(const std::string& path) {
    std::vector<std::uint8_t> bytes;
    std::string error;
    if (!readAll(path, bytes, error)) return {nullptr, error};
    if (bytes.size() < 12U || std::memcmp(bytes.data(), "FORM", 4U) != 0) {
        return {nullptr, "Not an AIFF/AIFC FORM file"};
    }
    const bool aifc = std::memcmp(bytes.data() + 8U, "AIFC", 4U) == 0;
    if (!aifc && std::memcmp(bytes.data() + 8U, "AIFF", 4U) != 0) {
        return {nullptr, "Not AIFF/AIFC"};
    }

    std::uint16_t channels = 0U;
    std::uint32_t declaredFrames = 0U;
    std::uint16_t bits = 0U;
    std::uint32_t sampleRate = 0U;
    std::array<char, 5> compression{{'N','O','N','E','\0'}};
    const std::uint8_t* pcm = nullptr;
    std::size_t pcmSize = 0U;
    std::uint8_t rootKey = 60U;

    std::size_t pos = 12U;
    while (pos + 8U <= bytes.size()) {
        const std::uint8_t* h = bytes.data() + pos;
        const std::uint32_t chunkSize = be32(h + 4U);
        const std::size_t dataPos = pos + 8U;
        if (dataPos > bytes.size() || static_cast<std::size_t>(chunkSize) > bytes.size() - dataPos) {
            return {nullptr, "Corrupt AIFF chunk size"};
        }
        if (std::memcmp(h, "COMM", 4U) == 0 && chunkSize >= 18U) {
            const std::uint8_t* c = bytes.data() + dataPos;
            channels = be16(c);
            declaredFrames = be32(c + 2U);
            bits = be16(c + 6U);
            const double sr = extended80ToDouble(c + 8U);
            if (!std::isfinite(sr) || sr < 1000.0 || sr > 768000.0) return {nullptr, "Invalid AIFF sample rate"};
            sampleRate = static_cast<std::uint32_t>(std::llround(sr));
            if (aifc && chunkSize >= 22U) {
                std::memcpy(compression.data(), c + 18U, 4U);
                compression[4] = '\0';
            }
        } else if (std::memcmp(h, "SSND", 4U) == 0 && chunkSize >= 8U) {
            const std::uint8_t* s = bytes.data() + dataPos;
            const std::uint32_t offset = be32(s);
            const std::size_t start = dataPos + 8U + static_cast<std::size_t>(offset);
            const std::size_t chunkEnd = dataPos + static_cast<std::size_t>(chunkSize);
            if (start <= chunkEnd) {
                pcm = bytes.data() + start;
                pcmSize = chunkEnd - start;
            }
        } else if (std::memcmp(h, "INST", 4U) == 0 && chunkSize >= 20U) {
            const std::uint8_t base = bytes[dataPos];
            if (base <= 127U) rootKey = base;
        }
        pos = dataPos + static_cast<std::size_t>(chunkSize) + (static_cast<std::size_t>(chunkSize) & 1U);
    }

    if (pcm == nullptr || channels == 0U || channels > 2U || sampleRate == 0U || bits == 0U) {
        return {nullptr, "AIFF is missing supported COMM/SSND chunks"};
    }
    if (bits != 8U && bits != 16U && bits != 24U && bits != 32U && bits != 64U) {
        return {nullptr, "Unsupported AIFF bit depth"};
    }

    const std::string comp(compression.data());
    const bool littleEndianPcm = aifc && comp == "sowt";
    const bool float32 = aifc && (comp == "fl32" || comp == "FL32");
    const bool float64 = aifc && (comp == "fl64" || comp == "FL64");
    const bool integerPcm = !aifc || comp == "NONE" || comp == "twos" || comp == "sowt";
    if (!integerPcm && !float32 && !float64) return {nullptr, "Unsupported AIFC compression: " + comp};
    if ((float32 && bits != 32U) || (float64 && bits != 64U)) return {nullptr, "AIFC float bit depth mismatch"};

    const std::size_t bytesPerSample = static_cast<std::size_t>(bits / 8U);
    const std::size_t frameBytes = bytesPerSample * channels;
    if (frameBytes == 0U) return {nullptr, "Invalid AIFF frame size"};
    const std::size_t availableFrames = pcmSize / frameBytes;
    const std::size_t frameCount = declaredFrames == 0U ? availableFrames : std::min<std::size_t>(declaredFrames, availableFrames);
    const std::size_t totalSamples = frameCount * channels;

    auto out = std::make_shared<SampleData>();
    out->name = basenameNoExt(path);
    out->sourcePath = path;
    out->sampleRate = sampleRate;
    out->channels = channels;
    out->rootKey = rootKey;
    out->interleaved.resize(totalSamples);

    for (std::size_t i = 0U; i < totalSamples; ++i) {
        const std::uint8_t* p = pcm + i * bytesPerSample;
        if (integerPcm) {
            out->interleaved[i] = littleEndianPcm ? decodePcmLE(p, static_cast<int>(bits)) : decodePcmBE(p, static_cast<int>(bits));
        } else if (float32) {
            const std::uint32_t u = be32(p);
            float f = 0.0F;
            std::memcpy(&f, &u, sizeof(f));
            out->interleaved[i] = clampAudio(static_cast<double>(f));
        } else {
            const std::uint64_t u = be64(p);
            double d = 0.0;
            std::memcpy(&d, &u, sizeof(d));
            out->interleaved[i] = clampAudio(d);
        }
    }
    return {out, {}};
}

} // namespace silveton::sampler

namespace silveton::sampler {
AudioLoadResult AudioFileLoader::loadWavStreaming(const std::string& path, std::uint64_t preloadFrames) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {nullptr, "Cannot open WAV for streaming: " + path};
    std::array<std::uint8_t, 12U> head{};
    if (!f.read(reinterpret_cast<char*>(head.data()), static_cast<std::streamsize>(head.size()))) {
        return {nullptr, "WAV header is truncated"};
    }
    const bool rf64 = std::memcmp(head.data(), "RF64", 4U) == 0;
    if ((!rf64 && std::memcmp(head.data(), "RIFF", 4U) != 0) || std::memcmp(head.data() + 8U, "WAVE", 4U) != 0) {
        return {nullptr, "Not a RIFF/RF64 WAVE file"};
    }

    std::uint16_t format = 0U;
    std::uint16_t channels = 0U;
    std::uint32_t sampleRate = 0U;
    std::uint16_t bits = 0U;
    std::uint64_t dataOffset = 0U;
    std::uint64_t dataBytes = 0U;
    std::uint64_t rf64DataBytes = 0U;
    SampleData metadata;

    while (f) {
        std::array<std::uint8_t, 8U> ch{};
        if (!f.read(reinterpret_cast<char*>(ch.data()), static_cast<std::streamsize>(ch.size()))) break;
        const std::uint32_t size32 = le32(ch.data() + 4U);
        const std::streamoff payload = f.tellg();
        if (payload < 0) return {nullptr, "Invalid WAV stream position"};
        std::uint64_t size = size32;
        if (std::memcmp(ch.data(), "data", 4U) == 0 && rf64 && size32 == 0xFFFFFFFFU) {
            if (rf64DataBytes == 0U) return {nullptr, "RF64 data chunk appeared before valid ds64 metadata"};
            size = rf64DataBytes;
        }
        if (std::memcmp(ch.data(), "ds64", 4U) == 0) {
            if (!rf64 || size32 < 28U) return {nullptr, "Invalid RF64 ds64 chunk"};
            std::vector<std::uint8_t> ds64(size32);
            if (!f.read(reinterpret_cast<char*>(ds64.data()), static_cast<std::streamsize>(ds64.size()))) return {nullptr, "Truncated RF64 ds64 chunk"};
            rf64DataBytes = le64(ds64.data() + 8U);
        } else if (std::memcmp(ch.data(), "fmt ", 4U) == 0) {
            if (size < 16U) return {nullptr, "WAV fmt chunk is too short"};
            std::vector<std::uint8_t> fmt(static_cast<std::size_t>(size));
            if (!f.read(reinterpret_cast<char*>(fmt.data()), static_cast<std::streamsize>(fmt.size()))) return {nullptr, "Truncated WAV fmt chunk"};
            format = le16(fmt.data());
            channels = le16(fmt.data() + 2U);
            sampleRate = le32(fmt.data() + 4U);
            bits = le16(fmt.data() + 14U);
            if (format == 0xFFFEU && size >= 40U) format = le16(fmt.data() + 24U);
        } else if (std::memcmp(ch.data(), "data", 4U) == 0) {
            dataOffset = static_cast<std::uint64_t>(payload);
            dataBytes = size;
            f.seekg(static_cast<std::streamoff>(size), std::ios::cur);
        } else if (std::memcmp(ch.data(), "smpl", 4U) == 0) {
            std::vector<std::uint8_t> smpl(static_cast<std::size_t>(size));
            if (!f.read(reinterpret_cast<char*>(smpl.data()), static_cast<std::streamsize>(smpl.size()))) return {nullptr, "Truncated WAV smpl chunk"};
            parseWavSmpl(smpl.data(), smpl.size(), metadata);
        } else {
            f.seekg(static_cast<std::streamoff>(size), std::ios::cur);
        }
        if ((size & 1U) != 0U) f.seekg(1, std::ios::cur);
    }

    if (dataOffset == 0U || dataBytes == 0U || channels == 0U || channels > 2U || sampleRate == 0U) {
        return {nullptr, "WAV is missing supported format/data chunks"};
    }
    if (format != 1U && format != 3U) return {nullptr, "Unsupported streaming WAV encoding"};
    if ((format == 1U && bits != 8U && bits != 16U && bits != 24U && bits != 32U) ||
        (format == 3U && bits != 32U)) {
        return {nullptr, "Unsupported streaming WAV bit depth"};
    }
    const std::uint64_t bytesPerSample = bits / 8U;
    const std::uint64_t frameBytes = bytesPerSample * channels;
    if (frameBytes == 0U || dataBytes % frameBytes != 0U) return {nullptr, "WAV data is not frame aligned"};
    const std::uint64_t frames = dataBytes / frameBytes;

    MappedPcmSpec spec;
    spec.dataOffset = dataOffset;
    spec.frameCount = frames;
    spec.sampleRate = sampleRate;
    spec.channels = channels;
    spec.bitDepth = bits;
    spec.formatTag = format;
    spec.bigEndian = false;
    std::string mapError;
    auto stream = MappedPcmStream::open(path, spec, mapError);
    if (!stream) return {nullptr, mapError};

    auto out = std::make_shared<SampleData>();
    out->name = basenameNoExt(path);
    out->sourcePath = path;
    out->sampleRate = sampleRate;
    out->channels = channels;
    out->rootKey = metadata.rootKey;
    out->fineTuneCents = metadata.fineTuneCents;
    out->loop = metadata.loop;
    out->stream = stream;
    out->totalFrames = frames;
    const std::uint64_t preload = std::min(preloadFrames, frames);
    out->interleaved.resize(static_cast<std::size_t>(preload) * static_cast<std::size_t>(channels));
    for (std::uint64_t frame = 0U; frame < preload; ++frame) {
        for (std::uint16_t chn = 0U; chn < channels; ++chn) {
            out->interleaved[static_cast<std::size_t>(frame) * channels + chn] = stream->readFrame(frame, chn);
        }
    }
    if (out->loop.endFrame > frames) out->loop.enabled = false;
    return {out, {}};
}
} // namespace silveton::sampler

namespace silveton::sampler {
AudioLoadResult AudioFileLoader::loadAiffStreaming(const std::string& path, std::uint64_t preloadFrames) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {nullptr, "Cannot open AIFF for streaming: " + path};
    std::array<std::uint8_t, 12U> head{};
    if (!f.read(reinterpret_cast<char*>(head.data()), static_cast<std::streamsize>(head.size()))) {
        return {nullptr, "AIFF header is truncated"};
    }
    if (std::memcmp(head.data(), "FORM", 4U) != 0) return {nullptr, "Not an AIFF/AIFC FORM file"};
    const bool aifc = std::memcmp(head.data() + 8U, "AIFC", 4U) == 0;
    if (!aifc && std::memcmp(head.data() + 8U, "AIFF", 4U) != 0) return {nullptr, "Not AIFF/AIFC"};

    std::uint16_t channels = 0U;
    std::uint32_t declaredFrames = 0U;
    std::uint16_t bits = 0U;
    std::uint32_t sampleRate = 0U;
    std::array<char, 5> compression{{'N','O','N','E','\0'}};
    std::uint64_t dataOffset = 0U;
    std::uint64_t dataBytes = 0U;
    std::uint8_t rootKey = 60U;

    while (f) {
        std::array<std::uint8_t, 8U> ch{};
        if (!f.read(reinterpret_cast<char*>(ch.data()), static_cast<std::streamsize>(ch.size()))) break;
        const std::uint32_t size = be32(ch.data() + 4U);
        const std::streamoff payload = f.tellg();
        if (payload < 0) return {nullptr, "Invalid AIFF stream position"};
        if (std::memcmp(ch.data(), "COMM", 4U) == 0) {
            if (size < 18U) return {nullptr, "AIFF COMM chunk is too short"};
            std::vector<std::uint8_t> comm(size);
            if (!f.read(reinterpret_cast<char*>(comm.data()), static_cast<std::streamsize>(comm.size()))) return {nullptr, "Truncated AIFF COMM chunk"};
            channels = be16(comm.data());
            declaredFrames = be32(comm.data() + 2U);
            bits = be16(comm.data() + 6U);
            const double sr = extended80ToDouble(comm.data() + 8U);
            if (!std::isfinite(sr) || sr < 1000.0 || sr > 768000.0) return {nullptr, "Invalid AIFF sample rate"};
            sampleRate = static_cast<std::uint32_t>(std::llround(sr));
            if (aifc && size >= 22U) {
                std::memcpy(compression.data(), comm.data() + 18U, 4U);
                compression[4] = '\0';
            }
        } else if (std::memcmp(ch.data(), "SSND", 4U) == 0) {
            if (size < 8U) return {nullptr, "AIFF SSND chunk is too short"};
            std::array<std::uint8_t, 8U> ssnd{};
            if (!f.read(reinterpret_cast<char*>(ssnd.data()), static_cast<std::streamsize>(ssnd.size()))) return {nullptr, "Truncated AIFF SSND chunk"};
            const std::uint32_t offset = be32(ssnd.data());
            if (static_cast<std::uint64_t>(offset) > static_cast<std::uint64_t>(size - 8U)) return {nullptr, "Invalid AIFF SSND offset"};
            const std::streamoff rawStart = f.tellg();
            if (rawStart < 0) return {nullptr, "Invalid AIFF SSND position"};
            dataOffset = static_cast<std::uint64_t>(rawStart) + offset;
            dataBytes = static_cast<std::uint64_t>(size - 8U) - offset;
            f.seekg(static_cast<std::streamoff>(size - 8U), std::ios::cur);
        } else if (std::memcmp(ch.data(), "INST", 4U) == 0) {
            std::vector<std::uint8_t> inst(size);
            if (!f.read(reinterpret_cast<char*>(inst.data()), static_cast<std::streamsize>(inst.size()))) return {nullptr, "Truncated AIFF INST chunk"};
            if (!inst.empty() && inst[0] <= 127U) rootKey = inst[0];
        } else {
            f.seekg(static_cast<std::streamoff>(size), std::ios::cur);
        }
        if ((size & 1U) != 0U) f.seekg(1, std::ios::cur);
    }

    if (dataOffset == 0U || dataBytes == 0U || channels == 0U || channels > 2U || sampleRate == 0U || bits == 0U) {
        return {nullptr, "AIFF is missing supported COMM/SSND chunks"};
    }
    const std::string comp(compression.data());
    const bool littleEndianPcm = aifc && comp == "sowt";
    const bool float32 = aifc && (comp == "fl32" || comp == "FL32");
    const bool float64 = aifc && (comp == "fl64" || comp == "FL64");
    const bool integerPcm = !aifc || comp == "NONE" || comp == "twos" || comp == "sowt";
    if (!integerPcm && !float32 && !float64) return {nullptr, "Unsupported AIFC compression: " + comp};
    if ((integerPcm && bits != 8U && bits != 16U && bits != 24U && bits != 32U) ||
        (float32 && bits != 32U) || (float64 && bits != 64U)) {
        return {nullptr, "Unsupported streaming AIFF bit depth"};
    }
    const std::uint64_t bytesPerSample = bits / 8U;
    const std::uint64_t frameBytes = bytesPerSample * channels;
    if (frameBytes == 0U) return {nullptr, "Invalid AIFF frame size"};
    const std::uint64_t availableFrames = dataBytes / frameBytes;
    const std::uint64_t frames = declaredFrames == 0U ? availableFrames : std::min<std::uint64_t>(declaredFrames, availableFrames);
    if (frames == 0U) return {nullptr, "AIFF contains no audio frames"};

    MappedPcmSpec spec;
    spec.dataOffset = dataOffset;
    spec.frameCount = frames;
    spec.sampleRate = sampleRate;
    spec.channels = channels;
    spec.bitDepth = bits;
    spec.formatTag = (float32 || float64) ? 3U : 1U;
    spec.bigEndian = !littleEndianPcm;
    std::string mapError;
    auto stream = MappedPcmStream::open(path, spec, mapError);
    if (!stream) return {nullptr, mapError};

    auto out = std::make_shared<SampleData>();
    out->name = basenameNoExt(path);
    out->sourcePath = path;
    out->sampleRate = sampleRate;
    out->channels = channels;
    out->rootKey = rootKey;
    out->stream = stream;
    out->totalFrames = frames;
    const std::uint64_t preload = std::min(preloadFrames, frames);
    out->interleaved.resize(static_cast<std::size_t>(preload) * static_cast<std::size_t>(channels));
    for (std::uint64_t frame = 0U; frame < preload; ++frame) {
        for (std::uint16_t chn = 0U; chn < channels; ++chn) {
            out->interleaved[static_cast<std::size_t>(frame) * channels + chn] = stream->readFrame(frame, chn);
        }
    }
    return {out, {}};
}
} // namespace silveton::sampler
