// SILVETON_ENGINES_V1 / V2 - the parameter tables of the nine engines (see EngineDefs.h).
#include "silveton/sampler/EngineDefs.h"
#include "silveton/sampler/ModelDefs.h"   // SILVETON_MODEL_V1

#include <algorithm>
#include <cmath>

namespace silveton::sampler {
namespace {

using K = EngineKind;
constexpr const char* kNone = "";
constexpr const char* kOctNames = "-2 OCT|-1 OCT|0 OCT|+1 OCT|+2 OCT";   // SILVETON_OCTAVE_V1

// ---------------------------------------------------------------- the common pages
const EngineParamDef kFilterPage[] = {
    {E_FILT_TYPE, "FILTER", "Видът на главния филтър", K::Choice, 0.0F, 5.0F, 1.0F, 1.0F, 0, "OFF|LP24|KORG35|LP12|HP12|BP12"},
    {E_CUTOFF, "CUTOFF", "Честота на среза Hz", K::Hz, 20.0F, 20000.0F, 20000.0F, 1.0F, 0, kNone},
    {E_RESO, "RESON", "Резонанс %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_KEYTRACK, "KEY TRACK", "Срезът следва клавиша %", K::Pct, -1.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_FEG_AMT, "F.EG AMT", "Обвивка към среза (октави)", K::Oct, -8.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_FEG_A, "F.ATTACK", "Атака на филтъра ms", K::Ms, 1.0F, 10000.0F, 5.0F, 1.0F, 0, kNone},
    {E_FEG_D, "F.DECAY", "Decay на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_FEG_S, "F.SUSTAIN", "Sustain на филтъра %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_FEG_R, "F.RELEASE", "Release на филтъра ms", K::Ms, 1.0F, 20000.0F, 200.0F, 1.0F, 0, kNone},
    {E_VEL_CUT, "VEL→CUT", "Силата отваря среза (октави)", K::Oct, 0.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_DRIVE, "DRIVE", "Насищане преди филтъра %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_F2_TYPE, "FILTER 2", "Втори филтър", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "OFF|LP|HP|BP|BR"},
    {E_F2_CUT, "CUTOFF 2", "Срез на втория филтър Hz", K::Hz, 20.0F, 20000.0F, 1000.0F, 1.0F, 0, kNone},
    {E_F2_RES, "RESON 2", "Резонанс на втория %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_F2_PAR, "ROUTING", "Вторият филтър е след първия или до него", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "SERIES|PARALLEL"},
};

const EngineParamDef kModPage[] = {
    {E_LFO_RATE, "LFO RATE", "Скорост на LFO Hz", K::Hz, 0.05F, 30.0F, 5.0F, 0.01F, 2, kNone},
    {E_LFO_WAVE, "LFO WAVE", "Форма на LFO", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "SINE|TRI|SAW|SQUARE|S&H"},
    {E_LFO_PITCH, "LFO→PITCH", "LFO към височината (cents)", K::Cents, 0.0F, 1200.0F, 0.0F, 1.0F, 0, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "LFO към среза (октави)", K::Oct, -4.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {E_LFO_AMP, "LFO→AMP", "LFO към силата %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_UNISON, "UNISON", "Копия на всяка нота", K::Lin, 1.0F, 4.0F, 1.0F, 1.0F, 0, kNone},
    {E_UNI_DET, "DETUNE", "Разстройка на копията (cents)", K::Cents, 0.0F, 100.0F, 8.0F, 1.0F, 0, kNone},
    {E_UNI_SPREAD, "SPREAD", "Стерео ширина на копията %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {E_ANALOG, "ANALOG", "Жив аналог %: разлики на всяка нота, бавно плаваща височина и яркост, лека ширина", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_BEND_UP, "BEND +", "Pitch bend нагоре в полутонове (UPPER = колкото е на VOICE, OFF = без)", K::Bend, -1.0F, 24.0F, 0.0F, 1.0F, 0, kNone},
    {E_BEND_DOWN, "BEND −", "Pitch bend надолу в полутонове (UPPER = колкото е на VOICE, OFF = без)", K::Bend, -1.0F, 24.0F, 0.0F, 1.0F, 0, kNone},
};
// the МОД page of CX-3 has one more key
const EngineParamDef kModPageCx3[] = {
    {E_LFO_RATE, "LFO RATE", "Скорост на LFO Hz", K::Hz, 0.05F, 30.0F, 5.0F, 0.01F, 2, kNone},
    {E_LFO_WAVE, "LFO WAVE", "Форма на LFO", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "SINE|TRI|SAW|SQUARE|S&H"},
    {E_LFO_PITCH, "LFO→PITCH", "LFO към височината (cents)", K::Cents, 0.0F, 1200.0F, 0.0F, 1.0F, 0, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "LFO към среза (октави)", K::Oct, -4.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {E_LFO_AMP, "LFO→AMP", "LFO към силата %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_ANALOG, "ANALOG", "Жив аналог %: разлики на всяка нота, бавно плаваща височина и яркост, лека ширина", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {CX_WHEEL_ROT, "WHEEL→LESLIE", "Лостчето за модулация превключва бавно / бързо", K::Switch, 0.0F, 1.0F, 1.0F, 1.0F, 0, kNone},
    {E_BEND_UP, "BEND +", "Pitch bend нагоре в полутонове (UPPER = колкото е на VOICE, OFF = без)", K::Bend, -1.0F, 24.0F, 0.0F, 1.0F, 0, kNone},
    {E_BEND_DOWN, "BEND −", "Pitch bend надолу в полутонове (UPPER = колкото е на VOICE, OFF = без)", K::Bend, -1.0F, 24.0F, 0.0F, 1.0F, 0, kNone},
};

// ---------------------------------------------------------------- the ЗВУК pages
// SILVETON_ENGINES_V3: where the sound comes from (every engine with a generator of its own shows it first)
#define SV_SOURCE_KEY {E_SOURCE, "ЗВУК ОТ", "Откъде е звукът: ДВЕТЕ = собственият генератор и записът · СОБСТВЕН = само генераторът · СЕМПЪЛ = само записът", K::Choice, 0.0F, 2.0F, 0.0F, 1.0F, 0, "ДВЕТЕ|СОБСТВЕН|СЕМПЪЛ"}
const EngineParamDef kHd1Page[] = {
    {HD_BOOST, "LOW BOOST", "Повдигане на баса dB", K::Db, 0.0F, 12.0F, 0.0F, 0.1F, 1, kNone},
    {HD_PEG_CENTS, "PITCH EG", "Обвивка на височината (cents, от началото към тона)", K::Cents, -1200.0F, 1200.0F, 0.0F, 1.0F, 0, kNone},
    {HD_PEG_TIME, "PEG TIME", "Време на обвивката на височината ms", K::Ms, 1.0F, 5000.0F, 80.0F, 1.0F, 0, kNone},
    {HD_PEG_VEL, "VEL→PEG", "Силата на удара води обвивката на височината %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {HD_INTERP, "INTERP", "Четене на записа: STUDIO (sinc по честотата) · CUBIC (4 точки) · SINC 16 / 32 точки", K::Choice, 0.0F, 3.0F, 0.0F, 1.0F, 0, "STUDIO|CUBIC|SINC 16|SINC 32"},
};

const EngineParamDef kPolysixPage[] = {
    SV_SOURCE_KEY,
    {P6_REC_LEVEL, "RECORD", "Ниво на самия запис %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {P6_FILT_SAT, "FILT SAT", "Насищане на стъпалата на ladder филтъра %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {P6_FX_TYPE, "EFFECT", "Вграденият ефект на Polysix", K::Choice, 0.0F, 3.0F, 3.0F, 1.0F, 0, "OFF|CHORUS|PHASE|ENSEMBLE"},
    {P6_FX_SPEED, "FX SPEED", "Скорост на ефекта Hz", K::Hz, 0.1F, 5.0F, 0.6F, 0.01F, 2, kNone},
    {P6_FX_DEPTH, "FX DEPTH", "Дълбочина на ефекта %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {P6_FX_MIX, "FX MIX", "Смес на ефекта %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};

const EngineParamDef kMs20Page[] = {
    SV_SOURCE_KEY,
    {MS_REC_LEVEL, "RECORD", "Ниво на самия запис %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {MS_HPF_CUT, "HPF CUTOFF", "Високопропускащ филтър Hz", K::Hz, 20.0F, 20000.0F, 20.0F, 1.0F, 0, kNone},
    {MS_HPF_PEAK, "HPF PEAK", "Резонанс (PEAK) на HPF %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {MS_EG1_DELAY, "EG1 DELAY", "EG1: закъснение ms", K::Ms, 0.0F, 5000.0F, 0.0F, 1.0F, 0, kNone},
    {MS_EG1_ATTACK, "EG1 ATTACK", "EG1: атака ms", K::Ms, 1.0F, 10000.0F, 50.0F, 1.0F, 0, kNone},
    {MS_EG1_RELEASE, "EG1 RELEASE", "EG1: отпускане ms", K::Ms, 1.0F, 10000.0F, 200.0F, 1.0F, 0, kNone},
    {MS_EG1_PITCH, "EG1→PITCH", "EG1 към височината (полутонове)", K::Semis, -24.0F, 24.0F, 0.0F, 0.1F, 1, kNone},
    {MS_EG1_HPF, "EG1→HPF", "EG1 към HPF (октави)", K::Oct, -8.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {MS_MG_HPF, "MG→HPF", "LFO (MG) към HPF (октави)", K::Oct, -4.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {MS_WHEEL_TO, "WHEEL→", "Лостчето за модулация отива към", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "OFF|PITCH|LPF|HPF|AMP"},
    {MS_WHEEL_AMT, "WHEEL AMT", "Колко лостчето действа %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};
constexpr const char* kMsSources = "OFF|EG1|EG2|MG|WHEEL|ESP|S&H|NOISE|VEL|KEY";
constexpr const char* kMsDests = "PITCH|LPF|HPF|AMP|LP PEAK|HP PEAK|MG RATE|PW";
const EngineParamDef kMs20Patch[] = {
    {MS_P1_SRC, "CABLE 1", "Кабел 1: откъде (EG2 = обвивката на филтъра, ESP = следи записа)", K::Choice, 0.0F, 9.0F, 0.0F, 1.0F, 0, kMsSources},
    {MS_P1_DST, "→ 1", "Кабел 1: накъде", K::Choice, 0.0F, 7.0F, 1.0F, 1.0F, 0, kMsDests},
    {MS_P1_AMT, "AMT 1", "Кабел 1: колко %", K::Pct, -1.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {MS_P2_SRC, "CABLE 2", "Кабел 2: откъде", K::Choice, 0.0F, 9.0F, 0.0F, 1.0F, 0, kMsSources},
    {MS_P2_DST, "→ 2", "Кабел 2: накъде", K::Choice, 0.0F, 7.0F, 2.0F, 1.0F, 0, kMsDests},
    {MS_P2_AMT, "AMT 2", "Кабел 2: колко %", K::Pct, -1.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {MS_P3_SRC, "CABLE 3", "Кабел 3: откъде", K::Choice, 0.0F, 9.0F, 0.0F, 1.0F, 0, kMsSources},
    {MS_P3_DST, "→ 3", "Кабел 3: накъде", K::Choice, 0.0F, 7.0F, 0.0F, 1.0F, 0, kMsDests},
    {MS_P3_AMT, "AMT 3", "Кабел 3: колко %", K::Pct, -1.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {MS_SH_RATE, "S&H RATE", "Такт на sample & hold Hz", K::Hz, 0.1F, 50.0F, 4.0F, 0.01F, 2, kNone},
    {MS_ESP_SENS, "ESP SENS", "Чувствителност на envelope follower-а (следи записа) %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {MS_MODEL, "MODEL", "Филтрите: LINEAR (чисто) или ANALOG (нелинейна обратна връзка, решавана итеративно)", K::Choice, 0.0F, 1.0F, 1.0F, 1.0F, 0, "LINEAR|ANALOG"},
    {MS_ROUTE, "ROUTE", "HPF → LPF последователно (както в MS-20) или успоредно", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "HP→LP|PARALLEL"},
    {MS_FB_SAT, "FB SAT", "Насищане на обратната връзка на филтрите %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};

const EngineParamDef kAl1Page[] = {
    SV_SOURCE_KEY,
    {AL_FM_AMT, "PCM FM", "Фазова модулация на записа %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {AL_FM_RATIO, "FM RATIO", "Отношение на модулатора към тона (0.25 · 0.5 · 1 · 2 · 3 ... - звукът остава в тоналността си)", K::Lin, 0.25F, 8.0F, 1.0F, 0.25F, 2, kNone},
    {AL_FM_EG, "FM←EG", "Обвивката на филтъра води FM %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_RING_LEVEL, "PCM RING", "Ring модулация на записа %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_RING_RATIO, "RING RATIO", "Отношение на ring модулатора (0.25 · 0.5 · 1 · 2 · 3 ... - звукът остава в тоналността си)", K::Lin, 0.25F, 8.0F, 2.0F, 0.25F, 2, kNone},
    {AL_SYNC, "PCM SYNC", "Твърда синхронизация (записът се рестартира на всеки период)", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {AL_SYNC_RATIO, "SYNC RATIO", "Колко по-високо свири синхронизираният запис", K::Lin, 1.0F, 4.0F, 1.5F, 0.01F, 2, kNone},
    {AL_SUB_LEVEL, "SUB", "Суб-осцилатор %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_SUB_OCT, "SUB OCT", "Суб-осцилаторът една или две октави надолу", K::Choice, 1.0F, 2.0F, 1.0F, 1.0F, 0, "-1 OCT|-2 OCT"},
    {AL_NOISE_LEVEL, "NOISE", "Шум %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_NOISE_COLOR, "NOISE COLOR", "Цвят на шума (срез Hz)", K::Hz, 100.0F, 20000.0F, 8000.0F, 1.0F, 0, kNone},
    {AL_SHAPE, "SHAPE", "Прегъване на вълната %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};
const EngineParamDef kAl1Osc[] = {
    {AL_OSC1_WAVE, "OSC 1", "Осцилатор 1 (band-limited)", K::Choice, 0.0F, 20.0F, 0.0F, 1.0F, 0, "OFF|SAW|PULSE|TRI|SINE|" SILVETON_USER_WAVE_NAMES},
    {AL_OSC1_OCT, "OSC1 ОКТАВА", "Октава на осцилатор 1", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {AL_OSC1_LEVEL, "OSC1 LEVEL", "Ниво на осцилатор 1 %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {AL_OSC2_WAVE, "OSC 2", "Осцилатор 2 (band-limited)", K::Choice, 0.0F, 20.0F, 0.0F, 1.0F, 0, "OFF|SAW|PULSE|TRI|SINE|" SILVETON_USER_WAVE_NAMES},
    {AL_OSC2_OCT, "OSC2 ОКТАВА", "Октава на осцилатор 2", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {AL_OSC2_LEVEL, "OSC2 LEVEL", "Ниво на осцилатор 2 %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {AL_OSC2_SEMI, "OSC2 SEMI", "Осцилатор 2 спрямо 1 (полутонове)", K::Semis, -24.0F, 24.0F, 0.0F, 1.0F, 0, kNone},
    {AL_OSC2_FINE, "OSC2 FINE", "Фина настройка на осцилатор 2 (cents)", K::Cents, -100.0F, 100.0F, 7.0F, 1.0F, 0, kNone},
    {AL_PW, "PW", "Ширина на импулса %", K::Pct, 0.05F, 0.95F, 0.5F, 0.01F, 0, kNone},
    {AL_PWM, "PWM", "LFO люлее ширината на импулса %", K::Pct, 0.0F, 0.45F, 0.0F, 0.01F, 0, kNone},
    {AL_OSC_SYNC, "OSC SYNC", "Осцилатор 2 се синхронизира твърдо с 1", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {AL_OSC_FM, "OSC FM", "Осцилатор 2 модулира фазата на осцилатор 1 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {AL_OSC_RING, "OSC RING", "Ring на осцилатор 1 x 2 %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_REC_LEVEL, "RECORD", "Ниво на самия запис %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
};

const EngineParamDef kMod7Page[] = {
    SV_SOURCE_KEY,
    {M7_OP2_RATIO, "OP2 RATIO", "Отношение на оператор 2 (0.25 · 0.5 · 1 · 2 · 3 ... - в тоналността)", K::Lin, 0.25F, 16.0F, 1.0F, 0.25F, 2, kNone},
    {M7_OP2_LEVEL, "OP2 LEVEL", "Ниво на оператор 2 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP3_RATIO, "OP3 RATIO", "Отношение на оператор 3 (0.25 · 0.5 · 1 · 2 · 3 ... - в тоналността)", K::Lin, 0.25F, 16.0F, 2.0F, 0.25F, 2, kNone},
    {M7_OP3_LEVEL, "OP3 LEVEL", "Ниво на оператор 3 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP3_TARGET, "OP3→", "(ALGO 1) Оператор 3 модулира оператор 2 или направо записа", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "OP2|RECORD"},
    {M7_FEEDBACK, "FEEDBACK", "Обратна връзка на последния оператор %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_FM_EG, "FM←EG", "Обвивката на филтъра води модулаторите %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_FM_VEL, "FM←VEL", "Силата на натиска води модулаторите %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_RING, "RING", "Оператор 2 като ring модулатор на записа %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_WS_TYPE, "SHAPER", "Waveshaper", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "OFF|SOFT|HARD|FOLD|SINE"},
    {M7_WS_DRIVE, "WS DRIVE", "Колко силно се оформя %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {M7_WS_MIX, "WS MIX", "Смес на оформеното %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {M7_BRIGHT, "BRIGHTNESS", "Макро: всички модулатори по-силни / по-слаби", K::Pct, -1.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};
const EngineParamDef kMod7Ops[] = {
    {M7_ALGO, "ALGORITHM", "Кой оператор кого модулира (6 x 6 матрица); 1 = записът с OP2 / OP3 както досега", K::Choice, 0.0F, 11.0F, 0.0F, 1.0F, 0,
     "1 PCM←2←3|2 PCM←2 ←3←4|3 PCM←2+3+4|4 2 CARRIERS|5 3 CARRIERS|6 FAN 6→ALL|7 PAIRS|8 FB CHAIN|9 ORGAN|10 BELL|11 PCM+5|12 ALL→PCM"},
    {M7_OP4_RATIO, "OP4 RATIO", "Отношение на оператор 4 (0.25 · 0.5 · 1 · 2 · 3 ... - в тоналността)", K::Lin, 0.25F, 16.0F, 1.0F, 0.25F, 2, kNone},
    {M7_OP4_LEVEL, "OP4 LEVEL", "Ниво на оператор 4 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP5_RATIO, "OP5 RATIO", "Отношение на оператор 5 (0.25 · 0.5 · 1 · 2 · 3 ... - в тоналността)", K::Lin, 0.25F, 16.0F, 3.0F, 0.25F, 2, kNone},
    {M7_OP5_LEVEL, "OP5 LEVEL", "Ниво на оператор 5 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP6_RATIO, "OP6 RATIO", "Отношение на оператор 6 (0.25 · 0.5 · 1 · 2 · 3 ... - в тоналността)", K::Lin, 0.25F, 16.0F, 1.0F, 0.25F, 2, kNone},
    {M7_OP6_LEVEL, "OP6 LEVEL", "Ниво на оператор 6 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP_LEVEL, "OPS OUT", "Ниво на синусовите носители (операторите, които звучат сами) %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {M7_PCM_LEVEL, "PCM LEVEL", "Ниво на записа (оператор 1) %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {M7_FINE, "OP DETUNE", "Фина разстройка на четните оператори (cents)", K::Cents, -50.0F, 50.0F, 0.0F, 1.0F, 0, kNone},
    {M7_ENV_A, "MOD ATTACK", "Обвивка на модулаторите: атака ms", K::Ms, 1.0F, 10000.0F, 2.0F, 1.0F, 0, kNone},
    {M7_ENV_D, "MOD DECAY", "Обвивка на модулаторите: decay ms", K::Ms, 1.0F, 20000.0F, 600.0F, 1.0F, 0, kNone},
    {M7_ENV_S, "MOD SUSTAIN", "Обвивка на модулаторите: sustain %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {M7_ENV_R, "MOD RELEASE", "Обвивка на модулаторите: release ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {M7_ENV_AMT, "MOD ENV AMT", "Колко обвивката води модулаторите %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_PEG, "PITCH EG", "Обвивка на височината (полутонове, от началото към тона)", K::Semis, -24.0F, 24.0F, 0.0F, 0.1F, 1, kNone},
    {M7_PEG_TIME, "PEG TIME", "Време на обвивката на височината ms", K::Ms, 1.0F, 5000.0F, 60.0F, 1.0F, 0, kNone},
    {M7_OVERSAMPLE, "OVERSAMPLE", "Операторите на двойна честота (по-чисто при дълбока модулация)", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {M7_OP2_WAVE, "OP2 WAVE", "Вълна на оператор 2", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "SINE|" SILVETON_USER_WAVE_NAMES},
    {M7_OP3_WAVE, "OP3 WAVE", "Вълна на оператор 3", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "SINE|" SILVETON_USER_WAVE_NAMES},
    {M7_OP4_WAVE, "OP4 WAVE", "Вълна на оператор 4", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "SINE|" SILVETON_USER_WAVE_NAMES},
    {M7_OP5_WAVE, "OP5 WAVE", "Вълна на оператор 5", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "SINE|" SILVETON_USER_WAVE_NAMES},
    {M7_OP6_WAVE, "OP6 WAVE", "Вълна на оператор 6", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "SINE|" SILVETON_USER_WAVE_NAMES},
};

const EngineParamDef kStr1Page[] = {
    SV_SOURCE_KEY,
    {ST_BODY_TYPE, "INSTRUMENT", "Инструментът (зарежда типичните му стойности): струнни и духови", K::Choice, 0.0F, 9.0F, 0.0F, 1.0F, 0, "GUITAR|VIOLIN|CELLO|HARP|SAX ALTO|SAX TENOR|CLARINET|TRUMPET|KAVAL|GAIDA"},
    {ST_STYLE, "STYLE", "Как се свири: китара PICK / FINGER / MUTE / HARMONIC · цигулка и чело ARCO (лък) / PIZZ / TREMOLO / SPICCATO · арфа NORMAL / HARMONIC / MUTED / PRES TABLE", K::Choice, 0.0F, 3.0F, 0.0F, 1.0F, 0, "PICK|FINGER|MUTE|HARMONIC"},
    {ST_BODY, "BODY", "Корпусът на инструмента %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {ST_STRING, "STRING", "Ниво на струната %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {ST_EXCITE, "EXCITE", "Ниво на самия запис (възбудителя) %", K::Pct, 0.0F, 1.0F, 0.2F, 0.01F, 0, kNone},
    {ST_EXC_LEN, "EXC LENGTH", "Колко дълго записът храни струната ms (0 = през цялото време)", K::Ms, 0.0F, 2000.0F, 40.0F, 1.0F, 0, kNone},
    {ST_PLUCK, "PLUCK", "Собствено дръпване %. На 0 и без запис струната се дърпа сама (80 %)", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {ST_PLUCK_COLOR, "PLUCK COLOR", "Цвят на дръпването Hz", K::Hz, 200.0F, 16000.0F, 4000.0F, 1.0F, 0, kNone},
    {ST_DECAY, "DECAY", "Затихване на струната s", K::Sec, 0.05F, 20.0F, 2.5F, 0.01F, 2, kNone},
    {ST_DAMP, "DAMPING", "Загуба на високите в струната %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {ST_DISP, "DISPERSION", "Нехармоничност (пиано-струна) %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {ST_PICK, "PICK POS", "Къде се дърпа струната %", K::Pct, 0.02F, 0.5F, 0.13F, 0.01F, 0, kNone},
    {ST_PICKUP, "PICKUP POS", "Къде е пикъпът % (2 = до магарето, без пикъп)", K::Pct, 0.02F, 0.5F, 0.2F, 0.01F, 0, kNone},
    {ST_FEEDBACK, "FEEDBACK", "Обратна връзка към струната (като пред усилвател) %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {ST_NONLIN, "NONLINEAR", "Нелинейност на струната %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {ST_TUNE, "STRING TUNE", "Настройка на струната (cents)", K::Cents, -100.0F, 100.0F, 0.0F, 1.0F, 0, kNone},
    {ST_KEY_DECAY, "KEY→DECAY", "Високите тонове затихват по-бързо %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};
// SILVETON_ENGINES_V3: the breath of the winds (the same ids and ranges as the ЛЪК page, plus GROWL)
const EngineParamDef kStr1Wind[] = {
    {ST_BOW_SPEED, "BREATH", "Силата на дъха = сила и яркост на тона %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {ST_BOW_PRESS, "EMBOUCHURE", "Устните / пискунът: малко = мек, тъмен · много = твърд, ярък %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {ST_BOW_ATTACK, "ATTACK", "За колко време дъхът набира сила ms", K::Ms, 5.0F, 2000.0F, 80.0F, 1.0F, 0, kNone},
    {ST_BOW_RELEASE, "RELEASE", "За колко време дъхът спира ms", K::Ms, 5.0F, 2000.0F, 120.0F, 1.0F, 0, kNone},
    {ST_VEL_BOW, "VEL→BREATH", "Силата на натиска на клавиша води дъха %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {ST_BOW_NOISE, "AIR", "Въздухът в тона (шум на дъха) %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {ST_GROWL, "GROWL", "Ръмжене (гърлото пее в инструмента) %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {ST_VIBRATO, "VIBRATO", "Вибрато (cents)", K::Cents, 0.0F, 60.0F, 18.0F, 1.0F, 0, kNone},
    {ST_VIB_RATE, "VIB RATE", "Скорост на вибратото Hz", K::Hz, 2.0F, 9.0F, 5.6F, 0.01F, 2, kNone},
    {ST_VIB_DELAY, "VIB DELAY", "След колко време започва вибратото ms", K::Ms, 0.0F, 2000.0F, 300.0F, 1.0F, 0, kNone},
};
// SILVETON_ENGINES_V3: the bow of VIOLIN / CELLO (ARCO, TREMOLO, SPICCATO) and the left hand
const EngineParamDef kStr1Bow[] = {
    {ST_BOW_PRESS, "BOW PRESS", "Натиск на лъка: малко = мек, въздушен · много = плътен, ярък %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {ST_BOW_SPEED, "BOW SPEED", "Скорост на лъка = сила на тона %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {ST_BOW_POS, "BOW POS", "Къде е лъкът: малко = до магарето (sul ponticello, ярко) · много = над грифа (sul tasto, меко) %", K::Pct, 0.05F, 0.16F, 0.11F, 0.01F, 0, kNone},
    {ST_BOW_ATTACK, "BOW ATTACK", "За колко време лъкът захваща струната ms", K::Ms, 5.0F, 2000.0F, 80.0F, 1.0F, 0, kNone},
    {ST_BOW_RELEASE, "BOW RELEASE", "За колко време лъкът се вдига от струната ms", K::Ms, 5.0F, 2000.0F, 120.0F, 1.0F, 0, kNone},
    {ST_VEL_BOW, "VEL→BOW", "Силата на натиска на клавиша води скоростта на лъка %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {ST_BOW_NOISE, "BOW NOISE", "Шумът на косъма (колофон) %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {ST_TREM_RATE, "TREM RATE", "TREMOLO: колко пъти в секунда лъкът сменя посоката Hz", K::Hz, 2.0F, 20.0F, 8.0F, 0.01F, 2, kNone},
    {ST_VIBRATO, "VIBRATO", "Вибрато на лявата ръка (cents)", K::Cents, 0.0F, 60.0F, 18.0F, 1.0F, 0, kNone},
    {ST_VIB_RATE, "VIB RATE", "Скорост на вибратото Hz", K::Hz, 2.0F, 9.0F, 5.6F, 0.01F, 2, kNone},
    {ST_VIB_DELAY, "VIB DELAY", "След колко време започва вибратото ms", K::Ms, 0.0F, 2000.0F, 300.0F, 1.0F, 0, kNone},
};

const EngineParamDef kCx3Page[] = {
    {CX_DB16, "16'", "Drawbar 16'", K::Drawbar, 0.0F, 8.0F, 8.0F, 1.0F, 0, kNone},
    {CX_DB513, "5⅓'", "Drawbar 5 1/3'", K::Drawbar, 0.0F, 8.0F, 8.0F, 1.0F, 0, kNone},
    {CX_DB8, "8'", "Drawbar 8'", K::Drawbar, 0.0F, 8.0F, 8.0F, 1.0F, 0, kNone},
    {CX_DB4, "4'", "Drawbar 4'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB223, "2⅔'", "Drawbar 2 2/3'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB2, "2'", "Drawbar 2'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB135, "1⅗'", "Drawbar 1 3/5'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB113, "1⅓'", "Drawbar 1 1/3'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB1, "1'", "Drawbar 1'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_PERC, "PERC", "Перкусия на 2-ри или 3-ти хармоник", K::Choice, 0.0F, 2.0F, 0.0F, 1.0F, 0, "OFF|2ND|3RD"},
    {CX_PERC_DECAY, "PERC DECAY", "Затихване на перкусията", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "FAST|SLOW"},
    {CX_PERC_LEVEL, "PERC LEVEL", "Сила на перкусията", K::Choice, 0.0F, 1.0F, 1.0F, 1.0F, 0, "SOFT|NORMAL"},
    {CX_CLICK, "KEY CLICK", "Щракане на клавиша %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {CX_LEAK, "LEAKAGE", "Изтичане между колелата %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {CX_VIBCHO, "VIB/CHO", "Вибрато / хорус скенер", K::Choice, 0.0F, 6.0F, 0.0F, 1.0F, 0, "OFF|V1|C1|V2|C2|V3|C3"},
    {CX_ROTARY, "LESLIE", "Въртящ се говорител", K::Choice, 0.0F, 2.0F, 1.0F, 1.0F, 0, "OFF|SLOW|FAST"},
    {CX_SLOW, "HORN SLOW", "Бавна скорост на рога Hz", K::Hz, 0.3F, 1.5F, 0.75F, 0.01F, 2, kNone},
    {CX_FAST, "HORN FAST", "Бърза скорост на рога Hz", K::Hz, 4.0F, 9.0F, 6.8F, 0.01F, 2, kNone},
    {CX_HORN, "HORN/DRUM", "Баланс рог / барабан %", K::Pct, 0.0F, 1.0F, 0.55F, 0.01F, 0, kNone},
    {CX_AMP_DRIVE, "AMP DRIVE", "Пренатоварване на усилвателя %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {CX_SAMPLE, "RECORD", "Колко от записа на Upper-а се чува покрай колелата %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    SV_SOURCE_KEY,
};
const EngineParamDef kCx3Wheels[] = {
    {CX_TUNING, "TUNING", "Колелата: равномерна темперация или зъбните колела на B-3 (леко разстроен връх)", K::Choice, 0.0F, 1.0F, 1.0F, 1.0F, 0, "EQUAL|GEARS"},
    {CX_FOLDBACK, "FOLDBACK", "Хармониците извън 91-те колела се прегъват октава навътре (както на B-3)", K::Switch, 0.0F, 1.0F, 1.0F, 1.0F, 0, kNone},
    {CX_TAPER, "TAPER", "Високите колела са по-тихи (резисторната мрежа) %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {CX_DRUM_SLOW, "DRUM SLOW", "Бавна скорост на барабана Hz", K::Hz, 0.2F, 1.5F, 0.66F, 0.01F, 2, kNone},
    {CX_DRUM_FAST, "DRUM FAST", "Бърза скорост на барабана Hz", K::Hz, 3.0F, 8.0F, 5.7F, 0.01F, 2, kNone},
    {CX_HORN_ACCEL, "HORN ACCEL", "Рогът набира / губи скорост за s", K::Sec, 0.2F, 5.0F, 1.0F, 0.01F, 2, kNone},
    {CX_DRUM_ACCEL, "DRUM ACCEL", "Барабанът набира / губи скорост за s", K::Sec, 0.5F, 10.0F, 4.0F, 0.01F, 2, kNone},
    {CX_MIC_DIST, "MIC DIST", "Микрофоните по-близо (дълбоко въртене) или по-далече %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};

const EngineParamDef kSgxPage[] = {
    {SG_STRING_RES, "STRING RES", "Симпатичен резонанс на държаните струни %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {SG_DAMPER_RES, "DAMPER RES", "Резонанс при натиснат педал %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {SG_RES_RELEASE, "RES RELEASE", "Колко дълго звучи резонансът s", K::Sec, 0.1F, 5.0F, 1.2F, 0.01F, 2, kNone},
    {SG_SYMP_LIMIT, "RES LIMIT", "Ограничител на енергията на резонанса (не се натрупва) %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {SG_BODY, "BODY", "Резонанс на корпуса (дъска + кутия) %", K::Pct, 0.0F, 1.0F, 0.25F, 0.01F, 0, kNone},
    {SG_BODY_TYPE, "BODY TYPE", "Какво пиано", K::Choice, 0.0F, 2.0F, 0.0F, 1.0F, 0, "GRAND|UPRIGHT|SMALL"},
    {SG_HALF_PEDAL, "HALF PEDAL", "Педалът влияе на затихването постепенно (полупедал), не само ON / OFF", K::Switch, 0.0F, 1.0F, 1.0F, 1.0F, 0, kNone},
    {SG_DAMPER_TIME, "DAMPER TIME", "За колко време дъмперът спира струната s", K::Sec, 0.03F, 1.0F, 0.15F, 0.01F, 2, kNone},
    {SG_UNA_CORDA, "UNA CORDA", "Левият педал (CC67) омекотява %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {SG_HAMMER, "HAMMER", "Механичен шум на чукчето %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {SG_KEYOFF, "KEY-OFF", "Шум при пускане на клавиша %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {SG_KEYOFF_TONE, "KEY-OFF TONE", "Цвят на шума при пускане Hz", K::Hz, 200.0F, 8000.0F, 1500.0F, 1.0F, 0, kNone},
    {SG_LID, "LID", "Капакът: 0 затворен, 100 отворен", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {SG_VEL_BRIGHT, "VEL→BRIGHT", "Силният удар е по-ярък %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {SG_WIDTH, "WIDTH", "Басът отляво, високите отдясно %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
};

const EngineParamDef kEpPage[] = {
    SV_SOURCE_KEY,
    {EP_TYPE, "TYPE", "Tine (Rhodes-тип) или Reed (Wurlitzer-тип)", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "TINE|REED"},
    {EP_MODEL, "TINE GEN", "Собственият модел на езичето (три затихващи тона) %, работи и без запис", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {EP_REC_LEVEL, "RECORD", "Ниво на самия запис %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {EP_TINE_DECAY, "TINE DECAY", "Затихване на модела s", K::Sec, 0.3F, 15.0F, 5.0F, 0.01F, 2, kNone},
    {EP_INHARM, "INHARMONIC", "Нехармоничност на горните тонове на модела %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {EP_HAMMER, "HAMMER", "Твърдост на чукчето (по-ярък удар) %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {EP_PICKUP_DRIVE, "PICKUP", "Нелинейност на пикъпа %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {EP_PICKUP_SYM, "PICKUP SYM", "Асиметрия на пикъпа (четни хармоници) %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {EP_BELL, "BELL", "Камбанката при силен удар %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {EP_BARK, "BARK", "Ръмженето при силен удар %", K::Pct, 0.0F, 1.0F, 0.2F, 0.01F, 0, kNone},
    {EP_PRE_DRIVE, "PREAMP", "Пренатоварване на предусилвателя %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {EP_BASS, "BASS", "Бас на усилвателя dB", K::Db, -12.0F, 12.0F, 0.0F, 0.1F, 1, kNone},
    {EP_TREBLE, "TREBLE", "Високи на усилвателя dB", K::Db, -12.0F, 12.0F, 0.0F, 0.1F, 1, kNone},
    {EP_TREM, "TREMOLO", "Тремоло (Tine: стерео; Reed: вибрато)", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {EP_TREM_SPEED, "TREM SPEED", "Скорост на тремолото Hz", K::Hz, 0.5F, 12.0F, 4.5F, 0.01F, 2, kNone},
    {EP_TREM_DEPTH, "TREM DEPTH", "Дълбочина на тремолото %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {EP_TREM_STEREO, "TREM STEREO", "Стерео ширина на тремолото %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {EP_CAB, "CABINET", "Говорител на усилвателя", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {EP_CAB_DRIVE, "CAB DRIVE", "Пренатоварване на говорителя %", K::Pct, 0.0F, 1.0F, 0.2F, 0.01F, 0, kNone},
    {EP_KEYOFF, "KEY-OFF", "Шум при пускане на клавиша %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
};

template <std::size_t N>
constexpr EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }

} // namespace

const char* engineName(EngineType t) noexcept {
    switch (t) {
        case EngineType::Off: return "OFF";
        case EngineType::HD1: return "HD-1";
        case EngineType::Polysix: return "POLYSIX";
        case EngineType::MS20: return "MS-20";
        case EngineType::AL1: return "AL-1";
        case EngineType::Mod7: return "MOD-7";
        case EngineType::Str1: return "STR-1";
        case EngineType::CX3: return "CX-3";
        case EngineType::SGX: return "SGX";
        case EngineType::EP: return "EP";
        case EngineType::Suse: return "SILVETON SYNTH";
        case EngineType::Synth: return "SILVETON SYNTH";   // SILVETON_SYNTH_V1
    }
    return "OFF";
}

int engineStoredCount(const EngineParams& e) noexcept {
    if (e.type == EngineType::Off) return 0;
    return e.type == EngineType::Suse ? kEngineParamCount : kEngineParamCountLegacy;
}

EngineType engineChoice(int index) noexcept { return index <= 0 ? EngineType::Off : EngineType::Synth; }   // SILVETON_SYNTH_V1: the one engine a screen offers

const char* engineLine(EngineType t) noexcept {
    switch (t) {
        case EngineType::Off: return "Без двигател: звукът е чист запис, както досега.";
        case EngineType::HD1: return "HD-1: два филтъра, обвивки, LFO, drive и boost върху записа; sinc / cubic четене.";
        case EngineType::Polysix: return "POLYSIX: свой saw / pulse осцилатор + записът, PWM, SUB, UNISON, ladder филтър, chorus / phase / ensemble.";
        case EngineType::MS20: return "MS-20: два VCO + записът, HPF и LPF с PEAK (аналогов модел), EG1 / EG2, MG, ESP, S&H и три patch кабела.";
        case EngineType::AL1: return "AL-1: два band-limited осцилатора (sync, ring, FM, PWM) + записът с FM / ring / sync, sub, шум.";
        case EngineType::Mod7: return "MOD-7: шест оператора (записът е първият) с 12 алгоритъма, обвивка на модулаторите, waveshaper.";
        case EngineType::Str1: return "STR-1: записът или собствено дръпване възбужда струна - damping, dispersion, pick / pickup, корпус.";
        case EngineType::CX3: return "CX-3: 91 общи колела (зъбни отношения, foldback), 9 drawbar-а, перкусия, click, скенер, Leslie рог + барабан.";
        case EngineType::SGX: return "SGX: пианото от записите + струни и корпус (резонатори), полупедал, una corda, шумове, капак.";
        case EngineType::EP: return "EP: електрическото пиано от записите + модел на езичето, нелинеен пикъп, bell / bark, тремоло, говорител.";
        case EngineType::Suse: return "SILVETON SYNTH: един двигател, шест генератора с връзки FM / PM / AM / ring, физически модели, адитивен, грануларен, спектрален; всичко се смята, без записи.";
        case EngineType::Synth: return "SILVETON SYNTH: звукът се ПРЕСМЯТА от наученото (хармониците кадър по кадър, атаката, животът, вибратото) - без запис; всяка нота на всеки модел с еднаква сила по ухо";
    }
    return "";
}

// SILVETON_ENGINES_PAGE_V2: every engine has its oscillators on a page of their own (AL-1 OSC, MOD-7 ОПЕРАТОРИ, the others ОСЦ)
const EngineParamDef kHd1Osc[] = {
    {HD_OSC_WAVE, "ВЪЛНА", "Осцилатор на двигателя: само твоите вълни (U1..U16)", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "OFF|" SILVETON_USER_WAVE_NAMES},
    {HD_OSC_LEVEL, "НИВО ВЪЛНА", "Ниво на осцилатора %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {HD_OSC_OCT, "ОКТАВА ВЪЛНА", "Октава на осцилатора", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {HD_OCTAVE, "ОКТАВА ЗВУК", "Октава на целия звук на двигателя (записа и осцилатора)", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
};
const EngineParamDef kSgxOsc[] = {
    {SG_OSC_WAVE, "ВЪЛНА", "Осцилатор на двигателя: само твоите вълни (U1..U16)", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "OFF|" SILVETON_USER_WAVE_NAMES},
    {SG_OSC_LEVEL, "НИВО ВЪЛНА", "Ниво на осцилатора %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {SG_OSC_OCT, "ОКТАВА ВЪЛНА", "Октава на осцилатора", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {SG_OCTAVE, "ОКТАВА ЗВУК", "Октава на целия звук на двигателя (записа и осцилатора)", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
};
const EngineParamDef kEpOsc[] = {
    {EP_OSC_WAVE, "ВЪЛНА", "Осцилатор на двигателя: само твоите вълни (U1..U16)", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "OFF|" SILVETON_USER_WAVE_NAMES},
    {EP_OSC_LEVEL, "НИВО ВЪЛНА", "Ниво на осцилатора %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {EP_OSC_OCT, "ОКТАВА ВЪЛНА", "Октава на осцилатора", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {EP_OCTAVE, "ОКТАВА ЗВУК", "Октава на целия звук на двигателя (записа и осцилатора)", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
};
const EngineParamDef kStr1Osc[] = {
    {ST_OSC_WAVE, "ВЪЛНА", "Осцилатор на двигателя: само твоите вълни (U1..U16)", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "OFF|" SILVETON_USER_WAVE_NAMES},
    {ST_OSC_LEVEL, "НИВО ВЪЛНА", "Ниво на осцилатора %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {ST_OSC_OCT, "ОКТАВА ВЪЛНА", "Октава на осцилатора", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {ST_OCTAVE, "ОКТАВА ЗВУК", "Октава на целия звук на двигателя (записа и осцилатора)", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
};
const EngineParamDef kCx3Osc[] = {
    {CX_OSC_WAVE, "ВЪЛНА", "Осцилатор на двигателя: само твоите вълни (U1..U16)", K::Choice, 0.0F, 16.0F, 0.0F, 1.0F, 0, "OFF|" SILVETON_USER_WAVE_NAMES},
    {CX_OSC_LEVEL, "НИВО ВЪЛНА", "Ниво на осцилатора %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {CX_OSC_OCT, "ОКТАВА ВЪЛНА", "Октава на осцилатора", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {CX_OCTAVE, "ОКТАВА ЗВУК", "Октава на целия звук на двигателя (записа и осцилатора)", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
};
const EngineParamDef kPolysixOsc[] = {
    {P6_OSC, "OSC", "Осцилаторът на Polysix (band-limited) до записа", K::Choice, 0.0F, 20.0F, 0.0F, 1.0F, 0, "OFF|SAW|PULSE|PWM|SAW+PULSE|" SILVETON_USER_WAVE_NAMES},
    {P6_OSC_OCT, "OSC ОКТАВА", "Октава на осцилатора", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {P6_OSC_LEVEL, "OSC LEVEL", "Ниво на осцилатора %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {P6_PWM_WIDTH, "PW", "Ширина на импулса (0 = OFF за записа)", K::Pct, 0.0F, 0.95F, 0.0F, 0.01F, 0, kNone},
    {P6_PWM_DEPTH, "PWM", "Люлеене на ширината %", K::Pct, 0.0F, 0.45F, 0.0F, 0.01F, 0, kNone},
    {P6_PWM_RATE, "PWM SPEED", "Скорост на PWM Hz", K::Hz, 0.02F, 20.0F, 0.5F, 0.01F, 2, kNone},
    {P6_SUB_LEVEL, "SUB", "Суб-осцилатор %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {P6_SUB_OCT, "SUB OCT", "Суб-осцилаторът една или две октави надолу", K::Choice, 1.0F, 2.0F, 1.0F, 1.0F, 0, "-1 OCT|-2 OCT"},
    {P6_SUB_WAVE, "SUB WAVE", "Суб: записът надолу или квадрат", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "RECORD|SQUARE"},
};
const EngineParamDef kMs20Osc[] = {
    {MS_VCO1_WAVE, "VCO 1", "Осцилатор 1 на MS-20", K::Choice, 0.0F, 20.0F, 0.0F, 1.0F, 0, "OFF|TRI|SAW|PULSE|NOISE|" SILVETON_USER_WAVE_NAMES},
    {MS_VCO1_OCT, "VCO1 ОКТАВА", "Октава на VCO 1", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {MS_VCO1_LEVEL, "VCO1 LEVEL", "Ниво на VCO 1 %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {MS_VCO2_WAVE, "VCO 2", "Осцилатор 2 на MS-20", K::Choice, 0.0F, 20.0F, 0.0F, 1.0F, 0, "OFF|SAW|SQUARE|PULSE|RING|" SILVETON_USER_WAVE_NAMES},
    {MS_VCO2_OCT, "VCO2 ОКТАВА", "Октава на VCO 2", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOctNames},
    {MS_VCO2_LEVEL, "VCO2 LEVEL", "Ниво на VCO 2 %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {MS_VCO2_PITCH, "VCO2 PITCH", "VCO 2 спрямо VCO 1 (полутонове)", K::Semis, -24.0F, 24.0F, 0.0F, 1.0F, 0, kNone},
    {MS_PW, "PW", "Ширина на импулса на VCO 1 / 2 %", K::Pct, 0.05F, 0.95F, 0.5F, 0.01F, 0, kNone},
};

int engineOscPage(EngineType t) noexcept {   // SILVETON_ENGINES_PAGE_V2: the page with the oscillators (the one an engine opens on)
    switch (t) {
        case EngineType::HD1: case EngineType::Polysix: case EngineType::SGX: case EngineType::EP: case EngineType::AL1: case EngineType::Mod7: return 3;
        case EngineType::MS20: case EngineType::Str1: case EngineType::CX3: return 4;
        default: return 0;
    }
}

int enginePageCount(EngineType t) noexcept {
    switch (t) {
        case EngineType::Suse: return 0;   // SILVETON SYNTH has screens of its own
        case EngineType::Synth: return synth::kPages;   // SILVETON_SYNTH_V1
        case EngineType::CX3: case EngineType::Str1: case EngineType::MS20: return 5;   // SILVETON_ENGINES_PAGE_V2: ... + ОСЦ
        default: return 4;
    }
}

const char* enginePageName(EngineType t, int page, int instrument) noexcept {
    if (t == EngineType::Synth) return synth::pageName(page);   // SILVETON_SYNTH_V1
    if (page == engineOscPage(t) && t != EngineType::AL1 && t != EngineType::Mod7) return "ОСЦ";   // SILVETON_ENGINES_PAGE_V2
    if (page == 1) return "ФИЛТЪР";
    if (page == 2) return "МОД";
    if (page == 3) {
        switch (t) {
            case EngineType::MS20: return "PATCH";
            case EngineType::AL1: return "ОСЦ";
            case EngineType::Mod7: return "ОПЕРАТОРИ";
            case EngineType::CX3: return "КОЛЕЛА";
            case EngineType::Str1: return instrument >= ST_SAX_ALTO ? "ДЪХ" : "ЛЪК";
            default: return "";
        }
    }
    return "ЗВУК";
}

EngineParamPage enginePage(EngineType t, int page, int instrument) noexcept {
    if (t == EngineType::Suse) return {nullptr, 0};   // SILVETON SYNTH: its knobs are the ids of SuseDefs.h, drawn by its own screens
    if (t == EngineType::Synth) return synth::page(page);   // SILVETON_SYNTH_V1
    if (page == engineOscPage(t) && t != EngineType::AL1 && t != EngineType::Mod7) {   // SILVETON_ENGINES_PAGE_V2
        switch (t) {
            case EngineType::HD1: return pageOf(kHd1Osc);
            case EngineType::Polysix: return pageOf(kPolysixOsc);
            case EngineType::MS20: return pageOf(kMs20Osc);
            case EngineType::Str1: return pageOf(kStr1Osc);
            case EngineType::CX3: return pageOf(kCx3Osc);
            case EngineType::SGX: return pageOf(kSgxOsc);
            case EngineType::EP: return pageOf(kEpOsc);
            default: break;
        }
    }
    if (page == 1) return pageOf(kFilterPage);
    if (page == 2) return t == EngineType::CX3 ? pageOf(kModPageCx3) : pageOf(kModPage);
    if (page == 3) {
        switch (t) {
            case EngineType::MS20: return pageOf(kMs20Patch);
            case EngineType::AL1: return pageOf(kAl1Osc);
            case EngineType::Mod7: return pageOf(kMod7Ops);
            case EngineType::CX3: return pageOf(kCx3Wheels);
            case EngineType::Str1: return instrument >= ST_SAX_ALTO ? pageOf(kStr1Wind) : pageOf(kStr1Bow);
            default: return {nullptr, 0};
        }
    }
    switch (t) {
        case EngineType::HD1: return pageOf(kHd1Page);
        case EngineType::Polysix: return pageOf(kPolysixPage);
        case EngineType::MS20: return pageOf(kMs20Page);
        case EngineType::AL1: return pageOf(kAl1Page);
        case EngineType::Mod7: return pageOf(kMod7Page);
        case EngineType::Str1: return pageOf(kStr1Page);
        case EngineType::CX3: return pageOf(kCx3Page);
        case EngineType::SGX: return pageOf(kSgxPage);
        case EngineType::EP: return pageOf(kEpPage);
        case EngineType::Off: case EngineType::Suse: case EngineType::Synth: break;
    }
    return {nullptr, 0};
}

const EngineParamDef* engineParamDef(EngineType t, int id) noexcept {
    if (t == EngineType::Suse) return nullptr;   // SILVETON_SUSE_V1: see suse::paramInfo
    for (int page = 0; page < kEngineMaxPages; ++page) {
        const EngineParamPage pg = enginePage(t, page);
        for (int i = 0; i < pg.count; ++i) if (pg.items[i].id == id) return &pg.items[i];
    }
    if (t == EngineType::Str1) for (const auto& d : kStr1Wind) if (d.id == id) return &d;   // GROWL is only on the ДЪХ page
    return nullptr;
}

EngineParams engineDefaults(EngineType t) noexcept {
    EngineParams e;
    e.type = t;
    e.p.fill(0.0F);
    if (t == EngineType::Suse) { suse::setDefaults(e.p.data()); return e; }   // SILVETON_SUSE_V1
    if (t == EngineType::Synth) { synth::setDefaults(e.p.data()); return e; }   // SILVETON_SYNTH_V1
    // the common block has sensible values even where an engine does not show a knob
    for (int page = 1; page < 3; ++page) {
        const EngineParamPage pg = enginePage(EngineType::HD1, page);
        for (int i = 0; i < pg.count; ++i) e.p[static_cast<std::size_t>(pg.items[i].id)] = pg.items[i].def;
    }
    for (const int page : {0, 3, 4}) {   // SILVETON_ENGINES_PAGE_V2: 4 = the ОСЦ page of MS-20 / STR-1 / CX-3
        const EngineParamPage own = enginePage(t, page);
        for (int i = 0; i < own.count; ++i) e.p[static_cast<std::size_t>(own.items[i].id)] = own.items[i].def;
    }
    if (t == EngineType::Str1) e.p[ST_GROWL] = 0.0F;
    // a few engines start with their characteristic filter
    switch (t) {
        case EngineType::Polysix: e.p[E_ANALOG] = 0.4F; e.p[E_FILT_TYPE] = 1.0F; e.p[E_CUTOFF] = 6000.0F; e.p[E_RESO] = 0.15F; e.p[E_FEG_AMT] = 1.5F; e.p[E_FEG_D] = 600.0F; e.p[E_FEG_S] = 0.3F; break;
        case EngineType::MS20: e.p[E_ANALOG] = 0.4F; e.p[E_FILT_TYPE] = 2.0F; e.p[E_CUTOFF] = 5000.0F; e.p[E_RESO] = 0.2F; e.p[E_FEG_AMT] = 2.0F; e.p[E_FEG_D] = 400.0F; e.p[E_FEG_S] = 0.2F; break;
        case EngineType::AL1: e.p[E_ANALOG] = 0.4F; e.p[E_FILT_TYPE] = 1.0F; e.p[E_CUTOFF] = 8000.0F; e.p[E_RESO] = 0.1F; e.p[E_FEG_AMT] = 1.0F; e.p[E_FEG_D] = 500.0F; e.p[E_FEG_S] = 0.4F; break;
        case EngineType::Mod7: e.p[E_ANALOG] = 0.4F; e.p[E_FILT_TYPE] = 3.0F; e.p[E_CUTOFF] = 12000.0F; e.p[M7_OP2_LEVEL] = 0.4F; break;
        case EngineType::Str1: e.p[E_FILT_TYPE] = 0.0F; break;
        case EngineType::CX3: e.p[E_FILT_TYPE] = 0.0F; e.p[E_UNISON] = 1.0F; e.p[CX_WHEEL_ROT] = 1.0F; break;
        case EngineType::SGX: e.p[E_FILT_TYPE] = 0.0F; break;
        case EngineType::EP: e.p[E_ANALOG] = 0.3F; e.p[E_FILT_TYPE] = 0.0F; break;
        case EngineType::HD1: e.p[E_FILT_TYPE] = 1.0F; e.p[E_CUTOFF] = 20000.0F; break;
        case EngineType::Off: case EngineType::Suse: case EngineType::Synth: break;
    }
    return e;
}

void engineFillV2Defaults(EngineParams& e) noexcept {
    if (e.type == EngineType::Suse || e.type == EngineType::Synth) return;   // SILVETON_SUSE_V1 / SILVETON_SYNTH_V1: a whole row
    const EngineParams d = engineDefaults(e.type);
    for (int k = kEngineParamCountV1; k < kEngineParamCountLegacy; ++k) e.p[static_cast<std::size_t>(k)] = d.p[static_cast<std::size_t>(k)];
    // the ids 36..47 of an engine's own range that V1 did not use were written as 0 by a V1 program: those take their defaults too
    for (int k = E_X0; k < kEngineParamCountV1; ++k) {
        const EngineParamDef* def = engineParamDef(e.type, k);
        if (def == nullptr) continue;
        // a V1 id of this engine keeps its stored value; the test is whether V1 showed the id (see the V1 tables: every V1 id is below the V2 ones)
        const bool v2Only =
            (e.type == EngineType::Polysix && k >= P6_OSC) || (e.type == EngineType::MS20 && k >= MS_P1_SRC) ||
            (e.type == EngineType::AL1 && k >= AL_OSC1_WAVE) || (e.type == EngineType::Mod7 && k >= M7_OP4_RATIO) ||
            (e.type == EngineType::Str1 && k >= ST_BODY) || (e.type == EngineType::SGX && k >= SG_BODY) ||
            (e.type == EngineType::EP && k >= EP_MODEL) || (e.type == EngineType::HD1 && k >= HD_INTERP);
        if (v2Only) e.p[static_cast<std::size_t>(k)] = d.p[static_cast<std::size_t>(k)];
    }
}

bool engineMakesOwnSound(const EngineParams& e) noexcept {
    const float* p = e.p.data();
    if (e.type == EngineType::Suse) return true;   // everything it sounds is calculated, it never needs a recording
    if (e.type == EngineType::Synth) return true;    // SILVETON_SYNTH_V1: everything it sounds is calculated from the learned model
    if (!engineOwnOn(e)) return false;   // SILVETON_ENGINES_V3: ЗВУК ОТ = СЕМПЪЛ - only the recording
    switch (e.type) {
        case EngineType::CX3: return true;
        // SILVETON_STR1_FIX_V1: every instrument sounds by itself - the plucked ones get a pluck of their own when no recording plays
        case EngineType::Str1: return true;
        case EngineType::AL1: return (p[AL_OSC1_WAVE] >= 0.5F && p[AL_OSC1_LEVEL] > 0.0F) || (p[AL_OSC2_WAVE] >= 0.5F && p[AL_OSC2_LEVEL] > 0.0F) || p[AL_NOISE_LEVEL] > 0.0F;
        case EngineType::Polysix: return p[P6_OSC] >= 0.5F && p[P6_OSC_LEVEL] > 0.0F;
        case EngineType::MS20: return (p[MS_VCO1_WAVE] >= 0.5F && p[MS_VCO1_LEVEL] > 0.0F) || (p[MS_VCO2_WAVE] >= 0.5F && p[MS_VCO2_LEVEL] > 0.0F);
        case EngineType::Mod7: {
            // which algorithms have a sine operator that is heard on its own (the same table as the sound: EngineDsp.h algoOf)
            static const bool sineCarrier[12] = {false, false, false, true, true, true, true, false, true, true, true, false};
            const int a = std::clamp(static_cast<int>(std::lround(p[M7_ALGO])), 0, 11);
            // SILVETON_ENGINES_V3: with no recording operator 1 is a sine of its own (every algorithm has it as a carrier)
            return (sineCarrier[a] && p[M7_OP_LEVEL] > 0.0F) || p[M7_PCM_LEVEL] > 0.0F;
        }
        case EngineType::EP: return p[EP_MODEL] > 0.0F || engineWaveOn(e);
        default: return engineWaveOn(e);   // SILVETON_ENGINE_WAVE_V1: HD-1 / SGX with a ВЪЛНА
    }
}

float engineClamp(EngineType t, int id, float v) noexcept {
    if (!std::isfinite(v)) return 0.0F;
    if (id == E_BYPASS) return v >= 0.5F ? 1.0F : 0.0F;
    if (t == EngineType::Suse) return suse::clampParam(id, v);   // SILVETON_SUSE_V1
    const EngineParamDef* d = engineParamDef(t, id);
    if (d == nullptr) {
        // an id this engine does not show: keep it inside the widest common range
        return std::clamp(v, -20000.0F, 20000.0F);
    }
    float x = std::clamp(v, d->lo, d->hi);
    if (d->kind == EngineKind::Choice || d->kind == EngineKind::Switch || d->kind == EngineKind::Drawbar || d->kind == EngineKind::Bend ||
        (d->kind == EngineKind::Lin && d->step >= 1.0F)) x = std::round(x);
    if (engineIsRatio(t, id)) x = engineMusicalRatio(x, d->hi);   // SILVETON_MUSICAL_V1
    return x;
}

// ---------------------------------------------------------------- SILVETON_ENGINES_V3
// SILVETON_BODY_V1 (engine block V4): a set saved before has ANALOG 0 on the synth engines - they get the new, living value once
void engineFillV4Defaults(EngineParams& e) noexcept {
    if (e.type == EngineType::Suse || e.type == EngineType::Synth) return;
    if (e.p[E_ANALOG] == 0.0F) e.p[E_ANALOG] = engineDefaults(e.type).p[E_ANALOG];
}

// SILVETON_STR1_REAL_V1 (engine block V5): a GUITAR / HARP of STR-1 that still holds the old starting decay gets the new, longer one
// (a value the player changed is left alone)
void engineFillV5Defaults(EngineParams& e) noexcept {
    if (e.type != EngineType::Str1) return;
    const int inst = static_cast<int>(std::lround(e.p[ST_BODY_TYPE]));
    if (inst == ST_GUITAR && e.p[ST_DECAY] == 2.5F && e.p[ST_KEY_DECAY] == 0.5F) { e.p[ST_DECAY] = 4.0F; e.p[ST_KEY_DECAY] = 0.35F; }
    if (inst == ST_HARP && e.p[ST_DECAY] == 4.0F && e.p[ST_KEY_DECAY] == 0.6F) { e.p[ST_DECAY] = 6.0F; e.p[ST_KEY_DECAY] = 0.35F; }
}

void engineFillV3Defaults(EngineParams& e) noexcept {
    if (e.type == EngineType::Suse || e.type == EngineType::Synth) return;
    const EngineParams d = engineDefaults(e.type);
    // STR-1: the STYLE and the bow (ids 40..51) were not used before V3 - a V1 / V2 set holds 0 there
    if (e.type == EngineType::Str1)
        for (int k = ST_STYLE; k <= ST_GROWL; ++k) e.p[static_cast<std::size_t>(k)] = d.p[static_cast<std::size_t>(k)];
    // E_SOURCE: 0 = ДВЕТЕ, exactly what V2 did - nothing to do
}

const char* str1StyleNames(int instrument) noexcept {
    switch (instrument) {
        case ST_VIOLIN: case ST_CELLO: return "ARCO|PIZZ|TREMOLO|SPICCATO";
        case ST_HARP: return "NORMAL|HARMONIC|MUTED|PRES TABLE";
        case ST_TRUMPET: return "NORMAL|MUTE|GROWL|STACCATO";
        case ST_KAVAL: return "NORMAL|BREATHY|GROWL|STACCATO";
        case ST_SAX_ALTO: case ST_SAX_TENOR: case ST_CLARINET: case ST_GAIDA: return "NORMAL|SOFT|GROWL|STACCATO";
        default: return "PICK|FINGER|MUTE|HARMONIC";
    }
}

bool str1Wind(const EngineParams& e) noexcept {
    return e.type == EngineType::Str1 && static_cast<int>(std::lround(e.p[ST_BODY_TYPE])) >= ST_SAX_ALTO;
}

bool str1Bowed(const EngineParams& e) noexcept {
    if (e.type != EngineType::Str1) return false;
    const int inst = static_cast<int>(std::lround(e.p[ST_BODY_TYPE]));
    const int style = static_cast<int>(std::lround(e.p[ST_STYLE]));
    return (inst == ST_VIOLIN || inst == ST_CELLO) && style != 1;
}

void str1InstrumentDefaults(EngineParams& e, int instrument) noexcept {
    if (e.type != EngineType::Str1) return;
    auto& p = e.p;
    const int inst = std::clamp(instrument, 0, kStr1Instruments - 1);
    p[ST_BODY_TYPE] = static_cast<float>(inst);
    p[ST_STYLE] = 0.0F;
    switch (inst) {
        case ST_VIOLIN:
            p[ST_BODY] = 0.9F; p[ST_DECAY] = 1.2F; p[ST_DAMP] = 0.35F; p[ST_DISP] = 0.05F; p[ST_PICK] = 0.25F; p[ST_PICKUP] = 0.02F; p[ST_PLUCK_COLOR] = 2500.0F;
            p[ST_BOW_POS] = 0.11F; p[ST_VIBRATO] = 18.0F; p[ST_VIB_RATE] = 5.6F; p[ST_KEY_DECAY] = 0.5F;
            break;
        case ST_CELLO:
            p[ST_BODY] = 0.9F; p[ST_DECAY] = 2.0F; p[ST_DAMP] = 0.3F; p[ST_DISP] = 0.05F; p[ST_PICK] = 0.25F; p[ST_PICKUP] = 0.02F; p[ST_PLUCK_COLOR] = 1800.0F;
            p[ST_BOW_POS] = 0.12F; p[ST_VIBRATO] = 15.0F; p[ST_VIB_RATE] = 5.0F; p[ST_KEY_DECAY] = 0.5F;
            break;
        case ST_HARP:
            p[ST_BODY] = 0.6F; p[ST_DECAY] = 6.0F; p[ST_DAMP] = 0.2F; p[ST_DISP] = 0.03F; p[ST_PICK] = 0.45F; p[ST_PICKUP] = 0.02F; p[ST_PLUCK_COLOR] = 2500.0F;
            p[ST_KEY_DECAY] = 0.35F;   // SILVETON_STR1_REAL_V1: 6 s, 0.35 (before 4 s, 0.6)
            break;
        case ST_SAX_ALTO: case ST_SAX_TENOR: case ST_CLARINET: case ST_TRUMPET: case ST_KAVAL: case ST_GAIDA: {
            // the winds: breath, embouchure, air, vibrato (DAMPING = the losses of the bell)
            static const float air[6] = {0.15F, 0.18F, 0.10F, 0.08F, 0.35F, 0.05F};
            static const float vib[6] = {14.0F, 16.0F, 0.0F, 8.0F, 18.0F, 0.0F};
            static const float vibHz[6] = {5.2F, 5.0F, 5.0F, 5.5F, 5.0F, 5.0F};
            const auto k = static_cast<std::size_t>(inst - ST_SAX_ALTO);
            static const float emb[6] = {0.5F, 0.5F, 0.5F, 0.9F, 0.1F, 0.8F};
            static const float damp[6] = {0.3F, 0.3F, 0.3F, 0.15F, 0.6F, 0.2F};
            p[ST_BODY] = 0.6F; p[ST_DAMP] = damp[k]; p[ST_PLUCK] = 0.0F;
            p[ST_BOW_SPEED] = 0.6F; p[ST_BOW_PRESS] = emb[k]; p[ST_BOW_ATTACK] = inst == ST_KAVAL ? 60.0F : 40.0F; p[ST_BOW_RELEASE] = 80.0F;
            p[ST_VEL_BOW] = inst == ST_GAIDA ? 0.0F : 0.7F; p[ST_BOW_NOISE] = air[k]; p[ST_GROWL] = 0.0F;
            p[ST_VIBRATO] = vib[k]; p[ST_VIB_RATE] = vibHz[k]; p[ST_VIB_DELAY] = 250.0F;
            break;
        }
        default:   // GUITAR: the starting values of STR-1
            p[ST_BODY] = 0.3F; p[ST_DECAY] = 4.0F; p[ST_DAMP] = 0.3F; p[ST_DISP] = 0.1F; p[ST_PICK] = 0.13F; p[ST_PICKUP] = 0.2F; p[ST_PLUCK_COLOR] = 4000.0F;
            p[ST_KEY_DECAY] = 0.35F;   // SILVETON_STR1_REAL_V1: 4 s, 0.35 (before 2.5 s, 0.5)
            break;
    }
}

} // namespace silveton::sampler
