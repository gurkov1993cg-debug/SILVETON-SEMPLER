// SILVETON_ENGINES_V1 - the parameter tables of the nine engines (see EngineDefs.h).
#include "silveton/sampler/EngineDefs.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler {
namespace {

using K = EngineKind;
constexpr const char* kNone = "";

// ---------------------------------------------------------------- the common pages
const EngineParamDef kFilterPage[] = {
    {E_FILT_TYPE, "FILTER", "Видът на главния филтър", K::Choice, 0.0F, 5.0F, 1.0F, 1.0F, 0, "OFF|LP24|KORG35|LP12|HP12|BP12"},
    {E_CUTOFF, "CUTOFF", "Честота на среза Hz", K::Hz, 20.0F, 20000.0F, 20000.0F, 1.0F, 0, kNone},
    {E_RESO, "RESON", "Резонанс %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_KEYTRACK, "KEY TRACK", "Срезът следва клавиша %", K::Pct, -1.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_FEG_AMT, "F.EG AMT", "Обвивка към среза (октави)", K::Oct, -8.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_FEG_A, "F.ATTACK", "Атака на филтъра ms", K::Ms, 1.0F, 10000.0F, 5.0F, 1.0F, 0, kNone},
    {E_FEG_D, "F.DECAY", "Decay на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_FEG_S, "F.SUSTAIN", "Sustain на филтъра %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_FEG_R, "F.RELEASE", "Release на филтъра ms", K::Ms, 1.0F, 20000.0F, 200.0F, 1.0F, 0, kNone},
    {E_VEL_CUT, "VEL→CUT", "Силата отваря среза (октави)", K::Oct, 0.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_DRIVE, "DRIVE", "Насищане преди филтъра %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_F2_TYPE, "FILTER 2", "Втори филтър", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "OFF|LP|HP|BP|BR"},
    {E_F2_CUT, "CUTOFF 2", "Срез на втория филтър Hz", K::Hz, 20.0F, 20000.0F, 1000.0F, 1.0F, 0, kNone},
    {E_F2_RES, "RESON 2", "Резонанс на втория %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_F2_PAR, "ROUTING", "Вторият филтър е след първия или до него", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "SERIES|PARALLEL"},
};

const EngineParamDef kModPage[] = {
    {E_LFO_RATE, "LFO RATE", "Скорост на LFO Hz", K::Hz, 0.05F, 30.0F, 5.0F, 0.01F, 2, kNone},
    {E_LFO_WAVE, "LFO WAVE", "Форма на LFO", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "SINE|TRI|SAW|SQUARE|S&H"},
    {E_LFO_PITCH, "LFO→PITCH", "LFO към височината (cents)", K::Cents, 0.0F, 1200.0F, 0.0F, 1.0F, 0, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "LFO към среза (октави)", K::Oct, -4.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {E_LFO_AMP, "LFO→AMP", "LFO към силата %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_UNISON, "UNISON", "Копия на всяка нота", K::Lin, 1.0F, 4.0F, 1.0F, 1.0F, 0, kNone},
    {E_UNI_DET, "DETUNE", "Разстройка на копията (cents)", K::Cents, 0.0F, 100.0F, 8.0F, 1.0F, 0, kNone},
    {E_UNI_SPREAD, "SPREAD", "Стерео ширина на копията %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {E_ANALOG, "ANALOG", "Малки случайни разлики на всяка нота %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};
// the МОД page of CX-3 has one more key
const EngineParamDef kModPageCx3[] = {
    {E_LFO_RATE, "LFO RATE", "Скорост на LFO Hz", K::Hz, 0.05F, 30.0F, 5.0F, 0.01F, 2, kNone},
    {E_LFO_WAVE, "LFO WAVE", "Форма на LFO", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "SINE|TRI|SAW|SQUARE|S&H"},
    {E_LFO_PITCH, "LFO→PITCH", "LFO към височината (cents)", K::Cents, 0.0F, 1200.0F, 0.0F, 1.0F, 0, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "LFO към среза (октави)", K::Oct, -4.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {E_LFO_AMP, "LFO→AMP", "LFO към силата %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_ANALOG, "ANALOG", "Малки случайни разлики на всяка нота %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {CX_WHEEL_ROT, "WHEEL→LESLIE", "Лостчето за модулация превключва бавно / бързо", K::Switch, 0.0F, 1.0F, 1.0F, 1.0F, 0, kNone},
};

// ---------------------------------------------------------------- the ЗВУК pages
const EngineParamDef kHd1Page[] = {
    {HD_BOOST, "LOW BOOST", "Повдигане на баса dB", K::Db, 0.0F, 12.0F, 0.0F, 0.1F, 1, kNone},
    {HD_PEG_CENTS, "PITCH EG", "Обвивка на височината (cents, от началото към тона)", K::Cents, -1200.0F, 1200.0F, 0.0F, 1.0F, 0, kNone},
    {HD_PEG_TIME, "PEG TIME", "Време на обвивката на височината ms", K::Ms, 1.0F, 5000.0F, 80.0F, 1.0F, 0, kNone},
};

const EngineParamDef kPolysixPage[] = {
    {P6_PWM_WIDTH, "PW", "Ширина на импулса (0 = OFF)", K::Pct, 0.0F, 0.95F, 0.0F, 0.01F, 0, kNone},
    {P6_PWM_DEPTH, "PWM", "Люлеене на ширината %", K::Pct, 0.0F, 0.45F, 0.0F, 0.01F, 0, kNone},
    {P6_PWM_RATE, "PWM SPEED", "Скорост на PWM Hz", K::Hz, 0.02F, 20.0F, 0.5F, 0.01F, 2, kNone},
    {P6_SUB_LEVEL, "SUB", "Суб-осцилатор %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {P6_SUB_OCT, "SUB OCT", "Суб-осцилаторът една или две октави надолу", K::Choice, 1.0F, 2.0F, 1.0F, 1.0F, 0, "-1 OCT|-2 OCT"},
    {P6_FX_TYPE, "EFFECT", "Вграденият ефект на Polysix", K::Choice, 0.0F, 3.0F, 3.0F, 1.0F, 0, "OFF|CHORUS|PHASE|ENSEMBLE"},
    {P6_FX_SPEED, "FX SPEED", "Скорост на ефекта Hz", K::Hz, 0.1F, 5.0F, 0.6F, 0.01F, 2, kNone},
    {P6_FX_DEPTH, "FX DEPTH", "Дълбочина на ефекта %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {P6_FX_MIX, "FX MIX", "Смес на ефекта %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};

const EngineParamDef kMs20Page[] = {
    {MS_HPF_CUT, "HPF CUTOFF", "Високопропускащ филтър Hz", K::Hz, 20.0F, 20000.0F, 20.0F, 1.0F, 0, kNone},
    {MS_HPF_PEAK, "HPF PEAK", "Резонанс (PEAK) на HPF %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {MS_EG1_DELAY, "EG1 DELAY", "EG1: закъснение ms", K::Ms, 0.0F, 5000.0F, 0.0F, 1.0F, 0, kNone},
    {MS_EG1_ATTACK, "EG1 ATTACK", "EG1: атака ms", K::Ms, 1.0F, 10000.0F, 50.0F, 1.0F, 0, kNone},
    {MS_EG1_RELEASE, "EG1 RELEASE", "EG1: отпускане ms", K::Ms, 1.0F, 10000.0F, 200.0F, 1.0F, 0, kNone},
    {MS_EG1_PITCH, "EG1→PITCH", "EG1 към височината (полутонове)", K::Semis, -24.0F, 24.0F, 0.0F, 0.1F, 1, kNone},
    {MS_EG1_HPF, "EG1→HPF", "EG1 към HPF (октави)", K::Oct, -8.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {MS_MG_HPF, "MG→HPF", "LFO (MG) към HPF (октави)", K::Oct, -4.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {MS_WHEEL_TO, "WHEEL→", "Лостчето за модулация отива към", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "OFF|PITCH|LPF|HPF|AMP"},
    {MS_WHEEL_AMT, "WHEEL AMT", "Колко лостчето действа %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};

const EngineParamDef kAl1Page[] = {
    {AL_FM_AMT, "FM", "Честотна модулация на записа %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {AL_FM_RATIO, "FM RATIO", "Отношение на модулатора към тона", K::Lin, 0.25F, 8.0F, 1.0F, 0.01F, 2, kNone},
    {AL_FM_EG, "FM←EG", "Обвивката на филтъра води FM %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_RING_LEVEL, "RING", "Ring модулация %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_RING_RATIO, "RING RATIO", "Отношение на ring модулатора", K::Lin, 0.25F, 8.0F, 1.5F, 0.01F, 2, kNone},
    {AL_SYNC, "SYNC", "Твърда синхронизация (записът се рестартира на всеки период)", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {AL_SYNC_RATIO, "SYNC RATIO", "Колко по-високо свири синхронизираният запис", K::Lin, 1.0F, 4.0F, 1.5F, 0.01F, 2, kNone},
    {AL_SUB_LEVEL, "SUB", "Суб-осцилатор %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_SUB_OCT, "SUB OCT", "Суб-осцилаторът една или две октави надолу", K::Choice, 1.0F, 2.0F, 1.0F, 1.0F, 0, "-1 OCT|-2 OCT"},
    {AL_NOISE_LEVEL, "NOISE", "Шум %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {AL_NOISE_COLOR, "NOISE COLOR", "Цвят на шума (срез Hz)", K::Hz, 100.0F, 20000.0F, 8000.0F, 1.0F, 0, kNone},
    {AL_SHAPE, "SHAPE", "Прегъване на вълната %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};

const EngineParamDef kMod7Page[] = {
    {M7_OP2_RATIO, "OP2 RATIO", "Отношение на оператор 2", K::Lin, 0.25F, 16.0F, 1.0F, 0.01F, 2, kNone},
    {M7_OP2_LEVEL, "OP2 LEVEL", "Дълбочина на FM от оператор 2 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP3_RATIO, "OP3 RATIO", "Отношение на оператор 3", K::Lin, 0.25F, 16.0F, 2.0F, 0.01F, 2, kNone},
    {M7_OP3_LEVEL, "OP3 LEVEL", "Дълбочина на FM от оператор 3 %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {M7_OP3_TARGET, "OP3→", "Оператор 3 модулира оператор 2 или направо записа", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "OP2|RECORD"},
    {M7_FEEDBACK, "FEEDBACK", "Обратна връзка на оператор 2 %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_FM_EG, "FM←EG", "Обвивката на филтъра води FM %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_FM_VEL, "FM←VEL", "Силата на натиска води FM %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_RING, "RING", "Оператор 2 като ring модулатор %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {M7_WS_TYPE, "SHAPER", "Waveshaper", K::Choice, 0.0F, 4.0F, 0.0F, 1.0F, 0, "OFF|SOFT|HARD|FOLD|SINE"},
    {M7_WS_DRIVE, "WS DRIVE", "Колко силно се оформя %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {M7_WS_MIX, "WS MIX", "Смес на оформеното %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {M7_BRIGHT, "BRIGHTNESS", "Макро: всички модулатори по-силни / по-слаби", K::Pct, -1.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};

const EngineParamDef kStr1Page[] = {
    {ST_STRING, "STRING", "Ниво на струната %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {ST_EXCITE, "EXCITE", "Ниво на самия запис (възбудителя) %", K::Pct, 0.0F, 1.0F, 0.2F, 0.01F, 0, kNone},
    {ST_EXC_LEN, "EXC LENGTH", "Колко дълго записът храни струната ms (0 = през цялото време)", K::Ms, 0.0F, 2000.0F, 40.0F, 1.0F, 0, kNone},
    {ST_DECAY, "DECAY", "Затихване на струната s", K::Sec, 0.05F, 20.0F, 2.5F, 0.01F, 2, kNone},
    {ST_DAMP, "DAMPING", "Загуба на високите в струната %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {ST_DISP, "DISPERSION", "Нехармоничност (пиано-струна) %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {ST_PICK, "PICK POS", "Къде се дърпа струната %", K::Pct, 0.02F, 0.5F, 0.13F, 0.01F, 0, kNone},
    {ST_PICKUP, "PICKUP POS", "Къде е пикъпът %", K::Pct, 0.02F, 0.5F, 0.2F, 0.01F, 0, kNone},
    {ST_FEEDBACK, "FEEDBACK", "Обратна връзка към струната (като пред усилвател) %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {ST_NONLIN, "NONLINEAR", "Нелинейност на струната %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {ST_TUNE, "STRING TUNE", "Настройка на струната (cents)", K::Cents, -100.0F, 100.0F, 0.0F, 1.0F, 0, kNone},
    {ST_KEY_DECAY, "KEY→DECAY", "Високите тонове затихват по-бързо %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
};

const EngineParamDef kCx3Page[] = {
    {CX_DB16, "16'", "Drawbar 16'", K::Drawbar, 0.0F, 8.0F, 8.0F, 1.0F, 0, kNone},
    {CX_DB513, "5⅓'", "Drawbar 5 1/3'", K::Drawbar, 0.0F, 8.0F, 8.0F, 1.0F, 0, kNone},
    {CX_DB8, "8'", "Drawbar 8'", K::Drawbar, 0.0F, 8.0F, 8.0F, 1.0F, 0, kNone},
    {CX_DB4, "4'", "Drawbar 4'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB223, "2⅔'", "Drawbar 2 2/3'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB2, "2'", "Drawbar 2'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB135, "1⅗'", "Drawbar 1 3/5'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB113, "1⅓'", "Drawbar 1 1/3'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_DB1, "1'", "Drawbar 1'", K::Drawbar, 0.0F, 8.0F, 0.0F, 1.0F, 0, kNone},
    {CX_PERC, "PERC", "Перкусия на 2-ри или 3-ти хармоник", K::Choice, 0.0F, 2.0F, 0.0F, 1.0F, 0, "OFF|2ND|3RD"},
    {CX_PERC_DECAY, "PERC DECAY", "Затихване на перкусията", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "FAST|SLOW"},
    {CX_PERC_LEVEL, "PERC LEVEL", "Сила на перкусията", K::Choice, 0.0F, 1.0F, 1.0F, 1.0F, 0, "SOFT|NORMAL"},
    {CX_CLICK, "KEY CLICK", "Щракане на клавиша %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {CX_LEAK, "LEAKAGE", "Изтичане между колелата %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {CX_VIBCHO, "VIB/CHO", "Вибрато / хорус скенер", K::Choice, 0.0F, 6.0F, 0.0F, 1.0F, 0, "OFF|V1|C1|V2|C2|V3|C3"},
    {CX_ROTARY, "LESLIE", "Въртящ се говорител", K::Choice, 0.0F, 2.0F, 1.0F, 1.0F, 0, "OFF|SLOW|FAST"},
    {CX_SLOW, "SLOW", "Бавна скорост Hz", K::Hz, 0.3F, 1.5F, 0.75F, 0.01F, 2, kNone},
    {CX_FAST, "FAST", "Бърза скорост Hz", K::Hz, 4.0F, 9.0F, 6.8F, 0.01F, 2, kNone},
    {CX_HORN, "HORN/ROTOR", "Баланс рог / ротор %", K::Pct, 0.0F, 1.0F, 0.55F, 0.01F, 0, kNone},
    {CX_AMP_DRIVE, "AMP DRIVE", "Пренатоварване на усилвателя %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {CX_SAMPLE, "RECORD", "Колко от записа на Upper-а се чува покрай колелата %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};

const EngineParamDef kSgxPage[] = {
    {SG_STRING_RES, "STRING RES", "Симпатичен резонанс на държаните струни %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {SG_DAMPER_RES, "DAMPER RES", "Резонанс при натиснат педал %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {SG_RES_RELEASE, "RES RELEASE", "Колко дълго звучи резонансът s", K::Sec, 0.1F, 5.0F, 1.2F, 0.01F, 2, kNone},
    {SG_UNA_CORDA, "UNA CORDA", "Левият педал (CC67) омекотява %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {SG_HAMMER, "HAMMER", "Механичен шум на чукчето %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {SG_KEYOFF, "KEY-OFF", "Шум при пускане на клавиша %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {SG_KEYOFF_TONE, "KEY-OFF TONE", "Цвят на шума при пускане Hz", K::Hz, 200.0F, 8000.0F, 1500.0F, 1.0F, 0, kNone},
    {SG_LID, "LID", "Капакът: 0 затворен, 100 отворен", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {SG_VEL_BRIGHT, "VEL→BRIGHT", "Силният удар е по-ярък %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {SG_WIDTH, "WIDTH", "Басът отляво, високите отдясно %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
};

const EngineParamDef kEpPage[] = {
    {EP_TYPE, "TYPE", "Tine (Rhodes-тип) или Reed (Wurlitzer-тип)", K::Choice, 0.0F, 1.0F, 0.0F, 1.0F, 0, "TINE|REED"},
    {EP_BELL, "BELL", "Камбанката при силен удар %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {EP_BARK, "BARK", "Ръмженето при силен удар %", K::Pct, 0.0F, 1.0F, 0.2F, 0.01F, 0, kNone},
    {EP_PRE_DRIVE, "PREAMP", "Пренатоварване на предусилвателя %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {EP_BASS, "BASS", "Бас на усилвателя dB", K::Db, -12.0F, 12.0F, 0.0F, 0.1F, 1, kNone},
    {EP_TREBLE, "TREBLE", "Високи на усилвателя dB", K::Db, -12.0F, 12.0F, 0.0F, 0.1F, 1, kNone},
    {EP_TREM, "TREMOLO", "Тремоло (Tine: стерео; Reed: вибрато)", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {EP_TREM_SPEED, "TREM SPEED", "Скорост на тремолото Hz", K::Hz, 0.5F, 12.0F, 4.5F, 0.01F, 2, kNone},
    {EP_TREM_DEPTH, "TREM DEPTH", "Дълбочина на тремолото %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
    {EP_TREM_STEREO, "TREM STEREO", "Стерео ширина на тремолото %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {EP_CAB, "CABINET", "Говорител на усилвателя", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {EP_CAB_DRIVE, "CAB DRIVE", "Пренатоварване на говорителя %", K::Pct, 0.0F, 1.0F, 0.2F, 0.01F, 0, kNone},
    {EP_KEYOFF, "KEY-OFF", "Шум при пускане на клавиша %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
};

template <std::size_t N>
constexpr EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }

} // namespace

const char* engineName(EngineType t) noexcept {
    switch (t) {
        case EngineType::Off: return "OFF";
        case EngineType::HD1: return "HD-1";
        case EngineType::Polysix: return "POLYSIX";
        case EngineType::MS20: return "MS-20";
        case EngineType::AL1: return "AL-1";
        case EngineType::Mod7: return "MOD-7";
        case EngineType::Str1: return "STR-1";
        case EngineType::CX3: return "CX-3";
        case EngineType::SGX: return "SGX";
        case EngineType::EP: return "EP";
    }
    return "OFF";
}

const char* engineLine(EngineType t) noexcept {
    switch (t) {
        case EngineType::Off: return "Без двигател: звукът е чист запис, както досега.";
        case EngineType::HD1: return "HD-1: два филтъра, обвивки, LFO, drive и boost върху записа.";
        case EngineType::Polysix: return "POLYSIX: PWM, SUB, UNISON, 4-полюсен филтър и chorus / phase / ensemble.";
        case EngineType::MS20: return "MS-20: HPF + LPF с PEAK (самоосцилират), EG1 / EG2, MG и лостчето като patch-кабел.";
        case EngineType::AL1: return "AL-1: FM, ring, sync, sub, шум и 4-полюсен аналогов филтър върху записа.";
        case EngineType::Mod7: return "MOD-7: записът е носител на FM с два оператора, waveshaper и филтър.";
        case EngineType::Str1: return "STR-1: записът възбужда струнен модел - damping, dispersion, pick / pickup, feedback.";
        case EngineType::CX3: return "CX-3: 9 drawbar-а, перкусия, click, leakage, vibrato / chorus и Leslie. Записът може да се добави.";
        case EngineType::SGX: return "SGX: пианото от записите + резонанс на струните, педал, una corda, шумове, капак.";
        case EngineType::EP: return "EP: електрическото пиано от записите + bell / bark, предусилвател, тремоло, говорител.";
    }
    return "";
}

EngineParamPage enginePage(EngineType t, int page) noexcept {
    if (page == 1) return pageOf(kFilterPage);
    if (page == 2) return t == EngineType::CX3 ? pageOf(kModPageCx3) : pageOf(kModPage);
    switch (t) {
        case EngineType::HD1: return pageOf(kHd1Page);
        case EngineType::Polysix: return pageOf(kPolysixPage);
        case EngineType::MS20: return pageOf(kMs20Page);
        case EngineType::AL1: return pageOf(kAl1Page);
        case EngineType::Mod7: return pageOf(kMod7Page);
        case EngineType::Str1: return pageOf(kStr1Page);
        case EngineType::CX3: return pageOf(kCx3Page);
        case EngineType::SGX: return pageOf(kSgxPage);
        case EngineType::EP: return pageOf(kEpPage);
        case EngineType::Off: break;
    }
    return {nullptr, 0};
}

const EngineParamDef* engineParamDef(EngineType t, int id) noexcept {
    for (int page = 0; page < 3; ++page) {
        const EngineParamPage pg = enginePage(t, page);
        for (int i = 0; i < pg.count; ++i) if (pg.items[i].id == id) return &pg.items[i];
    }
    return nullptr;
}

EngineParams engineDefaults(EngineType t) noexcept {
    EngineParams e;
    e.type = t;
    e.p.fill(0.0F);
    // the common block has sensible values even where an engine does not show a knob
    for (int page = 1; page < 3; ++page) {
        const EngineParamPage pg = enginePage(EngineType::HD1, page);
        for (int i = 0; i < pg.count; ++i) e.p[static_cast<std::size_t>(pg.items[i].id)] = pg.items[i].def;
    }
    const EngineParamPage own = enginePage(t, 0);
    for (int i = 0; i < own.count; ++i) e.p[static_cast<std::size_t>(own.items[i].id)] = own.items[i].def;
    // a few engines start with their characteristic filter
    switch (t) {
        case EngineType::Polysix: e.p[E_FILT_TYPE] = 1.0F; e.p[E_CUTOFF] = 6000.0F; e.p[E_RESO] = 0.15F; e.p[E_FEG_AMT] = 1.5F; e.p[E_FEG_D] = 600.0F; e.p[E_FEG_S] = 0.3F; break;
        case EngineType::MS20: e.p[E_FILT_TYPE] = 2.0F; e.p[E_CUTOFF] = 5000.0F; e.p[E_RESO] = 0.2F; e.p[E_FEG_AMT] = 2.0F; e.p[E_FEG_D] = 400.0F; e.p[E_FEG_S] = 0.2F; break;
        case EngineType::AL1: e.p[E_FILT_TYPE] = 1.0F; e.p[E_CUTOFF] = 8000.0F; e.p[E_RESO] = 0.1F; e.p[E_FEG_AMT] = 1.0F; e.p[E_FEG_D] = 500.0F; e.p[E_FEG_S] = 0.4F; break;
        case EngineType::Mod7: e.p[E_FILT_TYPE] = 3.0F; e.p[E_CUTOFF] = 12000.0F; e.p[M7_OP2_LEVEL] = 0.4F; break;
        case EngineType::Str1: e.p[E_FILT_TYPE] = 0.0F; break;
        case EngineType::CX3: e.p[E_FILT_TYPE] = 0.0F; e.p[E_UNISON] = 1.0F; e.p[CX_WHEEL_ROT] = 1.0F; break;
        case EngineType::SGX: e.p[E_FILT_TYPE] = 0.0F; break;
        case EngineType::EP: e.p[E_FILT_TYPE] = 0.0F; break;
        case EngineType::HD1: e.p[E_FILT_TYPE] = 1.0F; e.p[E_CUTOFF] = 20000.0F; break;
        case EngineType::Off: break;
    }
    return e;
}

float engineClamp(EngineType t, int id, float v) noexcept {
    if (!std::isfinite(v)) return 0.0F;
    const EngineParamDef* d = engineParamDef(t, id);
    if (d == nullptr) {
        // an id this engine does not show: keep it inside the widest common range
        return std::clamp(v, -20000.0F, 20000.0F);
    }
    float x = std::clamp(v, d->lo, d->hi);
    if (d->kind == EngineKind::Choice || d->kind == EngineKind::Switch || d->kind == EngineKind::Drawbar || (d->kind == EngineKind::Lin && d->step >= 1.0F)) x = std::round(x);
    return x;
}

} // namespace silveton::sampler
