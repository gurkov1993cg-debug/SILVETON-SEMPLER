#include "silveton/sampler/EngineDefs.h"
#include "silveton/sampler/SoloDefs.h"
namespace silveton::sampler {
int engineStoredCount(const EngineParams& e) noexcept {return e.chosen()?64:0;}
EngineType engineChoice(int n) noexcept {return n==1?EngineType::Solo:EngineType::Off;}
const char* engineName(EngineType t) noexcept {return t==EngineType::Solo?"SILVETON SOLO":"OFF";}
const char* engineLine(EngineType t) noexcept {return t==EngineType::Solo?"STAVROS / DRUGO — one continuous SOLO synthesizer":"Sample playback";}
int engineOscPage(EngineType) noexcept {return 0;}
int enginePageCount(EngineType t) noexcept {return t==EngineType::Solo?1:0;}
const char* enginePageName(EngineType,int,int) noexcept {return "SOLO";}
EngineParamPage enginePage(EngineType t,int page,int) noexcept {return t==EngineType::Solo&&page==0?EngineParamPage{solo::parameter(0),solo::Count}:EngineParamPage{nullptr,0};}
const EngineParamDef* engineParamDef(EngineType t,int id) noexcept {return t==EngineType::Solo?solo::parameter(id):nullptr;}
EngineParams engineDefaults(EngineType t) noexcept {EngineParams e;e.type=engineTypeOf(static_cast<int>(t));if(e.chosen())solo::defaults(e.p.data());return e;}
float engineClamp(EngineType t,int id,float v) noexcept {return t==EngineType::Solo?solo::clamp(id,v):0;}
bool engineMakesOwnSound(const EngineParams& e) noexcept {return e.chosen();}
void engineSanitizeLoaded(EngineParams& e) noexcept {
 // Slot 20 marked the personal spectral SOLO source. Older SOLO sources are
 // removed too; leave them OFF instead of pretending they are the new sound.
 if(e.type!=EngineType::Solo||e.p[20]<.5F||e.p[19]!=0)e=EngineParams{};
 else e.p[E_BEND_DOWN]=e.p[E_BEND_UP];
}
}
