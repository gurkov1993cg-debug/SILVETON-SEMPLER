// SILVETON_ENGINES_V1 / V2 - the sound of the nine engines (see include/silveton/sampler/EngineDefs.h).
// Included by SamplerEngine.cpp inside its file-local namespace, after the filters, ModEngine, Biquad and HeapLine:
// it uses them. Two parts:
//   eng::EngineVoice - lives in every voice: the per-note part of an engine - the band-limited oscillators (AL-1,
//                      POLYSIX, MS-20), the six FM operators of MOD-7, the STR-1 string with its pluck, the CX-3 tonewheel
//                      sum / percussion / click, the EP tine model and pickup, the SGX half pedal and noises, the main
//                      filter models (ladder, Korg35 LP / HP, state variable), the filter envelope, the LFO, the MS-20
//                      EG1 / ESP / S&H / patch panel.
//   eng::EngineBus   - one per Upper: the 91 shared tonewheels of CX-3 (continuous phase, computed once per chunk before
//                      the voices read them), and after the sum of the Upper: Polysix chorus / phase / ensemble, the CX-3
//                      scanner and Leslie (horn and drum apart), the EP preamp / tremolo / cabinet, the SGX strings
//                      (energy-limited) and body, the STR-1 body, the HD-1 low boost.
// Everything here is our own model of the original instruments. Nothing allocates, locks or blocks on the audio thread:
// the only buffers (EngineBus::allocate) are made when the sampler is prepared.
#pragma once

#include "silveton/sampler/EngineDefs.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace eng {

constexpr int kSineBits = 12;
constexpr int kSineSize = 1 << kSineBits;

inline const float* sineTable() noexcept {
    static const std::array<float, kSineSize + 1> table = [] {
        std::array<float, kSineSize + 1> t{};
        for (int i = 0; i <= kSineSize; ++i) t[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(2.0 * kPi * static_cast<double>(i) / kSineSize));
        return t;
    }();
    return table.data();
}

// sine of a phase given in cycles (any value)
inline float sin01(double cycles) noexcept {
    cycles -= std::floor(cycles);
    const double x = cycles * kSineSize;
    const int i = static_cast<int>(x);
    const float f = static_cast<float>(x - static_cast<double>(i));
    const float* t = sineTable();
    const auto k = static_cast<std::size_t>(std::min(i, kSineSize - 1));
    return t[k] + (t[k + 1U] - t[k]) * f;
}

inline float wrap01(double& ph) noexcept { ph -= std::floor(ph); return static_cast<float>(ph); }

inline float noise(std::uint32_t& s) noexcept {
    s = s * 1664525U + 1013904223U;
    return static_cast<float>(s >> 8) / 8388608.0F - 1.0F;
}

inline float softFold(float x, float amount) noexcept {
    if (amount <= 0.0F) return x;
    const float g = 1.0F + 4.0F * amount;
    float y = x * g;
    // triangle fold between -1 and 1
    y = std::fabs(std::fmod(y + 1.0F, 4.0F));
    if (y > 2.0F) y = 4.0F - y;
    return (y - 1.0F) * (1.0F - 0.55F * amount);
}

// SILVETON_ENGINES_V2: tanh from a table (4097 points over -8..8, linear between them; the largest error against
// std::tanh is below 2e-5, checked by the engine test). The filters and pickups call it many times per sample.
constexpr int kTanhPoints = 4096;
constexpr float kTanhRange = 8.0F;
inline const float* tanhTable() noexcept {
    static const std::array<float, kTanhPoints + 2> table = [] {
        std::array<float, kTanhPoints + 2> t{};
        for (int i = 0; i <= kTanhPoints + 1; ++i) {
            const double x = -static_cast<double>(kTanhRange) + 2.0 * kTanhRange * static_cast<double>(i) / kTanhPoints;
            t[static_cast<std::size_t>(i)] = static_cast<float>(std::tanh(x));
        }
        return t;
    }();
    return table.data();
}
inline float tanhT(float x) noexcept {
    if (x >= kTanhRange) return 1.0F;
    if (x <= -kTanhRange) return -1.0F;
    const float u = (x + kTanhRange) * (static_cast<float>(kTanhPoints) / (2.0F * kTanhRange));
    const int i = static_cast<int>(u);
    const float f = u - static_cast<float>(i);
    const float* t = tanhTable();
    const auto k = static_cast<std::size_t>(std::min(i, kTanhPoints));
    return t[k] + (t[k + 1U] - t[k]) * f;
}

inline bool finite(float x) noexcept { return std::isfinite(x) && std::fabs(x) < 1.0e6F; }
inline void flush(float& x) noexcept { if (std::fabs(x) < 1.0e-18F) x = 0.0F; }

// Per-block ADSR: linear attack, exponential decay / release. dt = seconds per step.
struct Adsr {
    int stage{0};   // 0 idle 1 attack 2 decay 3 sustain 4 release
    float v{0.0F};
    void on() noexcept { stage = 1; }
    void off() noexcept { if (stage != 0) stage = 4; }
    float step(float aMs, float dMs, float s, float rMs, float dt) noexcept {
        s = std::clamp(s, 0.0F, 1.0F);
        switch (stage) {
            case 1: v += dt * 1000.0F / std::max(aMs, 0.1F); if (v >= 1.0F) { v = 1.0F; stage = 2; } break;
            case 2: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(dMs, 1.0F)); v += (s - v) * k; if (std::fabs(v - s) < 0.001F) { v = s; stage = 3; } } break;
            case 3: v = s; break;
            case 4: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(rMs, 1.0F)); v -= v * k; if (v < 0.0005F) { v = 0.0F; stage = 0; } } break;
            default: v = 0.0F; break;
        }
        return v;
    }
};

// MS-20 EG1: delay, attack, then held at 1 while the key is down, release when it goes up.
struct Dar {
    int stage{0};   // 0 idle 1 delay 2 attack 3 hold 4 release
    float v{0.0F};
    float t{0.0F};
    void on() noexcept { stage = 1; t = 0.0F; v = 0.0F; }
    void off() noexcept { if (stage != 0) stage = 4; }
    float step(float delayMs, float aMs, float rMs, float dt) noexcept {
        switch (stage) {
            case 1: t += dt * 1000.0F; if (t >= delayMs) stage = 2; break;
            case 2: v += dt * 1000.0F / std::max(aMs, 0.1F); if (v >= 1.0F) { v = 1.0F; stage = 3; } break;
            case 3: v = 1.0F; break;
            case 4: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(rMs, 1.0F)); v -= v * k; if (v < 0.0005F) { v = 0.0F; stage = 0; } } break;
            default: v = 0.0F; break;
        }
        return v;
    }
};

// a one-pole in both directions
struct Pole { float z{0.0F}; float lp(float x, float a) noexcept { z += (x - z) * a; return z; } };

// RBJ low / high pass (Butterworth Q) - the cabinet
struct Lp2 {
    float b0{1.0F}, b1{0.0F}, b2{0.0F}, a1{0.0F}, a2{0.0F};
    float z1L{0.0F}, z2L{0.0F}, z1R{0.0F}, z2R{0.0F};
    void set(double sr, double hz, bool high, double q = 0.7071) noexcept {
        const double w0 = 2.0 * kPi * std::clamp(hz, 10.0, 0.45 * sr) / sr;
        const double c = std::cos(w0), s = std::sin(w0), al = s / (2.0 * q);
        double B0, B1, B2;
        if (high) { B0 = (1.0 + c) * 0.5; B1 = -(1.0 + c); B2 = (1.0 + c) * 0.5; }
        else { B0 = (1.0 - c) * 0.5; B1 = 1.0 - c; B2 = (1.0 - c) * 0.5; }
        const double A0 = 1.0 + al, A1 = -2.0 * c, A2 = 1.0 - al;
        b0 = static_cast<float>(B0 / A0); b1 = static_cast<float>(B1 / A0); b2 = static_cast<float>(B2 / A0);
        a1 = static_cast<float>(A1 / A0); a2 = static_cast<float>(A2 / A0);
    }
    static float tick(float x, float& z1, float& z2, float b0, float b1, float b2, float a1, float a2) noexcept {
        const float y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y;
    }
    void process(float& l, float& r) noexcept { l = tick(l, z1L, z2L, b0, b1, b2, a1, a2); r = tick(r, z1R, z2R, b0, b1, b2, a1, a2); }
    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0F; }
};

// SILVETON_ENGINES_V2: one mode of a body or a tine - a two-pole resonator
//   y = g x + a1 y1 + a2 y2,  r = exp(-1 / (tau sr)),  w = 2 pi f / sr,  a1 = 2 r cos w,  a2 = -r^2
struct Modal {
    float y1{0.0F}, y2{0.0F}, a1{0.0F}, a2{0.0F}, g{0.0F};
    // impulse = false: about unit gain for a steady tone at the peak, whatever the decay (a body that filters a sound);
    // impulse = true: a short hit of area 1 rings with amplitude `gain` (a struck tine)
    void set(double sr, double hz, double tauSec, float gain, bool impulse = false) noexcept {
        hz = std::clamp(hz, 10.0, 0.45 * sr);
        const double r = std::exp(-1.0 / (std::max(tauSec, 0.001) * sr));
        const double w = 2.0 * kPi * hz / sr;
        a1 = static_cast<float>(2.0 * r * std::cos(w));
        a2 = static_cast<float>(-r * r);
        g = gain * static_cast<float>((impulse ? 1.0 : (1.0 - r)) * std::sin(w));
    }
    float tick(float x) noexcept {
        const float y = g * x + a1 * y1 + a2 * y2;
        y2 = y1; y1 = y;
        return y;
    }
    void reset() noexcept { y1 = y2 = 0.0F; }
    void guard() noexcept { if (!finite(y1) || !finite(y2)) reset(); flush(y1); flush(y2); }
};

// SILVETON_ENGINES_V2: the polyBLEP residual of a step at the phase wrap (t = phase 0..1, dt = phase per sample)
inline float blep(double t, double dt) noexcept {
    if (t < dt) { t /= dt; return static_cast<float>(t + t - t * t - 1.0); }
    if (t > 1.0 - dt) { t = (t - 1.0) / dt; return static_cast<float>(t * t + t + t + 1.0); }
    return 0.0F;
}

// SILVETON_ENGINES_V2: a band-limited oscillator - saw and pulse by polyBLEP, triangle as the integrated pulse, sine
// from the table. Its output is one sample late, so that a hard sync can correct the sample before the reset as
// well as the one after it (the two polyBLEP residuals of the jump). wave: 0 off 1 saw 2 pulse 3 tri 4 sine.
struct Osc {
    double ph{0.0};
    float tri{-1.0F};
    float dly{0.0F}, corr{0.0F};
    bool wrapped{false};
    double wrapD{0.0};   // after step(): how many samples ago (0..1) the phase wrapped
    void reset(double startPhase) noexcept { ph = startPhase - std::floor(startPhase); tri = -1.0F + 4.0F * static_cast<float>(std::min(ph, 0.5)); dly = corr = 0.0F; wrapped = false; }
    static float raw(int wave, double p, float pw, float triV) noexcept {
        switch (wave) {
            case 1: return static_cast<float>(2.0 * p - 1.0);
            case 2: return p < static_cast<double>(pw) ? 1.0F : -1.0F;
            case 3: return triV;
            case 4: return sin01(p);
            default: return 0.0F;
        }
    }
    // advance one sample; returns this sample's band-limited value (the caller passes it to out())
    float step(int wave, double inc, float pw) noexcept {
        inc = std::clamp(inc, 0.0, 0.49);
        ph += inc; wrapped = false;
        if (ph >= 1.0) { ph -= 1.0; if (ph >= 1.0) ph -= std::floor(ph); wrapped = true; wrapD = inc > 0.0 ? ph / inc : 0.0; }
        switch (wave) {
            case 1: return static_cast<float>(2.0 * ph - 1.0) - blep(ph, inc);
            case 2: {
                float y = ph < static_cast<double>(pw) ? 1.0F : -1.0F;
                y += blep(ph, inc);
                double t2 = ph - static_cast<double>(pw); if (t2 < 0.0) t2 += 1.0;
                return y - blep(t2, inc);
            }
            case 3: {
                float sq = ph < 0.5 ? 1.0F : -1.0F;
                sq += blep(ph, inc);
                double t2 = ph - 0.5; if (t2 < 0.0) t2 += 1.0;
                sq -= blep(t2, inc);
                tri += static_cast<float>(4.0 * inc) * sq;
                tri *= 0.9995F;
                return tri;
            }
            case 4: return sin01(ph);
            default: return 0.0F;
        }
    }
    // the delayed output: the previous sample plus its pending correction
    float out(float yNow) noexcept { const float o = dly + corr; dly = yNow; corr = 0.0F; return o; }
    // hard sync to a master that wrapped d samples ago (0 <= d < 1): the phase restarts there. The jump is spread by the
    // two polyBLEP residuals: one on the sample before (still in the delay slot), one on this sample (yNow is rewritten).
    void sync(int wave, double inc, float pw, double d, float& yNow) noexcept {
        if (wave == 0) return;
        inc = std::clamp(inc, 0.0, 0.49);
        d = std::clamp(d, 0.0, 0.999);
        const double newPh = d * inc;
        double phW = ph - newPh; if (phW < 0.0) phW += 1.0;               // the phase the slave had at the wrap instant
        const float yOld = raw(wave, phW, pw, tri);
        if (wave == 3) tri = -1.0F + 4.0F * static_cast<float>(newPh);
        const float yAt0 = raw(wave, 0.0, pw, -1.0F);
        const float yNew = raw(wave, newPh, pw, tri);
        const float J = yAt0 - yOld;
        corr += static_cast<float>(0.5 * static_cast<double>(J) * d * d);
        yNow = yNew - static_cast<float>(0.5 * static_cast<double>(J) * (1.0 - d) * (1.0 - d));
        ph = newPh; wrapped = true; wrapD = d;
    }
};

// SILVETON_ENGINES_V2: the 4-pole ladder of POLYSIX / AL-1 (type LP24). Zero-delay feedback (the linear part is solved
// exactly), the nonlinearity of the feedback input solved by two fixed-point passes, a soft saturation of every stage
// (SAT). Divergence guard: a state that is not finite is cleared.
struct Ladder4 {
    float G{0.0F}, k{0.0F}, comp{1.0F}, sat{0.0F};
    std::array<float, 4> sL{}, sR{};
    bool prime{true};
    void set(float cutoffHz, float resonance, double sr, float saturation) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        G = static_cast<float>(g / (1.0 + g));
        k = 4.0F * std::clamp(resonance, 0.0F, 1.0F) * 0.985F;
        comp = 1.0F + 0.5F * k;   // keep the bass when the resonance is up
        sat = std::clamp(saturation, 0.0F, 1.0F);
    }
    static float stageSat(float a, float s) noexcept {
        if (s <= 0.0F) return a;
        const float c = std::clamp(a, -2.0F, 2.0F);
        return a + s * (c - a - c * c * c * (1.0F / 6.0F));   // cubic softening, bounded
    }
    float tick(float x, std::array<float, 4>& st) const noexcept {
        const float g1 = 1.0F - G;
        const float G2 = G * G, G3 = G2 * G, G4 = G3 * G;
        const float S = g1 * (G3 * st[0] + G2 * st[1] + G * st[2] + st[3]);   // what the states alone give at the output
        const float xin = x * comp;
        float u = 0.0F;
        if (sat > 0.0F) {
            // u = tanh(d (x - k y4)) / d  with  y4 = G4 u + S : two passes from the linear solution
            const float d = 1.0F + 2.0F * sat;
            float y4 = (G4 * xin + S) / (1.0F + k * G4);
            for (int it = 0; it < 2; ++it) {
                u = tanhT((xin - k * y4) * d) / d;
                y4 = G4 * u + S;
            }
            u = tanhT((xin - k * y4) * d) / d;
        } else {
            u = (xin - k * S) / (1.0F + k * G4);
        }
        for (int i = 0; i < 4; ++i) {
            const auto ii = static_cast<std::size_t>(i);
            const float a = stageSat(u, sat * 0.6F);
            const float vI = (a - st[ii]) * G;
            const float y = vI + st[ii];
            st[ii] = y + vI;
            u = y;
        }
        return u;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { sL.fill(0.0F); sR.fill(0.0F); prime = false; }
        l = tick(l, sL); r = tick(r, sR);
        if (!finite(l) || !finite(r)) { sL.fill(0.0F); sR.fill(0.0F); l = r = 0.0F; }
    }
    void guard() noexcept { for (auto& s : sL) flush(s); for (auto& s : sR) flush(s); }
};

// SILVETON_ENGINES_V2: the Korg35 filters of the MS-20 - low-pass (LPF1 -> LPF2, an HPF in the feedback with gain K)
// and high-pass (HPF1 -> HPF2, an LPF in the feedback). Zero-delay (the linear loop is solved exactly). ANALOG model: the
// feedback is saturated and the loop is solved by three fixed-point passes from the linear solution (the loop gain is
// below 0.5, so the passes converge); a result that is not finite clears the filter.
struct SkFilter {
    bool high{false};
    float G{0.0F}, K{0.0F}, satD{0.0F};
    bool analog{true};
    float s1L{0.0F}, s2L{0.0F}, s3L{0.0F}, s1R{0.0F}, s2R{0.0F}, s3R{0.0F};
    bool prime{true};
    void set(float cutoffHz, float resonance, double sr, bool analogModel, float fbSat) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        G = static_cast<float>(g / (1.0 + g));
        K = 2.0F * std::clamp(resonance, 0.0F, 1.0F) * 0.985F;
        analog = analogModel;
        satD = 0.5F + 1.5F * std::clamp(fbSat, 0.0F, 1.0F);
    }
    float sat(float x) const noexcept { return analog ? tanhT(x * satD) / satD : x; }
    float tickLp(float x, float& s1, float& s2, float& s3) const noexcept {
        // LPF1
        const float v1 = (x - s1) * G; const float u = v1 + s1; s1 = u + v1;
        const float g1 = 1.0F - G;
        // LPF2 with the HPF1 feedback: y = G (u + fb) + g1 s2,  fb = sat(K g1 (y - s3))
        const float den = 1.0F - G * K * g1;
        float y = (G * u - G * K * g1 * s3 + g1 * s2) / std::max(den, 0.05F);
        if (analog) {
            for (int it = 0; it < 3; ++it) y = G * (u + sat(K * g1 * (y - s3))) + g1 * s2;
            y = std::clamp(y, -4.0F, 4.0F);
        }
        const float fb = sat(K * g1 * (y - s3));
        const float in2 = u + fb;
        const float v2 = (in2 - s2) * G; const float y2 = v2 + s2; s2 = y2 + v2;
        const float v3 = (y2 - s3) * G; const float lp3 = v3 + s3; s3 = lp3 + v3;
        return y2;
    }
    float tickHp(float x, float& s1, float& s2, float& s3) const noexcept {
        const float g1 = 1.0F - G;
        // HPF1: hp = g1 (x - s1)
        const float h1 = g1 * (x - s1);
        const float v1 = (x - s1) * G; s1 = s1 + 2.0F * v1;
        // HPF2 with the LPF feedback: y = g1 (h1 + fb - s2),  fb = sat(K (G y + g1 s3))
        const float den = 1.0F - g1 * K * G;
        float y = g1 * (h1 + K * g1 * s3 - s2) / std::max(den, 0.05F);
        if (analog) {
            for (int it = 0; it < 3; ++it) y = g1 * (h1 + sat(K * (G * y + g1 * s3)) - s2);
            y = std::clamp(y, -4.0F, 4.0F);
        }
        const float fb = sat(K * (G * y + g1 * s3));
        const float in2 = h1 + fb;
        const float v2 = (in2 - s2) * G; const float y2 = in2 - (v2 + s2); s2 = s2 + 2.0F * v2;
        const float v3 = (y2 - s3) * G; s3 = s3 + 2.0F * v3;
        return y2;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { s1L = s2L = s3L = s1R = s2R = s3R = 0.0F; prime = false; }
        if (high) { l = tickHp(l, s1L, s2L, s3L); r = tickHp(r, s1R, s2R, s3R); }
        else { l = tickLp(l, s1L, s2L, s3L); r = tickLp(r, s1R, s2R, s3R); }
        if (!finite(l) || !finite(r)) { s1L = s2L = s3L = s1R = s2R = s3R = 0.0F; l = r = 0.0F; }
    }
    void reset() noexcept { prime = true; }
    void guard() noexcept { flush(s1L); flush(s2L); flush(s3L); flush(s1R); flush(s2R); flush(s3R); }
};

// SILVETON_ENGINES_V2: the MOD-7 algorithms - who modulates whom among the six operators. Operator 1 is the recording,
// 2..6 are sines. mod[i] = bit mask of the operators that modulate operator i; carrier = bit mask of the operators heard
// on their own; fb = the operator with the FEEDBACK knob on itself.
struct Algo { std::uint8_t mod[6]; std::uint8_t carrier; std::uint8_t fb; };
inline const Algo& algoOf(int ix) noexcept {
    static const Algo kAlgos[12] = {
        {{0x02, 0x04, 0x00, 0x00, 0x00, 0x00}, 0x01, 1},   // 1  PCM <- 2 <- 3   (the V1 routing; OP3-> may send 3 to the PCM instead)
        {{0x02, 0x04, 0x08, 0x00, 0x00, 0x00}, 0x01, 3},   // 2  PCM <- 2 <- 3 <- 4
        {{0x0E, 0x00, 0x00, 0x00, 0x00, 0x00}, 0x01, 3},   // 3  PCM <- 2 + 3 + 4
        {{0x02, 0x00, 0x08, 0x00, 0x00, 0x00}, 0x05, 3},   // 4  two carriers: PCM <- 2, 3 <- 4
        {{0x02, 0x00, 0x08, 0x00, 0x20, 0x00}, 0x15, 5},   // 5  three carriers: PCM <- 2, 3 <- 4, 5 <- 6
        {{0x20, 0x20, 0x20, 0x20, 0x20, 0x00}, 0x1F, 5},   // 6  fan: 6 -> everyone, five carriers
        {{0x00, 0x04, 0x00, 0x10, 0x00, 0x00}, 0x2B, 2},   // 7  pairs: 2 <- 3, 4 <- 5, 6 and PCM alone
        {{0x02, 0x04, 0x08, 0x10, 0x20, 0x00}, 0x01, 5},   // 8  feedback chain: PCM <- 2 <- 3 <- 4 <- 5 <- 6 (fb on 6)
        {{0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, 0x3F, 5},   // 9  organ: six carriers, no modulation
        {{0x02, 0x00, 0x08, 0x00, 0x20, 0x00}, 0x15, 1},   // 10 bell: like 5, feedback on 2 (set OP2 RATIO 3.5, OP4 RATIO 1.41)
        {{0x00, 0x04, 0x08, 0x10, 0x20, 0x00}, 0x03, 5},   // 11 PCM + a 5-deep stack on carrier 2
        {{0x3E, 0x00, 0x00, 0x00, 0x00, 0x00}, 0x01, 5},   // 12 everything modulates the PCM
    };
    return kAlgos[static_cast<std::size_t>(std::clamp(ix, 0, 11))];
}

// SILVETON_ENGINES_V2: does this engine make a sound of its own (so it plays even on an Upper that has no recording)
inline bool makesOwnSound(const silveton::sampler::EngineParams& e) noexcept { return silveton::sampler::engineMakesOwnSound(e); }

// what the per-block update needs to know about the player
struct BlockCtx {
    double sr{48000.0};
    float dt{0.001F};        // seconds of this block
    float wheel{0.0F};       // CC1 0..1
    float soft{0.0F};        // CC67 0..1
    float pedal{0.0F};       // the damper controller 0..1 (raw, for the half pedal)
    float velNorm{1.0F};
    int key{60};
    bool keyHeld{true};
    bool sustained{false};   // the key is up and the pedal keeps the note
};

struct EngineBus;

// ---------------------------------------------------------------------------------------------------------------
struct EngineVoice {
    static constexpr int kStringMax = 4096;   // one period down to 23 Hz at 96 kHz (a power of two: the index is masked)
    static constexpr int kStringMask = kStringMax - 1;
    static constexpr int kPickMax = 2048;
    static constexpr int kPickMask = kPickMax - 1;

    silveton::sampler::EngineType type{silveton::sampler::EngineType::Off};
    bool live{false};            // the Upper's ENGINE is on and is still the one this note started with
    bool startedLive{false};     // the ENGINE was on when the note started (a note started with ENGINE OFF stays plain)
    bool recEnded{false};        // the recording ran out; the engine's own generators keep the note (holdsAfterEnd)
    double syncHome{0.0};        // AL-1 SYNC: where the recording restarts (the note's start; a looped recording restarts at its loop)
    float keyHz{440.0F};
    int key{60};
    double inc0{0.0};            // cycles per sample of the key, when the recording has no known period
    std::uint32_t rng{0x51ED1234U};
    float random{0.0F};
    float velNorm{1.0F};
    bool keyDown{true};
    // per-block modulation results (read by the voice loop as constants of the block)
    float egF{0.0F};             // filter envelope 0..1
    float cutOct{0.0F};          // to the main filter
    float resAdd{0.0F};          // MS-20 patch: to the LP peak
    float pitchSemis{0.0F};      // to the pitch
    float ampMul{1.0F};          // to the level
    float pedalGain{1.0F};       // SGX half pedal (persistent)
    float fmNow{0.0F};           // PCM FM depth of this block (AL-1)
    float panOffset{0.0F};       // SGX key position
    float lfoNow{0.0F};
    float lfoRateMul{1.0F};
    float pwNow{0.5F};           // pulse width of this block (oscillators)
    Adsr feg{};
    Adsr menv{};                 // MOD-7 modulator envelope
    Dar eg1{};
    double lfoPhase{0.0};
    float lfoHold{0.0F};
    bool lfoNew{true};
    // the main filter (used instead of the sampler's own while the engine is live)
    int filtKind{0};             // 0 SVF LP (clean / LP12) 1 ladder 2 Korg35 LP 3 SVF HP 4 SVF BP
    float filtHz{1000.0F}, filtRes{0.0F};
    Ladder4 ladder{};
    SkFilter sk{};
    StateVariableFilter svf{};
    // MS-20
    SkFilter hpf{};
    float hpfHz{20.0F}, hpfRes{0.0F};
    bool hpfOn{false};
    bool msParallel{false};
    float msHpL{0.0F}, msHpR{0.0F};
    float espEnv{0.0F};          // the envelope follower of the recording (ESP)
    float shHold{0.0F};
    double shPhase{0.0};
    // oscillators (AL-1: 1 and 2; POLYSIX: osc + square sub; MS-20: VCO 1 and 2)
    Osc osc1{}, osc2{}, osc3{};
    double pwmPhase{0.0};
    // the PCM FM / ring of AL-1, the V1 ring of MOD-7
    double op2Phase{0.0}, ringPhase{0.0};
    float ringNow{0.0F};
    // MOD-7 operators 2..6 (index 1..5; 0 = the recording)
    std::array<double, 6> opPh{};
    std::array<float, 6> opOut{};
    std::array<float, 6> opIdx{};      // modulation index (cycles) or carrier amplitude of this block
    std::array<float, 6> opRatio{};
    float carrierSum{0.0F};
    float fbNow{0.0F};
    float pegNow{0.0F};
    // AL-1 noise, sync
    Pole noiseLp{};
    double syncPhase{0.0};
    double syncOldPos{0.0};
    int syncXfade{0};
    // STR-1 string
    std::array<float, kStringMax> str{};
    std::array<float, kPickMax> pick{};
    int strW{0}, pickW{0};
    double strLen{100.0};        // fractional delay in samples
    float strG{0.99F};           // loop gain per pass
    float strLpA{0.5F};          // loop damping coefficient
    float strApA{0.0F};          // dispersion allpass coefficient
    float strLpZ{0.0F}, strApX{0.0F}, strApY{0.0F}, strFbZ{0.0F};
    double strComp{1.0};         // what the loop filters delay (subtracted from the period: the pitch stays exact)
    double strTune{1.0};         // STRING TUNE as a factor
    double strInc{0.0};          // the key's cycles per sample the length was made for (pitch bend / glide follow it)
    double strAgeSec{0.0};
    int pluckLeft{0};
    float pluckGain{0.0F}, pluckA{0.5F};
    Pole pluckLp{};
    // CX-3 (the wheels themselves live in the EngineBus)
    std::array<int, 9> twWheel{};
    std::array<float, 9> twLevel{};
    int percWheel{-1};
    float percEnv{0.0F}, percCoef{0.0F}, percGain{0.0F};
    float clickEnv{0.0F}, clickCoef{0.0F};
    Pole clickLp{};
    float leakLevel{0.0F};
    // SGX / EP noises and colour
    float hammerEnv{0.0F}, hammerCoef{0.0F};
    float keyOffEnv{0.0F}, keyOffCoef{0.0F};
    bool keyOffDone{false};
    StateVariableFilter keyOffBp{};
    Pole brightL{}, brightR{};
    float brightA{1.0F};
    Pole bellL{}, bellR{};
    float bellGain{0.0F}, barkDrive{0.0F};
    // EP tine model: three damped partials and the pickup
    std::array<Modal, 3> tine{};
    std::array<double, 3> tineRatio{{1.0, 2.0, 3.0}};
    double tineInc{0.0};         // the key's cycles per sample the tine is tuned to now (pitch bend / glide retune it)
    int tineHit{0};
    float tineExc{0.0F};
    Pole tineLp{};
    float tineLpA{1.0F};

    // -------------------------------------------------------------- note on / off
    void noteOn(const silveton::sampler::EngineParams& e, double sr, float hz, float vel, float rnd, double periodFrames, std::uint32_t seed, bool percAllowed) noexcept {
        using namespace silveton::sampler;
        type = e.type;
        live = e.on();
        startedLive = live;
        recEnded = false;
        keyHz = std::max(1.0F, hz);
        key = std::clamp(static_cast<int>(std::lround(69.0 + 12.0 * std::log2(static_cast<double>(keyHz) / 440.0))), 0, 127);
        inc0 = static_cast<double>(keyHz) / std::max(1.0, sr);
        (void)periodFrames;
        rng = seed | 1U;
        random = rnd;
        velNorm = std::clamp(vel, 0.0F, 1.0F);
        keyDown = true;
        feg = Adsr{}; feg.on();
        menv = Adsr{}; menv.on();
        eg1 = Dar{}; eg1.on();
        lfoPhase = 0.0; lfoNew = true; lfoHold = 0.0F; lfoRateMul = 1.0F;
        filtKind = 0; ladder.prime = true; sk.reset(); svf.reset();
        hpf.reset(); hpf.high = true; hpfOn = false; msParallel = false; msHpL = msHpR = 0.0F; espEnv = 0.0F; shHold = 0.0F; shPhase = 0.0;
        const double startPh = e.p[E_ANALOG] > 0.0F ? static_cast<double>(noise(rng)) * 0.5 + 0.5 : 0.0;
        osc1.reset(startPh); osc2.reset(startPh * 0.37); osc3.reset(0.0); pwmPhase = 0.0;
        op2Phase = ringPhase = 0.0; ringNow = 0.0F;
        opPh.fill(0.0); opOut.fill(0.0F); opIdx.fill(0.0F); opRatio.fill(1.0F); carrierSum = 0.0F; fbNow = 0.0F;
        noiseLp = Pole{};
        syncPhase = 0.0; syncXfade = 0;
        egF = cutOct = resAdd = pitchSemis = 0.0F; ampMul = 1.0F; pedalGain = 1.0F; fmNow = 0.0F; panOffset = 0.0F; pwNow = 0.5F;
        percEnv = clickEnv = hammerEnv = keyOffEnv = 0.0F; keyOffDone = false; percWheel = -1;
        pegNow = 0.0F;
        pluckLeft = 0; pluckGain = 0.0F; pluckLp = Pole{};
        tineHit = 0; tineExc = 0.0F; tineLp = Pole{};
        if (!live) return;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::Str1: {
                std::fill(str.begin(), str.end(), 0.0F); std::fill(pick.begin(), pick.end(), 0.0F);
                strW = pickW = 0; strLpZ = strApX = strApY = strFbZ = 0.0F; strAgeSec = 0.0;
                setString(e, sr);
                const float pl = std::clamp(p[ST_PLUCK], 0.0F, 1.0F);
                if (pl > 0.0F) {
                    pluckLeft = static_cast<int>(std::clamp(strLen, 2.0, 4000.0));   // one period of noise, as a pluck
                    pluckGain = pl * (0.3F + 0.7F * velNorm) * 0.5F;
                    const float hzc = std::clamp(p[ST_PLUCK_COLOR], 200.0F, 16000.0F) * (0.5F + 0.5F * velNorm);
                    pluckA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::min(hzc, 16000.0F) / static_cast<float>(sr));
                }
                break;
            }
            case EngineType::CX3: {
                // the nine footages of a drawbar organ, as steps from the key: 16' 5⅓' 8' 4' 2⅔' 2' 1⅗' 1⅓' 1'
                static const int steps[9] = {-12, 7, 0, 12, 19, 24, 28, 31, 36};
                const bool percOn = p[CX_PERC] >= 0.5F;
                const bool fold = p[CX_FOLDBACK] >= 0.5F;
                for (int k = 0; k < 9; ++k) {
                    int w = key - 24 + steps[k];   // wheel 0 = C1 (the 8' of the lowest key C2 is wheel 12)
                    if (fold) { while (w < 0) w += 12; while (w > 90) w -= 12; }
                    twWheel[static_cast<std::size_t>(k)] = (w >= 0 && w <= 90) ? w : -1;
                    float db = p[CX_DB16 + k];
                    if (percOn && k == 8) db = 0.0F;   // the 1' drawbar is borrowed by the percussion (as on the B-3)
                    twLevel[static_cast<std::size_t>(k)] = db <= 0.0F ? 0.0F : std::pow(10.0F, (db - 8.0F) * 3.0F / 20.0F);
                }
                if (percOn && percAllowed) {
                    const int partial = p[CX_PERC] >= 1.5F ? 4 : 3;   // 3rd = 2⅔', 2nd = 4'
                    percWheel = twWheel[static_cast<std::size_t>(partial)];
                    const float decaySec = p[CX_PERC_DECAY] >= 0.5F ? 0.9F : 0.3F;
                    percCoef = std::exp(-1.0F / (decaySec * static_cast<float>(sr)) * 4.6F);
                    percGain = p[CX_PERC_LEVEL] >= 0.5F ? 1.0F : 0.5F;
                    percEnv = 1.0F;
                }
                clickEnv = std::clamp(p[CX_CLICK], 0.0F, 1.0F) * 0.9F;
                clickCoef = std::exp(-1.0F / (0.004F * static_cast<float>(sr)));
                leakLevel = std::clamp(p[CX_LEAK], 0.0F, 1.0F) * 0.02F;
                break;
            }
            case EngineType::SGX: {
                hammerEnv = std::clamp(p[SG_HAMMER], 0.0F, 1.0F) * velNorm * velNorm * 0.8F;
                hammerCoef = std::exp(-1.0F / (0.005F * static_cast<float>(sr)));
                keyOffCoef = std::exp(-1.0F / (0.035F * static_cast<float>(sr)));
                // the brightness of the hit: a soft note is darker
                const float vb = std::clamp(p[SG_VEL_BRIGHT], 0.0F, 1.0F);
                const float hz2 = 20000.0F * std::pow(0.12F + 0.88F * velNorm, 1.5F * vb);
                brightA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::clamp(hz2, 300.0F, 20000.0F) / static_cast<float>(sr));
                brightL = Pole{}; brightR = Pole{};
                panOffset = std::clamp(static_cast<float>(key - 60) / 36.0F, -1.0F, 1.0F) * std::clamp(p[SG_WIDTH], 0.0F, 1.0F);
                break;
            }
            case EngineType::EP: {
                bellGain = std::clamp(p[EP_BELL], 0.0F, 1.0F) * velNorm * velNorm * 2.5F;
                barkDrive = std::clamp(p[EP_BARK], 0.0F, 1.0F) * velNorm * velNorm * 3.0F;
                bellL = Pole{}; bellR = Pole{};
                keyOffCoef = std::exp(-1.0F / (0.025F * static_cast<float>(sr)));
                const float gen = std::clamp(p[EP_MODEL], 0.0F, 1.0F);
                if (gen > 0.0F) setTine(e, sr);
                break;
            }
            case EngineType::HD1: pegNow = p[HD_PEG_CENTS] * 0.01F * (1.0F - std::clamp(p[HD_PEG_VEL], 0.0F, 1.0F) * (1.0F - velNorm)); break;
            case EngineType::Mod7: pegNow = p[M7_PEG]; break;
            default: break;
        }
    }

    void noteOff() noexcept {
        keyDown = false;
        feg.off();
        menv.off();
        eg1.off();
        // the key-off noises of the organ, the piano and the EP
        if (!keyOffDone) { keyOffDone = true; keyOffEnv = 1.0F; }
    }

    // does the engine keep the note alive after a one-shot recording ran out (it has a sound of its own)
    [[nodiscard]] bool holdsAfterEnd(const silveton::sampler::EngineParams& e) const noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::CX3: return true;
            case EngineType::Str1: return true;
            case EngineType::AL1: return (p[AL_OSC1_WAVE] >= 0.5F && p[AL_OSC1_LEVEL] > 0.0F) || (p[AL_OSC2_WAVE] >= 0.5F && p[AL_OSC2_LEVEL] > 0.0F) || p[AL_NOISE_LEVEL] > 0.0F;
            case EngineType::Polysix: return p[P6_OSC] >= 0.5F && p[P6_OSC_LEVEL] > 0.0F;
            case EngineType::MS20: return (p[MS_VCO1_WAVE] >= 0.5F && p[MS_VCO1_LEVEL] > 0.0F) || (p[MS_VCO2_WAVE] >= 0.5F && p[MS_VCO2_LEVEL] > 0.0F);
            case EngineType::Mod7: return (algoOf(static_cast<int>(std::lround(p[M7_ALGO]))).carrier & 0x3EU) != 0U && p[M7_OP_LEVEL] > 0.0F;
            case EngineType::EP: return p[EP_MODEL] > 0.0F;
            default: return false;
        }
    }

    void setString(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const double hz = static_cast<double>(keyHz) * std::pow(2.0, static_cast<double>(p[ST_TUNE]) / 1200.0);
        const float disp = std::clamp(p[ST_DISP], 0.0F, 1.0F);
        strApA = -0.55F * disp;                                   // first-order allpass: negative = the highs arrive earlier (stiff string)
        const double apDelay = (1.0 - static_cast<double>(strApA)) / (1.0 + static_cast<double>(strApA));
        const float damp = std::clamp(p[ST_DAMP], 0.0F, 1.0F);
        strLpA = 1.0F - 0.85F * damp;                             // loop low-pass
        const double lpDelay = (1.0 - static_cast<double>(strLpA)) / static_cast<double>(strLpA) * 0.5;
        // pitch compensation: the loop delay is the period minus what the two filters delay at low frequencies
        strComp = apDelay + lpDelay + 1.0;
        strTune = std::pow(2.0, static_cast<double>(p[ST_TUNE]) / 1200.0);
        strInc = static_cast<double>(keyHz) / sr;
        strLen = std::clamp(sr / std::max(20.0, hz) - strComp, 4.0, static_cast<double>(kStringMax - 4));
        float decay = std::clamp(p[ST_DECAY], 0.05F, 20.0F);
        decay *= std::pow(2.0F, -static_cast<float>(key - 48) / 24.0F * std::clamp(p[ST_KEY_DECAY], 0.0F, 1.0F));
        strG = std::exp(-6.9F * static_cast<float>(strLen / sr) / decay);
        // the loop gain check: the damping low-pass never exceeds 1, the allpass is exactly 1, the soft limiter's slope is
        // at most 1 - so the gain round the loop is at most strG, which stays below 1
        strG = std::min(strG, 0.9995F);
    }

    void setTine(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const bool reed = p[EP_TYPE] >= 0.5F;
        const float inh = std::clamp(p[EP_INHARM], 0.0F, 1.0F);
        const float hammer = std::clamp(p[EP_HAMMER], 0.0F, 1.0F);
        float dec = std::clamp(p[EP_TINE_DECAY], 0.3F, 15.0F);
        dec *= std::pow(2.0F, -static_cast<float>(key - 60) / 24.0F);   // the high tines die sooner
        // partial ratios: the tine's fundamental, its second mode (a little sharp of the octave) and the bell mode
        const double r2 = reed ? 2.0 : 2.0 * (1.0 + 0.06 * inh);
        const double r3 = reed ? 3.0 * (1.0 + 0.02 * inh) : 6.27 * (0.7 + 0.3 * inh) ;
        const float v = velNorm;
        const float bright = 0.25F + 0.75F * hammer * v;
        tineRatio = {{1.0, r2, r3}};
        tineInc = static_cast<double>(keyHz) / sr;
        tine[0].set(sr, keyHz, dec, 1.0F, true);
        tine[1].set(sr, keyHz * r2, dec * (reed ? 0.7 : 0.45), (reed ? 0.35F : 0.25F) * bright, true);
        tine[2].set(sr, keyHz * r3, dec * 0.2, (reed ? 0.15F : 0.3F) * bright * v, true);
        for (auto& m : tine) m.reset();
        tineHit = 3;
        tineExc = (0.3F + 0.7F * v) * 0.25F;   // 3 samples: an area of about 0.75 at full strength -> the tine rings at about 0.75
        const float hzLp = 800.0F + 12000.0F * hammer * v;
        tineLpA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::min(hzLp, 16000.0F) / static_cast<float>(sr));
    }

    // -------------------------------------------------------------- once per block
    void block(const silveton::sampler::EngineParams& e, const BlockCtx& c) noexcept {
        using namespace silveton::sampler;
        if (!e.on()) { cutOct = pitchSemis = resAdd = 0.0F; ampMul = 1.0F; return; }
        const float* p = e.p.data();
        // the filter envelope (the common ADSR)
        egF = feg.step(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], c.dt);
        // the LFO
        {
            const double rate = std::clamp(static_cast<double>(p[E_LFO_RATE] * lfoRateMul), 0.02, 60.0);
            const double before = lfoPhase;
            lfoPhase += rate * c.dt; lfoPhase -= std::floor(lfoPhase);
            const int wave = static_cast<int>(std::lround(p[E_LFO_WAVE]));
            const float ph = static_cast<float>(lfoPhase);
            switch (wave) {
                case 1: lfoNow = 1.0F - 4.0F * std::fabs(ph - 0.5F); break;
                case 2: lfoNow = 2.0F * ph - 1.0F; break;
                case 3: lfoNow = ph < 0.5F ? 1.0F : -1.0F; break;
                case 4: if (lfoNew || lfoPhase < before) { lfoHold = noise(rng); lfoNew = false; } lfoNow = lfoHold; break;
                default: lfoNow = sin01(lfoPhase); break;
            }
        }
        lfoRateMul = 1.0F;
        cutOct = p[E_FEG_AMT] * egF + p[E_LFO_CUT] * lfoNow;
        resAdd = 0.0F;
        pitchSemis = p[E_LFO_PITCH] * 0.01F * lfoNow;
        ampMul = std::max(0.0F, 1.0F - std::clamp(p[E_LFO_AMP], 0.0F, 1.0F) * (0.5F - 0.5F * lfoNow));
        fmNow = 0.0F;
        switch (type) {
            case EngineType::MS20: {
                const float g1 = eg1.step(p[MS_EG1_DELAY], p[MS_EG1_ATTACK], p[MS_EG1_RELEASE], c.dt);
                pitchSemis += p[MS_EG1_PITCH] * g1;
                float hpfOct = p[MS_EG1_HPF] * g1 + p[MS_MG_HPF] * lfoNow;
                float hpfResAdd = 0.0F;
                float pwAdd = 0.0F;
                const int to = static_cast<int>(std::lround(p[MS_WHEEL_TO]));
                const float wa = std::clamp(p[MS_WHEEL_AMT], 0.0F, 1.0F) * c.wheel;
                if (to == 1) pitchSemis += wa * 12.0F;
                else if (to == 2) cutOct += wa * 4.0F;
                else if (to == 3) hpfOct += wa * 4.0F;
                else if (to == 4) ampMul *= 1.0F - 0.9F * wa;
                // the patch panel: three cables
                shPhase += std::clamp(static_cast<double>(p[MS_SH_RATE]), 0.1, 50.0) * c.dt;
                if (shPhase >= 1.0) { shPhase -= std::floor(shPhase); shHold = noise(rng); }
                const float nz = noise(rng);
                for (int cbl = 0; cbl < 3; ++cbl) {
                    const int src = static_cast<int>(std::lround(p[MS_P1_SRC + 3 * cbl]));
                    const int dst = static_cast<int>(std::lround(p[MS_P1_DST + 3 * cbl]));
                    const float amt = std::clamp(p[MS_P1_AMT + 3 * cbl], -1.0F, 1.0F);
                    if (src <= 0 || amt == 0.0F) continue;
                    float s = 0.0F;
                    switch (src) {
                        case 1: s = g1; break;
                        case 2: s = egF; break;
                        case 3: s = lfoNow; break;
                        case 4: s = c.wheel; break;
                        case 5: s = std::min(1.5F, espEnv * (0.5F + 4.0F * std::clamp(p[MS_ESP_SENS], 0.0F, 1.0F))); break;
                        case 6: s = shHold; break;
                        case 7: s = nz; break;
                        case 8: s = velNorm; break;
                        default: s = static_cast<float>(c.key - 60) / 60.0F; break;
                    }
                    const float a = amt * s;
                    switch (dst) {
                        case 0: pitchSemis += 12.0F * a; break;
                        case 1: cutOct += 4.0F * a; break;
                        case 2: hpfOct += 4.0F * a; break;
                        case 3: ampMul *= std::clamp(1.0F + a, 0.0F, 2.0F); break;
                        case 4: resAdd += a; break;
                        case 5: hpfResAdd += a; break;
                        case 6: lfoRateMul *= std::exp2(2.0F * a); break;
                        default: pwAdd += 0.45F * a; break;
                    }
                }
                hpfHz = std::clamp(p[MS_HPF_CUT] * std::exp2(hpfOct), 20.0F, 20000.0F);
                hpfRes = std::clamp(p[MS_HPF_PEAK] + hpfResAdd, 0.0F, 1.0F);
                msParallel = p[MS_ROUTE] >= 0.5F;
                const bool want = hpfHz > 25.0F || hpfRes > 0.01F || msParallel;
                if (want && !hpfOn) hpf.reset();
                hpfOn = want;
                hpf.high = true;
                hpf.set(hpfHz, hpfRes, c.sr, p[MS_MODEL] >= 0.5F, p[MS_FB_SAT]);
                pwNow = std::clamp(p[MS_PW] + pwAdd, 0.05F, 0.95F);
                break;
            }
            case EngineType::AL1: {
                const float eg = std::clamp(p[AL_FM_EG], 0.0F, 1.0F);
                fmNow = std::clamp(p[AL_FM_AMT], 0.0F, 2.0F) * (1.0F - eg + eg * egF);
                pwNow = std::clamp(p[AL_PW] + std::clamp(p[AL_PWM], 0.0F, 0.45F) * lfoNow, 0.05F, 0.95F);
                break;
            }
            case EngineType::Polysix: {
                pwmPhase += std::clamp(static_cast<double>(p[P6_PWM_RATE]), 0.02, 20.0) * c.dt; pwmPhase -= std::floor(pwmPhase);
                const int osc = static_cast<int>(std::lround(p[P6_OSC]));
                const float base = p[P6_PWM_WIDTH] < 0.02F ? 0.5F : std::clamp(p[P6_PWM_WIDTH], 0.02F, 0.95F);
                const float depth = osc == 3 ? std::max(std::clamp(p[P6_PWM_DEPTH], 0.0F, 0.45F), 0.15F) : std::clamp(p[P6_PWM_DEPTH], 0.0F, 0.45F);
                pwNow = std::clamp(base + depth * sin01(pwmPhase), 0.05F, 0.95F);
                break;
            }
            case EngineType::Mod7: {
                const float bright = std::exp2(std::clamp(p[M7_BRIGHT], -1.0F, 1.0F));
                const float eg = std::clamp(p[M7_FM_EG], 0.0F, 1.0F);
                const float vel = std::clamp(p[M7_FM_VEL], 0.0F, 1.0F);
                const float me = menv.step(p[M7_ENV_A], p[M7_ENV_D], p[M7_ENV_S], p[M7_ENV_R], c.dt);
                const float ea = std::clamp(p[M7_ENV_AMT], 0.0F, 1.0F);
                const float scale = bright * (1.0F - eg + eg * egF) * (1.0F - vel + vel * velNorm) * (1.0F - ea + ea * me);
                const Algo& a = algoOf(static_cast<int>(std::lround(p[M7_ALGO])));
                static const int levelId[6] = {0, M7_OP2_LEVEL, M7_OP3_LEVEL, M7_OP4_LEVEL, M7_OP5_LEVEL, M7_OP6_LEVEL};
                static const int ratioId[6] = {0, M7_OP2_RATIO, M7_OP3_RATIO, M7_OP4_RATIO, M7_OP5_RATIO, M7_OP6_RATIO};
                const float det = std::exp2(std::clamp(p[M7_FINE], -50.0F, 50.0F) / 1200.0F);
                const float opsOut = std::clamp(p[M7_OP_LEVEL], 0.0F, 1.0F);
                for (int i = 1; i < 6; ++i) {
                    const auto ii = static_cast<std::size_t>(i);
                    const float lev = std::clamp(p[levelId[i]], 0.0F, 2.0F);
                    const bool carrier = ((a.carrier >> i) & 1U) != 0U;
                    opIdx[ii] = carrier ? lev * 0.5F * opsOut : lev * 0.75F * scale;   // a carrier: its loudness; a modulator: its index in cycles
                    opRatio[ii] = std::clamp(p[ratioId[i]], 0.25F, 16.0F) * ((i & 1) == 0 ? det : 1.0F);
                }
                fbNow = std::clamp(p[M7_FEEDBACK], 0.0F, 1.0F) * 0.25F;
                const float ms = std::clamp(p[M7_PEG_TIME], 1.0F, 5000.0F);
                pegNow *= std::exp(-c.dt * 1000.0F / ms * 4.6F);
                pitchSemis += pegNow;
                break;
            }
            case EngineType::HD1: {
                const float ms = std::clamp(p[HD_PEG_TIME], 1.0F, 5000.0F);
                pegNow *= std::exp(-c.dt * 1000.0F / ms * 4.6F);
                pitchSemis += pegNow;
                break;
            }
            case EngineType::SGX: {
                // una corda: the left pedal takes some level and brightness
                const float uc = std::clamp(p[SG_UNA_CORDA], 0.0F, 1.0F) * c.soft;
                ampMul *= 1.0F - 0.3F * uc;
                // the half pedal: a key that is up and kept only by the pedal dies as fast as the dampers are let down
                if (p[SG_HALF_PEDAL] >= 0.5F && !c.keyHeld && c.sustained) {
                    const float lift = std::clamp((c.pedal - 0.5F) * 2.0F, 0.0F, 1.0F);   // 1 = the pedal fully down (the dampers are up)
                    const float damperTime = std::clamp(p[SG_DAMPER_TIME], 0.03F, 1.0F);
                    const float closeness = 1.0F - lift * lift;                           // how much the damper touches the string
                    if (closeness > 0.001F) pedalGain *= std::exp(-c.dt / damperTime * closeness);
                }
                ampMul *= pedalGain;
                break;
            }
            default: break;
        }
        // the filters' states never creep into the denormal range
        ladder.guard(); sk.guard(); hpf.guard();
        for (auto& m : tine) m.guard();
    }

    // -------------------------------------------------------------- the main filter (while the engine is live)
    void setMainFilter(const silveton::sampler::EngineParams& e, int kind, float hz, float res, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        if (kind != filtKind) { filtKind = kind; ladder.prime = true; sk.reset(); svf.reset(); }
        filtHz = hz;
        filtRes = std::clamp(res + resAdd, 0.0F, 1.0F);
        switch (kind) {
            case 1: ladder.set(hz, filtRes, sr, type == EngineType::Polysix ? p[P6_FILT_SAT] : 0.3F); break;
            case 2: sk.high = false; sk.set(hz, filtRes, sr, type != EngineType::MS20 || p[MS_MODEL] >= 0.5F, type == EngineType::MS20 ? p[MS_FB_SAT] : 0.5F); break;
            default: break;
        }
    }
    void mainFilter(float& l, float& r, double sr) noexcept {
        switch (filtKind) {
            case 1: ladder.process(l, r); break;
            case 2: sk.process(l, r); break;
            case 3: svf.process(l, r, FilterMode::HighPass, filtHz, filtRes, sr); break;
            case 4: svf.process(l, r, FilterMode::BandPass, filtHz, filtRes, sr); break;
            default: svf.process(l, r, FilterMode::LowPass, filtHz, filtRes, sr); break;
        }
        if (type == silveton::sampler::EngineType::MS20 && msParallel && hpfOn) { l = 0.5F * (l + msHpL); r = 0.5F * (r + msHpR); }
    }

    // -------------------------------------------------------------- per sample, before the recording is read:
    // the phase modulation of the recording, in periods of the key (0 = none). inc = cycles of the key per output sample.
    // (SILVETON_ENGINES_V2: the recording is moved in phase, never read backwards - the read rate stays the clean one.)
    float pmOffset(const silveton::sampler::EngineParams& e, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::AL1: {
                if (fmNow <= 0.0F) return 0.0F;
                op2Phase += inc * static_cast<double>(p[AL_FM_RATIO]);
                return fmNow * 0.5F * sin01(op2Phase);
            }
            case EngineType::Mod7: {
                const Algo& a = algoOf(static_cast<int>(std::lround(p[M7_ALGO])));
                const bool over = p[M7_OVERSAMPLE] >= 0.5F;
                const int passes = over ? 2 : 1;
                const double sub = over ? 0.5 : 1.0;
                float carriers = 0.0F;
                float pcmPm = 0.0F;
                for (int ps = 0; ps < passes; ++ps) {
                    std::array<float, 6> now{};
                    now[0] = 0.0F;
                    for (int i = 5; i >= 1; --i) {
                        const auto ii = static_cast<std::size_t>(i);
                        float pm = 0.0F;
                        const unsigned mask = a.mod[i];
                        if (mask != 0U) {
                            for (int j = 1; j < 6; ++j) {
                                if (((mask >> j) & 1U) == 0U) continue;
                                const auto jj = static_cast<std::size_t>(j);
                                pm += opIdx[jj] * (j > i ? now[jj] : opOut[jj]);   // a cycle uses last sample's value
                            }
                        }
                        if (a.fb == i && fbNow > 0.0F) pm += fbNow * opOut[ii];
                        // ALGO 1 keeps the V1 switch: OP3 -> OP2 or straight to the recording
                        if (i == 1 && &a == &algoOf(0) && p[M7_OP3_TARGET] >= 0.5F) pm -= opIdx[2] * now[2];
                        now[ii] = sin01(opPh[ii] + static_cast<double>(pm));
                        opPh[ii] += inc * static_cast<double>(opRatio[ii]) * sub;
                        if (opPh[ii] >= 4096.0) opPh[ii] -= std::floor(opPh[ii]);
                    }
                    float cs = 0.0F;
                    for (int i = 1; i < 6; ++i) if (((a.carrier >> i) & 1U) != 0U) cs += opIdx[static_cast<std::size_t>(i)] * now[static_cast<std::size_t>(i)];
                    carriers += cs;
                    float pm0 = 0.0F;
                    for (int j = 1; j < 6; ++j) if (((a.mod[0] >> j) & 1U) != 0U) pm0 += opIdx[static_cast<std::size_t>(j)] * now[static_cast<std::size_t>(j)];
                    if (&a == &algoOf(0) && p[M7_OP3_TARGET] >= 0.5F) pm0 += opIdx[2] * now[2];
                    pcmPm = pm0;
                    opOut = now;
                }
                carrierSum = carriers / static_cast<float>(passes);
                ringNow = opOut[1];
                return pcmPm * 0.5F;
            }
            default: return 0.0F;
        }
    }

    // -------------------------------------------------------------- per sample, after the recording was read (l / r = the recording)
    void post(const silveton::sampler::EngineParams& e, float& l, float& r, double inc, double sr, std::uint32_t frame, const EngineBus& bus) noexcept;

    // the STR-1 string: one sample in (the recording = the excitation), one sample out
    float stringTick(const silveton::sampler::EngineParams& e, float in, double sr, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        strAgeSec += 1.0 / sr;
        // SILVETON_ENGINES_V2: pitch bend / glide - the string follows the key's pitch of this sample
        if (inc > 1.0e-7 && std::fabs(inc - strInc) > strInc * 1.0e-5) {
            strInc = inc;
            strLen = std::clamp(1.0 / (inc * strTune) - strComp, 4.0, static_cast<double>(kStringMax - 4));
        }
        // the excitation feeds the string only for EXC LENGTH (0 = always)
        const float len = p[ST_EXC_LEN];
        // a recording driving a string at its own pitch adds up period after period: the excitation goes in quietly,
        // and the loop itself is soft-limited (a real string cannot swing without bound either)
        float x = in * 0.3F;
        if (len > 0.0F) {
            const double t = strAgeSec * 1000.0;
            const double fade = std::clamp((static_cast<double>(len) - t) / 5.0 + 1.0, 0.0, 1.0);   // a 5 ms fade at the end
            x *= static_cast<float>(fade);
        }
        if (pluckLeft > 0) {   // the pluck of its own: one period of coloured noise
            x += pluckLp.lp(noise(rng), pluckA) * pluckGain;
            --pluckLeft;
        }
        // pick position: the excitation minus itself delayed by PICK x the string length
        {
            const double d = std::clamp(static_cast<double>(std::clamp(p[ST_PICK], 0.02F, 0.5F)) * strLen, 1.0, static_cast<double>(kPickMax - 2));
            pick[static_cast<std::size_t>(pickW)] = x;
            const double rp = static_cast<double>(pickW) - d;
            const int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            const auto a0 = static_cast<std::size_t>(i0 & kPickMask), a1 = static_cast<std::size_t>((i0 + 1) & kPickMask);
            x -= pick[a0] + (pick[a1] - pick[a0]) * f;
            pickW = (pickW + 1) & kPickMask;
        }
        // feedback from the output back into the string (like a guitar in front of its amplifier)
        const float fb = std::clamp(p[ST_FEEDBACK], 0.0F, 1.0F);
        if (fb > 0.0F) x += tanhT(strFbZ * 2.0F) * fb * 0.35F;
        // read the string one period back (fractional), and at the pickup position
        const auto tap = [&](double delay) noexcept {
            const double rp = static_cast<double>(strW) - delay;
            const int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            const auto a0 = static_cast<std::size_t>(i0 & kStringMask), a1 = static_cast<std::size_t>((i0 + 1) & kStringMask);
            return str[a0] + (str[a1] - str[a0]) * f;
        };
        float y = tap(strLen);
        // loop filter: damping low-pass, dispersion allpass, nonlinearity, decay
        strLpZ += (y - strLpZ) * strLpA; y = strLpZ;
        {   // first-order allpass
            const float out = strApA * y + strApX - strApA * strApY;
            strApX = y; strApY = out; y = out;
        }
        const float nl = std::clamp(p[ST_NONLIN], 0.0F, 1.0F);
        if (nl > 0.0F) { const float g = 1.0F + 6.0F * nl; y = tanhT(y * g) / g; }
        else if (y > 0.7F || y < -0.7F) y = tanhT(y);
        y *= strG;
        float newSample = y + x;
        if (!finite(newSample)) { std::fill(str.begin(), str.end(), 0.0F); strLpZ = strApX = strApY = strFbZ = 0.0F; newSample = 0.0F; }
        str[static_cast<std::size_t>(strW)] = newSample;
        strW = (strW + 1) & kStringMask;
        // pickup position: the string minus itself at PICKUP x length (a comb on the output)
        const double pu = std::clamp(static_cast<double>(std::clamp(p[ST_PICKUP], 0.02F, 0.5F)) * strLen, 1.0, strLen - 1.0);
        const float out = newSample - tap(pu);
        strFbZ += (out - strFbZ) * 0.05F;   // the feedback path is dull (a loudspeaker far away)
        return out;
    }
};

// ---------------------------------------------------------------------------------------------------------------
// one per Upper
struct EngineBus {
    static constexpr int kWheels = 91;
    static constexpr int kChunk = 256;    // = SamplerEngine::Impl::kRenderChunk (checked where the bus is used)

    double sr{48000.0};
    silveton::sampler::EngineType type{silveton::sampler::EngineType::Off};
    // Polysix chorus / phase / ensemble
    ModEngine mod{};
    silveton::sampler::EffectSlot modCfg{};
    // CX-3: the shared tonewheel generator (SILVETON_ENGINES_V2) - the phases run on, note or no note
    std::array<double, kWheels> twPh{};
    std::array<double, kWheels> twInc{};
    std::array<float, kWheels> twGain{};
    std::array<std::uint8_t, kWheels> twNeed{};
    std::vector<float> twOut;            // kWheels x kChunk, written once per chunk before the voices read it
    int twTuning{-1};
    float twTaper{-1.0F};
    std::uint32_t twFrames{0U};
    // CX-3 scanner and Leslie
    HeapLine vibLine{};
    double vibPhase{0.0};
    HeapLine hornLine{};
    double hornPhase{0.0}, drumPhase{0.0}, hornSpeed{0.0}, drumSpeed{0.0};
    Pole xo1{}, xo2{};
    // EP
    Biquad bass{}, treble{};
    float bassDb{999.0F}, trebleDb{999.0F};
    double tremPhase{0.0};
    Lp2 cabHp{}, cabLp{};
    Biquad cabPeak{};
    bool cabSet{false};
    // SGX strings (combs) with the energy limiter, SGX / STR-1 body (modal resonators)
    struct Res {
        int key{-1};
        std::vector<float> buf;
        int w{0};
        double len{100.0};
        float g{0.0F};
        float lp{0.0F};
        std::uint32_t age{0U};
        float tick(float in, float lpA) noexcept {
            const double rp = static_cast<double>(w) - len;
            const int n = static_cast<int>(buf.size());
            int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            i0 = (i0 % n + n) % n;
            const int i1 = (i0 + 1) % n;
            const float y = buf[static_cast<std::size_t>(i0)] + (buf[static_cast<std::size_t>(i1)] - buf[static_cast<std::size_t>(i0)]) * f;
            lp += (y - lp) * lpA;
            const float s = in + lp * g;
            buf[static_cast<std::size_t>(w)] = s;
            w = (w + 1) % n;
            return lp;
        }
    };
    static constexpr int kHeldRes = 10;
    static constexpr int kDamperRes = 10;
    static constexpr int kBodyModes = 12;
    std::array<Res, kHeldRes> held{};
    std::array<Res, kDamperRes> damper{};
    std::uint32_t resClock{0U};
    float resGainHeld{0.0F}, resGainDamper{0.0F};
    float resEnergy{0.0F}, resLimit{0.0F};
    std::array<Modal, kBodyModes> body{};
    int bodyType{-1};
    float bodyGain{0.0F};
    Biquad lid{};
    float lidDb{999.0F};
    // HD-1
    Biquad boost{};
    float boostDb{999.0F};

    void allocate(double sampleRate) {
        sr = sampleRate;
        mod.allocate(sr);
        vibLine.allocate(static_cast<std::size_t>(0.004 * sr) + 64U);
        hornLine.allocate(static_cast<std::size_t>(0.004 * sr) + 64U);
        const auto resLen = static_cast<std::size_t>(sr / 22.0) + 8U;
        for (auto& r : held) { r.buf.assign(resLen, 0.0F); r.key = -1; }
        for (auto& r : damper) { r.buf.assign(resLen, 0.0F); r.key = -1; }
        twOut.assign(static_cast<std::size_t>(kWheels) * static_cast<std::size_t>(kChunk), 0.0F);
        reset();
    }
    void reset() noexcept {
        mod.reset(); vibLine.clear(); hornLine.clear(); vibPhase = hornPhase = drumPhase = 0.0; hornSpeed = drumSpeed = 0.0;
        xo1 = Pole{}; xo2 = Pole{};
        bass.reset(); treble.reset(); bassDb = trebleDb = 999.0F; tremPhase = 0.0; cabHp.reset(); cabLp.reset(); cabPeak.reset(); cabSet = false;
        for (auto& r : held) { std::fill(r.buf.begin(), r.buf.end(), 0.0F); r.key = -1; r.lp = 0.0F; r.w = 0; }
        for (auto& r : damper) { std::fill(r.buf.begin(), r.buf.end(), 0.0F); r.key = -1; r.lp = 0.0F; r.w = 0; }
        resEnergy = 0.0F;
        for (auto& m : body) m.reset();
        bodyType = -1; bodyGain = 0.0F;
        lid.reset(); lidDb = 999.0F; boost.reset(); boostDb = 999.0F;
        twNeed.fill(0U); twFrames = 0U; twTuning = -1; twTaper = -1.0F;
        type = silveton::sampler::EngineType::Off;
    }

    [[nodiscard]] bool active(const silveton::sampler::EngineParams& e) const noexcept {
        using namespace silveton::sampler;
        switch (e.type) {
            case EngineType::Polysix: return e.p[P6_FX_TYPE] >= 0.5F && e.p[P6_FX_MIX] > 0.0F;
            case EngineType::CX3: return true;
            case EngineType::EP: return true;
            case EngineType::SGX: return true;
            case EngineType::Str1: return e.p[ST_BODY] > 0.0F;
            case EngineType::HD1: return e.p[HD_BOOST] > 0.05F;
            default: return false;
        }
    }

    static double keyHz(int key) noexcept { return 440.0 * std::pow(2.0, (key - 69) / 12.0); }

    // SILVETON_ENGINES_V2: the 91 wheels - equal temperament, or the gear ratios of the B-3 (a 20 Hz shaft, tonewheels of
    // 2..128 teeth; the top seven wheels have 192 teeth and the ratios of a fifth below, so the top is a little out)
    void setWheels(int tuning, float taper) noexcept {
        if (tuning == twTuning && taper == twTaper) return;
        twTuning = tuning; twTaper = taper;
        static const double ratios[12] = {85.0 / 104.0, 71.0 / 82.0, 67.0 / 73.0, 105.0 / 108.0, 103.0 / 100.0, 84.0 / 77.0,
                                          74.0 / 64.0, 98.0 / 80.0, 96.0 / 74.0, 88.0 / 64.0, 67.0 / 46.0, 108.0 / 70.0};
        for (int w = 0; w < kWheels; ++w) {
            double f;
            if (tuning == 0) f = 32.703195662 * std::pow(2.0, static_cast<double>(w) / 12.0);
            else if (w < 84) f = 20.0 * static_cast<double>(2 << (w / 12)) * ratios[w % 12];
            else f = 20.0 * 192.0 * ratios[(w % 12 + 5) % 12];
            twInc[static_cast<std::size_t>(w)] = f / sr;
            // the generator's output tapers towards the top (the real resistor network)
            twGain[static_cast<std::size_t>(w)] = 1.0F - 0.7F * taper * std::clamp((static_cast<float>(f) - 1000.0F) / 5000.0F, 0.0F, 1.0F);
        }
    }
    void needWheels(const EngineVoice& v) noexcept {
        for (const int w : v.twWheel) if (w >= 0 && w < kWheels) { twNeed[static_cast<std::size_t>(w)] = 1U; }
        if (v.percWheel >= 0 && v.percWheel < kWheels) twNeed[static_cast<std::size_t>(v.percWheel)] = 1U;
        const int w8 = v.twWheel[2];   // the leakage: the neighbours of the 8' wheel
        if (w8 > 0) twNeed[static_cast<std::size_t>(w8 - 1)] = 1U;
        if (w8 >= 0 && w8 + 1 < kWheels) twNeed[static_cast<std::size_t>(w8 + 1)] = 1U;
    }
    // once per chunk, before the voices render: the needed wheels for `frames` samples; every phase moves on
    // pitchMul: the pitch bend of the Upper (SILVETON_ENGINES_V2) - every wheel turns faster / slower together, its phase runs on
    void prepareWheels(std::uint32_t frames, double pitchMul = 1.0) noexcept {
        if (twOut.empty()) return;
        frames = std::min(frames, static_cast<std::uint32_t>(kChunk));
        twFrames = frames;
        pitchMul = std::clamp(pitchMul, 0.0625, 16.0);
        for (int w = 0; w < kWheels; ++w) {
            const auto ww = static_cast<std::size_t>(w);
            const double inc = std::min(twInc[ww] * pitchMul, 0.45);
            if (twNeed[ww] != 0U) {
                float* out = twOut.data() + ww * static_cast<std::size_t>(kChunk);
                const double ph0 = twPh[ww];
                const float g = twGain[ww];
                for (std::uint32_t i = 0U; i < frames; ++i) out[i] = sin01(ph0 + inc * static_cast<double>(i)) * g;
            }
            twPh[ww] += inc * static_cast<double>(frames);
            twPh[ww] -= std::floor(twPh[ww]);
            twNeed[ww] = 0U;
        }
    }
    [[nodiscard]] float wheel(int w, std::uint32_t frame) const noexcept {
        if (w < 0 || w >= kWheels || frame >= twFrames || twOut.empty()) return 0.0F;
        return twOut[static_cast<std::size_t>(w) * static_cast<std::size_t>(kChunk) + frame];
    }

    void setBody(int kind, double scale, float gain) noexcept {
        // the modes of a soundboard / box, in Hz, and how long each rings (s)
        static const double grand[kBodyModes] = {52, 78, 112, 146, 188, 236, 292, 360, 446, 560, 700, 880};
        static const double guitar[kBodyModes] = {98, 196, 240, 318, 410, 520, 650, 790, 950, 1150, 1400, 1700};
        static const double violin[kBodyModes] = {275, 440, 540, 700, 880, 1050, 1250, 1500, 1800, 2200, 2700, 3300};
        static const double cello[kBodyModes] = {92, 150, 196, 250, 330, 420, 520, 650, 800, 1000, 1250, 1600};
        static const double harp[kBodyModes] = {62, 120, 180, 250, 330, 420, 520, 640, 800, 1000, 1250, 1600};
        const double* f = kind == 1 ? guitar : (kind == 2 ? violin : (kind == 3 ? cello : (kind == 4 ? harp : grand)));
        for (int i = 0; i < kBodyModes; ++i) {
            const auto ii = static_cast<std::size_t>(i);
            const double hz = f[i] * scale;
            const double tau = (kind == 0 ? 0.35 : 0.12) * std::pow(0.8, static_cast<double>(i) * 0.5);
            body[ii].set(sr, hz, tau, 0.9F / static_cast<float>(kBodyModes) * (1.0F - 0.04F * static_cast<float>(i)));
        }
        bodyType = kind; bodyGain = gain;
    }
    float bodyTick(float x) noexcept {
        float y = 0.0F;
        for (auto& m : body) y += m.tick(x);
        return y;
    }

    // once per block. heldKeys: the keys of this Upper that are down now (SGX); sustain / wheel of the Upper's channel.
    void block(const silveton::sampler::EngineParams& e, std::uint32_t frames, float wheel, bool sustain, const std::array<bool, 128>& heldKeys) noexcept {
        using namespace silveton::sampler;
        if (e.type != type) { reset(); type = e.type; }
        const float* p = e.p.data();
        (void)frames;
        switch (e.type) {
            case EngineType::Polysix: {
                const int t = static_cast<int>(std::lround(p[P6_FX_TYPE]));
                modCfg.type = t == 1 ? EffectType::Chorus : (t == 2 ? EffectType::Phaser : (t == 3 ? EffectType::Ensemble : EffectType::Off));
                modCfg.rateHz = std::clamp(p[P6_FX_SPEED], 0.1F, 5.0F);
                modCfg.depth = std::clamp(p[P6_FX_DEPTH], 0.0F, 1.0F);
                modCfg.feedback = t == 2 ? 0.35F : 0.0F;
                modCfg.param1 = t == 1 ? 3.0F : 6.0F;
                break;
            }
            case EngineType::EP: {
                if (p[EP_BASS] != bassDb) { bassDb = p[EP_BASS]; bass.setShelf(sr, 110.0F, std::clamp(bassDb, -12.0F, 12.0F), false); }
                if (p[EP_TREBLE] != trebleDb) { trebleDb = p[EP_TREBLE]; treble.setShelf(sr, 3200.0F, std::clamp(trebleDb, -12.0F, 12.0F), true); }
                if (!cabSet) { cabHp.set(sr, 85.0, true); cabLp.set(sr, 5200.0, false); cabPeak.setPeaking(sr, 420.0F, 0.8F, 2.5F); cabSet = true; }
                break;
            }
            case EngineType::SGX: {
                const float lidV = std::clamp(p[SG_LID], 0.0F, 1.0F);
                const float ld = -(1.0F - lidV) * 7.0F;
                if (ld != lidDb) { lidDb = ld; lid.setShelf(sr, 2400.0F, ld, true); }
                const float relSec = std::clamp(p[SG_RES_RELEASE], 0.1F, 5.0F);
                resGainHeld = std::clamp(p[SG_STRING_RES], 0.0F, 1.0F) * 0.25F;
                resGainDamper = sustain ? std::clamp(p[SG_DAMPER_RES], 0.0F, 1.0F) * 0.18F : 0.0F;
                resLimit = std::clamp(p[SG_SYMP_LIMIT], 0.0F, 1.0F) * 40.0F;
                const int bt = static_cast<int>(std::lround(p[SG_BODY_TYPE]));
                const float bg = std::clamp(p[SG_BODY], 0.0F, 1.0F) * 0.5F;
                if (bt != bodyType || bg != bodyGain) setBody(0, bt == 1 ? 1.3 : (bt == 2 ? 1.75 : 1.0), bg), bodyType = bt;
                // the held keys own a resonator each (the oldest one is given up when all are taken)
                ++resClock;
                for (auto& r : held) if (r.key >= 0 && !heldKeys[static_cast<std::size_t>(r.key)]) r.key = -1;   // the key went up: the line rings out and is free
                for (int k = 0; k < 128; ++k) {
                    if (!heldKeys[static_cast<std::size_t>(k)]) continue;
                    bool have = false;
                    for (const auto& r : held) if (r.key == k) { have = true; break; }
                    if (have) continue;
                    Res* slot = nullptr;
                    for (auto& r : held) if (r.key < 0) { if (slot == nullptr || r.age < slot->age) slot = &r; }
                    if (slot == nullptr) { for (auto& r : held) if (slot == nullptr || r.age < slot->age) slot = &r; }
                    if (slot == nullptr) break;
                    slot->key = k; slot->age = resClock;
                    const double hz = keyHz(k);
                    slot->len = std::clamp(sr / std::max(22.0, hz) - 1.0, 2.0, static_cast<double>(slot->buf.size() - 3U));
                    slot->g = std::min(0.998F, std::exp(-6.9F * static_cast<float>(slot->len / sr) / relSec));
                }
                for (auto& r : held) if (r.key < 0 && r.g > 0.0F) r.g = std::min(r.g, std::exp(-6.9F * static_cast<float>(r.len / sr) / relSec));
                if (damper[0].key < 0) {   // the undamped low strings: A1 .. F#4 every three semitones
                    for (int i = 0; i < kDamperRes; ++i) {
                        auto& r = damper[static_cast<std::size_t>(i)];
                        r.key = 33 + i * 3;
                        r.len = std::clamp(sr / keyHz(r.key) - 1.0, 2.0, static_cast<double>(r.buf.size() - 3U));
                    }
                }
                for (auto& r : damper) r.g = std::min(0.998F, std::exp(-6.9F * static_cast<float>(r.len / sr) / (relSec * 1.5F)));
                break;
            }
            case EngineType::Str1: {
                const int bt = static_cast<int>(std::lround(p[ST_BODY_TYPE]));
                const float bg = std::clamp(p[ST_BODY], 0.0F, 1.0F) * 0.6F;
                const int kind = bt + 1;   // 1 guitar 2 violin 3 cello 4 harp
                if (kind != bodyType || bg != bodyGain) setBody(kind, 1.0, bg);
                break;
            }
            case EngineType::HD1: {
                if (p[HD_BOOST] != boostDb) { boostDb = p[HD_BOOST]; boost.setShelf(sr, 110.0F, std::clamp(boostDb, 0.0F, 12.0F), false); }
                break;
            }
            case EngineType::CX3: {
                (void)wheel;
                setWheels(p[CX_TUNING] >= 0.5F ? 1 : 0, std::clamp(p[CX_TAPER], 0.0F, 1.0F));
                break;
            }
            default: break;
        }
        for (auto& m : body) m.guard();
    }

    void process(const silveton::sampler::EngineParams& e, float& l, float& r, float wheel) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (e.type) {
            case EngineType::Polysix: {
                if (modCfg.type == EffectType::Off) return;
                float wl = 0.0F, wr = 0.0F;
                mod.process(l, r, modCfg, wl, wr);
                const float mix = std::clamp(p[P6_FX_MIX], 0.0F, 1.0F);
                l += (wl - l) * mix; r += (wr - r) * mix;
                break;
            }
            case EngineType::HD1:
                if (boostDb > 0.05F) boost.process(l, r);
                break;
            case EngineType::Str1: {
                if (bodyGain > 0.0F) { const float b = bodyTick(0.5F * (l + r)) * bodyGain; l += b; r += b; }
                break;
            }
            case EngineType::CX3: {
                // scanner vibrato / chorus
                const int vc = static_cast<int>(std::lround(p[CX_VIBCHO]));
                if (vc > 0) {
                    vibLine.push(l, r);
                    const int depthIx = (vc + 1) / 2;   // 1 = V1/C1, 2 = V2/C2, 3 = V3/C3
                    const double depth = sr * 0.00032 * depthIx;
                    vibPhase += 6.9 / sr; vibPhase -= std::floor(vibPhase);
                    const double tri = 1.0 - 4.0 * std::abs(vibPhase - 0.5);
                    const double d = sr * 0.0004 + depth * (0.5 + 0.5 * tri);
                    const float wl = vibLine.tapHL(d), wr = vibLine.tapHR(d);
                    const bool chorus = (vc % 2) == 0;
                    if (chorus) { l = 0.5F * (l + wl); r = 0.5F * (r + wr); } else { l = wl; r = wr; }
                }
                // the amplifier
                const float drive = std::clamp(p[CX_AMP_DRIVE], 0.0F, 1.0F);
                if (drive > 0.0F) {
                    const float g = 1.0F + 6.0F * drive;
                    l = tanhT(l * g) / std::sqrt(g) * (1.0F + 0.3F * drive); r = tanhT(r * g) / std::sqrt(g) * (1.0F + 0.3F * drive);
                }
                // Leslie: the horn and the drum, each with its own speeds and inertia (SILVETON_ENGINES_V2)
                const int rot = static_cast<int>(std::lround(p[CX_ROTARY]));
                if (rot > 0) {
                    const bool fast = rot == 2 || (p[CX_WHEEL_ROT] >= 0.5F && wheel >= 0.5F);
                    const double hornWant = fast ? std::clamp(static_cast<double>(p[CX_FAST]), 4.0, 9.0) : std::clamp(static_cast<double>(p[CX_SLOW]), 0.3, 1.5);
                    const double drumWant = fast ? std::clamp(static_cast<double>(p[CX_DRUM_FAST]), 3.0, 8.0) : std::clamp(static_cast<double>(p[CX_DRUM_SLOW]), 0.2, 1.5);
                    const double hornAcc = std::clamp(static_cast<double>(p[CX_HORN_ACCEL]), 0.2, 5.0);
                    const double drumAcc = std::clamp(static_cast<double>(p[CX_DRUM_ACCEL]), 0.5, 10.0);
                    const double hornTau = hornWant > hornSpeed ? hornAcc : hornAcc * 1.7;
                    const double drumTau = drumWant > drumSpeed ? drumAcc : drumAcc * 1.4;
                    hornSpeed += (hornWant - hornSpeed) * (1.0 - std::exp(-1.0 / (hornTau * sr)));
                    drumSpeed += (drumWant - drumSpeed) * (1.0 - std::exp(-1.0 / (drumTau * sr)));
                    hornPhase += hornSpeed / sr; hornPhase -= std::floor(hornPhase);
                    drumPhase += drumSpeed / sr; drumPhase -= std::floor(drumPhase);
                    const float mono = 0.5F * (l + r);
                    const float k = onePoleCoef(800.0, sr);
                    const float lo = xo2.lp(xo1.lp(mono, k), k);
                    const float hi = mono - lo;
                    hornLine.push(hi, hi);
                    const float mic = std::clamp(p[CX_MIC_DIST], 0.0F, 1.0F);   // close microphones: deep amplitude swing and Doppler
                    const double base = sr * 0.0006;
                    const double dop = sr * (0.0002 + 0.0005 * static_cast<double>(1.0F - mic));
                    const float swing = 0.25F + 0.5F * (1.0F - mic);
                    const float sA = sin01(hornPhase), sB = sin01(hornPhase + 0.5);
                    const float hl = hornLine.tapHL(base + dop * (1.0 + sA)) * (1.0F - swing + swing * sA);
                    const float hr = hornLine.tapHR(base + dop * (1.0 + sB)) * (1.0F - swing + swing * sB);
                    const float dsw = 0.12F + 0.25F * (1.0F - mic);
                    const float dl = lo * (1.0F - dsw + dsw * sin01(drumPhase));
                    const float dr = lo * (1.0F - dsw + dsw * sin01(drumPhase + 0.4));
                    const float bal = std::clamp(p[CX_HORN], 0.0F, 1.0F);
                    const float hg = 2.0F * bal, dg = 2.0F * (1.0F - bal);
                    l = hl * hg + dl * dg; r = hr * hg + dr * dg;
                }
                break;
            }
            case EngineType::EP: {
                const float drive = std::clamp(p[EP_PRE_DRIVE], 0.0F, 1.0F);
                if (drive > 0.0F) { const float g = 1.0F + 5.0F * drive; l = tanhT(l * g) / std::sqrt(g); r = tanhT(r * g) / std::sqrt(g); }
                if (bassDb != 0.0F) bass.process(l, r);
                if (trebleDb != 0.0F) treble.process(l, r);
                if (p[EP_TREM] >= 0.5F) {
                    tremPhase += std::clamp(static_cast<double>(p[EP_TREM_SPEED]), 0.5, 12.0) / sr; tremPhase -= std::floor(tremPhase);
                    const float d = std::clamp(p[EP_TREM_DEPTH], 0.0F, 1.0F);
                    const bool reed = p[EP_TYPE] >= 0.5F;
                    const float st = reed ? 0.0F : std::clamp(p[EP_TREM_STEREO], 0.0F, 1.0F);
                    const float gl = 1.0F - d * (0.5F - 0.5F * sin01(tremPhase));
                    const float gr = 1.0F - d * (0.5F - 0.5F * sin01(tremPhase + 0.5 * st));
                    l *= gl; r *= gr;
                }
                if (p[EP_CAB] >= 0.5F && cabSet) {
                    const float cd = std::clamp(p[EP_CAB_DRIVE], 0.0F, 1.0F);
                    if (cd > 0.0F) { const float g = 1.0F + 4.0F * cd; l = tanhT(l * g) / std::sqrt(g); r = tanhT(r * g) / std::sqrt(g); }
                    cabHp.process(l, r); cabPeak.process(l, r); cabLp.process(l, r);
                }
                break;
            }
            case EngineType::SGX: {
                const float in = 0.5F * (l + r);
                // the energy limit: the strings take less when they already carry a lot (the acoustic coupling is bounded)
                const float limitG = 1.0F / (1.0F + resLimit * resEnergy);
                float res = 0.0F;
                if (resGainHeld > 0.0F) {
                    for (auto& rr : held) if (rr.key >= 0 || std::fabs(rr.lp) > 1.0e-6F) res += rr.tick(rr.key >= 0 ? in * resGainHeld * limitG : 0.0F, 0.35F);
                }
                if (resGainDamper > 0.0F || damper[0].lp != 0.0F) {
                    for (auto& rr : damper) res += rr.tick(in * resGainDamper * limitG, 0.3F);
                }
                resEnergy += (res * res - resEnergy) * 0.0005F;
                if (!finite(resEnergy)) resEnergy = 0.0F;
                l += res * 0.5F; r += res * 0.5F;
                if (bodyGain > 0.0F) { const float b = bodyTick(0.5F * (l + r)) * bodyGain; l += b; r += b; }
                if (lidDb < -0.05F) lid.process(l, r);
                break;
            }
            default: break;
        }
    }
};

// -------------------------------------------------------------- the per-sample part of a voice, after the recording was read
inline void EngineVoice::post(const silveton::sampler::EngineParams& e, float& l, float& r, double inc, double sr, std::uint32_t frame, const EngineBus& bus) noexcept {
    using namespace silveton::sampler;
    const float* p = e.p.data();
    switch (type) {
        case EngineType::MS20: {
            // the two VCOs next to the recording
            const int w1 = static_cast<int>(std::lround(p[MS_VCO1_WAVE]));
            const int w2 = static_cast<int>(std::lround(p[MS_VCO2_WAVE]));
            const float rec = std::clamp(p[MS_REC_LEVEL], 0.0F, 1.0F);
            if (rec != 1.0F) { l *= rec; r *= rec; }
            // ESP: the envelope of the recording (what the external signal processor would follow)
            {
                const float a = std::fabs(0.5F * (l + r));
                espEnv += (a - espEnv) * (a > espEnv ? 0.02F : 0.0005F);
            }
            if (w1 > 0 || w2 > 0) {
                float o1 = 0.0F, o2 = 0.0F, y1 = 0.0F;
                if (w1 > 0) {
                    if (w1 == 4) y1 = noise(rng) * 0.5F;
                    else y1 = osc1.step(w1 == 1 ? 3 : (w1 == 2 ? 1 : 2), inc, pwNow);
                    o1 = osc1.out(y1) * std::clamp(p[MS_VCO1_LEVEL], 0.0F, 1.0F);
                }
                if (w2 > 0) {
                    const double inc2 = inc * std::exp2(static_cast<double>(std::clamp(p[MS_VCO2_PITCH], -24.0F, 24.0F)) / 12.0);
                    float y2;
                    if (w2 == 4) { y2 = osc2.step(2, inc2, 0.5F); y2 *= y1; }          // ring: VCO1 x a square VCO2
                    else y2 = osc2.step(w2 == 1 ? 1 : 2, inc2, w2 == 2 ? 0.5F : pwNow);
                    o2 = osc2.out(y2) * std::clamp(p[MS_VCO2_LEVEL], 0.0F, 1.0F);
                }
                const float s = (o1 + o2) * 0.6F;
                l += s; r += s;
            }
            if (hpfOn) {
                if (msParallel) { msHpL = l; msHpR = r; hpf.process(msHpL, msHpR); }
                else hpf.process(l, r);
            }
            break;
        }
        case EngineType::Polysix: {
            const int osc = static_cast<int>(std::lround(p[P6_OSC]));
            const float rec = std::clamp(p[P6_REC_LEVEL], 0.0F, 1.0F);
            if (rec != 1.0F) { l *= rec; r *= rec; }
            if (osc > 0) {
                float y;
                if (osc == 4) { y = 0.5F * (osc1.step(1, inc, pwNow) + osc2.step(2, inc, pwNow)); }
                else y = osc1.step(osc == 1 ? 1 : 2, inc, pwNow);
                float o = osc1.out(y) * std::clamp(p[P6_OSC_LEVEL], 0.0F, 1.0F) * 0.6F;
                if (p[P6_SUB_WAVE] >= 0.5F && p[P6_SUB_LEVEL] > 0.0F) {   // the square sub-oscillator
                    const double div = p[P6_SUB_OCT] >= 1.5F ? 0.25 : 0.5;
                    o += osc3.out(osc3.step(2, inc * div, 0.5F)) * std::clamp(p[P6_SUB_LEVEL], 0.0F, 1.0F) * 0.5F;
                }
                l += o; r += o;
            }
            break;
        }
        case EngineType::AL1: {
            const float rec = std::clamp(p[AL_REC_LEVEL], 0.0F, 1.0F);
            if (rec != 1.0F) { l *= rec; r *= rec; }
            const float ring = std::clamp(p[AL_RING_LEVEL], 0.0F, 1.0F);
            if (ring > 0.0F) {
                ringPhase += inc * static_cast<double>(p[AL_RING_RATIO]);
                const float m = 1.0F - ring + ring * sin01(ringPhase);
                l *= m; r *= m;
            }
            // the two band-limited oscillators: 2 may be synced to 1, 2 may modulate the frequency of 1 (never below zero), 1 x 2 ring
            const int w1 = static_cast<int>(std::lround(p[AL_OSC1_WAVE]));
            const int w2 = static_cast<int>(std::lround(p[AL_OSC2_WAVE]));
            if (w1 > 0 || w2 > 0) {
                const double inc2 = inc * std::exp2((static_cast<double>(std::clamp(p[AL_OSC2_SEMI], -24.0F, 24.0F)) + static_cast<double>(std::clamp(p[AL_OSC2_FINE], -100.0F, 100.0F)) / 100.0) / 12.0);
                float y2 = 0.0F;
                if (w2 > 0) y2 = osc2.step(w2, inc2, pwNow);
                const float fm = std::clamp(p[AL_OSC_FM], 0.0F, 2.0F);
                const double inc1 = fm > 0.0F ? std::max(inc * (1.0 + static_cast<double>(fm) * static_cast<double>(osc2.dly)), 0.0) : inc;   // frequency modulation, the frequency never turns negative
                float y1 = 0.0F;
                if (w1 > 0) y1 = osc1.step(w1, inc1, pwNow);
                if (w2 > 0 && w1 > 0 && p[AL_OSC_SYNC] >= 0.5F && osc1.wrapped) osc2.sync(w2, inc2, pwNow, osc1.wrapD, y2);
                const float o1 = w1 > 0 ? osc1.out(y1) : 0.0F;
                const float o2 = w2 > 0 ? osc2.out(y2) : 0.0F;
                float s = o1 * std::clamp(p[AL_OSC1_LEVEL], 0.0F, 1.0F) + o2 * std::clamp(p[AL_OSC2_LEVEL], 0.0F, 1.0F);
                const float rg = std::clamp(p[AL_OSC_RING], 0.0F, 1.0F);
                if (rg > 0.0F) s += o1 * o2 * rg;
                s *= 0.6F;
                l += s; r += s;
            }
            const float nl = std::clamp(p[AL_NOISE_LEVEL], 0.0F, 1.0F);
            if (nl > 0.0F) {
                const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::clamp(p[AL_NOISE_COLOR], 100.0F, 20000.0F) / static_cast<float>(sr));
                const float n = noiseLp.lp(noise(rng), a) * nl * 0.5F;
                l += n; r += n;
            }
            const float sh = std::clamp(p[AL_SHAPE], 0.0F, 1.0F);
            if (sh > 0.0F) { l = softFold(l, sh); r = softFold(r, sh); }
            break;
        }
        case EngineType::Mod7: {
            const float pcm = std::clamp(p[M7_PCM_LEVEL], 0.0F, 1.0F);
            if (pcm != 1.0F) { l *= pcm; r *= pcm; }
            const float ring = std::clamp(p[M7_RING], 0.0F, 1.0F);
            if (ring > 0.0F) { const float m = 1.0F - ring + ring * ringNow; l *= m; r *= m; }
            if (carrierSum != 0.0F) { l += carrierSum; r += carrierSum; }
            const int ws = static_cast<int>(std::lround(p[M7_WS_TYPE]));
            if (ws > 0) {
                const float d = std::clamp(p[M7_WS_DRIVE], 0.0F, 1.0F);
                const float mix = std::clamp(p[M7_WS_MIX], 0.0F, 1.0F);
                const float g = 1.0F + 9.0F * d;
                const auto shape = [&](float x) noexcept {
                    switch (ws) {
                        case 1: return tanhT(x * g) / tanhT(g);
                        case 2: return std::clamp(x * g, -1.0F, 1.0F) * (1.0F / std::min(g, 4.0F));
                        case 3: return softFold(x, d);
                        default: return sin01(static_cast<double>(x * g) * 0.25);
                    }
                };
                l += (shape(l) - l) * mix; r += (shape(r) - r) * mix;
            }
            break;
        }
        case EngineType::Str1: {
            const float in = 0.5F * (l + r);
            const float out = stringTick(e, in, sr, inc);
            const float sl = std::clamp(p[ST_STRING], 0.0F, 1.0F), ex = std::clamp(p[ST_EXCITE], 0.0F, 1.0F);
            l = out * sl + l * ex; r = out * sl + r * ex;
            break;
        }
        case EngineType::CX3: {
            // the shared wheels of the Upper (the bus computed this chunk's samples before the voices started)
            float organ = 0.0F;
            for (int k = 0; k < 9; ++k) {
                const auto i = static_cast<std::size_t>(k);
                const float lev = twLevel[i];
                if (lev <= 0.0F) continue;
                organ += bus.wheel(twWheel[i], frame) * lev;
            }
            if (percEnv > 0.0F) {
                organ += bus.wheel(percWheel, frame) * percEnv * percGain * 0.8F;
                percEnv *= percCoef; if (percEnv < 1.0e-4F) percEnv = 0.0F;
            }
            if (leakLevel > 0.0F) {   // the neighbours of the 8' wheel leak in
                const int w8 = twWheel[2];
                organ += (bus.wheel(w8 - 1, frame) + bus.wheel(w8 + 1, frame)) * leakLevel;
            }
            if (clickEnv > 0.0F) {
                organ += clickLp.lp(noise(rng), 0.35F) * clickEnv * 0.6F;
                clickEnv *= clickCoef; if (clickEnv < 1.0e-4F) clickEnv = 0.0F;
            }
            if (keyOffEnv > 0.0F) {   // the key-off click
                organ += clickLp.lp(noise(rng), 0.35F) * keyOffEnv * std::clamp(p[CX_CLICK], 0.0F, 1.0F) * 0.4F;
                keyOffEnv *= clickCoef > 0.0F ? clickCoef : 0.9F; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
            }
            organ *= 0.35F;
            const float smp = std::clamp(p[CX_SAMPLE], 0.0F, 1.0F);
            l = organ + l * smp; r = organ + r * smp;
            break;
        }
        case EngineType::SGX: {
            if (brightA < 0.999F) { l = brightL.lp(l, brightA); r = brightR.lp(r, brightA); }
            if (hammerEnv > 0.0F) {
                const float n = noise(rng) * hammerEnv * 0.5F;
                l += n; r += n;
                hammerEnv *= hammerCoef; if (hammerEnv < 1.0e-4F) hammerEnv = 0.0F;
            }
            if (keyOffEnv > 0.0F) {
                float n = noise(rng), n2 = n;
                keyOffBp.process(n, n2, FilterMode::BandPass, std::clamp(p[SG_KEYOFF_TONE], 200.0F, 8000.0F), 0.5F, sr);
                const float g = keyOffEnv * std::clamp(p[SG_KEYOFF], 0.0F, 1.0F) * 0.5F;
                l += n * g; r += n2 * g;
                keyOffEnv *= keyOffCoef; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
            }
            break;
        }
        case EngineType::EP: {
            const float rec = std::clamp(p[EP_REC_LEVEL], 0.0F, 1.0F);
            if (rec != 1.0F) { l *= rec; r *= rec; }
            const float gen = std::clamp(p[EP_MODEL], 0.0F, 1.0F);
            if (gen > 0.0F) {   // the tine / reed model: three damped partials, struck by a short burst, through the pickup
                // SILVETON_ENGINES_V2: pitch bend / glide retune the three modes (their decay and level stay)
                if (inc > 1.0e-7 && tineInc > 0.0 && std::fabs(inc - tineInc) > tineInc * 1.0e-4) {
                    tineInc = inc;
                    for (std::size_t k = 0; k < tine.size(); ++k) {
                        const double w = 2.0 * kPi * std::min(inc * tineRatio[k], 0.45);
                        tine[k].a1 = static_cast<float>(2.0 * std::sqrt(std::max(0.0, -static_cast<double>(tine[k].a2))) * std::cos(w));
                    }
                }
                float x = 0.0F;
                if (tineHit > 0) { x = tineLp.lp(tineExc, tineLpA); --tineHit; }
                else if (tineLp.z > 1.0e-6F) x = tineLp.lp(0.0F, tineLpA);
                float t = 0.0F;
                for (auto& m : tine) t += m.tick(x);
                // the pickup: a saturating, slightly one-sided curve (even harmonics), louder with the hit
                const float d = 1.0F + 6.0F * std::clamp(p[EP_PICKUP_DRIVE], 0.0F, 1.0F);
                const float bias = 0.4F * std::clamp(p[EP_PICKUP_SYM], 0.0F, 1.0F);
                const float y = (tanhT(d * (t + bias)) - tanhT(d * bias)) / d;
                const float s = y * gen * 1.6F;
                l += s; r += s;
            }
            if (bellGain > 0.0F) {   // the bell: the part above ~2 kHz, louder with the hit
                const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * 2000.0F / static_cast<float>(sr));
                l += (l - bellL.lp(l, a)) * bellGain; r += (r - bellR.lp(r, a)) * bellGain;
            }
            if (barkDrive > 0.0F) {
                const float g = 1.0F + barkDrive;
                l = tanhT(l * g) / std::sqrt(g); r = tanhT(r * g) / std::sqrt(g);
            }
            if (keyOffEnv > 0.0F) {
                float n = noise(rng), n2 = n;
                keyOffBp.process(n, n2, FilterMode::BandPass, 3000.0F, 0.4F, sr);
                const float g = keyOffEnv * std::clamp(p[EP_KEYOFF], 0.0F, 1.0F) * 0.3F;
                l += n * g; r += n2 * g;
                keyOffEnv *= keyOffCoef; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
            }
            break;
        }
        default: break;
    }
}

} // namespace eng
