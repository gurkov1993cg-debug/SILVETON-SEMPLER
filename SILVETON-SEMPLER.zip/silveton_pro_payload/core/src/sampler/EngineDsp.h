// SILVETON_ENGINES_V1 / V2 - the sound of the nine engines (see include/silveton/sampler/EngineDefs.h).
// Included by SamplerEngine.cpp inside its file-local namespace, after the filters, ModEngine, Biquad and HeapLine:
// it uses them. Two parts:
//   eng::EngineVoice - lives in every voice: the per-note part of an engine - the band-limited oscillators (AL-1,
//                      POLYSIX, MS-20), the six FM operators of MOD-7, the STR-1 string with its pluck, the CX-3 tonewheel
//                      sum / percussion / click, the EP tine model and pickup, the SGX half pedal and noises, the main
//                      filter models (ladder, Korg35 LP / HP, state variable), the filter envelope, the LFO, the MS-20
//                      EG1 / ESP / S&H / patch panel.
//   eng::EngineBus   - one per Upper: the 91 shared tonewheels of CX-3 (continuous phase, computed once per chunk before
//                      the voices read them), and after the sum of the Upper: Polysix chorus / phase / ensemble, the CX-3
//                      scanner and Leslie (horn and drum apart), the EP preamp / tremolo / cabinet, the SGX strings
//                      (energy-limited) and body, the STR-1 body, the HD-1 low boost.
// Everything here is our own model of the original instruments. Nothing allocates, locks or blocks on the audio thread:
// the only buffers (EngineBus::allocate) are made when the sampler is prepared.
#pragma once

#include "silveton/sampler/EngineDefs.h"
#include "silveton/sampler/UserWaves.h"   // SILVETON_USER_WAVES_V1 (the including file includes it first, outside its namespaces)

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <vector>

namespace eng {

constexpr int kSineBits = 12;
constexpr int kSineSize = 1 << kSineBits;

inline const float* sineTable() noexcept {
    static const std::array<float, kSineSize + 1> table = [] {
        std::array<float, kSineSize + 1> t{};
        for (int i = 0; i <= kSineSize; ++i) t[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(2.0 * kPi * static_cast<double>(i) / kSineSize));
        return t;
    }();
    return table.data();
}

// sine of a phase given in cycles (any value)
inline float sin01(double cycles) noexcept {
    cycles -= std::floor(cycles);
    const double x = cycles * kSineSize;
    const int i = static_cast<int>(x);
    const float f = static_cast<float>(x - static_cast<double>(i));
    const float* t = sineTable();
    const auto k = static_cast<std::size_t>(std::min(i, kSineSize - 1));
    return t[k] + (t[k + 1U] - t[k]) * f;
}

inline float wrap01(double& ph) noexcept { ph -= std::floor(ph); return static_cast<float>(ph); }

inline float noise(std::uint32_t& s) noexcept {
    s = s * 1664525U + 1013904223U;
    return static_cast<float>(s >> 8) / 8388608.0F - 1.0F;
}

inline float softFold(float x, float amount) noexcept {
    if (amount <= 0.0F) return x;
    const float g = 1.0F + 4.0F * amount;
    float y = x * g;
    // triangle fold between -1 and 1
    y = std::fabs(std::fmod(y + 1.0F, 4.0F));
    if (y > 2.0F) y = 4.0F - y;
    return (y - 1.0F) * (1.0F - 0.55F * amount);
}

// SILVETON_ENGINES_V2: tanh from a table (4097 points over -8..8, linear between them; the largest error against
// std::tanh is below 2e-5, checked by the engine test). The filters and pickups call it many times per sample.
constexpr int kTanhPoints = 4096;
constexpr float kTanhRange = 8.0F;
inline const float* tanhTable() noexcept {
    static const std::array<float, kTanhPoints + 2> table = [] {
        std::array<float, kTanhPoints + 2> t{};
        for (int i = 0; i <= kTanhPoints + 1; ++i) {
            const double x = -static_cast<double>(kTanhRange) + 2.0 * kTanhRange * static_cast<double>(i) / kTanhPoints;
            t[static_cast<std::size_t>(i)] = static_cast<float>(std::tanh(x));
        }
        return t;
    }();
    return table.data();
}
inline float tanhT(float x) noexcept {
    if (x >= kTanhRange) return 1.0F;
    if (x <= -kTanhRange) return -1.0F;
    const float u = (x + kTanhRange) * (static_cast<float>(kTanhPoints) / (2.0F * kTanhRange));
    const int i = static_cast<int>(u);
    const float f = u - static_cast<float>(i);
    const float* t = tanhTable();
    const auto k = static_cast<std::size_t>(std::min(i, kTanhPoints));
    return t[k] + (t[k + 1U] - t[k]) * f;
}

inline bool finite(float x) noexcept { return std::isfinite(x) && std::fabs(x) < 1.0e6F; }
inline void flush(float& x) noexcept { if (std::fabs(x) < 1.0e-18F) x = 0.0F; }

// Per-block ADSR: linear attack, exponential decay / release. dt = seconds per step.
struct Adsr {
    int stage{0};   // 0 idle 1 attack 2 decay 3 sustain 4 release
    float v{0.0F};
    void on() noexcept { stage = 1; }
    void off() noexcept { if (stage != 0) stage = 4; }
    float step(float aMs, float dMs, float s, float rMs, float dt) noexcept {
        s = std::clamp(s, 0.0F, 1.0F);
        switch (stage) {
            case 1: v += dt * 1000.0F / std::max(aMs, 0.1F); if (v >= 1.0F) { v = 1.0F; stage = 2; } break;
            case 2: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(dMs, 1.0F)); v += (s - v) * k; if (std::fabs(v - s) < 0.001F) { v = s; stage = 3; } } break;
            case 3: v = s; break;
            case 4: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(rMs, 1.0F)); v -= v * k; if (v < 0.0005F) { v = 0.0F; stage = 0; } } break;
            default: v = 0.0F; break;
        }
        return v;
    }
};

// MS-20 EG1: delay, attack, then held at 1 while the key is down, release when it goes up.
struct Dar {
    int stage{0};   // 0 idle 1 delay 2 attack 3 hold 4 release
    float v{0.0F};
    float t{0.0F};
    void on() noexcept { stage = 1; t = 0.0F; v = 0.0F; }
    void off() noexcept { if (stage != 0) stage = 4; }
    float step(float delayMs, float aMs, float rMs, float dt) noexcept {
        switch (stage) {
            case 1: t += dt * 1000.0F; if (t >= delayMs) stage = 2; break;
            case 2: v += dt * 1000.0F / std::max(aMs, 0.1F); if (v >= 1.0F) { v = 1.0F; stage = 3; } break;
            case 3: v = 1.0F; break;
            case 4: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(rMs, 1.0F)); v -= v * k; if (v < 0.0005F) { v = 0.0F; stage = 0; } } break;
            default: v = 0.0F; break;
        }
        return v;
    }
};

// a one-pole in both directions
struct Pole { float z{0.0F}; float lp(float x, float a) noexcept { z += (x - z) * a; return z; } };

// RBJ low / high pass (Butterworth Q) - the cabinet
struct Lp2 {
    float b0{1.0F}, b1{0.0F}, b2{0.0F}, a1{0.0F}, a2{0.0F};
    float z1L{0.0F}, z2L{0.0F}, z1R{0.0F}, z2R{0.0F};
    void set(double sr, double hz, bool high, double q = 0.7071) noexcept {
        const double w0 = 2.0 * kPi * std::clamp(hz, 10.0, 0.45 * sr) / sr;
        const double c = std::cos(w0), s = std::sin(w0), al = s / (2.0 * q);
        double B0, B1, B2;
        if (high) { B0 = (1.0 + c) * 0.5; B1 = -(1.0 + c); B2 = (1.0 + c) * 0.5; }
        else { B0 = (1.0 - c) * 0.5; B1 = 1.0 - c; B2 = (1.0 - c) * 0.5; }
        const double A0 = 1.0 + al, A1 = -2.0 * c, A2 = 1.0 - al;
        b0 = static_cast<float>(B0 / A0); b1 = static_cast<float>(B1 / A0); b2 = static_cast<float>(B2 / A0);
        a1 = static_cast<float>(A1 / A0); a2 = static_cast<float>(A2 / A0);
    }
    static float tick(float x, float& z1, float& z2, float b0, float b1, float b2, float a1, float a2) noexcept {
        const float y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y;
    }
    void process(float& l, float& r) noexcept { l = tick(l, z1L, z2L, b0, b1, b2, a1, a2); r = tick(r, z1R, z2R, b0, b1, b2, a1, a2); }
    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0F; }
};

// SILVETON_ENGINES_V2: one mode of a body or a tine - a two-pole resonator
//   y = g x + a1 y1 + a2 y2,  r = exp(-1 / (tau sr)),  w = 2 pi f / sr,  a1 = 2 r cos w,  a2 = -r^2
struct Modal {
    float y1{0.0F}, y2{0.0F}, a1{0.0F}, a2{0.0F}, g{0.0F};
    // impulse = false: about unit gain for a steady tone at the peak, whatever the decay (a body that filters a sound);
    // impulse = true: a short hit of area 1 rings with amplitude `gain` (a struck tine)
    void set(double sr, double hz, double tauSec, float gain, bool impulse = false) noexcept {
        hz = std::clamp(hz, 10.0, 0.45 * sr);
        const double r = std::exp(-1.0 / (std::max(tauSec, 0.001) * sr));
        const double w = 2.0 * kPi * hz / sr;
        a1 = static_cast<float>(2.0 * r * std::cos(w));
        a2 = static_cast<float>(-r * r);
        g = gain * static_cast<float>((impulse ? 1.0 : (1.0 - r)) * std::sin(w));
    }
    float tick(float x) noexcept {
        const float y = g * x + a1 * y1 + a2 * y2;
        y2 = y1; y1 = y;
        return y;
    }
    void reset() noexcept { y1 = y2 = 0.0F; }
    void guard() noexcept { if (!finite(y1) || !finite(y2)) reset(); flush(y1); flush(y2); }
};

// SILVETON_ENGINES_V2: the polyBLEP residual of a step at the phase wrap (t = phase 0..1, dt = phase per sample)
inline float blep(double t, double dt) noexcept {
    if (t < dt) { t /= dt; return static_cast<float>(t + t - t * t - 1.0); }
    if (t > 1.0 - dt) { t = (t - 1.0) / dt; return static_cast<float>(t * t + t + t + 1.0); }
    return 0.0F;
}

// SILVETON_ENGINES_V3: the table waves - our own single-cycle waves made of harmonics (additive), each kept in ten versions
// with fewer and fewer harmonics (512, 256 .. 1): a note reads the version whose top harmonic stays below the Nyquist
// frequency, so the waves never alias. Built once when the sampler is made (SamplerEngine's constructor), never on the
// audio thread.
constexpr int kTabSize = 1024;
constexpr int kTabLevels = 10;
struct WaveBank {
    std::vector<float> t;   // [wave][level][kTabSize + 1]
    [[nodiscard]] const float* table(int w, int lvl) const noexcept {
        return t.data() + (static_cast<std::size_t>(w) * kTabLevels + static_cast<std::size_t>(lvl)) * (kTabSize + 1U);
    }
};
// the harmonics of each wave (n = 1..512): amplitude, may be negative
inline float tabRecipe(int w, int n) noexcept {
    const auto pick = [n](std::initializer_list<std::pair<int, float>> l) { for (const auto& h : l) if (h.first == n) return h.second; return 0.0F; };
    // SILVETON_WAVES_LIFE_V1: no wall at the last harmonic any more - above it the harmonics fade out over about a third more
    // (the walls left the waves dull: 25 .. 60 harmonics, at C3 that is 3 .. 8 kHz and then nothing)
    const auto fade = [n](int top) { return n <= top ? 1.0F : std::exp(-static_cast<float>(n - top) / (0.35F * static_cast<float>(top))); };
    const auto formant = [n, fade](std::initializer_list<std::array<float, 3>> fs) {   // a vowel at 130 Hz: formant Hz, gain, width Hz
        const float hz = 130.0F * static_cast<float>(n);
        float a = 0.12F * std::pow(static_cast<float>(n), -0.6F);   // SILVETON_WAVES_LIFE_V1: the voice itself under the vowel (the fundamental was missing)
        for (const auto& f : fs) { const float d = (hz - f[0]) / f[2]; a += f[1] * std::exp(-d * d); }
        return a * std::pow(static_cast<float>(n), -0.3F) * fade(40);
    };
    // a voiced instrument at `base` Hz: formants (Hz, gain, width Hz) over a slope n^-slope, up to maxN harmonics
    const auto at = [n, fade](float base, int maxN, float slope, std::initializer_list<std::array<float, 3>> fs) {
        if (n > 4 * maxN) return 0.0F;
        const float hz = base * static_cast<float>(n);
        float a = 0.05F;
        for (const auto& f : fs) { const float d = (hz - f[0]) / f[2]; a += f[1] * std::exp(-d * d); }
        return a * std::pow(static_cast<float>(n), -slope) * fade(maxN);
    };
    const float fn = static_cast<float>(n);
    switch (w) {
        case 0: return pick({{1, 1.0F}, {2, 1.0F}, {3, 0.7F}});                                                         // ORGAN 1: 16' 8' 5 1/3'
        case 1: return pick({{1, 1.0F}, {2, 0.8F}, {3, 0.7F}, {4, 0.6F}, {6, 0.5F}, {8, 0.4F}, {10, 0.25F}, {12, 0.2F}, {16, 0.15F}});   // ORGAN 2: full
        case 2: return pick({{1, 1.0F}, {2, 0.7F}, {4, 0.5F}, {8, 0.3F}});                                              // ORGAN 3: 8' 4' 2' 1'
        case 3: return formant({{{700.0F, 1.0F, 120.0F}}, {{1220.0F, 0.5F, 150.0F}}, {{2600.0F, 0.25F, 200.0F}}});       // VOX AH
        case 4: return formant({{{300.0F, 1.0F, 100.0F}}, {{870.0F, 0.35F, 130.0F}}, {{2240.0F, 0.1F, 200.0F}}});        // VOX OO
        case 5: return formant({{{270.0F, 1.0F, 100.0F}}, {{2290.0F, 0.4F, 180.0F}}, {{3010.0F, 0.3F, 220.0F}}});        // VOX EE
        case 6: { const float d = (fn - 6.0F) / 3.0F; return std::pow(fn, -0.7F) * (1.0F + std::exp(-d * d)) * fade(60); }   // BRASS
        case 7: return (1.0F + 0.5F * std::sin(1.3F * fn)) / fn * fade(80);                                             // STRINGS
        case 8: return std::pow(fn, -1.1F) * std::fabs(std::sin(static_cast<float>(kPi) * fn / 8.0F)) * fade(60);       // PIANO (hammer at 1/8)
        case 9: return pick({{1, 1.0F}, {2, 0.35F}, {3, 0.12F}, {4, 0.06F}, {7, 0.12F}});                              // E.PIANO
        case 10: return 2.0F * std::fabs(std::sin(static_cast<float>(kPi) * fn * 0.12F)) / fn * fade(100);              // CLAV (plucked near the end)
        case 11: return ((n & 1) != 0 ? 1.0F : 0.35F) / fn * fade(60);                                                 // REED
        case 12: return pick({{1, 1.0F}, {2, 0.3F}, {3, 0.12F}, {4, 0.05F}});                                          // FLUTE
        case 13: return pick({{1, 1.0F}, {3, 0.5F}, {4, 0.6F}, {7, 0.4F}, {11, 0.3F}, {13, 0.2F}});                   // BELL (glassy)
        case 14: return n > 24 ? 0.0F : 1.0F / (1.0F + 0.05F * fn);                                                    // DIGITAL 1
        case 15: return (n > 31 || (n & 1) == 0) ? 0.0F : (((n - 1) / 2) % 2 == 0 ? 1.0F : -1.0F) * 0.5F;              // DIGITAL 2
        case 16: return pick({{1, 1.0F}, {3, 0.5F}, {5, 0.3F}, {9, 0.2F}});                                            // HOLLOW
        case 17: return pick({{1, 1.0F}, {2, 0.6F}, {3, 0.35F}, {4, 0.2F}, {5, 0.1F}});                               // BASS
        // SILVETON_ENGINES_V3 (2): the winds, the folk instruments, the choir, the synth waves
        case 18: return at(350.0F, 40, 0.4F, {{{600.0F, 1.0F, 250.0F}}, {{1600.0F, 0.6F, 400.0F}}, {{2900.0F, 0.35F, 500.0F}}});    // SAX ALTO
        case 19: return at(200.0F, 50, 0.4F, {{{500.0F, 1.0F, 220.0F}}, {{1200.0F, 0.6F, 300.0F}}, {{2400.0F, 0.35F, 450.0F}}});    // SAX TENOR
        case 20: return at(400.0F, 40, 0.3F, {{{1300.0F, 1.0F, 900.0F}}, {{2600.0F, 0.4F, 800.0F}}});                           // TRUMPET
        case 21: return at(150.0F, 60, 0.3F, {{{500.0F, 1.0F, 300.0F}}, {{1100.0F, 0.6F, 500.0F}}, {{2000.0F, 0.2F, 600.0F}}});     // TROMBONE
        case 22: return ((n & 1) != 0 ? 1.0F : 0.08F) / fn * fade(25);                                                   // CLARINET
        case 23: return n == 1 ? 0.45F : at(400.0F, 30, 0.2F, {{{1100.0F, 1.0F, 350.0F}}, {{2900.0F, 0.4F, 500.0F}}});        // OBOE
        case 24: { const float d = (fn - 3.5F) / 1.5F; return std::pow(fn, -0.7F) * (1.0F + 0.6F * std::exp(-d * d)) * fade(40); }   // ACCORDION
        case 25: { if (n > 160) return 0.0F; const float d = (fn * 350.0F - 1800.0F) / 700.0F; return std::pow(fn, -0.4F) * ((n & 1) != 0 ? 1.0F : 0.6F) * (0.5F + std::exp(-d * d)) * fade(30); }   // GAIDA
        case 26: return pick({{1, 1.0F}, {2, 0.55F}, {3, 0.25F}, {4, 0.12F}, {5, 0.06F}});                             // KAVAL
        case 27: return pick({{1, 1.0F}, {2, 0.7F}, {3, 0.6F}, {4, 0.35F}, {5, 0.3F}, {6, 0.15F}, {7, 0.12F}, {8, 0.06F}});   // HARMONICA
        case 28: return at(130.0F, 40, 0.5F, {{{600.0F, 1.0F, 200.0F}}, {{1000.0F, 0.5F, 250.0F}}, {{2600.0F, 0.15F, 300.0F}}});    // CHOIR
        case 29: return ((n & 1) != 0 ? 1.7F : 1.0F) / fn;                                                               // SYNTH LEAD (saw + square)
        case 30: return std::pow(fn, -1.5F) * fade(64);                                                                  // SYNTH PAD (soft saw)
        case 31: return 2.0F / (static_cast<float>(kPi) * fn) * std::sin(static_cast<float>(kPi) * fn * 0.25F);         // SQUARE 25%
        default: return n == 1 ? 1.0F : 0.0F;
    }
}
inline WaveBank makeWaveBank() {
    constexpr int W = silveton::sampler::kTableWaveCount + 1;   // + the internal saw (SILVETON_AUDIT_V1)
    WaveBank b;
    b.t.assign(static_cast<std::size_t>(W) * kTabLevels * (kTabSize + 1U), 0.0F);
    constexpr int kMaxH = kTabSize / 2;
    std::vector<float> amp(static_cast<std::size_t>(kMaxH) + 1U);
    std::vector<double> acc(kTabLevels);
    for (int w = 0; w < W; ++w) {
        const bool saw = w == silveton::sampler::kTableWaveCount;   // 2x - 1 = -(2 / pi) sum sin(2 pi n x) / n
        for (int n = 1; n <= kMaxH; ++n) amp[static_cast<std::size_t>(n)] = saw ? static_cast<float>(-2.0 / kPi / n) : tabRecipe(w, n);
        for (int i = 0; i < kTabSize; ++i) {
            const double th = 2.0 * kPi * static_cast<double>(i) / kTabSize;
            const double c2 = 2.0 * std::cos(th);
            double s1 = 0.0, s0 = std::sin(th);   // sin((n-1) th), sin(n th)
            double sum = 0.0;
            for (int n = 1; n <= kMaxH; ++n) {
                sum += static_cast<double>(amp[static_cast<std::size_t>(n)]) * s0;
                for (int lvl = 0; lvl < kTabLevels; ++lvl) if (n == (kMaxH >> lvl)) acc[static_cast<std::size_t>(lvl)] = sum;
                const double s2 = c2 * s0 - s1; s1 = s0; s0 = s2;
            }
            for (int lvl = 0; lvl < kTabLevels; ++lvl) const_cast<float*>(b.table(w, lvl))[i] = static_cast<float>(acc[static_cast<std::size_t>(lvl)]);
        }
        float peak = 1.0e-6F;
        for (int i = 0; i < kTabSize; ++i) peak = std::max(peak, std::fabs(b.table(w, 0)[i]));
        if (saw) peak = 1.0F;   // the saw keeps the level of the naive one (+-1)
        for (int lvl = 0; lvl < kTabLevels; ++lvl) {
            float* t = const_cast<float*>(b.table(w, lvl));
            for (int i = 0; i < kTabSize; ++i) t[i] /= peak;
            t[kTabSize] = t[0];
        }
    }
    return b;
}
inline const WaveBank& waveBank() { static const WaveBank b = makeWaveBank(); return b; }
// SILVETON_USER_WAVES_V1: the user's own waves (USER 1..16, from SILVETON OSCILLATOR LAB via the folder SILVETON_OSC) are kept in
// the same ten versions as the table waves (UserWaves.h / UserWaves.cpp, made on the control thread, one atomic pointer).
static_assert(silveton::sampler::kUserTabSize == kTabSize && silveton::sampler::kUserTabLevels == kTabLevels, "user waves: same table layout");
// the version of a table for a tone of inc cycles per sample: its top harmonic stays below the Nyquist frequency
inline int tabLevel(double inc) noexcept {
    const double maxH = 0.45 / std::max(inc, 1.0e-6);
    int lvl = 0;
    while (lvl < kTabLevels - 1 && static_cast<double>((kTabSize / 2) >> lvl) > maxH) ++lvl;
    return lvl;
}
inline float tabCubic(const float* t, double ph) noexcept;
inline float tabReadAny(int w, double ph, double inc) noexcept { return tabCubic(waveBank().table(w, tabLevel(inc)), ph); }
// one sample of USER k+1 for a note started on `key` (a KMP wave: the zone of that key); 0 when its place is empty
inline float tabUser(int k, double ph, double inc, int key) noexcept {
    const silveton::sampler::UserWaveTables* b = silveton::sampler::userWaveTables().load(std::memory_order_acquire);
    if (b == nullptr) return 0.0F;
    const int ti = b->tableFor(k, key);
    if (ti < 0) return 0.0F;
    return tabCubic(b->table(ti, tabLevel(inc)), ph);
}
// one sample of table wave w at phase ph (0..1), for a tone of inc cycles per sample (w 32..47 = USER 1..16, `key` = the
// key the note started on: it picks the zone of a USER wave made from a KMP)
inline float tabRead(int w, double ph, double inc, int key = 60) noexcept {
    if (w >= silveton::sampler::kTableWaveCount) return tabUser(w - silveton::sampler::kTableWaveCount, ph, inc, key);
    return tabReadAny(std::max(w, 0), ph, inc);
}
inline float tabSaw(double ph, double inc) noexcept { return tabReadAny(silveton::sampler::kTableWaveCount, ph, inc); }
inline float tabCubic(const float* t, double ph) noexcept {
    const double x = (ph - std::floor(ph)) * kTabSize;
    const int i = std::min(static_cast<int>(x), kTabSize - 1);
    const float f = static_cast<float>(x - static_cast<double>(i));
    // SILVETON_AUDIT_V1: 4-point cubic (Catmull-Rom) instead of the straight line - the straight line left images of the
    // upper harmonics at about -62 dB (measured, C4 saw at 96 kHz); the cubic is far below
    constexpr int m = kTabSize - 1;
    const float y0 = t[(i - 1) & m], y1 = t[i], y2 = t[i + 1], y3 = t[(i + 2) & m];
    const float c1 = 0.5F * (y2 - y0);
    const float c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3;
    const float c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
    return ((c3 * f + c2) * f + c1) * f + y1;
}

// SILVETON_ENGINES_V2: a band-limited oscillator - saw and pulse by polyBLEP, triangle as the integrated pulse, sine
// from the table. Its output is one sample late, so that a hard sync can correct the sample before the reset as
// well as the one after it (the two polyBLEP residuals of the jump). wave: 0 off 1 saw 2 pulse 3 tri 4 sine.
// SILVETON_WAVES_LIFE_V1: what keeps a table wave alive (a recorded instrument is never the same cycle twice): the pitch
// wanders a few cents, slowly and never in a loop (two slow movements at unrelated rates), and the ensemble waves (choir,
// strings, accordion, pads...) play a second copy of themselves a few cents away, which wanders the other way - the slow
// beating of a section. Per wave: the cents of the second copy (0 = a solo instrument, no copy), its level, the wander.
struct WaveLife { float detune, mix, drift; };
inline const WaveLife& waveLife(int w) noexcept {
    static const WaveLife t[silveton::sampler::kTableWaveCount] = {
        {1.0F, 0.25F, 0.5F},  {1.0F, 0.25F, 0.5F},  {1.0F, 0.25F, 0.5F},     // ORGAN 1 2 3: ranks a hair apart
        {7.0F, 0.7F, 2.5F},   {7.0F, 0.7F, 2.5F},   {7.0F, 0.7F, 2.5F},      // VOX AH OO EE: several voices
        {5.0F, 0.5F, 3.0F},   {9.0F, 0.75F, 2.5F},                           // BRASS (section), STRINGS
        {2.0F, 0.35F, 1.0F},  {1.5F, 0.3F, 1.0F},   {0.0F, 0.0F, 1.0F},      // PIANO (the strings of a key), E.PIANO, CLAV
        {6.0F, 0.6F, 2.5F},   {0.0F, 0.0F, 2.5F},   {0.0F, 0.0F, 0.0F},      // REED, FLUTE (solo), BELL (still)
        {3.0F, 0.3F, 1.5F},   {3.0F, 0.3F, 1.5F},   {3.0F, 0.3F, 2.0F},      // DIGITAL 1 2, HOLLOW
        {0.0F, 0.0F, 1.5F},                                                  // BASS
        {0.0F, 0.0F, 2.5F},   {0.0F, 0.0F, 2.5F},   {0.0F, 0.0F, 2.5F},      // SAX ALTO, SAX TENOR, TRUMPET (solo)
        {0.0F, 0.0F, 2.5F},   {0.0F, 0.0F, 3.0F},   {0.0F, 0.0F, 2.5F},      // TROMBONE, CLARINET, OBOE (solo)
        {12.0F, 0.8F, 3.0F},                                                 // ACCORDION: the musette reeds
        {0.0F, 0.0F, 3.0F},   {0.0F, 0.0F, 3.0F},   {4.0F, 0.4F, 3.0F},      // GAIDA, KAVAL (solo), HARMONICA
        {8.0F, 0.8F, 2.5F},                                                  // CHOIR
        {6.0F, 0.5F, 2.5F},   {10.0F, 0.8F, 3.0F},  {4.0F, 0.4F, 2.0F},      // SYNTH LEAD, SYNTH PAD, SQUARE 25%
    };
    static const WaveLife user{0.0F, 0.0F, 1.5F};   // SILVETON_USER_WAVES_V1: the user's waves breathe a little, like the solo waves (no copy)
    if (w >= silveton::sampler::kTableWaveCount) return user;
    return t[std::clamp(w, 0, silveton::sampler::kTableWaveCount - 1)];
}

struct Osc {
    double ph{0.0};
    double lifePh2{0.0}, lifeOff{0.0}, lifeOff2{0.0}, lifeM1{0.0}, lifeM2{0.0}, lifeW1{0.0}, lifeW2{0.0};   // SILVETON_WAVES_LIFE_V1
    float tri{-1.0F};
    float dly{0.0F}, corr{0.0F};
    bool wrapped{false};
    double wrapD{0.0};   // after step(): how many samples ago (0..1) the phase wrapped
    int zoneKey{60};     // SILVETON_USER_WAVES_V1: the key the note started on (the zone of a USER wave made from a KMP)
    void reset(double startPhase) noexcept { ph = startPhase - std::floor(startPhase); tri = -1.0F + 4.0F * static_cast<float>(std::min(ph, 0.5)); dly = corr = 0.0F; wrapped = false; }
    // SILVETON_WAVES_LIFE_V1: every note wanders its own way (r1, r2 = two random numbers -1..1 of the note)
    void life(double sr, float r1, float r2) noexcept {
        lifeM1 = 0.5 + 0.5 * static_cast<double>(r1); lifeM2 = 0.5 + 0.5 * static_cast<double>(r2);
        lifeW1 = (0.29 + 0.1 * static_cast<double>(r2)) / std::max(1.0, sr); lifeW2 = (0.83 + 0.2 * static_cast<double>(r1)) / std::max(1.0, sr);
        lifePh2 = ph + 0.31 + 0.2 * static_cast<double>(r2); lifeOff = lifeOff2 = 0.0;
    }
    // one sample of table wave w, alive (the phase ph has just moved by inc)
    float tableLife(int w, double inc) noexcept {
        const WaveLife& L = waveLife(w);
        lifeM1 += lifeW1; lifeM1 -= std::floor(lifeM1);
        lifeM2 += lifeW2; lifeM2 -= std::floor(lifeM2);
        const double m = 0.6 * static_cast<double>(sin01(lifeM1)) + 0.4 * static_cast<double>(sin01(lifeM2));   // -1 .. 1
        constexpr double kCent = 0.000577622650466621;   // ln 2 / 1200: a cent as a part of the pitch
        // the two copies sit either side of the note, weighted by their levels, so that together they are in tune
        const double mix2 = static_cast<double>(L.mix) * static_cast<double>(L.mix);
        const double below = static_cast<double>(L.detune) * mix2 / (1.0 + mix2), above = static_cast<double>(L.detune) / (1.0 + mix2);
        lifeOff += inc * (static_cast<double>(L.drift) * m - below) * kCent;
        lifeOff -= std::floor(lifeOff);
        const float y1 = tabRead(w, ph + lifeOff, inc, zoneKey);
        if (L.mix <= 0.0F) return y1;
        lifePh2 += inc * (1.0 + above * kCent);
        lifePh2 -= std::floor(lifePh2);
        lifeOff2 -= inc * static_cast<double>(L.drift) * kCent * m;
        lifeOff2 -= std::floor(lifeOff2);
        const float y2 = tabRead(w, lifePh2 + lifeOff2, inc, zoneKey);
        return (y1 + L.mix * y2) / std::sqrt(1.0F + L.mix * L.mix);   // the two copies as loud as one
    }
    static float raw(int wave, double p, float pw, float triV, int zk = 60) noexcept {
        switch (wave) {
            case 1: return static_cast<float>(2.0 * p - 1.0);
            case 2: return p < static_cast<double>(pw) ? 1.0F : -1.0F;
            case 3: return triV;
            case 4: return sin01(p);
            case 90: return static_cast<float>(2.0 * p - 1.0);
            case 91: return p < static_cast<double>(pw) ? 1.0F : -1.0F;
            default: return wave >= 100 ? tabRead(wave - 100, p, 0.002, zk) : 0.0F;
        }
    }
    // advance one sample; returns this sample's band-limited value (the caller passes it to out())
    float step(int wave, double inc, float pw) noexcept {
        inc = std::clamp(inc, 0.0, 0.49);
        ph += inc; wrapped = false;
        if (ph >= 1.0) { ph -= 1.0; if (ph >= 1.0) ph -= std::floor(ph); wrapped = true; wrapD = inc > 0.0 ? ph / inc : 0.0; }
        switch (wave) {
            case 1: return static_cast<float>(2.0 * ph - 1.0) - blep(ph, inc);
            case 2: {
                float y = ph < static_cast<double>(pw) ? 1.0F : -1.0F;
                y += blep(ph, inc);
                double t2 = ph - static_cast<double>(pw); if (t2 < 0.0) t2 += 1.0;
                return y - blep(t2, inc);
            }
            case 3: {
                float sq = ph < 0.5 ? 1.0F : -1.0F;
                sq += blep(ph, inc);
                double t2 = ph - 0.5; if (t2 < 0.0) t2 += 1.0;
                sq -= blep(t2, inc);
                tri += static_cast<float>(4.0 * inc) * sq;
                tri *= 0.9995F;
                return tri;
            }
            case 4: return sin01(ph);
            // SILVETON_AUDIT_V1: the saw and the pulse from the band-limited saw table (the pulse = two saws, PWM stays continuous)
            case 90: return tabSaw(ph, inc);
            case 91: return tabSaw(ph - static_cast<double>(pw), inc) - tabSaw(ph, inc) + 2.0F * pw - 1.0F;
            default: return wave >= 100 ? tableLife(wave - 100, inc) : 0.0F;   // SILVETON_ENGINES_V3: a table wave (SILVETON_WAVES_LIFE_V1: alive)
        }
    }
    // the delayed output: the previous sample plus its pending correction
    float out(float yNow) noexcept { const float o = dly + corr; dly = yNow; corr = 0.0F; return o; }
    // hard sync to a master that wrapped d samples ago (0 <= d < 1): the phase restarts there. The jump is spread by the
    // two polyBLEP residuals: one on the sample before (still in the delay slot), one on this sample (yNow is rewritten).
    void sync(int wave, double inc, float pw, double d, float& yNow) noexcept {
        if (wave == 0) return;
        inc = std::clamp(inc, 0.0, 0.49);
        d = std::clamp(d, 0.0, 0.999);
        const double newPh = d * inc;
        double phW = ph - newPh; if (phW < 0.0) phW += 1.0;               // the phase the slave had at the wrap instant
        const float yOld = raw(wave, phW, pw, tri, zoneKey);
        if (wave == 3) tri = -1.0F + 4.0F * static_cast<float>(newPh);
        const float yAt0 = raw(wave, 0.0, pw, -1.0F, zoneKey);
        const float yNew = raw(wave, newPh, pw, tri, zoneKey);
        const float J = yAt0 - yOld;
        corr += static_cast<float>(0.5 * static_cast<double>(J) * d * d);
        yNow = yNew - static_cast<float>(0.5 * static_cast<double>(J) * (1.0 - d) * (1.0 - d));
        ph = newPh; wrapped = true; wrapD = d;
        lifePh2 = newPh; lifeOff = lifeOff2 = 0.0;   // SILVETON_WAVES_LIFE_V1: a hard sync restarts both copies
    }
};

// SILVETON_ENGINES_V2: the 4-pole ladder of POLYSIX / AL-1 (type LP24). Zero-delay feedback (the linear part is solved
// exactly), the nonlinearity of the feedback input solved by two fixed-point passes, a soft saturation of every stage
// (SAT). Divergence guard: a state that is not finite is cleared.
struct Ladder4 {
    float G{0.0F}, k{0.0F}, comp{1.0F}, sat{0.0F};
    std::array<float, 4> sL{}, sR{};
    bool prime{true};
    void set(float cutoffHz, float resonance, double sr, float saturation) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        G = static_cast<float>(g / (1.0 + g));
        k = 4.0F * std::clamp(resonance, 0.0F, 1.0F) * 0.985F;
        comp = 1.0F + 0.8F * k;   // keep the bass when the resonance is up (SILVETON_BODY_V1: was 0.5 - measured -2.7 dB at 100 Hz already at RESO 30 %, now about -1 dB up to 90 %)
        sat = std::clamp(saturation, 0.0F, 1.0F);
    }
    static float stageSat(float a, float s) noexcept {
        if (s <= 0.0F) return a;
        const float c = std::clamp(a, -2.0F, 2.0F);
        return a + s * (c - a - c * c * c * (1.0F / 6.0F));   // cubic softening, bounded
    }
    float tick(float x, std::array<float, 4>& st) const noexcept {
        const float g1 = 1.0F - G;
        const float G2 = G * G, G3 = G2 * G, G4 = G3 * G;
        const float S = g1 * (G3 * st[0] + G2 * st[1] + G * st[2] + st[3]);   // what the states alone give at the output
        const float xin = x * comp;
        float u = 0.0F;
        if (sat > 0.0F) {
            // u = tanh(d (x - k y4)) / d  with  y4 = G4 u + S : two passes from the linear solution
            const float d = 1.0F + 2.0F * sat;
            float y4 = (G4 * xin + S) / (1.0F + k * G4);
            for (int it = 0; it < 2; ++it) {
                u = tanhT((xin - k * y4) * d) / d;
                y4 = G4 * u + S;
            }
            u = tanhT((xin - k * y4) * d) / d;
        } else {
            u = (xin - k * S) / (1.0F + k * G4);
        }
        for (int i = 0; i < 4; ++i) {
            const auto ii = static_cast<std::size_t>(i);
            const float a = stageSat(u, sat * 0.6F);
            const float vI = (a - st[ii]) * G;
            const float y = vI + st[ii];
            st[ii] = y + vI;
            u = y;
        }
        return u;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { sL.fill(0.0F); sR.fill(0.0F); prime = false; }
        l = tick(l, sL); r = tick(r, sR);
        if (!finite(l) || !finite(r)) { sL.fill(0.0F); sR.fill(0.0F); l = r = 0.0F; }
    }
    void guard() noexcept { for (auto& s : sL) flush(s); for (auto& s : sR) flush(s); }
};

// SILVETON_ENGINES_V2: the Korg35 filters of the MS-20 - low-pass (LPF1 -> LPF2, an HPF in the feedback with gain K)
// and high-pass (HPF1 -> HPF2, an LPF in the feedback). Zero-delay (the linear loop is solved exactly). ANALOG model: the
// feedback is saturated and the loop is solved by three fixed-point passes from the linear solution (the loop gain is
// below 0.5, so the passes converge); a result that is not finite clears the filter.
struct SkFilter {
    bool high{false};
    float G{0.0F}, K{0.0F}, satD{0.0F};
    bool analog{true};
    float s1L{0.0F}, s2L{0.0F}, s3L{0.0F}, s1R{0.0F}, s2R{0.0F}, s3R{0.0F};
    bool prime{true};
    void set(float cutoffHz, float resonance, double sr, bool analogModel, float fbSat) noexcept {
        const double fc = std::clamp(static_cast<double>(cutoffHz), 20.0, 0.45 * std::max(1.0, sr));
        const double g = std::tan(kPi * fc / std::max(1.0, sr));
        G = static_cast<float>(g / (1.0 + g));
        K = 2.0F * std::clamp(resonance, 0.0F, 1.0F) * 0.985F;
        analog = analogModel;
        satD = 0.5F + 1.5F * std::clamp(fbSat, 0.0F, 1.0F);
    }
    float sat(float x) const noexcept { return analog ? tanhT(x * satD) / satD : x; }
    float tickLp(float x, float& s1, float& s2, float& s3) const noexcept {
        // LPF1
        const float v1 = (x - s1) * G; const float u = v1 + s1; s1 = u + v1;
        const float g1 = 1.0F - G;
        // LPF2 with the HPF1 feedback: y = G (u + fb) + g1 s2,  fb = sat(K g1 (y - s3))
        const float den = 1.0F - G * K * g1;
        float y = (G * u - G * K * g1 * s3 + g1 * s2) / std::max(den, 0.05F);
        if (analog) {
            for (int it = 0; it < 3; ++it) y = G * (u + sat(K * g1 * (y - s3))) + g1 * s2;
            y = std::clamp(y, -4.0F, 4.0F);
        }
        const float fb = sat(K * g1 * (y - s3));
        const float in2 = u + fb;
        const float v2 = (in2 - s2) * G; const float y2 = v2 + s2; s2 = y2 + v2;
        const float v3 = (y2 - s3) * G; const float lp3 = v3 + s3; s3 = lp3 + v3;
        return y2;
    }
    float tickHp(float x, float& s1, float& s2, float& s3) const noexcept {
        const float g1 = 1.0F - G;
        // HPF1: hp = g1 (x - s1)
        const float h1 = g1 * (x - s1);
        const float v1 = (x - s1) * G; s1 = s1 + 2.0F * v1;
        // HPF2 with the LPF feedback: y = g1 (h1 + fb - s2),  fb = sat(K (G y + g1 s3))
        const float den = 1.0F - g1 * K * G;
        float y = g1 * (h1 + K * g1 * s3 - s2) / std::max(den, 0.05F);
        if (analog) {
            for (int it = 0; it < 3; ++it) y = g1 * (h1 + sat(K * (G * y + g1 * s3)) - s2);
            y = std::clamp(y, -4.0F, 4.0F);
        }
        const float fb = sat(K * (G * y + g1 * s3));
        const float in2 = h1 + fb;
        const float v2 = (in2 - s2) * G; const float y2 = in2 - (v2 + s2); s2 = s2 + 2.0F * v2;
        const float v3 = (y2 - s3) * G; s3 = s3 + 2.0F * v3;
        return y2;
    }
    void process(float& l, float& r) noexcept {
        if (prime) { s1L = s2L = s3L = s1R = s2R = s3R = 0.0F; prime = false; }
        if (high) { l = tickHp(l, s1L, s2L, s3L); r = tickHp(r, s1R, s2R, s3R); }
        else { l = tickLp(l, s1L, s2L, s3L); r = tickLp(r, s1R, s2R, s3R); }
        if (!finite(l) || !finite(r)) { s1L = s2L = s3L = s1R = s2R = s3R = 0.0F; l = r = 0.0F; }
    }
    void reset() noexcept { prime = true; }
    void guard() noexcept { flush(s1L); flush(s2L); flush(s3L); flush(s1R); flush(s2R); flush(s3R); }
};

// SILVETON_ENGINES_V2: the MOD-7 algorithms - who modulates whom among the six operators. Operator 1 is the recording,
// 2..6 are sines. mod[i] = bit mask of the operators that modulate operator i; carrier = bit mask of the operators heard
// on their own; fb = the operator with the FEEDBACK knob on itself.
struct Algo { std::uint8_t mod[6]; std::uint8_t carrier; std::uint8_t fb; };
inline const Algo& algoOf(int ix) noexcept {
    static const Algo kAlgos[12] = {
        {{0x02, 0x04, 0x00, 0x00, 0x00, 0x00}, 0x01, 1},   // 1  PCM <- 2 <- 3   (the V1 routing; OP3-> may send 3 to the PCM instead)
        {{0x02, 0x04, 0x08, 0x00, 0x00, 0x00}, 0x01, 3},   // 2  PCM <- 2 <- 3 <- 4
        {{0x0E, 0x00, 0x00, 0x00, 0x00, 0x00}, 0x01, 3},   // 3  PCM <- 2 + 3 + 4
        {{0x02, 0x00, 0x08, 0x00, 0x00, 0x00}, 0x05, 3},   // 4  two carriers: PCM <- 2, 3 <- 4
        {{0x02, 0x00, 0x08, 0x00, 0x20, 0x00}, 0x15, 5},   // 5  three carriers: PCM <- 2, 3 <- 4, 5 <- 6
        {{0x20, 0x20, 0x20, 0x20, 0x20, 0x00}, 0x1F, 5},   // 6  fan: 6 -> everyone, five carriers
        {{0x00, 0x04, 0x00, 0x10, 0x00, 0x00}, 0x2B, 2},   // 7  pairs: 2 <- 3, 4 <- 5, 6 and PCM alone
        {{0x02, 0x04, 0x08, 0x10, 0x20, 0x00}, 0x01, 5},   // 8  feedback chain: PCM <- 2 <- 3 <- 4 <- 5 <- 6 (fb on 6)
        {{0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, 0x3F, 5},   // 9  organ: six carriers, no modulation
        {{0x02, 0x00, 0x08, 0x00, 0x20, 0x00}, 0x15, 1},   // 10 bell: like 5, feedback on 2 (set OP2 RATIO 3.5, OP4 RATIO 1.41)
        {{0x00, 0x04, 0x08, 0x10, 0x20, 0x00}, 0x03, 5},   // 11 PCM + a 5-deep stack on carrier 2
        {{0x3E, 0x00, 0x00, 0x00, 0x00, 0x00}, 0x01, 5},   // 12 everything modulates the PCM
    };
    return kAlgos[static_cast<std::size_t>(std::clamp(ix, 0, 11))];
}

// SILVETON_ENGINES_V2: does this engine make a sound of its own (so it plays even on an Upper that has no recording)
inline bool makesOwnSound(const silveton::sampler::EngineParams& e) noexcept { return silveton::sampler::engineMakesOwnSound(e); }

// SILVETON_ENGINES_V3: what the STYLE of a STR-1 instrument changes in the plucked string
struct StrStyle {
    float decayMul{1.0F}, dampMin{0.0F}, dampMul{1.0F}, colorMul{1.0F}, pick{-1.0F}, pluckPeriods{1.0F};
    double tuneMul{1.0};   // HARMONIC: the string sounds an octave up (touched in the middle)
};
inline StrStyle strStyleOf(int inst, int style) noexcept {
    using namespace silveton::sampler;
    StrStyle m;
    switch (inst) {
        case ST_GUITAR:
            switch (style) {
                case 1: m.colorMul = 0.3F; m.pluckPeriods = 1.5F; break;                                   // FINGER: soft and round
                case 2: m.decayMul = 0.08F; m.dampMin = 0.75F; m.colorMul = 0.6F; break;                  // MUTE: the palm on the strings
                case 3: m.tuneMul = 2.0; m.colorMul = 0.5F; m.dampMul = 0.5F; m.decayMul = 1.3F; break;   // HARMONIC: the 12th fret
                default: break;                                                                            // PICK
            }
            break;
        case ST_VIOLIN: case ST_CELLO:
            if (style == 1) { m.decayMul = 0.5F; m.colorMul = 0.5F; m.pluckPeriods = 1.5F; }               // PIZZ: plucked with a finger
            break;
        case ST_HARP:
            switch (style) {
                case 1: m.tuneMul = 2.0; m.colorMul = 0.4F; m.dampMul = 0.5F; m.decayMul = 1.2F; break;   // HARMONIC
                case 2: m.decayMul = 0.1F; m.dampMin = 0.6F; break;                                        // MUTED (étouffé)
                case 3: m.pick = 0.04F; m.colorMul = 1.6F; m.decayMul = 0.7F; break;                      // PRES TABLE: near the soundboard
                default: m.colorMul = 0.5F; m.pluckPeriods = 1.5F; break;                                  // NORMAL: the finger
            }
            break;
        default: break;
    }
    return m;
}

// SILVETON_ENGINES_V3: the body of a STR-1 instrument - a bank of resonances (constant-peak band-pass) plus a direct path and a
// gentle top cut, normalized so that a bright string comes out about as loud as it goes in. One per Upper (it is linear).
struct StrBody {
    static constexpr int kModes = 12;
    struct Bp { float b0{0.0F}, a1{0.0F}, a2{0.0F}, z1{0.0F}, z2{0.0F}, g{0.0F}; };
    struct Def { float hz, q, db; };
    std::array<Bp, kModes> m{};
    int count{0};
    float direct{0.0F}, norm{1.0F}, lpA{1.0F}, lpZ{0.0F};
    void set(double sr, int inst) noexcept {
        // our own sketches of the instruments' resonances (Hz, Q, dB): the air and the plates, then the broad "bridge hill"
        static const Def violin[] = {{275, 12, 4}, {410, 18, -2}, {470, 20, 8}, {545, 22, 7}, {640, 15, 2}, {810, 12, 3}, {1050, 10, 1},
                                     {1350, 10, 0}, {2400, 1.8F, 5}, {3100, 4, 1}, {4200, 3, -4}};
        static const Def cello[] = {{102, 10, 4}, {145, 15, -2}, {175, 18, 8}, {205, 20, 7}, {240, 15, 2}, {300, 12, 3}, {400, 10, 1},
                                    {520, 10, 0}, {1100, 1.8F, 6}, {1500, 4, 2}, {2200, 3, -3}};
        static const Def guitar[] = {{100, 12, 6}, {195, 15, 8}, {225, 12, 2}, {390, 12, 4}, {550, 10, 3}, {750, 10, 1}, {1000, 8, 2},
                                     {1500, 4, 1}, {2500, 2, 3}, {4000, 2, 0}};
        static const Def harp[] = {{120, 6, 4}, {210, 8, 3}, {330, 8, 3}, {480, 7, 2}, {700, 6, 2}, {1000, 5, 1}, {1500, 4, 1},
                                   {2300, 3, 0}, {3500, 2, -2}};
        // the winds: the bell / the body of the instrument, a few broad resonances and much of the direct sound
        static const Def saxA[] = {{600, 2.5F, 4}, {1600, 2, 3}, {2900, 3, 1}, {5000, 2, -6}};
        static const Def saxT[] = {{450, 2.5F, 4}, {1200, 2, 3}, {2400, 3, 1}, {4500, 2, -6}};
        static const Def clar[] = {{1500, 2, 2}, {3000, 3, -2}};
        static const Def trum[] = {{1200, 1.5F, 4}, {2500, 2, 3}};
        static const Def kaval[] = {{800, 2, 1}, {2000, 2, 2}};
        static const Def gaida[] = {{1800, 1.5F, 6}, {3500, 3, 3}};
        const Def* d = guitar; int n = 10; float directDb = -6.0F; double lpHz = 9000.0;
        switch (inst) {
            case silveton::sampler::ST_SAX_ALTO: d = saxA; n = 4; directDb = 0.0F; lpHz = 9000.0; break;
            case silveton::sampler::ST_SAX_TENOR: d = saxT; n = 4; directDb = 0.0F; lpHz = 8000.0; break;
            case silveton::sampler::ST_CLARINET: d = clar; n = 2; directDb = 0.0F; lpHz = 7000.0; break;
            case silveton::sampler::ST_TRUMPET: d = trum; n = 2; directDb = 0.0F; lpHz = 10000.0; break;
            case silveton::sampler::ST_KAVAL: d = kaval; n = 2; directDb = 0.0F; lpHz = 9000.0; break;
            case silveton::sampler::ST_GAIDA: d = gaida; n = 2; directDb = 0.0F; lpHz = 9000.0; break;
            case silveton::sampler::ST_VIOLIN: d = violin; n = 11; directDb = -14.0F; lpHz = 7500.0; break;
            case silveton::sampler::ST_CELLO: d = cello; n = 11; directDb = -14.0F; lpHz = 5000.0; break;
            case silveton::sampler::ST_HARP: d = harp; n = 9; directDb = -3.0F; lpHz = 8000.0; break;
            default: break;
        }
        count = std::min(n, kModes);
        direct = std::pow(10.0F, directDb / 20.0F);
        lpA = static_cast<float>(1.0 - std::exp(-2.0 * kPi * std::min(lpHz, 0.45 * sr) / sr));
        std::array<double, kModes> b0{}, a1{}, a2{}, g{};
        for (int i = 0; i < count; ++i) {
            const double w0 = 2.0 * kPi * std::clamp(static_cast<double>(d[i].hz), 20.0, 0.45 * sr) / sr;
            const double al = std::sin(w0) / (2.0 * std::max(0.3, static_cast<double>(d[i].q)));
            const double a0 = 1.0 + al;
            b0[static_cast<std::size_t>(i)] = al / a0; a1[static_cast<std::size_t>(i)] = -2.0 * std::cos(w0) / a0; a2[static_cast<std::size_t>(i)] = (1.0 - al) / a0;
            g[static_cast<std::size_t>(i)] = std::pow(10.0, static_cast<double>(d[i].db) / 20.0);
            auto& bp = m[static_cast<std::size_t>(i)];
            bp.b0 = static_cast<float>(b0[static_cast<std::size_t>(i)]); bp.a1 = static_cast<float>(a1[static_cast<std::size_t>(i)]);
            bp.a2 = static_cast<float>(a2[static_cast<std::size_t>(i)]); bp.g = static_cast<float>(g[static_cast<std::size_t>(i)]);
        }
        // the level: the power of a saw-like spectrum (1 / f per log band) through the body, 80 Hz .. 8 kHz
        double num = 0.0, den = 0.0;
        for (int k = 0; k < 64; ++k) {
            const double f = 80.0 * std::pow(100.0, static_cast<double>(k) / 63.0);
            const double w = 2.0 * kPi * f / sr;
            const std::complex<double> z1 = std::polar(1.0, -w), z2 = z1 * z1;
            std::complex<double> h = static_cast<double>(direct);
            for (int i = 0; i < count; ++i) {
                const auto ii = static_cast<std::size_t>(i);
                h += g[ii] * (b0[ii] * (1.0 - z2)) / (1.0 + a1[ii] * z1 + a2[ii] * z2);
            }
            const double la = static_cast<double>(lpA);
            h *= la / (1.0 - (1.0 - la) * z1);
            const double wt = 1.0 / f;
            num += wt; den += wt * std::norm(h);
        }
        norm = den > 1.0e-12 ? static_cast<float>(std::sqrt(num / den)) : 1.0F;
    }
    float tick(float x) noexcept {
        float y = direct * x;
        for (int i = 0; i < count; ++i) {
            auto& b = m[static_cast<std::size_t>(i)];
            const float o = b.b0 * x + b.z1;
            b.z1 = -b.a1 * o + b.z2;
            b.z2 = -b.b0 * x - b.a2 * o;
            y += b.g * o;
        }
        lpZ += (y - lpZ) * lpA;
        return lpZ * norm;
    }
    void reset() noexcept { for (auto& b : m) b.z1 = b.z2 = 0.0F; lpZ = 0.0F; }
    void guard() noexcept {
        bool bad = !finite(lpZ);
        for (auto& b : m) { if (!finite(b.z1) || !finite(b.z2)) bad = true; flush(b.z1); flush(b.z2); }
        if (bad) reset();
        flush(lpZ);
    }
};

// what the per-block update needs to know about the player
struct BlockCtx {
    double sr{48000.0};
    float breath{1.0F};      // SILVETON_AUDIT_V1: the breath controller 0..1 when the Upper takes it (else 1)
    float dt{0.001F};        // seconds of this block
    float wheel{0.0F};       // CC1 0..1
    float soft{0.0F};        // CC67 0..1
    float pedal{0.0F};       // the damper controller 0..1 (raw, for the half pedal)
    float velNorm{1.0F};
    int key{60};
    bool keyHeld{true};
    bool sustained{false};   // the key is up and the pedal keeps the note
};

struct EngineBus;

// SILVETON_STR1_REAL_V1: our own sketch of how each wind is voiced - the strength of the harmonics of its tone (not a copy of anything):
// a tilt in dB per octave of harmonic number, a corner above which the harmonics fall steeply (higher when played loud), and a few
// broad formants of the bell and the bore. Plus how the note starts: flat by SCOOP cents, a little too strong (OVER), the tongue (CHIFF).
struct WindVoicing {
    float h1Db, slope, fcSoft, fcLoud;
    float fHz[3], fQ[3], fDb[3];
    float scoopCents, over, chiff, noiseLoHz, noiseHiHz, outDb;
};
// The phase of each harmonic (spread like a slow sweep) so that the many harmonics do not all peak at the same instant: the same tone,
// the same strength of every harmonic, but a smooth wave instead of a sharp spike (the sharp spike is what ate the loudness).
struct WindPhases {
    std::array<float, 40> c{}, s{};
    WindPhases() noexcept {
        for (std::size_t h = 0; h < c.size(); ++h) {
            const double hh = static_cast<double>(h + 1U);
            const double ph = 3.14159265358979323846 * 0.9 * hh * hh / 40.0;
            c[h] = static_cast<float>(std::cos(ph)); s[h] = static_cast<float>(std::sin(ph));
        }
    }
};
inline const WindPhases& windPhases() noexcept { static const WindPhases t; return t; }
// SILVETON_STR1_REAL_V1: how loud the pluck of its own is, by key. Measured: before, a note at velocity 100 peaked at only 0.05 - 0.18
// (the string itself is quiet); this lifts it so that it peaks at about 0.45, like the other engines. dB at the keys 36, 48, 60, 72, 84, 96.
inline float pluckKeyGainDb(int inst, int style, int key) noexcept {
    static const float guitar[6] = {8.0F, 9.0F, 10.0F, 10.5F, 12.5F, 15.0F};
    static const float harp[6]   = {14.0F, 15.5F, 18.0F, 16.5F, 18.5F, 22.0F};
    static const float violin[6] = {11.0F, 11.5F, 13.0F, 13.5F, 14.5F, 17.0F};
    static const float cello[6]  = {15.5F, 17.5F, 19.5F, 18.5F, 22.0F, 27.0F};
    const float* t = inst == silveton::sampler::ST_HARP ? harp : inst == silveton::sampler::ST_VIOLIN ? violin : inst == silveton::sampler::ST_CELLO ? cello : guitar;
    const float x = std::clamp((static_cast<float>(key) - 36.0F) / 12.0F, 0.0F, 5.0F);
    const int i = std::min(static_cast<int>(x), 4);
    const float styleDb = (inst == silveton::sampler::ST_GUITAR && style == 1 ? 4.0F : 0.0F) + (inst == silveton::sampler::ST_HARP && style == 3 ? -5.0F : 0.0F);   // FINGER was quiet, HARMONICS hot
    return t[i] + (t[i + 1] - t[i]) * (x - static_cast<float>(i)) + styleDb;
}
inline const WindVoicing& windVoicingOf(int inst) noexcept {
    static const WindVoicing alto   {-2.0F, 5.5F, 2200.0F, 4800.0F, {850.0F, 1900.0F, 3300.0F}, {1.2F, 1.5F, 2.0F}, {5.0F, 3.0F, 1.0F}, 18.0F, 0.20F, 0.50F, 1500.0F, 6000.0F, 3.5F};
    static const WindVoicing tenor  {-2.0F, 6.0F, 1800.0F, 4000.0F, {600.0F, 1400.0F, 2600.0F}, {1.2F, 1.5F, 2.0F}, {5.0F, 3.0F, 1.0F}, 18.0F, 0.20F, 0.50F, 1200.0F, 5000.0F, 4.5F};
    static const WindVoicing trumpet{-5.0F, 3.5F, 2600.0F, 9000.0F, {1200.0F, 2600.0F, 4200.0F}, {1.3F, 1.5F, 2.0F}, {5.0F, 3.0F, 1.0F}, 25.0F, 0.25F, 0.60F, 2000.0F, 8000.0F, 2.0F};
    static const WindVoicing kaval  { 0.0F, 13.0F, 2500.0F, 3500.0F, {900.0F, 2200.0F, 4000.0F}, {1.5F, 1.5F, 2.0F}, {2.0F, 0.0F, 0.0F}, 8.0F, 0.10F, 0.30F, 2500.0F, 8000.0F, 4.5F};
    static const WindVoicing gaida  {-4.0F, 1.8F, 5500.0F, 9500.0F, {1700.0F, 3200.0F, 5200.0F}, {1.3F, 1.6F, 2.0F}, {6.0F, 4.0F, 1.0F}, 0.0F, 0.05F, 0.20F, 1800.0F, 7000.0F, 1.0F};
    switch (inst) {
        case silveton::sampler::ST_SAX_ALTO: return alto;
        case silveton::sampler::ST_SAX_TENOR: return tenor;
        case silveton::sampler::ST_TRUMPET: return trumpet;
        case silveton::sampler::ST_KAVAL: return kaval;
        default: return gaida;
    }
}

// ---------------------------------------------------------------------------------------------------------------
struct EngineVoice {
    static constexpr int kStringMax = 4096;   // one period down to 23 Hz at 96 kHz (a power of two: the index is masked)
    static constexpr int kStringMask = kStringMax - 1;
    static constexpr int kPickMax = 2048;
    static constexpr int kPickMask = kPickMax - 1;

    silveton::sampler::EngineType type{silveton::sampler::EngineType::Off};
    bool live{false};            // the Upper's ENGINE is on and is still the one this note started with
    bool startedLive{false};     // the ENGINE was on when the note started (a note started with ENGINE OFF stays plain)
    bool recEnded{false};        // the recording ran out; the engine's own generators keep the note (holdsAfterEnd)
    double syncHome{0.0};        // AL-1 SYNC: where the recording restarts (the note's start; a looped recording restarts at its loop)
    float keyHz{440.0F};
    int key{60};
    double inc0{0.0};            // cycles per sample of the key, when the recording has no known period
    std::uint32_t rng{0x51ED1234U};
    float random{0.0F};
    std::array<double, 4> anPh{}, anRate{0.31, 0.83, 0.23, 0.57};   // SILVETON_BODY_V1: ANALOG - four slow wanderers of this note (pitch, brightness)
    float velNorm{1.0F};
    bool keyDown{true};
    // per-block modulation results (read by the voice loop as constants of the block)
    float egF{0.0F};             // filter envelope 0..1
    float cutOct{0.0F};          // to the main filter
    float resAdd{0.0F};          // MS-20 patch: to the LP peak
    float pitchSemis{0.0F};      // to the pitch
    float ampMul{1.0F};          // to the level
    float pedalGain{1.0F};       // SGX half pedal (persistent)
    float fmNow{0.0F};           // PCM FM depth of this block (AL-1)
    float panOffset{0.0F};       // SGX key position
    float lfoNow{0.0F};
    float lfoRateMul{1.0F};
    float pwNow{0.5F};           // pulse width of this block (oscillators)
    Adsr feg{};
    Adsr menv{};                 // MOD-7 modulator envelope
    Dar eg1{};
    double lfoPhase{0.0};
    float lfoHold{0.0F};
    bool lfoNew{true};
    // the main filter (used instead of the sampler's own while the engine is live)
    int filtKind{0};             // 0 SVF LP (clean / LP12) 1 ladder 2 Korg35 LP 3 SVF HP 4 SVF BP
    float filtHz{1000.0F}, filtRes{0.0F};
    Ladder4 ladder{};
    SkFilter sk{};
    StateVariableFilter svf{};
    // MS-20
    SkFilter hpf{};
    float hpfHz{20.0F}, hpfRes{0.0F};
    bool hpfOn{false};
    bool msParallel{false};
    float msHpL{0.0F}, msHpR{0.0F};
    float espEnv{0.0F};          // the envelope follower of the recording (ESP)
    float shHold{0.0F};
    double shPhase{0.0};
    // oscillators (AL-1: 1 and 2; POLYSIX: osc + square sub; MS-20: VCO 1 and 2)
    Osc osc1{}, osc2{}, osc3{};
    double pwmPhase{0.0};
    // the PCM FM / ring of AL-1, the V1 ring of MOD-7
    double op2Phase{0.0}, ringPhase{0.0};
    float ringNow{0.0F};
    // SILVETON_ENGINES_V3: with no recording, the PCM knobs work on the engine's own sound (AL-1 FM / RING / SYNC / SUB,
    // MOD-7 operator 1 = a sine, POLYSIX SUB = the square)
    double alFmPh{0.0}, alSyncPh{0.0}, op1Ph{0.0};
    float alFmLast{0.0F};
    float m7Pm0{0.0F};
    // MOD-7 operators 2..6 (index 1..5; 0 = the recording)
    std::array<double, 6> opPh{};
    std::array<float, 6> opOut{};
    std::array<float, 6> opIdx{};      // modulation index (cycles) or carrier amplitude of this block
    std::array<float, 6> opRatio{};
    std::array<int, 6> opWave{};       // SILVETON_ENGINES_V3: 0 = sine, 1.. = a table wave
    float carrierSum{0.0F};
    float fbNow{0.0F};
    float pegNow{0.0F};
    // AL-1 noise, sync
    Pole noiseLp{};
    double syncPhase{0.0};
    double syncOldPos{0.0};
    int syncXfade{0};
    // STR-1 string
    std::array<float, kStringMax> str{};
    std::array<float, kPickMax> pick{};
    int strW{0}, pickW{0};
    double strLen{100.0};        // fractional delay in samples
    float strG{0.99F};           // loop gain per pass
    float strLpA{0.5F};          // loop damping coefficient
    float strApA{0.0F};          // dispersion allpass coefficient
    float strLpZ{0.0F}, strApX{0.0F}, strApY{0.0F}, strFbZ{0.0F};
    double strComp{1.0};         // what the loop filters delay (subtracted from the period: the pitch stays exact)
    double strTune{1.0};         // STRING TUNE as a factor
    double strInc{0.0};          // the key's cycles per sample the length was made for (pitch bend / glide follow it)
    double strAgeSec{0.0};
    int pluckLeft{0};
    float pluckGain{0.0F}, pluckA{0.5F};
    Pole pluckLp{};
    // SILVETON_ENGINES_V3: the INSTRUMENT / STYLE of this note, and the bow - two waveguides that meet at the bow (str = the
    // neck side, pick = the bridge side), a friction curve with a stick / slip memory decides the force; twice the sample rate
    int strInst{0}, strStyle{0};
    float strPick{0.13F};        // the pick position of this note (the STYLE can move it)
    bool bowOn{false};
    bool bowSlip{false};
    float bowEnv{0.0F};
    float bowVb{0.3F};           // the bow speed of this note (= its level)
    float bowK{0.7F};            // the bow force as a part of the largest force that still keeps the Helmholtz motion
    float bowLpZ{0.0F}, bowLpA{0.8F}, bowDlp{0.25F};
    float bowG{0.999F};
    float bowDecay{1.0F};        // s
    float bowAttC{0.01F}, bowRelC{0.01F}, bowSpicOnC{0.1F}, bowSpicOffC{0.01F};
    double bowN{0.0};            // the period at the bow's rate (twice the sample rate)
    Pole bowNoiseLp{}, bowHairLp{};
    float bowDriftA{0.002F};     // the slow drift of the arm (about 15 Hz)
    float bowOutZ1{0.0F}, bowOutZ2{0.0F}, bowOutA{0.6F};
    double bowTime{0.0}, tremPh{0.0}, vibPh{0.0}, bowPh{0.0};
    // SILVETON_ENGINES_V3: the winds - a reed (SAX / CLARINET / GAIDA), the lips (TRUMPET) or an air jet (KAVAL) blowing into
    // a bore (str = the bore; pick = the second part of the conical bore / the jet). Our own simple physical models.
    bool windOn{false};
    int windModel{0};            // 0 reed + cylinder (clarinet) 1 reed + cone (with a recording) 2 voiced tone (SAX, TRUMPET, KAVAL, GAIDA alone)
    bool windNoRec{false};       // SILVETON_STR1_REAL_V1: no recording plays under the note
    static constexpr int kWH = 40;
    std::array<float, kWH> whA{}, whB{}, whTA{}, whTB{};   // the harmonics of the voiced tone (strength x its phase, as cos / sin parts): now / wanted
    int whCount{0}, whGroups{0}, whTickN{0};                // how many harmonics are wanted, how many groups of 4 run, the counter of the slow update
    float whScoopE{1.0F}, whOverE{1.0F}, whChiffE{1.0F}, whScoopK{1.0F}, whOverK{1.0F}, whChiffK{1.0F};   // the start of the note: fading by themselves
    double whPh{0.0};
    Pole whJit{}, whFlt{}, whNzLo{}, whNzHi{};
    float whALo{0.1F}, whAHi{0.3F}, whOutG{1.0F};
    float windLpZ{0.0F}, windLpA{0.7F}, windDlp{0.4F};
    float windOff{0.7F}, windSlope{-0.3F};
    float windPm{0.8F};          // the blowing pressure of the note
    float windAir{0.1F}, windGrowl{0.0F};
    float windDcX{0.0F}, windDcY{0.0F}, windLipX{0.0F}, windLipY{0.0F}, windX1{0.0F}, windX2{0.0F};
    float windStyleMul{1.0F}, windGainBase{0.6F}, windPmTarget{0.8F}, windGainTarget{0.5F};   // SILVETON_AUDIT_V1: the live breath
    float windOutGain{1.0F};
    float windZeta{0.55F}, windTrackK{16.0F}, windDampNow{0.3F}, windConeLa{0.5F};
    double windConeF{-1.0}, windConeN{100.0};   // SILVETON_STR1_FIX_V1: the cone - the reed opening, the bore losses (x the pitch)
    double windJet{1.0};         // the register: 2 = KAVAL OVERBLOW
    double growlPh{0.0};
    Modal windLip{};
    // CX-3 (the wheels themselves live in the EngineBus)
    std::array<int, 9> twWheel{};
    std::array<float, 9> twLevel{};
    std::array<float, 9> twTarget{};   // SILVETON_AUDIT_V1: where the drawbar levels glide to (no zipper, no click)
    int percWheel{-1};
    float percEnv{0.0F}, percCoef{0.0F}, percGain{0.0F};
    float clickEnv{0.0F}, clickCoef{0.0F};
    Pole clickLp{};
    float leakLevel{0.0F};
    // SGX / EP noises and colour
    float hammerEnv{0.0F}, hammerCoef{0.0F};
    float keyOffEnv{0.0F}, keyOffCoef{0.0F};
    bool keyOffDone{false};
    StateVariableFilter keyOffBp{};
    Pole brightL{}, brightR{};
    float brightA{1.0F};
    Pole bellL{}, bellR{};
    float bellGain{0.0F}, barkDrive{0.0F};
    // EP tine model: three damped partials and the pickup
    std::array<Modal, 3> tine{};
    std::array<double, 3> tineRatio{{1.0, 2.0, 3.0}};
    double tineInc{0.0};         // the key's cycles per sample the tine is tuned to now (pitch bend / glide retune it)
    int tineHit{0};
    float epDcX{0.0F}, epDcY{0.0F}, epDcR{0.9995F};   // SILVETON_AUDIT_V1: the DC blocker after the pickup
    float tineExc{0.0F};
    Pole tineLp{};
    float tineLpA{1.0F};

    // -------------------------------------------------------------- note on / off
    // hasRecording: a recording of the Upper plays under the note (false = the silent carrier of an Upper with no sound)
    void noteOn(const silveton::sampler::EngineParams& e, double sr, float hz, float vel, float rnd, double periodFrames, std::uint32_t seed, bool percAllowed,
                bool hasRecording = true) noexcept {
        using namespace silveton::sampler;
        type = e.type;
        live = e.on();
        startedLive = live;
        recEnded = false;
        keyHz = std::max(1.0F, hz);
        key = std::clamp(static_cast<int>(std::lround(69.0 + 12.0 * std::log2(static_cast<double>(keyHz) / 440.0))), 0, 127);
        inc0 = static_cast<double>(keyHz) / std::max(1.0, sr);
        (void)periodFrames;
        rng = seed | 1U;
        random = rnd;
        velNorm = std::clamp(vel, 0.0F, 1.0F);
        keyDown = true;
        feg = Adsr{}; feg.on();
        menv = Adsr{}; menv.on();
        eg1 = Dar{}; eg1.on();
        lfoPhase = 0.0; lfoNew = true; lfoHold = 0.0F; lfoRateMul = 1.0F;
        filtKind = 0; ladder.prime = true; sk.reset(); svf.reset();
        hpf.reset(); hpf.high = true; hpfOn = false; msParallel = false; msHpL = msHpR = 0.0F; espEnv = 0.0F; shHold = 0.0F; shPhase = 0.0;
        const double startPh = e.p[E_ANALOG] > 0.0F ? static_cast<double>(noise(rng)) * 0.5 + 0.5 : 0.0;
        osc1.reset(startPh); osc2.reset(startPh * 0.37); osc3.reset(0.0); pwmPhase = 0.0;
        osc1.life(sr, noise(rng), noise(rng)); osc2.life(sr, noise(rng), noise(rng));   // SILVETON_WAVES_LIFE_V1
        osc1.zoneKey = osc2.zoneKey = osc3.zoneKey = key;                                // SILVETON_USER_WAVES_V1
        {   // SILVETON_BODY_V1: every note wanders on its own - other phases, other speeds (about a quarter either way)
            static constexpr std::array<double, 4> base{0.31, 0.83, 0.23, 0.57};
            for (std::size_t i = 0; i < 4U; ++i) { anPh[i] = static_cast<double>(noise(rng)) * 0.5 + 0.5; anRate[i] = base[i] * (1.0 + 0.25 * static_cast<double>(noise(rng))); }
        }
        op2Phase = ringPhase = 0.0; ringNow = 0.0F;
        alFmPh = alSyncPh = op1Ph = 0.0; alFmLast = 0.0F; m7Pm0 = 0.0F;
        opPh.fill(0.0); opOut.fill(0.0F); opIdx.fill(0.0F); opRatio.fill(1.0F); carrierSum = 0.0F; fbNow = 0.0F;
        noiseLp = Pole{};
        syncPhase = 0.0; syncXfade = 0;
        egF = cutOct = resAdd = pitchSemis = 0.0F; ampMul = 1.0F; pedalGain = 1.0F; fmNow = 0.0F; panOffset = 0.0F; pwNow = 0.5F;
        percEnv = clickEnv = hammerEnv = keyOffEnv = 0.0F; keyOffDone = false; percWheel = -1;
        pegNow = 0.0F;
        pluckLeft = 0; pluckGain = 0.0F; pluckLp = Pole{};
        tineHit = 0; tineExc = 0.0F; tineLp = Pole{};
        if (!live) return;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::Str1: {
                std::fill(str.begin(), str.end(), 0.0F); std::fill(pick.begin(), pick.end(), 0.0F);
                strW = pickW = 0; strLpZ = strApX = strApY = strFbZ = 0.0F; strAgeSec = 0.0;
                // SILVETON_ENGINES_V3: the instrument and the way it is played
                strInst = std::clamp(static_cast<int>(std::lround(p[ST_BODY_TYPE])), 0, kStr1Instruments - 1);
                strStyle = std::clamp(static_cast<int>(std::lround(p[ST_STYLE])), 0, 3);
                bowOn = str1Bowed(e) && engineOwnOn(e);
                windOn = str1Wind(e) && engineOwnOn(e);
                setString(e, sr);
                if (bowOn) { startBow(e, sr); break; }
                windNoRec = !hasRecording || !engineRecOn(e);   // SILVETON_STR1_REAL_V1
                if (windOn) { startWind(e, sr); break; }
                if (strInst >= ST_SAX_ALTO) break;   // a wind with ЗВУК ОТ = СЕМПЪЛ: the plain string on the recording
                float pl = engineOwnOn(e) ? std::clamp(p[ST_PLUCK], 0.0F, 1.0F) : 0.0F;
                // SILVETON_STR1_FIX_V1: nothing else moves the string when no recording plays into it (an Upper with no sound, or
                // ЗВУК ОТ = СОБСТВЕН): PLUCK = 0 then means a pluck of its own at 0.8 - before, GUITAR / HARP / PIZZ were silent
                if (pl <= 0.0F && engineOwnOn(e) && (!hasRecording || !engineRecOn(e))) pl = 0.8F;
                if (pl > 0.0F) {
                    const StrStyle m = strStyleOf(strInst, strStyle);
                    pluckLeft = static_cast<int>(std::clamp(strLen * static_cast<double>(m.pluckPeriods), 2.0, 4000.0));   // a period or so of noise, as a pluck
                    pluckGain = pl * (0.3F + 0.7F * velNorm) * 0.5F / std::sqrt(m.pluckPeriods);
                    if (!hasRecording || !engineRecOn(e)) pluckGain *= std::pow(10.0F, pluckKeyGainDb(strInst, strStyle, key) / 20.0F);   // SILVETON_STR1_REAL_V1: alone it is as loud as the others
                    float hzc = std::clamp(p[ST_PLUCK_COLOR] * m.colorMul, 200.0F, 16000.0F) * (0.5F + 0.5F * velNorm);
                    if (m.colorMul < 1.0F) hzc = std::max(hzc, 4.0F * keyHz * static_cast<float>(m.tuneMul));   // a soft finger still carries the note's own pitch
                    pluckA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::min(hzc, 16000.0F) / static_cast<float>(sr));
                }
                break;
            }
            case EngineType::CX3: {
                // the nine footages of a drawbar organ, as steps from the key: 16' 5⅓' 8' 4' 2⅔' 2' 1⅗' 1⅓' 1'
                static const int steps[9] = {-12, 7, 0, 12, 19, 24, 28, 31, 36};
                const bool percOn = p[CX_PERC] >= 0.5F;
                const bool fold = p[CX_FOLDBACK] >= 0.5F;
                for (int k = 0; k < 9; ++k) {
                    int w = key - 24 + steps[k];   // wheel 0 = C1 (the 8' of the lowest key C2 is wheel 12)
                    if (fold) { while (w < 0) w += 12; while (w > 90) w -= 12; }
                    twWheel[static_cast<std::size_t>(k)] = (w >= 0 && w <= 90) ? w : -1;
                }
                drawbarLevels(p);
                twLevel = twTarget;   // a new note starts at its levels
                if (percOn && percAllowed) {
                    const int partial = p[CX_PERC] >= 1.5F ? 4 : 3;   // 3rd = 2⅔', 2nd = 4'
                    percWheel = twWheel[static_cast<std::size_t>(partial)];
                    const float decaySec = p[CX_PERC_DECAY] >= 0.5F ? 0.9F : 0.3F;
                    percCoef = std::exp(-1.0F / (decaySec * static_cast<float>(sr)) * 4.6F);
                    percGain = p[CX_PERC_LEVEL] >= 0.5F ? 1.0F : 0.5F;
                    percEnv = 1.0F;
                }
                clickEnv = std::clamp(p[CX_CLICK], 0.0F, 1.0F) * 0.9F;
                clickCoef = std::exp(-1.0F / (0.004F * static_cast<float>(sr)));
                leakLevel = std::clamp(p[CX_LEAK], 0.0F, 1.0F) * 0.02F;
                break;
            }
            case EngineType::SGX: {
                hammerEnv = std::clamp(p[SG_HAMMER], 0.0F, 1.0F) * velNorm * velNorm * 0.8F;
                hammerCoef = std::exp(-1.0F / (0.005F * static_cast<float>(sr)));
                keyOffCoef = std::exp(-1.0F / (0.035F * static_cast<float>(sr)));
                // the brightness of the hit: a soft note is darker
                const float vb = std::clamp(p[SG_VEL_BRIGHT], 0.0F, 1.0F);
                const float hz2 = 20000.0F * std::pow(0.12F + 0.88F * velNorm, 1.5F * vb);
                brightA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::clamp(hz2, 300.0F, 20000.0F) / static_cast<float>(sr));
                brightL = Pole{}; brightR = Pole{};
                panOffset = std::clamp(static_cast<float>(key - 60) / 36.0F, -1.0F, 1.0F) * std::clamp(p[SG_WIDTH], 0.0F, 1.0F);
                break;
            }
            case EngineType::EP: {
                bellGain = std::clamp(p[EP_BELL], 0.0F, 1.0F) * velNorm * velNorm * 2.5F;
                barkDrive = std::clamp(p[EP_BARK], 0.0F, 1.0F) * velNorm * velNorm * 3.0F;
                bellL = Pole{}; bellR = Pole{};
                keyOffCoef = std::exp(-1.0F / (0.025F * static_cast<float>(sr)));
                const float gen = std::clamp(p[EP_MODEL], 0.0F, 1.0F);
                (void)gen;
                setTine(e, sr);   // SILVETON_AUDIT_V1: always (TINE GEN raised under a held note brings the ringing tine in)
                epDcX = epDcY = 0.0F;
                epDcR = static_cast<float>(1.0 - 2.0 * kPi * 8.0 / sr);
                break;
            }
            case EngineType::HD1: pegNow = p[HD_PEG_CENTS] * 0.01F * (1.0F - std::clamp(p[HD_PEG_VEL], 0.0F, 1.0F) * (1.0F - velNorm)); break;
            case EngineType::Mod7: pegNow = p[M7_PEG]; break;
            default: break;
        }
    }

    void noteOff() noexcept {
        keyDown = false;
        feg.off();
        menv.off();
        eg1.off();
        // the key-off noises of the organ, the piano and the EP
        if (!keyOffDone) { keyOffDone = true; keyOffEnv = 1.0F; }
    }

    // CX-3: the level of every footage from its drawbar (SILVETON_AUDIT_V1: also every block - pulling a drawbar moves the
    // notes that are held, as on the organ); a level change glides in the voice loop
    void drawbarLevels(const float* p) noexcept {
        using namespace silveton::sampler;
        const bool percOn = p[CX_PERC] >= 0.5F;
        for (int k = 0; k < 9; ++k) {
            float db = p[CX_DB16 + k];
            if (percOn && k == 8) db = 0.0F;   // the 1' drawbar is borrowed by the percussion (as on the B-3)
            twTarget[static_cast<std::size_t>(k)] = db <= 0.0F ? 0.0F : std::pow(10.0F, (db - 8.0F) * 3.0F / 20.0F);
        }
    }

    // does the engine keep the note alive after a one-shot recording ran out (it has a sound of its own)
    [[nodiscard]] bool holdsAfterEnd(const silveton::sampler::EngineParams& e) const noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        // SILVETON_AUDIT_V1: ЗВУК ОТ = СЕМПЪЛ - no generator plays: nothing to hold (STR-1: the string still rings out)
        if (!engineOwnOn(e) && type != EngineType::Str1) return false;
        switch (type) {
            case EngineType::CX3: return true;
            case EngineType::Str1: return true;
            case EngineType::AL1: return (p[AL_OSC1_WAVE] >= 0.5F && p[AL_OSC1_LEVEL] > 0.0F) || (p[AL_OSC2_WAVE] >= 0.5F && p[AL_OSC2_LEVEL] > 0.0F) || p[AL_NOISE_LEVEL] > 0.0F;
            case EngineType::Polysix: return p[P6_OSC] >= 0.5F && p[P6_OSC_LEVEL] > 0.0F;
            case EngineType::MS20: return (p[MS_VCO1_WAVE] >= 0.5F && p[MS_VCO1_LEVEL] > 0.0F) || (p[MS_VCO2_WAVE] >= 0.5F && p[MS_VCO2_LEVEL] > 0.0F);
            case EngineType::Mod7: return ((algoOf(static_cast<int>(std::lround(p[M7_ALGO]))).carrier & 0x3EU) != 0U && p[M7_OP_LEVEL] > 0.0F) || p[M7_PCM_LEVEL] > 0.0F;
            case EngineType::EP: return p[EP_MODEL] > 0.0F;
            default: return false;
        }
    }

    void setString(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const StrStyle m = strStyleOf(strInst, strStyle);   // SILVETON_ENGINES_V3
        strPick = m.pick >= 0.0F ? m.pick : std::clamp(p[ST_PICK], 0.02F, 0.5F);
        const double hz = static_cast<double>(keyHz) * std::pow(2.0, static_cast<double>(p[ST_TUNE]) / 1200.0) * m.tuneMul;
        const float disp = std::clamp(p[ST_DISP], 0.0F, 1.0F);
        strApA = -0.55F * disp;                                   // first-order allpass: negative = the highs arrive earlier (stiff string)
        const double apDelay = (1.0 - static_cast<double>(strApA)) / (1.0 + static_cast<double>(strApA));
        const float damp = std::max(std::clamp(p[ST_DAMP], 0.0F, 1.0F) * m.dampMul, m.dampMin);
        // SILVETON_STR1_REAL_V1: a plucked string loses its highs with TIME, not with every round: the low-pass of one round is
        // stronger for a low note (long round) and weaker for a high one (short round). Before, at 96 kHz the low notes lost almost nothing
        // (the buzzing, never-dulling tone) and the high notes lost it all at once. 262 Hz (C4) is unchanged.
        float lossLp = 0.85F * damp;
        if (!bowOn && !windOn && strInst < ST_SAX_ALTO) lossLp = std::min(lossLp * std::clamp(262.0F / static_cast<float>(hz), 0.15F, 3.5F), 0.88F);
        strLpA = 1.0F - lossLp;                                   // loop low-pass
        const double lpDelay = (1.0 - static_cast<double>(strLpA)) / static_cast<double>(strLpA);   // SILVETON_AUDIT_V1: the one-pole's real delay
        // pitch compensation: the loop delay is the period minus what the two filters delay at low frequencies
        // SILVETON_AUDIT_V1: the loop is the read delay + what the two filters delay (was 1 sample too much and half the low-pass:
        // the string played sharp, up to +20 cents at E6 - measured)
        strComp = apDelay + lpDelay;
        strTune = std::pow(2.0, static_cast<double>(p[ST_TUNE]) / 1200.0) * m.tuneMul;
        strInc = static_cast<double>(keyHz) / sr;
        strLen = std::clamp(sr / std::max(20.0, hz) - strComp, 4.0, static_cast<double>(kStringMax - 4));
        float decay = std::clamp(p[ST_DECAY], 0.05F, 20.0F) * m.decayMul;
        decay *= std::pow(2.0F, -static_cast<float>(key - 48) / 24.0F * std::clamp(p[ST_KEY_DECAY], 0.0F, 1.0F));
        bowDecay = std::max(decay, 0.05F);
        strG = std::exp(-6.9F * static_cast<float>(strLen / sr) / decay);
        // the loop gain check: the damping low-pass never exceeds 1, the allpass is exactly 1, the soft limiter's slope is
        // at most 1 - so the gain round the loop is at most strG, which stays below 1
        strG = std::min(strG, 0.9995F);
    }

    void setTine(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const bool reed = p[EP_TYPE] >= 0.5F;
        const float inh = std::clamp(p[EP_INHARM], 0.0F, 1.0F);
        const float hammer = std::clamp(p[EP_HAMMER], 0.0F, 1.0F);
        float dec = std::clamp(p[EP_TINE_DECAY], 0.3F, 15.0F);
        dec *= std::pow(2.0F, -static_cast<float>(key - 60) / 24.0F);   // the high tines die sooner
        // partial ratios: the tine's fundamental, its second mode (a little sharp of the octave) and the bell mode
        const double r2 = reed ? 2.0 : 2.0 * (1.0 + 0.06 * inh);
        const double r3 = reed ? 3.0 * (1.0 + 0.02 * inh) : 6.27 * (0.7 + 0.3 * inh) ;
        const float v = velNorm;
        const float bright = 0.25F + 0.75F * hammer * v;
        tineRatio = {{1.0, r2, r3}};
        tineInc = static_cast<double>(keyHz) / sr;
        tine[0].set(sr, keyHz, dec, 1.0F, true);
        tine[1].set(sr, keyHz * r2, dec * (reed ? 0.7 : 0.45), (reed ? 0.35F : 0.25F) * bright, true);
        tine[2].set(sr, keyHz * r3, dec * 0.2, (reed ? 0.15F : 0.3F) * bright * v, true);
        for (auto& m : tine) m.reset();
        tineHit = 3;
        tineExc = (0.3F + 0.7F * v) * 0.25F;   // 3 samples: an area of about 0.75 at full strength -> the tine rings at about 0.75
        const float hzLp = 800.0F + 12000.0F * hammer * v;
        tineLpA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::min(hzLp, 16000.0F) / static_cast<float>(sr));
    }

    // -------------------------------------------------------------- once per block
    void block(const silveton::sampler::EngineParams& e, const BlockCtx& c) noexcept {
        using namespace silveton::sampler;
        if (!e.on()) { cutOct = pitchSemis = resAdd = 0.0F; ampMul = 1.0F; return; }
        const float* p = e.p.data();
        // the filter envelope (the common ADSR)
        egF = feg.step(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], c.dt);
        // the LFO
        {
            const double rate = std::clamp(static_cast<double>(p[E_LFO_RATE] * lfoRateMul), 0.02, 60.0);
            const double before = lfoPhase;
            lfoPhase += rate * c.dt; lfoPhase -= std::floor(lfoPhase);
            const int wave = static_cast<int>(std::lround(p[E_LFO_WAVE]));
            const float ph = static_cast<float>(lfoPhase);
            switch (wave) {
                case 1: lfoNow = 1.0F - 4.0F * std::fabs(ph - 0.5F); break;
                case 2: lfoNow = 2.0F * ph - 1.0F; break;
                case 3: lfoNow = ph < 0.5F ? 1.0F : -1.0F; break;
                case 4: if (lfoNew || lfoPhase < before) { lfoHold = noise(rng); lfoNew = false; } lfoNow = lfoHold; break;
                default: lfoNow = sin01(lfoPhase); break;
            }
        }
        lfoRateMul = 1.0F;
        // SILVETON_AUDIT_V1: the live parts of CX-3 (drawbars) and of the STR-1 winds (breath, embouchure, the breath controller)
        if (type == EngineType::CX3) drawbarLevels(p);
        if (type == EngineType::Str1 && windOn) {
            const float emb = std::clamp(p[ST_BOW_PRESS], 0.0F, 1.0F);
            const float velAmt = std::clamp(p[ST_VEL_BOW], 0.0F, 1.0F);
            const float b = std::clamp(p[ST_BOW_SPEED], 0.0F, 1.0F) * (1.0F - velAmt * (1.0F - velNorm)) * windStyleMul;
            const float ctl = std::clamp(c.breath, 0.0F, 1.0F);
            windOff = 0.74F - 0.06F * emb;
            windSlope = -0.28F - 0.12F * emb;
            if (windModel == 2) {   // SILVETON_STR1_REAL_V1: the voiced tone follows the breath and the breath controller
                windAddSet(emb, b, ctl, windDampNow, c.sr);
                windPmTarget = windPm;
            } else if (windModel == 1) {   // SILVETON_STR1_FIX_V1: the cone keeps the glide - set the targets, then put the glided values back
                const float pmNow = windPm, gainNow = windOutGain;
                windConeSet(emb, b, ctl, windDampNow);
                windPmTarget = windPm; windGainTarget = windOutGain;
                windPm = pmNow; windOutGain = gainNow;
            } else {
            // below about a third of the controller the reed no longer speaks (a natural threshold), above it the pressure swells
            windPmTarget = (0.62F + (0.17F - 0.03F * emb) * b) * (0.55F + 0.45F * ctl);
            windGainTarget = windGainBase * (0.35F + 0.65F * b);
            }
        }
        cutOct = p[E_FEG_AMT] * egF + p[E_LFO_CUT] * lfoNow;
        resAdd = 0.0F;
        pitchSemis = p[E_LFO_PITCH] * 0.01F * lfoNow;
        {   // SILVETON_BODY_V1: ANALOG - the pitch (up to 6 cents) and the brightness (up to a quarter of an octave) never stand still
            const float an = std::clamp(p[E_ANALOG], 0.0F, 1.0F);
            for (std::size_t i = 0; i < 4U; ++i) { anPh[i] += anRate[i] * static_cast<double>(c.dt); anPh[i] -= std::floor(anPh[i]); }
            if (an > 0.0F) {
                const float dPitch = 0.6F * sin01(anPh[0]) + 0.4F * sin01(anPh[1]);
                const float dBright = 0.6F * sin01(anPh[2]) + 0.4F * sin01(anPh[3]);
                pitchSemis += dPitch * an * 0.06F;
                cutOct += dBright * an * 0.25F;
            }
        }
        ampMul = std::max(0.0F, 1.0F - std::clamp(p[E_LFO_AMP], 0.0F, 1.0F) * (0.5F - 0.5F * lfoNow));
        fmNow = 0.0F;
        switch (type) {
            case EngineType::MS20: {
                const float g1 = eg1.step(p[MS_EG1_DELAY], p[MS_EG1_ATTACK], p[MS_EG1_RELEASE], c.dt);
                pitchSemis += p[MS_EG1_PITCH] * g1;
                float hpfOct = p[MS_EG1_HPF] * g1 + p[MS_MG_HPF] * lfoNow;
                float hpfResAdd = 0.0F;
                float pwAdd = 0.0F;
                const int to = static_cast<int>(std::lround(p[MS_WHEEL_TO]));
                const float wa = std::clamp(p[MS_WHEEL_AMT], 0.0F, 1.0F) * c.wheel;
                if (to == 1) pitchSemis += wa * 12.0F;
                else if (to == 2) cutOct += wa * 4.0F;
                else if (to == 3) hpfOct += wa * 4.0F;
                else if (to == 4) ampMul *= 1.0F - 0.9F * wa;
                // the patch panel: three cables
                shPhase += std::clamp(static_cast<double>(p[MS_SH_RATE]), 0.1, 50.0) * c.dt;
                if (shPhase >= 1.0) { shPhase -= std::floor(shPhase); shHold = noise(rng); }
                const float nz = noise(rng);
                for (int cbl = 0; cbl < 3; ++cbl) {
                    const int src = static_cast<int>(std::lround(p[MS_P1_SRC + 3 * cbl]));
                    const int dst = static_cast<int>(std::lround(p[MS_P1_DST + 3 * cbl]));
                    const float amt = std::clamp(p[MS_P1_AMT + 3 * cbl], -1.0F, 1.0F);
                    if (src <= 0 || amt == 0.0F) continue;
                    float s = 0.0F;
                    switch (src) {
                        case 1: s = g1; break;
                        case 2: s = egF; break;
                        case 3: s = lfoNow; break;
                        case 4: s = c.wheel; break;
                        case 5: s = std::min(1.5F, espEnv * (0.5F + 4.0F * std::clamp(p[MS_ESP_SENS], 0.0F, 1.0F))); break;
                        case 6: s = shHold; break;
                        case 7: s = nz; break;
                        case 8: s = velNorm; break;
                        default: s = static_cast<float>(c.key - 60) / 60.0F; break;
                    }
                    const float a = amt * s;
                    switch (dst) {
                        case 0: pitchSemis += 12.0F * a; break;
                        case 1: cutOct += 4.0F * a; break;
                        case 2: hpfOct += 4.0F * a; break;
                        case 3: ampMul *= std::clamp(1.0F + a, 0.0F, 2.0F); break;
                        case 4: resAdd += a; break;
                        case 5: hpfResAdd += a; break;
                        case 6: lfoRateMul *= std::exp2(2.0F * a); break;
                        default: pwAdd += 0.45F * a; break;
                    }
                }
                hpfHz = std::clamp(p[MS_HPF_CUT] * std::exp2(hpfOct), 20.0F, 20000.0F);
                hpfRes = std::clamp(p[MS_HPF_PEAK] + hpfResAdd, 0.0F, 1.0F);
                msParallel = p[MS_ROUTE] >= 0.5F;
                const bool want = hpfHz > 25.0F || hpfRes > 0.01F || msParallel;
                if (want && !hpfOn) hpf.reset();
                hpfOn = want;
                hpf.high = true;
                hpf.set(hpfHz, hpfRes, c.sr, p[MS_MODEL] >= 0.5F, p[MS_FB_SAT]);
                pwNow = std::clamp(p[MS_PW] + pwAdd, 0.05F, 0.95F);
                break;
            }
            case EngineType::AL1: {
                const float eg = std::clamp(p[AL_FM_EG], 0.0F, 1.0F);
                fmNow = std::clamp(p[AL_FM_AMT], 0.0F, 2.0F) * (1.0F - eg + eg * egF);
                pwNow = std::clamp(p[AL_PW] + std::clamp(p[AL_PWM], 0.0F, 0.45F) * lfoNow, 0.05F, 0.95F);
                break;
            }
            case EngineType::Polysix: {
                pwmPhase += std::clamp(static_cast<double>(p[P6_PWM_RATE]), 0.02, 20.0) * c.dt; pwmPhase -= std::floor(pwmPhase);
                const int osc = static_cast<int>(std::lround(p[P6_OSC]));
                const float base = p[P6_PWM_WIDTH] < 0.02F ? 0.5F : std::clamp(p[P6_PWM_WIDTH], 0.02F, 0.95F);
                const float depth = osc == 3 ? std::max(std::clamp(p[P6_PWM_DEPTH], 0.0F, 0.45F), 0.15F) : std::clamp(p[P6_PWM_DEPTH], 0.0F, 0.45F);
                pwNow = std::clamp(base + depth * sin01(pwmPhase), 0.05F, 0.95F);
                break;
            }
            case EngineType::Mod7: {
                const float bright = std::exp2(std::clamp(p[M7_BRIGHT], -1.0F, 1.0F));
                const float eg = std::clamp(p[M7_FM_EG], 0.0F, 1.0F);
                const float vel = std::clamp(p[M7_FM_VEL], 0.0F, 1.0F);
                const float me = menv.step(p[M7_ENV_A], p[M7_ENV_D], p[M7_ENV_S], p[M7_ENV_R], c.dt);
                const float ea = std::clamp(p[M7_ENV_AMT], 0.0F, 1.0F);
                const float scale = bright * (1.0F - eg + eg * egF) * (1.0F - vel + vel * velNorm) * (1.0F - ea + ea * me);
                const Algo& a = algoOf(static_cast<int>(std::lround(p[M7_ALGO])));
                static const int levelId[6] = {0, M7_OP2_LEVEL, M7_OP3_LEVEL, M7_OP4_LEVEL, M7_OP5_LEVEL, M7_OP6_LEVEL};
                static const int ratioId[6] = {0, M7_OP2_RATIO, M7_OP3_RATIO, M7_OP4_RATIO, M7_OP5_RATIO, M7_OP6_RATIO};
                const float det = std::exp2(std::clamp(p[M7_FINE], -50.0F, 50.0F) / 1200.0F);
                const float opsOut = std::clamp(p[M7_OP_LEVEL], 0.0F, 1.0F);
                for (int i = 1; i < 6; ++i) {
                    const auto ii = static_cast<std::size_t>(i);
                    const float lev = std::clamp(p[levelId[i]], 0.0F, 2.0F);
                    const bool carrier = ((a.carrier >> i) & 1U) != 0U;
                    opIdx[ii] = carrier ? lev * 0.5F * opsOut : lev * 0.75F * scale;   // a carrier: its loudness; a modulator: its index in cycles
                    opRatio[ii] = std::clamp(p[ratioId[i]], 0.25F, 16.0F) * ((i & 1) == 0 ? det : 1.0F);
                    opWave[ii] = std::clamp(static_cast<int>(std::lround(p[M7_OP2_WAVE + i - 1])), 0, silveton::sampler::kTableWaveCount + silveton::sampler::kUserWaveCount);   // SILVETON_USER_WAVES_V1
                }
                fbNow = std::clamp(p[M7_FEEDBACK], 0.0F, 1.0F) * 0.25F;
                const float ms = std::clamp(p[M7_PEG_TIME], 1.0F, 5000.0F);
                pegNow *= std::exp(-c.dt * 1000.0F / ms * 4.6F);
                pitchSemis += pegNow;
                break;
            }
            case EngineType::HD1: {
                const float ms = std::clamp(p[HD_PEG_TIME], 1.0F, 5000.0F);
                pegNow *= std::exp(-c.dt * 1000.0F / ms * 4.6F);
                pitchSemis += pegNow;
                break;
            }
            case EngineType::SGX: {
                // una corda: the left pedal takes some level and brightness
                const float uc = std::clamp(p[SG_UNA_CORDA], 0.0F, 1.0F) * c.soft;
                ampMul *= 1.0F - 0.3F * uc;
                // the half pedal: a key that is up and kept only by the pedal dies as fast as the dampers are let down
                if (p[SG_HALF_PEDAL] >= 0.5F && !c.keyHeld && c.sustained) {
                    const float lift = std::clamp((c.pedal - 0.5F) * 2.0F, 0.0F, 1.0F);   // 1 = the pedal fully down (the dampers are up)
                    const float damperTime = std::clamp(p[SG_DAMPER_TIME], 0.03F, 1.0F);
                    const float closeness = 1.0F - lift * lift;                           // how much the damper touches the string
                    if (closeness > 0.001F) pedalGain *= std::exp(-c.dt / damperTime * closeness);
                }
                ampMul *= pedalGain;
                break;
            }
            default: break;
        }
        // the filters' states never creep into the denormal range
        ladder.guard(); sk.guard(); hpf.guard();
        for (auto& m : tine) m.guard();
    }

    // -------------------------------------------------------------- the main filter (while the engine is live)
    void setMainFilter(const silveton::sampler::EngineParams& e, int kind, float hz, float res, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        if (kind != filtKind) { filtKind = kind; ladder.prime = true; sk.reset(); svf.reset(); }
        filtHz = hz;
        filtRes = std::clamp(res + resAdd, 0.0F, 1.0F);
        switch (kind) {
            case 1: ladder.set(hz, filtRes, sr, type == EngineType::Polysix ? p[P6_FILT_SAT] : 0.3F); break;
            case 2: sk.high = false; sk.set(hz, filtRes, sr, type != EngineType::MS20 || p[MS_MODEL] >= 0.5F, type == EngineType::MS20 ? p[MS_FB_SAT] : 0.5F); break;
            default: break;
        }
    }
    void mainFilter(float& l, float& r, double sr) noexcept {
        switch (filtKind) {
            case 1: ladder.process(l, r); break;
            case 2: sk.process(l, r); break;
            case 3: svf.process(l, r, FilterMode::HighPass, filtHz, filtRes, sr); break;
            case 4: svf.process(l, r, FilterMode::BandPass, filtHz, filtRes, sr); break;
            default: svf.process(l, r, FilterMode::LowPass, filtHz, filtRes, sr); break;
        }
        if (type == silveton::sampler::EngineType::MS20 && msParallel && hpfOn) { l = 0.5F * (l + msHpL); r = 0.5F * (r + msHpR); }
    }

    // -------------------------------------------------------------- per sample, before the recording is read:
    // the phase modulation of the recording, in periods of the key (0 = none). inc = cycles of the key per output sample.
    // (SILVETON_ENGINES_V2: the recording is moved in phase, never read backwards - the read rate stays the clean one.)
    float pmOffset(const silveton::sampler::EngineParams& e, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::AL1: {
                if (fmNow <= 0.0F) return 0.0F;
                op2Phase += inc * static_cast<double>(p[AL_FM_RATIO]);
                return fmNow * 0.5F * sin01(op2Phase);
            }
            case EngineType::Mod7: {
                const Algo& a = algoOf(static_cast<int>(std::lround(p[M7_ALGO])));
                const bool over = p[M7_OVERSAMPLE] >= 0.5F;
                const int passes = over ? 2 : 1;
                const double sub = over ? 0.5 : 1.0;
                float carriers = 0.0F;
                float pcmPm = 0.0F;
                for (int ps = 0; ps < passes; ++ps) {
                    std::array<float, 6> now{};
                    now[0] = 0.0F;
                    for (int i = 5; i >= 1; --i) {
                        const auto ii = static_cast<std::size_t>(i);
                        float pm = 0.0F;
                        const unsigned mask = a.mod[i];
                        if (mask != 0U) {
                            for (int j = 1; j < 6; ++j) {
                                if (((mask >> j) & 1U) == 0U) continue;
                                const auto jj = static_cast<std::size_t>(j);
                                pm += opIdx[jj] * (j > i ? now[jj] : opOut[jj]);   // a cycle uses last sample's value
                            }
                        }
                        if (a.fb == i && fbNow > 0.0F) pm += fbNow * opOut[ii];
                        // ALGO 1 keeps the V1 switch: OP3 -> OP2 or straight to the recording
                        if (i == 1 && &a == &algoOf(0) && p[M7_OP3_TARGET] >= 0.5F) pm -= opIdx[2] * now[2];
                        // SILVETON_ENGINES_V3: the wave of the operator (0 = sine, 1.. = a table wave)
                        const int ow = opWave[ii];
                        now[ii] = ow > 0 ? tabRead(ow - 1, opPh[ii] + static_cast<double>(pm), inc * static_cast<double>(opRatio[ii]) * sub, key)
                                         : sin01(opPh[ii] + static_cast<double>(pm));
                        opPh[ii] += inc * static_cast<double>(opRatio[ii]) * sub;
                        if (opPh[ii] >= 4096.0) opPh[ii] -= std::floor(opPh[ii]);
                    }
                    float cs = 0.0F;
                    for (int i = 1; i < 6; ++i) if (((a.carrier >> i) & 1U) != 0U) cs += opIdx[static_cast<std::size_t>(i)] * now[static_cast<std::size_t>(i)];
                    carriers += cs;
                    float pm0 = 0.0F;
                    for (int j = 1; j < 6; ++j) if (((a.mod[0] >> j) & 1U) != 0U) pm0 += opIdx[static_cast<std::size_t>(j)] * now[static_cast<std::size_t>(j)];
                    if (&a == &algoOf(0) && p[M7_OP3_TARGET] >= 0.5F) pm0 += opIdx[2] * now[2];
                    pcmPm = pm0;
                    opOut = now;
                }
                carrierSum = carriers / static_cast<float>(passes);
                ringNow = opOut[1];
                m7Pm0 = pcmPm * 0.5F;
                return pcmPm * 0.5F;
            }
            default: return 0.0F;
        }
    }

    // -------------------------------------------------------------- per sample, after the recording was read (l / r = the recording)
    void post(const silveton::sampler::EngineParams& e, float& l, float& r, double inc, double sr, std::uint32_t frame, const EngineBus& bus) noexcept;

    // the recording as the excitation of the string: only for EXC LENGTH (0 = always). A recording driving a string at its own
    // pitch adds up period after period: it goes in quietly, and the loop itself is soft-limited.
    float strExcite(const float* p, float in) const noexcept {
        using namespace silveton::sampler;
        float x = in * 0.3F;
        const float len = p[ST_EXC_LEN];
        if (len > 0.0F) {
            const double t = strAgeSec * 1000.0;
            const double fade = std::clamp((static_cast<double>(len) - t) / 5.0 + 1.0, 0.0, 1.0);   // a 5 ms fade at the end
            x *= static_cast<float>(fade);
        }
        return x;
    }

    // SILVETON_ENGINES_V3: the bow of VIOLIN / CELLO
    void startBow(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        bowSlip = false; bowEnv = 0.0F; bowLpZ = 0.0F; bowNoiseLp = Pole{}; bowHairLp = Pole{}; bowTime = 0.0; tremPh = 0.0;
        bowOutZ1 = bowOutZ2 = 0.0F; bowPh = static_cast<double>(random) * 0.5 + 0.5;
        bowDriftA = static_cast<float>(1.0 - std::exp(-2.0 * kPi * 15.0 / sr));
        bowOutA = static_cast<float>(1.0 - std::exp(-2.0 * kPi * std::min(11000.0, 0.22 * sr) / (2.0 * sr)));   // ~11 kHz at the double rate
        vibPh = static_cast<double>(random) * 0.5 + 0.5;
        bowN = 0.0;
        const float damp = std::clamp(p[ST_DAMP], 0.0F, 1.0F);
        bowLpA = 1.0F - 0.75F * damp;                     // the losses at the bridge (at the bow's rate)
        bowDlp = (1.0F - bowLpA) / bowLpA;                // ... and what they delay
        const float velAmt = std::clamp(p[ST_VEL_BOW], 0.0F, 1.0F);
        bowVb = 0.5F * (0.25F + 0.75F * std::clamp(p[ST_BOW_SPEED], 0.0F, 1.0F)) * (1.0F - velAmt * (1.0F - velNorm));
        bowK = 0.6F + 0.2F * std::clamp(p[ST_BOW_PRESS], 0.0F, 1.0F);
        const auto coef = [sr](float ms) { return 1.0F - std::exp(-4.6F / (std::max(ms, 0.5F) * 0.001F * static_cast<float>(sr))); };
        bowAttC = coef(std::clamp(p[ST_BOW_ATTACK], 5.0F, 2000.0F));
        bowRelC = coef(std::clamp(p[ST_BOW_RELEASE], 5.0F, 2000.0F));
        bowSpicOnC = coef(3.0F);
        bowSpicOffC = coef(40.0F);
    }
    static float readFrac(const float* buf, int w, double delay, int mask) noexcept {
        const double rp = static_cast<double>(w) - delay;
        const int i0 = static_cast<int>(std::floor(rp));
        const float f = static_cast<float>(rp - static_cast<double>(i0));
        const float a = buf[static_cast<std::size_t>(i0 & mask)], b = buf[static_cast<std::size_t>((i0 + 1) & mask)];
        return a + (b - a) * f;
    }
    float bowTick(const silveton::sampler::EngineParams& e, float in, double sr, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const double dt = 1.0 / sr;
        bowTime += dt;
        strAgeSec += dt;
        // the bow on the string: ARCO / TREMOLO while the key is down; SPICCATO = one short stroke, whatever the key does
        if (strStyle == 3) {
            const bool stroke = bowTime < 0.05;
            bowEnv += ((stroke ? 1.0F : 0.0F) - bowEnv) * (stroke ? bowSpicOnC : bowSpicOffC);
        } else {
            bowEnv += ((keyDown ? 1.0F : 0.0F) - bowEnv) * (keyDown ? bowAttC : bowRelC);
        }
        // the left hand: vibrato after VIB DELAY, growing in over 0.3 s
        double pitchMul = 1.0;
        const float vibC = std::clamp(p[ST_VIBRATO], 0.0F, 60.0F);
        if (vibC > 0.0F && strStyle != 3) {
            const double since = bowTime - static_cast<double>(std::max(p[ST_VIB_DELAY], 0.0F)) * 0.001;
            if (since > 0.0) {
                vibPh += static_cast<double>(std::clamp(p[ST_VIB_RATE], 2.0F, 9.0F)) * dt;
                vibPh -= std::floor(vibPh);
                pitchMul = std::exp2(static_cast<double>(vibC) * std::min(1.0, since / 0.3) * static_cast<double>(sin01(vibPh)) / 1200.0);
            }
        }
        // SILVETON_AUDIT_V1: the bowed string as its clean Helmholtz motion. The friction model before it (stick / slip solved
        // sample by sample) slipped a little early or late in every period - measured: 15..35 dB of the sound was not the tone,
        // heard as a scratch, at every force / width / loss / 4x rate that was tried. A bowed string's bridge force IS a saw
        // (Helmholtz): here it is the band-limited saw at the exact pitch, the bow position takes out the harmonics of 1 / beta
        // (a comb, as the real contact point does), the pressure sets the brightness, the hair is a soft noise of its own.
        const double f = (inc > 1.0e-7 ? inc : inc0) * strTune * pitchMul;   // cycles per sample
        bowPh += f; bowPh -= std::floor(bowPh);
        const double beta = std::clamp(static_cast<double>(p[ST_BOW_POS]), 0.05, 0.45);
        // TREMOLO: the bow changes direction TREM RATE times a second (the level dips at every turn)
        float dir = 1.0F;
        if (strStyle == 2) {
            tremPh += static_cast<double>(std::clamp(p[ST_TREM_RATE], 2.0F, 20.0F)) * 0.5 * dt;
            tremPh -= std::floor(tremPh);
            dir = std::fabs(tanhT(6.0F * sin01(tremPh)));
        }
        const float press = std::clamp(p[ST_BOW_PRESS], 0.0F, 1.0F);
        const float bn = std::clamp(p[ST_BOW_NOISE], 0.0F, 1.0F);
        // the arm: the speed drifts slowly (15 Hz) - alive, never a scratch
        const float drift = bowNoiseLp.lp(noise(rng), bowDriftA) * bn * 2.0F;
        const float amp = bowVb * bowEnv * dir * (1.0F + 0.08F * drift);
        // the Helmholtz saw at the bridge, coloured by the contact point (its comb x(t) - x(t - beta T) takes the harmonics of
        // 1 / beta out: near the bridge brighter and glassier, over the fingerboard softer)
        const float saw = tabSaw(bowPh, f);
        const float late = tabSaw(bowPh - beta, f);
        float x = (-0.6F * saw + 0.2F * (late - saw)) * amp;
        // the pressure: a light bow is soft (flautando), a heavy one bright - a gentle low-pass on the bridge force
        const float hz = static_cast<float>(f * sr) * (5.0F + 45.0F * press);
        const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::min(hz, 0.45F * static_cast<float>(sr)) / static_cast<float>(sr));
        bowOutZ1 += (x - bowOutZ1) * a;
        x = bowOutZ1;
        // the hair on the string (rosin): a soft band of noise, more with a light bow; a little more while the bow takes hold
        const float hair = bowHairLp.lp(noise(rng), 0.35F) - bowOutZ2;   // high-passed by the slow follower below
        bowOutZ2 += (bowHairLp.z - bowOutZ2) * 0.02F;
        const float attackNoise = bowEnv * (1.0F - bowEnv) * 4.0F;   // most in the middle of the attack
        x += hair * bowVb * (bn * (1.2F - press) * 0.06F * bowEnv + 0.04F * attackNoise);
        // the recording (EXCITE) is added as it is (it does not drive a friction junction any more)
        if (engineRecOn(e)) x += strExcite(p, in) * 0.5F;
        float out = x * 1.7F;   // SILVETON_STR1_REAL_V1: was 1.2 - 3 dB too quiet
        if (!finite(out)) { bowOutZ1 = bowOutZ2 = 0.0F; out = 0.0F; }
        flush(bowOutZ1); flush(bowOutZ2);
        return out;
    }

    // SILVETON_ENGINES_V3: the winds
    void startWind(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        bowEnv = 0.0F; bowNoiseLp = Pole{}; bowTime = 0.0; vibPh = static_cast<double>(random) * 0.5 + 0.5; growlPh = 0.0;
        windLpZ = 0.0F; windDcX = windDcY = windLipX = windLipY = windX1 = windX2 = 0.0F; windLip.reset();
        // the clarinet: a reed on a cylinder; the others: a reed on a cone (every harmonic) - the trumpet and the kaval get their
        // colour from the embouchure, the air, the losses and the body of the instrument
        windModel = strInst == ST_CLARINET ? 0 : (windNoRec ? 2 : 1);   // SILVETON_STR1_REAL_V1: alone = the voiced tone
        float damp = std::clamp(p[ST_DAMP], 0.0F, 1.0F);
        const float emb = std::clamp(p[ST_BOW_PRESS], 0.0F, 1.0F);
        float breath = std::clamp(p[ST_BOW_SPEED], 0.0F, 1.0F);
        const float velAmt = std::clamp(p[ST_VEL_BOW], 0.0F, 1.0F);
        breath *= 1.0F - velAmt * (1.0F - velNorm);
        windAir = std::clamp(p[ST_BOW_NOISE], 0.0F, 1.0F);
        windGrowl = std::clamp(p[ST_GROWL], 0.0F, 1.0F);
        windJet = 1.0;   // the register (KAVAL OVERBLOW = the octave)
        // the STYLE
        windStyleMul = 1.0F;
        if (strStyle == 1) windStyleMul = strInst == ST_KAVAL ? 0.85F : 0.75F;
        if (strStyle == 1) {
            if (strInst == ST_KAVAL) { windAir = std::min(1.0F, windAir * 2.5F + 0.15F); breath *= 0.85F; }   // BREATHY
            else { breath *= 0.75F; windAir = std::min(1.0F, windAir * 2.0F + 0.05F); damp = std::min(1.0F, damp + 0.35F); }   // SOFT / SUBTONE / MUTE
        } else if (strStyle == 2) {
            windGrowl = std::max(windGrowl, 0.6F);                         // GROWL
        }
        windLpA = 1.0F - 0.8F * damp;
        windDlp = (1.0F - windLpA) / windLpA;
        windDampNow = damp;
        // the reed: its rest opening and its stiffness (EMBOUCHURE: a firmer lip = a brighter, edgier tone)
        windOff = 0.74F - 0.06F * emb;
        windSlope = -0.28F - 0.12F * emb;
        switch (windModel) {
            // the reed speaks between a soft and a hard blow (too hard and it shuts): the breath moves the pressure inside that
            // window, the loudness follows the breath
            case 0: windPm = 0.62F + (0.17F - 0.03F * emb) * breath; windOutGain = 0.8F * (0.35F + 0.65F * breath); windGainBase = 0.8F; break;   // (SILVETON_STR1_REAL_V1: was 0.55 - 3 dB too quiet)
            case 1: case 2: windPm = 0.62F + (0.17F - 0.03F * emb) * breath; windOutGain = 0.6F * (0.35F + 0.65F * breath); windGainBase = 0.6F; break;
            default: break;
        }
        if (windModel == 1) windConeSet(emb, breath, 1.0F, damp);
        if (windModel == 2) {   // SILVETON_STR1_REAL_V1: the voiced tone starts silent and finds its harmonics
            const WindVoicing& wv = windVoicingOf(strInst);
            whA.fill(0.0F); whB.fill(0.0F); whTA.fill(0.0F); whTB.fill(0.0F); whCount = whGroups = whTickN = 0; whPh = static_cast<double>(random) * 0.5 + 0.5;
            whScoopE = whOverE = whChiffE = 1.0F;
            whScoopK = std::exp(-1.0F / (0.035F * static_cast<float>(sr))); whOverK = std::exp(-1.0F / (0.06F * static_cast<float>(sr))); whChiffK = std::exp(-1.0F / (0.012F * static_cast<float>(sr)));
            whJit = Pole{}; whFlt = Pole{}; whNzLo = Pole{}; whNzHi = Pole{};
            whALo = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * wv.noiseLoHz / static_cast<float>(sr));
            whAHi = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * wv.noiseHiHz / static_cast<float>(sr));
            windAddSet(emb, breath, 1.0F, damp, sr);
            whA = whTA; whB = whTB; whGroups = (whCount + 3) / 4;
        }
        windPmTarget = windPm; windGainTarget = windOutGain;
        // SILVETON_STR1_FIX_V1: the bore starts with a little of its own tone in it (a tongued start) - a low note speaks in a few
        // dozen ms instead of a third of a second, and in its own register. A slow ATTACK gets less of it (a soft swell stays soft).
        {
            const float seed = 0.1F * std::min(1.0F, 60.0F / std::clamp(p[ST_BOW_ATTACK], 5.0F, 2000.0F));
            const double per = sr / std::max(1.0, static_cast<double>(keyHz) * strTune);   // samples per period
            if (windModel == 1) {
                windConeF = -1.0; windConeTune(1.0 / per);
                const double N = windConeN;
                const double D1 = std::max(2.0, 0.22 * N), D0 = std::max(2.0, N - D1);
                // the reed pressure of the tone: open for the long part of the period, shut for the short part
                const auto rect = [&](int j) noexcept {
                    const double t = -static_cast<double>(j) / N;
                    return (t - std::floor(t)) < D0 / N ? 0.6F * seed : -0.6F * seed * static_cast<float>(D0 / D1);
                };
                for (int j = 1; j < kStringMax; ++j) str[static_cast<std::size_t>((strW - j) & kStringMask)] = rect(j);
                for (int j = 1; j < kPickMax; ++j) pick[static_cast<std::size_t>((pickW - j) & kPickMask)] = rect(j);
            } else if (windModel == 0) {
                for (int j = 1; j < kStringMax; ++j)
                    str[static_cast<std::size_t>((strW - j) & kStringMask)] = 1.5F * seed * static_cast<float>(std::sin(-2.0 * kPi * static_cast<double>(j) / per));
            }
        }
        const auto coef = [sr](float ms) { return 1.0F - std::exp(-4.6F / (std::max(ms, 0.5F) * 0.001F * static_cast<float>(sr))); };
        bowAttC = coef(std::clamp(p[ST_BOW_ATTACK], 5.0F, 2000.0F));
        bowRelC = coef(std::clamp(p[ST_BOW_RELEASE], 5.0F, 2000.0F));
        bowSpicOnC = coef(4.0F);
        bowSpicOffC = coef(30.0F);
    }
    // SILVETON_STR1_FIX_V1: the reed of the cone (SAX / TRUMPET / KAVAL / GAIDA). The breath is the pressure in the mouth as a
    // part of the pressure that shuts the reed (it speaks from about 0.55, above about 0.75 it jumps to the octave - kept below);
    // the embouchure is how wide the reed opens; DAMPING = the losses of the bore, above a multiple of the note's pitch.
    // SILVETON_STR1_REAL_V1: the harmonics of the voiced tone for this note and this breath (once per block). The strength follows the
    // tilt and the formants of the instrument; the harder it is blown the higher the corner (brighter); a lossy bell (DAMPING) is darker.
    void windAddSet(float emb, float breath, float ctl, float damp, double sr) noexcept {
        const WindVoicing& v = windVoicingOf(strInst);
        windGainTarget = windGainBase * (0.35F + 0.65F * breath) * (0.25F + 0.75F * std::clamp(ctl, 0.0F, 1.0F));
        const float b = std::clamp(0.1F + 0.9F * breath * (0.45F + 0.55F * std::clamp(ctl, 0.0F, 1.0F)) + 0.2F * (emb - 0.5F) - (strStyle == 1 ? 0.25F : 0.0F), 0.0F, 1.0F);
        const float fc = v.fcSoft * std::pow(v.fcLoud / v.fcSoft, b) * (1.4F - 1.2F * std::clamp(damp, 0.0F, 1.0F));
        const float slope = v.slope * (1.3F - 0.6F * b);
        const double f0 = static_cast<double>(keyHz) * strTune;
        const double top = std::min(20000.0, 0.45 * sr);
        std::array<float, kWH> whTgt{};
        float sumSq = 0.0F; int n = 0;
        for (int h = 1; h <= kWH; ++h) {
            const double fh = f0 * static_cast<double>(h);
            if (fh > top) { whTgt[static_cast<std::size_t>(h - 1)] = 0.0F; continue; }
            float db = -slope * std::log2(static_cast<float>(h));
            if (h == 1) db += v.h1Db;
            for (int k = 0; k < 3; ++k) {
                const float r = std::log(static_cast<float>(fh) / v.fHz[k]) * v.fQ[k] * 1.25F;
                db += v.fDb[k] * std::exp(-0.5F * r * r);
            }
            if (fh > static_cast<double>(fc)) db -= 24.0F * std::log2(static_cast<float>(fh) / fc);
            const float a = std::pow(10.0F, db / 20.0F);
            whTgt[static_cast<std::size_t>(h - 1)] = a; sumSq += a * a; n = h;
        }
        whOutG = std::pow(10.0F, v.outDb / 20.0F);
        const float norm = 1.0F / std::sqrt(std::max(0.5F * sumSq, 1.0e-6F));
        while (n > 0 && whTgt[static_cast<std::size_t>(n - 1)] * norm < 6.0e-4F) --n;   // nothing is heard from the harmonics below -64 dB: they are not computed
        whCount = n;
        const WindPhases& wp = windPhases();
        for (int h = 0; h < kWH; ++h) {
            const auto hi = static_cast<std::size_t>(h);
            const float a = h < n ? whTgt[hi] * norm : 0.0F;
            whTA[hi] = a * wp.c[hi]; whTB[hi] = a * wp.s[hi];
        }
    }
    void windConeSet(float emb, float breath, float ctl, float damp) noexcept {
        windZeta = 0.65F - 0.2F * emb;
        windTrackK = 10.0F + 8.0F * (1.0F - std::clamp(damp, 0.0F, 1.0F));
        windPm = (0.56F + 0.18F * std::clamp(breath, 0.0F, 1.0F)) * (0.8F + 0.2F * std::clamp(ctl, 0.0F, 1.0F));
        windOutGain = windGainBase * (0.35F + 0.65F * breath) * (0.25F + 0.75F * std::clamp(ctl, 0.0F, 1.0F));
    }
    [[nodiscard]] float windConeLp(double f) const noexcept {   // the bore's low-pass for a tone of f cycles per sample
        return 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::min(0.45F, windTrackK * static_cast<float>(f)));
    }
    // ... and the length of the bore for that tone: the period minus what the low-pass delays at the tone. Kept while the pitch
    // moves less than 0.03 cent.
    void windConeTune(double f) noexcept {
        if (std::fabs(f - windConeF) <= f * 2.0e-5) return;
        windConeF = f;
        windConeLa = windConeLp(f);
        const double q = 1.0 - static_cast<double>(windConeLa), w = 2.0 * kPi * f;
        // (the tone's sharp corner travels a little faster than the fundamental: 94 % of that delay - measured, within 0.3 cent)
        const double delay = 0.94 * std::atan2(q * std::sin(w), 1.0 - q * std::cos(w)) / std::max(w, 1.0e-9);
        windConeN = std::clamp(1.0 / std::max(f, 1.0e-6) - delay, 6.0, static_cast<double>(kStringMax - 8));
    }
    float windTick(const silveton::sampler::EngineParams& e, float in, double sr, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const double dt = 1.0 / sr;
        bowTime += dt;
        strAgeSec += dt;
        // the breath: while the key is down; STACCATO = a short tongued note
        if (strStyle == 3) {
            const bool on = bowTime < 0.07 && keyDown;
            bowEnv += ((on ? 1.0F : 0.0F) - bowEnv) * (on ? bowSpicOnC : bowSpicOffC);
        } else {
            bowEnv += ((keyDown ? 1.0F : 0.0F) - bowEnv) * (keyDown ? bowAttC : bowRelC);
        }
        // vibrato: the pitch and a little of the breath
        double pitchMul = 1.0;
        float vibAmp = 0.0F;
        const float vibC = std::clamp(p[ST_VIBRATO], 0.0F, 60.0F);
        if (vibC > 0.0F && strStyle != 3) {
            const double since = bowTime - static_cast<double>(std::max(p[ST_VIB_DELAY], 0.0F)) * 0.001;
            if (since > 0.0) {
                vibPh += static_cast<double>(std::clamp(p[ST_VIB_RATE], 2.0F, 9.0F)) * dt;
                vibPh -= std::floor(vibPh);
                const float v = sin01(vibPh) * static_cast<float>(std::min(1.0, since / 0.3));
                pitchMul = std::exp2(static_cast<double>(vibC * v) / 1200.0);
                vibAmp = v * vibC * 0.004F;
            }
        }
        const double f = (inc > 1.0e-7 ? inc : inc0) * strTune * pitchMul * windJet;   // cycles per sample
        // SILVETON_AUDIT_V1: the breath follows its knobs and the breath controller (block targets, glided here)
        windPm += (windPmTarget - windPm) * 0.002F;
        windOutGain += (windGainTarget - windOutGain) * 0.002F;
        // the mouth pressure: the breath, the air in it, the growl (the throat singing into the instrument)
        const float air = bowNoiseLp.lp(noise(rng), 0.5F);
        float pm = windPm * bowEnv * (1.0F + vibAmp) * (1.0F + windAir * 0.35F * air);
        if (windGrowl > 0.0F) {
            growlPh += 27.0 * dt; growlPh -= std::floor(growlPh);
            pm *= 1.0F + windGrowl * (0.35F * sin01(growlPh) + 0.25F * air);
        }
        const float x = engineRecOn(e) ? strExcite(p, in) : 0.0F;   // the recording blows in too
        pm += x;
        float out = 0.0F;
        switch (windModel) {
            case 0: {   // CLARINET: a reed on a cylinder - the bore inverts at the bell, the period is twice the bore
                const double D = std::clamp(0.5 / std::max(f, 1.0e-6) - static_cast<double>(windDlp), 2.0, static_cast<double>(kStringMax - 4));
                const float bore = readFrac(str.data(), strW, D, kStringMask);
                windLpZ += (bore - windLpZ) * windLpA;
                const float refl = -0.95F * windLpZ;
                const float pd = refl - pm;
                const float reed = std::clamp(windOff + windSlope * pd, -1.0F, 1.0F);
                const float y = pm + pd * reed;
                str[static_cast<std::size_t>(strW)] = y; strW = (strW + 1) & kStringMask;
                out = y;
                break;
            }
            case 1: {
                // SILVETON_STR1_FIX_V1: SAX / TRUMPET / KAVAL / GAIDA - a reed on a cone. A cone sounds every harmonic like two open
                // tubes side by side at the reed: the long one (D0, to the bell) and the short one that stands for the missing tip of
                // the cone (D1). The two waves that come back make the pressure at the reed together; the air that the reed lets
                // through (it shuts at the pressure 1) adds to it; what leaves is that pressure minus what came back. The tone is the
                // pressure at the reed: open for the long part of the period, shut for the short part - the fundamental strongest.
                // (Before: the short tube only echoed the long one; most of the tone sat an octave up, and from about C6 it WAS an
                // octave up - measured.)
                windConeTune(f);
                const float la = windConeLa;
                const double N = windConeN;
                const double D1 = std::max(2.0, 0.22 * N), D0 = std::max(2.0, N - D1);
                const float a0 = readFrac(str.data(), strW, D0, kStringMask);   // back from the bell
                const float a1 = readFrac(pick.data(), pickW, D1, kPickMask);   // back from the tip
                windLpZ += (a0 - windLpZ) * la;
                const float p0 = -0.98F * windLpZ, p1 = -0.99F * a1;           // both ends open: the waves come back turned over
                const float ph = p0 + p1;
                // the reed: flow u = D (1 - D) for the pressure drop D = pm - p (0 .. 1, shut at 1), u = D when it is pushed open;
                // the pressure at the reed p = ph + zeta u (the two tubes side by side take the flow) - solved for D
                const float z = windZeta, c = pm - ph;
                float drop = 1.0F;
                if (c < 1.0F) {
                    const float b = 1.0F + z, disc = b * b - 4.0F * z * c;
                    drop = disc > 0.0F ? (b - std::sqrt(disc)) / (2.0F * z) : 1.0F;
                    if (drop < 0.0F) drop = c / (1.0F + z);
                    drop = std::min(drop, 1.0F);
                } else {
                    drop = c;   // shut: no air, the waves alone
                }
                const float pr = pm - drop;
                str[static_cast<std::size_t>(strW)] = std::clamp(pr - p0, -6.0F, 6.0F); strW = (strW + 1) & kStringMask;
                pick[static_cast<std::size_t>(pickW)] = std::clamp(pr - p1, -6.0F, 6.0F); pickW = (pickW + 1) & kPickMask;
                // the tone without its constant part (a 20 Hz DC filter)
                const float y = pr - windDcX + 0.9987F * windDcY;
                windDcX = pr; windDcY = y;
                out = y * 0.5F;
                break;
            }

            case 2: {
                // SILVETON_STR1_REAL_V1: the voiced tone - every harmonic of the instrument at its own strength, with its own phase.
                // The note starts a little flat and settles (the lip / the reed finding the note), the pitch and the strength of a
                // human breath are never quite still, the start is a little too strong, the tongue and the air are noise.
                const WindVoicing& wv = windVoicingOf(strInst);
                if ((whTickN++ & 7) == 0) {   // the harmonics follow the breath: a slow update, every 8th sample, 4 groups of harmonics at a time
                    int liveH = 0;
                    for (int h = 0; h < kWH; ++h) {
                        const auto hi = static_cast<std::size_t>(h);
                        whA[hi] += (whTA[hi] - whA[hi]) * 0.03F; whB[hi] += (whTB[hi] - whB[hi]) * 0.03F;
                        if (std::fabs(whA[hi]) + std::fabs(whB[hi]) > 1.0e-5F) liveH = h + 1;
                    }
                    whGroups = (liveH + 3) / 4;
                }
                const float jit = whJit.lp(noise(rng), 0.0008F) * 150.0F;
                const float cents = -wv.scoopCents * whScoopE + jit;
                whScoopE *= whScoopK; whOverE *= whOverK; whChiffE *= whChiffK;
                whPh += f * (1.0 + static_cast<double>(cents) * 5.776e-4); whPh -= std::floor(whPh);   // 2^(c/1200) for a few cents, to 1e-4
                const float th = static_cast<float>(2.0 * kPi * whPh);
                // the harmonics 1..4 straight, every next four by one rotation of the fourth (four independent chains, not one long one)
                const float s1 = std::sin(th), c1 = std::cos(th);
                const float s2 = 2.0F * s1 * c1, c2 = 1.0F - 2.0F * s1 * s1;
                const float s3 = s2 * c1 + c2 * s1, c3 = c2 * c1 - s2 * s1;
                const float s4 = 2.0F * s2 * c2, c4 = 1.0F - 2.0F * s2 * s2;
                float sn0 = s1, sn1 = s2, sn2 = s3, sn3 = s4, cn0 = c1, cn1 = c2, cn2 = c3, cn3 = c4;
                float a0 = 0.0F, a1 = 0.0F, a2 = 0.0F, a3 = 0.0F;
                for (int g = 0; g < whGroups; ++g) {
                    const auto b = static_cast<std::size_t>(g) * 4U;
                    a0 += whA[b] * sn0 + whB[b] * cn0;
                    a1 += whA[b + 1U] * sn1 + whB[b + 1U] * cn1;
                    a2 += whA[b + 2U] * sn2 + whB[b + 2U] * cn2;
                    a3 += whA[b + 3U] * sn3 + whB[b + 3U] * cn3;
                    const float t0 = sn0 * c4 + cn0 * s4; cn0 = cn0 * c4 - sn0 * s4; sn0 = t0;
                    const float t1 = sn1 * c4 + cn1 * s4; cn1 = cn1 * c4 - sn1 * s4; sn1 = t1;
                    const float t2 = sn2 * c4 + cn2 * s4; cn2 = cn2 * c4 - sn2 * s4; sn2 = t2;
                    const float t3 = sn3 * c4 + cn3 * s4; cn3 = cn3 * c4 - sn3 * s4; sn3 = t3;
                }
                const float sum = (a0 + a1) + (a2 + a3);
                const float flut = 1.0F + whFlt.lp(noise(rng), 0.0006F) * 3.0F;
                float amp = bowEnv * (1.0F + vibAmp) * flut * (1.0F + wv.over * whOverE);
                if (windGrowl > 0.0F) amp *= 1.0F + windGrowl * 0.45F * sin01(growlPh);
                const float n0 = noise(rng);
                const float nz = whNzHi.lp(n0, whAHi) - whNzLo.lp(n0, whALo);
                const float nzAmp = windAir * 0.42F + wv.chiff * 0.3F * whChiffE + windGrowl * 0.1F;
                out = (sum + nz * nzAmp * 5.0F) * amp * 0.405F * whOutG;
                break;
            }
            default: break;
        }
        out *= windOutGain;
        if (!finite(out)) {
            std::fill(str.begin(), str.end(), 0.0F); std::fill(pick.begin(), pick.end(), 0.0F);
            windLpZ = windDcX = windDcY = 0.0F; windLip.reset(); out = 0.0F;
        }
        flush(windLpZ); flush(windDcY);
        return out;
    }

    // the STR-1 string: one sample in (the recording = the excitation), one sample out
    float stringTick(const silveton::sampler::EngineParams& e, float in, double sr, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        strAgeSec += 1.0 / sr;
        // SILVETON_ENGINES_V2: pitch bend / glide - the string follows the key's pitch of this sample
        if (inc > 1.0e-7 && std::fabs(inc - strInc) > strInc * 1.0e-5) {
            strInc = inc;
            strLen = std::clamp(1.0 / (inc * strTune) - strComp, 4.0, static_cast<double>(kStringMax - 4));
        }
        float x = strExcite(p, in);
        if (pluckLeft > 0) {   // the pluck of its own: one period of coloured noise
            x += pluckLp.lp(noise(rng), pluckA) * pluckGain;
            --pluckLeft;
        }
        // pick position: the excitation minus itself delayed by PICK x the string length
        {
            const double d = std::clamp(static_cast<double>(strPick) * strLen, 1.0, static_cast<double>(kPickMax - 2));
            pick[static_cast<std::size_t>(pickW)] = x;
            const double rp = static_cast<double>(pickW) - d;
            const int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            const auto a0 = static_cast<std::size_t>(i0 & kPickMask), a1 = static_cast<std::size_t>((i0 + 1) & kPickMask);
            x -= pick[a0] + (pick[a1] - pick[a0]) * f;
            pickW = (pickW + 1) & kPickMask;
        }
        // feedback from the output back into the string (like a guitar in front of its amplifier)
        const float fb = std::clamp(p[ST_FEEDBACK], 0.0F, 1.0F);
        if (fb > 0.0F) x += tanhT(strFbZ * 2.0F) * fb * 0.35F;
        // read the string one period back (fractional), and at the pickup position
        const auto tap = [&](double delay) noexcept {
            const double rp = static_cast<double>(strW) - delay;
            const int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            const auto a0 = static_cast<std::size_t>(i0 & kStringMask), a1 = static_cast<std::size_t>((i0 + 1) & kStringMask);
            return str[a0] + (str[a1] - str[a0]) * f;
        };
        float y = tap(strLen);
        // loop filter: damping low-pass, dispersion allpass, nonlinearity, decay
        strLpZ += (y - strLpZ) * strLpA; y = strLpZ;
        {   // first-order allpass
            const float out = strApA * y + strApX - strApA * strApY;
            strApX = y; strApY = out; y = out;
        }
        const float nl = std::clamp(p[ST_NONLIN], 0.0F, 1.0F);
        if (nl > 0.0F) { const float g = 1.0F + 6.0F * nl; y = tanhT(y * g) / g; }
        else if (y > 0.7F || y < -0.7F) y = tanhT(y);
        y *= strG;
        float newSample = y + x;
        if (!finite(newSample)) { std::fill(str.begin(), str.end(), 0.0F); strLpZ = strApX = strApY = strFbZ = 0.0F; newSample = 0.0F; }
        str[static_cast<std::size_t>(strW)] = newSample;
        strW = (strW + 1) & kStringMask;
        // pickup position: the string minus itself at PICKUP x length (a comb on the output)
        const double pu = std::clamp(static_cast<double>(std::clamp(p[ST_PICKUP], 0.02F, 0.5F)) * strLen, 1.0, strLen - 1.0);
        // SILVETON_STR1_FIX_V1: the newest sample is already written - one more back is PICKUP x length (before, the comb was one
        // sample short: at 1 sample it took the sound away completely - the high notes of HARP / VIOLIN / CELLO were silent)
        const float out = newSample - 0.5F * tap(pu + 1.0);   // SILVETON_STR1_REAL_V1: half the depth - the full comb took out the body of the tone
        strFbZ += (out - strFbZ) * 0.05F;   // the feedback path is dull (a loudspeaker far away)
        return out;
    }
};

// ---------------------------------------------------------------------------------------------------------------
// one per Upper
struct EngineBus {
    static constexpr int kWheels = 91;
    static constexpr int kChunk = 256;    // = SamplerEngine::Impl::kRenderChunk (checked where the bus is used)

    double sr{48000.0};
    silveton::sampler::EngineType type{silveton::sampler::EngineType::Off};
    // Polysix chorus / phase / ensemble
    ModEngine mod{};
    silveton::sampler::EffectSlot modCfg{};
    // CX-3: the shared tonewheel generator (SILVETON_ENGINES_V2) - the phases run on, note or no note
    std::array<double, kWheels> twPh{};
    std::array<double, kWheels> twInc{};
    std::array<float, kWheels> twGain{};
    std::array<std::uint8_t, kWheels> twNeed{};
    std::vector<float> twOut;            // kWheels x kChunk, written once per chunk before the voices read it
    int twTuning{-1};
    float twTaper{-1.0F};
    std::uint32_t twFrames{0U};
    // CX-3 scanner and Leslie
    HeapLine vibLine{};
    double vibPhase{0.0};
    // SILVETON_BODY_V1: ANALOG - the phase of the width (one for the whole Upper: this is its bus)
    double awPh{0.0};
    Pole awLpL{}, awLpR{};
    HeapLine hornLine{};
    double hornPhase{0.0}, drumPhase{0.0}, hornSpeed{0.0}, drumSpeed{0.0};
    Pole xo1{}, xo2{};
    // EP
    Biquad bass{}, treble{};
    float bassDb{999.0F}, trebleDb{999.0F};
    double tremPhase{0.0};
    Lp2 cabHp{}, cabLp{};
    Biquad cabPeak{};
    bool cabSet{false};
    // SGX strings (combs) with the energy limiter, SGX / STR-1 body (modal resonators)
    struct Res {
        int key{-1};
        std::vector<float> buf;
        int w{0};
        double len{100.0};
        float g{0.0F};
        float lp{0.0F};
        std::uint32_t age{0U};
        float tick(float in, float lpA) noexcept {
            const double rp = static_cast<double>(w) - len;
            const int n = static_cast<int>(buf.size());
            int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            i0 = (i0 % n + n) % n;
            const int i1 = (i0 + 1) % n;
            const float y = buf[static_cast<std::size_t>(i0)] + (buf[static_cast<std::size_t>(i1)] - buf[static_cast<std::size_t>(i0)]) * f;
            lp += (y - lp) * lpA;
            const float s = in + lp * g;
            buf[static_cast<std::size_t>(w)] = s;
            w = (w + 1) % n;
            return lp;
        }
    };
    static constexpr int kHeldRes = 10;
    static constexpr int kDamperRes = 10;
    static constexpr int kBodyModes = 12;
    std::array<Res, kHeldRes> held{};
    std::array<Res, kDamperRes> damper{};
    std::uint32_t resClock{0U};
    // SILVETON_SGX_OWN_V1: what every held key plays itself, this chunk (per sound of the Upper - each renders on its own core):
    // a held string resonates with the OTHER notes, not with its own - before, one note fed its own resonator and came out
    // 5 dB fuller and duller (measured: the attack was lost under it)
    static constexpr int kOwnSounds = silveton::sampler::kUpperLayers + 1;
    std::array<std::array<std::array<float, kChunk>, kHeldRes>, kOwnSounds> own{};
    std::array<float, kHeldRes> ownNow{};
    [[nodiscard]] int heldSlotOf(int key) const noexcept {
        for (int k = 0; k < kHeldRes; ++k) if (held[static_cast<std::size_t>(k)].key == key) return k;
        return -1;
    }
    void ownClear(int n) noexcept {
        for (auto& snd : own) for (auto& slot : snd) std::fill(slot.begin(), slot.begin() + std::clamp(n, 0, kChunk), 0.0F);
    }
    void ownAt(int i) noexcept {
        for (int k = 0; k < kHeldRes; ++k) {
            float s = 0.0F;
            for (const auto& snd : own) s += snd[static_cast<std::size_t>(k)][static_cast<std::size_t>(i)];
            ownNow[static_cast<std::size_t>(k)] = s;
        }
    }
    float resGainHeld{0.0F}, resGainDamper{0.0F};
    float resEnergy{0.0F}, resLimit{0.0F};
    std::array<Modal, kBodyModes> body{};
    int bodyType{-1};
    float bodyGain{0.0F};
    StrBody strBody{};           // SILVETON_ENGINES_V3: the STR-1 instrument body (in series, BODY = how much)
    int strBodyInst{-1};
    float strBodyMix{0.0F};
    Biquad lid{};
    float lidDb{999.0F};
    // HD-1
    Biquad boost{};
    float boostDb{999.0F};

    void allocate(double sampleRate) {
        sr = sampleRate;
        mod.allocate(sr);
        vibLine.allocate(static_cast<std::size_t>(0.004 * sr) + 64U);
        hornLine.allocate(static_cast<std::size_t>(0.004 * sr) + 64U);
        const auto resLen = static_cast<std::size_t>(sr / 22.0) + 8U;
        for (auto& r : held) { r.buf.assign(resLen, 0.0F); r.key = -1; }
        for (auto& r : damper) { r.buf.assign(resLen, 0.0F); r.key = -1; }
        twOut.assign(static_cast<std::size_t>(kWheels) * static_cast<std::size_t>(kChunk), 0.0F);
        reset();
    }
    void reset() noexcept {
        mod.reset(); vibLine.clear(); hornLine.clear(); vibPhase = hornPhase = drumPhase = 0.0; hornSpeed = drumSpeed = 0.0;
        xo1 = Pole{}; xo2 = Pole{}; awLpL = Pole{}; awLpR = Pole{}; awPh = 0.0;
        bass.reset(); treble.reset(); bassDb = trebleDb = 999.0F; tremPhase = 0.0; cabHp.reset(); cabLp.reset(); cabPeak.reset(); cabSet = false;
        for (auto& r : held) { std::fill(r.buf.begin(), r.buf.end(), 0.0F); r.key = -1; r.lp = 0.0F; r.w = 0; }
        for (auto& r : damper) { std::fill(r.buf.begin(), r.buf.end(), 0.0F); r.key = -1; r.lp = 0.0F; r.w = 0; }
        resEnergy = 0.0F;
        for (auto& m : body) m.reset();
        bodyType = -1; bodyGain = 0.0F;
        strBody.reset(); strBodyInst = -1; strBodyMix = 0.0F;
        lid.reset(); lidDb = 999.0F; boost.reset(); boostDb = 999.0F;
        twNeed.fill(0U); twFrames = 0U; twTuning = -1; twTaper = -1.0F;
        type = silveton::sampler::EngineType::Off;
    }

    [[nodiscard]] bool active(const silveton::sampler::EngineParams& e) const noexcept {
        using namespace silveton::sampler;
        switch (e.type) {
            case EngineType::Polysix: return e.p[P6_FX_TYPE] >= 0.5F && e.p[P6_FX_MIX] > 0.0F;
            case EngineType::CX3: return true;
            case EngineType::EP: return true;
            case EngineType::AL1: case EngineType::MS20: case EngineType::Mod7: return e.p[E_ANALOG] > 0.0F;   // SILVETON_BODY_V1: the width of ANALOG
            case EngineType::SGX: return true;
            case EngineType::Str1: return e.p[ST_BODY] > 0.0F;
            case EngineType::HD1: return e.p[HD_BOOST] > 0.05F;
            default: return false;
        }
    }

    static double keyHz(int key) noexcept { return 440.0 * std::pow(2.0, (key - 69) / 12.0); }

    // SILVETON_ENGINES_V2: the 91 wheels - equal temperament, or the gear ratios of the B-3 (a 20 Hz shaft, tonewheels of
    // 2..128 teeth; the top seven wheels have 192 teeth and the ratios of a fifth below, so the top is a little out)
    void setWheels(int tuning, float taper) noexcept {
        if (tuning == twTuning && taper == twTaper) return;
        twTuning = tuning; twTaper = taper;
        static const double ratios[12] = {85.0 / 104.0, 71.0 / 82.0, 67.0 / 73.0, 105.0 / 108.0, 103.0 / 100.0, 84.0 / 77.0,
                                          74.0 / 64.0, 98.0 / 80.0, 96.0 / 74.0, 88.0 / 64.0, 67.0 / 46.0, 108.0 / 70.0};
        for (int w = 0; w < kWheels; ++w) {
            double f;
            if (tuning == 0) f = 32.703195662 * std::pow(2.0, static_cast<double>(w) / 12.0);
            else if (w < 84) f = 20.0 * static_cast<double>(2 << (w / 12)) * ratios[w % 12];
            else f = 20.0 * 192.0 * ratios[(w % 12 + 5) % 12];
            twInc[static_cast<std::size_t>(w)] = f / sr;
            // the generator's output tapers towards the top (the real resistor network)
            twGain[static_cast<std::size_t>(w)] = 1.0F - 0.7F * taper * std::clamp((static_cast<float>(f) - 1000.0F) / 5000.0F, 0.0F, 1.0F);
        }
    }
    void needWheels(const EngineVoice& v) noexcept {
        for (const int w : v.twWheel) if (w >= 0 && w < kWheels) { twNeed[static_cast<std::size_t>(w)] = 1U; }
        if (v.percWheel >= 0 && v.percWheel < kWheels) twNeed[static_cast<std::size_t>(v.percWheel)] = 1U;
        const int w8 = v.twWheel[2];   // the leakage: the neighbours of the 8' wheel
        if (w8 > 0) twNeed[static_cast<std::size_t>(w8 - 1)] = 1U;
        if (w8 >= 0 && w8 + 1 < kWheels) twNeed[static_cast<std::size_t>(w8 + 1)] = 1U;
    }
    // once per chunk, before the voices render: the needed wheels for `frames` samples; every phase moves on
    // pitchMul: the pitch bend of the Upper (SILVETON_ENGINES_V2) - every wheel turns faster / slower together, its phase runs on
    void prepareWheels(std::uint32_t frames, double pitchMul = 1.0) noexcept {
        if (twOut.empty()) return;
        frames = std::min(frames, static_cast<std::uint32_t>(kChunk));
        twFrames = frames;
        pitchMul = std::clamp(pitchMul, 0.0625, 16.0);
        for (int w = 0; w < kWheels; ++w) {
            const auto ww = static_cast<std::size_t>(w);
            const double inc = std::min(twInc[ww] * pitchMul, 0.45);
            if (twNeed[ww] != 0U) {
                float* out = twOut.data() + ww * static_cast<std::size_t>(kChunk);
                const double ph0 = twPh[ww];
                const float g = twGain[ww];
                for (std::uint32_t i = 0U; i < frames; ++i) out[i] = sin01(ph0 + inc * static_cast<double>(i)) * g;
            }
            twPh[ww] += inc * static_cast<double>(frames);
            twPh[ww] -= std::floor(twPh[ww]);
            twNeed[ww] = 0U;
        }
    }
    [[nodiscard]] float wheel(int w, std::uint32_t frame) const noexcept {
        if (w < 0 || w >= kWheels || frame >= twFrames || twOut.empty()) return 0.0F;
        return twOut[static_cast<std::size_t>(w) * static_cast<std::size_t>(kChunk) + frame];
    }

    void setBody(int kind, double scale, float gain) noexcept {
        // the modes of a soundboard / box, in Hz, and how long each rings (s)
        static const double grand[kBodyModes] = {52, 78, 112, 146, 188, 236, 292, 360, 446, 560, 700, 880};
        static const double guitar[kBodyModes] = {98, 196, 240, 318, 410, 520, 650, 790, 950, 1150, 1400, 1700};
        static const double violin[kBodyModes] = {275, 440, 540, 700, 880, 1050, 1250, 1500, 1800, 2200, 2700, 3300};
        static const double cello[kBodyModes] = {92, 150, 196, 250, 330, 420, 520, 650, 800, 1000, 1250, 1600};
        static const double harp[kBodyModes] = {62, 120, 180, 250, 330, 420, 520, 640, 800, 1000, 1250, 1600};
        const double* f = kind == 1 ? guitar : (kind == 2 ? violin : (kind == 3 ? cello : (kind == 4 ? harp : grand)));
        for (int i = 0; i < kBodyModes; ++i) {
            const auto ii = static_cast<std::size_t>(i);
            const double hz = f[i] * scale;
            const double tau = (kind == 0 ? 0.35 : 0.12) * std::pow(0.8, static_cast<double>(i) * 0.5);
            body[ii].set(sr, hz, tau, 0.9F / static_cast<float>(kBodyModes) * (1.0F - 0.04F * static_cast<float>(i)));
        }
        bodyType = kind; bodyGain = gain;
    }
    float bodyTick(float x) noexcept {
        float y = 0.0F;
        for (auto& m : body) y += m.tick(x);
        return y;
    }

    // once per block. heldKeys: the keys of this Upper that are down now (SGX); sustain / wheel of the Upper's channel.
    void block(const silveton::sampler::EngineParams& e, std::uint32_t frames, float wheel, bool sustain, const std::array<bool, 128>& heldKeys) noexcept {
        using namespace silveton::sampler;
        if (e.type != type) { reset(); type = e.type; }
        const float* p = e.p.data();
        (void)frames;
        switch (e.type) {
            case EngineType::Polysix: {
                const int t = static_cast<int>(std::lround(p[P6_FX_TYPE]));
                modCfg.type = t == 1 ? EffectType::Chorus : (t == 2 ? EffectType::Phaser : (t == 3 ? EffectType::Ensemble : EffectType::Off));
                modCfg.rateHz = std::clamp(p[P6_FX_SPEED], 0.1F, 5.0F);
                modCfg.depth = std::clamp(p[P6_FX_DEPTH], 0.0F, 1.0F);
                modCfg.feedback = t == 2 ? 0.35F : 0.0F;
                modCfg.param1 = t == 1 ? 3.0F : 6.0F;
                break;
            }
            case EngineType::EP: {
                if (p[EP_BASS] != bassDb) { bassDb = p[EP_BASS]; bass.setShelf(sr, 110.0F, std::clamp(bassDb, -12.0F, 12.0F), false); }
                if (p[EP_TREBLE] != trebleDb) { trebleDb = p[EP_TREBLE]; treble.setShelf(sr, 3200.0F, std::clamp(trebleDb, -12.0F, 12.0F), true); }
                if (!cabSet) { cabHp.set(sr, 85.0, true); cabLp.set(sr, 5200.0, false); cabPeak.setPeaking(sr, 420.0F, 0.8F, 2.5F); cabSet = true; }
                break;
            }
            case EngineType::SGX: {
                const float lidV = std::clamp(p[SG_LID], 0.0F, 1.0F);
                const float ld = -(1.0F - lidV) * 7.0F;
                if (ld != lidDb) { lidDb = ld; lid.setShelf(sr, 2400.0F, ld, true); }
                const float relSec = std::clamp(p[SG_RES_RELEASE], 0.1F, 5.0F);
                resGainHeld = std::clamp(p[SG_STRING_RES], 0.0F, 1.0F) * 0.25F;
                resGainDamper = sustain ? std::clamp(p[SG_DAMPER_RES], 0.0F, 1.0F) * 0.18F : 0.0F;
                resLimit = std::clamp(p[SG_SYMP_LIMIT], 0.0F, 1.0F) * 40.0F;
                const int bt = static_cast<int>(std::lround(p[SG_BODY_TYPE]));
                const float bg = std::clamp(p[SG_BODY], 0.0F, 1.0F) * 0.5F;
                if (bt != bodyType || bg != bodyGain) setBody(0, bt == 1 ? 1.3 : (bt == 2 ? 1.75 : 1.0), bg), bodyType = bt;
                // the held keys own a resonator each (the oldest one is given up when all are taken)
                ++resClock;
                for (auto& r : held) if (r.key >= 0 && !heldKeys[static_cast<std::size_t>(r.key)]) r.key = -1;   // the key went up: the line rings out and is free
                for (int k = 0; k < 128; ++k) {
                    if (!heldKeys[static_cast<std::size_t>(k)]) continue;
                    bool have = false;
                    for (const auto& r : held) if (r.key == k) { have = true; break; }
                    if (have) continue;
                    Res* slot = nullptr;
                    for (auto& r : held) if (r.key < 0) { if (slot == nullptr || r.age < slot->age) slot = &r; }
                    if (slot == nullptr) { for (auto& r : held) if (slot == nullptr || r.age < slot->age) slot = &r; }
                    if (slot == nullptr) break;
                    slot->key = k; slot->age = resClock;
                    const double hz = keyHz(k);
                    slot->len = std::clamp(sr / std::max(22.0, hz) - 1.0, 2.0, static_cast<double>(slot->buf.size() - 3U));
                    slot->g = std::min(0.998F, std::exp(-6.9F * static_cast<float>(slot->len / sr) / relSec));
                }
                for (auto& r : held) if (r.key < 0 && r.g > 0.0F) r.g = std::min(r.g, std::exp(-6.9F * static_cast<float>(r.len / sr) / relSec));
                if (damper[0].key < 0) {   // the undamped low strings: A1 .. F#4 every three semitones
                    for (int i = 0; i < kDamperRes; ++i) {
                        auto& r = damper[static_cast<std::size_t>(i)];
                        r.key = 33 + i * 3;
                        r.len = std::clamp(sr / keyHz(r.key) - 1.0, 2.0, static_cast<double>(r.buf.size() - 3U));
                    }
                }
                for (auto& r : damper) r.g = std::min(0.998F, std::exp(-6.9F * static_cast<float>(r.len / sr) / (relSec * 1.5F)));
                break;
            }
            case EngineType::Str1: {
                // SILVETON_ENGINES_V3: the body of the INSTRUMENT, in series (the string goes through it); BODY = how much
                const int inst = std::clamp(static_cast<int>(std::lround(p[ST_BODY_TYPE])), 0, kStr1Instruments - 1);
                strBodyMix = std::clamp(p[ST_BODY], 0.0F, 1.0F);
                if (inst != strBodyInst) { strBody.set(sr, inst); strBody.reset(); strBodyInst = inst; }
                break;
            }
            case EngineType::HD1: {
                if (p[HD_BOOST] != boostDb) { boostDb = p[HD_BOOST]; boost.setShelf(sr, 110.0F, std::clamp(boostDb, 0.0F, 12.0F), false); }
                break;
            }
            case EngineType::CX3: {
                (void)wheel;
                setWheels(p[CX_TUNING] >= 0.5F ? 1 : 0, std::clamp(p[CX_TAPER], 0.0F, 1.0F));
                break;
            }
            default: break;
        }
        for (auto& m : body) m.guard();
        strBody.guard();
    }

    void process(const silveton::sampler::EngineParams& e, float& l, float& r, float wheel) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (e.type) {
            case EngineType::Polysix: {
                if (modCfg.type == EffectType::Off) return;
                float wl = 0.0F, wr = 0.0F;
                mod.process(l, r, modCfg, wl, wr);
                const float mix = std::clamp(p[P6_FX_MIX], 0.0F, 1.0F);
                // SILVETON_ATTACK_V1: the dry sound stays on time and nearly whole, the effect is added beside it (before: at MIX 50
                // the dry was halved and the other half came ~7 ms late - the attack was smeared and 6 dB weaker, measured)
                const float dryG = 1.0F - 0.05F * mix, wetG = 0.7F * mix;   // SILVETON_BODY_V1: was 0.3 / 0.7 - at MIX 50 the sound lost 3 dB (measured)
                l = l * dryG + wl * wetG; r = r * dryG + wr * wetG;
                break;
            }
            case EngineType::HD1:
                if (boostDb > 0.05F) boost.process(l, r);
                break;
            case EngineType::Str1: {
                if (strBodyMix > 0.0F) {
                    const float mid = 0.5F * (l + r);
                    const float d = (strBody.tick(mid) - mid) * strBodyMix;
                    l += d; r += d;
                }
                break;
            }
            case EngineType::CX3: {
                // scanner vibrato / chorus
                const int vc = static_cast<int>(std::lround(p[CX_VIBCHO]));
                if (vc > 0) {
                    vibLine.push(l, r);
                    const int depthIx = (vc + 1) / 2;   // 1 = V1/C1, 2 = V2/C2, 3 = V3/C3
                    const double depth = sr * 0.00032 * depthIx;
                    vibPhase += 6.9 / sr; vibPhase -= std::floor(vibPhase);
                    const double tri = 1.0 - 4.0 * std::abs(vibPhase - 0.5);
                    const double d = sr * 0.0004 + depth * (0.5 + 0.5 * tri);
                    const float wl = vibLine.tapHL(d), wr = vibLine.tapHR(d);
                    const bool chorus = (vc % 2) == 0;
                    if (chorus) { l = 0.5F * (l + wl); r = 0.5F * (r + wr); } else { l = wl; r = wr; }
                }
                // the amplifier
                const float drive = std::clamp(p[CX_AMP_DRIVE], 0.0F, 1.0F);
                if (drive > 0.0F) {
                    const float g = 1.0F + 6.0F * drive;
                    l = tanhT(l * g) / std::sqrt(g) * (1.0F + 0.3F * drive); r = tanhT(r * g) / std::sqrt(g) * (1.0F + 0.3F * drive);
                }
                // Leslie: the horn and the drum, each with its own speeds and inertia (SILVETON_ENGINES_V2)
                const int rot = static_cast<int>(std::lround(p[CX_ROTARY]));
                if (rot > 0) {
                    const bool fast = rot == 2 || (p[CX_WHEEL_ROT] >= 0.5F && wheel >= 0.5F);
                    const double hornWant = fast ? std::clamp(static_cast<double>(p[CX_FAST]), 4.0, 9.0) : std::clamp(static_cast<double>(p[CX_SLOW]), 0.3, 1.5);
                    const double drumWant = fast ? std::clamp(static_cast<double>(p[CX_DRUM_FAST]), 3.0, 8.0) : std::clamp(static_cast<double>(p[CX_DRUM_SLOW]), 0.2, 1.5);
                    const double hornAcc = std::clamp(static_cast<double>(p[CX_HORN_ACCEL]), 0.2, 5.0);
                    const double drumAcc = std::clamp(static_cast<double>(p[CX_DRUM_ACCEL]), 0.5, 10.0);
                    const double hornTau = hornWant > hornSpeed ? hornAcc : hornAcc * 1.7;
                    const double drumTau = drumWant > drumSpeed ? drumAcc : drumAcc * 1.4;
                    hornSpeed += (hornWant - hornSpeed) * (1.0 - std::exp(-1.0 / (hornTau * sr)));
                    drumSpeed += (drumWant - drumSpeed) * (1.0 - std::exp(-1.0 / (drumTau * sr)));
                    hornPhase += hornSpeed / sr; hornPhase -= std::floor(hornPhase);
                    drumPhase += drumSpeed / sr; drumPhase -= std::floor(drumPhase);
                    const float mono = 0.5F * (l + r);
                    const float k = onePoleCoef(800.0, sr);
                    const float lo = xo2.lp(xo1.lp(mono, k), k);
                    const float hi = mono - lo;
                    hornLine.push(hi, hi);
                    const float mic = std::clamp(p[CX_MIC_DIST], 0.0F, 1.0F);   // close microphones: deep amplitude swing and Doppler
                    const double base = sr * 0.0006;
                    const double dop = sr * (0.0002 + 0.0005 * static_cast<double>(1.0F - mic));
                    const float swing = 0.25F + 0.5F * (1.0F - mic);
                    const float sA = sin01(hornPhase), sB = sin01(hornPhase + 0.5);
                    const float hl = hornLine.tapHL(base + dop * (1.0 + sA)) * (1.0F - swing + swing * sA);
                    const float hr = hornLine.tapHR(base + dop * (1.0 + sB)) * (1.0F - swing + swing * sB);
                    const float dsw = 0.12F + 0.25F * (1.0F - mic);
                    const float dl = lo * (1.0F - dsw + dsw * sin01(drumPhase));
                    const float dr = lo * (1.0F - dsw + dsw * sin01(drumPhase + 0.4));
                    const float bal = std::clamp(p[CX_HORN], 0.0F, 1.0F);
                    const float hg = 2.0F * bal, dg = 2.0F * (1.0F - bal);
                    l = hl * hg + dl * dg; r = hr * hg + dr * dg;
                }
                break;
            }
            case EngineType::EP: {
                const float drive = std::clamp(p[EP_PRE_DRIVE], 0.0F, 1.0F);
                if (drive > 0.0F) { const float g = 1.0F + 5.0F * drive; l = tanhT(l * g) / std::sqrt(g); r = tanhT(r * g) / std::sqrt(g); }
                if (bassDb != 0.0F) bass.process(l, r);
                if (trebleDb != 0.0F) treble.process(l, r);
                if (p[EP_TREM] >= 0.5F) {
                    tremPhase += std::clamp(static_cast<double>(p[EP_TREM_SPEED]), 0.5, 12.0) / sr; tremPhase -= std::floor(tremPhase);
                    const float d = std::clamp(p[EP_TREM_DEPTH], 0.0F, 1.0F);
                    const bool reed = p[EP_TYPE] >= 0.5F;
                    const float st = reed ? 0.0F : std::clamp(p[EP_TREM_STEREO], 0.0F, 1.0F);
                    const float gl = 1.0F - d * (0.5F - 0.5F * sin01(tremPhase));
                    const float gr = 1.0F - d * (0.5F - 0.5F * sin01(tremPhase + 0.5 * st));
                    l *= gl; r *= gr;
                }
                if (p[EP_CAB] >= 0.5F && cabSet) {
                    const float cd = std::clamp(p[EP_CAB_DRIVE], 0.0F, 1.0F);
                    if (cd > 0.0F) { const float g = 1.0F + 4.0F * cd; l = tanhT(l * g) / std::sqrt(g); r = tanhT(r * g) / std::sqrt(g); }
                    cabHp.process(l, r); cabPeak.process(l, r); cabLp.process(l, r);
                }
                break;
            }
            case EngineType::SGX: {
                const float in = 0.5F * (l + r);
                // the energy limit: the strings take less when they already carry a lot (the acoustic coupling is bounded)
                const float limitG = 1.0F / (1.0F + resLimit * resEnergy);
                float res = 0.0F;
                if (resGainHeld > 0.0F) {
                    for (int k = 0; k < kHeldRes; ++k) {
                        auto& rr = held[static_cast<std::size_t>(k)];
                        if (rr.key >= 0 || std::fabs(rr.lp) > 1.0e-6F)
                            res += rr.tick(rr.key >= 0 ? (in - ownNow[static_cast<std::size_t>(k)]) * resGainHeld * limitG : 0.0F, 0.35F);   // SILVETON_SGX_OWN_V1
                    }
                }
                if (resGainDamper > 0.0F || damper[0].lp != 0.0F) {
                    for (auto& rr : damper) res += rr.tick(in * resGainDamper * limitG, 0.3F);
                }
                resEnergy += (res * res - resEnergy) * 0.0005F;
                if (!finite(resEnergy)) resEnergy = 0.0F;
                l += res * 0.5F; r += res * 0.5F;
                if (bodyGain > 0.0F) { const float b = bodyTick(0.5F * (l + r)) * bodyGain; l += b; r += b; }
                if (lidDb < -0.05F) lid.process(l, r);
                break;
            }
            default: break;
        }
        // SILVETON_BODY_V1: ANALOG also opens the sound a little - like the ensemble of an analog poly. Above 250 Hz a copy of each side
        // is added to the whole sound, read from a short line at 2.6 ms (left) and 3.7 ms (right) that moves a little and slowly in
        // opposite directions (the pitch moves under one cent). The sound itself stays whole and on time; the bass stays in the
        // middle. Not for CX-3 / POLYSIX (their own Leslie / ensemble), nor for the pianos and the strings.
        if (e.type == EngineType::AL1 || e.type == EngineType::MS20 || e.type == EngineType::Mod7 || e.type == EngineType::EP) {
            const float an = std::clamp(p[E_ANALOG], 0.0F, 1.0F);
            if (an > 0.0F && vibLine.size > 64U) {
                const float k = onePoleCoef(250.0, sr);
                vibLine.push(l - awLpL.lp(l, k), r - awLpR.lp(r, k));
                awPh += 0.37 / sr; awPh -= std::floor(awPh);
                const double m = sr * 0.00018;
                const float wl = vibLine.tapHL(sr * 0.0026 + m * static_cast<double>(sin01(awPh)));
                const float wr = vibLine.tapHR(sr * 0.0037 - m * static_cast<double>(sin01(awPh + 0.21)));
                const float g = std::min(0.4F, 0.8F * an);
                l += wl * g; r += wr * g;
            }
        }
    }
};

// -------------------------------------------------------------- the per-sample part of a voice, after the recording was read
inline void EngineVoice::post(const silveton::sampler::EngineParams& e, float& l, float& r, double inc, double sr, std::uint32_t frame, const EngineBus& bus) noexcept {
    using namespace silveton::sampler;
    const float* p = e.p.data();
    switch (type) {
        case EngineType::MS20: {
            const bool hi = sr >= 88000.0; const int SAW = hi ? 90 : 1, PUL = hi ? 91 : 2;   // SILVETON_AUDIT_V1
            // the two VCOs next to the recording
            const int w1 = static_cast<int>(std::lround(p[MS_VCO1_WAVE]));
            const int w2 = static_cast<int>(std::lround(p[MS_VCO2_WAVE]));
            const float rec = engineRecOn(e) ? std::clamp(p[MS_REC_LEVEL], 0.0F, 1.0F) : 0.0F;   // SILVETON_ENGINES_V3: ЗВУК ОТ
            if (rec != 1.0F) { l *= rec; r *= rec; }
            // ESP: the envelope of the recording (what the external signal processor would follow)
            {
                const float a = std::fabs(0.5F * (l + r));
                espEnv += (a - espEnv) * (a > espEnv ? 0.02F : 0.0005F);
            }
            if ((w1 > 0 || w2 > 0) && engineOwnOn(e)) {
                float o1 = 0.0F, o2 = 0.0F, y1 = 0.0F;
                if (w1 > 0) {
                    if (w1 == 4) y1 = noise(rng) * 0.5F;
                    else if (w1 >= silveton::sampler::kOscOwnWaves) y1 = osc1.step(100 + w1 - silveton::sampler::kOscOwnWaves, inc, pwNow);
                    else y1 = osc1.step(w1 == 1 ? 3 : (w1 == 2 ? SAW : PUL), inc, pwNow);
                    o1 = osc1.out(y1) * std::clamp(p[MS_VCO1_LEVEL], 0.0F, 1.0F);
                }
                if (w2 > 0) {
                    const double inc2 = inc * std::exp2(static_cast<double>(std::clamp(p[MS_VCO2_PITCH], -24.0F, 24.0F)) / 12.0);
                    float y2;
                    if (w2 == 4) { y2 = osc2.step(PUL, inc2, 0.5F); y2 *= y1; }        // ring: VCO1 x a square VCO2
                    else if (w2 >= silveton::sampler::kOscOwnWaves) y2 = osc2.step(100 + w2 - silveton::sampler::kOscOwnWaves, inc2, pwNow);
                    else y2 = osc2.step(w2 == 1 ? SAW : PUL, inc2, w2 == 2 ? 0.5F : pwNow);
                    o2 = osc2.out(y2) * std::clamp(p[MS_VCO2_LEVEL], 0.0F, 1.0F);
                }
                const float s = (o1 + o2) * 0.6F;
                l += s; r += s;
            }
            if (hpfOn) {
                if (msParallel) { msHpL = l; msHpR = r; hpf.process(msHpL, msHpR); }
                else hpf.process(l, r);
            }
            break;
        }
        case EngineType::Polysix: {
            const bool hi = sr >= 88000.0; const int SAW = hi ? 90 : 1, PUL = hi ? 91 : 2;   // SILVETON_AUDIT_V1
            const int osc = static_cast<int>(std::lround(p[P6_OSC]));
            const float rec = engineRecOn(e) ? std::clamp(p[P6_REC_LEVEL], 0.0F, 1.0F) : 0.0F;   // SILVETON_ENGINES_V3: ЗВУК ОТ
            if (rec != 1.0F) { l *= rec; r *= rec; }
            if (osc > 0 && engineOwnOn(e)) {
                float y;
                if (osc >= silveton::sampler::kOscOwnWaves) y = osc1.step(100 + osc - silveton::sampler::kOscOwnWaves, inc, pwNow);
                else if (osc == 4) { y = 0.5F * (osc1.step(SAW, inc, pwNow) + osc2.step(PUL, inc, pwNow)); }
                else y = osc1.step(osc == 1 ? SAW : PUL, inc, pwNow);
                float o = osc1.out(y) * std::clamp(p[P6_OSC_LEVEL], 0.0F, 1.0F) * 0.6F;
                if ((p[P6_SUB_WAVE] >= 0.5F || recEnded || !engineRecOn(e)) && p[P6_SUB_LEVEL] > 0.0F) {   // the square sub-oscillator (V3: also when nothing is recorded)
                    const double div = p[P6_SUB_OCT] >= 1.5F ? 0.25 : 0.5;
                    o += osc3.out(osc3.step(PUL, inc * div, 0.5F)) * std::clamp(p[P6_SUB_LEVEL], 0.0F, 1.0F) * 0.5F;
                }
                l += o; r += o;
            }
            break;
        }
        case EngineType::AL1: {
            const float rec = engineRecOn(e) ? std::clamp(p[AL_REC_LEVEL], 0.0F, 1.0F) : 0.0F;   // SILVETON_ENGINES_V3: ЗВУК ОТ
            if (rec != 1.0F) { l *= rec; r *= rec; }
            const bool own = engineOwnOn(e);
            const bool noRec = recEnded || !engineRecOn(e);   // SILVETON_ENGINES_V3: nothing recorded: the PCM knobs take the oscillators
            const float ring = std::clamp(p[AL_RING_LEVEL], 0.0F, 1.0F);
            float ringM = 1.0F;
            if (ring > 0.0F) {
                ringPhase += inc * static_cast<double>(p[AL_RING_RATIO]);
                ringM = 1.0F - ring + ring * sin01(ringPhase);
                l *= ringM; r *= ringM;
            }
            // the two band-limited oscillators: 2 may be synced to 1, 2 may modulate the frequency of 1 (never below zero), 1 x 2 ring
            // SILVETON_ENGINES_V3: 5.. = the table waves (codes 100..)
            const bool hi = sr >= 88000.0;   // SILVETON_AUDIT_V1: the saw / pulse from the table at the high rates
            const auto code = [hi](int w) { return w >= silveton::sampler::kOscOwnWaves ? 100 + w - silveton::sampler::kOscOwnWaves : (hi && w == 1 ? 90 : (hi && w == 2 ? 91 : w)); };
            const int w1 = own ? code(static_cast<int>(std::lround(p[AL_OSC1_WAVE]))) : 0;
            const int w2 = own ? code(static_cast<int>(std::lround(p[AL_OSC2_WAVE]))) : 0;
            if (w1 > 0 || w2 > 0) {
                const double inc2 = inc * std::exp2((static_cast<double>(std::clamp(p[AL_OSC2_SEMI], -24.0F, 24.0F)) + static_cast<double>(std::clamp(p[AL_OSC2_FINE], -100.0F, 100.0F)) / 100.0) / 12.0);
                float y2 = 0.0F;
                const float fm = std::clamp(p[AL_OSC_FM], 0.0F, 2.0F);
                double inc1 = fm > 0.0F ? std::max(inc * (1.0 + static_cast<double>(fm) * static_cast<double>(osc2.dly)), 0.0) : inc;   // frequency modulation, the frequency never turns negative
                // SILVETON_ENGINES_V3: PCM FM / PCM SYNC on the oscillators when there is no recording
                double incA = 0.0;
                if (noRec && fmNow > 0.0F) {
                    alFmPh += inc * static_cast<double>(p[AL_FM_RATIO]); alFmPh -= std::floor(alFmPh);
                    const float pmv = fmNow * 0.5F * sin01(alFmPh);
                    incA = static_cast<double>(pmv - alFmLast); alFmLast = pmv;   // the phase moves = a frequency change
                }
                const bool pcmSync = noRec && p[AL_SYNC] >= 0.5F;
                const double sr2 = pcmSync ? std::clamp(static_cast<double>(p[AL_SYNC_RATIO]), 1.0, 4.0) : 1.0;
                inc1 = std::max(inc1 * sr2 + incA, 0.0);
                const double inc2s = std::max(inc2 * sr2 + incA, 0.0);
                float y1 = 0.0F;
                if (w2 > 0) y2 = osc2.step(w2, inc2s, pwNow);
                if (w1 > 0) y1 = osc1.step(w1, inc1, pwNow);
                if (pcmSync) {   // the master is the key: every period of the key both oscillators restart
                    alSyncPh += inc;
                    if (alSyncPh >= 1.0) {
                        alSyncPh -= std::floor(alSyncPh);
                        const double d = inc > 0.0 ? alSyncPh / inc : 0.0;
                        if (w1 > 0) osc1.sync(w1, inc1, pwNow, d, y1);
                        if (w2 > 0) osc2.sync(w2, inc2s, pwNow, d, y2);
                    }
                }
                if (w2 > 0 && w1 > 0 && p[AL_OSC_SYNC] >= 0.5F && osc1.wrapped) osc2.sync(w2, inc2s, pwNow, osc1.wrapD, y2);
                const float o1 = w1 > 0 ? osc1.out(y1) : 0.0F;
                const float o2 = w2 > 0 ? osc2.out(y2) : 0.0F;
                float s = o1 * std::clamp(p[AL_OSC1_LEVEL], 0.0F, 1.0F) + o2 * std::clamp(p[AL_OSC2_LEVEL], 0.0F, 1.0F);
                const float rg = std::clamp(p[AL_OSC_RING], 0.0F, 1.0F);
                if (rg > 0.0F) s += o1 * o2 * rg;
                s *= 0.6F;
                if (noRec) {
                    s *= ringM;   // PCM RING on the oscillators
                    const float sub = std::clamp(p[AL_SUB_LEVEL], 0.0F, 1.0F);
                    if (sub > 0.0F) s += osc3.out(osc3.step(hi ? 91 : 2, inc * (p[AL_SUB_OCT] >= 1.5F ? 0.25 : 0.5), 0.5F)) * sub * 0.4F;   // the square sub
                }
                l += s; r += s;
            }
            const float nl = own ? std::clamp(p[AL_NOISE_LEVEL], 0.0F, 1.0F) : 0.0F;
            if (nl > 0.0F) {
                const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::clamp(p[AL_NOISE_COLOR], 100.0F, 20000.0F) / static_cast<float>(sr));
                const float n = noiseLp.lp(noise(rng), a) * nl * 0.5F;
                l += n; r += n;
            }
            const float sh = std::clamp(p[AL_SHAPE], 0.0F, 1.0F);
            if (sh > 0.0F) { l = softFold(l, sh); r = softFold(r, sh); }
            break;
        }
        case EngineType::Mod7: {
            const float pcm = engineRecOn(e) ? std::clamp(p[M7_PCM_LEVEL], 0.0F, 1.0F) : 0.0F;   // SILVETON_ENGINES_V3: ЗВУК ОТ
            if (pcm != 1.0F) { l *= pcm; r *= pcm; }
            const float ring = std::clamp(p[M7_RING], 0.0F, 1.0F);
            if (ring > 0.0F) { const float m = 1.0F - ring + ring * ringNow; l *= m; r *= m; }
            if (carrierSum != 0.0F && engineOwnOn(e)) { l += carrierSum; r += carrierSum; }
            if ((recEnded || !engineRecOn(e)) && engineOwnOn(e)) {   // SILVETON_ENGINES_V3: no recording - operator 1 is a sine (PCM LEVEL = its level)
                op1Ph += inc; op1Ph -= std::floor(op1Ph);
                float o1 = sin01(op1Ph + static_cast<double>(m7Pm0)) * std::clamp(p[M7_PCM_LEVEL], 0.0F, 1.0F) * 0.5F;
                if (ring > 0.0F) o1 *= 1.0F - ring + ring * ringNow;
                l += o1; r += o1;
            }
            const int ws = static_cast<int>(std::lround(p[M7_WS_TYPE]));
            if (ws > 0) {
                const float d = std::clamp(p[M7_WS_DRIVE], 0.0F, 1.0F);
                const float mix = std::clamp(p[M7_WS_MIX], 0.0F, 1.0F);
                const float g = 1.0F + 9.0F * d;
                const auto shape = [&](float x) noexcept {
                    switch (ws) {
                        case 1: return tanhT(x * g) / tanhT(g);
                        case 2: return std::clamp(x * g, -1.0F, 1.0F) * (1.0F / std::min(g, 4.0F));
                        case 3: return softFold(x, d);
                        default: return sin01(static_cast<double>(x * g) * 0.25);
                    }
                };
                l += (shape(l) - l) * mix; r += (shape(r) - r) * mix;
            }
            break;
        }
        case EngineType::Str1: {
            // SILVETON_ENGINES_V3: ЗВУК ОТ = СОБСТВЕН - the recording neither excites the string nor is heard
            const bool rec = engineRecOn(e);
            const float in = rec ? 0.5F * (l + r) : 0.0F;
            const float out = bowOn ? bowTick(e, in, sr, inc) : (windOn ? windTick(e, in, sr, inc) : stringTick(e, in, sr, inc));
            const float sl = std::clamp(p[ST_STRING], 0.0F, 1.0F);
            float ex = rec ? std::clamp(p[ST_EXCITE], 0.0F, 1.0F) : 0.0F;
            // SILVETON_STR1_FIX_V1: the hit of the recording is heard as it is - the first 15 ms in full, then over about 40 ms
            // down to EXCITE (before, the string took ~40 ms to speak and the recording was at EXCITE from the start: no attack)
            if (rec && ex < 1.0F && strAgeSec < 0.2) {
                const double t = strAgeSec - 0.015;
                const float hitNow = t <= 0.0 ? 1.0F : static_cast<float>(std::exp(-t / 0.04));
                ex += (1.0F - ex) * hitNow;
            }
            l = out * sl + l * ex; r = out * sl + r * ex;
            break;
        }
        case EngineType::CX3: {
            // the shared wheels of the Upper (the bus computed this chunk's samples before the voices started)
            float organ = 0.0F;
            for (int k = 0; k < 9; ++k) {
                const auto i = static_cast<std::size_t>(k);
                twLevel[i] += (twTarget[i] - twLevel[i]) * 0.002F;   // SILVETON_AUDIT_V1: a few ms of glide
                const float lev = twLevel[i];
                if (lev <= 0.0F) continue;
                organ += bus.wheel(twWheel[i], frame) * lev;
            }
            if (percEnv > 0.0F) {
                organ += bus.wheel(percWheel, frame) * percEnv * percGain * 0.8F;
                percEnv *= percCoef; if (percEnv < 1.0e-4F) percEnv = 0.0F;
            }
            if (leakLevel > 0.0F) {   // the neighbours of the 8' wheel leak in
                const int w8 = twWheel[2];
                organ += (bus.wheel(w8 - 1, frame) + bus.wheel(w8 + 1, frame)) * leakLevel;
            }
            if (clickEnv > 0.0F) {
                organ += clickLp.lp(noise(rng), 0.35F) * clickEnv * 0.6F;
                clickEnv *= clickCoef; if (clickEnv < 1.0e-4F) clickEnv = 0.0F;
            }
            if (keyOffEnv > 0.0F) {   // the key-off click
                organ += clickLp.lp(noise(rng), 0.35F) * keyOffEnv * std::clamp(p[CX_CLICK], 0.0F, 1.0F) * 0.4F;
                keyOffEnv *= clickCoef > 0.0F ? clickCoef : 0.9F; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
            }
            organ *= engineOwnOn(e) ? 0.35F : 0.0F;   // SILVETON_ENGINES_V3: ЗВУК ОТ
            const float smp = engineRecOn(e) ? (engineOwnOn(e) ? std::clamp(p[CX_SAMPLE], 0.0F, 1.0F) : 1.0F) : 0.0F;
            l = organ + l * smp; r = organ + r * smp;
            break;
        }
        case EngineType::SGX: {
            if (brightA < 0.999F) { l = brightL.lp(l, brightA); r = brightR.lp(r, brightA); }
            if (hammerEnv > 0.0F) {
                const float n = noise(rng) * hammerEnv * 0.5F;
                l += n; r += n;
                hammerEnv *= hammerCoef; if (hammerEnv < 1.0e-4F) hammerEnv = 0.0F;
            }
            if (keyOffEnv > 0.0F) {
                float n = noise(rng), n2 = n;
                keyOffBp.process(n, n2, FilterMode::BandPass, std::clamp(p[SG_KEYOFF_TONE], 200.0F, 8000.0F), 0.5F, sr);
                const float g = keyOffEnv * std::clamp(p[SG_KEYOFF], 0.0F, 1.0F) * 0.5F;
                l += n * g; r += n2 * g;
                keyOffEnv *= keyOffCoef; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
            }
            break;
        }
        case EngineType::EP: {
            const float rec = engineRecOn(e) ? std::clamp(p[EP_REC_LEVEL], 0.0F, 1.0F) : 0.0F;   // SILVETON_ENGINES_V3: ЗВУК ОТ
            if (rec != 1.0F) { l *= rec; r *= rec; }
            const float gen = engineOwnOn(e) ? std::clamp(p[EP_MODEL], 0.0F, 1.0F) : 0.0F;
            if (gen > 0.0F) {   // the tine / reed model: three damped partials, struck by a short burst, through the pickup
                // SILVETON_ENGINES_V2: pitch bend / glide retune the three modes (their decay and level stay)
                if (inc > 1.0e-7 && tineInc > 0.0 && std::fabs(inc - tineInc) > tineInc * 1.0e-4) {
                    tineInc = inc;
                    for (std::size_t k = 0; k < tine.size(); ++k) {
                        const double w = 2.0 * kPi * std::min(inc * tineRatio[k], 0.45);
                        tine[k].a1 = static_cast<float>(2.0 * std::sqrt(std::max(0.0, -static_cast<double>(tine[k].a2))) * std::cos(w));
                    }
                }
                float x = 0.0F;
                if (tineHit > 0) { x = tineLp.lp(tineExc, tineLpA); --tineHit; }
                else if (tineLp.z > 1.0e-6F) x = tineLp.lp(0.0F, tineLpA);
                float t = 0.0F;
                for (auto& m : tine) t += m.tick(x);
                // the pickup: a saturating, slightly one-sided curve (even harmonics), louder with the hit
                const float d = 1.0F + 6.0F * std::clamp(p[EP_PICKUP_DRIVE], 0.0F, 1.0F);
                const float bias = 0.4F * std::clamp(p[EP_PICKUP_SYM], 0.0F, 1.0F);
                float y = (tanhT(d * (t + bias)) - tanhT(d * bias)) / d;
                // SILVETON_AUDIT_V1: the one-sided pickup rectifies a little - 12..17 % of the level was DC (measured): an 8 Hz high-pass
                { const float yo = y - epDcX + epDcR * epDcY; epDcX = y; epDcY = yo; y = yo; }
                const float s = y * gen * 1.6F;
                l += s; r += s;
            }
            if (bellGain > 0.0F) {   // the bell: the part above ~2 kHz, louder with the hit
                const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * 2000.0F / static_cast<float>(sr));
                l += (l - bellL.lp(l, a)) * bellGain; r += (r - bellR.lp(r, a)) * bellGain;
            }
            if (barkDrive > 0.0F) {
                const float g = 1.0F + barkDrive;
                l = tanhT(l * g) / std::sqrt(g); r = tanhT(r * g) / std::sqrt(g);
            }
            if (keyOffEnv > 0.0F) {
                float n = noise(rng), n2 = n;
                keyOffBp.process(n, n2, FilterMode::BandPass, 3000.0F, 0.4F, sr);
                const float g = keyOffEnv * std::clamp(p[EP_KEYOFF], 0.0F, 1.0F) * 0.3F;
                l += n * g; r += n2 * g;
                keyOffEnv *= keyOffCoef; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
            }
            break;
        }
        default: break;
    }
}

} // namespace eng
