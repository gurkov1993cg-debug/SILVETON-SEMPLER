// SILVETON_ENGINES_V1 - the sound of the nine engines (see include/silveton/sampler/EngineDefs.h).
// Included by SamplerEngine.cpp inside its file-local namespace, after the filters, ModEngine, Biquad and HeapLine:
// it uses them. Two parts:
//   eng::EngineVoice - lives in every voice: the per-note part of an engine (FM / ring / sync, MOD-7 operators and
//                      waveshaper, the STR-1 string, the CX-3 tonewheels / percussion / click, SGX and EP noises, the
//                      filter envelope, the MS-20 HPF and EG1, the LFO).
//   eng::EngineBus   - one per Upper, after the sum of its sounds: Polysix chorus / phase / ensemble, the CX-3 scanner
//                      vibrato / chorus and Leslie, the EP preamp / tremolo / cabinet, the SGX string and damper resonance
//                      and lid, the HD-1 low boost.
// Everything here is our own model of the original instruments.
#pragma once

#include "silveton/sampler/EngineDefs.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace eng {

constexpr int kSineBits = 12;
constexpr int kSineSize = 1 << kSineBits;

inline const float* sineTable() noexcept {
    static const std::array<float, kSineSize + 1> table = [] {
        std::array<float, kSineSize + 1> t{};
        for (int i = 0; i <= kSineSize; ++i) t[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(2.0 * kPi * static_cast<double>(i) / kSineSize));
        return t;
    }();
    return table.data();
}

// sine of a phase given in cycles (any value)
inline float sin01(double cycles) noexcept {
    cycles -= std::floor(cycles);
    const double x = cycles * kSineSize;
    const int i = static_cast<int>(x);
    const float f = static_cast<float>(x - static_cast<double>(i));
    const float* t = sineTable();
    const auto k = static_cast<std::size_t>(std::min(i, kSineSize - 1));
    return t[k] + (t[k + 1U] - t[k]) * f;
}

inline float wrap01(double& ph) noexcept { ph -= std::floor(ph); return static_cast<float>(ph); }

inline float noise(std::uint32_t& s) noexcept {
    s = s * 1664525U + 1013904223U;
    return static_cast<float>(s >> 8) / 8388608.0F - 1.0F;
}

inline float softFold(float x, float amount) noexcept {
    if (amount <= 0.0F) return x;
    const float g = 1.0F + 4.0F * amount;
    float y = x * g;
    // triangle fold between -1 and 1
    y = std::fabs(std::fmod(y + 1.0F, 4.0F));
    if (y > 2.0F) y = 4.0F - y;
    return (y - 1.0F) * (1.0F - 0.55F * amount);
}

// Per-block ADSR: linear attack, exponential decay / release. dt = seconds per step.
struct Adsr {
    int stage{0};   // 0 idle 1 attack 2 decay 3 sustain 4 release
    float v{0.0F};
    void on() noexcept { stage = 1; }
    void off() noexcept { if (stage != 0) stage = 4; }
    float step(float aMs, float dMs, float s, float rMs, float dt) noexcept {
        s = std::clamp(s, 0.0F, 1.0F);
        switch (stage) {
            case 1: v += dt * 1000.0F / std::max(aMs, 0.1F); if (v >= 1.0F) { v = 1.0F; stage = 2; } break;
            case 2: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(dMs, 1.0F)); v += (s - v) * k; if (std::fabs(v - s) < 0.001F) { v = s; stage = 3; } } break;
            case 3: v = s; break;
            case 4: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(rMs, 1.0F)); v -= v * k; if (v < 0.0005F) { v = 0.0F; stage = 0; } } break;
            default: v = 0.0F; break;
        }
        return v;
    }
};

// MS-20 EG1: delay, attack, then held at 1 while the key is down, release when it goes up.
struct Dar {
    int stage{0};   // 0 idle 1 delay 2 attack 3 hold 4 release
    float v{0.0F};
    float t{0.0F};
    void on() noexcept { stage = 1; t = 0.0F; v = 0.0F; }
    void off() noexcept { if (stage != 0) stage = 4; }
    float step(float delayMs, float aMs, float rMs, float dt) noexcept {
        switch (stage) {
            case 1: t += dt * 1000.0F; if (t >= delayMs) stage = 2; break;
            case 2: v += dt * 1000.0F / std::max(aMs, 0.1F); if (v >= 1.0F) { v = 1.0F; stage = 3; } break;
            case 3: v = 1.0F; break;
            case 4: { const float k = 1.0F - std::exp(-dt * 1000.0F * 4.6F / std::max(rMs, 1.0F)); v -= v * k; if (v < 0.0005F) { v = 0.0F; stage = 0; } } break;
            default: v = 0.0F; break;
        }
        return v;
    }
};

// a one-pole in both directions
struct Pole { float z{0.0F}; float lp(float x, float a) noexcept { z += (x - z) * a; return z; } };

// RBJ low / high pass (Butterworth Q) - the cabinet
struct Lp2 {
    float b0{1.0F}, b1{0.0F}, b2{0.0F}, a1{0.0F}, a2{0.0F};
    float z1L{0.0F}, z2L{0.0F}, z1R{0.0F}, z2R{0.0F};
    void set(double sr, double hz, bool high, double q = 0.7071) noexcept {
        const double w0 = 2.0 * kPi * std::clamp(hz, 10.0, 0.45 * sr) / sr;
        const double c = std::cos(w0), s = std::sin(w0), al = s / (2.0 * q);
        double B0, B1, B2;
        if (high) { B0 = (1.0 + c) * 0.5; B1 = -(1.0 + c); B2 = (1.0 + c) * 0.5; }
        else { B0 = (1.0 - c) * 0.5; B1 = 1.0 - c; B2 = (1.0 - c) * 0.5; }
        const double A0 = 1.0 + al, A1 = -2.0 * c, A2 = 1.0 - al;
        b0 = static_cast<float>(B0 / A0); b1 = static_cast<float>(B1 / A0); b2 = static_cast<float>(B2 / A0);
        a1 = static_cast<float>(A1 / A0); a2 = static_cast<float>(A2 / A0);
    }
    static float tick(float x, float& z1, float& z2, float b0, float b1, float b2, float a1, float a2) noexcept {
        const float y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y;
    }
    void process(float& l, float& r) noexcept { l = tick(l, z1L, z2L, b0, b1, b2, a1, a2); r = tick(r, z1R, z2R, b0, b1, b2, a1, a2); }
    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0F; }
};

// what the per-block update needs to know about the player
struct BlockCtx {
    double sr{48000.0};
    float dt{0.001F};        // seconds of this block
    float wheel{0.0F};       // CC1 0..1
    float soft{0.0F};        // CC67 0..1
    float velNorm{1.0F};
    int key{60};
    bool keyHeld{true};
};

// ---------------------------------------------------------------------------------------------------------------
struct EngineVoice {
    static constexpr int kStringMax = 4096;   // one period down to 23 Hz at 96 kHz
    static constexpr int kPickMax = 2048;

    silveton::sampler::EngineType type{silveton::sampler::EngineType::Off};
    bool live{false};            // the Upper's ENGINE is on and is still the one this note started with
    double syncHome{0.0};        // AL-1 SYNC: where the recording restarts (the note's start; a looped recording restarts at its loop)
    float keyHz{440.0F};
    double inc0{0.0};            // cycles per sample of the key, when the recording has no known period
    std::uint32_t rng{0x51ED1234U};
    float random{0.0F};
    float velNorm{1.0F};
    bool keyDown{true};
    // per-block modulation results (read by the voice loop as constants of the block)
    float egF{0.0F};             // filter envelope 0..1
    float cutOct{0.0F};          // to the main filter
    float pitchSemis{0.0F};      // to the pitch
    float ampMul{1.0F};          // to the level
    float fmNow{0.0F};           // FM depth of this block (AL-1 / MOD-7 op2)
    float fm3Now{0.0F};
    float panOffset{0.0F};       // SGX key position
    float lfoNow{0.0F};
    Adsr feg{};
    Dar eg1{};
    double lfoPhase{0.0};
    float lfoHold{0.0F};
    bool lfoNew{true};
    // MS-20 HPF
    StateVariableFilter hpf{};
    float hpfHz{20.0F}, hpfRes{0.0F};
    bool hpfOn{false};
    // HP / BP main filter of the common block (types 3 / 4 of filterTypeNow)
    StateVariableFilter svf{};
    float svfHz{1000.0F}, svfRes{0.0F};
    // FM / ring (AL-1, MOD-7)
    double op2Phase{0.0}, op3Phase{0.0}, ringPhase{0.0};
    float op2Prev{0.0F}, ringNow{0.0F};
    // AL-1 noise, sync
    Pole noiseLp{};
    double syncPhase{0.0};
    double syncOldPos{0.0};
    int syncXfade{0};
    bool syncArmed{false};
    // STR-1 string
    std::array<float, kStringMax> str{};
    std::array<float, kPickMax> pick{};
    int strW{0}, pickW{0};
    double strLen{100.0};        // fractional delay in samples
    float strG{0.99F};           // loop gain per pass
    float strLpA{0.5F};          // loop damping coefficient
    float strApA{0.0F};          // dispersion allpass coefficient
    float strLpZ{0.0F}, strApX{0.0F}, strApY{0.0F}, strFbZ{0.0F};
    double strAgeSec{0.0};
    float strOutPrev{0.0F};
    // CX-3
    std::array<double, 9> twPhase{};
    std::array<float, 9> twInc{};
    std::array<float, 9> twLevel{};
    std::array<float, 9> twTaper{};
    float percEnv{0.0F}, percCoef{0.0F}, percGain{0.0F};
    int percPartial{-1};
    float clickEnv{0.0F}, clickCoef{0.0F};
    Pole clickLp{};
    float leakLevel{0.0F};
    // SGX / EP noises and colour
    float hammerEnv{0.0F}, hammerCoef{0.0F};
    float keyOffEnv{0.0F}, keyOffCoef{0.0F};
    bool keyOffDone{false};
    StateVariableFilter keyOffBp{};
    Pole brightL{}, brightR{};
    float brightA{1.0F};
    Pole bellL{}, bellR{};
    float bellGain{0.0F}, barkDrive{0.0F};
    // HD-1 pitch envelope
    float pegNow{0.0F};

    // -------------------------------------------------------------- note on / off
    void noteOn(const silveton::sampler::EngineParams& e, double sr, float hz, float vel, float rnd, double periodFrames, std::uint32_t seed, bool percAllowed) noexcept {
        using namespace silveton::sampler;
        type = e.type;
        keyHz = std::max(1.0F, hz);
        inc0 = static_cast<double>(keyHz) / std::max(1.0, sr);
        (void)periodFrames;
        rng = seed | 1U;
        random = rnd;
        velNorm = std::clamp(vel, 0.0F, 1.0F);
        keyDown = true;
        feg = Adsr{}; feg.on();
        eg1 = Dar{}; eg1.on();
        lfoPhase = 0.0; lfoNew = true; lfoHold = 0.0F;
        hpf.reset(); svf.reset(); hpfOn = false;
        op2Phase = op3Phase = ringPhase = 0.0; op2Prev = 0.0F; ringNow = 0.0F;
        noiseLp = Pole{};
        syncPhase = 0.0; syncXfade = 0; syncArmed = false;
        egF = cutOct = pitchSemis = 0.0F; ampMul = 1.0F; fmNow = fm3Now = 0.0F; panOffset = 0.0F;
        percEnv = clickEnv = hammerEnv = keyOffEnv = 0.0F; keyOffDone = false; percPartial = -1;
        pegNow = 0.0F;
        if (!e.on()) return;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::Str1: {
                std::fill(str.begin(), str.end(), 0.0F); std::fill(pick.begin(), pick.end(), 0.0F);
                strW = pickW = 0; strLpZ = strApX = strApY = strFbZ = 0.0F; strAgeSec = 0.0; strOutPrev = 0.0F;
                setString(e, sr);
                break;
            }
            case EngineType::CX3: {
                // Hammond footages: 16' 5⅓' 8' 4' 2⅔' 2' 1⅗' 1⅓' 1'
                static const float ratios[9] = {0.5F, 1.5F, 1.0F, 2.0F, 3.0F, 4.0F, 5.0F, 6.0F, 8.0F};
                const bool percOn = p[CX_PERC] >= 0.5F;
                for (int k = 0; k < 9; ++k) {
                    float f = keyHz * ratios[k];
                    // tonewheel foldback: no wheel below C1 (32.7 Hz) or above the 91st (≈ 5920 Hz)
                    while (f < 32.0F) f *= 2.0F;
                    while (f > 5950.0F) f *= 0.5F;
                    twInc[static_cast<std::size_t>(k)] = static_cast<float>(f / sr);
                    twPhase[static_cast<std::size_t>(k)] = static_cast<double>(noise(rng)) * 0.5 + 0.5;   // the wheels are always turning
                    // the generator's output tapers towards the top (the real resistor network)
                    twTaper[static_cast<std::size_t>(k)] = 1.0F - 0.35F * std::clamp((f - 1000.0F) / 5000.0F, 0.0F, 1.0F);
                    float db = p[CX_DB16 + k];
                    if (percOn && k == 8) db = 0.0F;   // the 1' drawbar is borrowed by the percussion (as on the B-3)
                    twLevel[static_cast<std::size_t>(k)] = db <= 0.0F ? 0.0F : std::pow(10.0F, (db - 8.0F) * 3.0F / 20.0F);
                }
                if (percOn && percAllowed) {
                    percPartial = p[CX_PERC] >= 1.5F ? 4 : 3;   // 3rd = 2⅔', 2nd = 4'
                    const float decaySec = p[CX_PERC_DECAY] >= 0.5F ? 0.9F : 0.3F;
                    percCoef = std::exp(-1.0F / (decaySec * static_cast<float>(sr)) * 4.6F);
                    percGain = p[CX_PERC_LEVEL] >= 0.5F ? 1.0F : 0.5F;
                    percEnv = 1.0F;
                }
                clickEnv = std::clamp(p[CX_CLICK], 0.0F, 1.0F) * 0.9F;
                clickCoef = std::exp(-1.0F / (0.004F * static_cast<float>(sr)));
                leakLevel = std::clamp(p[CX_LEAK], 0.0F, 1.0F) * 0.012F;
                break;
            }
            case EngineType::SGX: {
                hammerEnv = std::clamp(p[SG_HAMMER], 0.0F, 1.0F) * velNorm * velNorm * 0.8F;
                hammerCoef = std::exp(-1.0F / (0.005F * static_cast<float>(sr)));
                keyOffCoef = std::exp(-1.0F / (0.035F * static_cast<float>(sr)));
                // the brightness of the hit: a soft note is darker
                const float vb = std::clamp(p[SG_VEL_BRIGHT], 0.0F, 1.0F);
                const float hz2 = 20000.0F * std::pow(0.12F + 0.88F * velNorm, 1.5F * vb);
                brightA = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::clamp(hz2, 300.0F, 20000.0F) / static_cast<float>(sr));
                brightL = Pole{}; brightR = Pole{};
                const int key = static_cast<int>(std::lround(69.0 + 12.0 * std::log2(static_cast<double>(keyHz) / 440.0)));
                panOffset = std::clamp(static_cast<float>(key - 60) / 36.0F, -1.0F, 1.0F) * std::clamp(p[SG_WIDTH], 0.0F, 1.0F);
                break;
            }
            case EngineType::EP: {
                bellGain = std::clamp(p[EP_BELL], 0.0F, 1.0F) * velNorm * velNorm * 2.5F;
                barkDrive = std::clamp(p[EP_BARK], 0.0F, 1.0F) * velNorm * velNorm * 3.0F;
                bellL = Pole{}; bellR = Pole{};
                keyOffCoef = std::exp(-1.0F / (0.025F * static_cast<float>(sr)));
                break;
            }
            case EngineType::HD1: pegNow = p[HD_PEG_CENTS] * 0.01F; break;
            default: break;
        }
    }

    void noteOff() noexcept {
        keyDown = false;
        feg.off();
        eg1.off();
        // the key-off noises of the organ, the piano and the EP
        if (!keyOffDone) { keyOffDone = true; keyOffEnv = 1.0F; }
    }

    void setString(const silveton::sampler::EngineParams& e, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        const int key = static_cast<int>(std::lround(69.0 + 12.0 * std::log2(static_cast<double>(keyHz) / 440.0)));
        const double hz = static_cast<double>(keyHz) * std::pow(2.0, static_cast<double>(p[ST_TUNE]) / 1200.0);
        const float disp = std::clamp(p[ST_DISP], 0.0F, 1.0F);
        strApA = -0.55F * disp;                                   // first-order allpass: negative = the highs arrive earlier (stiff string)
        const double apDelay = (1.0 - static_cast<double>(strApA)) / (1.0 + static_cast<double>(strApA));
        const float damp = std::clamp(p[ST_DAMP], 0.0F, 1.0F);
        strLpA = 1.0F - 0.85F * damp;                             // loop low-pass
        const double lpDelay = (1.0 - static_cast<double>(strLpA)) / static_cast<double>(strLpA) * 0.5;
        strLen = std::clamp(sr / std::max(20.0, hz) - apDelay - lpDelay - 1.0, 4.0, static_cast<double>(kStringMax - 4));
        float decay = std::clamp(p[ST_DECAY], 0.05F, 20.0F);
        decay *= std::pow(2.0F, -static_cast<float>(key - 48) / 24.0F * std::clamp(p[ST_KEY_DECAY], 0.0F, 1.0F));
        strG = std::exp(-6.9F * static_cast<float>(strLen / sr) / decay);
        strG = std::min(strG, 0.9995F);
    }

    // -------------------------------------------------------------- once per block
    void block(const silveton::sampler::EngineParams& e, const BlockCtx& c) noexcept {
        using namespace silveton::sampler;
        if (!e.on()) { cutOct = pitchSemis = 0.0F; ampMul = 1.0F; return; }
        const float* p = e.p.data();
        // the filter envelope (the common ADSR)
        egF = feg.step(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], c.dt);
        // the LFO
        {
            const double rate = std::clamp(static_cast<double>(p[E_LFO_RATE]), 0.05, 30.0);
            const double before = lfoPhase;
            lfoPhase += rate * c.dt; lfoPhase -= std::floor(lfoPhase);
            const int wave = static_cast<int>(std::lround(p[E_LFO_WAVE]));
            const float ph = static_cast<float>(lfoPhase);
            switch (wave) {
                case 1: lfoNow = 1.0F - 4.0F * std::fabs(ph - 0.5F); break;
                case 2: lfoNow = 2.0F * ph - 1.0F; break;
                case 3: lfoNow = ph < 0.5F ? 1.0F : -1.0F; break;
                case 4: if (lfoNew || lfoPhase < before) { lfoHold = noise(rng); lfoNew = false; } lfoNow = lfoHold; break;
                default: lfoNow = sin01(lfoPhase); break;
            }
        }
        cutOct = p[E_FEG_AMT] * egF + p[E_LFO_CUT] * lfoNow;
        pitchSemis = p[E_LFO_PITCH] * 0.01F * lfoNow;
        ampMul = std::max(0.0F, 1.0F - std::clamp(p[E_LFO_AMP], 0.0F, 1.0F) * (0.5F - 0.5F * lfoNow));
        fmNow = fm3Now = 0.0F;
        switch (type) {
            case EngineType::MS20: {
                const float g1 = eg1.step(p[MS_EG1_DELAY], p[MS_EG1_ATTACK], p[MS_EG1_RELEASE], c.dt);
                pitchSemis += p[MS_EG1_PITCH] * g1;
                float hpfOct = p[MS_EG1_HPF] * g1 + p[MS_MG_HPF] * lfoNow;
                const int to = static_cast<int>(std::lround(p[MS_WHEEL_TO]));
                const float wa = std::clamp(p[MS_WHEEL_AMT], 0.0F, 1.0F) * c.wheel;
                if (to == 1) pitchSemis += wa * 12.0F;
                else if (to == 2) cutOct += wa * 4.0F;
                else if (to == 3) hpfOct += wa * 4.0F;
                else if (to == 4) ampMul *= 1.0F - 0.9F * wa;
                hpfHz = std::clamp(p[MS_HPF_CUT] * std::exp2(hpfOct), 20.0F, 20000.0F);
                hpfRes = std::clamp(p[MS_HPF_PEAK], 0.0F, 1.0F);
                const bool want = hpfHz > 25.0F || hpfRes > 0.01F;
                if (want && !hpfOn) hpf.reset();
                hpfOn = want;
                break;
            }
            case EngineType::AL1: {
                const float eg = std::clamp(p[AL_FM_EG], 0.0F, 1.0F);
                fmNow = std::clamp(p[AL_FM_AMT], 0.0F, 2.0F) * (1.0F - eg + eg * egF);
                break;
            }
            case EngineType::Mod7: {
                const float bright = std::exp2(std::clamp(p[M7_BRIGHT], -1.0F, 1.0F));
                const float eg = std::clamp(p[M7_FM_EG], 0.0F, 1.0F);
                const float vel = std::clamp(p[M7_FM_VEL], 0.0F, 1.0F);
                const float scale = bright * (1.0F - eg + eg * egF) * (1.0F - vel + vel * velNorm);
                fmNow = std::clamp(p[M7_OP2_LEVEL], 0.0F, 2.0F) * scale;
                fm3Now = std::clamp(p[M7_OP3_LEVEL], 0.0F, 2.0F) * scale;
                break;
            }
            case EngineType::HD1: {
                const float ms = std::clamp(p[HD_PEG_TIME], 1.0F, 5000.0F);
                pegNow *= std::exp(-c.dt * 1000.0F / ms * 4.6F);
                pitchSemis += pegNow;
                break;
            }
            case EngineType::SGX: {
                // una corda: the left pedal takes some level and brightness
                const float uc = std::clamp(p[SG_UNA_CORDA], 0.0F, 1.0F) * c.soft;
                ampMul *= 1.0F - 0.3F * uc;
                break;
            }
            default: break;
        }
    }

    // -------------------------------------------------------------- per sample, before the recording is read:
    // the factor the read rate is multiplied with (FM). inc = cycles of the key per output sample.
    float rateMul(const silveton::sampler::EngineParams& e, double inc) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::AL1: {
                if (fmNow <= 0.0F) return 1.0F;
                op2Phase += inc * static_cast<double>(p[AL_FM_RATIO]);
                return 1.0F + fmNow * sin01(op2Phase);
            }
            case EngineType::Mod7: {
                if (fmNow <= 0.0F && fm3Now <= 0.0F && p[M7_RING] <= 0.0F) return 1.0F;
                op3Phase += inc * static_cast<double>(p[M7_OP3_RATIO]);
                op2Phase += inc * static_cast<double>(p[M7_OP2_RATIO]);
                const float s3 = sin01(op3Phase) * fm3Now;
                const bool toOp2 = p[M7_OP3_TARGET] < 0.5F;
                const float fb = std::clamp(p[M7_FEEDBACK], 0.0F, 1.0F);
                const float s2 = sin01(op2Phase + static_cast<double>((toOp2 ? s3 : 0.0F) * 0.25F + fb * op2Prev * 0.2F));
                op2Prev = s2;
                ringNow = s2;
                return 1.0F + fmNow * s2 + (toOp2 ? 0.0F : s3);
            }
            default: return 1.0F;
        }
    }

    // -------------------------------------------------------------- per sample, after the recording was read
    void post(const silveton::sampler::EngineParams& e, float& l, float& r, double inc, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (type) {
            case EngineType::MS20:
                if (hpfOn) hpf.process(l, r, FilterMode::HighPass, hpfHz, hpfRes, sr);
                break;
            case EngineType::AL1: {
                const float ring = std::clamp(p[AL_RING_LEVEL], 0.0F, 1.0F);
                if (ring > 0.0F) {
                    ringPhase += inc * static_cast<double>(p[AL_RING_RATIO]);
                    const float m = 1.0F - ring + ring * sin01(ringPhase);
                    l *= m; r *= m;
                }
                const float nl = std::clamp(p[AL_NOISE_LEVEL], 0.0F, 1.0F);
                if (nl > 0.0F) {
                    const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * std::clamp(p[AL_NOISE_COLOR], 100.0F, 20000.0F) / static_cast<float>(sr));
                    const float n = noiseLp.lp(noise(rng), a) * nl * 0.5F;
                    l += n; r += n;
                }
                const float sh = std::clamp(p[AL_SHAPE], 0.0F, 1.0F);
                if (sh > 0.0F) { l = softFold(l, sh); r = softFold(r, sh); }
                break;
            }
            case EngineType::Mod7: {
                const float ring = std::clamp(p[M7_RING], 0.0F, 1.0F);
                if (ring > 0.0F) { const float m = 1.0F - ring + ring * ringNow; l *= m; r *= m; }
                const int ws = static_cast<int>(std::lround(p[M7_WS_TYPE]));
                if (ws > 0) {
                    const float d = std::clamp(p[M7_WS_DRIVE], 0.0F, 1.0F);
                    const float mix = std::clamp(p[M7_WS_MIX], 0.0F, 1.0F);
                    const float g = 1.0F + 9.0F * d;
                    const auto shape = [&](float x) noexcept {
                        switch (ws) {
                            case 1: return std::tanh(x * g) / std::tanh(g);
                            case 2: return std::clamp(x * g, -1.0F, 1.0F) * (1.0F / std::min(g, 4.0F));
                            case 3: return softFold(x, d);
                            default: return sin01(static_cast<double>(x * g) * 0.25) ;
                        }
                    };
                    l += (shape(l) - l) * mix; r += (shape(r) - r) * mix;
                }
                break;
            }
            case EngineType::Str1: {
                const float in = 0.5F * (l + r);
                const float out = stringTick(e, in, sr);
                const float sl = std::clamp(p[ST_STRING], 0.0F, 1.0F), ex = std::clamp(p[ST_EXCITE], 0.0F, 1.0F);
                l = out * sl + l * ex; r = out * sl + r * ex;
                break;
            }
            case EngineType::CX3: {
                float organ = 0.0F;
                for (int k = 0; k < 9; ++k) {
                    const auto i = static_cast<std::size_t>(k);
                    twPhase[i] += twInc[i];
                    const float lev = twLevel[i] + leakLevel;
                    if (lev <= 0.0F && percPartial != k) continue;
                    const float s = sin01(twPhase[i]);
                    organ += s * lev * twTaper[i];
                    if (percPartial == k) organ += s * percEnv * percGain * 0.8F;
                }
                if (percEnv > 0.0F) { percEnv *= percCoef; if (percEnv < 1.0e-4F) percEnv = 0.0F; }
                if (clickEnv > 0.0F) {
                    organ += clickLp.lp(noise(rng), 0.35F) * clickEnv * 0.6F;
                    clickEnv *= clickCoef; if (clickEnv < 1.0e-4F) clickEnv = 0.0F;
                }
                if (keyOffEnv > 0.0F) {   // the key-off click
                    organ += clickLp.lp(noise(rng), 0.35F) * keyOffEnv * std::clamp(p[CX_CLICK], 0.0F, 1.0F) * 0.4F;
                    keyOffEnv *= clickCoef > 0.0F ? clickCoef : 0.9F; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
                }
                organ *= 0.35F;
                const float smp = std::clamp(p[CX_SAMPLE], 0.0F, 1.0F);
                l = organ + l * smp; r = organ + r * smp;
                break;
            }
            case EngineType::SGX: {
                if (brightA < 0.999F) { l = brightL.lp(l, brightA); r = brightR.lp(r, brightA); }
                if (hammerEnv > 0.0F) {
                    const float n = noise(rng) * hammerEnv * 0.5F;
                    l += n; r += n;
                    hammerEnv *= hammerCoef; if (hammerEnv < 1.0e-4F) hammerEnv = 0.0F;
                }
                if (keyOffEnv > 0.0F) {
                    float n = noise(rng), n2 = n;
                    keyOffBp.process(n, n2, FilterMode::BandPass, std::clamp(p[SG_KEYOFF_TONE], 200.0F, 8000.0F), 0.5F, sr);
                    const float g = keyOffEnv * std::clamp(p[SG_KEYOFF], 0.0F, 1.0F) * 0.5F;
                    l += n * g; r += n2 * g;
                    keyOffEnv *= keyOffCoef; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
                }
                break;
            }
            case EngineType::EP: {
                if (bellGain > 0.0F) {   // the bell: the part above ~2 kHz, louder with the hit
                    const float a = 1.0F - std::exp(-2.0F * static_cast<float>(kPi) * 2000.0F / static_cast<float>(sr));
                    l += (l - bellL.lp(l, a)) * bellGain; r += (r - bellR.lp(r, a)) * bellGain;
                }
                if (barkDrive > 0.0F) {
                    const float g = 1.0F + barkDrive;
                    l = std::tanh(l * g) / std::sqrt(g); r = std::tanh(r * g) / std::sqrt(g);
                }
                if (keyOffEnv > 0.0F) {
                    float n = noise(rng), n2 = n;
                    keyOffBp.process(n, n2, FilterMode::BandPass, 3000.0F, 0.4F, sr);
                    const float g = keyOffEnv * std::clamp(p[EP_KEYOFF], 0.0F, 1.0F) * 0.3F;
                    l += n * g; r += n2 * g;
                    keyOffEnv *= keyOffCoef; if (keyOffEnv < 1.0e-4F) keyOffEnv = 0.0F;
                }
                break;
            }
            default: break;
        }
    }

    // the STR-1 string: one sample in (the recording = the excitation), one sample out
    float stringTick(const silveton::sampler::EngineParams& e, float in, double sr) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        strAgeSec += 1.0 / sr;
        // the excitation feeds the string only for EXC LENGTH (0 = always)
        const float len = p[ST_EXC_LEN];
        // a recording driving a string at its own pitch adds up period after period: the excitation goes in quietly,
        // and the loop itself is soft-limited (a real string cannot swing without bound either)
        float x = in * 0.3F;
        if (len > 0.0F) {
            const double t = strAgeSec * 1000.0;
            const double fade = std::clamp((static_cast<double>(len) - t) / 5.0 + 1.0, 0.0, 1.0);   // a 5 ms fade at the end
            x *= static_cast<float>(fade);
        }
        // pick position: the excitation minus itself delayed by PICK x the string length
        {
            const double d = std::clamp(static_cast<double>(std::clamp(p[ST_PICK], 0.02F, 0.5F)) * strLen, 1.0, static_cast<double>(kPickMax - 2));
            pick[static_cast<std::size_t>(pickW)] = x;
            const double rp = static_cast<double>(pickW) - d;
            int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            i0 = (i0 % kPickMax + kPickMax) % kPickMax;
            const int i1 = (i0 + 1) % kPickMax;
            x -= pick[static_cast<std::size_t>(i0)] + (pick[static_cast<std::size_t>(i1)] - pick[static_cast<std::size_t>(i0)]) * f;
            pickW = (pickW + 1) % kPickMax;
        }
        // feedback from the output back into the string (like a guitar in front of its amplifier)
        const float fb = std::clamp(p[ST_FEEDBACK], 0.0F, 1.0F);
        if (fb > 0.0F) x += std::tanh(strFbZ * 2.0F) * fb * 0.35F;
        // read the string one period back (fractional), and at the pickup position
        const auto tap = [&](double delay) noexcept {
            const double rp = static_cast<double>(strW) - delay;
            int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            i0 = (i0 % kStringMax + kStringMax) % kStringMax;
            const int i1 = (i0 + 1) % kStringMax;
            return str[static_cast<std::size_t>(i0)] + (str[static_cast<std::size_t>(i1)] - str[static_cast<std::size_t>(i0)]) * f;
        };
        float y = tap(strLen);
        // loop filter: damping low-pass, dispersion allpass, nonlinearity, decay
        strLpZ += (y - strLpZ) * strLpA; y = strLpZ;
        {   // first-order allpass
            const float out = strApA * y + strApX - strApA * strApY;
            strApX = y; strApY = out; y = out;
        }
        const float nl = std::clamp(p[ST_NONLIN], 0.0F, 1.0F);
        if (nl > 0.0F) { const float g = 1.0F + 6.0F * nl; y = std::tanh(y * g) / g; }
        else if (y > 0.7F || y < -0.7F) y = std::tanh(y);
        y *= strG;
        const float newSample = y + x;
        str[static_cast<std::size_t>(strW)] = newSample;
        strW = (strW + 1) % kStringMax;
        // pickup position: the string minus itself at PICKUP x length (a comb on the output)
        const double pu = std::clamp(static_cast<double>(std::clamp(p[ST_PICKUP], 0.02F, 0.5F)) * strLen, 1.0, strLen - 1.0);
        const float out = newSample - tap(pu);
        strFbZ += (out - strFbZ) * 0.05F;   // the feedback path is dull (a loudspeaker far away)
        strOutPrev = out;
        return out;
    }
};

// ---------------------------------------------------------------------------------------------------------------
// one per Upper
struct EngineBus {
    double sr{48000.0};
    silveton::sampler::EngineType type{silveton::sampler::EngineType::Off};
    // Polysix chorus / phase / ensemble
    ModEngine mod{};
    silveton::sampler::EffectSlot modCfg{};
    // CX-3 scanner and Leslie
    HeapLine vibLine{};
    double vibPhase{0.0};
    HeapLine hornLine{};
    double hornPhase{0.0}, drumPhase{0.0}, hornSpeed{0.0}, drumSpeed{0.0};
    Pole xo1{}, xo2{};
    // EP
    Biquad bass{}, treble{};
    float bassDb{999.0F}, trebleDb{999.0F};
    double tremPhase{0.0};
    Lp2 cabHp{}, cabLp{};
    Biquad cabPeak{};
    bool cabSet{false};
    // SGX
    struct Res {
        int key{-1};
        std::vector<float> buf;
        int w{0};
        double len{100.0};
        float g{0.0F};
        float lp{0.0F};
        std::uint32_t age{0U};
        float tick(float in, float lpA) noexcept {
            const double rp = static_cast<double>(w) - len;
            const int n = static_cast<int>(buf.size());
            int i0 = static_cast<int>(std::floor(rp));
            const float f = static_cast<float>(rp - static_cast<double>(i0));
            i0 = (i0 % n + n) % n;
            const int i1 = (i0 + 1) % n;
            const float y = buf[static_cast<std::size_t>(i0)] + (buf[static_cast<std::size_t>(i1)] - buf[static_cast<std::size_t>(i0)]) * f;
            lp += (y - lp) * lpA;
            const float s = in + lp * g;
            buf[static_cast<std::size_t>(w)] = s;
            w = (w + 1) % n;
            return lp;
        }
    };
    static constexpr int kHeldRes = 10;
    static constexpr int kDamperRes = 10;
    std::array<Res, kHeldRes> held{};
    std::array<Res, kDamperRes> damper{};
    std::uint32_t resClock{0U};
    float resGainHeld{0.0F}, resGainDamper{0.0F};
    Biquad lid{};
    float lidDb{999.0F};
    // HD-1
    Biquad boost{};
    float boostDb{999.0F};

    void allocate(double sampleRate) {
        sr = sampleRate;
        mod.allocate(sr);
        vibLine.allocate(static_cast<std::size_t>(0.004 * sr) + 64U);
        hornLine.allocate(static_cast<std::size_t>(0.004 * sr) + 64U);
        const auto resLen = static_cast<std::size_t>(sr / 22.0) + 8U;
        for (auto& r : held) { r.buf.assign(resLen, 0.0F); r.key = -1; }
        for (auto& r : damper) { r.buf.assign(resLen, 0.0F); r.key = -1; }
        reset();
    }
    void reset() noexcept {
        mod.reset(); vibLine.clear(); hornLine.clear(); vibPhase = hornPhase = drumPhase = 0.0; hornSpeed = drumSpeed = 0.0;
        xo1 = Pole{}; xo2 = Pole{};
        bass.reset(); treble.reset(); bassDb = trebleDb = 999.0F; tremPhase = 0.0; cabHp.reset(); cabLp.reset(); cabPeak.reset(); cabSet = false;
        for (auto& r : held) { std::fill(r.buf.begin(), r.buf.end(), 0.0F); r.key = -1; r.lp = 0.0F; r.w = 0; }
        for (auto& r : damper) { std::fill(r.buf.begin(), r.buf.end(), 0.0F); r.key = -1; r.lp = 0.0F; r.w = 0; }
        lid.reset(); lidDb = 999.0F; boost.reset(); boostDb = 999.0F;
        type = silveton::sampler::EngineType::Off;
    }

    [[nodiscard]] bool active(const silveton::sampler::EngineParams& e) const noexcept {
        using namespace silveton::sampler;
        switch (e.type) {
            case EngineType::Polysix: return e.p[P6_FX_TYPE] >= 0.5F && e.p[P6_FX_MIX] > 0.0F;
            case EngineType::CX3: return true;
            case EngineType::EP: return true;
            case EngineType::SGX: return true;
            case EngineType::HD1: return e.p[HD_BOOST] > 0.05F;
            default: return false;
        }
    }

    static double keyHz(int key) noexcept { return 440.0 * std::pow(2.0, (key - 69) / 12.0); }

    // once per block. heldKeys: the keys of this Upper that are down now (SGX); sustain / wheel of the Upper's channel.
    void block(const silveton::sampler::EngineParams& e, std::uint32_t frames, float wheel, bool sustain, const std::array<bool, 128>& heldKeys) noexcept {
        using namespace silveton::sampler;
        if (e.type != type) { reset(); type = e.type; }
        const float* p = e.p.data();
        (void)frames;
        switch (e.type) {
            case EngineType::Polysix: {
                const int t = static_cast<int>(std::lround(p[P6_FX_TYPE]));
                modCfg.type = t == 1 ? EffectType::Chorus : (t == 2 ? EffectType::Phaser : (t == 3 ? EffectType::Ensemble : EffectType::Off));
                modCfg.rateHz = std::clamp(p[P6_FX_SPEED], 0.1F, 5.0F);
                modCfg.depth = std::clamp(p[P6_FX_DEPTH], 0.0F, 1.0F);
                modCfg.feedback = t == 2 ? 0.35F : 0.0F;
                modCfg.param1 = t == 1 ? 3.0F : 6.0F;
                break;
            }
            case EngineType::EP: {
                if (p[EP_BASS] != bassDb) { bassDb = p[EP_BASS]; bass.setShelf(sr, 110.0F, std::clamp(bassDb, -12.0F, 12.0F), false); }
                if (p[EP_TREBLE] != trebleDb) { trebleDb = p[EP_TREBLE]; treble.setShelf(sr, 3200.0F, std::clamp(trebleDb, -12.0F, 12.0F), true); }
                if (!cabSet) { cabHp.set(sr, 85.0, true); cabLp.set(sr, 5200.0, false); cabPeak.setPeaking(sr, 420.0F, 0.8F, 2.5F); cabSet = true; }
                break;
            }
            case EngineType::SGX: {
                const float lidV = std::clamp(p[SG_LID], 0.0F, 1.0F);
                const float ld = -(1.0F - lidV) * 7.0F;
                if (ld != lidDb) { lidDb = ld; lid.setShelf(sr, 2400.0F, ld, true); }
                const float relSec = std::clamp(p[SG_RES_RELEASE], 0.1F, 5.0F);
                resGainHeld = std::clamp(p[SG_STRING_RES], 0.0F, 1.0F) * 0.25F;
                resGainDamper = sustain ? std::clamp(p[SG_DAMPER_RES], 0.0F, 1.0F) * 0.18F : 0.0F;
                // the held keys own a resonator each (the oldest one is given up when all are taken)
                ++resClock;
                for (auto& r : held) if (r.key >= 0 && !heldKeys[static_cast<std::size_t>(r.key)]) r.key = -1;   // the key went up: the line rings out and is free
                for (int k = 0; k < 128; ++k) {
                    if (!heldKeys[static_cast<std::size_t>(k)]) continue;
                    bool have = false;
                    for (const auto& r : held) if (r.key == k) { have = true; break; }
                    if (have) continue;
                    Res* slot = nullptr;
                    for (auto& r : held) if (r.key < 0) { if (slot == nullptr || r.age < slot->age) slot = &r; }
                    if (slot == nullptr) { for (auto& r : held) if (slot == nullptr || r.age < slot->age) slot = &r; }
                    if (slot == nullptr) break;
                    slot->key = k; slot->age = resClock;
                    const double hz = keyHz(k);
                    slot->len = std::clamp(sr / std::max(22.0, hz) - 1.0, 2.0, static_cast<double>(slot->buf.size() - 3U));
                    slot->g = std::min(0.998F, std::exp(-6.9F * static_cast<float>(slot->len / sr) / relSec));
                }
                for (auto& r : held) if (r.key < 0 && r.g > 0.0F) r.g = std::min(r.g, std::exp(-6.9F * static_cast<float>(r.len / sr) / relSec));
                if (damper[0].key < 0) {   // the undamped low strings: A1 .. F#4 every three semitones
                    for (int i = 0; i < kDamperRes; ++i) {
                        auto& r = damper[static_cast<std::size_t>(i)];
                        r.key = 33 + i * 3;
                        r.len = std::clamp(sr / keyHz(r.key) - 1.0, 2.0, static_cast<double>(r.buf.size() - 3U));
                    }
                }
                for (auto& r : damper) r.g = std::min(0.998F, std::exp(-6.9F * static_cast<float>(r.len / sr) / (relSec * 1.5F)));
                break;
            }
            case EngineType::HD1: {
                if (p[HD_BOOST] != boostDb) { boostDb = p[HD_BOOST]; boost.setShelf(sr, 110.0F, std::clamp(boostDb, 0.0F, 12.0F), false); }
                break;
            }
            case EngineType::CX3: {
                (void)wheel;
                break;
            }
            default: break;
        }
    }

    void process(const silveton::sampler::EngineParams& e, float& l, float& r, float wheel) noexcept {
        using namespace silveton::sampler;
        const float* p = e.p.data();
        switch (e.type) {
            case EngineType::Polysix: {
                if (modCfg.type == EffectType::Off) return;
                float wl = 0.0F, wr = 0.0F;
                mod.process(l, r, modCfg, wl, wr);
                const float mix = std::clamp(p[P6_FX_MIX], 0.0F, 1.0F);
                l += (wl - l) * mix; r += (wr - r) * mix;
                break;
            }
            case EngineType::HD1:
                if (boostDb > 0.05F) boost.process(l, r);
                break;
            case EngineType::CX3: {
                // scanner vibrato / chorus
                const int vc = static_cast<int>(std::lround(p[CX_VIBCHO]));
                if (vc > 0) {
                    vibLine.push(l, r);
                    const int depthIx = (vc + 1) / 2;   // 1 = V1/C1, 2 = V2/C2, 3 = V3/C3
                    const double depth = sr * 0.00032 * depthIx;
                    vibPhase += 6.9 / sr; vibPhase -= std::floor(vibPhase);
                    const double tri = 1.0 - 4.0 * std::abs(vibPhase - 0.5);
                    const double d = sr * 0.0004 + depth * (0.5 + 0.5 * tri);
                    const float wl = vibLine.tapHL(d), wr = vibLine.tapHR(d);
                    const bool chorus = (vc % 2) == 0;
                    if (chorus) { l = 0.5F * (l + wl); r = 0.5F * (r + wr); } else { l = wl; r = wr; }
                }
                // the amplifier
                const float drive = std::clamp(p[CX_AMP_DRIVE], 0.0F, 1.0F);
                if (drive > 0.0F) {
                    const float g = 1.0F + 6.0F * drive;
                    l = std::tanh(l * g) / std::sqrt(g) * (1.0F + 0.3F * drive); r = std::tanh(r * g) / std::sqrt(g) * (1.0F + 0.3F * drive);
                }
                // Leslie
                const int rot = static_cast<int>(std::lround(p[CX_ROTARY]));
                if (rot > 0) {
                    const bool fast = rot == 2 || (p[CX_WHEEL_ROT] >= 0.5F && wheel >= 0.5F);
                    const double slow = std::clamp(static_cast<double>(p[CX_SLOW]), 0.3, 1.5);
                    const double fastHz = std::clamp(static_cast<double>(p[CX_FAST]), 4.0, 9.0);
                    const double hornWant = fast ? fastHz : slow;
                    const double drumWant = hornWant * 0.9;
                    const double hornTau = hornWant > hornSpeed ? 0.9 : 1.6;
                    const double drumTau = drumWant > drumSpeed ? 3.5 : 5.0;
                    hornSpeed += (hornWant - hornSpeed) * (1.0 - std::exp(-1.0 / (hornTau * sr)));
                    drumSpeed += (drumWant - drumSpeed) * (1.0 - std::exp(-1.0 / (drumTau * sr)));
                    hornPhase += hornSpeed / sr; hornPhase -= std::floor(hornPhase);
                    drumPhase += drumSpeed / sr; drumPhase -= std::floor(drumPhase);
                    const float mono = 0.5F * (l + r);
                    const float k = onePoleCoef(800.0, sr);
                    const float lo = xo2.lp(xo1.lp(mono, k), k);
                    const float hi = mono - lo;
                    hornLine.push(hi, hi);
                    const double base = sr * 0.0006;
                    const double dop = sr * 0.00045;
                    const float sA = sin01(hornPhase), sB = sin01(hornPhase + 0.5);
                    const float hl = hornLine.tapHL(base + dop * (1.0 + sA)) * (0.62F + 0.38F * sA);
                    const float hr = hornLine.tapHR(base + dop * (1.0 + sB)) * (0.62F + 0.38F * sB);
                    const float dl = lo * (0.78F + 0.22F * sin01(drumPhase));
                    const float dr = lo * (0.78F + 0.22F * sin01(drumPhase + 0.4));
                    const float bal = std::clamp(p[CX_HORN], 0.0F, 1.0F);
                    const float hg = 2.0F * bal, dg = 2.0F * (1.0F - bal);
                    l = hl * hg + dl * dg; r = hr * hg + dr * dg;
                }
                break;
            }
            case EngineType::EP: {
                const float drive = std::clamp(p[EP_PRE_DRIVE], 0.0F, 1.0F);
                if (drive > 0.0F) { const float g = 1.0F + 5.0F * drive; l = std::tanh(l * g) / std::sqrt(g); r = std::tanh(r * g) / std::sqrt(g); }
                if (bassDb != 0.0F) bass.process(l, r);
                if (trebleDb != 0.0F) treble.process(l, r);
                if (p[EP_TREM] >= 0.5F) {
                    tremPhase += std::clamp(static_cast<double>(p[EP_TREM_SPEED]), 0.5, 12.0) / sr; tremPhase -= std::floor(tremPhase);
                    const float d = std::clamp(p[EP_TREM_DEPTH], 0.0F, 1.0F);
                    const bool reed = p[EP_TYPE] >= 0.5F;
                    const float st = reed ? 0.0F : std::clamp(p[EP_TREM_STEREO], 0.0F, 1.0F);
                    const float gl = 1.0F - d * (0.5F - 0.5F * sin01(tremPhase));
                    const float gr = 1.0F - d * (0.5F - 0.5F * sin01(tremPhase + 0.5 * st));
                    l *= gl; r *= gr;
                }
                if (p[EP_CAB] >= 0.5F && cabSet) {
                    const float cd = std::clamp(p[EP_CAB_DRIVE], 0.0F, 1.0F);
                    if (cd > 0.0F) { const float g = 1.0F + 4.0F * cd; l = std::tanh(l * g) / std::sqrt(g); r = std::tanh(r * g) / std::sqrt(g); }
                    cabHp.process(l, r); cabPeak.process(l, r); cabLp.process(l, r);
                }
                break;
            }
            case EngineType::SGX: {
                const float in = 0.5F * (l + r);
                float res = 0.0F;
                if (resGainHeld > 0.0F) {
                    for (auto& rr : held) if (rr.key >= 0 || std::fabs(rr.lp) > 1.0e-6F) res += rr.tick(rr.key >= 0 ? in * resGainHeld : 0.0F, 0.35F);
                }
                if (resGainDamper > 0.0F || damper[0].lp != 0.0F) {
                    for (auto& rr : damper) res += rr.tick(in * resGainDamper, 0.3F);
                }
                l += res * 0.5F; r += res * 0.5F;
                if (lidDb < -0.05F) lid.process(l, r);
                break;
            }
            default: break;
        }
    }
};

} // namespace eng
