#include "silveton/sampler/KorgImporter.h"
#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstring>
#include "silveton/sampler/FsCompat.h"
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_set>

namespace silveton::sampler {
namespace {

std::uint32_t be32(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24U) |
           (static_cast<std::uint32_t>(p[1]) << 16U) |
           (static_cast<std::uint32_t>(p[2]) << 8U) |
           static_cast<std::uint32_t>(p[3]);
}

std::uint32_t be24(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 16U) |
           (static_cast<std::uint32_t>(p[1]) << 8U) |
           static_cast<std::uint32_t>(p[2]);
}

bool readAll(const std::string& path, std::vector<std::uint8_t>& out, std::string& error) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { error = "Cannot open Korg file: " + path; return false; }
    const std::streamsize size = f.tellg();
    if (size <= 0) { error = "Korg file is empty: " + path; return false; }
    f.seekg(0, std::ios::beg);
    out.resize(static_cast<std::size_t>(size));
    if (!f.read(reinterpret_cast<char*>(out.data()), size)) {
        error = "Failed to read Korg file: " + path; return false;
    }
    return true;
}

std::string fixedString(const std::uint8_t* p, std::size_t n) {
    std::size_t len = 0U;
    while (len < n && p[len] != 0U && p[len] != static_cast<std::uint8_t>(' ')) ++len;
    return std::string(reinterpret_cast<const char*>(p), len);
}

std::string trim(const std::string& s) {
    std::size_t a = 0U;
    while (a < s.size() && std::isspace(static_cast<unsigned char>(s[a])) != 0) ++a;
    std::size_t b = s.size();
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1U])) != 0) --b;
    return s.substr(a, b - a);
}

struct Chunk {
    std::string id;
    const std::uint8_t* data{nullptr};
    std::size_t size{0U};
};

bool parseChunks(const std::vector<std::uint8_t>& bytes, std::vector<Chunk>& chunks, std::string& error) {
    std::size_t pos = 0U;
    while (pos + 8U <= bytes.size()) {
        Chunk c;
        c.id.assign(reinterpret_cast<const char*>(bytes.data() + pos), 4U);
        c.size = static_cast<std::size_t>(be32(bytes.data() + pos + 4U));
        const std::size_t dataPos = pos + 8U;
        if (dataPos > bytes.size() || c.size > bytes.size() - dataPos) {
            error = "Corrupt Korg chunk size in " + c.id;
            return false;
        }
        c.data = bytes.data() + dataPos;
        chunks.push_back(c);
        pos = dataPos + c.size;
    }
    if (pos != bytes.size()) {
        // KORG chunks are byte packed; trailing bytes are not expected.
        error = "Trailing bytes after final Korg chunk";
        return false;
    }
    return !chunks.empty();
}

const Chunk* findChunk(const std::vector<Chunk>& chunks, const char* id) {
    for (const auto& c : chunks) if (c.id == id) return &c;
    return nullptr;
}

float decodeKsf8(std::uint8_t b) noexcept {
    return static_cast<float>(static_cast<std::int8_t>(b)) / 128.0F;
}

float decodeKsf16(const std::uint8_t* p) noexcept {
    const std::uint16_t u = static_cast<std::uint16_t>((static_cast<std::uint16_t>(p[0]) << 8U) |
                                                      static_cast<std::uint16_t>(p[1]));
    return static_cast<float>(static_cast<std::int16_t>(u)) / 32768.0F;
}

std::string sourceIdentityFor(const silveton::fsx::path& path) {
    std::error_code ec;
    const auto canonical = silveton::fsx::weakly_canonical(path, ec);
    return (ec ? path.lexically_normal() : canonical).generic_string();
}

std::string ksfPathFor(const silveton::fsx::path& kmpPath, const std::string& filename) {
    const auto direct = kmpPath.parent_path() / filename;
    if (silveton::fsx::exists(direct)) return direct.string();
    // Korg Save One Multisample commonly creates a same-name subdirectory.
    const auto nested = kmpPath.parent_path() / kmpPath.stem() / filename;
    if (silveton::fsx::exists(nested)) return nested.string();
    return direct.string();
}

} // namespace

KorgSampleResult KorgImporter::loadKsf(const std::string& path) {
    std::vector<std::uint8_t> bytes;
    std::string error;
    if (!readAll(path, bytes, error)) return {nullptr, error};
    std::vector<Chunk> chunks;
    if (!parseChunks(bytes, chunks, error)) return {nullptr, error};

    const Chunk* smp = findChunk(chunks, "SMP1");
    const Chunk* smd = findChunk(chunks, "SMD1");
    if (smp == nullptr || smp->size < 32U || smd == nullptr || smd->size < 12U) {
        return {nullptr, "KSF requires SMP1(32) and SMD1 chunks"};
    }

    const std::uint32_t sampleRate = be32(smd->data);
    const std::uint8_t attributes = smd->data[4U];
    const auto loopTune = static_cast<std::int8_t>(smd->data[5U]);
    const std::uint8_t channels = smd->data[6U];
    const std::uint8_t bitDepth = smd->data[7U];
    const std::uint32_t samplePoints = be32(smd->data + 8U);
    if (sampleRate == 0U || channels == 0U || channels > 2U || (bitDepth != 8U && bitDepth != 16U)) {
        return {nullptr, "Unsupported KSF sample format"};
    }
    const std::size_t bytesPerSample = static_cast<std::size_t>(bitDepth / 8U);
    const std::size_t expectedBytes = static_cast<std::size_t>(samplePoints) * static_cast<std::size_t>(channels) * bytesPerSample;
    const std::size_t availableBytes = smd->size - 12U;
    if (availableBytes != expectedBytes) {
        // Compressed/divided KSF variants require their compression or continuation algorithm.
        return {nullptr, "Compressed, divided, or malformed KSF data is not supported by this decoder"};
    }

    auto out = std::make_shared<SampleData>();
    out->name = fixedString(smp->data, 16U);
    out->sourcePath = path;
    out->sourceIdentity = sourceIdentityFor(path);
    out->sampleRate = sampleRate;
    out->channels = channels;
    out->fineTuneCents = static_cast<float>(loopTune);

    // SMP1 exists in an older layout (bank byte + 24-bit Start) and a newer
    // layout (32-bit Start). Select the older layout only when its bank byte is
    // a documented 0..3 and the newer interpretation would clearly exceed data.
    const std::uint32_t modernStart = be32(smp->data + 16U);
    const bool oldLayout = smp->data[16U] <= 3U && modernStart > samplePoints;
    std::uint32_t start = 0U, start2 = 0U, loopStart = 0U, loopEnd = 0U;
    if (oldLayout) {
        start = be24(smp->data + 17U);
        start2 = be32(smp->data + 20U);
        loopStart = be32(smp->data + 24U);
        loopEnd = be32(smp->data + 28U);
    } else {
        start = modernStart;
        start2 = be32(smp->data + 20U);
        loopStart = be32(smp->data + 24U);
        loopEnd = be32(smp->data + 28U);
    }
    (void)start2;

    const std::uint8_t* pcm = smd->data + 12U;
    out->interleaved.resize(static_cast<std::size_t>(samplePoints) * static_cast<std::size_t>(channels));
    for (std::size_t i = 0U; i < out->interleaved.size(); ++i) {
        out->interleaved[i] = bitDepth == 8U ? decodeKsf8(pcm[i]) : decodeKsf16(pcm + i * 2U);
    }

    if (start > 0U && start < samplePoints) {
        const std::size_t eraseSamples = static_cast<std::size_t>(start) * static_cast<std::size_t>(channels);
        out->interleaved.erase(out->interleaved.begin(), out->interleaved.begin() + static_cast<std::ptrdiff_t>(eraseSamples));
        if (loopStart >= start) loopStart -= start; else loopStart = 0U;
        if (loopEnd >= start) loopEnd -= start; else loopEnd = 0U;
    }

    // Attribute bit layouts vary by generation. Instead of guessing compression
    // flags, compression was already detected by the exact SMD1 byte count.
    // Loop addresses are honored whenever they form a valid forward region.
    (void)attributes;
    const std::uint64_t frames = out->frameCount();
    if (loopEnd > loopStart && static_cast<std::uint64_t>(loopEnd) <= frames) {
        out->loop.enabled = true;
        out->loop.startFrame = loopStart;
        out->loop.endFrame = loopEnd;
        out->loop.crossfadeFrames = 0U;
    }
    return {out, {}};
}


KorgSampleResult KorgImporter::loadKsfStreaming(const std::string& path, std::uint64_t preloadFrames) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {nullptr, "Cannot open Korg file: " + path};

    std::array<std::uint8_t, 32U> smp{};
    bool haveSmp = false;
    std::array<std::uint8_t, 12U> smdHeader{};
    bool haveSmd = false;
    std::uint64_t smdPcmOffset = 0U;
    std::uint32_t smdChunkSize = 0U;

    while (f) {
        std::array<std::uint8_t, 8U> header{};
        if (!f.read(reinterpret_cast<char*>(header.data()), static_cast<std::streamsize>(header.size()))) break;
        const std::uint32_t size = be32(header.data() + 4U);
        const std::streamoff payload = f.tellg();
        if (payload < 0) return {nullptr, "Invalid KSF stream position"};
        const std::string id(reinterpret_cast<const char*>(header.data()), 4U);
        if (id == "SMP1") {
            if (size < 32U) return {nullptr, "KSF SMP1 chunk is too short"};
            if (!f.read(reinterpret_cast<char*>(smp.data()), static_cast<std::streamsize>(smp.size()))) return {nullptr, "Truncated KSF SMP1 chunk"};
            if (size > smp.size()) f.seekg(static_cast<std::streamoff>(size - smp.size()), std::ios::cur);
            haveSmp = true;
        } else if (id == "SMD1") {
            if (size < 12U) return {nullptr, "KSF SMD1 chunk is too short"};
            if (!f.read(reinterpret_cast<char*>(smdHeader.data()), static_cast<std::streamsize>(smdHeader.size()))) return {nullptr, "Truncated KSF SMD1 header"};
            const std::streamoff pcm = f.tellg();
            if (pcm < 0) return {nullptr, "Invalid KSF PCM position"};
            smdPcmOffset = static_cast<std::uint64_t>(pcm);
            smdChunkSize = size;
            if (size > smdHeader.size()) f.seekg(static_cast<std::streamoff>(size - smdHeader.size()), std::ios::cur);
            haveSmd = true;
        } else {
            f.seekg(static_cast<std::streamoff>(size), std::ios::cur);
        }
    }
    if (!haveSmp || !haveSmd) return {nullptr, "KSF requires SMP1(32) and SMD1 chunks"};

    const std::uint32_t sampleRate = be32(smdHeader.data());
    const auto loopTune = static_cast<std::int8_t>(smdHeader[5U]);
    const std::uint8_t channels = smdHeader[6U];
    const std::uint8_t bitDepth = smdHeader[7U];
    const std::uint32_t samplePoints = be32(smdHeader.data() + 8U);
    if (sampleRate == 0U || channels == 0U || channels > 2U || (bitDepth != 8U && bitDepth != 16U)) {
        return {nullptr, "Unsupported KSF sample format"};
    }
    const std::uint64_t bytesPerSample = bitDepth / 8U;
    const std::uint64_t frameBytes = bytesPerSample * channels;
    const std::uint64_t expectedBytes = static_cast<std::uint64_t>(samplePoints) * frameBytes;
    if (static_cast<std::uint64_t>(smdChunkSize) != 12U + expectedBytes) {
        return {nullptr, "Compressed, divided, or malformed KSF data is not supported by this decoder"};
    }

    const std::uint32_t modernStart = be32(smp.data() + 16U);
    const bool oldLayout = smp[16U] <= 3U && modernStart > samplePoints;
    std::uint32_t start = 0U, loopStart = 0U, loopEnd = 0U;
    if (oldLayout) {
        start = be24(smp.data() + 17U);
        loopStart = be32(smp.data() + 24U);
        loopEnd = be32(smp.data() + 28U);
    } else {
        start = modernStart;
        loopStart = be32(smp.data() + 24U);
        loopEnd = be32(smp.data() + 28U);
    }
    if (start >= samplePoints) start = 0U;
    const std::uint64_t frames = static_cast<std::uint64_t>(samplePoints) - start;

    MappedPcmSpec spec{};
    spec.dataOffset = smdPcmOffset + static_cast<std::uint64_t>(start) * frameBytes;
    spec.frameCount = frames;
    spec.sampleRate = sampleRate;
    spec.channels = channels;
    spec.bitDepth = bitDepth;
    spec.formatTag = 1U;
    spec.bigEndian = true;
    std::string mapError;
    auto stream = MappedPcmStream::open(path, spec, mapError);
    if (!stream) return {nullptr, mapError};

    auto out = std::make_shared<SampleData>();
    out->name = fixedString(smp.data(), 16U);
    out->sourcePath = path;
    out->sourceIdentity = sourceIdentityFor(path);
    out->sampleRate = sampleRate;
    out->channels = channels;
    out->fineTuneCents = static_cast<float>(loopTune);
    out->stream = stream;
    out->totalFrames = frames;
    const auto preload = std::min<std::uint64_t>(preloadFrames, frames);
    out->interleaved.resize(static_cast<std::size_t>(preload) * static_cast<std::size_t>(channels));
    for (std::uint64_t frame = 0U; frame < preload; ++frame) {
        for (std::uint16_t ch = 0U; ch < channels; ++ch) {
            out->interleaved[static_cast<std::size_t>(frame) * channels + ch] = stream->readFrame(frame, ch);
        }
    }
    if (loopStart >= start) loopStart -= start; else loopStart = 0U;
    if (loopEnd >= start) loopEnd -= start; else loopEnd = 0U;
    if (loopEnd > loopStart && static_cast<std::uint64_t>(loopEnd) <= frames) {
        out->loop.enabled = true;
        out->loop.startFrame = loopStart;
        out->loop.endFrame = loopEnd;
    }
    return {out, {}};
}

KorgImportResult KorgImporter::loadKmp(const std::string& path) {
    std::vector<std::uint8_t> bytes;
    std::string error;
    if (!readAll(path, bytes, error)) return {nullptr, {}, error, {}};
    std::vector<Chunk> chunks;
    if (!parseChunks(bytes, chunks, error)) return {nullptr, {}, error, {}};

    const Chunk* msp = findChunk(chunks, "MSP1");
    const Chunk* rlp = findChunk(chunks, "RLP1");
    if (msp == nullptr || msp->size < 18U || rlp == nullptr) {
        return {nullptr, {}, "KMP requires MSP1 and RLP1 chunks", {}};
    }
    const std::uint8_t regionCount = msp->data[16U];
    if (regionCount == 0U || rlp->size < static_cast<std::size_t>(regionCount) * 18U) {
        return {nullptr, {}, "KMP RLP1 region count/size mismatch", {}};
    }

    auto ms = std::make_shared<Multisample>();
    ms->name = fixedString(msp->data, 16U);
    ms->sourceIdentity = sourceIdentityFor(path);
    std::vector<SamplePtr> loaded;
    std::vector<std::string> warnings;
    const silveton::fsx::path kmpPath(path);
    std::uint8_t lowKey = 0U;

    for (std::uint8_t i = 0U; i < regionCount; ++i) {
        const std::uint8_t* r = rlp->data + static_cast<std::size_t>(i) * 18U;
        const std::uint8_t originalRaw = r[0U];
        const bool nonTranspose = (originalRaw & 0x80U) != 0U;
        const std::uint8_t originalKey = static_cast<std::uint8_t>(originalRaw & 0x7FU);
        const std::uint8_t topKey = static_cast<std::uint8_t>(std::min<int>(127, r[1U]));
        const auto tune = static_cast<std::int8_t>(r[2U]);
        const auto level = static_cast<std::int8_t>(r[3U]);
        const auto pan = static_cast<std::int8_t>(r[4U]);
        const auto cutoff = static_cast<std::int8_t>(r[5U]);
        const std::string filename = fixedString(r + 6U, 12U);
        if (filename.empty() || filename == "SKIPPEDSAMPL" || filename.rfind("INTERNAL", 0U) == 0U) {
            warnings.push_back("Skipped KMP region with unavailable sample: " + filename);
            lowKey = topKey < 127U ? static_cast<std::uint8_t>(topKey + 1U) : 127U;
            continue;
        }

        const std::string samplePath = ksfPathFor(kmpPath, filename);
        const auto ksf = loadKsfStreaming(samplePath);
        if (!ksf.ok()) {
            warnings.push_back(filename + ": " + ksf.error);
            lowKey = topKey < 127U ? static_cast<std::uint8_t>(topKey + 1U) : 127U;
            continue;
        }
        loaded.push_back(ksf.sample);
        SampleZone zone{};
        zone.sample = ksf.sample;
        zone.keyLow = lowKey;
        zone.keyHigh = std::max(lowKey, topKey);
        zone.velocityLow = 1U;
        zone.velocityHigh = 127U;
        zone.rootKey = originalKey;
        zone.tuneCents = static_cast<float>(tune);
        zone.nonTranspose = nonTranspose;
        zone.sourceLevelRaw = level;
        zone.sourceFilterRaw = cutoff;
        zone.pan = std::clamp(static_cast<float>(pan) / 64.0F, -1.0F, 1.0F);
        // Preserve Korg's raw level in sourceLevelRaw. Do not invent an undocumented
        // dB conversion; gain remains unity until a verified transfer is defined.
        zone.gainDb = 0.0F;
        ms->zones.push_back(zone);
        lowKey = topKey < 127U ? static_cast<std::uint8_t>(topKey + 1U) : 127U;
    }

    if (ms->zones.empty()) return {nullptr, loaded, "KMP contained no loadable external KSF regions", warnings};
    return {ms, loaded, {}, warnings};
}

std::vector<std::string> KorgImporter::parseKsc(const std::string& path, std::string& error) {
    std::ifstream f(path);
    if (!f) { error = "Cannot open KSC file: " + path; return {}; }
    std::vector<std::string> entries;
    std::string line;
    bool sawHeader = false;
    while (std::getline(f, line)) {
        line = trim(line);
        if (line.empty()) continue;
        if (line[0] == '#') {
            if (!sawHeader && line.rfind("#KORG Script Version", 0U) == 0U) sawHeader = true;
            continue;
        }
        entries.push_back(line);
    }
    if (!sawHeader) {
        error = "KSC header is missing or unsupported";
        return {};
    }
    error.clear();
    return entries;
}

KorgCollectionResult KorgImporter::loadKsc(const std::string& path) {
    KorgCollectionResult out;
    std::string parseError;
    const auto entries = parseKsc(path, parseError);
    if (!parseError.empty()) { out.error = parseError; return out; }
    const silveton::fsx::path base = silveton::fsx::path(path).parent_path();

    std::vector<silveton::fsx::path> kmpEntries;
    std::vector<silveton::fsx::path> ksfEntries;
    for (const auto& entry : entries) {
        silveton::fsx::path p = entry;
        if (p.is_relative()) p = base / p;
        auto ext = p.extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        if (ext == ".kmp") kmpEntries.push_back(p);
        else if (ext == ".ksf") ksfEntries.push_back(p);
        else out.warnings.push_back("Skipped unsupported KSC entry: " + entry);
    }

    std::unordered_set<std::string> loadedSamplePaths;
    for (const auto& p : kmpEntries) {
        const auto r = loadKmp(p.string());
        if (!r.ok()) {
            out.warnings.push_back(p.filename().string() + ": " + r.error);
            continue;
        }
        out.multisamples.push_back(r.multisample);
        for (const auto& sample : r.samples) {
            if (sample != nullptr) {
                loadedSamplePaths.insert(silveton::fsx::path(sample->sourcePath).lexically_normal().string());
                out.samples.push_back(sample);
            }
        }
        out.warnings.insert(out.warnings.end(), r.warnings.begin(), r.warnings.end());
    }

    // Some KSC files also contain standalone KSF entries. Import only samples
    // that were not already pulled in through a KMP, avoiding duplicate layers.
    for (const auto& p : ksfEntries) {
        const auto normalized = p.lexically_normal().string();
        if (loadedSamplePaths.find(normalized) != loadedSamplePaths.end()) continue;
        const auto r = loadKsfStreaming(p.string());
        if (!r.ok()) {
            out.warnings.push_back(p.filename().string() + ": " + r.error);
            continue;
        }
        auto ms = std::make_shared<Multisample>();
        ms->name = r.sample->name.empty() ? p.stem().string() : r.sample->name;
        ms->sourceIdentity = std::string("KSF:") + sourceIdentityFor(p);
        SampleZone z{};
        z.sample = r.sample;
        z.keyLow = 0U; z.keyHigh = 127U;
        z.velocityLow = 1U; z.velocityHigh = 127U;
        z.rootKey = r.sample->rootKey;
        ms->zones.push_back(z);
        out.samples.push_back(r.sample);
        out.multisamples.push_back(ms);
        loadedSamplePaths.insert(normalized);
    }

    if (out.multisamples.empty()) out.error = "KSC contained no loadable KMP/KSF resources";
    return out;
}

} // namespace silveton::sampler
