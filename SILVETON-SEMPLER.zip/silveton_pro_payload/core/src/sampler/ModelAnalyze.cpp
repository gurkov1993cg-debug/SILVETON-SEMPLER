// SILVETON_MODEL_V1 - measuring a blend (see ModelAnalyze.h). A light version of the teacher's listening: the pitch near the note
// of the zone, the harmonics of the steady part -> the tone curve, the loudness frame by frame -> the loudness curve.
#include "silveton/sampler/ModelAnalyze.h"

#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cmath>
#include <complex>

namespace silveton::sampler::model {

namespace {
constexpr double kPi = 3.14159265358979323846;

void fft(std::vector<std::complex<double>>& a) {
    const std::size_t n = a.size();
    for (std::size_t i = 1, j = 0; i < n; ++i) {
        std::size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (std::size_t len = 2; len <= n; len <<= 1) {
        const double ang = -2.0 * kPi / static_cast<double>(len);
        const std::complex<double> wl(std::cos(ang), std::sin(ang));
        for (std::size_t i = 0; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (std::size_t j = 0; j < len / 2; ++j) {
                const std::complex<double> u = a[i + j], v = a[i + j + len / 2] * w;
                a[i + j] = u + v; a[i + j + len / 2] = u - v; w *= wl;
            }
        }
    }
}

// up to `maxFrames` frames of the sample as mono, from its preload or its stream
std::vector<float> monoOf(const SampleData& s, std::size_t maxFrames) {
    const std::uint64_t total = s.frameCount();
    const std::size_t n = static_cast<std::size_t>(std::min<std::uint64_t>(total, maxFrames));
    std::vector<float> out(n, 0.0F);
    const std::size_t pre = static_cast<std::size_t>(s.preloadedFrameCount());
    const unsigned ch = std::max<unsigned>(1U, s.channels);
    for (std::size_t i = 0; i < n; ++i) {
        double v = 0.0;
        if (i < pre) { for (unsigned c = 0; c < ch; ++c) v += s.interleaved[i * ch + c]; }
        else if (s.stream) { for (unsigned c = 0; c < ch; ++c) v += s.stream->readFrame(i, static_cast<std::uint16_t>(c)); }
        out[i] = static_cast<float>(v / ch);
    }
    return out;
}

struct Spectrum {
    int N = 4096; double sr = 48000.0;
    std::vector<double> mag;
    double binHz() const { return sr / N; }
    void at(const std::vector<float>& x, long centre) {
        std::vector<std::complex<double>> buf(static_cast<std::size_t>(N));
        for (int i = 0; i < N; ++i) {
            const long idx = centre - N / 2 + i;
            const double v = idx >= 0 && idx < static_cast<long>(x.size()) ? x[static_cast<std::size_t>(idx)] : 0.0;
            buf[static_cast<std::size_t>(i)] = std::complex<double>(v * (0.5 - 0.5 * std::cos(2.0 * kPi * (i + 0.5) / N)), 0.0);
        }
        fft(buf);
        mag.assign(static_cast<std::size_t>(N / 2 + 1), 0.0);
        for (int k = 0; k <= N / 2; ++k) mag[static_cast<std::size_t>(k)] = std::abs(buf[static_cast<std::size_t>(k)]);
    }
    double magAt(double hz) const { const double b = hz / binHz(); if (b < 0 || b >= N / 2) return 0; const int i = static_cast<int>(b); const double f = b - i; return mag[static_cast<std::size_t>(i)] + (mag[static_cast<std::size_t>(std::min(i + 1, N / 2))] - mag[static_cast<std::size_t>(i)]) * f; }
    bool peakNear(double hz, double tolHz, double& peakHz, double& amp) const {
        const double bh = binHz();
        const int lo = std::max(1, static_cast<int>(std::floor((hz - tolHz) / bh))), hi = std::min(N / 2 - 1, static_cast<int>(std::ceil((hz + tolHz) / bh)));
        if (hi <= lo) return false;
        int best = -1; double bm = 0;
        for (int k = lo; k <= hi; ++k) if (mag[static_cast<std::size_t>(k)] > bm && mag[static_cast<std::size_t>(k)] >= mag[static_cast<std::size_t>(k) - 1] && mag[static_cast<std::size_t>(k)] >= mag[static_cast<std::size_t>(k) + 1]) { bm = mag[static_cast<std::size_t>(k)]; best = k; }
        if (best < 0) return false;
        const double a = std::log(std::max(mag[static_cast<std::size_t>(best) - 1], 1e-12)), b = std::log(std::max(mag[static_cast<std::size_t>(best)], 1e-12)), c = std::log(std::max(mag[static_cast<std::size_t>(best) + 1], 1e-12));
        const double den = a - 2 * b + c;
        const double d = std::fabs(den) > 1e-12 ? std::max(-0.5, std::min(0.5, 0.5 * (a - c) / den)) : 0.0;
        peakHz = (best + d) * bh;
        amp = std::exp(b - 0.25 * (a - c) * d) * 4.0 / N;
        return true;
    }
    // the pitch near a prior (+- 2 semitones), made exact by the harmonics' own peaks; voicing = the harmonics' share of the power to 8 kHz
    double pitchNear(double prior, double& voicing) const {
        const double lo = prior * std::pow(2.0, -2.0 / 12.0), hi = prior * std::pow(2.0, 2.0 / 12.0);
        double bestF = prior, bestS = -1;
        for (int s = 0; s <= 120; ++s) {
            const double f = lo * std::pow(hi / lo, s / 120.0);
            double sum = 0; for (int k = 1; k <= 8; ++k) { if (k * f > sr * 0.45) break; sum += magAt(k * f) / std::sqrt(static_cast<double>(k)); }
            if (sum > bestS) { bestS = sum; bestF = f; }
        }
        double num = 0, den = 0;
        for (int k = 1; k <= 10; ++k) { if (k * bestF > sr * 0.45) break; double ph, am; if (peakNear(k * bestF, std::max(binHz() * 0.75, k * bestF * 0.012), ph, am) && am > 0) { num += am * am * ph / k; den += am * am; } }
        const double f0 = den > 0 ? num / den : bestF;
        double hp = 0, tp = 0; const int kMax = std::min(N / 2 - 2, static_cast<int>(8000.0 / binHz()));
        for (int k = 1; k <= kMax; ++k) tp += mag[static_cast<std::size_t>(k)] * mag[static_cast<std::size_t>(k)];
        for (int h = 1; h <= 24; ++h) { const double c = h * f0 / binHz(); if (c >= kMax) break; const int ci = static_cast<int>(std::lround(c)); for (int k = std::max(1, ci - 2); k <= std::min(kMax, ci + 2); ++k) hp += mag[static_cast<std::size_t>(k)] * mag[static_cast<std::size_t>(k)]; }
        voicing = tp > 0 ? hp / tp : 0;
        return f0;
    }
};

double keyHz(double key) { return 440.0 * std::pow(2.0, (key - 69.0) / 12.0); }
double dbOf(double a) { return 20.0 * std::log10(std::max(a, 1e-10)); }
}  // namespace

const ZoneShape* BlendShape::shapeOf(const SampleData* sample) const noexcept {
    for (const Entry& e : entries) if (e.sample == sample) return &e.shape;
    return nullptr;
}

ZoneShape analyzeSample(const SampleData& s, int rootKey, float tuneCents) {
    ZoneShape z; z.rootKey = rootKey; z.lowKey = 0; z.topKey = 127;
    for (float& h : z.harmDb) h = -120.0F;
    if (!s.valid()) return z;
    const double sr = s.sampleRate;
    std::vector<float> x = monoOf(s, static_cast<std::size_t>(sr * 1.5));
    // a looped recording shorter than a second (Korg loops of 40..100 ms, a single cycle) is played round and round, so it is measured
    // that way: the loop is repeated until there is at least 1.2 s (the loudness curve keeps the real start)
    const bool loopedShort = s.loop.enabled && s.loop.endFrame > s.loop.startFrame + 8U && s.loop.endFrame <= x.size() && x.size() < static_cast<std::size_t>(sr * 1.2);
    if (loopedShort) {
        const std::size_t ls = static_cast<std::size_t>(s.loop.startFrame), le = static_cast<std::size_t>(s.loop.endFrame), len = le - ls;
        x.resize(le);
        while (x.size() < static_cast<std::size_t>(sr * 1.2)) for (std::size_t i = 0; i < len && x.size() < static_cast<std::size_t>(sr * 1.25); ++i) x.push_back(x[ls + i]);
    }
    if (x.size() < static_cast<std::size_t>(sr * 0.05)) return z;
    // the loudness, 10 ms a frame
    const int hop = std::max(1, static_cast<int>(std::lround(sr * 0.010)));
    const int frames = static_cast<int>(x.size() / static_cast<std::size_t>(hop));
    std::vector<double> lvl(static_cast<std::size_t>(std::max(frames, 1)), -120.0);
    double peakDb = -120; int peakFrame = 0;
    for (int i = 0; i < frames; ++i) { double e = 0; for (int j = 0; j < hop; ++j) { const double v = x[static_cast<std::size_t>(i * hop + j)]; e += v * v; } lvl[static_cast<std::size_t>(i)] = dbOf(std::sqrt(e / hop)); if (lvl[static_cast<std::size_t>(i)] > peakDb) { peakDb = lvl[static_cast<std::size_t>(i)]; peakFrame = i; } }
    if (peakDb < -70) return z;
    // the steady part: the loop when it is inside what was read, else the later half after the peak
    const bool looped = s.loop.enabled && s.loop.endFrame > s.loop.startFrame + 8U;
    int s0, s1;
    if (loopedShort) { s0 = std::max(0, static_cast<int>(s.loop.startFrame / static_cast<std::uint64_t>(hop)) + 1); s1 = frames - 2; }
    else if (looped && s.loop.endFrame <= x.size()) { s0 = static_cast<int>(s.loop.startFrame / static_cast<std::uint64_t>(hop)); s1 = std::max(s0 + 1, static_cast<int>(s.loop.endFrame / static_cast<std::uint64_t>(hop)) - 1); }
    else { s0 = std::min(frames - 2, peakFrame + std::max(3, (frames - peakFrame) / 3)); s1 = std::max(s0 + 1, frames - 2); }
    s0 = std::max(0, std::min(s0, frames - 2)); s1 = std::max(s0 + 1, std::min(s1, frames - 1));
    double steadyDb = 0; for (int i = s0; i <= s1; ++i) steadyDb += lvl[static_cast<std::size_t>(i)]; steadyDb /= (s1 - s0 + 1);
    z.steadyRms = static_cast<float>(std::pow(10.0, steadyDb / 20.0));
    for (int i = 0; i < kLevelFrames; ++i) z.level[i] = static_cast<float>(i < frames ? std::max(-60.0, std::min(24.0, lvl[static_cast<std::size_t>(i)] - steadyDb)) : 0.0);
    // the attack: 10 % -> 90 % of the peak
    { int a10 = 0, a90 = peakFrame; for (int i = 0; i <= peakFrame; ++i) { if (lvl[static_cast<std::size_t>(i)] >= peakDb - 20) { a10 = i; break; } } for (int i = 0; i <= peakFrame; ++i) { if (lvl[static_cast<std::size_t>(i)] >= peakDb - 0.92) { a90 = i; break; } } z.attackMs = static_cast<float>(std::max(1, a90 - a10) * 10.0); }
    // the pitch and the harmonics: three spectra in the steady part
    Spectrum sp; sp.N = sr > 50000.0 ? 8192 : 4096; sp.sr = sr;
    const double prior = keyHz(rootKey + tuneCents / 100.0);
    std::vector<double> amp; int got = 0; double f0sum = 0;
    for (int t = 0; t < 3; ++t) {
        const int fi = s0 + (s1 - s0) * (t + 1) / 4;
        sp.at(x, static_cast<long>(fi) * hop);
        double voicing = 0; const double f0 = sp.pitchNear(prior, voicing);
        if (voicing < 0.3 || f0 <= 0) continue;
        if (amp.empty()) amp.assign(64, 0.0);
        for (int k = 1; k <= 64; ++k) { const double hz = k * f0; if (hz > sr * 0.47) break; double ph, am; if (sp.peakNear(hz, std::max(sp.binHz() * 0.75, hz * (k <= 8 ? 0.012 : 0.02)), ph, am)) amp[static_cast<std::size_t>(k - 1)] += am; }
        f0sum += f0; ++got;
    }
    if (got == 0) return z;
    for (double& a : amp) a /= got;
    z.f0Hz = static_cast<float>(f0sum / got);
    { double mx = 0.0; for (const double a : amp) mx = std::max(mx, a);
      for (int k = 0; k < kHarmonics; ++k) { const double a = amp[static_cast<std::size_t>(k)]; z.harmDb[k] = (mx > 0.0 && a > mx * 1e-6) ? static_cast<float>(20.0 * std::log10(a / mx)) : -120.0F; } }
    // the tone curve, like the models'
    {
        const int H = 64; int last = -1; for (int k = 0; k < H; ++k) if (amp[static_cast<std::size_t>(k)] > 0) last = k;
        for (int b = 0; b < kBands; ++b) z.tone[b] = -120.0F;
        if (last >= 0) {
            double maxDb = -200; std::vector<double> db(static_cast<std::size_t>(H), -200.0);
            for (int k = 0; k < H; ++k) if (amp[static_cast<std::size_t>(k)] > 0) { db[static_cast<std::size_t>(k)] = dbOf(amp[static_cast<std::size_t>(k)]); maxDb = std::max(maxDb, db[static_cast<std::size_t>(k)]); }
            for (int b = 0; b < kBands; ++b) {
                const double kf = bandHz(b) / z.f0Hz;
                if (kf < 0.75 || kf > last + 1.25) continue;
                const double kk = std::min(std::max(kf, 1.0), static_cast<double>(last + 1));
                const int k0 = std::max(1, std::min(last + 1, static_cast<int>(std::floor(kk)))), k1 = std::min(last + 1, k0 + 1);
                const double tt = kk - k0;
                double d0 = db[static_cast<std::size_t>(k0 - 1)], d1 = db[static_cast<std::size_t>(k1 - 1)];
                if (d0 < -150 && d1 < -150) continue;
                if (d0 < -150) d0 = d1;
                if (d1 < -150) d1 = d0;
                z.tone[b] = static_cast<float>(std::max(-96.0, d0 * (1 - tt) + d1 * tt - maxDb));
            }
        }
    }
    z.ok = true;
    return z;
}

std::shared_ptr<const BlendShape> analyzeBlend(const Program& program) {
    auto out = std::make_shared<BlendShape>();
    out->program = &program;
    for (const ProgramLayer& layer : program.layers) {
        if (!layer.enabled || layer.multisample == nullptr) continue;
        for (const SampleZone& zone : layer.multisample->zones) {
            if (zone.sample == nullptr || out->shapeOf(zone.sample.get()) != nullptr) continue;
            BlendShape::Entry e; e.sample = zone.sample.get();
            e.shape = analyzeSample(*zone.sample, static_cast<int>(zone.rootKey) + zone.transposeSemitones + layer.transposeSemitones, zone.tuneCents + layer.tuneCents);
            e.shape.lowKey = zone.keyLow; e.shape.topKey = zone.keyHigh;
            out->entries.push_back(e);
            if (out->entries.size() >= 256U) return out;
        }
    }
    return out;
}

} // namespace silveton::sampler::model
