// SILVETON_MODEL_V1 - reading SILVETON_OSC.sv of the teacher and turning it into the shapes the engine lays over a blend.
#include "silveton/sampler/ModelBank.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <utility>

namespace silveton::sampler::model {

namespace {
constexpr int kTeacherNoiseBands = 8;
constexpr int kTeacherLoopFrames = 32;
constexpr float kTeacherFrameMs = 5.0F;
constexpr int kNumCountV2 = 32, kNumCountV3 = 40;
enum : int { nF0 = 0, nTune = 1, nScoop = 2, nVibHz = 3, nVibCents = 4, nLife = 5, nAttack = 7, nRelease = 11, nLoopLen = 31, nUnison = 32 };

inline std::uint16_t u16(const std::uint8_t* p) noexcept { return static_cast<std::uint16_t>(p[0] | (p[1] << 8)); }
inline std::uint32_t u32(const std::uint8_t* p) noexcept { return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) | (static_cast<std::uint32_t>(p[2]) << 16) | (static_cast<std::uint32_t>(p[3]) << 24); }
inline float f32(const std::uint8_t* p) noexcept { const std::uint32_t x = u32(p); float f; std::memcpy(&f, &x, 4); return f; }
inline double trackDb(std::uint8_t q) noexcept { return harmTrackDb(q); }
inline double dbOf(double a) noexcept { return 20.0 * std::log10(std::max(a, 1e-10)); }

// the tone curve from the harmonics of the steady part: between two harmonics the curve is straight in dB over log frequency;
// a band below the first harmonic or above the last has no information (-120)
void toneFromHarmonics(const std::vector<double>& ampLinear, double f0, float* tone) {
    const int H = static_cast<int>(ampLinear.size());
    for (int b = 0; b < kBands; ++b) tone[b] = -120.0F;
    if (H < 1 || f0 <= 0.0) return;
    int last = -1; for (int k = 0; k < H; ++k) if (ampLinear[static_cast<std::size_t>(k)] > 0.0) last = k;
    if (last < 0) return;
    double maxDb = -200.0;
    std::vector<double> db(static_cast<std::size_t>(H), -200.0);
    for (int k = 0; k < H; ++k) if (ampLinear[static_cast<std::size_t>(k)] > 0.0) { db[static_cast<std::size_t>(k)] = dbOf(ampLinear[static_cast<std::size_t>(k)]); maxDb = std::max(maxDb, db[static_cast<std::size_t>(k)]); }
    for (int b = 0; b < kBands; ++b) {
        const double fc = bandHz(b);
        const double kf = fc / f0;   // the harmonic number this band sits at
        if (kf < 0.75 || kf > last + 1.25) continue;
        const double kk = std::min(std::max(kf, 1.0), static_cast<double>(last + 1));
        const int k0 = std::max(1, std::min(last + 1, static_cast<int>(std::floor(kk)))), k1 = std::min(last + 1, k0 + 1);
        const double t = kk - k0;
        double d0 = db[static_cast<std::size_t>(k0 - 1)], d1 = db[static_cast<std::size_t>(k1 - 1)];
        if (d0 < -150.0 && d1 < -150.0) continue;
        if (d0 < -150.0) d0 = d1;
        if (d1 < -150.0) d1 = d0;
        tone[b] = static_cast<float>(std::max(-96.0, (d0 * (1.0 - t) + d1 * t) - maxDb));
    }
}
// SILVETON_FULLTRACK_V1: how loud a zone is at its loudest, by ear. The ear curve is the one of SynthVoice.cpp (the A curve, power, 1 at 1 kHz).
double earPowerHz(double hz) noexcept {
    const double f2 = hz * hz;
    const double num = 12194.0 * 12194.0 * f2 * f2;
    const double den = (f2 + 20.6 * 20.6) * std::sqrt((f2 + 107.7 * 107.7) * (f2 + 737.9 * 737.9)) * (f2 + 12194.0 * 12194.0);
    const double a = num / den * 1.2589;
    return a * a;
}
// The loudest 100 ms of the track (the ear's power of the rows, 20 rows boxcar, at the pitch the zone was measured at) and the harmonics
// of that moment. The track is played against this reference, so every sound - one that dies away or one that holds - has the same
// loudness at its loudest (Цветомир: "всички модели с еднаква сила"); the steady snapshots would make a dying sound far too loud.
void findPeakWindow(ZoneShape& z) {
    const int A = z.attackRows, H = z.trackH, hk = std::min(H, kHarmonics);
    for (int k = 0; k < kHarmonics; ++k) z.peakDb[k] = -200.0F;
    if (A < 1 || H < 1) return;
    double f0 = z.f0Hz > 20.0F ? static_cast<double>(z.f0Hz) : 440.0 * std::pow(2.0, (z.rootKey - 69) / 12.0);
    double w[kHarmonics];
    for (int k = 0; k < hk; ++k) { const double hz = f0 * (k + 1); w[k] = hz < 22000.0 ? earPowerHz(hz) : 0.0; }
    double table[256];   // the power of an amplitude of q half-decibels below the reference
    for (int q = 0; q < 255; ++q) table[q] = std::pow(10.0, -0.05 * q);
    table[255] = 0.0;
    std::vector<double> pre(static_cast<std::size_t>(A) + 1U, 0.0);   // running sum of the rows' ear power
    for (int r = 0; r < A; ++r) {
        const std::uint8_t* row = &z.harmTrack[static_cast<std::size_t>(r) * static_cast<std::size_t>(H)];
        double s = 0.0;
        for (int k = 0; k < hk; ++k) s += 0.5 * table[row[k]] * w[k];
        pre[static_cast<std::size_t>(r) + 1U] = pre[static_cast<std::size_t>(r)] + s;
    }
    constexpr int kHalf = 10;   // 20 rows = 100 ms
    int best = A / 2; double bestMean = -1.0;
    for (int c = 0; c < A; ++c) {
        const int lo = std::max(0, c - kHalf), hi = std::min(A, c + kHalf);
        const double m = (pre[static_cast<std::size_t>(hi)] - pre[static_cast<std::size_t>(lo)]) / (hi - lo);
        if (m > bestMean) { bestMean = m; best = c; }
    }
    if (bestMean <= 1e-18) return;   // silent: no reference (the zone plays nothing)
    const int lo = std::max(0, best - kHalf), hi = std::min(A, best + kHalf);
    for (int k = 0; k < hk; ++k) {
        double a = 0.0;
        for (int r = lo; r < hi; ++r) a += std::sqrt(table[z.harmTrack[static_cast<std::size_t>(r) * static_cast<std::size_t>(H) + static_cast<std::size_t>(k)]]);
        a /= (hi - lo);
        z.peakDb[k] = a > 1e-9 ? static_cast<float>(20.0 * std::log10(a)) : -200.0F;
    }
}
}  // namespace

float bandHz(int band) noexcept { return 40.0F * std::pow(2.0F, 0.3F * static_cast<float>(std::clamp(band, 0, kBands - 1))); }
float bandOfHz(float hz) noexcept { return std::log2(std::max(hz, 1.0F) / 40.0F) / 0.3F; }

int ModelShape::zoneFor(int key) const noexcept {
    int best = -1, bestDist = 1 << 20;
    for (std::size_t i = 0; i < zones.size(); ++i) {
        const ZoneShape& z = zones[i]; if (!z.ok) continue;
        if (key >= z.lowKey && key <= z.topKey) return static_cast<int>(i);
        const int d = key < z.lowKey ? z.lowKey - key : key - z.topKey;
        if (d < bestDist) { bestDist = d; best = static_cast<int>(i); }
    }
    return best;
}

int ModelShape::expressiveZoneFor(int key, int velocity, int cc2, int cc11) const noexcept {
    // Restrict matching to the closest keyboard root before considering
    // dynamics, so a nearby model does not take a different pitch zone.
    const int origin = zoneFor(key);
    if (origin < 0) return -1;
    const ZoneShape& first = zones[static_cast<std::size_t>(origin)];
    int best = origin;
    int bestScore = 0x7fffffff;
    for (std::size_t i = 0; i < zones.size(); ++i) {
        const ZoneShape& z = zones[i];
        if (!z.ok || z.rootKey != first.rootKey || z.lowKey != first.lowKey || z.topKey != first.topKey) continue;
        const int dv = velocity - z.learnedVelocity, db = cc2 - z.learnedCC2, de = cc11 - z.learnedCC11;
        const int score = dv * dv + db * db + de * de;
        if (score < bestScore) { best = static_cast<int>(i); bestScore = score; }
    }
    return best;
}

std::shared_ptr<const LearnedModels> parseLearnedModels(const std::vector<std::uint8_t>& b, const std::string& path) {
    auto out = std::make_shared<LearnedModels>();
    out->path = path;
    const auto fail = [&](const char* why) { out->error = why; out->models.clear(); return std::shared_ptr<const LearnedModels>(out); };
    if (b.size() < 20U) return fail("SILVETON_OSC.sv е празен или отрязан");
    if (std::memcmp(b.data(), "SVOSC001", 8) == 0) return fail("Това е стар файл с вълни (OSCILLATOR LAB), не модели от SILVETON TEACHER");
    int numCount = 0;
    const bool expressive = std::memcmp(b.data(), "SVOSC004", 8) == 0;
    if (expressive || std::memcmp(b.data(), "SVOSC003", 8) == 0) numCount = kNumCountV3;
    else if (std::memcmp(b.data(), "SVOSC002", 8) == 0) numCount = kNumCountV2;
    else return fail("Това не е SILVETON_OSC.sv от SILVETON TEACHER");
    std::size_t p = 8;
    const auto need = [&](std::size_t n) { return p + n <= b.size(); };
    if (!need(4)) return fail("SILVETON_OSC.sv е отрязан");
    const std::uint32_t count = u32(&b[p]); p += 4;
    if (count > 4096U) return fail("SILVETON_OSC.sv: невъзможен брой звуци");
    out->total = count;
    bool anyLongTrack = false;   // Legacy inference applies only to unmarked zones.
    std::vector<bool> playbackExplicit;
    for (std::uint32_t i = 0; i < count; ++i) {
        ModelShape m;
        if (!need(2)) return fail("SILVETON_OSC.sv е отрязан");
        const std::uint16_t nl = u16(&b[p]); p += 2; if (!need(nl)) return fail("SILVETON_OSC.sv е отрязан"); m.name.assign(reinterpret_cast<const char*>(&b[p]), nl); p += nl;
        if (!need(2)) return fail("SILVETON_OSC.sv е отрязан");
        const std::uint16_t sl = u16(&b[p]); p += 2; if (!need(sl)) return fail("SILVETON_OSC.sv е отрязан"); m.slot.assign(reinterpret_cast<const char*>(&b[p]), sl); p += sl;
        { const std::size_t mark = m.slot.find('\x1f'); if (mark != std::string::npos) m.slot.resize(mark); }   // SILVETON_MODELNAMES_V1: the teacher keeps "<slot><0x1F><the name it was learned under>" - the tablet shows the slot only
        if (!need(2)) return fail("SILVETON_OSC.sv е отрязан");
        const std::uint16_t zc = u16(&b[p]); p += 2;
        for (std::uint16_t zi = 0; zi < zc; ++zi) {
            ZoneShape z;
            if (!need(4)) return fail("SILVETON_OSC.sv е отрязан");
            z.lowKey = b[p]; z.topKey = b[p + 1]; z.rootKey = b[p + 2]; const unsigned flags = b[p + 3]; p += 4;
            z.ok = (flags & 1U) != 0U; z.looped = (flags & 2U) != 0U;
            if (expressive) {
                if (!need(4)) return fail("SILVETON_OSC.sv: отрязани expressive MIDI данни");
                z.learnedVelocity = b[p++]; z.learnedCC2 = b[p++]; z.learnedCC11 = b[p++]; ++p;
                if (z.learnedVelocity < 1 || z.learnedVelocity > 127 || z.learnedCC2 > 127 || z.learnedCC11 > 127)
                    return fail("SILVETON_OSC.sv: невалидни MIDI слоеве");
            }
            const bool explicitMode = (flags & kZonePlaybackExplicit) != 0U;
            playbackExplicit.push_back(explicitMode);
            z.fullTrack = explicitMode && (flags & kZonePlaybackFullTrack) != 0U;
            float n[kNumCountV3] = {};
            if (!need(4U * static_cast<std::size_t>(numCount))) return fail("SILVETON_OSC.sv е отрязан");
            for (int k = 0; k < numCount; ++k) { n[k] = f32(&b[p]); p += 4; }
            if (!need(10)) return fail("SILVETON_OSC.sv е отрязан");
            const int H = u16(&b[p]), A = u16(&b[p + 2]), L = u16(&b[p + 4]); p += 6; p += 4;   // frameMs
            if (z.ok) {
                if (L != kTeacherLoopFrames || H < 1 || H > 64 || A > 4096) return fail("SILVETON_OSC.sv: зона с непознат размер");
                const std::size_t rows = static_cast<std::size_t>(A + L);
                if (!need(rows * static_cast<std::size_t>(H) + rows * kTeacherNoiseBands + static_cast<std::size_t>(A))) return fail("SILVETON_OSC.sv е отрязан");
                const std::uint8_t* harm = &b[p]; p += rows * static_cast<std::size_t>(H);
                const std::uint8_t* noise = &b[p]; p += rows * kTeacherNoiseBands;
                const std::int8_t* pitch = reinterpret_cast<const std::int8_t*>(&b[p]); p += static_cast<std::size_t>(A);
                // the numbers
                z.f0Hz = n[nF0]; z.octaveShift = static_cast<int>(std::lround(n[nTune] / 1200.0F));
                z.attackMs = n[nAttack]; z.releaseMs = n[nRelease];
                z.vibratoHz = n[nVibHz]; z.vibratoCents = n[nVibCents]; z.lifeCents = n[nLife];
                z.unisonCents = numCount >= kNumCountV3 ? n[nUnison] : 0.0F;
                z.loopMs = numCount >= kNumCountV3 && z.looped && n[nLoopLen] > 0.0F ? n[nLoopLen] : 0.0F;
                if (!explicitMode && A > kOldMaxAttackRows) anyLongTrack = true;
                // the steady part: the mean of the loop rows
                std::vector<double> amp(static_cast<std::size_t>(H), 0.0);
                double steadyPower = 0.0;
                for (int r = A; r < A + L; ++r) { double pw = 0.0; for (int k = 0; k < H; ++k) { const double a = std::pow(10.0, trackDb(harm[static_cast<std::size_t>(r) * H + k]) / 20.0); amp[static_cast<std::size_t>(k)] += a / L; pw += a * a * 0.5; } steadyPower += pw / L; }
                toneFromHarmonics(amp, z.f0Hz, z.tone);
                z.harmTrack.assign(harm, harm + rows * static_cast<std::size_t>(H)); z.trackRows = A + L; z.attackRows = A; z.trackH = H;   // SILVETON_SYNTH_V1
                if (expressive && (flags & 16U) != 0U) {
                    z.synthPitchRows.assign(pitch, pitch + A);
                    z.synthNoiseRows.resize(rows);
                    for (std::size_t rr = 0; rr < rows; ++rr) {
                        for (int eb = 0; eb < 4; ++eb) {
                            const auto q0 = noise[rr * kTeacherNoiseBands + static_cast<std::size_t>(eb * 2)];
                            const auto q1 = noise[rr * kTeacherNoiseBands + static_cast<std::size_t>(eb * 2 + 1)];
                            const float a = q0 == 255U ? 0.0F : static_cast<float>(std::pow(10.0, trackDb(q0) / 20.0));
                            const float bandOne = q1 == 255U ? 0.0F : static_cast<float>(std::pow(10.0, trackDb(q1) / 20.0));
                            z.synthNoiseRows[rr][static_cast<std::size_t>(eb)] = std::sqrt(a * a + bandOne * bandOne);
                        }
                    }
                }
                { double mx = 0.0; for (const double a : amp) mx = std::max(mx, a);
                  for (int k = 0; k < kHarmonics; ++k) { const double a = k < H ? amp[static_cast<std::size_t>(k)] : 0.0; z.harmDb[k] = (mx > 0.0 && a > mx * 1e-6) ? static_cast<float>(20.0 * std::log10(a / mx)) : -120.0F; } }
                z.pitchDoubt = std::max(z.harmDb[0], std::max(z.harmDb[1], z.harmDb[2])) < -40.0F;   // SILVETON_MODEL_CLEAN_V1: no fundamental = another octave
                z.steadyRms = static_cast<float>(std::sqrt(std::max(steadyPower, 1e-20)));
                // the loudness in time: the attack rows (5 ms) against the steady power, 10 ms a frame
                for (int i2 = 0; i2 < kLevelFrames; ++i2) {
                    const int r0 = i2 * 2, r1 = i2 * 2 + 1;
                    if (r0 >= A) { z.level[i2] = 0.0F; continue; }
                    double pw = 0.0; int m2 = 0;
                    for (int r = r0; r <= std::min(r1, A - 1); ++r) { double rp = 0.0; for (int k = 0; k < H; ++k) { const double a = std::pow(10.0, trackDb(harm[static_cast<std::size_t>(r) * H + k]) / 20.0); rp += a * a * 0.5; } pw += rp; ++m2; }
                    pw /= std::max(1, m2);
                    z.level[i2] = static_cast<float>(std::max(-60.0, std::min(24.0, 10.0 * std::log10((pw + 1e-20) / (steadyPower + 1e-20)))));
                }
                for (int i2 = 0; i2 < kScoopFrames; ++i2) z.scoop[i2] = i2 < A ? static_cast<float>(pitch[i2]) : 0.0F;
                // the breath: eight teacher bands -> four engine bands (0-500 / 500-2k / 2k-8k / 8k+), the steady part and the attack's peak
                for (int eb = 0; eb < kNoiseBands; ++eb) {
                    double steady = 0.0, attackMax = 0.0;
                    for (int tb = eb * 2; tb < eb * 2 + 2; ++tb) {
                        double s = 0.0; for (int r = A; r < A + L; ++r) { const double a = std::pow(10.0, trackDb(noise[static_cast<std::size_t>(r) * kTeacherNoiseBands + tb]) / 20.0); s += a * a / L; }
                        steady += s;
                        double mx = 0.0; for (int r = 0; r < std::min(A, 10); ++r) { const double a = std::pow(10.0, trackDb(noise[static_cast<std::size_t>(r) * kTeacherNoiseBands + tb]) / 20.0); mx = std::max(mx, a * a); }
                        attackMax += mx;
                    }
                    z.breathDb[eb] = static_cast<float>(std::max(-120.0, dbOf(std::sqrt(steady))));
                    z.chiffDb[eb] = static_cast<float>(std::max(-120.0, dbOf(std::sqrt(attackMax))));
                }
            }
            m.zones.push_back(z);
        }
        out->models.push_back(std::move(m));
    }
    if (!need(8) || std::memcmp(&b[p], "SVOSCEND", 8) != 0) return fail("SILVETON_OSC.sv няма краен знак");
    std::size_t zoneIndex = 0;
    for (auto& m : out->models) for (auto& z : m.zones) {
        if (!playbackExplicit[zoneIndex++]) z.fullTrack = anyLongTrack;
        z.fullTrack = z.fullTrack && z.ok && z.attackRows >= 1;
        if (z.fullTrack) findPeakWindow(z);
    }
    // Precalculate all spectrum normalisation coefficients on the model-loading
    // thread. When CC2/CC11 moves in a long note, the audio callback only
    // copies these floats; no transcendental computations are needed here.
    for (auto& m : out->models) for (auto& z : m.zones) {
        z.synthSteadyDb.fill(-200.0F);
        z.synthSteadyRef = 1.0F;
        z.synthPeakRefDb = -200.0F;
        if (!z.ok || z.trackRows <= 0 || z.trackH <= 0) continue;
        const int loopRows = std::max(1, z.trackRows - z.attackRows);
        double mx = 1e-12;
        for (int k = 0; k < std::min(kHarmonics, z.trackH); ++k) {
            double a = 0.0;
            for (int rr = z.attackRows; rr < z.trackRows; ++rr) {
                a += std::pow(10.0, harmTrackDb(z.harmTrack[static_cast<std::size_t>(rr) *
                                   static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]) / 20.0);
            }
            a /= loopRows;
            z.synthSteadyDb[static_cast<std::size_t>(k)] = a > 1e-9
                ? static_cast<float>(20.0 * std::log10(a)) : -200.0F;
            mx = std::max(mx, a);
        }
        z.synthSteadyRef = static_cast<float>(mx);
        if (z.fullTrack) for (int k = 0; k < std::min(kHarmonics, z.trackH); ++k)
            z.synthPeakRefDb = std::max(z.synthPeakRefDb, z.peakDb[k]);
        z.synthNoiseRefGain = z.fullTrack
            ? static_cast<float>(std::pow(10.0, std::clamp(-static_cast<double>(z.synthPeakRefDb), -60.0, 60.0) / 20.0))
            : 1.0F / std::max(z.synthSteadyRef, 1.0e-9F);
        z.synthPrecomputed = true;
    }
    return out;
}

// ---------------------------------------------------------------------------------------------------------------- SILVETON_MODELS_FROM_FILE_V1
// Where every sound of a teacher file begins and ends (only the sizes are followed, nothing is turned into shapes). The same walk as parseLearnedModels.
namespace {
struct ZonePlaybackMark {
    std::size_t flagsOffset;
    bool hasTrack;
};
struct SoundRange {
    std::size_t first, second;
    std::vector<ZonePlaybackMark> playback;
};
bool soundRanges(const std::vector<std::uint8_t>& b, std::vector<SoundRange>& ranges, std::string& why,
                 bool* legacyFullTrack = nullptr) {
    ranges.clear();
    if (legacyFullTrack != nullptr) *legacyFullTrack = false;
    if (b.size() < 20U) { why = "SILVETON_OSC.sv е празен или отрязан"; return false; }
    int numCount = 0;
    const bool expressive = std::memcmp(b.data(), "SVOSC004", 8) == 0;
    if (expressive || std::memcmp(b.data(), "SVOSC003", 8) == 0) numCount = kNumCountV3;
    else if (std::memcmp(b.data(), "SVOSC002", 8) == 0) numCount = kNumCountV2;
    else { why = "Това не е SILVETON_OSC.sv от SILVETON TEACHER"; return false; }
    std::size_t p = 8;
    const auto need = [&](std::size_t n) { return p + n <= b.size(); };
    const std::uint32_t count = u32(&b[p]); p += 4;
    if (count > 4096U) { why = "SILVETON_OSC.sv: невъзможен брой звуци"; return false; }
    for (std::uint32_t i = 0; i < count; ++i) {
        const std::size_t start = p;
        SoundRange range{start, start, {}};
        if (!need(2)) { why = "SILVETON_OSC.sv е отрязан"; return false; }
        const std::uint16_t nl = u16(&b[p]); p += 2; if (!need(nl)) { why = "SILVETON_OSC.sv е отрязан"; return false; } p += nl;
        if (!need(2)) { why = "SILVETON_OSC.sv е отрязан"; return false; }
        const std::uint16_t sl = u16(&b[p]); p += 2; if (!need(sl)) { why = "SILVETON_OSC.sv е отрязан"; return false; } p += sl;
        if (!need(2)) { why = "SILVETON_OSC.sv е отрязан"; return false; }
        const std::uint16_t zc = u16(&b[p]); p += 2;
        for (std::uint16_t zi = 0; zi < zc; ++zi) {
            if (!need(4)) { why = "SILVETON_OSC.sv е отрязан"; return false; }
            const std::size_t flagsOffset = p + 3;
            const unsigned flags = b[flagsOffset]; p += 4;
            if (expressive) {
                if (!need(4)) { why = "SILVETON_OSC.sv: отрязани expressive MIDI данни"; return false; }
                if (b[p] < 1 || b[p] > 127 || b[p + 1] > 127 || b[p + 2] > 127) {
                    why = "SILVETON_OSC.sv: невалидни MIDI слоеве"; return false;
                }
                p += 4;
            }
            if (!need(4U * static_cast<std::size_t>(numCount) + 10U)) { why = "SILVETON_OSC.sv е отрязан"; return false; }
            p += 4U * static_cast<std::size_t>(numCount);
            const int H = u16(&b[p]), A = u16(&b[p + 2]), L = u16(&b[p + 4]); p += 10;
            range.playback.push_back({flagsOffset, (flags & 1U) != 0U && A > 0});
            if ((flags & 1U) != 0U) {
                if (L != kTeacherLoopFrames || H < 1 || H > 64 || A > 4096) { why = "SILVETON_OSC.sv: зона с непознат размер"; return false; }
                const std::size_t rows = static_cast<std::size_t>(A + L);
                const std::size_t bytes = rows * static_cast<std::size_t>(H) + rows * kTeacherNoiseBands + static_cast<std::size_t>(A);
                if (!need(bytes)) { why = "SILVETON_OSC.sv е отрязан"; return false; }
                p += bytes;
                if (legacyFullTrack != nullptr && (flags & kZonePlaybackExplicit) == 0U && A > kOldMaxAttackRows)
                    *legacyFullTrack = true;
            }
        }
        range.second = p;
        ranges.push_back(std::move(range));
    }
    if (!need(8) || std::memcmp(&b[p], "SVOSCEND", 8) != 0) { why = "SILVETON_OSC.sv няма краен знак"; return false; }
    return true;
}
std::uint8_t pinnedPlaybackFlags(std::uint8_t flags, bool hasTrack, bool legacyFullTrack) noexcept {
    const bool fullTrack = hasTrack && ((flags & kZonePlaybackExplicit) != 0U
        ? (flags & kZonePlaybackFullTrack) != 0U : legacyFullTrack);
    const unsigned preserved = flags & ~(static_cast<unsigned>(kZonePlaybackExplicit) | kZonePlaybackFullTrack);
    return static_cast<std::uint8_t>(preserved | kZonePlaybackExplicit | (fullTrack ? kZonePlaybackFullTrack : 0U));
}
}  // namespace

bool removeSoundsFromBytes(const std::vector<std::uint8_t>& b, const std::vector<int>& indices, std::vector<std::uint8_t>& out, std::string& why) {
    std::vector<SoundRange> ranges;
    bool legacyFullTrack = false;
    if (!soundRanges(b, ranges, why, &legacyFullTrack)) return false;
    std::vector<bool> drop(ranges.size(), false);
    for (const int i : indices) { if (i < 0 || i >= static_cast<int>(ranges.size())) { why = "Няма такъв модел във файла"; return false; } drop[static_cast<std::size_t>(i)] = true; }
    if (indices.empty()) { out = b; return true; }
    std::uint32_t kept = 0; std::size_t size = 8U + 4U + 8U;
    for (std::size_t i = 0; i < ranges.size(); ++i) if (!drop[i]) { ++kept; size += ranges[i].second - ranges[i].first; }
    out.clear(); out.reserve(size);
    out.insert(out.end(), b.begin(), b.begin() + 8);
    for (int k = 0; k < 4; ++k) out.push_back(static_cast<std::uint8_t>((kept >> (8 * k)) & 0xFFU));
    for (std::size_t i = 0; i < ranges.size(); ++i) if (!drop[i]) {
        const SoundRange& range = ranges[i];
        const std::size_t start = out.size();
        out.insert(out.end(), b.begin() + static_cast<std::ptrdiff_t>(range.first), b.begin() + static_cast<std::ptrdiff_t>(range.second));
        for (const auto& zone : range.playback)
            out[start + zone.flagsOffset - range.first] = pinnedPlaybackFlags(b[zone.flagsOffset], zone.hasTrack, legacyFullTrack);
    }
    out.insert(out.end(), {'S', 'V', 'O', 'S', 'C', 'E', 'N', 'D'});
    return true;
}

std::string removeLearnedSounds(const std::string& file, const std::vector<int>& indices) {
    if (indices.empty()) return std::string();
    std::vector<std::uint8_t> b;
    {
        std::ifstream in(file.c_str(), std::ios::binary);
        if (!in) return "няма SILVETON_OSC.sv";
        in.seekg(0, std::ios::end); const std::streamoff n = in.tellg(); in.seekg(0, std::ios::beg);
        if (n <= 0 || n > (std::streamoff(1) << 30)) return "SILVETON_OSC.sv е празен или прекалено голям";
        b.resize(static_cast<std::size_t>(n));
        in.read(reinterpret_cast<char*>(b.data()), n);
        if (in.gcount() != n) return "SILVETON_OSC.sv не се чете";
    }
    std::vector<SoundRange> ranges;
    std::string why;
    bool legacyFullTrack = false;
    if (!soundRanges(b, ranges, why, &legacyFullTrack)) return why;
    std::vector<bool> drop(ranges.size(), false);
    std::size_t dropped = 0;
    for (const int i : indices) { if (i < 0 || i >= static_cast<int>(ranges.size())) return "Няма такъв модел във файла"; if (!drop[static_cast<std::size_t>(i)]) { drop[static_cast<std::size_t>(i)] = true; ++dropped; } }
    const std::size_t keptCount = ranges.size() - dropped;
    std::size_t newSize = 8U + 4U + 8U;
    for (std::size_t i = 0; i < ranges.size(); ++i) if (!drop[i]) {
        newSize += ranges[i].second - ranges[i].first;
        for (const auto& zone : ranges[i].playback)
            b[zone.flagsOffset] = pinnedPlaybackFlags(b[zone.flagsOffset], zone.hasTrack, legacyFullTrack);
    }
    const std::string tmp = file + ".new";
    {   // written range by range from the bytes already in memory (no second copy of a big file)
        std::ofstream o(tmp.c_str(), std::ios::binary | std::ios::trunc);
        if (!o) return "Не мога да направя " + tmp;
        o.write(reinterpret_cast<const char*>(b.data()), 8);
        const std::uint32_t kept = static_cast<std::uint32_t>(keptCount);
        const char cnt[4] = {static_cast<char>(kept & 0xFFU), static_cast<char>((kept >> 8) & 0xFFU), static_cast<char>((kept >> 16) & 0xFFU), static_cast<char>((kept >> 24) & 0xFFU)};
        o.write(cnt, 4);
        for (std::size_t i = 0; i < ranges.size(); ++i) if (!drop[i]) o.write(reinterpret_cast<const char*>(&b[ranges[i].first]), static_cast<std::streamsize>(ranges[i].second - ranges[i].first));
        o.write("SVOSCEND", 8);
        o.flush();
        if (!o) { o.close(); std::remove(tmp.c_str()); return "Записът не успя (няма място или няма достъп)"; }
    }
    b.clear(); b.shrink_to_fit();
    {   // read back: the right size and every sound in its place, nothing else
        std::ifstream in(tmp.c_str(), std::ios::binary);
        std::vector<std::uint8_t> back;
        bool good = static_cast<bool>(in);
        if (good) { in.seekg(0, std::ios::end); const std::streamoff n = in.tellg(); in.seekg(0, std::ios::beg); good = n == static_cast<std::streamoff>(newSize); if (good) { back.resize(static_cast<std::size_t>(n)); in.read(reinterpret_cast<char*>(back.data()), n); good = in.gcount() == n; } }
        std::vector<SoundRange> r2; std::string w2;
        if (good) good = soundRanges(back, r2, w2) && r2.size() == keptCount;
        if (!good) { std::remove(tmp.c_str()); return "Новият файл не се провери - старият остава непроменен"; }
    }
    if (std::rename(tmp.c_str(), file.c_str()) != 0) { std::remove(tmp.c_str()); return "Не мога да сменя SILVETON_OSC.sv - старият остава непроменен"; }
    return std::string();
}

std::shared_ptr<const LearnedModels> loadLearnedModels(const std::string& file) {
    std::ifstream in(file.c_str(), std::ios::binary);
    if (!in) { auto out = std::make_shared<LearnedModels>(); out->path = file; out->error = "няма SILVETON_OSC.sv"; return out; }
    in.seekg(0, std::ios::end); const std::streamoff n = in.tellg(); in.seekg(0, std::ios::beg);
    if (n <= 0 || n > (std::streamoff(1) << 30)) { auto out = std::make_shared<LearnedModels>(); out->path = file; out->error = "SILVETON_OSC.sv е празен или прекалено голям"; return out; }
    std::vector<std::uint8_t> b(static_cast<std::size_t>(n));
    in.read(reinterpret_cast<char*>(b.data()), n);
    if (in.gcount() != n) { auto out = std::make_shared<LearnedModels>(); out->path = file; out->error = "SILVETON_OSC.sv не се чете"; return out; }
    return parseLearnedModels(b, file);
}

} // namespace silveton::sampler::model
