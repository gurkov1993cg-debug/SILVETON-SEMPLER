// SILVETON_MODEL_V1 - reading SILVETON_OSC.sv of the teacher and turning it into the shapes the engine lays over a blend.
#include "silveton/sampler/ModelBank.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>

namespace silveton::sampler::model {

namespace {
constexpr int kTeacherNoiseBands = 8;
constexpr int kTeacherLoopFrames = 32;
constexpr float kTeacherFrameMs = 5.0F;
constexpr int kNumCountV2 = 32, kNumCountV3 = 40;
enum : int { nF0 = 0, nTune = 1, nScoop = 2, nVibHz = 3, nVibCents = 4, nLife = 5, nAttack = 7, nRelease = 11, nUnison = 32 };

inline std::uint16_t u16(const std::uint8_t* p) noexcept { return static_cast<std::uint16_t>(p[0] | (p[1] << 8)); }
inline std::uint32_t u32(const std::uint8_t* p) noexcept { return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) | (static_cast<std::uint32_t>(p[2]) << 16) | (static_cast<std::uint32_t>(p[3]) << 24); }
inline float f32(const std::uint8_t* p) noexcept { const std::uint32_t x = u32(p); float f; std::memcpy(&f, &x, 4); return f; }
inline double trackDb(std::uint8_t q) noexcept { return harmTrackDb(q); }
inline double dbOf(double a) noexcept { return 20.0 * std::log10(std::max(a, 1e-10)); }

// the tone curve from the harmonics of the steady part: between two harmonics the curve is straight in dB over log frequency;
// a band below the first harmonic or above the last has no information (-120)
void toneFromHarmonics(const std::vector<double>& ampLinear, double f0, float* tone) {
    const int H = static_cast<int>(ampLinear.size());
    for (int b = 0; b < kBands; ++b) tone[b] = -120.0F;
    if (H < 1 || f0 <= 0.0) return;
    int last = -1; for (int k = 0; k < H; ++k) if (ampLinear[static_cast<std::size_t>(k)] > 0.0) last = k;
    if (last < 0) return;
    double maxDb = -200.0;
    std::vector<double> db(static_cast<std::size_t>(H), -200.0);
    for (int k = 0; k < H; ++k) if (ampLinear[static_cast<std::size_t>(k)] > 0.0) { db[static_cast<std::size_t>(k)] = dbOf(ampLinear[static_cast<std::size_t>(k)]); maxDb = std::max(maxDb, db[static_cast<std::size_t>(k)]); }
    for (int b = 0; b < kBands; ++b) {
        const double fc = bandHz(b);
        const double kf = fc / f0;   // the harmonic number this band sits at
        if (kf < 0.75 || kf > last + 1.25) continue;
        const double kk = std::min(std::max(kf, 1.0), static_cast<double>(last + 1));
        const int k0 = std::max(1, std::min(last + 1, static_cast<int>(std::floor(kk)))), k1 = std::min(last + 1, k0 + 1);
        const double t = kk - k0;
        double d0 = db[static_cast<std::size_t>(k0 - 1)], d1 = db[static_cast<std::size_t>(k1 - 1)];
        if (d0 < -150.0 && d1 < -150.0) continue;
        if (d0 < -150.0) d0 = d1;
        if (d1 < -150.0) d1 = d0;
        tone[b] = static_cast<float>(std::max(-96.0, (d0 * (1.0 - t) + d1 * t) - maxDb));
    }
}
}  // namespace

float bandHz(int band) noexcept { return 40.0F * std::pow(2.0F, 0.3F * static_cast<float>(std::clamp(band, 0, kBands - 1))); }
float bandOfHz(float hz) noexcept { return std::log2(std::max(hz, 1.0F) / 40.0F) / 0.3F; }

int ModelShape::zoneFor(int key) const noexcept {
    int best = -1, bestDist = 1 << 20;
    for (std::size_t i = 0; i < zones.size(); ++i) {
        const ZoneShape& z = zones[i]; if (!z.ok) continue;
        if (key >= z.lowKey && key <= z.topKey) return static_cast<int>(i);
        const int d = key < z.lowKey ? z.lowKey - key : key - z.topKey;
        if (d < bestDist) { bestDist = d; best = static_cast<int>(i); }
    }
    return best;
}

std::shared_ptr<const LearnedModels> parseLearnedModels(const std::vector<std::uint8_t>& b, const std::string& path) {
    auto out = std::make_shared<LearnedModels>();
    out->path = path;
    const auto fail = [&](const char* why) { out->error = why; out->models.clear(); return std::shared_ptr<const LearnedModels>(out); };
    if (b.size() < 20U) return fail("SILVETON_OSC.sv е празен или отрязан");
    if (std::memcmp(b.data(), "SVOSC001", 8) == 0) return fail("Това е стар файл с вълни (OSCILLATOR LAB), не модели от SILVETON TEACHER");
    int numCount = 0;
    if (std::memcmp(b.data(), "SVOSC003", 8) == 0) numCount = kNumCountV3;
    else if (std::memcmp(b.data(), "SVOSC002", 8) == 0) numCount = kNumCountV2;
    else return fail("Това не е SILVETON_OSC.sv от SILVETON TEACHER");
    std::size_t p = 8;
    const auto need = [&](std::size_t n) { return p + n <= b.size(); };
    if (!need(4)) return fail("SILVETON_OSC.sv е отрязан");
    const std::uint32_t count = u32(&b[p]); p += 4;
    if (count > 4096U) return fail("SILVETON_OSC.sv: невъзможен брой звуци");
    for (std::uint32_t i = 0; i < count; ++i) {
        ModelShape m;
        if (!need(2)) return fail("SILVETON_OSC.sv е отрязан");
        const std::uint16_t nl = u16(&b[p]); p += 2; if (!need(nl)) return fail("SILVETON_OSC.sv е отрязан"); m.name.assign(reinterpret_cast<const char*>(&b[p]), nl); p += nl;
        if (!need(2)) return fail("SILVETON_OSC.sv е отрязан");
        const std::uint16_t sl = u16(&b[p]); p += 2; if (!need(sl)) return fail("SILVETON_OSC.sv е отрязан"); m.slot.assign(reinterpret_cast<const char*>(&b[p]), sl); p += sl;
        if (!need(2)) return fail("SILVETON_OSC.sv е отрязан");
        const std::uint16_t zc = u16(&b[p]); p += 2;
        for (std::uint16_t zi = 0; zi < zc; ++zi) {
            ZoneShape z;
            if (!need(4)) return fail("SILVETON_OSC.sv е отрязан");
            z.lowKey = b[p]; z.topKey = b[p + 1]; z.rootKey = b[p + 2]; const unsigned flags = b[p + 3]; p += 4;
            z.ok = (flags & 1U) != 0U;
            float n[kNumCountV3] = {};
            if (!need(4U * static_cast<std::size_t>(numCount))) return fail("SILVETON_OSC.sv е отрязан");
            for (int k = 0; k < numCount; ++k) { n[k] = f32(&b[p]); p += 4; }
            if (!need(10)) return fail("SILVETON_OSC.sv е отрязан");
            const int H = u16(&b[p]), A = u16(&b[p + 2]), L = u16(&b[p + 4]); p += 6; p += 4;   // frameMs
            if (z.ok) {
                if (L != kTeacherLoopFrames || H < 1 || H > 64 || A > 4096) return fail("SILVETON_OSC.sv: зона с непознат размер");
                const std::size_t rows = static_cast<std::size_t>(A + L);
                if (!need(rows * static_cast<std::size_t>(H) + rows * kTeacherNoiseBands + static_cast<std::size_t>(A))) return fail("SILVETON_OSC.sv е отрязан");
                const std::uint8_t* harm = &b[p]; p += rows * static_cast<std::size_t>(H);
                const std::uint8_t* noise = &b[p]; p += rows * kTeacherNoiseBands;
                const std::int8_t* pitch = reinterpret_cast<const std::int8_t*>(&b[p]); p += static_cast<std::size_t>(A);
                // the numbers
                z.f0Hz = n[nF0]; z.octaveShift = static_cast<int>(std::lround(n[nTune] / 1200.0F));
                z.attackMs = n[nAttack]; z.releaseMs = n[nRelease];
                z.vibratoHz = n[nVibHz]; z.vibratoCents = n[nVibCents]; z.lifeCents = n[nLife];
                z.unisonCents = numCount >= kNumCountV3 ? n[nUnison] : 0.0F;
                // the steady part: the mean of the loop rows
                std::vector<double> amp(static_cast<std::size_t>(H), 0.0);
                double steadyPower = 0.0;
                for (int r = A; r < A + L; ++r) { double pw = 0.0; for (int k = 0; k < H; ++k) { const double a = std::pow(10.0, trackDb(harm[static_cast<std::size_t>(r) * H + k]) / 20.0); amp[static_cast<std::size_t>(k)] += a / L; pw += a * a * 0.5; } steadyPower += pw / L; }
                toneFromHarmonics(amp, z.f0Hz, z.tone);
                z.harmTrack.assign(harm, harm + rows * static_cast<std::size_t>(H)); z.trackRows = A + L; z.attackRows = A; z.trackH = H;   // SILVETON_SYNTH_V1
                { double mx = 0.0; for (const double a : amp) mx = std::max(mx, a);
                  for (int k = 0; k < kHarmonics; ++k) { const double a = k < H ? amp[static_cast<std::size_t>(k)] : 0.0; z.harmDb[k] = (mx > 0.0 && a > mx * 1e-6) ? static_cast<float>(20.0 * std::log10(a / mx)) : -120.0F; } }
                z.pitchDoubt = std::max(z.harmDb[0], std::max(z.harmDb[1], z.harmDb[2])) < -40.0F;   // SILVETON_MODEL_CLEAN_V1: no fundamental = another octave
                z.steadyRms = static_cast<float>(std::sqrt(std::max(steadyPower, 1e-20)));
                // the loudness in time: the attack rows (5 ms) against the steady power, 10 ms a frame
                for (int i2 = 0; i2 < kLevelFrames; ++i2) {
                    const int r0 = i2 * 2, r1 = i2 * 2 + 1;
                    if (r0 >= A) { z.level[i2] = 0.0F; continue; }
                    double pw = 0.0; int m2 = 0;
                    for (int r = r0; r <= std::min(r1, A - 1); ++r) { double rp = 0.0; for (int k = 0; k < H; ++k) { const double a = std::pow(10.0, trackDb(harm[static_cast<std::size_t>(r) * H + k]) / 20.0); rp += a * a * 0.5; } pw += rp; ++m2; }
                    pw /= std::max(1, m2);
                    z.level[i2] = static_cast<float>(std::max(-60.0, std::min(24.0, 10.0 * std::log10((pw + 1e-20) / (steadyPower + 1e-20)))));
                }
                for (int i2 = 0; i2 < kScoopFrames; ++i2) z.scoop[i2] = i2 < A ? static_cast<float>(pitch[i2]) : 0.0F;
                // the breath: eight teacher bands -> four engine bands (0-500 / 500-2k / 2k-8k / 8k+), the steady part and the attack's peak
                for (int eb = 0; eb < kNoiseBands; ++eb) {
                    double steady = 0.0, attackMax = 0.0;
                    for (int tb = eb * 2; tb < eb * 2 + 2; ++tb) {
                        double s = 0.0; for (int r = A; r < A + L; ++r) { const double a = std::pow(10.0, trackDb(noise[static_cast<std::size_t>(r) * kTeacherNoiseBands + tb]) / 20.0); s += a * a / L; }
                        steady += s;
                        double mx = 0.0; for (int r = 0; r < std::min(A, 10); ++r) { const double a = std::pow(10.0, trackDb(noise[static_cast<std::size_t>(r) * kTeacherNoiseBands + tb]) / 20.0); mx = std::max(mx, a * a); }
                        attackMax += mx;
                    }
                    z.breathDb[eb] = static_cast<float>(std::max(-120.0, dbOf(std::sqrt(steady))));
                    z.chiffDb[eb] = static_cast<float>(std::max(-120.0, dbOf(std::sqrt(attackMax))));
                }
            }
            m.zones.push_back(z);
        }
        out->models.push_back(std::move(m));
    }
    if (!need(8) || std::memcmp(&b[p], "SVOSCEND", 8) != 0) return fail("SILVETON_OSC.sv няма краен знак");
    return out;
}

std::shared_ptr<const LearnedModels> loadLearnedModels(const std::string& file) {
    std::ifstream in(file.c_str(), std::ios::binary);
    if (!in) { auto out = std::make_shared<LearnedModels>(); out->path = file; out->error = "няма SILVETON_OSC.sv"; return out; }
    in.seekg(0, std::ios::end); const std::streamoff n = in.tellg(); in.seekg(0, std::ios::beg);
    if (n <= 0 || n > (std::streamoff(1) << 30)) { auto out = std::make_shared<LearnedModels>(); out->path = file; out->error = "SILVETON_OSC.sv е празен или прекалено голям"; return out; }
    std::vector<std::uint8_t> b(static_cast<std::size_t>(n));
    in.read(reinterpret_cast<char*>(b.data()), n);
    if (in.gcount() != n) { auto out = std::make_shared<LearnedModels>(); out->path = file; out->error = "SILVETON_OSC.sv не се чете"; return out; }
    return parseLearnedModels(b, file);
}

} // namespace silveton::sampler::model
