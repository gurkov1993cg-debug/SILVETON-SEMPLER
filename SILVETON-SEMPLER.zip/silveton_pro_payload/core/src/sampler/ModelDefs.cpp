// SILVETON_MODEL_V1 / SILVETON_SYNTH_V1 - the filter page and the knobs of SILVETON SYNTH (see ModelDefs.h).
#include "silveton/sampler/ModelDefs.h"

#include <algorithm>

namespace silveton::sampler::model {

namespace {

using K = EngineKind;
constexpr const char* kNone = "";

// ---- the FILTER page: the common block, on the sound after the model
const EngineParamDef kFilter[] = {
    {E_FILT_TYPE, "FILTER", "Видът на филтъра", K::Choice, 0.0F, 5.0F, 0.0F, 1.0F, 0, "OFF|LADDER 24|KORG35|LP 12|HP 12|BP 12"},
    {E_CUTOFF, "CUTOFF", "Честота на среза Hz", K::Hz, 20.0F, 20000.0F, 20000.0F, 1.0F, 0, kNone},
    {E_RESO, "RESONANCE", "Резонанс %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_KEYTRACK, "KEY TRACK", "Срезът следва клавиша %", K::Pct, -1.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_DRIVE, "DRIVE", "Насищане преди филтъра %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_FEG_AMT, "ENV AMOUNT", "Обвивката на филтъра към среза (октави)", K::Oct, -8.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_FEG_A, "F.ATTACK", "Атака на филтъра ms", K::Ms, 1.0F, 10000.0F, 1.0F, 1.0F, 0, kNone},   // SILVETON_MODEL_START_V1
    {E_FEG_D, "F.DECAY", "Затихване на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_FEG_S, "F.SUSTAIN", "Държане на филтъра %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {E_FEG_R, "F.RELEASE", "Отпускане на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_VEL_CUT, "VEL→CUTOFF", "Силата на удара отваря среза (октави)", K::Oct, 0.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "Вибратото на модела люлее и среза (октави)", K::Oct, 0.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
};

template <std::size_t N>
EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }

}  // namespace

EngineParamPage filterPage() noexcept { return pageOf(kFilter); }

void setDefaults(float* p) noexcept {
    for (int i = 0; i < kEngineParamCountLegacy; ++i) p[i] = 0.0F;
    const EngineParamPage page_ = filterPage();
    for (int i = 0; i < page_.count; ++i) p[page_.items[i].id] = page_.items[i].def;
    p[E_F2_TYPE] = 0.0F; p[E_F2_CUT] = 1000.0F; p[E_F2_RES] = 0.0F; p[E_F2_PAR] = 0.0F;
    p[E_LFO_RATE] = 5.0F; p[E_LFO_PITCH] = 0.0F; p[E_LFO_AMP] = 0.0F; p[E_LFO_WAVE] = 0.0F;
    p[E_UNISON] = 1.0F; p[E_UNI_DET] = 0.0F; p[E_UNI_SPREAD] = 0.0F; p[E_ANALOG] = 0.0F;
    p[E_SOURCE] = static_cast<float>(E_SRC_SAMPLE);   // the recording is the sound, always
    p[E_BYPASS] = 0.0F;
    p[E_BEND_UP] = 0.0F; p[E_BEND_DOWN] = 0.0F;        // as the part's own PITCH BEND
}

} // namespace silveton::sampler::model

// ---------------------------------------------------------------- SILVETON_SYNTH_V1
namespace silveton::sampler::synth {
namespace {
using K = EngineKind;
constexpr const char* kNone = "";
constexpr const char* kModelNames = "NONE|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32";
const EngineParamDef kSynth[] = {
    {SY_MODEL, "MODEL", "Кой научен модел се свири (пресметнат, без запис)", K::Choice, 0.0F, static_cast<float>(model::kMaxModels), 0.0F, 1.0F, 0, kModelNames},
    // SILVETON_SYNTH_TUNE_V1: the FORMANT SHIFT is gone from the engine - TUNE of the place does it (SamplerEngine.cpp synthTuneKeys). The id
    // stays so that every saved blend and SET keeps its numbers; nothing reads it any more and the screen does not show it.
    {SY_SHIFT, "(не се ползва)", "Старият FORMANT SHIFT - сега го прави TUNE на семплера", K::Semis, -12.0F, 12.0F, 0.0F, 1.0F, 0, kNone},
    {SY_BRIGHT, "BRIGHT", "Яркост (dB на октава)", K::Lin, -6.0F, 6.0F, 0.0F, 0.25F, 2, kNone},
    {SY_HARMONICS, "HARMONICS", "Колко хармоника се пресмятат (по-малко = по-тъмно и по-леко за процесора)", K::Lin, 4.0F, 48.0F, 48.0F, 1.0F, 0, kNone},
    {SY_SHAPE, "SHAPE", "Колко атаката на хармониците следва наученото %", K::Pct, 0.0F, 2.0F, 0.0F, 0.01F, 0, kNone},
    {SY_SCOOP, "SCOOP", "Атаката на височината като в наученото %", K::Pct, 0.0F, 2.0F, 0.23F, 0.01F, 0, kNone},
    {SY_UNISON, "UNISON", "Унисонът на модела (разстроени копия) %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {SY_LIFE, "LIFE", "Трептенето на модела %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {SY_VIBRATO, "VIBRATO", "Вибратото, което моделът имаше в записа %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
};
template <std::size_t N>
EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }
}  // namespace
const char* pageName(int page) noexcept { return page == 0 ? "ВРЪТКИ" : "FILTER"; }
EngineParamPage page(int p) noexcept { return p == 0 ? pageOf(kSynth) : (p == 1 ? model::filterPage() : EngineParamPage{nullptr, 0}); }
void setDefaults(float* p) noexcept {
    model::setDefaults(p);   // the filter, the common part, the row's shape - the same
    const EngineParamPage pg = page(0);
    for (int i = 0; i < pg.count; ++i) p[pg.items[i].id] = pg.items[i].def;
    p[model::MO_AMOUNT] = 1.0F;
}
} // namespace silveton::sampler::synth
