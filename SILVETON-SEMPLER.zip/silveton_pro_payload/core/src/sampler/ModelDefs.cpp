// SILVETON_MODEL_V1 - the knobs and pages of SILVETON MODEL (see ModelDefs.h).
#include "silveton/sampler/ModelDefs.h"

#include <algorithm>

namespace silveton::sampler::model {

namespace {

using K = EngineKind;
constexpr const char* kNone = "";
constexpr const char* kModelNames = "NONE|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32";

// ---- page 0 MODEL: which model, how much, and the learned parts one by one (0 % / 0 dB = as the model learned it)
const EngineParamDef kModel[] = {
    {MO_MODEL, "MODEL", "Кой вграден или потребителски модел се прилага върху звука от банката", K::Choice, 0.0F, static_cast<float>(kMaxModels), 0.0F, 1.0F, 0, kModelNames},
    {MO_AMOUNT, "AMOUNT", "Колко далеч от себе си към модела отива блендата %", K::Pct, 0.0F, 1.0F, 1.0F, 0.01F, 0, kNone},
    {MO_TUNE, "TUNE", "Само тембърът се мести, тонът не мърда: записът на друг клавиш, свирен на същия тон (полутонове)", K::Semis, -12.0F, 12.0F, 0.0F, 1.0F, 0, kNone},
    {MO_BRIGHT, "BRIGHT", "Яркост върху модела (dB на октава)", K::Lin, -6.0F, 6.0F, 0.0F, 0.25F, 2, kNone},
    {MO_FORMANT, "FORMANT", "Колко силно формантите на модела се натискат върху блендата %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {MO_SHAPE, "SHAPE", "Колко силата във времето следва модела (плък / надуване) %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {MO_SCOOP, "SCOOP", "Атаката на височината като на модела (откъде тръгва тонът) %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {MO_CHIFF, "CHIFF", "Щракът / дъхът в атаката спрямо модела (dB)", K::Lin, -24.0F, 12.0F, 0.0F, 1.0F, 0, kNone},
    {MO_BREATH, "BREATH", "Дъхът спрямо модела (dB)", K::Lin, -24.0F, 12.0F, 0.0F, 1.0F, 0, kNone},
    {MO_UNISON, "UNISON", "Унисонът на модела (разстроени копия на самата бленда) %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {MO_LIFE, "LIFE", "Трептенето на модела %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
    {MO_VIBRATO, "VIBRATO", "Вибратото, което моделът имаше в записа %", K::Pct, 0.0F, 2.0F, 1.0F, 0.01F, 0, kNone},
};
// ---- page 1 FILTER: the common block, on the sound after the model
const EngineParamDef kFilter[] = {
    {E_FILT_TYPE, "FILTER", "Видът на филтъра", K::Choice, 0.0F, 5.0F, 0.0F, 1.0F, 0, "OFF|LADDER 24|KORG35|LP 12|HP 12|BP 12"},
    {E_CUTOFF, "CUTOFF", "Честота на среза Hz", K::Hz, 20.0F, 20000.0F, 20000.0F, 1.0F, 0, kNone},
    {E_RESO, "RESONANCE", "Резонанс %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_KEYTRACK, "KEY TRACK", "Срезът следва клавиша %", K::Pct, -1.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_DRIVE, "DRIVE", "Насищане преди филтъра %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {E_FEG_AMT, "ENV AMOUNT", "Обвивката на филтъра към среза (октави)", K::Oct, -8.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_FEG_A, "F.ATTACK", "Атака на филтъра ms", K::Ms, 1.0F, 10000.0F, 3.0F, 1.0F, 0, kNone},
    {E_FEG_D, "F.DECAY", "Затихване на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_FEG_S, "F.SUSTAIN", "Държане на филтъра %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {E_FEG_R, "F.RELEASE", "Отпускане на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_VEL_CUT, "VEL→CUTOFF", "Силата на удара отваря среза (октави)", K::Oct, 0.0F, 8.0F, 0.0F, 0.05F, 2, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "Вибратото на модела люлее и среза (октави)", K::Oct, 0.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
};

template <std::size_t N>
EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }

}  // namespace

const char* pageName(int page) noexcept { return page == 0 ? "MODEL" : "FILTER"; }
EngineParamPage page(int p) noexcept { return p == 0 ? pageOf(kModel) : (p == 1 ? pageOf(kFilter) : EngineParamPage{nullptr, 0}); }
int firstRow(int page) noexcept { return page == 0 ? 6 : 6; }

void setDefaults(float* p) noexcept {
    for (int i = 0; i < kEngineParamCountLegacy; ++i) p[i] = 0.0F;
    for (int pg = 0; pg < kPages; ++pg) {
        const EngineParamPage page_ = page(pg);
        for (int i = 0; i < page_.count; ++i) p[page_.items[i].id] = page_.items[i].def;
    }
    p[E_F2_TYPE] = 0.0F; p[E_F2_CUT] = 1000.0F; p[E_F2_RES] = 0.0F; p[E_F2_PAR] = 0.0F;
    p[E_LFO_RATE] = 5.0F; p[E_LFO_PITCH] = 0.0F; p[E_LFO_AMP] = 0.0F; p[E_LFO_WAVE] = 0.0F;
    p[E_UNISON] = 1.0F; p[E_UNI_DET] = 0.0F; p[E_UNI_SPREAD] = 0.0F; p[E_ANALOG] = 0.0F;
    p[E_SOURCE] = static_cast<float>(E_SRC_SAMPLE);   // the recording is the sound, always
    p[E_BYPASS] = 0.0F;
    p[E_BEND_UP] = 0.0F; p[E_BEND_DOWN] = 0.0F;        // as the part's own PITCH BEND
}

} // namespace silveton::sampler::model
