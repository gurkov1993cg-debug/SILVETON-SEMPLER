// SILVETON_MODEL_V1 / SILVETON_SYNTH_V1 - the filter pieces of the learned-model notes (see ModelVoice.h). Our own calculation throughout.
#include "ModelVoice.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler::model {

namespace {
constexpr double kTwoPi = 6.283185307179586;
inline float clampf(float x, float lo, float hi) noexcept { return x < lo ? lo : (x > hi ? hi : x); }
inline float flush(float x) noexcept { return std::fabs(x) < 1.0e-20F ? 0.0F : x; }
inline float tanhF(float x) noexcept {
    if (x > 3.0F) return 1.0F;
    if (x < -3.0F) return -1.0F;
    const float x2 = x * x;
    return x * (27.0F + x2) / (27.0F + 9.0F * x2);
}
inline float coefFor(float ms, double sr, float divisor) noexcept {
    const double tau = std::max(static_cast<double>(ms), 0.05) / 1000.0 / static_cast<double>(divisor);
    return static_cast<float>(1.0 - std::exp(-1.0 / (tau * sr)));
}
}  // namespace

void Env::setTimes(float aMs, float dMs, float s01, float rMs, double sr) noexcept {
    aCoef = coefFor(aMs, sr, 1.79F); dCoef = coefFor(dMs, sr, 3.0F); rCoef = coefFor(rMs, sr, 3.0F); sus = clampf(s01, 0.0F, 1.0F);
}
float Env::tick() noexcept {
    switch (stage) {
        case Attack: level += (1.2F - level) * aCoef; if (level >= 1.0F) { level = 1.0F; stage = Decay; } break;
        case Decay: level += (sus - level) * dCoef; if (std::fabs(level - sus) < 1.0e-4F) { level = sus; stage = Sustain; } break;
        case Sustain: level = sus; break;
        case Release: level += (0.0F - level) * rCoef; if (level < 2.0e-3F) { level = 0.0F; stage = Done; } break;
        default: level = 0.0F; break;
    }
    return level;
}

void Ladder::set(float hz, float res, double sr) noexcept {
    hz = clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F);
    g = 1.0F - std::exp(-static_cast<float>(kTwoPi) * hz / static_cast<float>(sr));
    k = 3.95F * clampf(res, 0.0F, 1.0F);
}
float Ladder::run(float x, float drive) noexcept {
    const float in = tanhF((x - k * s[3]) * (1.0F + drive * 3.0F));
    s[0] = flush(s[0] + g * (in - tanhF(s[0])));
    s[1] = flush(s[1] + g * (tanhF(s[0]) - tanhF(s[1])));
    s[2] = flush(s[2] + g * (tanhF(s[1]) - tanhF(s[2])));
    s[3] = flush(s[3] + g * (tanhF(s[2]) - tanhF(s[3])));
    return s[3] * (1.0F + k);   // the ladder loses its passband with the feedback: given back (the knobs never make the note quieter)
}
void Korg35::set(float hz, float res, double sr) noexcept {
    const double rate = std::max(1.0, sr);
    const double fc = std::clamp(static_cast<double>(hz), 20.0, rate * 0.45);
    const double warped = std::tan(kTwoPi * 0.5 * fc / rate);
    g = static_cast<float>(warped / (1.0 + warped));
    k = 1.97F * clampf(res, 0.0F, 1.0F);
}
float Korg35::run(float x) noexcept {
    const float v1 = (x - s1) * g;
    const float u = v1 + s1;
    s1 = flush(u + v1);
    const float g1 = 1.0F - g;
    const float denominator = std::max(1.0F - g * k * g1, 0.05F);
    float y = (g * u - g * k * g1 * s3 + g1 * s2) / denominator;
    // Use the same bounded saturation approximation as this filter module.
    // The surrounding drive and this feedback nonlinearity both run at 4x.
    y = tanhF(y * 0.8F) * 1.25F;
    const float in2 = u + k * g1 * (y - s3);
    const float v2 = (in2 - s2) * g;
    const float out = v2 + s2;
    s2 = flush(out + v2);
    const float v3 = (y - s3) * g;
    s3 = flush(s3 + 2.0F * v3);
    return out;
}
void Svf::set(float hz, float res, double sr) noexcept {
    hz = clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F);
    const float gg = std::tan(static_cast<float>(kTwoPi * 0.5) * hz / static_cast<float>(sr));
    k = 1.0F / std::max(0.5F + res * res * 19.5F, 0.3F);
    a1 = 1.0F / (1.0F + gg * (gg + k)); a2 = gg * a1; a3 = gg * a2;
}
float Svf::run(float x, int type) noexcept {
    const float v3 = x - ic2;
    const float v1 = a1 * ic1 + a2 * v3;
    const float v2 = ic2 + a2 * ic1 + a3 * v3;
    ic1 = flush(2.0F * v1 - ic1); ic2 = flush(2.0F * v2 - ic2);
    const float bp = v1, hp = x - k * v1 - v2;
    switch (type) { case 4: return hp; case 5: return bp * k; default: return v2; }
}

} // namespace silveton::sampler::model
