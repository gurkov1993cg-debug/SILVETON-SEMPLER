// SILVETON_MODEL_V1 - the note of SILVETON MODEL (see ModelVoice.h). Our own calculation throughout.
#include "ModelVoice.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler::model {

namespace {
constexpr double kTwoPi = 6.283185307179586;
inline float clampf(float x, float lo, float hi) noexcept { return x < lo ? lo : (x > hi ? hi : x); }
inline float flush(float x) noexcept { return std::fabs(x) < 1.0e-20F ? 0.0F : x; }
inline float tanhF(float x) noexcept {
    if (x > 3.0F) return 1.0F;
    if (x < -3.0F) return -1.0F;
    const float x2 = x * x;
    return x * (27.0F + x2) / (27.0F + 9.0F * x2);
}
inline float dbToGain(float db) noexcept { return std::pow(10.0F, db / 20.0F); }
inline std::uint32_t lcg(std::uint32_t& s) noexcept { s = s * 1664525U + 1013904223U; return s; }
inline float noiseOf(std::uint32_t& s) noexcept { return static_cast<float>(lcg(s) >> 8) / 8388608.0F - 1.0F; }
inline float coefFor(float ms, double sr, float divisor) noexcept {
    const double tau = std::max(static_cast<double>(ms), 0.05) / 1000.0 / static_cast<double>(divisor);
    return static_cast<float>(1.0 - std::exp(-1.0 / (tau * sr)));
}
// the tone curve of a shape at a frequency (dB against its strongest band); -120 = no information there
inline float toneAt(const ZoneShape& z, float hz) noexcept {
    const float b = bandOfHz(hz);
    if (b <= 0.0F) return z.tone[0];
    if (b >= static_cast<float>(kBands - 1)) return z.tone[kBands - 1];
    const int i = static_cast<int>(b); const float f = b - static_cast<float>(i);
    const float a = z.tone[i], c = z.tone[i + 1];
    if (a < -100.0F || c < -100.0F) return f < 0.5F ? a : c;
    return a + (c - a) * f;
}
inline float levelAt(const ZoneShape& z, double tSec) noexcept {
    const double fr = tSec * 1000.0 / kLevelFrameMs;
    if (fr >= kLevelFrames - 1) return 0.0F;
    const int i = static_cast<int>(fr); const float f = static_cast<float>(fr - i);
    return z.level[i] + (z.level[i + 1] - z.level[i]) * f;
}
inline float scoopAt(const ZoneShape& z, double tSec) noexcept {
    const double fr = tSec * 1000.0 / kScoopFrameMs;
    if (fr >= kScoopFrames - 1) return 0.0F;
    const int i = static_cast<int>(fr); const float f = static_cast<float>(fr - i);
    return z.scoop[i] + (z.scoop[i + 1] - z.scoop[i]) * f;
}
constexpr float kDiffMaxDb = 18.0F;   // SILVETON_MODEL_CLEAN_V1: how far the model may move one band of the blend (more lifts noise and aliasing: nasty)
constexpr float kBandMaxDb = 24.0F;   // one EQ band, BRIGHT included
constexpr float kEqStepDb = 0.35F;    // a band's largest move in one chunk of 32 samples while the note sounds
constexpr float kEqQ = 1.2F;   // bands 0.55 octave apart, wide enough to add up to a smooth curve (a narrow Q rippled by several dB between them)
inline float eqHzOf(int band, double sr) noexcept { return std::min(60.0F * std::pow(2.0F, 0.55F * static_cast<float>(band)), static_cast<float>(sr) * 0.45F); }
constexpr float kNoiseLo[kNoiseBands] = {60.0F, 500.0F, 2000.0F, 8000.0F};
constexpr float kNoiseHi[kNoiseBands] = {500.0F, 2000.0F, 8000.0F, 16000.0F};

// The levelling: how much a change (the EQ, the filter) has to be scaled so the blend's power after it equals the power before it.
// The blend's power lies at its harmonics (the tone curve read at the recording's own harmonics, played at this note's pitch), so the
// change's power response is weighed there; a blend without a clear pitch is weighed by its smooth curve at the band centres.
// `resp(hz)` = the change's power response at hz.
template <class Resp>
float levelAgainst(const ZoneShape* bz, int key, double sr, const Resp& resp) noexcept {
    double all = 0.0, after = 0.0;
    const double top = sr * 0.45;
    if (bz != nullptr && bz->ok && bz->f0Hz > 20.0F) {
        const double noteHz = static_cast<double>(bz->f0Hz) * std::exp2(static_cast<double>(key - bz->rootKey) / 12.0);
        for (int k = 1; k <= kHarmonics; ++k) {
            const double fp = noteHz * k;
            if (fp > top) break;
            const float t = bz->harmDb[k - 1];
            if (t < -100.0F) continue;
            const double w = std::pow(10.0, std::max(-60.0F, t) / 10.0);
            all += w; after += w * resp(fp);
        }
    } else {
        for (int b = 0; b < kBands; ++b) {
            const double hz = bandHz(b);
            if (hz > top) break;
            const double w = (bz != nullptr && bz->ok) ? std::pow(10.0, std::max(-60.0F, bz->tone[b]) / 10.0) : (hz < 4000.0 ? 1.0 : 0.3);
            all += w; after += w * resp(hz);
        }
    }
    if (all <= 0.0 || after <= 0.0) return 1.0F;
    return static_cast<float>(std::clamp(std::sqrt(all / after), 0.05, 20.0));
}
}  // namespace

// ---------------------------------------------------------------- the pieces
void Biquad::peaking(float hz, float q, float gainDb, double sr) noexcept {
    const float A = std::pow(10.0F, gainDb / 40.0F);
    const float w0 = static_cast<float>(kTwoPi) * clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F) / static_cast<float>(sr);
    const float al = std::sin(w0) / (2.0F * q), cw = std::cos(w0);
    const float a0 = 1.0F + al / A;
    b0 = (1.0F + al * A) / a0; b1 = -2.0F * cw / a0; b2 = (1.0F - al * A) / a0; a1 = -2.0F * cw / a0; a2 = (1.0F - al / A) / a0;
}
void Biquad::bandpass(float hz, float q, double sr) noexcept {
    const float w0 = static_cast<float>(kTwoPi) * clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F) / static_cast<float>(sr);
    const float al = std::sin(w0) / (2.0F * q), cw = std::cos(w0);
    const float a0 = 1.0F + al;
    b0 = al / a0; b1 = 0.0F; b2 = -al / a0; a1 = -2.0F * cw / a0; a2 = (1.0F - al) / a0;
}

void Env::setTimes(float aMs, float dMs, float s01, float rMs, double sr) noexcept {
    aCoef = coefFor(aMs, sr, 1.79F); dCoef = coefFor(dMs, sr, 3.0F); rCoef = coefFor(rMs, sr, 3.0F); sus = clampf(s01, 0.0F, 1.0F);
}
float Env::tick() noexcept {
    switch (stage) {
        case Attack: level += (1.2F - level) * aCoef; if (level >= 1.0F) { level = 1.0F; stage = Decay; } break;
        case Decay: level += (sus - level) * dCoef; if (std::fabs(level - sus) < 1.0e-4F) { level = sus; stage = Sustain; } break;
        case Sustain: level = sus; break;
        case Release: level += (0.0F - level) * rCoef; if (level < 2.0e-3F) { level = 0.0F; stage = Done; } break;
        default: level = 0.0F; break;
    }
    return level;
}

void Ladder::set(float hz, float res, double sr) noexcept {
    hz = clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F);
    g = 1.0F - std::exp(-static_cast<float>(kTwoPi) * hz / static_cast<float>(sr));
    k = 3.95F * clampf(res, 0.0F, 1.0F);
}
float Ladder::run(float x, float drive) noexcept {
    const float in = tanhF((x - k * s[3]) * (1.0F + drive * 3.0F));
    s[0] = flush(s[0] + g * (in - tanhF(s[0])));
    s[1] = flush(s[1] + g * (tanhF(s[0]) - tanhF(s[1])));
    s[2] = flush(s[2] + g * (tanhF(s[1]) - tanhF(s[2])));
    s[3] = flush(s[3] + g * (tanhF(s[2]) - tanhF(s[3])));
    return s[3] * (1.0F + k);   // the ladder loses its passband with the feedback: given back (the knobs never make the note quieter)
}
void Svf::set(float hz, float res, double sr) noexcept {
    hz = clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F);
    const float gg = std::tan(static_cast<float>(kTwoPi * 0.5) * hz / static_cast<float>(sr));
    k = 1.0F / std::max(0.5F + res * res * 19.5F, 0.3F);
    a1 = 1.0F / (1.0F + gg * (gg + k)); a2 = gg * a1; a3 = gg * a2;
}
float Svf::run(float x, int type) noexcept {
    const float v3 = x - ic2;
    const float v1 = a1 * ic1 + a2 * v3;
    const float v2 = ic2 + a2 * ic1 + a3 * v3;
    ic1 = flush(2.0F * v1 - ic1); ic2 = flush(2.0F * v2 - ic2);
    const float bp = v1, hp = x - k * v1 - v2;
    switch (type) { case 4: return hp; case 5: return bp * k; default: return v2; }
}

// ---------------------------------------------------------------- the note
void Voice::noteOn(const float* params, double sampleRate, const Inputs& in, const ZoneShape* modelZone, const ZoneShape* blendZone, std::uint32_t seed) noexcept {
    p_ = params; sr_ = sampleRate; in_ = in; key_ = in.key; mz_ = modelZone; bz_ = blendZone;
    rng_ = seed | 1U; pos_ = kChunk; t_ = 0.0; pitchSemis_ = 0.0; peak_ = 0.0F; needControl_ = true;
    for (int b = 0; b < kEq; ++b) { eq_[static_cast<std::size_t>(b)] = Biquad(); eqHz_[b] = eqHzOf(b, sr_); eqNow_[static_cast<std::size_t>(b)] = eqTarget_[static_cast<std::size_t>(b)] = 0.0F; eq_[static_cast<std::size_t>(b)].peaking(eqHz_[b], kEqQ, 0.0F, sr_); }
    for (int b = 0; b < kEq; ++b) {
        const double w = kTwoPi * static_cast<double>(eqHz_[b]) / sr_;
        eqC1_[b] = static_cast<float>(std::cos(w)); eqS1_[b] = static_cast<float>(std::sin(w));
        eqC2_[b] = static_cast<float>(std::cos(2.0 * w)); eqS2_[b] = static_cast<float>(std::sin(2.0 * w));
    }
    eqLevel_ = 1.0F;
    shapeNow_ = shapeTarget_ = 0.0F; gainNow_ = 1.0F; gainTick_ = 0.0F;
    for (int b = 0; b < kNoiseBands; ++b) {
        nz_[static_cast<std::size_t>(b)] = Biquad();
        const float lo = kNoiseLo[b], hi = std::min(kNoiseHi[b], static_cast<float>(sr_) * 0.45F);
        const float c = std::sqrt(lo * hi);
        nz_[static_cast<std::size_t>(b)].bandpass(c, c / std::max(hi - lo, 10.0F), sr_);
        // a band-pass fed with white noise (RMS 1/sqrt 3) gives about sqrt(bandwidth / (sr / 2)) of it: the gain that makes its RMS 1
        nzGain_[b] = 1.0F / std::max(0.02F, 0.5774F * std::sqrt((hi - lo) / static_cast<float>(sr_ * 0.5)) * 1.11F);
        breathRms_[b] = chiffRms_[b] = breathNow_[b] = 0.0F;
    }
    for (int i = 0; i < kUniLen; ++i) { uniL_[i] = uniR_[i] = 0.0F; }
    uniW_ = 0; uniPh1_ = 0.0; uniPh2_ = 0.37; uniAmt_ = uniDepth_ = uniAmtWant_ = uniDepthWant_ = 0.0F;
    lifeState_ = 0.0; lifeCentsRms_ = 0.0F; vibPh_ = 0.0;
    filtEnv_ = Env{}; filtEnv_.trigger(); ladderL_.reset(); ladderR_.reset(); svfL_.reset(); svfR_.reset();
    filtType_ = 0; cutHz_ = -1.0F; res_ = clampf(p_[E_RESO], 0.0F, 1.0F); drive_ = 0.0F; filtGain_ = 1.0F;
    control();   // the first chunk starts where the model says (its quiet start, its scoop, its tone) - nothing ramps in from the plain recording
    pos_ = 0;
}

void Voice::setInputs(const Inputs& in, double sampleRate) noexcept {
    sr_ = sampleRate;
    const bool wasGate = in_.gate;
    in_ = in;
    if (wasGate && !in.gate) filtEnv_.release();
    if (in.gate && in.key != key_) key_ = in.key;
}

// what the filter takes from the blend's own tone, so it can be given back (the power above the cutoff, at the blend's harmonics)
float Voice::gainOfFilter() const noexcept {
    if (filtType_ == 0 || bz_ == nullptr || !bz_->ok) return 1.0F;
    const int type = filtType_; const double cut = std::max(20.0F, cutHz_);
    const float g = levelAgainst(bz_, key_, sr_, [type, cut](double hz) noexcept {
        const double r = hz / cut;   // the filter's power response, roughly
        if (type == 4) return 1.0 / (1.0 + std::pow(1.0 / std::max(r, 1e-6), 4.0));            // HP 12
        if (type == 5) { const double lr = std::log2(std::max(r, 1e-6)); return 1.0 / (1.0 + lr * lr * 4.0); }   // BP 12
        return 1.0 / (1.0 + std::pow(r, type == 1 ? 8.0 : 4.0));                                  // LP 24 / LP 12
    });
    return std::min(g, 4.0F);   // at most +12 dB back
}

void Voice::control() noexcept {
    const float* p = p_;
    const float chunkSec = static_cast<float>(kChunk) / static_cast<float>(sr_);
    const float amt = amount(p);
    const bool model = mz_ != nullptr && mz_->ok && amt > 0.0F;
    const bool blend = bz_ != nullptr && bz_->ok;
    // SILVETON_MODEL_CLEAN_V1: a zone learned in another octave (no fundamental in its harmonics) lends no tone - a comb over the
    // blend is never "the model", it is only nasty. Its attack, breath and movement are still used.
    const bool modelTone = model && !mz_->pitchDoubt;
    // ---- the tone: the model's curve against the blend's, BRIGHT; levelled to 0 dB by the blend's own power
    {
        const float formantK = clampf(p[MO_FORMANT], 0.0F, 2.0F) * amt;
        const float bright = clampf(p[MO_BRIGHT], -6.0F, 6.0F);
        float diff[kEq]; bool known[kEq];
        for (int b = 0; b < kEq; ++b) {
            const float hz = eqHz_[b];
            diff[b] = 0.0F; known[b] = false;
            if (modelTone && blend) {
                const float m = toneAt(*mz_, hz), s = toneAt(*bz_, hz);
                if (m > -100.0F && s > -100.0F) { diff[b] = clampf(m - s, -kDiffMaxDb, kDiffMaxDb) * formantK; known[b] = true; }
            } else if (modelTone) {
                const float m = toneAt(*mz_, hz);
                if (m > -100.0F) { diff[b] = clampf(m + 6.0F * std::log2(hz / 1000.0F), -kDiffMaxDb, kDiffMaxDb) * formantK * 0.5F; known[b] = true; }   // without the blend's own curve: a saw-like one is assumed
            }
        }
        // where one of the two has no information (above its last harmonic, below its first) the nearest known difference holds on -
        // a jump to "no change" there would make the bands between ring
        for (int b = 1; b < kEq; ++b) if (!known[b] && known[b - 1]) { diff[b] = diff[b - 1]; known[b] = true; }
        for (int b = kEq - 2; b >= 0; --b) if (!known[b] && known[b + 1]) { diff[b] = diff[b + 1]; known[b] = true; }
        for (int b = 0; b < kEq; ++b) eqTarget_[static_cast<std::size_t>(b)] = clampf(bright * std::log2(eqHz_[b] / 1000.0F) + diff[b], -kBandMaxDb, kBandMaxDb);
        // the bands overlap, so the curve they make together is solved, not set band by band: the response of all of them is read at
        // every centre and each band steps towards what is missing there (a note start takes several steps at once, a knob one a chunk)
        bool moved = false;
        for (int it = 0, iters = needControl_ ? 6 : 1; it < iters; ++it) {
            bool any = false;
            float real[kEq];
            for (int e = 0; e < kEq; ++e) {
                double h = 1.0;
                for (int k = 0; k < kEq; ++k) if (eqNow_[static_cast<std::size_t>(k)] != 0.0F) h *= eq_[static_cast<std::size_t>(k)].powerAt(eqC1_[e], eqS1_[e], eqC2_[e], eqS2_[e]);
                real[e] = static_cast<float>(10.0 * std::log10(std::max(h, 1.0e-12)));
            }
            for (int e = 0; e < kEq; ++e) {
                const float err = eqTarget_[static_cast<std::size_t>(e)] - real[e];
                if (std::fabs(err) < 0.03F) continue;
                float& now = eqNow_[static_cast<std::size_t>(e)];
                // SILVETON_MODEL_CLEAN_V1: during the note a band moves at most kEqStepDb a chunk (about 1 dB a millisecond at 96 kHz):
                // a knob turned fast, a model changed mid-note, AMOUNT switched - the tone glides, the filters never jump (no click)
                const float step = needControl_ ? err * 0.5F : clampf(err * 0.5F, -kEqStepDb, kEqStepDb);
                now = clampf(now + step, -kBandMaxDb, kBandMaxDb);
                eq_[static_cast<std::size_t>(e)].peaking(eqHz_[e], kEqQ, now, sr_);
                any = true;
            }
            if (!any) break;
            moved = true;
        }
        // the levelling: the blend's power through the EQ as it stands now = the blend's power before it (the power domain, by the
        // realised response of all the bands together - a tilt or a formant never makes the note quieter or louder as a whole)
        if (moved) {
            const double sr = sr_;
            eqLevel_ = std::min(4.0F, levelAgainst(bz_, key_, sr_, [this, sr](double hz) noexcept {
                const double w = kTwoPi * hz / sr;
                const float c1 = static_cast<float>(std::cos(w)), s1 = static_cast<float>(std::sin(w));
                const float c2 = 2.0F * c1 * c1 - 1.0F, s2 = 2.0F * s1 * c1;
                double h = 1.0;
                for (int e = 0; e < kEq; ++e) if (eqNow_[static_cast<std::size_t>(e)] != 0.0F) h *= eq_[static_cast<std::size_t>(e)].powerAt(c1, s1, c2, s2);
                return h;
            }));   // at most +12 dB back: a tone that cuts nearly everything must not pull the rest (and the noise floor) up without end
        }
    }
    // ---- the loudness in time: the model's curve against the blend's
    {
        float target = 0.0F;
        if (model) {
            const float shapeK = clampf(p[MO_SHAPE], 0.0F, 2.0F) * amt;
            target = levelAt(*mz_, t_) - (blend ? levelAt(*bz_, t_) : 0.0F);
            target = clampf(target * shapeK, -30.0F, 18.0F);
        }
        shapeTarget_ = target;
        const float gNext = dbToGain(shapeTarget_) * eqLevel_;
        if (needControl_) { gainNow_ = gNext; gainTick_ = 0.0F; }
        else gainTick_ = (gNext - gainNow_) / static_cast<float>(kChunk);
    }
    // ---- the pitch: the scoop of the attack, the life, the vibrato of the model
    {
        double semis = 0.0;
        if (model) {
            semis += static_cast<double>(scoopAt(*mz_, t_) * clampf(p[MO_SCOOP], 0.0F, 2.0F) * amt) / 100.0;
            lifeCentsRms_ = mz_->lifeCents * clampf(p[MO_LIFE], 0.0F, 2.0F) * amt;
            const float vibK = clampf(p[MO_VIBRATO], 0.0F, 2.0F) * amt;
            if (mz_->vibratoCents > 0.0F && vibK > 0.0F) {
                vibPh_ += kTwoPi * static_cast<double>(mz_->vibratoHz) * chunkSec; if (vibPh_ > kTwoPi) vibPh_ -= kTwoPi;
                semis += std::sin(vibPh_) * static_cast<double>(mz_->vibratoCents * vibK) / 100.0;
            }
        } else lifeCentsRms_ = 0.0F;
        if (lifeCentsRms_ > 0.0F) {
            const double c = std::exp(-kTwoPi * 6.0 * chunkSec);
            lifeState_ = lifeState_ * c + static_cast<double>(noiseOf(rng_)) * (1.0 - c);
            const double gain = std::sqrt(3.0 * (1.0 + c) / (1.0 - c));   // unit RMS
            semis += lifeState_ * gain * static_cast<double>(lifeCentsRms_) / 100.0;
        }
        pitchSemis_ = semis;
    }
    // ---- the breath and the chiff: noise shaped like the model's, sized by the blend's own loudness
    {
        const float ref = blend ? bz_->steadyRms : 0.1F;   // the loudness the blend plays at
        for (int b = 0; b < kNoiseBands; ++b) {
            float breath = 0.0F, chiff = 0.0F;
            if (model && mz_->steadyRms > 0.0F) {
                const float scale = ref / mz_->steadyRms * 0.7071F;   // the model's "equivalent sinusoid" -> RMS, at the blend's loudness
                breath = dbToGain(mz_->breathDb[b] + clampf(p[MO_BREATH], -24.0F, 12.0F)) * scale * amt;
                const float extra = mz_->chiffDb[b] - mz_->breathDb[b];
                if (extra > 1.0F) chiff = dbToGain(mz_->chiffDb[b] + clampf(p[MO_CHIFF], -24.0F, 12.0F)) * scale * amt * static_cast<float>(std::exp(-t_ / 0.035));
            }
            breathRms_[b] = std::min(breath, 0.5F); chiffRms_[b] = std::min(chiff, 0.7F);
        }
    }
    // ---- the unison: the blend against itself
    {
        const float u = model ? mz_->unisonCents * clampf(p[MO_UNISON], 0.0F, 2.0F) * amt : 0.0F;
        uniAmtWant_ = u >= 1.0F ? clampf(u / 12.0F, 0.0F, 1.0F) : 0.0F;   // how much of the two moving copies is heard (full at 12 cents)
        // a tap whose delay swings by D at w radians a second moves the pitch by D w: for +- u cents at 0.7 Hz
        uniDepthWant_ = static_cast<float>(static_cast<double>(u) * 0.000577 / (kTwoPi * 0.7) * sr_);   // in samples (0.000577 = ln2 / 1200)
        uniDepthWant_ = std::min(uniDepthWant_, static_cast<float>(kUniLen / 2 - 8));
        // SILVETON_MODEL_CLEAN_V1: the mix and the depth slide towards the knob (about 7 ms) - a tap never jumps, the mix never steps
        if (needControl_) { uniAmt_ = uniAmtWant_; uniDepth_ = uniDepthWant_; }
        else { uniAmt_ += (uniAmtWant_ - uniAmt_) * 0.15F; uniDepth_ += (uniDepthWant_ - uniDepth_) * 0.15F; if (uniAmt_ < 0.002F && uniAmtWant_ <= 0.0F) uniAmt_ = 0.0F; }
    }
    // ---- the filter block
    {
        filtEnv_.setTimes(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], sr_);
        filtType_ = std::clamp(static_cast<int>(p[E_FILT_TYPE] + 0.5F), 0, 5);
        drive_ = clampf(p[E_DRIVE], 0.0F, 1.0F);
        const float fenv = filtEnv_.level;
        float oct = clampf(p[E_KEYTRACK], -1.0F, 1.0F) * static_cast<float>(key_ - 60) / 12.0F + clampf(p[E_FEG_AMT], -8.0F, 8.0F) * fenv +
                    clampf(p[E_VEL_CUT], 0.0F, 8.0F) * clampf(in_.velocity, 0.0F, 1.0F);
        if (model && mz_->vibratoCents > 0.0F) oct += clampf(p[E_LFO_CUT], 0.0F, 4.0F) * static_cast<float>(std::sin(vibPh_));
        const float cutTarget = clampf(clampf(p[E_CUTOFF], 20.0F, 20000.0F) * std::exp2(oct), 20.0F, 20000.0F);
        cutHz_ = cutHz_ <= 0.0F ? cutTarget : std::exp(std::log(cutHz_) + (std::log(cutTarget) - std::log(cutHz_)) * 0.45F);
        res_ += (clampf(p[E_RESO], 0.0F, 1.0F) - res_) * 0.45F;
        if (filtType_ == 1 || filtType_ == 2) { ladderL_.set(cutHz_, res_, sr_); ladderR_.set(cutHz_, res_, sr_); }
        else if (filtType_ >= 3) { svfL_.set(cutHz_, res_, sr_); svfR_.set(cutHz_, res_, sr_); }
        const float gTarget = gainOfFilter();
        filtGain_ = needControl_ ? gTarget : filtGain_ + (gTarget - filtGain_) * 0.3F;
    }
    needControl_ = false;
}

void Voice::tick(float& l, float& r) noexcept {
    if (p_ == nullptr) return;
    if (pos_ >= kChunk) { control(); pos_ = 0; }
    ++pos_;
    t_ += 1.0 / sr_;
    filtEnv_.tick();
    // the tone
    for (int b = 0; b < kEq; ++b) if (eqNow_[static_cast<std::size_t>(b)] != 0.0F) eq_[static_cast<std::size_t>(b)].run(l, r);
    // the breath and the chiff
    const float white = noiseOf(rng_);
    for (int b = 0; b < kNoiseBands; ++b) {
        const float want = breathRms_[b] + chiffRms_[b];
        breathNow_[b] += (want - breathNow_[b]) * 0.002F;
        if (breathNow_[b] > 1.0e-6F) { const float n = nz_[static_cast<std::size_t>(b)].runMono(white) * nzGain_[b] * breathNow_[b]; l += n; r += n; }
    }
    // the unison: two copies of the blend, a little apart in pitch (moving taps), mixed in at equal power
    uniL_[uniW_] = l; uniR_[uniW_] = r;   // (always: the moment the unison comes in, its taps read real sound, not a silence that would dip the level)
    if (uniAmt_ > 0.0F) {
        uniPh1_ += kTwoPi * 0.7 / sr_; if (uniPh1_ > kTwoPi) uniPh1_ -= kTwoPi;
        uniPh2_ += kTwoPi * 0.9 / sr_; if (uniPh2_ > kTwoPi) uniPh2_ -= kTwoPi;
        const double d1 = 8.0 + uniDepth_ * (1.0 + std::sin(uniPh1_)), d2 = 8.0 + uniDepth_ * (1.0 + std::sin(uniPh2_ + 2.1));
        const auto tap = [&](const float* buf, double d) noexcept {
            double rp = static_cast<double>(uniW_) - d; if (rp < 0.0) rp += kUniLen;
            const int i0 = static_cast<int>(rp); const float f = static_cast<float>(rp - i0);
            const int i1 = i0 + 1 >= kUniLen ? 0 : i0 + 1;
            return buf[i0] + (buf[i1] - buf[i0]) * f;
        };
        const float wet = uniAmt_ * 0.5F, dry = std::sqrt(std::max(0.0F, 1.0F - 2.0F * wet * wet));
        l = l * dry + (tap(uniL_, d1) + tap(uniL_, d2)) * wet;
        r = r * dry + (tap(uniR_, d1) + tap(uniR_, d2)) * wet;
    }
    if (++uniW_ >= kUniLen) uniW_ = 0;
    // the loudness in time
    gainNow_ += gainTick_;
    l *= gainNow_; r *= gainNow_;
    // the filter block
    if (filtType_ != 0) {
        if (drive_ > 0.0F) { l = tanhF(l * (1.0F + 4.0F * drive_)) / (1.0F + 1.2F * drive_); r = tanhF(r * (1.0F + 4.0F * drive_)) / (1.0F + 1.2F * drive_); }
        if (filtType_ <= 2) { l = ladderL_.run(l, drive_); r = ladderR_.run(r, drive_); }
        else { l = svfL_.run(l, filtType_); r = svfR_.run(r, filtType_); }
        l *= filtGain_; r *= filtGain_;
    }
    if (!std::isfinite(l) || !std::isfinite(r)) {
        l = r = 0.0F;
        for (auto& e : eq_) e.reset();
        for (auto& n : nz_) n.reset();
        ladderL_.reset(); ladderR_.reset(); svfL_.reset(); svfR_.reset();
        for (int i = 0; i < kUniLen; ++i) { uniL_[i] = uniR_[i] = 0.0F; }
    }
    peak_ = std::max(std::max(std::fabs(l), std::fabs(r)), peak_ * 0.9995F);
}

} // namespace silveton::sampler::model
