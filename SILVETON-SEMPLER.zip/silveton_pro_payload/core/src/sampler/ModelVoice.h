#pragma once
// SILVETON_MODEL_V1 - one note of SILVETON MODEL. It does not make sound: the sampler reads the blend's recording and hands every
// sample to tick(), which sends it back CHANGED towards the model: the tone (16 bands of EQ: the model's tone against the blend's
// own, the special TUNE that moves only the timbre, BRIGHT), the loudness in time (the model's pluck or swell against the blend's),
// the breath and the chiff (noise shaped like the model's), the unison (the blend detuned against itself), and - through
// pitchSemis(), read by the sampler once per block - the scoop of the attack, the life and the vibrato. Then the FILTER block.
// Nothing here makes the note quieter on its own: every change is levelled (the power-weighted mean of the EQ is 0 dB, the loudness
// curve is 0 dB at the steady part, the filter is paid back what it takes).
// Real-time rules: no allocation, no locks; a NaN / Inf starts the voice from silence.
#include "silveton/sampler/ModelBank.h"
#include "silveton/sampler/ModelDefs.h"

#include <array>
#include <cstdint>

namespace silveton::sampler::model {

struct Inputs {
    float velocity{1.0F};   // 0..1
    int key{60};
    bool gate{true};
    float wheel{0.0F};
    float pressure{0.0F};
};

constexpr int kChunk = 32;
constexpr int kEq = 16;

struct Biquad {
    float b0{1.0F}, b1{0.0F}, b2{0.0F}, a1{0.0F}, a2{0.0F};
    float z1L{0.0F}, z2L{0.0F}, z1R{0.0F}, z2R{0.0F};
    void peaking(float hz, float q, float gainDb, double sr) noexcept;
    void bandpass(float hz, float q, double sr) noexcept;
    void run(float& l, float& r) noexcept {
        const float yl = b0 * l + z1L; z1L = b1 * l - a1 * yl + z2L; z2L = b2 * l - a2 * yl; l = yl;
        const float yr = b0 * r + z1R; z1R = b1 * r - a1 * yr + z2R; z2R = b2 * r - a2 * yr; r = yr;
    }
    float runMono(float x) noexcept { const float y = b0 * x + z1L; z1L = b1 * x - a1 * y + z2L; z2L = b2 * x - a2 * y; return y; }
    void reset() noexcept { z1L = z2L = z1R = z2R = 0.0F; }
    // the power response at a frequency given as cos / sin of w and of 2w
    [[nodiscard]] float powerAt(float c1, float s1, float c2, float s2) const noexcept {
        const float br = b0 + b1 * c1 + b2 * c2, bi = -(b1 * s1 + b2 * s2);
        const float ar = 1.0F + a1 * c1 + a2 * c2, ai = -(a1 * s1 + a2 * s2);
        const float den = ar * ar + ai * ai;
        return (br * br + bi * bi) / (den < 1.0e-12F ? 1.0e-12F : den);
    }
};

struct Env {   // ADSR of the filter
    enum Stage : int { Attack = 0, Decay, Sustain, Release, Done };
    int stage{Done};
    float level{0.0F};
    float aCoef{0.1F}, dCoef{0.01F}, rCoef{0.01F}, sus{1.0F};
    void setTimes(float aMs, float dMs, float s01, float rMs, double sr) noexcept;
    void trigger() noexcept { stage = Attack; }
    void release() noexcept { if (stage != Done) stage = Release; }
    float tick() noexcept;
};

struct Ladder {
    float s[4]{0.0F, 0.0F, 0.0F, 0.0F};
    float g{0.1F}, k{0.0F};
    void set(float hz, float res, double sr) noexcept;
    float run(float x, float drive) noexcept;
    void reset() noexcept { s[0] = s[1] = s[2] = s[3] = 0.0F; }
};
struct Svf {
    float ic1{0.0F}, ic2{0.0F};
    float a1{0.0F}, a2{0.0F}, a3{0.0F}, k{1.0F};
    void set(float hz, float res, double sr) noexcept;
    float run(float x, int type) noexcept;   // 3 LP, 4 HP, 5 BP (the common FILTER choice)
    void reset() noexcept { ic1 = ic2 = 0.0F; }
};

class Voice {
public:
    // modelZone: the zone of the chosen model that plays this key (nullptr = no model); blendZone: what the blend's own sample measured as
    void noteOn(const float* params, double sampleRate, const Inputs& in, const ZoneShape* modelZone, const ZoneShape* blendZone, std::uint32_t seed) noexcept;
    void setParams(const float* params) noexcept { p_ = params; }
    void setModel(const ZoneShape* modelZone) noexcept { mz_ = modelZone; }   // SILVETON_MODEL_CLEAN_V1: mid-note the tone GLIDES to the new model (no jump = no click)
    void setInputs(const Inputs& in, double sampleRate) noexcept;
    [[nodiscard]] double pitchSemis() const noexcept { return pitchSemis_; }   // the scoop, the life, the vibrato of this block
    void tick(float& l, float& r) noexcept;                                     // the sample just read, in and out
    [[nodiscard]] float lastPeak() const noexcept { return peak_; }
    [[nodiscard]] float levelGain() const noexcept { return eqLevel_; }                                   // (tests) what the tone change is levelled by
    [[nodiscard]] float eqGainDb(int band) const noexcept { return band >= 0 && band < kEq ? eqNow_[static_cast<std::size_t>(band)] : 0.0F; }   // (tests)

private:
    void control() noexcept;
    float gainOfFilter() const noexcept;

    const float* p_{nullptr};
    const ZoneShape* mz_{nullptr};
    const ZoneShape* bz_{nullptr};
    double sr_{48000.0};
    Inputs in_{};
    int key_{60};
    bool needControl_{true};
    std::uint32_t rng_{1U};
    int pos_{kChunk};
    double t_{0.0};
    double pitchSemis_{0.0};
    float peak_{0.0F};
    // the tone
    std::array<Biquad, kEq> eq_{};
    std::array<float, kEq> eqNow_{}, eqTarget_{};
    float eqHz_[kEq]{};
    float eqLevel_{1.0F};                                        // what gives the tone change back its loudness (the blend's own power, after the EQ, = before)
    float eqC1_[kEq]{}, eqS1_[kEq]{}, eqC2_[kEq]{}, eqS2_[kEq]{};                       // the same at the EQ centres (the bands overlap: solved together)
    // the loudness in time
    float shapeNow_{0.0F}, shapeTarget_{0.0F};   // dB
    float gainNow_{1.0F}, gainTick_{0.0F};
    // the breath and the chiff
    std::array<Biquad, kNoiseBands> nz_{};
    float nzGain_[kNoiseBands]{};
    float breathRms_[kNoiseBands]{}, chiffRms_[kNoiseBands]{};
    float breathNow_[kNoiseBands]{};
    // the unison: the blend against itself, two moving taps
    static constexpr int kUniLen = 1024;
    float uniL_[kUniLen]{}, uniR_[kUniLen]{};
    int uniW_{0};
    double uniPh1_{0.0}, uniPh2_{0.37};
    float uniAmt_{0.0F}, uniDepth_{0.0F};
    float uniAmtWant_{0.0F}, uniDepthWant_{0.0F};   // SILVETON_MODEL_CLEAN_V1: the knobs set these; the real ones slide towards them (no jump of the taps)
    // the pitch
    double lifeState_{0.0};
    float lifeCentsRms_{0.0F};
    double vibPh_{0.0};
    // the filter block
    Env filtEnv_;
    Ladder ladderL_, ladderR_;
    Svf svfL_, svfR_;
    int filtType_{0};
    float cutHz_{20000.0F}, res_{0.0F}, drive_{0.0F}, filtGain_{1.0F};
};

} // namespace silveton::sampler::model
