#pragma once
// SILVETON_MODEL_V1 / SILVETON_SYNTH_V1 - the pieces of a note that SILVETON SYNTH shares with the rest of the learned-model code: what the
// player does to the note (Inputs), the length of a control step (kChunk), and the FILTER block: the filter's envelope (Env), the 24 dB ladder
// (Ladder) and the 12 dB state-variable filter (Svf). (SILVETON MODEL, the note that bent a recording of the bank towards a model, was removed
// on 03.11.2026 - its tone EQ, breath, levelling and unison are gone with it; SynthVoice.h is the note.)
// Real-time rules: no allocation, no locks.
#include "silveton/sampler/ModelBank.h"
#include "silveton/sampler/ModelDefs.h"

#include <array>
#include <cstdint>

namespace silveton::sampler::model {

struct Inputs {
    float velocity{1.0F};   // 0..1
    int key{60};
    bool gate{true};
    float wheel{0.0F};
    float pressure{0.0F};
};

constexpr int kChunk = 32;

struct Env {   // ADSR of the filter
    enum Stage : int { Attack = 0, Decay, Sustain, Release, Done };
    int stage{Done};
    float level{0.0F};
    float aCoef{0.1F}, dCoef{0.01F}, rCoef{0.01F}, sus{1.0F};
    void setTimes(float aMs, float dMs, float s01, float rMs, double sr) noexcept;
    void trigger() noexcept { stage = Attack; }
    void release() noexcept { if (stage != Done) stage = Release; }
    float tick() noexcept;
};

struct Ladder {
    float s[4]{0.0F, 0.0F, 0.0F, 0.0F};
    float g{0.1F}, k{0.0F};
    void set(float hz, float res, double sr) noexcept;
    float run(float x, float drive) noexcept;
    void reset() noexcept { s[0] = s[1] = s[2] = s[3] = 0.0F; }
};
struct Svf {
    float ic1{0.0F}, ic2{0.0F};
    float a1{0.0F}, a2{0.0F}, a3{0.0F}, k{1.0F};
    void set(float hz, float res, double sr) noexcept;
    float run(float x, int type) noexcept;   // 3 LP, 4 HP, 5 BP (the common FILTER choice)
    void reset() noexcept { ic1 = ic2 = 0.0F; }
};

} // namespace silveton::sampler::model
