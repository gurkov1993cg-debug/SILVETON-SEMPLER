#include "silveton/sampler/MultisampleEditor.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler {
namespace {

MultisampleEditResult cloneChecked(const MultisamplePtr& source) {
    if (source == nullptr) return {nullptr, "MULTISAMPLE is null"};
    return {std::make_shared<Multisample>(*source), {}};
}

} // namespace

bool MultisampleEditor::validateZone(const SampleZone& zone, std::string& error) noexcept {
    if (zone.sample == nullptr || !zone.sample->valid()) { error = "Zone SAMPLE is invalid"; return false; }
    if (zone.keyLow > zone.keyHigh) { error = "Zone key range is invalid"; return false; }
    if (zone.velocityLow < 1U || zone.velocityLow > zone.velocityHigh) { error = "Zone velocity range is invalid"; return false; }
    if (!std::isfinite(zone.tuneCents) || !std::isfinite(zone.gainDb) || !std::isfinite(zone.pan)) {
        error = "Zone numeric parameter is not finite"; return false;
    }
    if (zone.pan < -1.0F || zone.pan > 1.0F) { error = "Zone pan is out of range"; return false; }
    return true;
}

MultisampleEditResult MultisampleEditor::rename(const MultisamplePtr& source, const std::string& name) {
    auto r = cloneChecked(source); if (!r.ok()) return r;
    if (name.empty()) return {nullptr, "MULTISAMPLE name cannot be empty"};
    r.multisample->name = name;
    return r;
}

MultisampleEditResult MultisampleEditor::addZone(const MultisamplePtr& source, const SampleZone& zone) {
    auto r = cloneChecked(source); if (!r.ok()) return r;
    std::string error; if (!validateZone(zone, error)) return {nullptr, error};
    if (r.multisample->zones.size() >= static_cast<std::size_t>(kMaxZonesPerMultisample)) return {nullptr, "MULTISAMPLE zone limit reached"};
    r.multisample->zones.push_back(zone);
    return r;
}

MultisampleEditResult MultisampleEditor::insertZone(const MultisamplePtr& source, std::size_t index, const SampleZone& zone) {
    auto r = cloneChecked(source); if (!r.ok()) return r;
    std::string error; if (!validateZone(zone, error)) return {nullptr, error};
    if (r.multisample->zones.size() >= static_cast<std::size_t>(kMaxZonesPerMultisample)) return {nullptr, "MULTISAMPLE zone limit reached"};
    if (index > r.multisample->zones.size()) return {nullptr, "Zone insert index is out of range"};
    r.multisample->zones.insert(r.multisample->zones.begin() + static_cast<std::ptrdiff_t>(index), zone);
    return r;
}

MultisampleEditResult MultisampleEditor::removeZone(const MultisamplePtr& source, std::size_t index) {
    auto r = cloneChecked(source); if (!r.ok()) return r;
    if (index >= r.multisample->zones.size()) return {nullptr, "Zone index is out of range"};
    if (r.multisample->zones.size() <= 1U) return {nullptr, "MULTISAMPLE must keep at least one zone"};
    r.multisample->zones.erase(r.multisample->zones.begin() + static_cast<std::ptrdiff_t>(index));
    return r;
}

MultisampleEditResult MultisampleEditor::moveZone(const MultisamplePtr& source, std::size_t from, std::size_t to) {
    auto r = cloneChecked(source); if (!r.ok()) return r;
    if (from >= r.multisample->zones.size() || to >= r.multisample->zones.size()) return {nullptr, "Zone move index is out of range"};
    if (from == to) return r;
    auto zone = r.multisample->zones[from];
    r.multisample->zones.erase(r.multisample->zones.begin() + static_cast<std::ptrdiff_t>(from));
    r.multisample->zones.insert(r.multisample->zones.begin() + static_cast<std::ptrdiff_t>(to), std::move(zone));
    return r;
}

MultisampleEditResult MultisampleEditor::updateZone(const MultisamplePtr& source, std::size_t index, const SampleZone& zone) {
    auto r = cloneChecked(source); if (!r.ok()) return r;
    if (index >= r.multisample->zones.size()) return {nullptr, "Zone index is out of range"};
    std::string error; if (!validateZone(zone, error)) return {nullptr, error};
    r.multisample->zones[index] = zone;
    return r;
}

} // namespace silveton::sampler
