#include "silveton/sampler/SampleEditor.h"
#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>

namespace silveton::sampler {
namespace {

float readFrame(const SampleData& s, std::uint64_t frame, std::uint16_t ch) noexcept {
    if (frame >= s.frameCount() || s.channels == 0U) return 0.0F;
    const auto actualCh = std::min<std::uint16_t>(ch, static_cast<std::uint16_t>(s.channels - 1U));
    if (frame < s.preloadedFrameCount()) {
        return s.interleaved[static_cast<std::size_t>(frame) * s.channels + actualCh];
    }
    if (s.stream != nullptr) return s.stream->readFrame(frame, actualCh);
    return 0.0F;
}

std::shared_ptr<SampleData> cloneMaterialized(const SampleData& source) {
    if (!source.valid()) return nullptr;
    auto out = std::make_shared<SampleData>();
    out->name = source.name;
    out->sourcePath = source.sourcePath;
    out->sampleRate = source.sampleRate;
    out->channels = source.channels;
    out->rootKey = source.rootKey;
    out->fineTuneCents = source.fineTuneCents;
    out->loop = source.loop;
    out->totalFrames = source.frameCount();
    out->interleaved.resize(static_cast<std::size_t>(out->totalFrames) * out->channels);
    for (std::uint64_t frame = 0U; frame < out->totalFrames; ++frame) {
        for (std::uint16_t ch = 0U; ch < out->channels; ++ch) {
            out->interleaved[static_cast<std::size_t>(frame) * out->channels + ch] = readFrame(source, frame, ch);
        }
    }
    out->stream.reset();
    return out;
}

} // namespace

SampleEditResult SampleEditor::materialize(const SampleData& source) {
    auto out = cloneMaterialized(source);
    if (!out) return {nullptr, "Cannot materialize invalid sample"};
    return {out, {}};
}

SampleEditResult SampleEditor::trim(const SampleData& source,
                                    std::uint64_t startFrame,
                                    std::uint64_t endFrameExclusive) {
    if (!source.valid() || startFrame >= endFrameExclusive || endFrameExclusive > source.frameCount()) {
        return {nullptr, "Invalid trim range"};
    }
    auto out = std::make_shared<SampleData>();
    out->name = source.name;
    out->sampleRate = source.sampleRate;
    out->channels = source.channels;
    out->rootKey = source.rootKey;
    out->fineTuneCents = source.fineTuneCents;
    out->totalFrames = endFrameExclusive - startFrame;
    out->interleaved.resize(static_cast<std::size_t>(out->totalFrames) * out->channels);
    for (std::uint64_t frame = 0U; frame < out->totalFrames; ++frame) {
        for (std::uint16_t ch = 0U; ch < out->channels; ++ch) {
            out->interleaved[static_cast<std::size_t>(frame) * out->channels + ch] = readFrame(source, startFrame + frame, ch);
        }
    }
    if (source.loop.enabled && source.loop.startFrame >= startFrame && source.loop.endFrame <= endFrameExclusive) {
        out->loop = source.loop;
        out->loop.startFrame -= startFrame;
        out->loop.endFrame -= startFrame;
        const auto loopLength = out->loop.endFrame - out->loop.startFrame;
        out->loop.crossfadeFrames = static_cast<std::uint32_t>(std::min<std::uint64_t>(out->loop.crossfadeFrames, loopLength / 2U));
    }
    return {out, {}};
}

SampleEditResult SampleEditor::normalize(const SampleData& source, float targetPeakDb) {
    auto out = cloneMaterialized(source);
    if (!out) return {nullptr, "Cannot normalize invalid sample"};
    float peak = 0.0F;
    for (float x : out->interleaved) peak = std::max(peak, std::abs(x));
    if (peak <= std::numeric_limits<float>::epsilon()) return {out, {}};
    const float target = std::pow(10.0F, std::clamp(targetPeakDb, -60.0F, 0.0F) / 20.0F);
    const float gain = target / peak;
    for (float& x : out->interleaved) x = std::clamp(x * gain, -1.0F, 1.0F);
    out->sourcePath.clear();
    return {out, {}};
}

SampleEditResult SampleEditor::reverse(const SampleData& source) {
    auto out = cloneMaterialized(source);
    if (!out) return {nullptr, "Cannot reverse invalid sample"};
    const std::uint64_t frames = out->frameCount();
    for (std::uint64_t a = 0U; a < frames / 2U; ++a) {
        const std::uint64_t b = frames - 1U - a;
        for (std::uint16_t ch = 0U; ch < out->channels; ++ch) {
            std::swap(out->interleaved[static_cast<std::size_t>(a) * out->channels + ch],
                      out->interleaved[static_cast<std::size_t>(b) * out->channels + ch]);
        }
    }
    if (out->loop.enabled) {
        const std::uint64_t oldStart = out->loop.startFrame;
        const std::uint64_t oldEnd = out->loop.endFrame;
        out->loop.startFrame = frames - oldEnd;
        out->loop.endFrame = frames - oldStart;
    }
    out->sourcePath.clear();
    return {out, {}};
}

SampleEditResult SampleEditor::fade(const SampleData& source,
                                    std::uint64_t fadeInFrames,
                                    std::uint64_t fadeOutFrames) {
    auto out = cloneMaterialized(source);
    if (!out) return {nullptr, "Cannot fade invalid sample"};
    const std::uint64_t frames = out->frameCount();
    fadeInFrames = std::min(fadeInFrames, frames);
    fadeOutFrames = std::min(fadeOutFrames, frames);
    for (std::uint64_t frame = 0U; frame < frames; ++frame) {
        float gain = 1.0F;
        if (fadeInFrames > 0U && frame < fadeInFrames) {
            gain *= static_cast<float>(frame) / static_cast<float>(fadeInFrames);
        }
        if (fadeOutFrames > 0U && frame >= frames - fadeOutFrames) {
            gain *= static_cast<float>(frames - 1U - frame) / static_cast<float>(fadeOutFrames);
        }
        gain = std::clamp(gain, 0.0F, 1.0F);
        for (std::uint16_t ch = 0U; ch < out->channels; ++ch) {
            out->interleaved[static_cast<std::size_t>(frame) * out->channels + ch] *= gain;
        }
    }
    out->sourcePath.clear();
    return {out, {}};
}

SampleEditResult SampleEditor::setLoop(const SampleData& source,
                                       std::uint64_t startFrame,
                                       std::uint64_t endFrameExclusive,
                                       std::uint32_t crossfadeFrames) {
    if (!source.valid()) return {nullptr, "Cannot set loop on invalid sample"};
    if (startFrame >= endFrameExclusive || endFrameExclusive > source.frameCount()) {
        return {nullptr, "Invalid loop range"};
    }
    auto out = std::make_shared<SampleData>(source);
    const std::uint64_t loopLength = endFrameExclusive - startFrame;
    out->loop.enabled = true;
    out->loop.startFrame = startFrame;
    out->loop.endFrame = endFrameExclusive;
    out->loop.crossfadeFrames = static_cast<std::uint32_t>(std::min<std::uint64_t>(crossfadeFrames, loopLength / 2U));
    return {out, {}};
}

SampleEditResult SampleEditor::clearLoop(const SampleData& source) {
    if (!source.valid()) return {nullptr, "Cannot clear loop on invalid sample"};
    auto out = std::make_shared<SampleData>(source);
    out->loop = LoopRegion{};
    return {out, {}};
}

SampleEditResult SampleEditor::updateMetadata(const SampleData& source,
                                              const std::string& name,
                                              std::uint8_t rootKey,
                                              float fineTuneCents) {
    if (!source.valid()) return {nullptr, "Cannot edit invalid sample"};
    if (!std::isfinite(fineTuneCents)) return {nullptr, "Sample fine tune is not finite"};
    auto out = std::make_shared<SampleData>(source);
    out->name = name.empty() ? source.name : name;
    out->rootKey = static_cast<std::uint8_t>(std::min<unsigned int>(rootKey, 127U));
    out->fineTuneCents = std::clamp(fineTuneCents, -100.0F, 100.0F);
    return {out, {}};
}

std::uint64_t SampleEditor::nearestZeroCrossing(const SampleData& source,
                                                std::uint64_t aroundFrame,
                                                std::uint64_t searchRadius) noexcept {
    if (!source.valid()) return 0U;
    const std::uint64_t frames = source.frameCount();
    aroundFrame = std::min(aroundFrame, frames - 1U);
    const std::uint64_t begin = aroundFrame > searchRadius ? aroundFrame - searchRadius : 1U;
    const std::uint64_t end = std::min(frames - 1U, aroundFrame + searchRadius);
    std::uint64_t best = aroundFrame;
    std::uint64_t bestDistance = searchRadius + 1U;
    for (std::uint64_t frame = begin; frame <= end; ++frame) {
        const float a = readFrame(source, frame - 1U, 0U);
        const float b = readFrame(source, frame, 0U);
        if ((a <= 0.0F && b >= 0.0F) || (a >= 0.0F && b <= 0.0F)) {
            const std::uint64_t d = frame > aroundFrame ? frame - aroundFrame : aroundFrame - frame;
            if (d < bestDistance) { bestDistance = d; best = frame; }
        }
    }
    return best;
}

} // namespace silveton::sampler
