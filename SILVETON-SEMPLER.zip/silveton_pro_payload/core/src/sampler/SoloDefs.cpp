// SILVETON_SOLO_V1 - the knobs, pages, start values and built-in sounds of SILVETON SOLO (see SoloDefs.h).
#include "silveton/sampler/SoloDefs.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler::solo {

namespace {

using K = EngineKind;
constexpr const char* kNone = "";
constexpr const char* kOct = "-2 ОКТ|-1 ОКТ|0|+1 ОКТ|+2 ОКТ";
constexpr const char* kWaveNames = "ЗЪБЧАТА|ПУЛС|ТРИЪГЪЛНИК|СИНУС|CZ ЗЪБ|CZ ИМПУЛС|CZ РЕЗОНАНС I|CZ РЕЗОНАНС II";

// ---- page 0 ОСЦИЛ.: the two oscillators, the sub, the noise
const EngineParamDef kOsc[] = {
    {SO_OSC1_WAVE, "ВЪЛНА 1", "Вълната на осцилатор 1", K::Choice, 0.0F, static_cast<float>(kWaves - 1), 0.0F, 1.0F, 0, kWaveNames},
    {SO_OSC1_LEVEL, "СИЛА 1", "Колко се чува осцилатор 1 %", K::Pct, 0.0F, 1.0F, 0.8F, 0.01F, 0, kNone},
    {SO_OSC1_OCT, "ОКТАВА 1", "Октава на осцилатор 1", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOct},
    {SO_PW, "ШИРИНА", "Ширина на импулса (ПУЛС и CZ ИМПУЛС) %", K::Pct, 0.05F, 0.95F, 0.5F, 0.01F, 0, kNone},
    {SO_PWM_DEPTH, "PWM", "Колко ширината се люлее %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {SO_PWM_RATE, "PWM СКОРОСТ", "Скорост на люлеенето Hz", K::Hz, 0.05F, 20.0F, 0.6F, 0.01F, 2, kNone},
    {SO_OSC2_WAVE, "ВЪЛНА 2", "Вълната на осцилатор 2", K::Choice, 0.0F, static_cast<float>(kWaves - 1), 0.0F, 1.0F, 0, kWaveNames},
    {SO_OSC2_LEVEL, "СИЛА 2", "Колко се чува осцилатор 2 %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {SO_OSC2_OCT, "ОКТАВА 2", "Октава на осцилатор 2", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOct},
    {SO_OSC2_SEMI, "ПОЛУТОН 2", "Осцилатор 2 спрямо 1 (полутонове)", K::Semis, -12.0F, 12.0F, 0.0F, 1.0F, 0, kNone},
    {SO_OSC2_FINE, "ФИНО 2", "Осцилатор 2 фино (цента)", K::Cents, -50.0F, 50.0F, 0.0F, 1.0F, 0, kNone},
    {SO_SYNC, "СИНХРОН", "Осцилатор 2 почва отначало с всеки период на 1", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {SO_SUB_LEVEL, "СУБ", "Квадрат една октава под осцилатор 1 %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {SO_NOISE_LEVEL, "ШУМ", "Бял шум %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};
// ---- page 1 ФИЛТЪР: the common block, named for this engine, and the output
const EngineParamDef kFilter[] = {
    {E_FILT_TYPE, "ФИЛТЪР", "Видът на филтъра", K::Choice, 0.0F, static_cast<float>(kFilters - 1), static_cast<float>(FL_LADDER24), 1.0F, 0, "ИЗКЛ.|СТЪЛБА 24|НИСЪК 12|ВИСОК 12|ЛЕНТОВ 12"},
    {E_CUTOFF, "ОТРЯЗВАНЕ", "Честота на среза Hz", K::Hz, 20.0F, 20000.0F, 2400.0F, 1.0F, 0, kNone},
    {E_RESO, "РЕЗОНАНС", "Резонанс %", K::Pct, 0.0F, 1.0F, 0.25F, 0.01F, 0, kNone},
    {E_KEYTRACK, "СЛЕДВА КЛАВИША", "Срезът следва клавиша %", K::Pct, -1.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {E_DRIVE, "НАСИЩАНЕ", "Насищане преди филтъра %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {E_FEG_AMT, "ОБВИВКА→СРЕЗ", "Обвивката на филтъра към среза (октави)", K::Oct, -8.0F, 8.0F, 2.5F, 0.05F, 2, kNone},
    {E_FEG_A, "Ф.АТАКА", "Атака на филтъра ms", K::Ms, 1.0F, 10000.0F, 3.0F, 1.0F, 0, kNone},
    {E_FEG_D, "Ф.ЗАТИХВАНЕ", "Затихване на филтъра ms", K::Ms, 1.0F, 20000.0F, 420.0F, 1.0F, 0, kNone},
    {E_FEG_S, "Ф.ДЪРЖАНЕ", "Държане на филтъра %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {E_FEG_R, "Ф.ОТПУСКАНЕ", "Отпускане на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_VEL_CUT, "СИЛА→СРЕЗ", "Силата на удара отваря среза (октави)", K::Oct, 0.0F, 8.0F, 1.5F, 0.05F, 2, kNone},
    {E_LFO_CUT, "ВИБРАТО→СРЕЗ", "Вибратото люлее и среза (октави)", K::Oct, 0.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {SO_OUT_DRIVE, "ДРАЙВ", "Меко насищане на изхода %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {SO_WIDTH, "ШИРИНА СТЕРЕО", "Колко широко стои звукът %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
};
// ---- page 2 ОБВИВКИ: the CZ shape with its envelope, the amplifier envelope
const EngineParamDef kEnv[] = {
    {SO_DCW, "CZ ОГЪВАНЕ", "Колко се огъва синусът (CZ вълните) %", K::Pct, 0.0F, 1.0F, 0.8F, 0.01F, 0, kNone},
    {SO_DCW_KEY, "CZ ПО КЛАВИША", "Нагоре по клавиатурата огъването намалява %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {SO_DCW_VEL, "CZ ОТ СИЛАТА", "Силата на удара огъва повече %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {SO_DCW_A, "CZ АТАКА", "Атака на огъването ms", K::Ms, 1.0F, 10000.0F, 2.0F, 1.0F, 0, kNone},
    {SO_DCW_D, "CZ ЗАТИХВАНЕ", "Затихване на огъването ms", K::Ms, 1.0F, 20000.0F, 600.0F, 1.0F, 0, kNone},
    {SO_DCW_S, "CZ ДЪРЖАНЕ", "Държане на огъването %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {SO_DCW_R, "CZ ОТПУСКАНЕ", "Отпускане на огъването ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {SO_AMP_A, "АТАКА", "Колко бързо стига до най-силното ms", K::Ms, 1.0F, 10000.0F, 4.0F, 1.0F, 0, kNone},
    {SO_AMP_D, "ЗАТИХВАНЕ", "Колко бавно пада до ДЪРЖАНЕ ms", K::Ms, 1.0F, 20000.0F, 250.0F, 1.0F, 0, kNone},
    {SO_AMP_S, "ДЪРЖАНЕ", "Нивото, докато държиш клавиша %", K::Pct, 0.0F, 1.0F, 0.85F, 0.01F, 0, kNone},
    {SO_AMP_R, "ОТПУСКАНЕ", "Колко бавно угасва, след като пуснеш ms", K::Ms, 1.0F, 20000.0F, 180.0F, 1.0F, 0, kNone},
    {SO_VEL_AMP, "СИЛА→НИВО", "Силата на удара към нивото %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
};
// ---- page 3 СВИРЕНЕ: unison, vibrato, the glide, legato, pitch bend
const EngineParamDef kPlay[] = {
    {E_UNISON, "УНИСОН", "Гласове на нота", K::Choice, 1.0F, 4.0F, 2.0F, 1.0F, 0, "1|2|3|4"},
    {E_UNI_DET, "РАЗСТРОЙВАНЕ", "Разстройване на унисона (цента)", K::Cents, 0.0F, 60.0F, 9.0F, 0.5F, 1, kNone},
    {E_UNI_SPREAD, "РАЗПЕРВАНЕ", "Унисонът в стерео %", K::Pct, 0.0F, 1.0F, 0.7F, 0.01F, 0, kNone},
    {E_ANALOG, "АНАЛОГ", "Малки разлики при всяка нота %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {E_LFO_RATE, "ВИБРАТО СКОРОСТ", "Скорост на вибратото Hz", K::Hz, 0.5F, 12.0F, 5.6F, 0.1F, 1, kNone},
    {E_LFO_PITCH, "ВИБРАТО", "Дълбочина на вибратото (цента)", K::Cents, 0.0F, 200.0F, 0.0F, 1.0F, 0, kNone},
    {SO_VIB_DELAY, "ВИБРАТО ЗАКЪСН.", "Вибратото идва след ms", K::Ms, 0.0F, 3000.0F, 350.0F, 10.0F, 0, kNone},
    {SO_VIB_WHEEL, "КОЛЕЛО→ВИБРАТО", "Колелото добавя вибрато (цента при докрай)", K::Cents, 0.0F, 200.0F, 60.0F, 1.0F, 0, kNone},
    {SO_VIB_AT, "НАТИСК→ВИБРАТО", "Натискът на клавиша добавя вибрато (цента)", K::Cents, 0.0F, 200.0F, 40.0F, 1.0F, 0, kNone},
    {SO_GLIDE, "ПОРТАМЕНТО", "Време на плъзгането ms (0 = без)", K::Ms, 0.0F, 5000.0F, 0.0F, 1.0F, 0, kNone},
    {SO_GLIDE_STYLE, "СТИЛ", "Кривата на плъзгането", K::Choice, 0.0F, static_cast<float>(kGlideStyles - 1), static_cast<float>(GL_JS1), 1.0F, 0, "CZ|DX|JS1|JS2"},
    {SO_LEGATO, "ЛЕГАТО", "ВИНАГИ = плъзга от последната нота; С ПРЪСТИ = само докато държиш", K::Choice, 0.0F, 1.0F, 1.0F, 1.0F, 0, "ВИНАГИ|С ПРЪСТИ"},
    {E_BEND_UP, "БЕНД НАГОРЕ", "Пич бенд нагоре (полутонове; UPPER = както е на Upper-а)", K::Bend, -1.0F, 24.0F, 2.0F, 1.0F, 0, kNone},
    {E_BEND_DOWN, "БЕНД НАДОЛУ", "Пич бенд надолу (полутонове)", K::Bend, -1.0F, 24.0F, 2.0F, 1.0F, 0, kNone},
};

template <std::size_t N>
EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }

struct Preset {
    const char* name;
    // the values the sound changes from the start values (id, value); the rest stays as setDefaults
    struct Set { int id; float v; };
    Set sets[28];
};

// the eight sounds, by recipe (the player tunes them by ear)
const Preset kSounds[kPresets] = {
    {"БАЛКАН СОЛО", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_PULSE}, {SO_OSC2_LEVEL, 0.55F}, {SO_OSC2_FINE, 7.0F}, {SO_PW, 0.42F},
                      {E_CUTOFF, 2600.0F}, {E_RESO, 0.3F}, {E_FEG_AMT, 2.0F}, {E_FEG_D, 380.0F}, {E_FEG_S, 0.35F},
                      {SO_AMP_A, 3.0F}, {SO_AMP_R, 160.0F}, {E_UNISON, 2.0F}, {E_UNI_DET, 8.0F},
                      {SO_GLIDE, 70.0F}, {SO_GLIDE_STYLE, GL_JS1}, {SO_LEGATO, LG_FINGERED}, {E_LFO_PITCH, 0.0F}, {SO_VIB_WHEEL, 70.0F}, {SO_OUT_DRIVE, 0.2F}, {-1, 0.0F}}},
    {"CZ СОЛО", {{SO_OSC1_WAVE, W_CZ_SAW}, {SO_OSC2_WAVE, W_CZ_PULSE}, {SO_OSC2_LEVEL, 0.5F}, {SO_OSC2_FINE, -6.0F},
                  {SO_DCW, 0.9F}, {SO_DCW_D, 700.0F}, {SO_DCW_S, 0.45F}, {E_FILT_TYPE, FL_OFF},
                  {SO_AMP_A, 2.0F}, {SO_AMP_R, 200.0F}, {E_UNISON, 2.0F}, {E_UNI_DET, 6.0F},
                  {SO_GLIDE, 60.0F}, {SO_GLIDE_STYLE, GL_CZ}, {SO_LEGATO, LG_FINGERED}, {SO_VIB_WHEEL, 60.0F}, {SO_OUT_DRIVE, 0.15F}, {-1, 0.0F}}},
    {"CZ РЕЗОНАНС", {{SO_OSC1_WAVE, W_CZ_RES1}, {SO_OSC2_WAVE, W_CZ_RES2}, {SO_OSC2_LEVEL, 0.45F}, {SO_OSC2_FINE, 5.0F},
                      {SO_DCW, 0.75F}, {SO_DCW_D, 900.0F}, {SO_DCW_S, 0.3F}, {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 6000.0F}, {E_RESO, 0.1F}, {E_FEG_AMT, 0.5F},
                      {SO_AMP_A, 2.0F}, {SO_AMP_R, 220.0F}, {E_UNISON, 2.0F}, {E_UNI_DET, 7.0F},
                      {SO_GLIDE, 55.0F}, {SO_GLIDE_STYLE, GL_CZ}, {SO_LEGATO, LG_FINGERED}, {-1, 0.0F}}},
    {"СИНХРОН ЛИЙД", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_SAW}, {SO_OSC2_LEVEL, 0.9F}, {SO_OSC1_LEVEL, 0.3F}, {SO_OSC2_SEMI, 7.0F}, {SO_SYNC, 1.0F},
                       {E_CUTOFF, 3200.0F}, {E_RESO, 0.2F}, {E_FEG_AMT, 1.5F}, {E_DRIVE, 0.3F},
                       {SO_AMP_A, 2.0F}, {SO_AMP_R, 150.0F}, {E_UNISON, 1.0F},
                       {SO_GLIDE, 45.0F}, {SO_GLIDE_STYLE, GL_DX}, {SO_LEGATO, LG_FINGERED}, {SO_VIB_WHEEL, 80.0F}, {SO_OUT_DRIVE, 0.3F}, {-1, 0.0F}}},
    {"КАВАЛ СИНТ", {{SO_OSC1_WAVE, W_TRI}, {SO_OSC2_WAVE, W_SINE}, {SO_OSC2_LEVEL, 0.5F}, {SO_OSC2_OCT, 1.0F}, {SO_NOISE_LEVEL, 0.06F},
                     {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 4500.0F}, {E_RESO, 0.05F}, {E_FEG_AMT, 0.8F}, {E_FEG_A, 40.0F},
                     {SO_AMP_A, 35.0F}, {SO_AMP_R, 240.0F}, {E_UNISON, 1.0F},
                     {E_LFO_PITCH, 18.0F}, {E_LFO_RATE, 5.2F}, {SO_VIB_DELAY, 500.0F}, {SO_VIB_WHEEL, 50.0F},
                     {SO_GLIDE, 90.0F}, {SO_GLIDE_STYLE, GL_JS1}, {SO_LEGATO, LG_FINGERED}, {SO_OUT_DRIVE, 0.0F}, {-1, 0.0F}}},
    {"ДЕБЕЛ БАС", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_PULSE}, {SO_OSC2_LEVEL, 0.6F}, {SO_OSC2_OCT, -1.0F}, {SO_SUB_LEVEL, 0.5F}, {SO_PW, 0.3F},
                    {E_CUTOFF, 900.0F}, {E_RESO, 0.35F}, {E_FEG_AMT, 3.0F}, {E_FEG_D, 260.0F}, {E_FEG_S, 0.15F}, {E_KEYTRACK, 0.3F}, {E_DRIVE, 0.3F},
                    {SO_AMP_A, 2.0F}, {SO_AMP_D, 400.0F}, {SO_AMP_S, 0.7F}, {SO_AMP_R, 120.0F}, {E_UNISON, 1.0F},
                    {SO_GLIDE, 40.0F}, {SO_GLIDE_STYLE, GL_JS2}, {SO_LEGATO, LG_FINGERED}, {SO_OUT_DRIVE, 0.35F}, {SO_WIDTH, 0.2F}, {-1, 0.0F}}},
    {"ПУЛС ОРГАН", {{SO_OSC1_WAVE, W_PULSE}, {SO_PW, 0.5F}, {SO_PWM_DEPTH, 0.25F}, {SO_PWM_RATE, 0.4F}, {SO_OSC2_WAVE, W_PULSE}, {SO_OSC2_LEVEL, 0.5F}, {SO_OSC2_OCT, 1.0F},
                     {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 5000.0F}, {E_RESO, 0.0F}, {E_FEG_AMT, 0.0F},
                     {SO_AMP_A, 5.0F}, {SO_AMP_S, 1.0F}, {SO_AMP_R, 90.0F}, {E_UNISON, 2.0F}, {E_UNI_DET, 5.0F},
                     {SO_GLIDE, 0.0F}, {SO_LEGATO, LG_ALWAYS}, {SO_OUT_DRIVE, 0.05F}, {-1, 0.0F}}},
    {"МЕКА СТРУНА", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_SAW}, {SO_OSC2_LEVEL, 0.8F}, {SO_OSC2_FINE, 9.0F},
                      {E_CUTOFF, 1800.0F}, {E_RESO, 0.05F}, {E_FEG_AMT, 1.2F}, {E_FEG_A, 400.0F}, {E_FEG_D, 1500.0F}, {E_FEG_S, 0.6F},
                      {SO_AMP_A, 320.0F}, {SO_AMP_D, 800.0F}, {SO_AMP_S, 0.9F}, {SO_AMP_R, 700.0F}, {E_UNISON, 4.0F}, {E_UNI_DET, 12.0F}, {E_UNI_SPREAD, 0.9F},
                      {E_LFO_PITCH, 8.0F}, {SO_VIB_DELAY, 800.0F}, {SO_GLIDE, 0.0F}, {SO_LEGATO, LG_ALWAYS}, {SO_OUT_DRIVE, 0.0F}, {-1, 0.0F}}},
};

}  // namespace

const char* pageName(int page) noexcept {
    switch (page) {
        case 0: return "ОСЦИЛ.";
        case 1: return "ФИЛТЪР";
        case 2: return "ОБВИВКИ";
        default: return "СВИРЕНЕ";
    }
}

EngineParamPage page(int p) noexcept {
    switch (p) {
        case 0: return pageOf(kOsc);
        case 1: return pageOf(kFilter);
        case 2: return pageOf(kEnv);
        case 3: return pageOf(kPlay);
        default: return {nullptr, 0};
    }
}

void setDefaults(float* p) noexcept {
    for (int i = 0; i < kEngineParamCountLegacy; ++i) p[i] = 0.0F;
    for (int pg = 0; pg < kPages; ++pg) {
        const EngineParamPage page_ = page(pg);
        for (int i = 0; i < page_.count; ++i) p[page_.items[i].id] = page_.items[i].def;
    }
    // the common ids the engine does not show, at a sensible rest
    p[E_F2_TYPE] = 0.0F; p[E_F2_CUT] = 1000.0F; p[E_F2_RES] = 0.0F; p[E_F2_PAR] = 0.0F;
    p[E_LFO_AMP] = 0.0F; p[E_LFO_WAVE] = 0.0F;
    p[E_SOURCE] = static_cast<float>(E_SRC_OWN);   // its own sound, always
    p[E_BYPASS] = 0.0F;
}

const char* presetName(int i) noexcept { return kSounds[std::clamp(i, 0, kPresets - 1)].name; }

void preset(int i, float* p) noexcept {
    const Preset& pr = kSounds[std::clamp(i, 0, kPresets - 1)];
    const float src = p[E_SOURCE], byp = p[E_BYPASS], bu = p[E_BEND_UP], bd = p[E_BEND_DOWN];
    setDefaults(p);
    for (const auto& s : pr.sets) { if (s.id < 0) break; p[s.id] = s.v; }
    p[E_SOURCE] = src; p[E_BYPASS] = byp; p[E_BEND_UP] = bu; p[E_BEND_DOWN] = bd;
}

// the glide: TIME is for a jump of an octave; the style says how other intervals relate to it
float glideSeconds(const float* p, double semis) noexcept {
    const float ms = std::clamp(p[SO_GLIDE], 0.0F, 5000.0F);
    if (ms <= 0.5F) return 0.0F;
    const float base = ms / 1000.0F;
    const double d = std::fabs(semis);
    switch (static_cast<int>(p[SO_GLIDE_STYLE] + 0.5F)) {
        case GL_CZ: return base;                                                                   // the same time for every interval
        case GL_DX: return std::clamp(static_cast<float>(base * std::max(d, 0.5) / 12.0), 0.004F, 10.0F);   // a time per octave
        case GL_JS2: return base;                                                                  // the musical curve (shape in the sampler), the time as set
        default: {                                                                                 // JS1: far = TIME, 1 semitone a little longer and softer
            const double w = d <= 1.0 ? 1.0 : (d >= 4.0 ? 0.0 : (4.0 - d) / 3.0);
            return base * static_cast<float>(1.0 + 0.35 * w);
        }
    }
}

} // namespace silveton::sampler::solo
