// SILVETON_SOLO_V1 - the knobs, pages, start values and built-in sounds of SILVETON SOLO (see SoloDefs.h).
#include "silveton/sampler/SoloDefs.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler::solo {

namespace {

using K = EngineKind;
constexpr const char* kNone = "";
constexpr const char* kOct = "-2 OCT|-1 OCT|0|+1 OCT|+2 OCT";
constexpr const char* kWaveNames = "SAW|PULSE|TRIANGLE|SINE|CZ SAW|CZ PULSE|CZ RESONANCE I|CZ RESONANCE II|VPM|COMB|RING";

// ---- page 0 ОСЦИЛ.: the two oscillators, the sub, the noise
const EngineParamDef kOsc[] = {
    // row 1: everything of oscillator 1, the RATIO of the second tone (both oscillators), then the sub (an octave under it)
    {SO_OSC1_WAVE, "WAVE 1", "Вълната на осцилатор 1", K::Choice, 0.0F, static_cast<float>(kWaves - 1), 0.0F, 1.0F, 0, kWaveNames},
    {SO_OSC1_LEVEL, "LEVEL 1", "Колко се чува осцилатор 1 %", K::Pct, 0.0F, 1.0F, 0.8F, 0.01F, 0, kNone},
    {SO_OSC1_OCT, "OCTAVE 1", "Октава на осцилатор 1", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOct},
    {SO_PW, "PULSE WIDTH", "Ширина на импулса (само PULSE, CZ PULSE, COMB) %", K::Pct, 0.05F, 0.95F, 0.5F, 0.01F, 0, kNone},
    {SO_PWM_DEPTH, "PWM", "Колко ширината се люлее (само PULSE) %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {SO_PWM_RATE, "PWM RATE", "Скорост на люлеенето (само PULSE) Hz", K::Hz, 0.05F, 20.0F, 0.6F, 0.01F, 2, kNone},
    {SO_RATIO, "RATIO", "Вторият тон спрямо нотата: VPM = модулаторът, COMB = гребенът, RING = пръстенът (1 = същата, 2 = октава)", K::Lin, 0.25F, 16.0F, 1.0F, 0.25F, 2, kNone},
    {SO_SUB_LEVEL, "SUB", "Квадрат една октава под осцилатор 1 %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    // row 2: everything of oscillator 2, then the noise
    {SO_OSC2_WAVE, "WAVE 2", "Вълната на осцилатор 2", K::Choice, 0.0F, static_cast<float>(kWaves - 1), 0.0F, 1.0F, 0, kWaveNames},
    {SO_OSC2_LEVEL, "LEVEL 2", "Колко се чува осцилатор 2 %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
    {SO_OSC2_OCT, "OCTAVE 2", "Октава на осцилатор 2", K::Choice, -2.0F, 2.0F, 0.0F, 1.0F, 0, kOct},
    {SO_OSC2_SEMI, "SEMI 2", "Осцилатор 2 спрямо 1 (полутонове)", K::Semis, -12.0F, 12.0F, 0.0F, 1.0F, 0, kNone},
    {SO_OSC2_FINE, "FINE 2", "Осцилатор 2 фино (цента)", K::Cents, -50.0F, 50.0F, 0.0F, 1.0F, 0, kNone},
    {SO_SYNC, "SYNC", "Осцилатор 2 почва отначало с всеки период на 1", K::Switch, 0.0F, 1.0F, 0.0F, 1.0F, 0, kNone},
    {SO_NOISE_LEVEL, "NOISE", "Бял шум %", K::Pct, 0.0F, 1.0F, 0.0F, 0.01F, 0, kNone},
};
// ---- page 1 ФИЛТЪР: the common block, named for this engine, and the output
const EngineParamDef kFilter[] = {
    {E_FILT_TYPE, "FILTER", "Видът на филтъра", K::Choice, 0.0F, static_cast<float>(kFilters - 1), static_cast<float>(FL_LADDER24), 1.0F, 0, "OFF|LADDER 24|LP 12|HP 12|BP 12"},
    {E_CUTOFF, "CUTOFF", "Честота на среза Hz", K::Hz, 20.0F, 20000.0F, 2400.0F, 1.0F, 0, kNone},
    {E_RESO, "RESONANCE", "Резонанс %", K::Pct, 0.0F, 1.0F, 0.25F, 0.01F, 0, kNone},
    {E_KEYTRACK, "KEY TRACK", "Срезът следва клавиша %", K::Pct, -1.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {E_DRIVE, "DRIVE", "Насищане преди филтъра %", K::Pct, 0.0F, 1.0F, 0.15F, 0.01F, 0, kNone},
    {E_FEG_AMT, "ENV AMOUNT", "Обвивката на филтъра към среза (октави)", K::Oct, -8.0F, 8.0F, 2.5F, 0.05F, 2, kNone},
    {E_FEG_A, "F.ATTACK", "Атака на филтъра ms", K::Ms, 1.0F, 10000.0F, 3.0F, 1.0F, 0, kNone},
    {E_FEG_D, "F.DECAY", "Затихване на филтъра ms", K::Ms, 1.0F, 20000.0F, 420.0F, 1.0F, 0, kNone},
    {E_FEG_S, "F.SUSTAIN", "Държане на филтъра %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
    {E_FEG_R, "F.RELEASE", "Отпускане на филтъра ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {E_VEL_CUT, "VEL→CUTOFF", "Силата на удара отваря среза (октави)", K::Oct, 0.0F, 8.0F, 1.5F, 0.05F, 2, kNone},
    {E_LFO_CUT, "LFO→CUTOFF", "Вибратото люлее и среза (октави)", K::Oct, 0.0F, 4.0F, 0.0F, 0.05F, 2, kNone},
    {SO_OUT_DRIVE, "OUT DRIVE", "Меко насищане на изхода %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {SO_WIDTH, "STEREO WIDTH", "Колко широко стои звукът %", K::Pct, 0.0F, 1.0F, 0.3F, 0.01F, 0, kNone},
};
// ---- page 2 ENV: the SHAPE of the wave (CZ bend / VPM depth / COMB feedback / RING mix) with its envelope, the amplifier envelope
const EngineParamDef kEnv[] = {
    {SO_DCW, "SHAPE", "Формата на вълната: CZ = огъване, VPM = дълбочина, COMB = резонанс, RING = колко пръстен %", K::Pct, 0.0F, 1.0F, 0.8F, 0.01F, 0, kNone},
    {SO_DCW_KEY, "SHAPE KEY", "Нагоре по клавиатурата формата намалява %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {SO_DCW_VEL, "SHAPE VEL", "Силата на удара отваря формата повече %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {SO_DCW_A, "SHAPE ATTACK", "Атака на формата ms", K::Ms, 1.0F, 10000.0F, 2.0F, 1.0F, 0, kNone},
    {SO_DCW_D, "SHAPE DECAY", "Затихване на формата ms", K::Ms, 1.0F, 20000.0F, 600.0F, 1.0F, 0, kNone},
    {SO_DCW_S, "SHAPE SUSTAIN", "Държане на формата %", K::Pct, 0.0F, 1.0F, 0.4F, 0.01F, 0, kNone},
    {SO_DCW_R, "SHAPE RELEASE", "Отпускане на формата ms", K::Ms, 1.0F, 20000.0F, 300.0F, 1.0F, 0, kNone},
    {SO_AMP_A, "ATTACK", "Колко бързо стига до най-силното ms", K::Ms, 1.0F, 10000.0F, 4.0F, 1.0F, 0, kNone},
    {SO_AMP_D, "DECAY", "Колко бавно пада до SUSTAIN ms", K::Ms, 1.0F, 20000.0F, 250.0F, 1.0F, 0, kNone},
    {SO_AMP_S, "SUSTAIN", "Нивото, докато държиш клавиша %", K::Pct, 0.0F, 1.0F, 0.85F, 0.01F, 0, kNone},
    {SO_AMP_R, "RELEASE", "Колко бавно угасва, след като пуснеш ms", K::Ms, 1.0F, 20000.0F, 180.0F, 1.0F, 0, kNone},
    {SO_VEL_AMP, "VEL→LEVEL", "Силата на удара към нивото %", K::Pct, 0.0F, 1.0F, 0.6F, 0.01F, 0, kNone},
};
// ---- page 3 СВИРЕНЕ: unison, vibrato, the glide, legato, pitch bend
const EngineParamDef kPlay[] = {
    {E_UNISON, "UNISON", "Гласове на нота", K::Choice, 1.0F, 4.0F, 1.0F, 1.0F, 0, "1|2|3|4"},
    {E_UNI_DET, "DETUNE", "Разстройване на унисона (цента)", K::Cents, 0.0F, 60.0F, 4.0F, 0.5F, 1, kNone},
    {E_UNI_SPREAD, "SPREAD", "Унисонът в стерео %", K::Pct, 0.0F, 1.0F, 0.5F, 0.01F, 0, kNone},
    {E_ANALOG, "ANALOG", "Малки разлики при всяка нота %", K::Pct, 0.0F, 1.0F, 0.1F, 0.01F, 0, kNone},
    {E_LFO_RATE, "VIB RATE", "Скорост на вибратото Hz", K::Hz, 0.5F, 12.0F, 5.6F, 0.1F, 1, kNone},
    {E_LFO_PITCH, "VIB DEPTH", "Дълбочина на вибратото (цента)", K::Cents, 0.0F, 200.0F, 0.0F, 1.0F, 0, kNone},
    {SO_VIB_DELAY, "VIB DELAY", "Вибратото идва след ms", K::Ms, 0.0F, 3000.0F, 350.0F, 10.0F, 0, kNone},
    {SO_VIB_WHEEL, "WHEEL→VIB", "Колелото добавя вибрато (цента при докрай)", K::Cents, 0.0F, 200.0F, 60.0F, 1.0F, 0, kNone},
    {SO_VIB_AT, "AFTERTOUCH→VIB", "Натискът на клавиша добавя вибрато (цента)", K::Cents, 0.0F, 200.0F, 40.0F, 1.0F, 0, kNone},
    {SO_GLIDE, "PORTAMENTO", "Време на плъзгането ms (0 = без)", K::Ms, 0.0F, 5000.0F, 0.0F, 1.0F, 0, kNone},
    {SO_GLIDE_STYLE, "GLIDE", "Кривата на плъзгането", K::Choice, 0.0F, static_cast<float>(kGlideStyles - 1), static_cast<float>(GL_JS1), 1.0F, 0, "CZ|DX|JS1|JS2"},
    {SO_LEGATO, "LEGATO", "ALWAYS = плъзга от последната нота; FINGERED = само докато държиш", K::Choice, 0.0F, 1.0F, 1.0F, 1.0F, 0, "ALWAYS|FINGERED"},
    {E_BEND_UP, "BEND UP", "Пич бенд нагоре (полутонове; UPPER = както е на Upper-а)", K::Bend, -1.0F, 24.0F, 2.0F, 1.0F, 0, kNone},
    {E_BEND_DOWN, "BEND DOWN", "Пич бенд надолу (полутонове)", K::Bend, -1.0F, 24.0F, 2.0F, 1.0F, 0, kNone},
};

template <std::size_t N>
EngineParamPage pageOf(const EngineParamDef (&a)[N]) noexcept { return {a, static_cast<int>(N)}; }

struct Preset {
    const char* name;
    // the values the sound changes from the start values (id, value); the rest stays as setDefaults
    struct Set { int id; float v; };
    Set sets[28];
};

// the eight sounds, by recipe (the player tunes them by ear)
const Preset kSounds[kPresets] = {
    {"BALKAN SOLO", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_PULSE}, {SO_OSC2_LEVEL, 0.55F}, {SO_OSC2_FINE, 7.0F}, {SO_PW, 0.42F},
                      {E_CUTOFF, 2600.0F}, {E_RESO, 0.3F}, {E_FEG_AMT, 2.0F}, {E_FEG_D, 380.0F}, {E_FEG_S, 0.35F},
                      {SO_AMP_A, 3.0F}, {SO_AMP_R, 160.0F}, {E_UNISON, 1.0F},
                      {SO_GLIDE, 70.0F}, {SO_GLIDE_STYLE, GL_JS1}, {SO_LEGATO, LG_FINGERED}, {E_LFO_PITCH, 0.0F}, {SO_VIB_WHEEL, 70.0F}, {SO_OUT_DRIVE, 0.2F}, {-1, 0.0F}}},
    {"CZ SOLO", {{SO_OSC1_WAVE, W_CZ_SAW}, {SO_OSC2_WAVE, W_CZ_PULSE}, {SO_OSC2_LEVEL, 0.5F}, {SO_OSC2_FINE, -6.0F},
                  {SO_DCW, 0.9F}, {SO_DCW_D, 700.0F}, {SO_DCW_S, 0.45F}, {E_FILT_TYPE, FL_OFF},
                  {SO_AMP_A, 2.0F}, {SO_AMP_R, 200.0F}, {E_UNISON, 1.0F},
                  {SO_GLIDE, 60.0F}, {SO_GLIDE_STYLE, GL_CZ}, {SO_LEGATO, LG_FINGERED}, {SO_VIB_WHEEL, 60.0F}, {SO_OUT_DRIVE, 0.15F}, {-1, 0.0F}}},
    {"CZ RESONANCE", {{SO_OSC1_WAVE, W_CZ_RES1}, {SO_OSC2_WAVE, W_CZ_RES2}, {SO_OSC2_LEVEL, 0.45F}, {SO_OSC2_FINE, 5.0F},
                      {SO_DCW, 0.75F}, {SO_DCW_D, 900.0F}, {SO_DCW_S, 0.3F}, {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 6000.0F}, {E_RESO, 0.1F}, {E_FEG_AMT, 0.5F},
                      {SO_AMP_A, 2.0F}, {SO_AMP_R, 220.0F}, {E_UNISON, 1.0F},
                      {SO_GLIDE, 55.0F}, {SO_GLIDE_STYLE, GL_CZ}, {SO_LEGATO, LG_FINGERED}, {-1, 0.0F}}},
    {"SYNC LEAD", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_SAW}, {SO_OSC2_LEVEL, 0.9F}, {SO_OSC1_LEVEL, 0.3F}, {SO_OSC2_SEMI, 7.0F}, {SO_SYNC, 1.0F},
                       {E_CUTOFF, 3200.0F}, {E_RESO, 0.2F}, {E_FEG_AMT, 1.5F}, {E_DRIVE, 0.3F},
                       {SO_AMP_A, 2.0F}, {SO_AMP_R, 150.0F}, {E_UNISON, 1.0F},
                       {SO_GLIDE, 45.0F}, {SO_GLIDE_STYLE, GL_DX}, {SO_LEGATO, LG_FINGERED}, {SO_VIB_WHEEL, 80.0F}, {SO_OUT_DRIVE, 0.3F}, {-1, 0.0F}}},
    {"KAVAL SYNTH", {{SO_OSC1_WAVE, W_TRI}, {SO_OSC2_WAVE, W_SINE}, {SO_OSC2_LEVEL, 0.5F}, {SO_OSC2_OCT, 1.0F}, {SO_NOISE_LEVEL, 0.06F},
                     {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 4500.0F}, {E_RESO, 0.05F}, {E_FEG_AMT, 0.8F}, {E_FEG_A, 40.0F},
                     {SO_AMP_A, 35.0F}, {SO_AMP_R, 240.0F}, {E_UNISON, 1.0F},
                     {E_LFO_PITCH, 18.0F}, {E_LFO_RATE, 5.2F}, {SO_VIB_DELAY, 500.0F}, {SO_VIB_WHEEL, 50.0F},
                     {SO_GLIDE, 90.0F}, {SO_GLIDE_STYLE, GL_JS1}, {SO_LEGATO, LG_FINGERED}, {SO_OUT_DRIVE, 0.0F}, {-1, 0.0F}}},
    {"FAT BASS", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_PULSE}, {SO_OSC2_LEVEL, 0.6F}, {SO_OSC2_OCT, -1.0F}, {SO_SUB_LEVEL, 0.5F}, {SO_PW, 0.3F},
                    {E_CUTOFF, 900.0F}, {E_RESO, 0.35F}, {E_FEG_AMT, 3.0F}, {E_FEG_D, 260.0F}, {E_FEG_S, 0.15F}, {E_KEYTRACK, 0.3F}, {E_DRIVE, 0.3F},
                    {SO_AMP_A, 2.0F}, {SO_AMP_D, 400.0F}, {SO_AMP_S, 0.7F}, {SO_AMP_R, 120.0F}, {E_UNISON, 1.0F},
                    {SO_GLIDE, 40.0F}, {SO_GLIDE_STYLE, GL_JS2}, {SO_LEGATO, LG_FINGERED}, {SO_OUT_DRIVE, 0.35F}, {SO_WIDTH, 0.2F}, {-1, 0.0F}}},
    {"PULSE ORGAN", {{SO_OSC1_WAVE, W_PULSE}, {SO_PW, 0.5F}, {SO_PWM_DEPTH, 0.25F}, {SO_PWM_RATE, 0.4F}, {SO_OSC2_WAVE, W_PULSE}, {SO_OSC2_LEVEL, 0.5F}, {SO_OSC2_OCT, 1.0F},
                     {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 5000.0F}, {E_RESO, 0.0F}, {E_FEG_AMT, 0.0F},
                     {SO_AMP_A, 5.0F}, {SO_AMP_S, 1.0F}, {SO_AMP_R, 90.0F}, {E_UNISON, 2.0F}, {E_UNI_DET, 5.0F}, {E_UNI_SPREAD, 0.6F},
                     {SO_GLIDE, 0.0F}, {SO_LEGATO, LG_ALWAYS}, {SO_OUT_DRIVE, 0.05F}, {-1, 0.0F}}},
    {"SOFT STRING", {{SO_OSC1_WAVE, W_SAW}, {SO_OSC2_WAVE, W_SAW}, {SO_OSC2_LEVEL, 0.8F}, {SO_OSC2_FINE, 9.0F},
                      {E_CUTOFF, 1800.0F}, {E_RESO, 0.05F}, {E_FEG_AMT, 1.2F}, {E_FEG_A, 400.0F}, {E_FEG_D, 1500.0F}, {E_FEG_S, 0.6F},
                      {SO_AMP_A, 320.0F}, {SO_AMP_D, 800.0F}, {SO_AMP_S, 0.9F}, {SO_AMP_R, 700.0F}, {E_UNISON, 2.0F}, {E_UNI_DET, 7.0F}, {E_UNI_SPREAD, 0.9F}, {SO_WIDTH, 0.6F},
                      {E_LFO_PITCH, 8.0F}, {SO_VIB_DELAY, 800.0F}, {SO_GLIDE, 0.0F}, {SO_LEGATO, LG_ALWAYS}, {SO_OUT_DRIVE, 0.0F}, {-1, 0.0F}}},
    // SILVETON_SOLO_V2: the new waves, so they can be heard at once
    {"VPM LEAD", {{SO_OSC1_WAVE, W_VPM}, {SO_RATIO, 1.0F}, {SO_DCW, 0.7F}, {SO_DCW_KEY, 0.6F}, {SO_DCW_VEL, 0.6F}, {SO_DCW_D, 500.0F}, {SO_DCW_S, 0.5F},
                   {SO_OSC2_WAVE, W_SAW}, {SO_OSC2_LEVEL, 0.35F}, {SO_OSC2_FINE, -5.0F},
                   {E_FILT_TYPE, FL_LP12}, {E_CUTOFF, 6000.0F}, {E_RESO, 0.1F}, {E_FEG_AMT, 0.5F},
                   {SO_AMP_A, 2.0F}, {SO_AMP_R, 160.0F}, {E_UNISON, 1.0F},
                   {SO_GLIDE, 60.0F}, {SO_GLIDE_STYLE, GL_JS1}, {SO_LEGATO, LG_FINGERED}, {SO_VIB_WHEEL, 70.0F}, {SO_OUT_DRIVE, 0.2F}, {-1, 0.0F}}},
    {"COMB PLUCK", {{SO_OSC1_WAVE, W_COMB}, {SO_PW, 0.15F}, {SO_RATIO, 1.0F}, {SO_DCW, 0.95F}, {SO_DCW_KEY, 0.3F}, {SO_DCW_VEL, 0.3F},
                     {SO_DCW_A, 1.0F}, {SO_DCW_D, 900.0F}, {SO_DCW_S, 0.2F}, {SO_DCW_R, 300.0F},
                     {E_CUTOFF, 3500.0F}, {E_RESO, 0.1F}, {E_FEG_AMT, 1.0F}, {E_FEG_D, 300.0F}, {E_FEG_S, 0.2F},
                     {SO_AMP_A, 1.0F}, {SO_AMP_D, 600.0F}, {SO_AMP_S, 0.6F}, {SO_AMP_R, 250.0F}, {E_UNISON, 1.0F},
                     {SO_GLIDE, 0.0F}, {SO_LEGATO, LG_FINGERED}, {SO_OUT_DRIVE, 0.1F}, {-1, 0.0F}}},
};

}  // namespace

const char* pageName(int page) noexcept {
    switch (page) {
        case 0: return "OSC";
        case 1: return "FILTER";
        case 2: return "ENV";
        default: return "PLAY";
    }
}

EngineParamPage page(int p) noexcept {
    switch (p) {
        case 0: return pageOf(kOsc);
        case 1: return pageOf(kFilter);
        case 2: return pageOf(kEnv);
        case 3: return pageOf(kPlay);
        default: return {nullptr, 0};
    }
}

int firstRow(int page) noexcept {
    switch (page) {
        case 0: return 8;    // WAVE 1 ... RATIO, SUB  /  WAVE 2 ... SYNC, NOISE
        case 2: return 7;    // the seven SHAPE knobs  /  ATTACK ... VEL->LEVEL
        default: return 7;
    }
}

const char* dimNote(const float* p, int id) noexcept {
    const int w1 = std::clamp(static_cast<int>(p[SO_OSC1_WAVE] + 0.5F), 0, kWaves - 1);
    const int w2 = std::clamp(static_cast<int>(p[SO_OSC2_WAVE] + 0.5F), 0, kWaves - 1);
    const bool osc2 = p[SO_OSC2_LEVEL] > 0.0F;   // a silent oscillator 2 does not make its knobs work
    const bool pulse = waveUsesPulseWidth(w1) || (osc2 && waveUsesPulseWidth(w2));
    const bool ratio = waveUsesRatio(w1) || (osc2 && waveUsesRatio(w2));
    const bool shape = waveUsesShape(w1) || (osc2 && waveUsesShape(w2));
    switch (id) {
        case SO_PW: return pulse ? nullptr : "PULSE · COMB";
        case SO_PWM_DEPTH: case SO_PWM_RATE: return pulse ? nullptr : "PULSE ONLY";
        case SO_RATIO: return ratio ? nullptr : "VPM · COMB · RING";
        case SO_DCW: case SO_DCW_KEY: case SO_DCW_VEL: case SO_DCW_A: case SO_DCW_D: case SO_DCW_S: case SO_DCW_R: return shape ? nullptr : "CZ · VPM · COMB · RING";
        default: return nullptr;
    }
}

void setDefaults(float* p) noexcept {
    for (int i = 0; i < kEngineParamCountLegacy; ++i) p[i] = 0.0F;
    for (int pg = 0; pg < kPages; ++pg) {
        const EngineParamPage page_ = page(pg);
        for (int i = 0; i < page_.count; ++i) p[page_.items[i].id] = page_.items[i].def;
    }
    // the common ids the engine does not show, at a sensible rest
    p[E_F2_TYPE] = 0.0F; p[E_F2_CUT] = 1000.0F; p[E_F2_RES] = 0.0F; p[E_F2_PAR] = 0.0F;
    p[E_LFO_AMP] = 0.0F; p[E_LFO_WAVE] = 0.0F;
    p[E_SOURCE] = static_cast<float>(E_SRC_OWN);   // its own sound, always
    p[E_BYPASS] = 0.0F;
}

const char* presetName(int i) noexcept { return kSounds[std::clamp(i, 0, kPresets - 1)].name; }

void preset(int i, float* p) noexcept {
    const Preset& pr = kSounds[std::clamp(i, 0, kPresets - 1)];
    const float src = p[E_SOURCE], byp = p[E_BYPASS], bu = p[E_BEND_UP], bd = p[E_BEND_DOWN];
    setDefaults(p);
    for (const auto& s : pr.sets) { if (s.id < 0) break; p[s.id] = s.v; }
    p[E_SOURCE] = src; p[E_BYPASS] = byp; p[E_BEND_UP] = bu; p[E_BEND_DOWN] = bd;
}

// the glide: TIME is for a jump of an octave; the style says how other intervals relate to it
float glideSeconds(const float* p, double semis) noexcept {
    const float ms = std::clamp(p[SO_GLIDE], 0.0F, 5000.0F);
    if (ms <= 0.5F) return 0.0F;
    const float base = ms / 1000.0F;
    const double d = std::fabs(semis);
    switch (static_cast<int>(p[SO_GLIDE_STYLE] + 0.5F)) {
        case GL_CZ: return base;                                                                   // the same time for every interval
        case GL_DX: return std::clamp(static_cast<float>(base * std::max(d, 0.5) / 12.0), 0.004F, 10.0F);   // a time per octave
        case GL_JS2: return base;                                                                  // the musical curve (shape in the sampler), the time as set
        default: {                                                                                 // JS1: far = TIME, 1 semitone a little longer and softer
            const double w = d <= 1.0 ? 1.0 : (d >= 4.0 ? 0.0 : (4.0 - d) / 3.0);
            return base * static_cast<float>(1.0 + 0.35 * w);
        }
    }
}

} // namespace silveton::sampler::solo
