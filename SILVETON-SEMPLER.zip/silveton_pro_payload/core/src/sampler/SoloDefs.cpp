#include "silveton/sampler/SoloDefs.h"
#include <algorithm>
#include <cmath>
namespace silveton::sampler::solo {
namespace {
using K=EngineKind;
const EngineParamDef defs[]={
 {MorphX,"CHARACTER","STAVROS to DRUGO",K::Pct,0,1,0.F,.01F,0,""},
 {MorphY,"STEREO","Static harmonic stereo width; no pitch detuning",K::Pct,0,1,0.F,.01F,0,""},
 {Brightness,"BRIGHT","Harmonic decay and pulse brightness",K::Pct,0,1,.5F,.01F,0,""},
 {Hollow,"BODY","Even/odd harmonic and sub-tone balance",K::Pct,0,1,.5F,.01F,0,""},
 {Formant,"COLOR","Spectral envelope position independent of pitch",K::Pct,0,1,.5F,.01F,0,""},
 {Focus,"FOCUS","Harmonic contrast",K::Pct,0,1,.5F,.01F,0,""},
 {Air,"MEMORY","Recent playing history",K::Pct,0,1,.15F,.01F,0,""},
 {Response,"REACT","Timbre responds to played intervals",K::Pct,0,1,.25F,.01F,0,""},
 {AttackMs,"ATTACK","Amplitude attack ms",K::Ms,0,300,3,1,0,""},
 {ReleaseMs,"RELEASE","Amplitude release ms",K::Ms,0,2000,25,1,0,""},
 {VibratoCents,"VIBRATO","CC1 / channel pressure vibrato cents",K::Lin,0,100,35,1,0,""},
 {VibratoHz,"VIB RATE","Vibrato Hz",K::Hz,1,12,5.6F,.1F,1,""},
 {VibratoDelayMs,"VIB DELAY","Vibrato delay ms",K::Ms,0,800,80,1,0,""},
 {LevelDb,"LEVEL","Engine output dB",K::Db,-24,6,-3,.5F,1,""},
 {BreathDepth,"BC DEPTH","Breath-to-timbre amount",K::Pct,0,1,.65F,.01F,0,""},
 {Retrigger,"RETRIGGER","Attack on every legato note",K::Switch,0,1,0,1,0,""},
 {Priority,"PRIORITY","Held-note priority",K::Choice,0,2,0,1,0,"LAST|HIGH|LOW"},
 {BreathMode,"BREATH","Keyboard / CC2 timbre / CC2 gate",K::Choice,0,2,0,1,0,"KEYS|BC TONE|BC GATE"},

};
const char* names[]={"STAVROS","DRUGO","MORPH"};
}
const EngineParamDef* parameter(int id) noexcept {return id>=0&&id<Count?&defs[id]:nullptr;}
float clamp(int id,float v) noexcept {
    if(!std::isfinite(v))v=0;
    if(id==E_BEND_UP||id==E_BEND_DOWN)return std::round(std::clamp(v,-1.F,24.F));
    if(id==E_BYPASS)return v>=.5F?1.F:0.F;
    if(id==E_SOURCE)return 1;
    if(id==19)return std::round(std::clamp(v,-1.F,500.F));
    if(id==20)return v>=.5F?1.F:0.F;
    const auto* d=parameter(id);if(!d)return 0;
    v=std::clamp(v,d->lo,d->hi);
    return d->kind==K::Choice||d->kind==K::Switch?std::round(v):v;
}
void defaults(float* p) noexcept {
 std::fill_n(p,kEngineParamCount,0.F);for(const auto& d:defs)p[d.id]=d.def;
 p[MorphX]=p[MorphY]=0;p[Brightness]=p[Hollow]=p[Formant]=p[Focus]=.5F;
 p[Air]=.15F;p[Response]=.25F;p[AttackMs]=3;p[ReleaseMs]=25;p[LevelDb]=-3;
 p[20]=1;p[E_SOURCE]=1;p[E_BEND_UP]=p[E_BEND_DOWN]=2;
}
void learnedDefaults(float* p, float releaseMs) noexcept {
 defaults(p);
 p[Air]=p[Response]=p[VibratoCents]=0;
 p[AttackMs]=1;p[ReleaseMs]=clamp(ReleaseMs,releaseMs);p[LevelDb]=0;
 p[BreathMode]=0;
}
const char* presetName(int i) noexcept{return names[std::clamp(i,0,kPresets-1)];}

void factory(int index,float* p) noexcept {
 defaults(p);if(index==1){p[MorphX]=1;p[MorphY]=.7F;}
 if(index==2){p[MorphX]=.5F;p[MorphY]=.35F;}
}
}
