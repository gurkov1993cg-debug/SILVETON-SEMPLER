#pragma once
// The existing SOLO source, revised from two user-provided tone references.
// One phase-locked spectral oscillator with static stereo placement of harmonics.
// No PCM or wave-period replay. Teacher coefficients are immutable; no render-time allocation.
#include "silveton/sampler/SoloDefs.h"
#include "SoloCharacter.h"
#include "silveton/sampler/SoloModel.h"
#include <algorithm>
#include <array>
#include <cmath>
namespace silveton::sampler::solo {
class Source {
public:
    void prepare(double rate,int key,double velocity) noexcept {
        *this=Source{};rate_=rate;key_=key;registerKey_=key;velocity_=velocity;
        fastRate_=1-std::exp(-1/(.018*rate));slowRate_=1-std::exp(-1/(.34*rate));
        gestureDecay_=std::exp(-1/(.075*rate));attackDecay_=std::exp(-1/(.035*rate));
        smooth_=1-std::exp(-1/(.0025*rate));attack_=1;
    }
    void note(int key,double velocity) noexcept {
        if(key!=key_){direction_=std::clamp((key-key_)/7.,-1.,1.);attack_=std::min(1.,attack_+.35);}
        key_=key;registerKey_=key;velocity_=velocity;
    }
    // Registration follows the transposed note, independently of articulation.
    void setRegisterKey(int key) noexcept {registerKey_=key;}
    void learned(const Model* model,const Condition& q) noexcept {model_=model;condition_=q;}
    void controls(const float* p,double hz,double breath,double pressure) noexcept {
        const double morph=std::clamp(static_cast<double>(p[MorphX]),0.,1.);
        spreadTarget_=std::clamp(static_cast<double>(p[MorphY]),0.,1.);
        memory_=p[Air];response_=p[Response];
        const double bc=p[BreathMode]>.5F?(breath-.5)*p[BreathDepth]:0;
        effort_=std::clamp(.6*velocity_+.3*pressure+.5*bc+.15*attack_,0.,1.);
        const double motion=response_*(.5*direction_+.25*attack_)+memory_*(fast_-slow_);
        const double shift=(p[Formant]-.5)*16+motion*1.6+bc*2;
        const double registerKey=registerKey_+shift;
        auto a=at(character::stavros,registerKey),b=at(character::drugo,registerKey);
        Spectrum measured;bool trained=false;
        if(model_){auto q=condition_;q.key=static_cast<float>(registerKey);trained=model_->predict(q,measured);if(trained){a.db=measured.db;a.sub=measured.sub;}}
        pitchCents_=trained?measured.pitchCents:0;
        const double tilt=(p[Brightness]-.5)*12+bc*4+motion*1.5;
        const double contrast=std::exp2((p[Focus]-.5)*1.8);
        double power=0;
        for(int h=0;h<H;++h){
            // Formant motion resamples the envelope without detuning the oscillator.
            const double source=std::clamp((h+1)*std::exp2(-shift/48.)-1,0.,static_cast<double>(H-1));
            const int lo=static_cast<int>(source),hi=std::min(lo+1,H-1);const double t=source-lo;
            const double da=a.db[lo]+(a.db[hi]-a.db[lo])*t,db=b.db[lo]+(b.db[hi]-b.db[lo])*t;
            double level=((1-morph)*da+morph*db)*contrast+tilt*std::log2(static_cast<double>(h+1));
            if((h+1)%2==0)level+=(.5-p[Hollow])*24;
            const double edge=std::clamp((rate_*.21-hz*(h+1))/(hz*2),0.,1.);
            target_[h]=static_cast<float>(std::pow(10.,std::clamp(level,-90.,18.)/20.)*edge);
            power+=.5*target_[h]*target_[h];
        }
        subTarget_=std::clamp(((1-morph)*a.sub+morph*b.sub)*std::exp2((p[Hollow]-.5)*2),0.,.8);
        power+=.5*subTarget_*subTarget_;
        normaliseTarget_=(trained?std::pow(10.,measured.rmsDb/20.):.21)/std::sqrt(std::max(power,.000001));
    }
    double tick(double hz) noexcept {
        fast_+=fastRate_*(effort_-fast_);slow_+=slowRate_*(fast_-slow_);
        direction_*=gestureDecay_;attack_*=attackDecay_;
        spread_+=(spreadTarget_-spread_)*smooth_;sub_+=(subTarget_-sub_)*smooth_;
        normalise_+=(normaliseTarget_-normalise_)*smooth_;
        const double dt=std::clamp(hz/rate_,.000001,.44);
        phase_+=dt;phase_-=2*std::floor(phase_/2);
        const double s=std::sin(tau*phase_),c=2*std::cos(tau*phase_);
        double previous=0,value=s,mid=0,side=0;
        for(int h=0;h<H;++h){
            amp_[h]+=static_cast<float>((target_[h]-amp_[h])*smooth_);
            const double partial=amp_[h]*value;
            mid+=partial;
            // Static harmonic placement: no frequency offset, delay, or moving phase.
            // Fundamental/sub stay centred; L+R always recovers the mono oscillator.
            if(h>0)side+=partial*((h%2)==0?1.:-1.);
            const double next=c*value-previous;previous=value;value=next;
        }
        mid+=sub_*std::sin(tau*.5*phase_);
        side*=.35*spread_;
        right_=normalise_*(mid-side);
        return normalise_*(mid+side);
    }
    double learnedPitchCents() const noexcept {return pitchCents_;}
    double right() const noexcept {return right_;}
    double history() const noexcept {return fast_-slow_;}
private:
    static constexpr int H=character::harmonics;
    static constexpr double tau=6.2831853071795864769;
    template<std::size_t N> static character::Anchor at(const character::Anchor (&nodes)[N],double key) noexcept {
        std::size_t hi=1;while(hi<N-1&&key>nodes[hi].key)++hi;
        const auto& a=nodes[hi-1];const auto& b=nodes[hi];const double mix=std::clamp((key-a.key)/(b.key-a.key),0.,1.);
        character::Anchor out{};out.key=static_cast<float>(key);out.sub=static_cast<float>(a.sub+(b.sub-a.sub)*mix);
        for(int i=0;i<H;++i)out.db[i]=static_cast<float>(a.db[i]+(b.db[i]-a.db[i])*mix);
        return out;
    }
    std::array<float,H> amp_{},target_{};
    double rate_{96000},phase_{0},velocity_{1},direction_{0},attack_{0};
    double fast_{0},slow_{0},fastRate_{0},slowRate_{0},gestureDecay_{0},attackDecay_{0},effort_{0};
    double smooth_{.01},memory_{0},response_{0},spread_{0},spreadTarget_{0},sub_{0},subTarget_{0};
    double normalise_{.2},normaliseTarget_{.2},right_{0};
    double pitchCents_{0};
    const Model* model_{nullptr};Condition condition_{};
    int key_{60},registerKey_{60};
};
}
