#include "SoloVoice.h"
#include <algorithm>
#include <cmath>

namespace silveton::sampler::solo {
namespace {
constexpr double pi=3.14159265358979323846,tau=2*pi;
double unit(double x) noexcept{return std::clamp(x,0.0,1.0);}
// 2:1 low-pass decimator; independently generated for this voice.
constexpr double fir[81]={
    -0.00039859768723934431,
    -0.0006362329621563969,
    -9.8854012450112514e-05,
    0.00066978935628486907,
    0.00041249146816242513,
    -0.00082783374895543504,
    -0.00091607732625151295,
    0.00077499197204881182,
    0.0016192479031389439,
    -0.00044125024953451032,
    -0.0023643332927878219,
    -0.00033918914504630124,
    0.0030389333948828159,
    0.0015819450131951717,
    -0.0033745909251499096,
    -0.003316976461995089,
    0.0031487456007358253,
    0.0053868336265359461,
    -0.0020566416894645368,
    -0.0075820149860010783,
    -0.00010059407968530201,
    0.0095011513813608121,
    0.0034984340001703619,
    -0.01068313517673233,
    -0.0081338230476198804,
    0.010517501510854647,
    0.013900678436738933,
    -0.0083560696714988381,
    -0.020488373910308187,
    0.0034017672165540472,
    0.027483200085031901,
    0.005348957896729495,
    -0.034330977020685771,
    -0.019669931612391132,
    0.040467018233909684,
    0.043824519137197759,
    -0.045317307020578589,
    -0.093688359166991725,
    0.048437754611039691,
    0.31448671231211522,
    0.45124098007367291,
    0.31448671231211522,
    0.048437754611039691,
    -0.093688359166991725,
    -0.045317307020578589,
    0.043824519137197759,
    0.040467018233909684,
    -0.019669931612391132,
    -0.034330977020685771,
    0.005348957896729495,
    0.027483200085031901,
    0.0034017672165540472,
    -0.020488373910308187,
    -0.0083560696714988381,
    0.013900678436738933,
    0.010517501510854647,
    -0.0081338230476198804,
    -0.01068313517673233,
    0.0034984340001703619,
    0.0095011513813608121,
    -0.00010059407968530201,
    -0.0075820149860010783,
    -0.0020566416894645368,
    0.0053868336265359461,
    0.0031487456007358253,
    -0.003316976461995089,
    -0.0033745909251499096,
    0.0015819450131951717,
    0.0030389333948828159,
    -0.00033918914504630124,
    -0.0023643332927878219,
    -0.00044125024953451032,
    0.0016192479031389439,
    0.00077499197204881182,
    -0.00091607732625151295,
    -0.00082783374895543504,
    0.00041249146816242513,
    0.00066978935628486907,
    -9.8854012450112514e-05,
    -0.0006362329621563969,
    -0.00039859768723934431
};
}




void Voice::setParams(const float* p) noexcept {
    for(int i=0;i<Count;++i)target_[static_cast<std::size_t>(i)]=clamp(i,p[i]);
}
void Voice::noteOn(const float* p,double sr,const Inputs& in,std::uint32_t /*seed*/) noexcept {
    *this=Voice{};hostRate_=std::max(8000.,sr);oversample_=sr<=48000?2:1;rate_=hostRate_*oversample_;
    setParams(p);smooth_=target_;inputs_=in;velocity_=unit(in.velocity);
    smoothCoefficient_=1-std::exp(-1/(.004*rate_));
    dcPole_=std::exp(-tau*15/rate_);wheel_=std::max(unit(in.wheel),unit(in.pressure));breath_=unit(in.breath);
    source_.prepare(rate_,in.key,velocity_);
    source_.setRegisterKey(in.registerKey<0?in.key:in.registerKey);
    control(440*std::exp2((in.key-69)/12.));
}
void Voice::setInputs(const Inputs& in,double /*sampleRate*/) noexcept {
    if(inputs_.gate&&!in.gate){phaseAge_=0;stage_=2;releaseStep_=amp_/std::max(1.,(target_[ReleaseMs]>0?target_[ReleaseMs]:5.F)*.001*rate_);}
    if(!inputs_.gate&&in.gate){phaseAge_=0;modelLegato_=false;stage_=0;finished_=false;}
    if(in.gate&&(inputs_.key!=in.key||(in.model&&inputs_.articulation!=in.articulation))){
        interval_=in.key-inputs_.key;phaseAge_=0;modelLegato_=inputs_.gate;source_.note(in.key,in.velocity);
        if(target_[Retrigger]>=.5F){stage_=3;fadeStep_=amp_/std::max(1.,.002*rate_);}
    }
    source_.setRegisterKey(in.registerKey<0?in.key:in.registerKey);
    inputs_=in;
}
void Voice::control(double hz) noexcept {
    Condition q;q.key=static_cast<float>(inputs_.registerKey<0?inputs_.key:inputs_.registerKey);q.ageMs=static_cast<float>(phaseAge_*1000);
    q.velocity=inputs_.commonProcessing?1.F:inputs_.velocity;q.breath=inputs_.breath;q.expression=inputs_.expression;q.wheel=inputs_.wheel;q.pressure=inputs_.pressure;q.interval=static_cast<float>(interval_);
    q.phase=!inputs_.gate?(inputs_.commonProcessing?Phase::Sustain:Phase::Release):modelLegato_&&q.ageMs<250?Phase::Legato:q.ageMs<180?Phase::Attack:Phase::Sustain;
    source_.learned(inputs_.model,q);
    source_.controls(smooth_.data(),hz,breath_,inputs_.pressure);
    gain_=std::pow(10.,smooth_[LevelDb]/20.);
}
float Voice::sample(double baseHz) noexcept {
    if(finished_){sampleRight_=0;return 0;}
    for(int i=0;i<Count;++i) smooth_[static_cast<std::size_t>(i)]+=static_cast<float>((target_[static_cast<std::size_t>(i)]-smooth_[static_cast<std::size_t>(i)])*smoothCoefficient_);
    wheel_+=(std::max(unit(inputs_.wheel),unit(inputs_.pressure))-wheel_)*smoothCoefficient_;
    breath_+=(unit(inputs_.breath)-breath_)*smoothCoefficient_;velocity_+=(unit(inputs_.velocity)-velocity_)*smoothCoefficient_;
    age_+=1/rate_;phaseAge_+=1/rate_;
    vibPhase_+=smooth_[VibratoHz]/rate_;vibPhase_-=std::floor(vibPhase_);
    const double fade=unit((age_-smooth_[VibratoDelayMs]*.001)/.12);
    double hz=std::clamp(baseHz*std::exp2(std::sin(tau*vibPhase_)*(inputs_.commonProcessing?0:wheel_*fade*smooth_[VibratoCents])/1200),8.,hostRate_*.44);
    if(controlCounter_--<=0){control(hz);controlCounter_=inputs_.model?static_cast<int>(rate_/150):63;}
    if(inputs_.model){learnedPitch_+=(source_.learnedPitchCents()-learnedPitch_)*smoothCoefficient_;hz=std::clamp(hz*std::exp2(learnedPitch_/1200),8.,hostRate_*.44);}
    double sound=source_.tick(hz);const double soundRight=source_.right();
    const double dc=sound-dcX_+dcPole_*dcY_;dcX_=sound;dcY_=std::abs(dc)<1e-20?0:dc;
    if(inputs_.commonProcessing){amp_=1;stage_=1;}
    else if(stage_==0){amp_+=1/std::max(1.,std::max(1.F,smooth_[AttackMs])*.001*rate_);if(amp_>=1){amp_=1;stage_=1;}}
    else if(stage_==2){amp_-=releaseStep_;if(amp_<=0){amp_=0;if(!inputs_.model)finished_=true;}}
    else if(stage_==3){amp_-=fadeStep_;if(amp_<=0){amp_=0;stage_=0;}}
    const double gate=target_[BreathMode]>=1.5F?breath_:1;
    double volume=amp_*(.35+.65*velocity_)*gain_*gate;
    if(inputs_.model){
        // Learned levels already describe velocity, controllers and the amplitude envelope.
        // Manual attack/release remain effective as safety/range controls, not a second envelope.
        const double release=std::max(5.F,target_[ReleaseMs])*.001;
        const double envelopeFade=inputs_.gate?unit(phaseAge_/std::max(.001,smooth_[AttackMs]*.001)):unit((release-phaseAge_)/.005);
        volume=gain_*gate*envelopeFade;
        if(!inputs_.gate){finished_=phaseAge_>=release; if(finished_)volume=0;}
    }
    if(inputs_.commonProcessing){volume=gain_;finished_=false;}
    sound=dc*volume;
    const double dr=soundRight-dcRightX_+dcPole_*dcRightY_;dcRightX_=soundRight;dcRightY_=std::abs(dr)<1e-20?0:dr;
    const auto limit=[](double x){return std::abs(x)>.65?std::copysign(.65+.2*std::tanh((std::abs(x)-.65)/.2),x):x;};
    sampleRight_=limit(dr*volume);return static_cast<float>(limit(sound));
}
float Voice::decimate(float x,bool output,bool right) noexcept {
    auto& filter=right?filterRight_:filter_;auto& position=right?filterRightPosition_:filterPosition_;
    filter[static_cast<std::size_t>(position)]=x;const int newest=position;
    if(++position==kTaps)position=0;
    if(!output)return 0;
    double sum=0;for(int i=0;i<kTaps;++i){int j=newest-i;if(j<0)j+=kTaps;sum+=fir[i]*filter[static_cast<std::size_t>(j)];}
    return static_cast<float>(sum);
}
void Voice::tick(double inc,float& left,float& right) noexcept {
    if(!std::isfinite(inc))inc=0;
    if(!pitchReady_){previousIncrement_=inc;pitchReady_=true;}
    float out=0,outRight=0;
    for(int i=0;i<oversample_;++i){
        const double pitch=previousIncrement_+(inc-previousIncrement_)*static_cast<double>(i+1)/oversample_;
        const float raw=sample(pitch*hostRate_);
        if(finished_)++tailSamples_;
        out=oversample_==1?raw:decimate(raw,i+1==oversample_);
        outRight=oversample_==1?static_cast<float>(sampleRight_):decimate(static_cast<float>(sampleRight_),i+1==oversample_,true);
    }
    previousIncrement_=inc;
    if(!std::isfinite(out)||!std::isfinite(outRight)){out=outRight=0;finished_=true;}
    {
        // Rare reconstruction overshoot at extreme level/parameter changes.
        // The normal reference level is below this knee and stays linear.
        const auto guard=[](float x){return std::abs(x)>.9F?std::copysign(.9F+.1F*std::tanh((std::abs(x)-.9F)/.1F),x):x;};
        out=guard(out);outRight=guard(outRight);
    }
    left=out;right=outRight;
}
}
