// SILVETON_SOLO_V1 - the voice of SILVETON SOLO (see SoloVoice.h).
#include "SoloVoice.h"

#include <algorithm>

namespace silveton::sampler::solo {

namespace {

constexpr double kTwoPi = 6.283185307179586;
constexpr int kSinTab = 1024;

inline float clampf(float x, float lo, float hi) noexcept { return x < lo ? lo : (x > hi ? hi : x); }
inline float flush(float x) noexcept { return std::fabs(x) < 1.0e-20F ? 0.0F : x; }
inline float tanhF(float x) noexcept {   // rational tanh, never above 1
    if (x > 3.0F) return 1.0F;
    if (x < -3.0F) return -1.0F;
    const float x2 = x * x;
    return x * (27.0F + x2) / (27.0F + 9.0F * x2);
}
inline float soft(float x) noexcept {   // straight up to 0.9, then bends to 1
    const float a = std::fabs(x);
    if (a <= 0.9F) return x;
    const float y = 0.9F + 0.1F * tanhF((a - 0.9F) * 10.0F);
    return x < 0.0F ? -y : y;
}
const float* sineTable() noexcept {
    static const auto t = [] {
        static float s[kSinTab + 1];
        for (int i = 0; i <= kSinTab; ++i) s[i] = static_cast<float>(std::sin(kTwoPi * i / kSinTab));
        return s;
    }();
    return t;
}
inline float sinT(double ph) noexcept {   // sine of a phase 0..1
    ph -= std::floor(ph);
    const float* s = sineTable();
    const double x = ph * kSinTab;
    const int i = static_cast<int>(x);
    const float f = static_cast<float>(x - i);
    return s[i] + (s[i + 1] - s[i]) * f;
}
inline float cosT(double ph) noexcept { return sinT(ph + 0.25); }
// the PolyBLEP correction of a step at phase 0 (dt = the phase increment): the band-limited saw and pulse
inline float blep(double t, double dt) noexcept {
    if (t < dt) { const float x = static_cast<float>(t / dt); return x + x - x * x - 1.0F; }
    if (t > 1.0 - dt) { const float x = static_cast<float>((t - 1.0) / dt); return x * x + x + x + 1.0F; }
    return 0.0F;
}
inline std::uint32_t lcg(std::uint32_t& s) noexcept { s = s * 1664525U + 1013904223U; return s; }
inline float noiseOf(std::uint32_t& s) noexcept { return static_cast<float>(lcg(s) >> 8) / 8388608.0F - 1.0F; }
inline float coefFor(float ms, double sr, float divisor) noexcept {   // one-pole coefficient: the move is over in `ms`
    const double tau = std::max(static_cast<double>(ms), 0.05) / 1000.0 / static_cast<double>(divisor);
    return static_cast<float>(1.0 - std::exp(-1.0 / (tau * sr)));
}

}  // namespace

// ---------------------------------------------------------------- the envelope
void Env::setTimes(float aMs, float dMs, float s01, float rMs, double sr) noexcept {
    aCoef = coefFor(aMs, sr, 1.79F);   // aims at 1.2: reaches 1.0 in aMs
    dCoef = coefFor(dMs, sr, 3.0F);
    rCoef = coefFor(rMs, sr, 3.0F);
    sus = clampf(s01, 0.0F, 1.0F);
}

float Env::tick() noexcept {
    switch (stage) {
        case Attack:
            level += (1.2F - level) * aCoef;
            if (level >= 1.0F) { level = 1.0F; stage = Decay; }
            break;
        case Decay:
            level += (sus - level) * dCoef;
            if (std::fabs(level - sus) < 1.0e-4F) { level = sus; stage = Sustain; }
            break;
        case Sustain:
            level = sus;
            break;
        case Release:
            level += (0.0F - level) * rCoef;
            if (level < 2.0e-3F) { level = 0.0F; stage = Done; }   // -54 dB: quiet enough to end, the voice is free sooner
            break;
        default: level = 0.0F; break;
    }
    return level;
}

// ---------------------------------------------------------------- the filters
void Ladder::set(float hz, float res, double sr) noexcept {
    hz = clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F);
    g = 1.0F - std::exp(-static_cast<float>(kTwoPi) * hz / static_cast<float>(sr));
    k = 3.95F * clampf(res, 0.0F, 1.0F);
}
float Ladder::run(float x, float drive) noexcept {
    const float in = tanhF((x - k * s[3]) * (1.0F + drive * 3.0F));
    s[0] = flush(s[0] + g * (in - tanhF(s[0])));
    s[1] = flush(s[1] + g * (tanhF(s[0]) - tanhF(s[1])));
    s[2] = flush(s[2] + g * (tanhF(s[1]) - tanhF(s[2])));
    s[3] = flush(s[3] + g * (tanhF(s[2]) - tanhF(s[3])));
    return s[3] * (1.0F + 0.12F * k);   // the resonance takes a little of the bass: a touch given back
}
void Svf::set(float hz, float res, double sr) noexcept {
    hz = clampf(hz, 10.0F, static_cast<float>(sr) * 0.45F);
    const float gg = std::tan(static_cast<float>(kTwoPi * 0.5) * hz / static_cast<float>(sr));
    k = 1.0F / std::max(0.5F + res * res * 19.5F, 0.3F);
    a1 = 1.0F / (1.0F + gg * (gg + k)); a2 = gg * a1; a3 = gg * a2;
}
float Svf::run(float x, int type) noexcept {
    const float v3 = x - ic2;
    const float v1 = a1 * ic1 + a2 * v3;
    const float v2 = ic2 + a2 * ic1 + a3 * v3;
    ic1 = flush(2.0F * v1 - ic1); ic2 = flush(2.0F * v2 - ic2);
    const float bp = v1, hp = x - k * v1 - v2;
    switch (type) {
        case FL_HP12: return hp;
        case FL_BP12: return bp * k;
        default: return v2;
    }
}

// ---------------------------------------------------------------- the life of a note
// ---------------------------------------------------------------- the comb (SILVETON_SOLO_V2)
void Comb::reset() noexcept { std::fill(buf, buf + kLen, 0.0F); w = 0; lp = 0.0F; }

float Comb::run(float x, float delay, float fb) noexcept {
    delay = clampf(delay, 2.0F, static_cast<float>(kLen - 3));
    float rp = static_cast<float>(w) - delay; if (rp < 0.0F) rp += static_cast<float>(kLen);
    const int i0 = static_cast<int>(rp);
    const float fr = rp - static_cast<float>(i0);
    const int i1 = i0 + 1 >= kLen ? 0 : i0 + 1;
    const float d = buf[i0] + (buf[i1] - buf[i0]) * fr;
    lp = flush(lp + 0.5F * (d - lp));            // the low-pass in the loop: the high harmonics ring shorter (a string)
    const float y = x + fb * lp;
    buf[w] = y; if (++w >= kLen) w = 0;
    return y * (1.0F - 0.8F * fb);               // the resonance does not run away in loudness
}

void Voice::noteOn(const float* params, double sampleRate, const Inputs& in, std::uint32_t seed) noexcept {
    p_ = params; sr_ = sampleRate; in_ = in; key_ = in.key;
    finished_ = false; killing_ = false; killGain_ = 1.0F; peak_ = 0.0F; pos_ = kChunk;
    rng_ = seed | 1U;
    age_ = 0.0F; lfoPh_ = 0.0; pwmPh_ = 0.0;
    // ANALOG: small differences of this note (pitch, cutoff), the same for its whole life
    const float an = clampf(p_[E_ANALOG], 0.0F, 1.0F);
    analogDet_ = noiseOf(rng_) * an * 4.0F;      // cents
    analogCut_ = noiseOf(rng_) * an * 0.12F;     // octaves
    for (int u = 0; u < kUnisonMax; ++u) {
        Uni& U = uni_[static_cast<std::size_t>(u)];
        U.ladder.reset(); U.svf.reset(); U.dcX = U.dcY = 0.0F;
        U.ph1 = static_cast<double>(noiseOf(rng_) * 0.5F + 0.5F) * (u == 0 ? 0.0 : 1.0);   // the first copy starts clean, the others spread
        U.ph2 = U.ph1; U.phSub = 0.0; U.phM1 = U.phM2 = 0.0;
    }
    wave1_ = wave2_ = -1;   // the first control() sees the waves as new (a COMB starts from a silent line)
    ampEnv_ = Env{}; filtEnv_ = Env{}; dcwEnv_ = Env{};
    ampEnv_.trigger(); filtEnv_.trigger(); dcwEnv_.trigger();
    gainNow_ = 0.0F; gainTick_ = 0.0F; dcwNow_ = 0.0F; dcwTick_ = 0.0F;
    lvl1_ = lvl2_ = lvlSub_ = lvlNoise_ = -1.0F;   // -1: the first chunk takes the levels at once
    pw_ = -1.0F;
    cutHz_ = -1.0F; res_ = clampf(p_[E_RESO], 0.0F, 1.0F);
}

void Voice::setInputs(const Inputs& in, double sampleRate) noexcept {
    sr_ = sampleRate;
    const bool wasGate = in_.gate;
    in_ = in;
    if (wasGate && !in.gate) { ampEnv_.release(); filtEnv_.release(); dcwEnv_.release(); }
    if (in.gate && in.key != key_) key_ = in.key;   // LEGATO: the same voice goes to a new key - no new attack, the pitch comes with `inc`
}

// ---------------------------------------------------------------- the knobs -> the chunk
void Voice::control(double inc) noexcept {
    const float* p = p_;
    const float chunkSec = static_cast<float>(kChunk) / static_cast<float>(sr_);
    age_ += chunkSec;
    // envelopes
    ampEnv_.setTimes(p[SO_AMP_A], p[SO_AMP_D], p[SO_AMP_S], p[SO_AMP_R], sr_);
    filtEnv_.setTimes(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], sr_);
    dcwEnv_.setTimes(p[SO_DCW_A], p[SO_DCW_D], p[SO_DCW_S], p[SO_DCW_R], sr_);
    releaseSec_ = std::max(p[SO_AMP_R], 1.0F) / 1000.0F;
    // the oscillators
    const int w1 = std::clamp(static_cast<int>(p[SO_OSC1_WAVE] + 0.5F), 0, kWaves - 1);
    const int w2 = std::clamp(static_cast<int>(p[SO_OSC2_WAVE] + 0.5F), 0, kWaves - 1);
    if (w1 != wave1_ && w1 == W_COMB) for (auto& U : uni_) U.comb1.reset();   // SILVETON_SOLO_V2: a comb begins silent
    if (w2 != wave2_ && w2 == W_COMB) for (auto& U : uni_) U.comb2.reset();
    wave1_ = w1; wave2_ = w2;
    ratio_ = clampf(p[SO_RATIO], 0.25F, 16.0F);
    sync_ = p[SO_SYNC] >= 0.5F;
    oct1_ = std::exp2(static_cast<double>(std::clamp(std::round(p[SO_OSC1_OCT]), -2.0F, 2.0F)) + static_cast<double>(analogDet_) / 1200.0);
    oct2_ = std::exp2(static_cast<double>(std::clamp(std::round(p[SO_OSC2_OCT]), -2.0F, 2.0F)) +
                      (static_cast<double>(std::clamp(p[SO_OSC2_SEMI], -12.0F, 12.0F)) + static_cast<double>(clampf(p[SO_OSC2_FINE], -50.0F, 50.0F) + analogDet_) / 100.0) / 12.0);
    // PWM: the width swings around the knob
    pwmPh_ += static_cast<double>(clampf(p[SO_PWM_RATE], 0.05F, 20.0F)) * chunkSec;
    pwmPh_ -= std::floor(pwmPh_);
    const float pwBase = clampf(p[SO_PW], 0.05F, 0.95F);
    pwT_ = clampf(pwBase + 0.42F * clampf(p[SO_PWM_DEPTH], 0.0F, 1.0F) * sinT(pwmPh_), 0.05F, 0.95F);
    if (pw_ < 0.0F) pw_ = pwT_;
    // levels (ramped over the chunk)
    lvl1T_ = clampf(p[SO_OSC1_LEVEL], 0.0F, 1.0F); lvl2T_ = clampf(p[SO_OSC2_LEVEL], 0.0F, 1.0F);
    lvlSubT_ = clampf(p[SO_SUB_LEVEL], 0.0F, 1.0F); lvlNoiseT_ = clampf(p[SO_NOISE_LEVEL], 0.0F, 1.0F) * 0.5F;
    if (lvl1_ < 0.0F) { lvl1_ = lvl1T_; lvl2_ = lvl2T_; lvlSub_ = lvlSubT_; lvlNoise_ = lvlNoiseT_; }
    drive_ = clampf(p[E_DRIVE], 0.0F, 1.0F);
    outDrive_ = clampf(p[SO_OUT_DRIVE], 0.0F, 1.0F);
    width_ = clampf(p[SO_WIDTH], 0.0F, 1.0F);
    // unison: the copies, their detune and their place in the stereo picture
    const int n = std::clamp(static_cast<int>(p[E_UNISON] + 0.5F), 1, kUnisonMax);
    nUni_ = n;
    const float det = clampf(p[E_UNI_DET], 0.0F, 60.0F), spread = clampf(p[E_UNI_SPREAD], 0.0F, 1.0F);
    for (int u = 0; u < n; ++u) {
        Uni& U = uni_[static_cast<std::size_t>(u)];
        const float off = n == 1 ? 0.0F : (static_cast<float>(u) / static_cast<float>(n - 1)) * 2.0F - 1.0F;   // -1..1
        U.detune = std::exp2(off * det / 1200.0F);
        const float pan = off * spread;   // -1..1
        U.panL = std::cos((pan + 1.0F) * 0.78539816F); U.panR = std::sin((pan + 1.0F) * 0.78539816F);
    }
    // vibrato: the LFO, its depth from the knob, the wheel and the pressure, after the delay
    const float delaySec = clampf(p[SO_VIB_DELAY], 0.0F, 3000.0F) / 1000.0F;
    const float fade = age_ < delaySec ? 0.0F : clampf((age_ - delaySec) / 0.35F, 0.0F, 1.0F);
    const float depth = clampf(p[E_LFO_PITCH], 0.0F, 200.0F) * fade + clampf(p[SO_VIB_WHEEL], 0.0F, 200.0F) * clampf(in_.wheel, 0.0F, 1.0F) +
                        clampf(p[SO_VIB_AT], 0.0F, 200.0F) * clampf(in_.pressure, 0.0F, 1.0F);
    vibInc_ = clampf(p[E_LFO_RATE], 0.5F, 12.0F) / static_cast<float>(sr_);
    vibCents_ = depth;
    // the filter: cutoff follows the key, the envelope, the velocity, the vibrato
    const float fenv = filtEnv_.level;
    const float lfoNow = sinT(lfoPh_);
    float oct = clampf(p[E_KEYTRACK], -1.0F, 1.0F) * static_cast<float>(key_ - 60) / 12.0F +
                clampf(p[E_FEG_AMT], -8.0F, 8.0F) * fenv +
                clampf(p[E_VEL_CUT], 0.0F, 8.0F) * clampf(in_.velocity, 0.0F, 1.0F) +
                clampf(p[E_LFO_CUT], 0.0F, 4.0F) * lfoNow * fade + analogCut_;
    const float cutTarget = clampf(clampf(p[E_CUTOFF], 20.0F, 20000.0F) * std::exp2(oct), 20.0F, 20000.0F);
    // the cutoff glides between chunks (a knob jump is spread over a few milliseconds: no step in the sound)
    cutHz_ = cutHz_ <= 0.0F ? cutTarget : std::exp(std::log(cutHz_) + (std::log(cutTarget) - std::log(cutHz_)) * 0.45F);
    res_ += (clampf(p[E_RESO], 0.0F, 1.0F) - res_) * 0.45F;
    filtType_ = std::clamp(static_cast<int>(p[E_FILT_TYPE] + 0.5F), 0, kFilters - 1);
    for (int u = 0; u < n; ++u) {
        Uni& U = uni_[static_cast<std::size_t>(u)];
        if (filtType_ == FL_LADDER24) U.ladder.set(cutHz_, res_, sr_);
        else if (filtType_ != FL_OFF) U.svf.set(cutHz_, res_, sr_);
    }
    // the CZ shape: the knob x its envelope, less up the keyboard, more with the velocity
    const float keyFall = 1.0F - clampf(p[SO_DCW_KEY], 0.0F, 1.0F) * clampf(static_cast<float>(key_ - 48) / 48.0F, 0.0F, 1.0F) * 0.75F;
    const float velUp = 1.0F - clampf(p[SO_DCW_VEL], 0.0F, 1.0F) * (1.0F - clampf(in_.velocity, 0.0F, 1.0F));
    const float dcwTarget = clampf(p[SO_DCW], 0.0F, 1.0F) * dcwEnv_.level * keyFall * velUp;
    dcwTick_ = (dcwTarget - dcwNow_) / static_cast<float>(kChunk);
    // the velocity to the level
    const float va = clampf(p[SO_VEL_AMP], 0.0F, 1.0F);
    velGain_ = 1.0F - va + va * clampf(in_.velocity, 0.0F, 1.0F);
    (void)inc;
}

// one sample of one oscillator: wave, phase (advanced here), the phase of its second tone, its comb, its increment, the pulse width, SHAPE
float Voice::oscillator(int wave, double& ph, double& phM, Comb& comb, double inc, float pw, float dcw, bool syncReset) noexcept {
    if (syncReset) { ph = 0.0; phM = 0.0; }
    ph += inc;
    if (ph >= 1.0) ph -= std::floor(ph);
    const double dt = std::min(inc, 0.5);
    const auto pulse = [&](float width) noexcept {
        float y = ph < static_cast<double>(width) ? 1.0F : -1.0F;
        y += blep(ph, dt);
        double t2 = ph - static_cast<double>(width); if (t2 < 0.0) t2 += 1.0;
        y -= blep(t2, dt);
        return y;
    };
    switch (wave) {
        case W_SAW: return static_cast<float>(2.0 * ph - 1.0) - blep(ph, dt);
        case W_PULSE: return pulse(pw);
        case W_TRI: return static_cast<float>(4.0 * std::fabs(ph - 0.5) - 1.0);
        case W_SINE: return sinT(ph);
        case W_CZ_SAW: {   // the first half of the cosine is pressed into a short piece of the period: the sine becomes a saw
            const double k = 0.5 * (1.0 - 0.97 * static_cast<double>(dcw));
            const double phi = ph < k ? 0.5 * ph / k : 0.5 + 0.5 * (ph - k) / (1.0 - k);
            return -cosT(phi);
        }
        case W_CZ_PULSE: {   // the whole cosine runs in a part of the period and then rests: a pulse whose width is ШИРИНА
            const double w = std::min(1.0, std::max(0.06, 1.0 - 0.94 * static_cast<double>(dcw)) * (0.5 + static_cast<double>(pw)));
            return -cosT(std::min(ph / w, 1.0));
        }
        case W_CZ_RES1: case W_CZ_RES2: {   // a faster cosine, started again every period, under a window: a resonance that the shape knob moves
            const double f0 = inc * sr_;
            const double nMax = std::max(0.0, (sr_ * 0.22) / std::max(f0, 1.0) - 1.0);
            const double n = std::min(8.0 * static_cast<double>(dcw), nMax);
            const float win = wave == W_CZ_RES1 ? static_cast<float>(1.0 - ph) : static_cast<float>(1.0 - std::fabs(2.0 * ph - 1.0));
            return cosT(ph * (1.0 + n)) * win;
        }
        // SILVETON_SOLO_V2
        case W_VPM: {   // a sine whose phase a second sine (at RATIO) pushes back and forth: FM-like bite, SHAPE = how far (less up high: no aliasing)
            phM += inc * static_cast<double>(ratio_); if (phM >= 1.0) phM -= std::floor(phM);
            const double f0 = inc * sr_;
            const float lim = static_cast<float>(std::min(1.0, 3500.0 / std::max(f0, 1.0)));
            const float d = 0.5F * dcw * lim;   // in cycles: 0.5 = about 3 radians
            return sinT(ph + static_cast<double>(d * sinT(phM)));
        }
        case W_COMB: {   // the pulse (PULSE WIDTH) rings in a comb tuned to RATIO x the note; SHAPE = the feedback
            const double fc = std::max(inc * static_cast<double>(ratio_) * sr_, 1.0);
            const float delay = static_cast<float>(sr_ / fc) - 1.0F;   // minus the loop's low-pass (one sample)
            return comb.run(pulse(pw) * 0.9F, delay, 0.985F * dcw);
        }
        case W_RING: {   // a sine times a second sine at RATIO (1 = octave up and hollow, 1.5 = bell, 2 = odd harmonics); SHAPE = the mix
            phM += inc * static_cast<double>(ratio_); if (phM >= 1.0) phM -= std::floor(phM);
            const float s = sinT(ph);
            return s * ((1.0F - dcw) + dcw * sinT(phM));
        }
        default: return 0.0F;
    }
}

// ---------------------------------------------------------------- one sample
void Voice::tick(double inc, float& l, float& r) noexcept {
    if (p_ == nullptr || finished_) { l = r = 0.0F; return; }
    if (pos_ >= kChunk) { control(inc); pos_ = 0; }
    ++pos_;
    // envelopes, vibrato
    const float amp = ampEnv_.tick();
    filtEnv_.tick();
    dcwEnv_.tick();
    lfoPh_ += vibInc_; if (lfoPh_ >= 1.0) lfoPh_ -= 1.0;
    const double vib = vibCents_ > 0.0F ? std::exp2(static_cast<double>(vibCents_ * sinT(lfoPh_)) / 1200.0) : 1.0;
    dcwNow_ += dcwTick_;
    const float dcw = clampf(dcwNow_, 0.0F, 1.0F);
    // the knobs that ramp inside the chunk
    const float step = 1.0F / static_cast<float>(kChunk);
    lvl1_ += (lvl1T_ - lvl1_) * step; lvl2_ += (lvl2T_ - lvl2_) * step; lvlSub_ += (lvlSubT_ - lvlSub_) * step; lvlNoise_ += (lvlNoiseT_ - lvlNoise_) * step;
    pw_ += (pwT_ - pw_) * step;
    const float noise = lvlNoise_ > 0.0F ? noiseOf(rng_) * lvlNoise_ : 0.0F;
    const double base = std::fabs(inc) * vib;
    float outL = 0.0F, outR = 0.0F;
    const float norm = 1.0F / std::sqrt(static_cast<float>(nUni_));
    for (int u = 0; u < nUni_; ++u) {
        Uni& U = uni_[static_cast<std::size_t>(u)];
        const double inc1 = base * oct1_ * static_cast<double>(U.detune);
        const double inc2 = base * oct2_ * static_cast<double>(U.detune);
        const double before = U.ph1;
        const float o1 = oscillator(wave1_, U.ph1, U.phM1, U.comb1, inc1, pw_, dcw, false);
        const bool wrapped = U.ph1 < before;   // oscillator 1 began a new period: the sync point
        const float o2 = lvl2_ > 0.0F ? oscillator(wave2_, U.ph2, U.phM2, U.comb2, inc2, pw_, dcw, sync_ && wrapped) : 0.0F;
        float sub = 0.0F;
        if (lvlSub_ > 0.0F) {
            U.phSub += inc1 * 0.5; if (U.phSub >= 1.0) U.phSub -= 1.0;
            sub = U.phSub < 0.5 ? 1.0F : -1.0F;
            const double dt = std::min(inc1 * 0.5, 0.5);
            sub += blep(U.phSub, dt);
            double t2 = U.phSub - 0.5; if (t2 < 0.0) t2 += 1.0;
            sub -= blep(t2, dt);
        }
        float x = o1 * lvl1_ + o2 * lvl2_ + sub * lvlSub_ + noise;
        if (drive_ > 0.0F) x = tanhF(x * (1.0F + 4.0F * drive_)) / (1.0F + 1.2F * drive_);
        if (filtType_ == FL_LADDER24) x = U.ladder.run(x, drive_);
        else if (filtType_ != FL_OFF) x = U.svf.run(x, filtType_);
        // a 5 Hz DC blocker (the CZ resonance waves carry an offset)
        const float yd = x - U.dcX + 0.9993F * U.dcY; U.dcX = x; U.dcY = flush(yd);
        outL += yd * U.panL; outR += yd * U.panR;
    }
    const float g = amp * velGain_ * norm;
    outL *= g; outR *= g;
    // width, drive, the soft limit
    float mid = 0.5F * (outL + outR), side = 0.5F * (outL - outR) * width_ * 2.0F;
    l = mid + side; r = mid - side;
    if (outDrive_ > 0.0F) { const float dk = 1.0F + 5.0F * outDrive_; const float nm = 0.7F / tanhF(dk * 0.7F); l = tanhF(l * dk) * nm; r = tanhF(r * dk) * nm; }
    l = soft(l); r = soft(r);
    if (killing_) { killGain_ *= static_cast<float>(std::exp(-1.0 / (0.004 * sr_))); l *= killGain_; r *= killGain_; }
    if (!std::isfinite(l) || !std::isfinite(r)) {   // the guard: start from silence
        l = r = 0.0F;
        for (auto& U : uni_) { U.ladder.reset(); U.svf.reset(); U.dcX = U.dcY = 0.0F; U.comb1.reset(); U.comb2.reset(); }
    }
    peak_ = std::max(std::max(std::fabs(l), std::fabs(r)), peak_ * 0.9995F);
    if (!in_.gate && ampEnv_.done()) finished_ = true;
    if (killing_ && killGain_ < 1.0e-4F) finished_ = true;
}

} // namespace silveton::sampler::solo
