#pragma once
#include "silveton/sampler/SoloDefs.h"
#include "SoloSource.h"
#include <array>
#include <cstdint>
namespace silveton::sampler::solo {
struct Inputs {bool commonProcessing{false};int key{60};bool gate{true};float velocity{1},wheel{0},pressure{0},breath{0};int registerKey{-1};float expression{1};const Model* model{nullptr};std::uint32_t articulation{0};};
class Voice {
public:
 void noteOn(const float*,double,const Inputs&,std::uint32_t) noexcept;
 void setParams(const float*) noexcept;
 void setInputs(const Inputs&,double) noexcept;
 void tick(double,float&,float&) noexcept;
 bool finished() const noexcept {return finished_&&(oversample_==1||tailSamples_>=kTaps);}
private:
 void control(double) noexcept;float sample(double) noexcept;
 std::array<float,Count> target_{},smooth_{};Inputs inputs_{};Source source_{};
 double hostRate_{48000},rate_{96000},vibPhase_{0},age_{0};
 double gain_{.5},smoothCoefficient_{.01},amp_{0},releaseStep_{0},fadeStep_{0};
 double wheel_{0},breath_{0},velocity_{1},dcX_{0},dcY_{0},dcPole_{.999};
 double learnedPitch_{0};double phaseAge_{0};int interval_{0};bool modelLegato_{false};
 double previousIncrement_{0},sampleRight_{0},dcRightX_{0},dcRightY_{0};
 int oversample_{2},controlCounter_{0},stage_{0};bool finished_{false},pitchReady_{false};
 static constexpr int kTaps=81;std::array<float,kTaps> filter_{},filterRight_{};
 int filterPosition_{0},filterRightPosition_{0},tailSamples_{0};
 float decimate(float,bool,bool=false) noexcept;
};
}
