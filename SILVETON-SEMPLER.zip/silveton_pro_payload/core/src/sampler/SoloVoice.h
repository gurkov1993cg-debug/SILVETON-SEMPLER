#pragma once
// SILVETON_SOLO_V1 - one voice (one note) of SILVETON SOLO. The sound is made here: two oscillators with up to four unison copies,
// the sub and the noise, the filter, the three envelopes, the vibrato, the drive. Real-time rules: no allocation, no locks, every
// buffer is inside the voice; a NaN / Inf starts the voice from silence. Our own calculation throughout (see SoloDefs.h).
#include "silveton/sampler/SoloDefs.h"

#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::sampler::solo {

// what the voice needs to know about the player, once per audio block
struct Inputs {
    float velocity{1.0F};   // 0..1
    int key{60};
    bool gate{true};        // the key is held (or the pedal holds it)
    float wheel{0.0F};      // 0..1 the modulation wheel
    float pressure{0.0F};   // 0..1 aftertouch
};

constexpr int kChunk = 32;        // the control rate: the knobs are read every 32 samples
constexpr int kUnisonMax = 4;

// an ADSR envelope: the attack aims above 1 and is cut at 1 (the firm start of an analog envelope), decay and release fall exponentially
struct Env {
    enum Stage : int { Attack = 0, Decay, Sustain, Release, Done };
    int stage{Done};
    float level{0.0F};
    float aCoef{0.1F}, dCoef{0.01F}, rCoef{0.01F}, sus{1.0F};
    void setTimes(float aMs, float dMs, float sMs01, float rMs, double sr) noexcept;
    void trigger() noexcept { stage = Attack; }
    void release() noexcept { if (stage != Done) stage = Release; }
    [[nodiscard]] bool done() const noexcept { return stage == Done; }
    float tick() noexcept;
};

struct Ladder {   // 24 dB low-pass, four one-poles with feedback and soft saturation in the loop (our own simple model)
    float s[4]{0.0F, 0.0F, 0.0F, 0.0F};
    float g{0.1F}, k{0.0F};
    void set(float hz, float res, double sr) noexcept;
    float run(float x, float drive) noexcept;
    void reset() noexcept { s[0] = s[1] = s[2] = s[3] = 0.0F; }
};

// SILVETON_SOLO_V2: the tuned comb of the COMB wave - a delay of one period (of RATIO x the note) fed back through a one-pole
// low-pass: the pulse that goes in rings like a plucked string; SHAPE is the feedback. The pitch stays the pulse's.
struct Comb {
    static constexpr int kLen = 4096;
    float buf[kLen];
    int w{0};
    float lp{0.0F};
    void reset() noexcept;
    float run(float x, float delay, float fb) noexcept;   // delay in samples (2 .. kLen - 3), fb 0 .. 0.99
};

struct Svf {   // state-variable 12 dB: low / high / band from one pass (trapezoidal)
    float ic1{0.0F}, ic2{0.0F};
    float a1{0.0F}, a2{0.0F}, a3{0.0F}, k{1.0F};
    void set(float hz, float res, double sr) noexcept;
    float run(float x, int type) noexcept;   // type: FL_LP12 / FL_HP12 / FL_BP12
    void reset() noexcept { ic1 = ic2 = 0.0F; }
};

class Voice {
public:
    void noteOn(const float* params, double sampleRate, const Inputs& in, std::uint32_t seed) noexcept;
    void setParams(const float* params) noexcept { p_ = params; }
    void setInputs(const Inputs& in, double sampleRate) noexcept;   // once per block: key off = release; a new key while held = legato (no new attack)
    void tick(double inc, float& l, float& r) noexcept;              // one sample; inc = cycles per sample of the note (glide, bend ... included)
    [[nodiscard]] bool finished() const noexcept { return finished_; }
    [[nodiscard]] float releaseSeconds() const noexcept { return releaseSec_; }
    [[nodiscard]] bool gateOn() const noexcept { return in_.gate; }
    [[nodiscard]] float lastPeak() const noexcept { return peak_; }
    void panicFade() noexcept { killing_ = true; }

private:
    struct Uni {
        double ph1{0.0}, ph2{0.0}, phSub{0.0};
        double phM1{0.0}, phM2{0.0};   // SILVETON_SOLO_V2: the second tone of VPM / RING (its own phase: RATIO can be a fraction)
        Comb comb1, comb2;
        float detune{1.0F};      // the pitch factor of this copy
        float panL{0.7071F}, panR{0.7071F};
        Ladder ladder;
        Svf svf;
        float dcX{0.0F}, dcY{0.0F};
    };
    void control(double inc) noexcept;   // every kChunk samples: the knobs become the numbers of the chunk
    float oscillator(int wave, double& ph, double& phM, Comb& comb, double inc, float pw, float shape, bool syncReset) noexcept;

    const float* p_{nullptr};
    double sr_{48000.0};
    Inputs in_{};
    int key_{60};
    bool finished_{false}, killing_{false};
    float killGain_{1.0F};
    float peak_{0.0F};
    float releaseSec_{0.2F};
    std::uint32_t rng_{1U};
    int pos_{kChunk};
    // the copies
    std::array<Uni, kUnisonMax> uni_{};
    int nUni_{1};
    // envelopes and the LFO
    Env ampEnv_, filtEnv_, dcwEnv_;
    double lfoPh_{0.0};
    float age_{0.0F};            // seconds since the note began (the vibrato delay)
    double pwmPh_{0.0};
    // the numbers of the chunk (smoothed where a step would click)
    float lvl1_{0.0F}, lvl2_{0.0F}, lvlSub_{0.0F}, lvlNoise_{0.0F}, lvl1T_{0.0F}, lvl2T_{0.0F}, lvlSubT_{0.0F}, lvlNoiseT_{0.0F};
    float pw_{0.5F}, pwT_{0.5F}, drive_{0.0F}, outDrive_{0.0F}, width_{1.0F};
    float cutHz_{1000.0F}, res_{0.0F};
    int filtType_{1};
    int wave1_{-1}, wave2_{-1};
    float ratio_{1.0F};
    bool sync_{false};
    double oct1_{1.0}, oct2_{1.0};
    float dcwBase_{0.0F}, vibCents_{0.0F}, velGain_{1.0F};
    float analogDet_{0.0F}, analogCut_{0.0F};
    float dcwNow_{0.0F}, dcwTick_{0.0F};
    float gainNow_{0.0F}, gainTick_{0.0F};   // amp env x velocity, ramped inside the chunk
    float vibInc_{0.0F};
};

} // namespace silveton::sampler::solo
