// SILVETON_SUSE_V1 - the numbers of SILVETON SYNTH: what each id is, its range, its start value (see SuseDefs.h).
#include "silveton/sampler/SuseDefs.h"

#include <algorithm>

namespace silveton::sampler::suse {

namespace {

constexpr int kDestSlotOfOffset[kGenStride] = {
    // 0..14: the choices (not targets)
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    0 /*LEVEL 15*/, 1 /*PAN 16*/, 3 /*FINE 17*/, -1 /*RATIO 18*/, -1 /*FIXHZ 19*/, 7 /*PHASE 20*/, 4 /*FCUT 21*/, 5 /*FRES 22*/,
    -1 /*VELLEV 23*/, 6 /*UNIDET 24*/, -1, -1, -1, -1, -1,
    8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, -1, -1, -1};

void set(float* p, int id, float v) noexcept { p[id] = v; }

}  // namespace

int destSlotOfOffset(int off) noexcept { return off >= 0 && off < kGenStride ? kDestSlotOfOffset[off] : -1; }

const char* methodName(int m) noexcept {
    static const char* const n[kMethods] = {"ИЗКЛ.", "ВЪЛНА", "ХАРМОНИЦИ", "СТРУНА", "ДУХОВ", "УДАРНО ТЯЛО", "ШУМ", "ЗЪРНА", "СПЕКТЪР"};
    return n[std::clamp(m, 0, kMethods - 1)];
}

Dest destOf(int k) noexcept {
    k = std::clamp(k, 0, kDestCount - 1);
    if (k < kDestFilterBase) {
        const int g = k / kDestPerGen, s = k % kDestPerGen;
        static constexpr int off[kDestPerGen] = {GN_LEVEL, GN_PAN, -1, GN_FINE, GN_FCUT, GN_FRES, GN_UNIDET, GN_PHASE,
                                                 GN_F0, GN_F0 + 1, GN_F0 + 2, GN_F0 + 3, GN_F0 + 4, GN_F0 + 5, GN_F0 + 6, GN_F0 + 7,
                                                 GN_F0 + 8, GN_F0 + 9, GN_F0 + 10, GN_F0 + 11, GN_F0 + 12, GN_F0 + 13};
        if (s == 2) return {-1, g};
        return {genId(g, off[s]), -1};
    }
    if (k < kDestLfoBase) {
        const int i = k - kDestFilterBase, f = i / 4, s = i % 4;
        static constexpr int off[4] = {FL_CUT, FL_RES, FL_DRIVE, FL_VOWEL};
        return {filterId(f, off[s]), -1};
    }
    if (k < kDestGlobalBase) return {lfoId(k - kDestLfoBase, LF_RATE), -1};
    if (k < kDestAllPitch) {
        static constexpr int g[4] = {G_LEVEL, G_VIB_DEPTH, G_TREM_DEPTH, G_WIDTH};
        return {g[k - kDestGlobalBase], -1};
    }
    return {-1, kGens};
}

ParamInfo paramInfo(int id) noexcept {
    if (id < 0 || id >= kParamCount) return {0.0F, 0.0F, 0.0F, false};
    if (id < kGenBase) {
        switch (id) {
            case G_QUALITY: case G_FILTER_LINK: case G_RETRIG: case G_KEEP_RES: case G_VIB_WHEEL: return {0.0F, 1.0F, 0.0F, true};
            case G_PRIORITY: return {0.0F, 2.0F, 0.0F, true};
            case G_VOICES: return {1.0F, 24.0F, 12.0F, true};
            case E_SOURCE_ID: return {0.0F, 2.0F, 1.0F, true};
            case E_BYPASS_ID: return {0.0F, 1.0F, 0.0F, true};
            case E_BEND_UP_ID: case E_BEND_DOWN_ID: return {-1.0F, 24.0F, 0.0F, true};
            default: return {0.0F, 1.0F, 0.0F, false};
        }
    }
    if (id < kLinkBase) {
        const int off = (id - kGenBase) % kGenStride;
        switch (off) {
            case GN_METHOD: return {0.0F, static_cast<float>(kMethods - 1), 0.0F, true};
            case GN_ROUTE: return {0.0F, static_cast<float>(kRoutes - 1), 1.0F, true};
            case GN_FTYPE: return {0.0F, static_cast<float>(kOwnFilters - 1), 0.0F, true};
            case GN_SEL1: case GN_SEL2: return {0.0F, 127.0F, 0.0F, true};
            case GN_SEL3: case GN_SEL4: return {0.0F, 15.0F, 0.0F, true};
            case GN_OCT: return {-3.0F, 3.0F, 0.0F, true};
            case GN_SEMI: return {-24.0F, 24.0F, 0.0F, true};
            case GN_UNISON: return {1.0F, 4.0F, 1.0F, true};
            case GN_SYNC: case GN_FIXED: case GN_MUTE: return {0.0F, 1.0F, 0.0F, true};
            case GN_AMPENV: case GN_FENV: case GN_PENV: return {0.0F, static_cast<float>(kEnvs), 0.0F, true};
            default: return {0.0F, 1.0F, 0.5F, false};
        }
    }
    if (id < kFilterBase) {
        return ((id - kLinkBase) & 1) == 0 ? ParamInfo{0.0F, static_cast<float>(kLinkTypes - 1), 0.0F, true} : ParamInfo{0.0F, 1.0F, 0.5F, false};
    }
    if (id < kEnvBase) {
        const int off = (id - kFilterBase) % kFilterStride;
        if (off == FL_TYPE) return {0.0F, static_cast<float>(kFilterTypes - 1), 0.0F, true};
        if (off == FL_ENV) return {0.0F, static_cast<float>(kEnvs), 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    if (id < kLfoBase) {
        const int off = (id - kEnvBase) % kEnvStride;
        if (off == EV_SUS) return {0.0F, static_cast<float>(kEnvPoints - 1), 1.0F, true};
        if (off == EV_LOOP) return {0.0F, 1.0F, 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    if (id < kStepBase) {
        const int off = (id - kLfoBase) % kLfoStride;
        if (off == LF_WAVE) return {0.0F, static_cast<float>(kLfoWaves - 1), 0.0F, true};
        if (off == LF_UNI) return {0.0F, 1.0F, 0.0F, true};
        if (off == LF_FREE) return {0.0F, 2.0F, 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    if (id < kModBase) {
        const int off = id - kStepBase;
        if (off == ST_LEN) return {1.0F, static_cast<float>(kStepCount), 8.0F, true};
        if (off == ST_DIR) return {0.0F, 3.0F, 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    if (id < kCtlBase) {
        const int off = (id - kModBase) % kModStride;
        if (off == 0) return {0.0F, static_cast<float>(kModSources - 1), 0.0F, true};
        if (off == 1) return {0.0F, static_cast<float>(kDestCount - 1), 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    if (id < kTuneBase) {
        const int off = (id - kCtlBase) % kCtlStride;
        if (off == CT_SRC) return {0.0F, 130.0F, 0.0F, true};
        if (off == CT_CURVE) return {0.0F, 2.0F, 0.0F, true};
        if (off == CT_D1 || off == CT_D2 || off == CT_D3) return {0.0F, static_cast<float>(kDestCount - 1), 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    if (id < kDrawBase) {
        const int off = id - kTuneBase;
        if (off == TN_ON) return {0.0F, 1.0F, 0.0F, true};
        if (off == TN_ROOT) return {0.0F, 11.0F, 0.0F, true};
        return {0.0F, 1.0F, 0.5F, false};
    }
    return {0.0F, 1.0F, 0.5F, false};
}

float clampParam(int id, float v) noexcept {
    if (!(v == v)) v = 0.0F;   // NaN
    const ParamInfo i = paramInfo(id);
    v = std::clamp(v, i.lo, i.hi);
    return i.whole ? std::floor(v + 0.5F) : v;
}

int selChoices(int method, int sel) noexcept {
    switch (method) {
        case M_WAVE: return sel == GN_SEL3 ? kShapers : (sel == GN_SEL4 ? kPhaseDists : kWaveChoices);
        case M_ADD: return sel == GN_SEL1 ? kAddSeries : 4;
        case M_STRING: return sel == GN_SEL1 ? kExciters : kGens + 1;
        case M_WIND: return sel == GN_SEL1 ? kWinds : 1;
        case M_MODAL: return sel == GN_SEL1 ? kMaterials : kGens + 1;
        case M_NOISE: return sel == GN_SEL1 ? kNoiseColors : 1;
        case M_GRAIN: return sel == GN_SEL1 ? kGens : 4;
        case M_SPECTRAL: return sel == GN_SEL1 ? kGens : kSpectralOps;
        default: return 1;
    }
}

void setMethod(float* p, int g, int method) noexcept {
    method = std::clamp(method, 0, kMethods - 1);
    const int b = genBase(g);
    for (int i = 0; i < kGenFloats; ++i) p[b + GN_F0 + i] = 0.0F;
    for (int s = GN_SEL1; s <= GN_SEL4; ++s) p[b + s] = 0.0F;
    p[b + GN_METHOD] = static_cast<float>(method);
    float* f = p + b + GN_F0;
    switch (method) {
        case M_WAVE:     // f: MORPH SYMMETRY TILT FOLD SHAPE PD HARMLIMIT SUB SELFFB BIAS
            f[0] = 0.0F; f[1] = 0.5F; f[2] = 0.5F; f[3] = 0.0F; f[4] = 0.0F; f[5] = 0.0F; f[6] = 1.0F; f[7] = 0.0F; f[8] = 0.0F; f[9] = 0.5F;
            p[b + GN_SEL1] = 0.0F; p[b + GN_SEL2] = 4.0F; p[b + GN_SEL3] = 1.0F;
            break;
        case M_ADD:      // f: PARTIALS TILT ODDEVEN FORMANT-HZ FORMANT-WIDTH FORMANT-GAIN PHASESPREAD STRETCH SHIFT
            f[0] = 0.25F; f[1] = 0.5F; f[2] = 0.5F; f[3] = 0.5F; f[4] = 0.5F; f[5] = 0.0F; f[6] = 0.0F; f[7] = 0.0F; f[8] = 0.5F;
            break;
        case M_STRING:   // f: DECAY DAMPING DISPERSION PICKPOS EXCITE BOWPRESS BOWSPEED BOWPOS NONLIN BODY EXCLEN TUNE
            f[0] = 0.85F; f[1] = 0.35F; f[2] = 0.0F; f[3] = 0.2F; f[4] = 0.6F; f[5] = 0.5F; f[6] = 0.5F; f[7] = 0.15F; f[8] = 0.0F; f[9] = 0.3F; f[10] = 0.3F; f[11] = 0.5F;
            break;
        case M_WIND:     // f: BREATH EMBOUCHURE DAMPING BRIGHT NOISE GROWL OVERBLOW ATTACK VIBRATO BREATHCTL BORESHAPE
            f[0] = 0.6F; f[1] = 0.5F; f[2] = 0.4F; f[3] = 0.6F; f[4] = 0.12F; f[5] = 0.0F; f[6] = 0.0F; f[7] = 0.3F; f[8] = 0.0F; f[9] = 1.0F; f[10] = 0.0F;
            break;
        case M_MODAL:    // f: DECAY DAMPTILT INHARM STRIKEPOS HARDNESS MODES BRIGHT
            f[0] = 0.8F; f[1] = 0.5F; f[2] = 0.3F; f[3] = 0.3F; f[4] = 0.5F; f[5] = 0.6F; f[6] = 0.6F;
            break;
        case M_NOISE:    // f: TILT BANDHZ BANDWIDTH CRACKLE RATE
            f[0] = 0.5F; f[1] = 0.6F; f[2] = 1.0F; f[3] = 0.5F; f[4] = 1.0F;
            break;
        case M_GRAIN:    // f: SIZE DENSITY POSITION POSRANDOM PITCH PITCHRANDOM REVERSE FREEZE SPREAD DRY
            f[0] = 0.45F; f[1] = 0.55F; f[2] = 0.3F; f[3] = 0.3F; f[4] = 0.5F; f[5] = 0.0F; f[6] = 0.0F; f[7] = 0.0F; f[8] = 0.5F; f[9] = 0.0F;
            p[b + GN_SEL1] = static_cast<float>(g == 0 ? 2 : 1);
            break;
        case M_SPECTRAL: // f: AMOUNT SHIFT THRESHOLD BLUR FREEZE TILT STRETCH DRY
            f[0] = 1.0F; f[1] = 0.5F; f[2] = 0.2F; f[3] = 0.3F; f[4] = 0.0F; f[5] = 0.5F; f[6] = 0.5F; f[7] = 0.0F;
            p[b + GN_SEL1] = static_cast<float>(g == 0 ? 2 : 1); p[b + GN_SEL2] = static_cast<float>(SP_BLUR);
            break;
        default: break;
    }
    if (method == M_GRAIN || method == M_SPECTRAL) { p[b + GN_SEL1] = static_cast<float>(std::clamp(static_cast<int>(p[b + GN_SEL1]), 0, kGens - 1)); }
}

void setDefaults(float* p) noexcept {
    for (int i = 0; i < kParamCount; ++i) p[i] = paramInfo(i).def;
    set(p, G_LEVEL, 0.857F);                     // 0 dB
    set(p, G_VOICES, 12.0F);
    set(p, G_VIB_RATE, unmapLog(5.5F, rng::kVibRateLo, rng::kVibRateHi));
    set(p, G_VIB_DEPTH, 0.1F);
    set(p, G_VIB_DELAY, 0.15F);
    set(p, G_VIB_WHEEL, 1.0F);
    set(p, G_TREM_RATE, unmapLog(5.0F, 0.1F, 14.0F));
    set(p, G_TREM_DEPTH, 0.0F);
    set(p, G_WIDTH, 0.5F);
    set(p, G_VEL_CURVE, 0.5F);
    set(p, G_DRIVE, 0.0F);
    set(p, G_RETRIG, 0.0F);
    set(p, G_KEEP_RES, 1.0F);
    set(p, E_SOURCE_ID, 1.0F);
    set(p, E_BYPASS_ID, 0.0F);
    set(p, E_BEND_UP_ID, 0.0F);
    set(p, E_BEND_DOWN_ID, 0.0F);
    for (int g = 0; g < kGens; ++g) {
        const int b = genBase(g);
        setMethod(p, g, M_OFF);
        p[b + GN_ROUTE] = static_cast<float>(R_A);
        p[b + GN_AMPENV] = 1.0F;
        p[b + GN_LEVEL] = 0.9F;
        p[b + GN_PAN] = 0.5F;
        p[b + GN_FINE] = 0.5F;
        p[b + GN_RATIO] = unmapLog(1.0F, rng::kRatioLo, rng::kRatioHi);
        p[b + GN_FIXHZ] = unmapLog(440.0F, rng::kFixHzLo, rng::kFixHzHi);
        p[b + GN_PHASE] = 0.0F;
        p[b + GN_FCUT] = 0.8F;
        p[b + GN_FRES] = 0.2F;
        p[b + GN_VELLEV] = 0.5F;
        p[b + GN_UNIDET] = 0.3F;
        p[b + GN_UNISPR] = 0.6F;
        p[b + GN_SYNCR] = 0.15F;
        p[b + GN_FENVAMT] = 0.5F;
        p[b + GN_PENVAMT] = 0.5F;
        p[b + GN_FKEY] = 0.0F;
    }
    setMethod(p, 0, M_WAVE);
    p[genBase(0) + GN_SEL1] = 2.0F;   // SAW
    p[genBase(0) + GN_SEL2] = 4.0F;   // SQUARE (the other wave of the morph)
    // links: all off, amount 0.5 (a mid knob)
    for (int d = 0; d < kGens; ++d) for (int s = 0; s < kGens; ++s) { p[linkType(d, s)] = 0.0F; p[linkAmt(d, s)] = 0.3F; }
    // filters
    for (int f = 0; f < kFilters; ++f) {
        p[filterId(f, FL_TYPE)] = f == 0 ? static_cast<float>(FT_LP) : static_cast<float>(FT_OFF);
        p[filterId(f, FL_CUT)] = unmapLog(8000.0F, rng::kCutLo, rng::kCutHi);
        p[filterId(f, FL_RES)] = 0.2F;
        p[filterId(f, FL_DRIVE)] = 0.0F;
        p[filterId(f, FL_KEY)] = 0.0F;
        p[filterId(f, FL_VEL)] = 0.0F;
        p[filterId(f, FL_ENV)] = 2.0F;
        p[filterId(f, FL_ENVAMT)] = 0.5F;
        p[filterId(f, FL_VOWEL)] = 0.0F;
        p[filterId(f, FL_MORPH)] = 0.0F;
    }
    // envelopes: 0 amplitude, 1 filter, 2 pitch / free, 3 free
    struct EnvDef { float a, d, s, r; };
    const EnvDef defs[kEnvs] = {{0.005F, 0.3F, 0.7F, 0.25F}, {0.002F, 0.4F, 0.4F, 0.3F}, {0.0F, 0.2F, 0.0F, 0.2F}, {0.3F, 0.5F, 0.5F, 0.4F}};
    auto tOf = [](float sec) { return sec <= 0.0F ? 0.0F : std::log10(sec / rng::kTimeLo) / 4.0F; };
    for (int e = 0; e < kEnvs; ++e) {
        p[envId(e, EV_START)] = 0.0F;
        p[envId(e, envT(0))] = tOf(defs[e].a); p[envId(e, envL(0))] = 1.0F;
        p[envId(e, envT(1))] = tOf(defs[e].d); p[envId(e, envL(1))] = defs[e].s;
        for (int i = 2; i < kEnvPoints; ++i) { p[envId(e, envT(i))] = 0.0F; p[envId(e, envL(i))] = 0.0F; }
        p[envId(e, EV_SUS)] = 1.0F;
        p[envId(e, EV_REL)] = tOf(defs[e].r);
        p[envId(e, EV_CURVE)] = 0.7F;
        p[envId(e, EV_LOOP)] = 0.0F;
        p[envId(e, EV_KEYT)] = 0.5F;
    }
    // LFOs
    const float rates[kLfos] = {5.0F, 0.5F, 2.0F, 8.0F};
    for (int l = 0; l < kLfos; ++l) {
        p[lfoId(l, LF_WAVE)] = 0.0F;
        p[lfoId(l, LF_RATE)] = unmapLog(rates[l], rng::kLfoLo, rng::kLfoHi);
        p[lfoId(l, LF_DELAY)] = 0.0F; p[lfoId(l, LF_FADE)] = 0.0F; p[lfoId(l, LF_PHASE)] = 0.0F;
        p[lfoId(l, LF_UNI)] = 0.0F; p[lfoId(l, LF_FREE)] = 0.0F; p[lfoId(l, LF_KEYF)] = 0.0F;
    }
    // step modulator
    p[stepId(ST_LEN)] = 8.0F; p[stepId(ST_RATE)] = unmapLog(4.0F, rng::kStepLo, rng::kStepHi); p[stepId(ST_GLIDE)] = 0.0F; p[stepId(ST_DIR)] = 0.0F;
    for (int i = 0; i < kStepCount; ++i) p[stepId(ST_STEPS + i)] = 0.5F + 0.4F * (static_cast<float>(i % 4) - 1.5F) / 1.5F;
    // modulation matrix and controllers: everything off
    for (int m = 0; m < kMods; ++m) { p[modId(m, 0)] = 0.0F; p[modId(m, 1)] = 0.0F; p[modId(m, 2)] = 0.5F; }
    for (int c = 0; c < kCtls; ++c) {
        p[ctlId(c, CT_SRC)] = 0.0F; p[ctlId(c, CT_CURVE)] = 0.0F;
        for (int k = 0; k < 3; ++k) { p[ctlId(c, CT_D1 + 2 * k)] = 0.0F; p[ctlId(c, CT_A1 + 2 * k)] = 0.5F; }
    }
    // tuning
    p[tuneId(TN_ON)] = 0.0F; p[tuneId(TN_ROOT)] = 0.0F; p[tuneId(TN_MASTER)] = 0.5F;
    for (int i = 0; i < 12; ++i) p[tuneId(TN_CENTS + i)] = 0.5F;
    // the four drawn waves start as a sine, a triangle, a saw and a square - to be changed in the editor
    for (int w = 0; w < kDrawnWaves; ++w) {
        for (int i = 0; i < kDrawLen; ++i) {
            const float x = static_cast<float>(i) / static_cast<float>(kDrawLen);
            float v = 0.0F;
            switch (w) {
                case 0: v = std::sin(6.28318530718F * x); break;
                case 1: v = x < 0.25F ? 4.0F * x : (x < 0.75F ? 2.0F - 4.0F * x : 4.0F * x - 4.0F); break;
                case 2: v = 2.0F * x - 1.0F; break;
                default: v = x < 0.5F ? 1.0F : -1.0F; break;
            }
            p[drawId(w, i)] = 0.5F + 0.5F * 0.9F * v;
        }
    }
}

}  // namespace silveton::sampler::suse
