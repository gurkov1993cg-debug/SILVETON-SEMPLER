#pragma once
// SILVETON_SUSE_V1 - the sound core of SILVETON SYNTH (our own code; nothing of any other instrument's code is in here).
// One voice = six generators of any method (wave / additive / string / wind / modal / noise / granular / spectral) that can
// modulate each other (PM, FM, AM, ring, sync, warp, filter-FM), two shared filters, four multipoint envelopes, four LFOs,
// a step modulator, a 16-slot modulation matrix, 8 learnable controller routes, vibrato / tremolo, microtuning.
// Real-time rules: no allocation, no locks, no files; every buffer is inside the voice; NaN / Inf are caught every 16 samples;
// every knob glides (the sampler glides the knobs themselves, the voice ramps what it calculates); a change of a whole-number
// choice (method, wave, filter type ...) fades the generator out and in, so it never clicks.
#include "SuseWaves.h"
#include "silveton/sampler/SuseDefs.h"
#include "silveton/sampler/UserWaves.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>

namespace silveton::sampler::suse {

constexpr int kChunk = 16;            // the control rate: modulation is calculated every 16 samples
constexpr int kMemSize = 8192;        // floats of memory of one generator (delay lines, grains, spectrum frames)
constexpr double kTwoPi = 6.283185307179586;
constexpr float kDen = 1.0e-20F;

inline float flush(float x) noexcept { return std::fabs(x) < kDen ? 0.0F : x; }
inline float clampf(float x, float lo, float hi) noexcept { return x < lo ? lo : (x > hi ? hi : x); }
inline float soft(float x) noexcept {   // a soft limiter: straight up to 0.9, then bends to 1
    const float a = std::fabs(x);
    if (a <= 0.9F) return x;
    const float y = 0.9F + 0.1F * std::tanh((a - 0.9F) * 10.0F);
    return x < 0.0F ? -y : y;
}
// a sine from a phase 0..1 (a table, shared by all)
inline const std::array<float, kTab + 1>& sineTab() noexcept {
    static const std::array<float, kTab + 1> t = [] { std::array<float, kTab + 1> s{}; for (int i = 0; i <= kTab; ++i) s[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(kTwoPi * i / kTab)); return s; }();
    return t;
}
inline float readTab(const float* t, double phi) noexcept {   // 4-point Hermite, phi 0..1
    const double x = phi * kTab;
    const int i = static_cast<int>(x);
    const float f = static_cast<float>(x - i);
    const float y0 = t[(i - 1) & (kTab - 1)], y1 = t[i & (kTab - 1)], y2 = t[(i + 1) & (kTab - 1)], y3 = t[(i + 2) & (kTab - 1)];
    const float c1 = 0.5F * (y2 - y0), c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3, c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
    return ((c3 * f + c2) * f + c1) * f + y1;
}
inline float sinT(double ph) noexcept {   // sine of a phase 0..1 (any value)
    ph -= std::floor(ph);
    const auto& s = sineTab();
    const double x = ph * kTab; const int i = static_cast<int>(x); const float f = static_cast<float>(x - i);
    return s[static_cast<std::size_t>(i)] + (s[static_cast<std::size_t>(i) + 1U] - s[static_cast<std::size_t>(i)]) * f;
}
inline float cosT(double ph) noexcept { return sinT(ph + 0.25); }
inline float tanhF(float x) noexcept {   // rational tanh, good to 2e-3, never above 1
    if (x > 3.0F) return 1.0F;
    if (x < -3.0F) return -1.0F;
    const float x2 = x * x;
    return x * (27.0F + x2) / (27.0F + 9.0F * x2);
}
inline float foldTri(float x) noexcept {   // folds into -1..1 like a triangle
    x = x * 0.25F + 0.25F;
    x -= std::floor(x);
    return std::fabs(x * 4.0F - 2.0F) - 1.0F;
}

// ------------------------------------------------------------------------------------------------ filters
struct Svf {   // state-variable filter (trapezoidal): low / band / high / notch from one pass
    float ic1{0.0F}, ic2{0.0F};
    float g{0.1F}, k{1.0F}, a1{0.0F}, a2{0.0F}, a3{0.0F};
    void set(float hz, float q, double sr) noexcept {
        hz = clampf(hz, 8.0F, static_cast<float>(sr) * 0.45F);
        g = std::tan(static_cast<float>(kTwoPi * 0.5) * hz / static_cast<float>(sr));
        k = 1.0F / std::max(q, 0.3F);
        a1 = 1.0F / (1.0F + g * (g + k)); a2 = g * a1; a3 = g * a2;
    }
    // returns lp; bp, hp through the references
    float run(float x, float& bp, float& hp) noexcept {
        const float v3 = x - ic2;
        const float v1 = a1 * ic1 + a2 * v3;
        const float v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = flush(2.0F * v1 - ic1); ic2 = flush(2.0F * v2 - ic2);
        bp = v1; hp = x - k * v1 - v2;
        return v2;
    }
    void reset() noexcept { ic1 = ic2 = 0.0F; }
};

struct Ladder {   // 4-pole low-pass with feedback (a transistor-ladder style, our own simple model)
    float s[4]{0.0F, 0.0F, 0.0F, 0.0F};
    float gc{0.1F}, k{0.0F};
    void set(float hz, float res, double sr) noexcept {
        hz = clampf(hz, 8.0F, static_cast<float>(sr) * 0.45F);
        gc = 1.0F - std::exp(-static_cast<float>(kTwoPi) * hz / static_cast<float>(sr));
        k = 3.9F * clampf(res, 0.0F, 1.0F);
    }
    float run(float x, float drive) noexcept {
        const float in = tanhF((x - k * s[3]) * (1.0F + drive * 3.0F));
        s[0] = flush(s[0] + gc * (in - tanhF(s[0])));
        s[1] = flush(s[1] + gc * (tanhF(s[0]) - tanhF(s[1])));
        s[2] = flush(s[2] + gc * (tanhF(s[1]) - tanhF(s[2])));
        s[3] = flush(s[3] + gc * (tanhF(s[2]) - tanhF(s[3])));
        return s[3] * (1.0F + 0.5F * k * 0.25F);
    }
    void reset() noexcept { s[0] = s[1] = s[2] = s[3] = 0.0F; }
};

// the shared filter (one per channel): every type of FilterType
struct ShFilter {
    Svf a, b, c;   // a: the main one, b / c: the other formant bands
    Ladder lad;
    int type{0};
    float morph{0.0F}, drive{0.0F};
    float vowel{0.0F};
    void setup(int t, float hz, float res, float drv, float vow, float mor, double sr) noexcept {
        type = t; drive = drv; morph = mor; vowel = vow;
        const float q = qOf(res);
        switch (t) {
            case FT_LP: case FT_HP: case FT_BP: case FT_NOTCH: case FT_SVF: a.set(hz, q, sr); break;
            case FT_LADDER: lad.set(hz, res, sr); break;
            case FT_RESONANT: a.set(hz, 1.0F + 90.0F * res * res, sr); break;
            case FT_FORMANT: {
                // five vowels (A E I O U): the three formants of each, interpolated by `vowel`
                static constexpr float f1[5] = {800.0F, 400.0F, 350.0F, 450.0F, 325.0F};
                static constexpr float f2[5] = {1150.0F, 1600.0F, 1700.0F, 800.0F, 700.0F};
                static constexpr float f3[5] = {2900.0F, 2700.0F, 2700.0F, 2830.0F, 2700.0F};
                const float v = clampf(vow, 0.0F, 1.0F) * 4.0F;
                const int i = std::min(3, static_cast<int>(v)); const float fr = v - static_cast<float>(i);
                const float shift = hz / 1000.0F;   // the cutoff moves all formants (1 kHz = as the table)
                a.set((f1[i] + (f1[i + 1] - f1[i]) * fr) * shift, 6.0F + 6.0F * res, sr);
                b.set((f2[i] + (f2[i + 1] - f2[i]) * fr) * shift, 8.0F + 8.0F * res, sr);
                c.set((f3[i] + (f3[i + 1] - f3[i]) * fr) * shift, 10.0F + 10.0F * res, sr);
                break;
            }
            default: break;
        }
    }
    float run(float x) noexcept {
        float bp = 0.0F, hp = 0.0F, lp = 0.0F;
        if (drive > 0.0F && type != FT_LADDER) x = tanhF(x * (1.0F + 4.0F * drive)) / (1.0F + 1.5F * drive);
        switch (type) {
            case FT_LP: return a.run(x, bp, hp);
            case FT_HP: a.run(x, bp, hp); return hp;
            case FT_BP: a.run(x, bp, hp); return bp * a.k;
            case FT_NOTCH: lp = a.run(x, bp, hp); return lp + hp;
            case FT_LADDER: return lad.run(x, drive);
            case FT_SVF: {   // morph: LP -> BP -> HP
                lp = a.run(x, bp, hp);
                const float m = clampf(morph, 0.0F, 1.0F) * 2.0F;
                return m < 1.0F ? lp + (bp * a.k - lp) * m : bp * a.k + (hp - bp * a.k) * (m - 1.0F);
            }
            case FT_RESONANT: { lp = a.run(x, bp, hp); return tanhF(lp * 1.2F + bp * a.k * 0.8F); }
            case FT_FORMANT: {
                float b1, h1, b2, h2, b3, h3;
                a.run(x, b1, h1); b.run(x, b2, h2); c.run(x, b3, h3);
                return (b1 * a.k * 1.0F + b2 * b.k * 0.6F + b3 * c.k * 0.35F) * 1.6F;
            }
            default: return x;
        }
    }
    void reset() noexcept { a.reset(); b.reset(); c.reset(); lad.reset(); }
};

// ------------------------------------------------------------------------------------------------ envelope: five points, a sustain point, a release
struct EnvCfg {
    float start{0.0F};
    float t[kEnvPoints]{}, l[kEnvPoints]{};
    int sus{1};
    float rel{0.2F};
    float curve{0.0F};
    bool loop{false};
    float raw[kEnvStride]{};   // the numbers it was made from
};
struct EnvState {
    int stage{0};          // 0..4 points, 5 release, 6 done
    float level{0.0F}, from{0.0F}, to{0.0F}, ph{0.0F}, dph{1.0F};
    bool gate{true};
    [[nodiscard]] bool done() const noexcept { return stage >= 6; }
    static float ease(float x, float c) noexcept {
        if (c == 0.0F) return x;
        const float k = 1.0F + 3.0F * std::fabs(c);
        return c > 0.0F ? 1.0F - std::pow(1.0F - x, k) : std::pow(x, k);
    }
    void begin(const EnvCfg& c, double sr, float timeMul) noexcept {
        stage = 0; level = c.start; gate = true; goTo(c, 0, sr, timeMul);
    }
    void goTo(const EnvCfg& c, int st, double sr, float timeMul) noexcept {
        stage = st; from = level; ph = 0.0F;
        float secs = 0.0F;
        if (st <= kEnvPoints - 1) { to = c.l[st]; secs = c.t[st] * timeMul; }
        else { to = 0.0F; secs = c.rel * timeMul; stage = 5; }
        dph = secs <= 0.0F ? 1.0F : static_cast<float>(1.0 / (static_cast<double>(secs) * sr));
        if (secs <= 0.0F) { level = to; ph = 1.0F; }
    }
    void release(const EnvCfg& c, double sr, float timeMul) noexcept {
        if (stage >= 5) return;
        gate = false;
        int nx = std::max(stage, c.sus) + 1;
        while (nx < kEnvPoints && c.t[nx] <= 0.0F) ++nx;   // points after the sustain point count only when they have a time
        goTo(c, nx < kEnvPoints ? nx : 5, sr, timeMul);
    }
    float tick(const EnvCfg& c, double sr, float timeMul) noexcept {
        if (stage >= 6) return 0.0F;
        if (ph < 1.0F) {
            ph += dph;
            if (ph >= 1.0F) { ph = 1.0F; level = to; } else level = from + (to - from) * ease(ph, c.curve);
        } else level = to;
        if (ph >= 1.0F) {   // the segment is over
            if (stage == 5) { if (level <= 1.0e-4F) { level = 0.0F; stage = 6; } else { level = 0.0F; stage = 6; } }
            else if (gate) {
                if (stage < c.sus) goTo(c, stage + 1, sr, timeMul);
                else if (c.loop && stage == c.sus) goTo(c, 0, sr, timeMul);
                // else: holds at the sustain point
            } else {
                int nx = stage + 1;
                while (nx < kEnvPoints && c.t[nx] <= 0.0F) ++nx;
                goTo(c, nx < kEnvPoints ? nx : 5, sr, timeMul);
            }
        }
        return level;
    }
};

// ------------------------------------------------------------------------------------------------ LFO and step modulator
struct LfoState {
    double ph{0.0};
    float hold{0.0F}, a{0.0F}, b{0.0F};
    std::uint32_t rng{1U};
    float age{0.0F};
    // one value for the chunk; rate in Hz
    float tick(int wave, float hz, double chunkSec, bool bipolar, float delaySec, float fadeSec) noexcept {
        age += static_cast<float>(chunkSec);
        const double old = ph;
        ph += static_cast<double>(hz) * chunkSec;
        const bool wrapped = std::floor(ph) > std::floor(old);
        ph -= std::floor(ph);
        float v = 0.0F;
        switch (wave) {
            case LW_SINE: v = sinT(ph); break;
            case LW_TRI: v = ph < 0.25 ? static_cast<float>(4.0 * ph) : (ph < 0.75 ? static_cast<float>(2.0 - 4.0 * ph) : static_cast<float>(4.0 * ph - 4.0)); break;
            case LW_SAW: v = static_cast<float>(2.0 * ph - 1.0); break;
            case LW_RSAW: v = static_cast<float>(1.0 - 2.0 * ph); break;
            case LW_SQUARE: v = ph < 0.5 ? 1.0F : -1.0F; break;
            case LW_SH: if (wrapped) hold = lcgf(rng); v = hold; break;
            default: {   // smooth random: glides between random values
                if (wrapped) { a = b; b = lcgf(rng); }
                const float x = static_cast<float>(ph);
                v = a + (b - a) * (x * x * (3.0F - 2.0F * x));
                break;
            }
        }
        float fade = 1.0F;
        if (age < delaySec) fade = 0.0F;
        else if (fadeSec > 0.0F) fade = clampf((age - delaySec) / fadeSec, 0.0F, 1.0F);
        v *= fade;
        return bipolar ? v : 0.5F + 0.5F * v;
    }
};

struct StepState {
    double ph{0.0};
    int idx{0};
    int dir{1};
    float cur{0.0F};
    std::uint32_t rng{7U};
};

} // namespace silveton::sampler::suse
