// SILVETON_SUSE_V1 - the generators of SILVETON SYNTH: wave, additive, string, wind, modal, noise, granular, spectral.
// Every generator is our own calculation from the textbook ideas (waveguides, resonators, partials, grains, the short-time
// spectrum); nothing is a recording and nothing is copied from another instrument.
#include "SuseVoice.h"

namespace silveton::sampler::suse {

namespace {

const float kZeroTab[kTabStride] = {};

float uniOffset(int n, int u) noexcept {   // -1..1 across the unison voices
    static constexpr float t2[2] = {-1.0F, 1.0F};
    static constexpr float t3[3] = {-1.0F, 0.0F, 1.0F};
    static constexpr float t4[4] = {-1.0F, -0.3333F, 0.3333F, 1.0F};
    return n == 1 ? 0.0F : (n == 2 ? t2[u] : (n == 3 ? t3[u] : t4[u]));
}

// a cubic read of a delay line: the sample written D samples ago (D >= 2); w = the next write position
inline float rdDelay(const float* b, int mask, int w, float d) noexcept {
    const int i = static_cast<int>(d);
    const float f = d - static_cast<float>(i);
    const float s0 = b[(w - (i - 1)) & mask], s1 = b[(w - i) & mask], s2 = b[(w - i - 1) & mask], s3 = b[(w - i - 2) & mask];
    const float c1 = 0.5F * (s2 - s0), c2 = s0 - 2.5F * s1 + 2.0F * s2 - 0.5F * s3, c3 = 0.5F * (s3 - s0) + 1.5F * (s1 - s2);
    return ((c3 * f + c2) * f + c1) * f + s1;
}

float noiseOf(std::uint32_t& s) noexcept { return lcgf(s); }

// ---- the short FFT of the spectral generator (512 points, floats, no allocation)
constexpr int kFft = 512;
struct FftTables {
    float c[kFft / 2], s[kFft / 2];
    std::uint16_t rev[kFft];
    float win[kFft];
    FftTables() {
        for (int i = 0; i < kFft / 2; ++i) { c[i] = static_cast<float>(std::cos(kTwoPi * i / kFft)); s[i] = static_cast<float>(-std::sin(kTwoPi * i / kFft)); }
        for (int i = 0; i < kFft; ++i) {
            int r = 0; for (int b = 0; b < 9; ++b) if (i & (1 << b)) r |= 1 << (8 - b);
            rev[i] = static_cast<std::uint16_t>(r);
            win[i] = static_cast<float>(std::sin(3.14159265358979 * (i + 0.5) / kFft));   // sqrt of Hann (periodic form is close enough: Hann = sin^2)
        }
    }
};
const FftTables& fftTables() { static const FftTables t; return t; }
void fft512(float* re, float* im, bool inverse) noexcept {
    const FftTables& T = fftTables();
    for (int i = 0; i < kFft; ++i) { const int j = T.rev[i]; if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); } }
    for (int len = 2; len <= kFft; len <<= 1) {
        const int half = len >> 1, step = kFft / len;
        for (int i = 0; i < kFft; i += len) {
            for (int k = 0; k < half; ++k) {
                const float wr = T.c[k * step], wi = inverse ? -T.s[k * step] : T.s[k * step];
                const int a = i + k, b = i + k + half;
                const float tr = re[b] * wr - im[b] * wi, ti = re[b] * wi + im[b] * wr;
                re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
            }
        }
    }
}

}  // namespace

const float* Voice::tableFor(int wave, int level) const noexcept {
    level = std::clamp(level, 0, kLevels - 1);
    if (wave < 0) return kZeroTab;
    if (wave < kMathWaves) return mathTables().table(wave, level);
    if (wave < kWaveFile0) {
        if (shared_ == nullptr || !shared_->ready) return kZeroTab;
        return shared_->drawn[static_cast<std::size_t>(wave - kWaveDrawn0)].data() + static_cast<std::size_t>(level) * kTabStride;
    }
    if (shared_ == nullptr || shared_->files == nullptr) return kZeroTab;
    const int k = wave - kWaveFile0;
    if (k >= kFileWaves) return kZeroTab;
    const int idx = shared_->files->tableFor(k, keyNow_);
    if (idx < 0) return kZeroTab;
    return shared_->files->table(idx, std::min((level + 1) / 2, kUserTabLevels - 1));
}

// ------------------------------------------------------------------------------------------------ chunk preparation
void Voice::prepareGen(int g, GenCtl& c, double inc) noexcept {
    Gen& G = gen_[static_cast<std::size_t>(g)];
    const double incNow = (c.fixedHz ? G.mulCur : inc * G.mulCur);
    G.incNow = incNow;   // the method preparations below read the pitch of this chunk
    const double sr = sr_;
    G.ownType = G.aFtype;
    if (G.aFtype != OF_OFF) { G.own.set(c.ownHz, c.ownQ, sr); G.ownS.set(c.ownHz, c.ownQ, sr); }
    switch (G.aMethod) {
        case M_WAVE: {
            const float* f = c.f;
            float fmMax = 0.0F;
            for (int k = 0; k < nLinks_[static_cast<std::size_t>(g)]; ++k) { const Link& L = links_[static_cast<std::size_t>(g)][static_cast<std::size_t>(k)]; if (L.type == L_FM) fmMax += L.amt * 4.0F; else if (L.type == L_PM) fmMax += L.amt * 2.0F; }
            const float pw = 0.02F + 0.96F * f[1];
            float slope = f[1] == 0.5F ? 1.0F : 0.5F / std::min(pw, 1.0F - pw);
            const int pd = G.aSel[3];
            const float pa = f[5];
            if (pd == PD_SAWBEND) slope *= 1.0F + 3.0F * pa; else if (pd == PD_PULSEBEND) slope *= 1.0F / (1.0F - 0.92F * pa);
            else if (pd == PD_RESONANT) slope *= 1.0F + 7.0F * pa; else if (pd == PD_TWIST || pd == PD_DOUBLE) slope *= 1.0F + pa;
            double eff = std::fabs(incNow) * (1.0 + static_cast<double>(fmMax)) * static_cast<double>(slope) * std::pow(2.0, static_cast<double>(c.uniDet) / 1200.0);
            if (c.sync) eff *= static_cast<double>(c.syncRatio);
            int lvl = levelFor(std::min(eff, 0.49));
            lvl += static_cast<int>(std::lround(f[3] * 4.0F + (G.aSel[2] != SH_OFF ? f[4] * 3.0F : 0.0F)));
            const double hmax = std::pow(512.0, static_cast<double>(f[6]));
            int lh = 0; while (lh < kLevels - 1 && static_cast<double>(levelHarmonics(lh)) > hmax) ++lh;
            lvl = std::min(std::max(lvl, lh), kLevels - 1);
            G.tabA = tableFor(G.aSel[0], lvl); G.tabB = tableFor(G.aSel[1], lvl);
            break;
        }
        case M_ADD: prepareAdd(G, c); break;
        case M_STRING: prepareString(G, c); break;
        case M_WIND: prepareWind(G, c); break;
        case M_MODAL: prepareModal(G, c); break;
        default: break;
    }
}

void Voice::switchChoices(int g, const GenCtl& c) noexcept {
    Gen& G = gen_[static_cast<std::size_t>(g)];
    const bool methodChanged = c.method != G.aMethod;
    const bool selChanged = c.sel[0] != G.aSel[0] || c.sel[1] != G.aSel[1] || c.sel[2] != G.aSel[2] || c.sel[3] != G.aSel[3];
    G.aMethod = c.method; for (int i = 0; i < 4; ++i) G.aSel[i] = c.sel[i];
    G.aUni = c.unison;
    if (G.aFtype != c.ftype) { G.aFtype = c.ftype; G.own.reset(); G.ownS.reset(); }
    if (methodChanged || (selChanged && c.method != M_WAVE)) resetGen(g);
    if (methodChanged && c.method == M_WAVE) { for (auto& ph : G.ph) ph = 0.0; }
}

// ------------------------------------------------------------------------------------------------ one sample of one generator
void Voice::genSample(int g, const GenCtl& cNew, Gen& G, int /*i*/, float& y, float& side) noexcept {
    // the fade of a switch
    const float fstep = static_cast<float>(1.0 / (0.003 * sr_));
    if (G.fadingOut) {
        G.fade -= fstep;
        if (G.fade <= 0.0F) { G.fade = 0.0F; G.fadingOut = false; switchChoices(g, cNew); prepareGen(g, const_cast<GenCtl&>(cNew), lastInc_); }
    } else if (G.fade < 1.0F) G.fade = std::min(1.0F, G.fade + fstep);
    const GenCtl& c = G.fadingOut ? hold_[static_cast<std::size_t>(g)] : cNew;   // while the old method fades out it keeps its own knobs
    if (G.aMethod == M_OFF) { y = 0.0F; side = 0.0F; return; }
    G.mulCur += G.mulDlt;
    const double inc = c.fixedHz ? G.mulCur : lastInc_ * G.mulCur;
    G.incNow = inc;
    G.pitchPh += inc; G.wrapped = false;
    if (G.pitchPh >= 1.0) { G.pitchPh -= std::floor(G.pitchPh); G.wrapped = true; } else if (G.pitchPh < 0.0) { G.pitchPh -= std::floor(G.pitchPh); G.wrapped = true; }
    // what the other generators do to this one
    double pm = 0.0; float fm = 0.0F, am = 1.0F, ring = 1.0F, warp = 0.0F, ffm = 0.0F; bool syncHit = false;
    const int nl = nLinks_[static_cast<std::size_t>(g)];
    for (int k = 0; k < nl; ++k) {
        const Link& L = links_[static_cast<std::size_t>(g)][static_cast<std::size_t>(k)];
        const float x = modOut_[static_cast<std::size_t>(L.src)];
        switch (L.type) {
            case L_PM: pm += static_cast<double>(x * L.amt * 2.0F); break;
            case L_FM: fm += x * L.amt * 4.0F; break;
            case L_AM: am *= 1.0F - L.amt + L.amt * (0.5F + 0.5F * x); break;
            case L_RING: ring *= 1.0F - L.amt + L.amt * x; break;
            case L_SYNC: if (gen_[static_cast<std::size_t>(L.src)].wrapped) syncHit = true; break;
            case L_WARP: warp += x * L.amt; break;
            case L_FILTFM: ffm += x * L.amt; break;
            default: break;
        }
    }
    side = 0.0F;
    switch (G.aMethod) {
        case M_WAVE: y = waveSample(G, c, pm, fm, warp, syncHit, side); break;
        case M_ADD: y = addSample(G, c); break;
        case M_STRING: y = stringSample(g, G, c); break;
        case M_WIND: y = windSample(G, c); break;
        case M_MODAL: y = modalSample(g, G, c); break;
        case M_NOISE: y = noiseSample(G, c); break;
        case M_GRAIN: y = grainSample(g, G, c, side); break;
        case M_SPECTRAL: y = spectralSample(g, G, c); break;
        default: y = 0.0F; break;
    }
    const float mix = am * ring;
    if (mix != 1.0F) { y *= mix; side *= mix; }
    if (G.ownType != OF_OFF) {
        if (ffm != 0.0F) { const float hz = clampf(c.ownHz * std::pow(2.0F, ffm * 4.0F), 20.0F, 20000.0F); G.own.set(hz, c.ownQ, sr_); G.ownS.set(hz, c.ownQ, sr_); }
        float bp = 0.0F, hp = 0.0F, lp = G.own.run(y, bp, hp);
        float bs = 0.0F, hs = 0.0F, ls = G.ownS.run(side, bs, hs);
        switch (G.ownType) {
            case OF_LP: y = lp; side = ls; break;
            case OF_HP: y = hp; side = hs; break;
            case OF_BP: y = bp * G.own.k; side = bs * G.own.k; break;
            default: y = lp + hp; side = ls + hs; break;
        }
    }
    if (!std::isfinite(y)) y = 0.0F;
}

// ------------------------------------------------------------------------------------------------ WAVE
float Voice::waveSample(Gen& G, const GenCtl& c, double pmCycles, float fm, float warp, bool syncHit, float& side) noexcept {
    const float* f = c.f;
    const int n = G.aUni;
    const double incCar = G.incNow * (1.0 + static_cast<double>(fm));
    double syncFrac = 0.0;
    if (c.sync) {
        G.phSync += G.incNow;
        if (G.phSync >= 1.0) { G.phSync -= std::floor(G.phSync); syncHit = true; syncFrac = G.phSync; }
    }
    const float morph = f[0];
    const float pw = 0.02F + 0.96F * f[1];
    const bool sym = f[1] != 0.5F;
    const int pdt = G.aSel[3];
    const float pda = f[5];
    const float fb = f[8] * 0.5F;
    float sum = 0.0F, sumSide = 0.0F;
    for (int u = 0; u < n; ++u) {
        const float off = uniOffset(n, u);
        // no detune: the factor is exactly 1, so the pow is skipped (the same numbers, a lot less work per sample)
        const double uniCents = static_cast<double>(off * c.uniDet);
        double incU = uniCents == 0.0 ? incCar : incCar * std::pow(2.0, uniCents / 1200.0);
        if (c.sync) incU *= static_cast<double>(c.syncRatio);
        double& ph = G.ph[u];
        ph += incU; ph -= std::floor(ph);
        if (syncHit) ph = c.sync ? syncFrac * static_cast<double>(c.syncRatio) : 0.0;
        double phi = ph + static_cast<double>(c.phase) + pmCycles + static_cast<double>(fb * G.lastY);
        phi -= std::floor(phi);
        if (sym) phi = phi < static_cast<double>(pw) ? phi * 0.5 / static_cast<double>(pw) : 0.5 + (phi - static_cast<double>(pw)) * 0.5 / static_cast<double>(1.0F - pw);
        if (warp != 0.0F) { phi += static_cast<double>(warp * 0.25F) * static_cast<double>(sinT(phi)); phi -= std::floor(phi); }
        float window = 1.0F;
        if (pdt != PD_OFF && pda > 0.0F) {
            switch (pdt) {
                case PD_SAWBEND: phi = std::pow(phi, 1.0 + 3.0 * static_cast<double>(pda)); break;
                case PD_PULSEBEND: phi = std::min(1.0, phi / (1.0 - 0.92 * static_cast<double>(pda))); if (phi >= 1.0) phi = 0.0; break;
                case PD_RESONANT: window = 1.0F - static_cast<float>(phi); phi = phi * (1.0 + 7.0 * static_cast<double>(pda)); phi -= std::floor(phi); break;
                case PD_TWIST: phi += static_cast<double>(pda * 0.16F) * static_cast<double>(sinT(phi)); phi -= std::floor(phi); break;
                case PD_DOUBLE: { const double d = phi * 2.0; phi = (1.0 - static_cast<double>(pda)) * phi + static_cast<double>(pda) * (d - std::floor(d)); break; }
                default: break;
            }
        }
        float y = readTab(G.tabA, phi);
        if (morph > 0.001F) y += (readTab(G.tabB, phi) - y) * morph;
        y *= window;
        sum += y; sumSide += y * off;
    }
    float y = sum / static_cast<float>(n);
    side = sumSide / static_cast<float>(n) * c.uniSpread * 0.5F;
    // the sub-oscillator, an octave below
    if (f[7] > 0.001F) {
        G.phSub += G.incNow * 0.5; G.phSub -= std::floor(G.phSub);
        y += readTab(G.tabA, G.phSub) * f[7];
    }
    // spectral tilt: a shelf that follows the pitch
    const float tilt = (f[2] - 0.5F) * 2.0F;
    if (std::fabs(tilt) > 0.01F) {
        const float a = 1.0F - std::exp(-static_cast<float>(kTwoPi) * clampf(static_cast<float>(std::fabs(G.incNow) * sr_ * 3.0), 20.0F, static_cast<float>(sr_) * 0.4F) / static_cast<float>(sr_));
        G.tiltLp += a * (y - G.tiltLp); G.tiltLp = flush(G.tiltLp);
        y = tilt > 0.0F ? y + tilt * 1.5F * (y - G.tiltLp) : y + (-tilt) * (G.tiltLp - y);
    }
    // bias, fold, shaper
    if (f[9] != 0.5F) y += (f[9] - 0.5F) * 1.2F;
    if (f[3] > 0.001F) y = foldTri(y * (1.0F + 7.0F * f[3]));
    const int sh = G.aSel[2];
    if (sh != SH_OFF && f[4] > 0.001F) {
        const float a = f[4], gn = 1.0F + 9.0F * a;
        float s = y;
        switch (sh) {
            case SH_TANH: s = tanhF(gn * y) / tanhF(gn); break;
            case SH_ATAN: s = std::atan(gn * y) / std::atan(gn); break;
            case SH_CHEBY3: s = 4.0F * y * y * y - 3.0F * y; break;
            case SH_SINE: s = sinT(static_cast<double>(0.25F * gn * y)); break;
            case SH_POWER: s = (y < 0.0F ? -1.0F : 1.0F) * std::pow(std::fabs(y), 1.0F / gn); break;
            case SH_CRUSH: { const float q = std::pow(2.0F, 12.0F - 10.0F * a); s = std::round(y * q) / q; break; }
            case SH_RECT: s = 2.0F * std::fabs(y) - 1.0F; break;
            default: break;
        }
        const float wet = clampf(a * 3.0F, 0.0F, 1.0F);
        y += (s - y) * wet;
    }
    // a 10 Hz DC blocker (the shapers and the bias make DC)
    const float o = y - G.dcX + 0.9987F * G.dcY;
    G.dcX = y; G.dcY = flush(o);
    G.lastY = clampf(o, -2.0F, 2.0F);
    return o;
}

// ------------------------------------------------------------------------------------------------ ADDITIVE
// memory: cos 0..63, sin 64..127, rotate cos 128..191, rotate sin 192..255, amp 256..319, target 320..383, angle 384..447
void Voice::prepareAdd(Gen& G, const GenCtl& c) noexcept {
    float* m = mem_[static_cast<std::size_t>(&G - gen_.data())].data();
    const double f0 = std::fabs(G.incNow) * sr_;
    const int want = 1 + static_cast<int>(std::lround(c.f[0] * 63.0F));
    const float B = c.f[7] * c.f[7] * 0.02F;
    const float shiftHz = (c.f[8] - 0.5F) * 2.0F * 200.0F;
    const float tilt = (c.f[1] - 0.5F) * 24.0F;
    const float eo = (c.f[2] - 0.5F) * 2.0F;
    const float fc = mapLog(c.f[3], 100.0F, 8000.0F);
    const float bw = 0.1F + c.f[4] * 1.5F;
    const float fg = c.f[5] > 0.001F ? std::pow(10.0F, 24.0F * c.f[5] / 20.0F) - 1.0F : 0.0F;
    const float nyq = static_cast<float>(sr_) * 0.46F;
    float sumSq = 0.0F;
    int top = 0;
    // the phase spread follows the knob (rotates the partials by the change)
    const float spread = c.f[6];
    const float dSpread = spread - G.k[0];
    G.k[0] = spread;
    for (int n = 1; n <= 64; ++n) {
        const auto i = static_cast<std::size_t>(n - 1);
        float a = 0.0F;
        const float freq = static_cast<float>(f0) * static_cast<float>(n) * std::sqrt(1.0F + B * static_cast<float>(n * n)) + shiftHz;
        if (n <= want && freq > 0.0F && freq < nyq) {
            const bool odd = (n & 1) != 0;
            switch (G.aSel[0]) {
                case AS_SAW: a = 1.0F / static_cast<float>(n); break;
                case AS_SQUARE: a = odd ? 1.0F / static_cast<float>(n) : 0.0F; break;
                case AS_TRIANGLE: a = odd ? ((n / 2) % 2 == 0 ? 1.0F : -1.0F) / static_cast<float>(n * n) : 0.0F; break;
                case AS_EQUAL: a = 1.0F; break;
                case AS_PRIME: { bool pr = n > 1; for (int d = 2; d * d <= n; ++d) if (n % d == 0) pr = false; a = (pr || n == 1) ? 1.0F / static_cast<float>(n) : 0.0F; break; }
                default: a = 1.0F / std::sqrt(static_cast<float>(n)); break;
            }
            a *= std::pow(10.0F, tilt * std::log2(static_cast<float>(n)) / 20.0F);
            if (eo > 0.0F && !odd) a *= 1.0F - eo; else if (eo < 0.0F && odd) a *= 1.0F + eo;
            if (fg > 0.0F) { const float x = std::log2(freq / fc) / bw; a *= 1.0F + fg * std::exp(-0.5F * x * x); }
            const float edge = nyq - freq;
            if (edge < nyq * 0.1F) a *= clampf(edge / (nyq * 0.1F), 0.0F, 1.0F);
            top = n;
        }
        m[320 + i] = a;   // target (the normalisation comes below)
        sumSq += a * a;
        if (dSpread != 0.0F) {
            std::uint32_t s = static_cast<std::uint32_t>(n) * 2654435761U; const float r = lcgf(s) * 0.5F + 0.5F;
            const float d = dSpread * static_cast<float>(kTwoPi) * r;
            const float cr = m[i], ci = m[64 + i];
            m[i] = cr * std::cos(d) - ci * std::sin(d); m[64 + i] = cr * std::sin(d) + ci * std::cos(d);
        }
        const double ang = kTwoPi * static_cast<double>(freq > 0.0F ? freq : 0.0F) / sr_;
        if (std::fabs(ang - static_cast<double>(m[384 + i])) > 1.0e-7) { m[384 + i] = static_cast<float>(ang); m[128 + i] = static_cast<float>(std::cos(ang)); m[192 + i] = static_cast<float>(std::sin(ang)); }
        // keep the phasor on the circle
        const float mag = m[i] * m[i] + m[64 + i] * m[64 + i];
        if (mag > 0.0F && std::fabs(mag - 1.0F) > 1.0e-6F) { const float k = 1.0F / std::sqrt(mag); m[i] *= k; m[64 + i] *= k; }
        if (mag == 0.0F) { m[i] = 1.0F; m[64 + i] = 0.0F; }
    }
    const float norm = sumSq > 1.0e-9F ? std::min(8.0F, 0.35F / std::sqrt(0.5F * sumSq)) : 0.0F;
    for (int n = 0; n < 64; ++n) m[320 + n] *= norm;
    // the highest partial still audible (the ones fading out keep running)
    int act = top;
    for (int n = 64; n > top; --n) if (m[256 + n - 1] > 1.0e-5F) { act = n; break; }
    G.addN = act;
}

float Voice::addSample(Gen& G, const GenCtl& /*c*/) noexcept {
    float* m = mem_[static_cast<std::size_t>(&G - gen_.data())].data();
    float y = 0.0F;
    for (int i = 0; i < G.addN; ++i) {
        const float cr = m[i], ci = m[64 + i];
        const float nr = cr * m[128 + i] - ci * m[192 + i], ni = cr * m[192 + i] + ci * m[128 + i];
        m[i] = nr; m[64 + i] = ni;
        m[256 + i] += (m[320 + i] - m[256 + i]) * 0.05F;
        y += m[256 + i] * ni;
    }
    return y;
}

// ------------------------------------------------------------------------------------------------ STRING (a digital waveguide with two delay lines, bridge and nut)
// memory: neck 0..4095, bridge 4096..8191. k: 0 neck delay, 1 bridge delay, 2 loop gain, 3 lowpass a, 4 allpass c, 5 pluck gain, 6 hardness a,
// 7 nonlinear, 8 body, 9 bow slope, 10 bow vmax, 11 bow target
void Voice::prepareString(Gen& G, const GenCtl& c) noexcept {
    const double fmin = 12.0 * sr_ / 48000.0;
    const double f0 = clampf(static_cast<float>(std::fabs(G.incNow) * sr_), static_cast<float>(fmin), static_cast<float>(sr_ * 0.45));
    double P = sr_ / f0 / std::pow(2.0, static_cast<double>(c.f[11] - 0.5F) * 100.0 / 1200.0);
    const float T60 = mapLog(c.f[0], 0.05F, 30.0F);
    const float a = c.f[1] * 0.85F;
    const float cap = c.f[2] * 0.6F;
    const double lpDelay = static_cast<double>(a / (1.0F - a));
    const double apDelay = c.f[2] > 0.001F ? 2.0 * static_cast<double>((1.0F - cap) / (1.0F + cap)) : 0.0;
    double tot = P - lpDelay - apDelay;
    tot = std::clamp(tot, 5.0, 8000.0);
    const bool bow = G.aSel[1] == 0 && G.aSel[0] == EX_BOW;
    const float pos = clampf(bow ? c.f[7] : c.f[3], 0.04F, 0.5F);
    float db = static_cast<float>(tot) * pos, dn = static_cast<float>(tot) - db;
    db = std::clamp(db, 2.5F, 4090.0F); dn = std::clamp(dn, 2.5F, 4090.0F);
    G.k[0] = dn; G.k[1] = db;
    float T = T60;
    if (!in_.gate) T = std::min(T, 0.5F);   // the damper touches the string when the key is up
    G.k[2] = std::pow(10.0F, -3.0F * static_cast<float>(P / sr_) / T);
    G.k[3] = a; G.k[4] = cap;
    G.k[6] = 0.9F * (1.0F - c.f[4]);
    G.k[7] = c.f[8];
    G.k[8] = c.f[9];
    G.k[9] = 4.5F - 3.5F * c.f[5];
    G.k[10] = 0.1F + 0.5F * c.f[6];
    G.k[11] = in_.gate ? 1.0F : 0.0F;
    if (!G.started || G.excTotal == 0) {
        // the burst of a pluck / hammer is made when the string starts
        const float vel = 0.35F + 0.65F * in_.velocity;
        G.k[5] = vel;
        if (G.aSel[0] == EX_PLUCK) G.excTotal = std::max(8, static_cast<int>(mapLin(c.f[10], 1.0F, 40.0F) * 0.001F * static_cast<float>(sr_)));
        else if (G.aSel[0] == EX_HAMMER) G.excTotal = std::max(8, static_cast<int>(mapLin(1.0F - c.f[4], 0.5F, 8.0F) * 0.001F * static_cast<float>(sr_)));
        else if (G.aSel[0] == EX_IMPULSE) G.excTotal = 1;
        else G.excTotal = 1;
        G.excLeft = G.excTotal;
        G.started = true;
    }
}

float Voice::stringSample(int g, Gen& G, const GenCtl& c) noexcept {
    float* neck = mem_[static_cast<std::size_t>(g)].data();
    float* bridge = neck + 4096;
    constexpr int mask = 4095;
    const float dn = G.k[0], db = G.k[1];
    const float yb = rdDelay(bridge, mask, G.wB, db);
    const float yn = rdDelay(neck, mask, G.wN, dn);
    // bridge: loss, brightness, stiffness
    float x = yb * G.k[2];
    G.lpZ = flush((1.0F - G.k[3]) * x + G.k[3] * G.lpZ);
    float refl = -G.lpZ;
    if (G.k[4] > 0.0F) {
        const float ap = G.k[4];
        for (int s = 0; s < 2; ++s) { const float o = ap * refl + G.apZ[s] - ap * G.apY[s]; G.apZ[s] = flush(refl); G.apY[s] = flush(o); refl = o; }
    }
    if (G.k[7] > 0.0F) refl = refl / (1.0F + G.k[7] * 4.0F * std::fabs(refl));
    const float nut = -yn;
    // the exciter
    float e = 0.0F;
    const int ext = G.aSel[1];
    const float gate = G.k[11];
    G.bowSmooth += (gate - G.bowSmooth) * (gate > G.bowSmooth ? 0.0008F : 0.002F);   // the bow / breath ramps
    if (ext > 0 && ext <= kGens && ext - 1 != g) {
        e = modOut_[static_cast<std::size_t>(ext - 1)] * c.f[4] * 0.6F;
    } else {
        switch (G.aSel[0]) {
            case EX_PLUCK:
                if (G.excLeft > 0) {
                    const float env = static_cast<float>(G.excLeft) / static_cast<float>(G.excTotal);
                    G.excLp += (noiseOf(G.rng) - G.excLp) * (1.0F - G.k[6]);
                    e = G.excLp * env * G.k[5] * (1.0F + 3.0F * G.k[6]);
                    --G.excLeft;
                }
                break;
            case EX_HAMMER:
                if (G.excLeft > 0) {
                    const float ph = 1.0F - static_cast<float>(G.excLeft) / static_cast<float>(G.excTotal);
                    e = sinT(static_cast<double>(ph) * 0.5) * G.k[5] * 0.8F;
                    --G.excLeft;
                }
                break;
            case EX_IMPULSE:
                if (G.excLeft > 0) { e = G.k[5]; --G.excLeft; }
                break;
            case EX_NOISE:
                e = noiseOf(G.rng) * (0.04F + 0.4F * c.f[4]) * G.bowSmooth * (0.4F + 0.6F * in_.velocity);
                break;
            default: {   // EX_BOW: a friction curve between the bow and the string
                const float vb = G.k[10] * G.bowSmooth * (0.5F + 0.5F * in_.velocity);
                const float vs = refl + nut;
                const float vd = vb - vs;
                const float t = std::fabs(vd * G.k[9]) + 0.75F;
                const float t2 = t * t;
                float fr = 1.0F / (t2 * t2);
                fr = clampf(fr, 0.01F, 0.98F);
                e = vd * fr;
                break;
            }
        }
    }
    neck[G.wN & mask] = refl + e; G.wN = (G.wN + 1) & mask;
    bridge[G.wB & mask] = nut + e; G.wB = (G.wB + 1) & mask;
    float out = yb;
    if (G.k[8] > 0.001F) {   // the body: two broad resonances
        float bp1, hp1, bp2, hp2;
        if (G.bodyA[0] == 0.0F && G.bodyB[0] == 0.0F) { G.lip.set(230.0F, 3.0F, sr_); G.bell.set(540.0F, 3.0F, sr_); G.bodyA[0] = 1.0F; }
        G.lip.run(yb, bp1, hp1); G.bell.run(yb, bp2, hp2);
        out += (bp1 + bp2) * G.k[8] * 0.6F * G.lip.k;
    }
    return out * 0.7F;
}

// ------------------------------------------------------------------------------------------------ WIND
// A bore (one delay line = the round trip of the wave) with a one-pole low-pass (the losses and the bell), a source at the mouth:
//   CLARINET  a reed on a cylinder (closed at the reed, open at the bell: the wave comes back upside down, the period is 2 x the round trip)
//   SAX/ZURNA a reed on a cone (the round trip is the period; a high-pass in the loop keeps the pressure from locking to a constant)
//   KAVAL     an air jet across an edge, the jet delay and the bore make the tone
//   BRASS     a lip, a resonance that opens and closes the air for the bore
// memory: bore 0..4095, jet 4096..4607. k: 0 bore delay, 1 loop gain, 2 low-pass a, 3 reed offset, 4 reed slope, 5 jet delay, 6 loop sign,
// 7 mouth pressure aimed at, 8 attack seconds, 9 loop high-pass a (0 = none), 10 mouth-side noise
void Voice::prepareWind(Gen& G, const GenCtl& c) noexcept {
    const double fmin = 20.0 * sr_ / 48000.0;
    const double f0 = clampf(static_cast<float>(std::fabs(G.incNow) * sr_), static_cast<float>(fmin), static_cast<float>(sr_ * 0.4));
    const double P = sr_ / f0;
    const double w = kTwoPi * f0 / sr_;
    const int model = G.aSel[0];
    const float bright = c.f[3], damp = c.f[2], emb = c.f[1];
    // the low-pass of the loop: it makes the sound dark / bright and takes a little delay (calculated exactly at the note)
    const float a = 0.03F + 0.55F * (1.0F - bright) * (1.0F - bright);
    const double lpDelay = std::atan2(static_cast<double>(a) * std::sin(w), 1.0 - static_cast<double>(a) * std::cos(w)) / w;
    G.regSm += (c.f[6] - G.regSm) * 0.02F;
    double loop = P;           // the wanted delay round the whole loop
    float sign = -1.0F, g = 0.97F - 0.12F * damp, off = 0.7F, slope = -0.3F, ha = 0.0F;
    switch (model) {
        case WI_CLARINET: loop = P * 0.5 * (1.0 - static_cast<double>(G.regSm) * (2.0 / 3.0)); sign = -1.0F; off = 0.7F; slope = -(0.28F + 0.12F * emb); break;
        case WI_SAX:      loop = P * (1.0 - static_cast<double>(G.regSm) * 0.5); sign = 1.0F; off = 0.62F; slope = -(0.3F + 0.12F * emb); ha = 1.0F - static_cast<float>(kTwoPi * 0.18 * f0 / sr_); break;
        case WI_ZURNA:    loop = P * (1.0 - static_cast<double>(G.regSm) * 0.5); sign = 1.0F; off = 0.58F; slope = -(0.36F + 0.12F * emb); ha = 1.0F - static_cast<float>(kTwoPi * 0.18 * f0 / sr_); break;
        case WI_BRASS:    loop = P * 2.0 * (1.0 - static_cast<double>(G.regSm) * 0.5); sign = 1.0F; break;
        default:          loop = P * (1.0 - static_cast<double>(G.regSm) * 0.5); sign = 1.0F; break;   // KAVAL
    }
    double bore = loop - lpDelay;   // (the high-pass of a cone adds no delay that has to be taken off: measured)
    G.k[5] = 0.0F;
    if (model == WI_KAVAL) { const double jetRatio = 0.32; G.k[5] = static_cast<float>(std::clamp(bore * jetRatio / (1.0 + jetRatio), 3.0, 480.0)); bore = bore / (1.0 + jetRatio); }
    G.k[0] = static_cast<float>(std::clamp(bore, 4.0, 4000.0));
    G.k[1] = g; G.k[2] = a; G.k[3] = off; G.k[4] = slope; G.k[6] = sign; G.k[9] = ha;
    // the breath of the note: the pressure aimed at (a reed or a lip needs about 0.5 to start)
    const float cb = c.f[9];
    const float eff = c.f[0] * (1.0F - cb + cb * in_.breath);
    G.k[7] = (in_.gate && eff > 0.002F) ? (model == WI_CLARINET ? 0.52F + 0.3F * eff : (model == WI_KAVAL ? 0.15F + 0.85F * eff : 0.5F + 0.5F * eff)) : 0.0F;
    G.k[8] = mapLog(c.f[7], 0.01F, 0.5F);
    if (model == WI_BRASS) G.lip.set(static_cast<float>(f0) * (1.0F + G.regSm) * 0.945F * (1.0F + 0.05F * (c.f[10] - 0.5F)), 12.0F + 16.0F * emb, sr_);
}

float Voice::windSample(Gen& G, const GenCtl& c) noexcept {
    float* bore = mem_[static_cast<std::size_t>(&G - gen_.data())].data();
    float* jet = bore + 4096;
    constexpr int mask = 4095;
    // the pressure in the mouth follows the breath: it rises in the attack time and falls fast
    const bool rising = G.k[7] > G.pm;
    const float stepUp = 0.55F / (G.k[8] * static_cast<float>(sr_)), stepDn = 0.55F / (0.04F * static_cast<float>(sr_));
    G.pm += clampf(G.k[7] - G.pm, -stepDn, stepUp);
    (void)rising;
    G.vibPh += c.f[8] > 0.0F ? 5.3F / static_cast<float>(sr_) : 0.0F; G.vibPh -= std::floor(G.vibPh);
    G.growlPh += c.f[5] > 0.0F ? 38.0F / static_cast<float>(sr_) : 0.0F; G.growlPh -= std::floor(G.growlPh);
    const float nz = noiseOf(G.rng);
    const float pm = G.pm * (1.0F + c.f[8] * 0.12F * sinT(static_cast<double>(G.vibPh))) * (1.0F - c.f[5] * 0.35F * (0.5F + 0.5F * sinT(static_cast<double>(G.growlPh))));
    const int model = G.aSel[0];
    const float boreOut = rdDelay(bore, mask, G.wW, G.k[0]);
    G.windLp = flush(G.windLp + (1.0F - G.k[2]) * (boreOut - G.windLp));
    float back = G.windLp * G.k[1];   // what the bore gives back at the mouth
    if (G.k[9] > 0.0F) { const float y = G.k[9] * (G.hpY + back - G.hpX); G.hpX = back; G.hpY = flush(y); back = y; }
    float into = 0.0F;
    if (model == WI_KAVAL) {
        const float pb = G.k[6] * back;
        const float breath = pm * (1.0F + c.f[4] * 1.2F * nz);
        jet[G.wJ & 511] = pb * 3.0F; G.wJ = (G.wJ + 1) & 511;
        const float jd = rdDelay(jet, 511, G.wJ, clampf(G.k[5] + 1.0F, 2.5F, 500.0F));
        const float sj = clampf(jd - jd * jd * jd * (1.0F / 3.0F), -0.67F, 0.67F);
        const float x = breath * sj + breath * nz * (0.01F + 0.06F * c.f[4]);
        const float yDc = x - G.dcA + 0.995F * G.dcB; G.dcA = x; G.dcB = flush(yDc);
        into = yDc;
    } else if (model == WI_BRASS) {
        const float pb = G.k[6] * back;
        float bp = 0.0F, hp = 0.0F;
        const float mouth = 0.3F * pm * (1.0F + 0.3F * c.f[4] * nz);
        const float d = mouth - pb;
        const float y = G.lip.run(d, bp, hp);          // the lip: a spring with a mass, a resonance near the note
        const float op = std::min(y * y * 8.0F, 1.0F);   // how far it is open (never negative)
        const float x = op * mouth + (1.0F - op) * pb;
        const float yDc = x - G.dcA + 0.995F * G.dcB; G.dcA = x; G.dcB = flush(yDc);
        into = yDc;
    } else {
        const float pmN = pm * (1.0F + c.f[4] * 0.2F * nz);
        const float pb = G.k[6] * back * 0.95F;
        const float diff = pb - pmN;
        const float refl = clampf(G.k[3] + G.k[4] * diff, -1.0F, 1.0F);
        into = pmN + diff * refl;
    }
    bore[G.wW & mask] = into; G.wW = (G.wW + 1) & mask;
    // what comes out of the bell: a little brightness control and, for the zurna, a nasal resonance
    float o = boreOut;
    G.windOut += (o - G.windOut) * clampf(static_cast<float>(kTwoPi) * mapLog(c.f[3] * c.f[3], 1500.0F, 16000.0F) / static_cast<float>(sr_), 0.0F, 0.95F);
    G.windOut = flush(G.windOut);
    o = G.windOut;
    if (model == WI_ZURNA) {
        if (G.bellSet == 0) { G.bell.set(1300.0F, 2.5F, sr_); G.bellSet = 1; }
        float bp, hp; G.bell.run(o, bp, hp);
        o += bp * G.bell.k * 0.8F;
    }
    o += nz * c.f[4] * 0.1F * clampf(G.pm * 2.0F - 0.8F, 0.0F, 1.0F);   // the air noise
    return o * 0.8F;
}

// ------------------------------------------------------------------------------------------------ MODAL (a bank of damped resonators)
// memory: y1 0..31, y2 32..63, a1 64..95, a2 96..127, gain 128..159. k: 0 count, 1 burst length, 2 burst gain
void Voice::prepareModal(Gen& G, const GenCtl& c) noexcept {
    float* m = mem_[static_cast<std::size_t>(&G - gen_.data())].data();
    static constexpr float bar[] = {1.0F, 2.756F, 5.404F, 8.933F, 13.344F, 18.638F, 24.814F, 31.88F};
    static constexpr float plate[] = {1.0F, 1.593F, 2.136F, 2.296F, 2.653F, 2.918F, 3.156F, 3.501F, 3.600F, 3.652F, 4.060F, 4.154F};
    static constexpr float bell[] = {0.5F, 1.0F, 1.183F, 1.506F, 2.0F, 2.514F, 2.662F, 3.011F, 4.166F, 5.433F, 6.796F, 8.215F};
    static constexpr float wood[] = {1.0F, 3.9F, 9.2F, 15.0F, 22.0F};
    static constexpr float glass[] = {1.0F, 2.32F, 4.25F, 6.63F, 9.38F, 12.5F, 16.0F};
    const double f0 = std::fabs(G.incNow) * sr_;
    const int count = std::clamp(1 + static_cast<int>(std::lround(c.f[5] * 31.0F)), 1, 32);
    const float T60 = mapLog(c.f[0], 0.05F, 20.0F) * (in_.gate ? 1.0F : 0.5F);
    const float tiltD = c.f[1] * 4.0F;
    const float inh = c.f[2];
    const float hard = c.f[4], pos = c.f[3], br = c.f[6];
    int made = 0;
    // the strike lasts a few milliseconds, but never longer than 3/4 of a period (else the high notes would hardly be struck at all)
    const float strikeW = std::max(6.0F, std::min(mapLin(1.0F - hard, 0.4F, 6.0F) * 0.001F * static_cast<float>(sr_), static_cast<float>(0.75 * sr_ / std::max(f0, 20.0))));
    const float strikeSum = 3.0F * 0.64F * strikeW;   // the size of the strike (a half-sine bump of height 3)
    for (int k = 0; k < 32; ++k) {
        float ratio = 1.0F;
        switch (G.aSel[0]) {
            case MA_BAR: ratio = k < 8 ? bar[k] : bar[7] * std::pow(static_cast<float>(k + 1) / 8.0F, 2.0F); break;
            case MA_PLATE: ratio = k < 12 ? plate[k] : plate[11] + 0.45F * static_cast<float>(k - 11); break;
            case MA_BELL: ratio = k < 12 ? bell[k] : bell[11] + 1.5F * static_cast<float>(k - 11); break;
            case MA_TUBE: ratio = static_cast<float>(2 * k + 1); break;
            case MA_WOOD: ratio = k < 5 ? wood[k] : wood[4] + 8.0F * static_cast<float>(k - 4); break;
            default: ratio = k < 7 ? glass[k] : glass[6] + 3.8F * static_cast<float>(k - 6); break;
        }
        ratio *= 1.0F + inh * 0.02F * static_cast<float>(k * k);
        const double fk = f0 * static_cast<double>(ratio);
        const auto i = static_cast<std::size_t>(k);
        if (k >= count || fk >= sr_ * 0.45 || fk <= 1.0) { m[128 + i] = 0.0F; m[64 + i] = 0.0F; m[96 + i] = 0.0F; continue; }
        const float t60k = T60 / (1.0F + tiltD * 0.35F * std::max(ratio - 1.0F, 0.0F));   // the higher modes die sooner
        const double r = std::pow(10.0, -3.0 / (static_cast<double>(t60k) * sr_));
        m[96 + i] = static_cast<float>(r * r);
        m[64 + i] = static_cast<float>(2.0 * r * std::cos(kTwoPi * fk / sr_));
        float w = std::fabs(std::sin(3.14159265F * pos * static_cast<float>(k + 1)));
        w *= 1.0F / (1.0F + static_cast<float>(fk) / (400.0F + 9000.0F * hard));
        w *= std::pow(static_cast<float>(fk / std::max(f0, 1.0)), br - 0.6F);
        // every mode answers the strike with about the same size, whatever its pitch (an impulse answer of a resonator peaks at 1/sin(w))
        m[128 + i] = w * 0.8F * static_cast<float>(std::sin(kTwoPi * fk / sr_)) / strikeSum;
        made = k + 1;
    }
    G.modalCount = made;
    if (G.strikeN == 0) {   // the first chunk of the note: the strike
        G.strikeTotal = strikeW;
        G.strikeLeft = G.strikeTotal;
        G.strikeN = 1;
    }
}

float Voice::modalSample(int g, Gen& G, const GenCtl& c) noexcept {
    float* m = mem_[static_cast<std::size_t>(g)].data();
    float e = 0.0F;
    const int ext = G.aSel[1];
    if (ext > 0 && ext <= kGens && ext - 1 != g) e = modOut_[static_cast<std::size_t>(ext - 1)] * 0.8F;
    else if (G.strikeLeft > 0.0F) {
        const float ph = 1.0F - G.strikeLeft / G.strikeTotal;
        e = sinT(static_cast<double>(ph) * 0.5) * (0.35F + 0.65F * in_.velocity) * 3.0F;
        G.strikeLeft -= 1.0F;
    }
    (void)c;
    float y = 0.0F;
    for (int k = 0; k < G.modalCount; ++k) {
        const float y0 = m[64 + k] * m[k] - m[96 + k] * m[32 + k] + e;
        m[32 + k] = m[k]; m[k] = flush(y0);
        y += y0 * m[128 + k];
    }
    return y;
}

// ------------------------------------------------------------------------------------------------ NOISE
float Voice::noiseSample(Gen& G, const GenCtl& c) noexcept {
    const float w = noiseOf(G.rng);
    float y = 0.0F;
    switch (G.aSel[0]) {
        case NC_WHITE: y = w * 0.5F; break;
        case NC_PINK:
            G.pink[0] = 0.99765F * G.pink[0] + w * 0.0990460F; G.pink[1] = 0.96300F * G.pink[1] + w * 0.2965164F; G.pink[2] = 0.57000F * G.pink[2] + w * 1.0526913F;
            y = (G.pink[0] + G.pink[1] + G.pink[2] + w * 0.1848F) * 0.22F; break;
        case NC_BROWN: G.brown = flush((G.brown + 0.02F * w) / 1.02F); y = G.brown * 3.5F; break;
        case NC_BLUE: y = (w - G.nzPrev) * 0.35F; G.nzPrev = w; break;
        case NC_CRACKLE: {
            const float d = c.f[3];
            const float prob = d * d * d * 0.02F;
            if (std::fabs(w) < prob * 2.0F) G.nzHold = noiseOf(G.rng) * 1.2F;
            y = G.nzHold; G.nzHold *= 0.75F; break;
        }
        default: {   // sample & hold
            const int every = std::max(1, static_cast<int>(sr_ / mapLog(1.0F - c.f[4] * 0.999F, 20.0F, static_cast<float>(sr_) * 0.5F)));
            if (++G.nzCount >= every) { G.nzCount = 0; G.nzHold = w * 0.6F; }
            y = G.nzHold; break;
        }
    }
    const float tilt = (c.f[0] - 0.5F) * 2.0F;
    if (std::fabs(tilt) > 0.02F) {
        G.nzLp += (y - G.nzLp) * 0.1F; G.nzLp = flush(G.nzLp);
        y = tilt < 0.0F ? y + (-tilt) * (G.nzLp - y) : y + tilt * 2.0F * (y - G.nzLp);
    }
    if (c.f[2] < 0.999F) {
        if (G.k[0] != c.f[1] + 10.0F * c.f[2]) { G.band.set(mapLog(c.f[1], 40.0F, 12000.0F), 0.7F + 30.0F * (1.0F - c.f[2]) * (1.0F - c.f[2]), sr_); G.k[0] = c.f[1] + 10.0F * c.f[2]; }
        float bp, hp; G.band.run(y, bp, hp);
        y = bp * G.band.k * 1.5F;
    }
    return y;
}

// ------------------------------------------------------------------------------------------------ GRANULAR (grains cut from the generator's own sound)
float Voice::grainSample(int g, Gen& G, const GenCtl& c, float& side) noexcept {
    float* ring = mem_[static_cast<std::size_t>(g)].data();
    constexpr int mask = kMemSize - 1;
    const int srcIdx = G.aSel[0];
    const float src = (srcIdx >= 0 && srcIdx < kGens && srcIdx != g) ? modOut_[static_cast<std::size_t>(srcIdx)] : 0.0F;
    if (c.f[7] < 0.5F) { ring[G.gW & mask] = src; G.gW = (G.gW + 1) & mask; }   // FREEZE stops the recording of the source
    const float lenSec = mapLog(c.f[0], 0.005F, 0.12F);
    const int len = std::clamp(static_cast<int>(lenSec * static_cast<float>(sr_)), 16, 4000);
    const float density = mapLog(c.f[1], 1.0F, 200.0F);
    G.gTimer -= 1.0;
    if (G.gTimer <= 0.0) {
        G.gTimer += static_cast<double>(sr_ / density) * (0.75 + 0.5 * static_cast<double>(noiseOf(G.sRng) * 0.5F + 0.5F));
        for (auto& gr : G.grains) {
            if (gr.on) continue;
            const float rnd = noiseOf(G.sRng), rnd2 = noiseOf(G.sRng), rnd3 = noiseOf(G.sRng);
            const double pr = std::pow(2.0, static_cast<double>((c.f[4] - 0.5F) * 2.0F * 24.0F + rnd * c.f[5] * 12.0F) / 12.0);
            const bool rev = (rnd3 * 0.5F + 0.5F) < c.f[6];
            const int minBack = static_cast<int>(static_cast<double>(len) * std::fabs(pr)) + 24;
            const int maxBack = kMemSize - 24;
            const float where = clampf(c.f[2] + rnd2 * c.f[3] * 0.5F, 0.0F, 1.0F);
            const int back = std::clamp(minBack + static_cast<int>(where * static_cast<float>(std::max(0, maxBack - minBack))), minBack, maxBack);
            gr.on = true; gr.age = 0; gr.len = len; gr.inc = rev ? -pr : pr;
            gr.pos = static_cast<double>(G.gW - back) + (rev ? static_cast<double>(len) * pr : 0.0);
            gr.pan = 0.5F + rnd * c.f[8] * 0.5F;
            break;
        }
    }
    float y = 0.0F, sd = 0.0F;
    const float norm = 1.0F / std::sqrt(std::max(1.0F, density * lenSec));
    for (auto& gr : G.grains) {
        if (!gr.on) continue;
        const double pi = std::floor(gr.pos); const float f = static_cast<float>(gr.pos - pi);
        const int i0 = static_cast<int>(pi);
        const float s0 = ring[(i0 - 1) & mask], s1 = ring[i0 & mask], s2 = ring[(i0 + 1) & mask], s3 = ring[(i0 + 2) & mask];
        const float c1 = 0.5F * (s2 - s0), c2 = s0 - 2.5F * s1 + 2.0F * s2 - 0.5F * s3, c3 = 0.5F * (s3 - s0) + 1.5F * (s1 - s2);
        const float v = ((c3 * f + c2) * f + c1) * f + s1;
        const float x = static_cast<float>(gr.age) / static_cast<float>(gr.len);
        float win = 0.0F;
        switch (G.aSel[1]) {
            case 0: win = 0.5F - 0.5F * cosT(static_cast<double>(x)); break;
            case 1: win = 1.0F - std::fabs(2.0F * x - 1.0F); break;
            case 2: win = std::exp(-18.0F * (x - 0.5F) * (x - 0.5F)); break;
            default: win = x < 0.2F ? 0.5F - 0.5F * cosT(static_cast<double>(x * 2.5F)) : (x > 0.8F ? 0.5F - 0.5F * cosT(static_cast<double>((1.0F - x) * 2.5F)) : 1.0F); break;
        }
        y += v * win; sd += v * win * (gr.pan - 0.5F) * 2.0F * 0.5F;
        gr.pos += gr.inc; ++gr.age;
        if (gr.age >= gr.len) gr.on = false;
    }
    y *= norm; sd *= norm;
    y += c.f[9] * src; side = sd;
    return y;
}

// ------------------------------------------------------------------------------------------------ SPECTRAL (the short-time spectrum of the generator's own sound)
// memory: input ring 0..511, output ring 512..1535, re 1536..2047, im 2048..2559, hold mag 2560..2815, phase acc 2816..3071, prev mag 3072..3327, tmp mag 3328..3583, tmp ph 3584..3839
float Voice::spectralSample(int g, Gen& G, const GenCtl& c) noexcept {
    float* m = mem_[static_cast<std::size_t>(g)].data();
    float* inR = m; float* outR = m + 512; float* re = m + 1536; float* im = m + 2048;
    float* hold = m + 2560; float* pacc = m + 2816; float* prev = m + 3072; float* nm = m + 3328; float* np = m + 3584;
    const int srcIdx = G.aSel[0];
    const float src = (srcIdx >= 0 && srcIdx < kGens && srcIdx != g) ? modOut_[static_cast<std::size_t>(srcIdx)] : 0.0F;
    inR[G.sW & 511] = src;
    ++G.sW;
    constexpr int hop = 128;
    if ((G.sW % hop) == 0) {
        const FftTables& T = fftTables();
        for (int k = 0; k < kFft; ++k) { re[k] = inR[(G.sW - kFft + k) & 511] * T.win[k]; im[k] = 0.0F; }
        fft512(re, im, false);
        constexpr int nb = kFft / 2 + 1;
        float maxMag = 0.0F;
        for (int k = 0; k < nb; ++k) { nm[k] = std::sqrt(re[k] * re[k] + im[k] * im[k]); np[k] = std::atan2(im[k], re[k]); maxMag = std::max(maxMag, nm[k]); }
        const bool frozen = c.f[4] >= 0.5F;
        if (frozen && G.holdMag == 0.0F) { for (int k = 0; k < nb; ++k) hold[k] = nm[k]; G.holdMag = 1.0F; }
        if (!frozen) G.holdMag = 0.0F;
        const int op = G.aSel[1];
        // the operation works on a copy of the magnitudes; shifts / stretches move the bins
        float mag[nb], ph[nb];
        for (int k = 0; k < nb; ++k) { mag[k] = nm[k]; ph[k] = np[k]; }
        switch (op) {
            case SP_BLUR: {
                const float b = c.f[3] * 0.97F;
                for (int k = 0; k < nb; ++k) {
                    const float sm = 0.25F * nm[std::max(k - 1, 0)] + 0.5F * nm[k] + 0.25F * nm[std::min(k + 1, nb - 1)];
                    mag[k] = prev[k] * b + sm * (1.0F - b);
                }
                break;
            }
            case SP_SHIFT: case SP_STRETCH: {
                const float fac = op == SP_SHIFT ? std::pow(2.0F, (c.f[1] - 0.5F) * 2.0F * 24.0F / 12.0F) : 0.5F + c.f[6];
                for (int k = 0; k < nb; ++k) { mag[k] = 0.0F; }
                for (int k = 1; k < nb; ++k) {
                    const int j = static_cast<int>(std::lround(static_cast<float>(k) * fac));
                    if (j >= 1 && j < nb) { mag[j] += nm[k]; ph[j] = np[k]; }
                }
                break;
            }
            case SP_GATE: {
                const float thr = c.f[2] * c.f[2] * maxMag;
                for (int k = 0; k < nb; ++k) if (nm[k] < thr) mag[k] = 0.0F;
                break;
            }
            case SP_TILT: {
                const float tl = (c.f[5] - 0.5F) * 24.0F;
                for (int k = 1; k < nb; ++k) mag[k] = nm[k] * std::pow(10.0F, tl * std::log2(static_cast<float>(k) / 8.0F) / 20.0F);
                break;
            }
            case SP_COMB: {
                const float period = 2.0F + c.f[6] * 60.0F;
                for (int k = 0; k < nb; ++k) mag[k] = nm[k] * (1.0F - c.f[3] + c.f[3] * (0.5F + 0.5F * std::cos(static_cast<float>(kTwoPi) * static_cast<float>(k) / period)));
                break;
            }
            case SP_WHISPER: {
                for (int k = 0; k < nb; ++k) { const float r = noiseOf(G.sRng) * 3.14159265F; ph[k] = ph[k] + (r - ph[k]) * c.f[3]; }
                break;
            }
            default: break;   // SP_FREEZE: the hold below does the work
        }
        for (int k = 0; k < nb; ++k) prev[k] = mag[k];
        if (frozen || op == SP_FREEZE) {
            if (op == SP_FREEZE && !frozen) { /* a freeze with the hold open follows the sound */ }
            else {
                for (int k = 0; k < nb; ++k) { mag[k] = hold[k]; pacc[k] += static_cast<float>(kTwoPi) * static_cast<float>(k) * static_cast<float>(hop) / static_cast<float>(kFft); pacc[k] = std::fmod(pacc[k], static_cast<float>(kTwoPi)); ph[k] = pacc[k]; }
            }
        } else for (int k = 0; k < nb; ++k) pacc[k] = ph[k];
        for (int k = 0; k < nb; ++k) { re[k] = mag[k] * std::cos(ph[k]); im[k] = mag[k] * std::sin(ph[k]); }
        im[0] = 0.0F; im[nb - 1] = 0.0F;
        for (int k = 1; k < kFft / 2; ++k) { re[kFft - k] = re[k]; im[kFft - k] = -im[k]; }
        fft512(re, im, true);
        for (int k = 0; k < kFft; ++k) outR[(G.sW - kFft + k) & 1023] += re[k] * T.win[k] * (0.5F / static_cast<float>(kFft)) * 2.0F;
    }
    const int q = (G.sW - kFft) & 1023;
    const float wet = outR[q]; outR[q] = 0.0F;
    const float dry = inR[(G.sW - kFft) & 511];
    const float amount = c.f[0];
    return dry + (wet - dry) * amount + c.f[7] * src;
}

} // namespace silveton::sampler::suse
