// SILVETON_SUSE_V1 - the preset text of SILVETON SYNTH (versioned, with a check sum), the factory presets and the loudness.
#include "silveton/sampler/SuseTools.h"

#include "SuseVoice.h"
#include "silveton/sampler/UserWaves.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>

namespace silveton::sampler::suse {

// ------------------------------------------------------------------------------------------------- check sum and text
std::uint32_t crc32(const void* data, std::size_t n) noexcept {
    static std::uint32_t table[256];
    static bool made = false;
    if (!made) {
        for (std::uint32_t i = 0; i < 256U; ++i) {
            std::uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1U) != 0U ? 0xEDB88320U ^ (c >> 1U) : c >> 1U;
            table[i] = c;
        }
        made = true;
    }
    std::uint32_t c = 0xFFFFFFFFU;
    const auto* b = static_cast<const unsigned char*>(data);
    for (std::size_t i = 0; i < n; ++i) c = table[(c ^ b[i]) & 0xFFU] ^ (c >> 8U);
    return c ^ 0xFFFFFFFFU;
}

namespace {

std::string cleanName(const std::string& in) {
    std::string s;
    for (const char ch : in) {
        const auto u = static_cast<unsigned char>(ch);
        if (u < 32U || u == 127U) s += ' '; else s += ch;
    }
    while (!s.empty() && s.front() == ' ') s.erase(s.begin());
    while (!s.empty() && s.back() == ' ') s.pop_back();
    if (s.size() > kPresetNameMax) {
        std::size_t cut = kPresetNameMax;
        while (cut > 0U && (static_cast<unsigned char>(s[cut]) & 0xC0U) == 0x80U) --cut;   // do not cut a letter in two
        s.resize(cut);
    }
    return s.empty() ? std::string("SOUND") : s;
}

std::string hexOf(const float* v, int n) {
    static const char* const d = "0123456789abcdef";
    std::string s;
    s.reserve(static_cast<std::size_t>(n) * 8U);
    for (int i = 0; i < n; ++i) {
        std::uint32_t u = 0;
        std::memcpy(&u, &v[i], 4);
        for (int k = 7; k >= 0; --k) s += d[(u >> (4U * static_cast<unsigned>(k))) & 15U];
    }
    return s;
}

bool unhex(const std::string& s, std::size_t at, float& out) {
    std::uint32_t u = 0;
    for (std::size_t k = 0; k < 8U; ++k) {
        const char c = s[at + k];
        int d = -1;
        if (c >= '0' && c <= '9') d = c - '0'; else if (c >= 'a' && c <= 'f') d = c - 'a' + 10; else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
        if (d < 0) return false;
        u = (u << 4U) | static_cast<std::uint32_t>(d);
    }
    std::memcpy(&out, &u, 4);
    return true;
}

std::string hex8(std::uint32_t v) {
    char b[16];
    std::snprintf(b, sizeof b, "%08x", static_cast<unsigned>(v));
    return b;
}

// the lines "key=value" of a block after its first line
bool field(const std::string& text, const char* key, std::string& value) {
    const std::string k = std::string("\n") + key + "=";
    const std::size_t at = text.find(k);
    if (at == std::string::npos) return false;
    const std::size_t from = at + k.size();
    const std::size_t to = text.find('\n', from);
    value = text.substr(from, to == std::string::npos ? std::string::npos : to - from);
    return true;
}

std::string block(const char* magic, const std::string& name, const float* v, int n) {
    std::string body = "name=" + cleanName(name) + "\ncount=" + std::to_string(n) + "\ndata=" + hexOf(v, n) + "\n";
    const std::string head = std::string(magic) + " " + std::to_string(kPresetVersion) + "\n";
    return head + body + "crc=" + hex8(crc32(body.data(), body.size())) + "\n";
}

// reads one block: checks magic, version and the check sum; gives the numbers as they are
bool readBlock(const std::string& text, const char* magic, std::string& name, std::vector<float>& v, std::string& error) {
    const std::size_t nl = text.find('\n');
    if (nl == std::string::npos || text.compare(0U, std::strlen(magic), magic) != 0 || text[std::strlen(magic)] != ' ') { error = "Това не е файл на SILVETON SYNTH"; return false; }
    const int ver = std::atoi(text.substr(std::strlen(magic) + 1U, nl - std::strlen(magic) - 1U).c_str());
    if (ver < 1) { error = "Файлът е повреден (версия)"; return false; }
    if (ver > kPresetVersion) { error = "Файлът е от по-нова версия на програмата"; return false; }
    const std::size_t crcAt = text.find("\ncrc=", nl);
    if (crcAt == std::string::npos) { error = "Файлът е повреден (няма проверка)"; return false; }
    const std::string body = text.substr(nl + 1U, crcAt + 1U - (nl + 1U));
    std::string crcText;
    if (!field(text, "crc", crcText) || crcText.size() != 8U) { error = "Файлът е повреден (проверка)"; return false; }
    if (hex8(crc32(body.data(), body.size())) != crcText) { error = "Файлът е повреден (проверката не съвпада)"; return false; }
    std::string countText, data;
    if (!field(text, "name", name) || !field(text, "count", countText) || !field(text, "data", data)) { error = "Файлът е повреден (липсват данни)"; return false; }
    const int n = std::atoi(countText.c_str());
    if (n < 1 || n > 8192 || data.size() != static_cast<std::size_t>(n) * 8U) { error = "Файлът е повреден (брой числа)"; return false; }
    v.assign(static_cast<std::size_t>(n), 0.0F);
    for (int i = 0; i < n; ++i) if (!unhex(data, static_cast<std::size_t>(i) * 8U, v[static_cast<std::size_t>(i)])) { error = "Файлът е повреден (число)"; return false; }
    return true;
}

}  // namespace

std::string encodePreset(const std::string& name, const float* patch) { return block("SUSP", name, patch, kParamCount); }

bool decodePreset(const std::string& text, std::string& name, float* patch, std::string& error) {
    std::vector<float> v;
    if (!readBlock(text, "SUSP", name, v, error)) return false;
    setDefaults(patch);   // a preset with fewer numbers keeps the start values for the rest
    const int n = std::min(static_cast<int>(v.size()), kParamCount);
    for (int i = 0; i < n; ++i) if (std::isfinite(v[static_cast<std::size_t>(i)])) patch[i] = clampParam(i, v[static_cast<std::size_t>(i)]);
    name = cleanName(name);
    return true;
}

std::string encodeBank(const std::vector<PresetEntry>& presets) {
    std::string s = "SUSB " + std::to_string(kPresetVersion) + "\ncount=" + std::to_string(presets.size()) + "\n";
    for (const PresetEntry& e : presets) {
        std::vector<float> p(kParamCount, 0.0F);
        for (int i = 0; i < kParamCount && i < static_cast<int>(e.patch.size()); ++i) p[static_cast<std::size_t>(i)] = e.patch[static_cast<std::size_t>(i)];
        s += encodePreset(e.name, p.data());
    }
    return s;
}

bool decodeBank(const std::string& text, std::vector<PresetEntry>& out, std::string& error) {
    out.clear();
    const std::size_t nl = text.find('\n');
    if (nl == std::string::npos || text.compare(0U, 5U, "SUSB ") != 0) { error = "Това не е банка на SILVETON SYNTH"; return false; }
    if (std::atoi(text.substr(5U, nl - 5U).c_str()) > kPresetVersion) { error = "Файлът е от по-нова версия на програмата"; return false; }
    std::string countText;
    if (!field(text, "count", countText)) { error = "Файлът е повреден"; return false; }
    const int count = std::atoi(countText.c_str());
    std::size_t at = text.find("\nSUSP ");
    while (at != std::string::npos) {
        const std::size_t start = at + 1U;
        const std::size_t next = text.find("\nSUSP ", start);
        const std::string part = text.substr(start, next == std::string::npos ? std::string::npos : next + 1U - start);
        PresetEntry e;
        std::vector<float> patch(kParamCount, 0.0F);
        std::string name;
        if (!decodePreset(part, name, patch.data(), error)) return false;
        e.name = name; e.patch = std::move(patch);
        out.push_back(std::move(e));
        at = next;
    }
    if (static_cast<int>(out.size()) != count) { error = "Файлът е повреден (липсват звуци)"; out.clear(); return false; }
    return true;
}

std::string encodeWave(const std::string& name, const float* points) { return block("SUSW", name, points, kDrawLen); }

bool decodeWave(const std::string& text, std::string& name, float* points, std::string& error) {
    std::vector<float> v;
    if (!readBlock(text, "SUSW", name, v, error)) return false;
    if (static_cast<int>(v.size()) != kDrawLen) { error = "Файлът е повреден (брой точки)"; return false; }
    for (int i = 0; i < kDrawLen; ++i) points[i] = std::isfinite(v[static_cast<std::size_t>(i)]) ? std::clamp(v[static_cast<std::size_t>(i)], -1.0F, 1.0F) : 0.0F;
    name = cleanName(name);
    return true;
}

// ------------------------------------------------------------------------------------------------- the factory presets
namespace {

float tOf(float sec) { return sec <= 0.0F ? 0.0F : std::min(1.0F, std::log10(sec / rng::kTimeLo) / 4.0F); }
void env(float* p, int e, float a, float d, float s, float r) {
    p[envId(e, envT(0))] = tOf(a); p[envId(e, envL(0))] = 1.0F;
    p[envId(e, envT(1))] = tOf(d); p[envId(e, envL(1))] = s;
    p[envId(e, EV_SUS)] = 1.0F; p[envId(e, EV_REL)] = tOf(r);
}
void level(float* p, int g, float db) { p[genId(g, GN_LEVEL)] = std::clamp((db - rng::kGenDbLo) / (rng::kGenDbHi - rng::kGenDbLo), 0.0F, 1.0F); }
void ratio(float* p, int g, float r) { p[genId(g, GN_RATIO)] = unmapLog(r, rng::kRatioLo, rng::kRatioHi); }
void waveGen(float* p, int g, int a) { setMethod(p, g, M_WAVE); p[genId(g, GN_SEL1)] = static_cast<float>(a); p[genId(g, GN_F0)] = 0.0F; p[genId(g, GN_SEL3)] = 0.0F; p[genId(g, GN_F0 + 4)] = 0.0F; }
void method(float* p, int g, int m, int sel1 = 0) { setMethod(p, g, m); p[genId(g, GN_SEL1)] = static_cast<float>(sel1); p[genId(g, GN_SEL2)] = m == M_STRING || m == M_MODAL ? 0.0F : p[genId(g, GN_SEL2)]; }
void mute(float* p, int g) { p[genId(g, GN_MUTE)] = 1.0F; }
void filt(float* p, int f, int type, float hz, float res) { p[filterId(f, FL_TYPE)] = static_cast<float>(type); p[filterId(f, FL_CUT)] = unmapLog(hz, rng::kCutLo, rng::kCutHi); p[filterId(f, FL_RES)] = res; }
void link(float* p, int dst, int src, int type, float amt) { p[linkType(dst, src)] = static_cast<float>(type); p[linkAmt(dst, src)] = amt; }
void mod(float* p, int slot, int src, int dest, float amount) { p[modId(slot, 0)] = static_cast<float>(src); p[modId(slot, 1)] = static_cast<float>(dest); p[modId(slot, 2)] = 0.5F + 0.5F * amount; }
void lfo(float* p, int l, int wave, float hz) { p[lfoId(l, LF_WAVE)] = static_cast<float>(wave); p[lfoId(l, LF_RATE)] = unmapLog(hz, rng::kLfoLo, rng::kLfoHi); }
void noFilters(float* p) { p[filterId(0, FL_TYPE)] = static_cast<float>(FT_OFF); p[filterId(1, FL_TYPE)] = static_cast<float>(FT_OFF); }
void wind(float* p, int instrument, float a, float r) {
    method(p, 0, M_WIND, instrument); noFilters(p); env(p, 0, a, 0.1F, 1.0F, r);
    p[G_RETRIG] = 0.0F; p[G_KEEP_RES] = 1.0F;
}
void unison(float* p, int g, int n, float det) { p[genId(g, GN_UNISON)] = static_cast<float>(n); p[genId(g, GN_UNIDET)] = det; }
void tuning(float* p, int root, const int* degreeCents, int n) {
    p[tuneId(TN_ON)] = 1.0F; p[tuneId(TN_ROOT)] = static_cast<float>(root);
    for (int i = 0; i < n; ++i) p[tuneId(TN_CENTS + degreeCents[2 * i])] = 0.5F + static_cast<float>(degreeCents[2 * i + 1]) / 200.0F;
}

struct Factory { const char* name; const char* group; };
const Factory kFactory[] = {
    {"INIT SAW", "BASIC"},
    {"CLARINET", "WINDS"}, {"SAX", "WINDS"}, {"ZURNA", "WINDS"}, {"KAVAL", "WINDS"}, {"BRASS", "WINDS"},
    {"VIOLIN", "STRINGS"}, {"PLUCKED STRING", "STRINGS"}, {"HAMMERED STRING", "STRINGS"}, {"STRING + SAW EXCITER", "STRINGS"},
    {"FM E-PIANO", "FM"}, {"FM BELL", "FM"}, {"6-OP FM PAD", "FM"}, {"RING METAL", "FM"}, {"SYNC LEAD", "FM"},
    {"ADDITIVE ORGAN", "ADDITIVE"}, {"FORMANT CHOIR", "ADDITIVE"},
    {"SUB BASS", "SUBTRACTIVE"}, {"ANALOG PAD", "SUBTRACTIVE"}, {"WAVE MORPH LEAD", "SUBTRACTIVE"},
    {"GRANULAR CLOUD", "TEXTURE"}, {"SPECTRAL SHIMMER", "TEXTURE"}, {"WIND NOISE", "TEXTURE"},
    {"MODAL BELL", "MODAL"}, {"MARIMBA", "MODAL"}, {"GLASS", "MODAL"},
    {"RAST PAD", "MICROTONAL"}, {"BAYATI REED", "MICROTONAL"},
};
constexpr int kFactoryCount = static_cast<int>(sizeof(kFactory) / sizeof(kFactory[0]));

}  // namespace

int factoryPresetCount() noexcept { return kFactoryCount; }
const char* factoryPresetName(int i) noexcept { return kFactory[std::clamp(i, 0, kFactoryCount - 1)].name; }
const char* factoryPresetGroup(int i) noexcept { return kFactory[std::clamp(i, 0, kFactoryCount - 1)].group; }

void factoryPreset(int i, float* p) noexcept {
    setDefaults(p);
    switch (std::clamp(i, 0, kFactoryCount - 1)) {
        case 0: break;
        case 1: wind(p, WI_CLARINET, 0.03F, 0.12F); break;
        case 2: wind(p, WI_SAX, 0.05F, 0.15F); break;
        case 3: wind(p, WI_ZURNA, 0.03F, 0.12F); break;
        case 4: wind(p, WI_KAVAL, 0.08F, 0.25F); p[genId(0, GN_F0 + 4)] = 0.3F; break;
        case 5: wind(p, WI_BRASS, 0.06F, 0.15F); break;
        case 6:   // VIOLIN: a bowed string with a body, a slow start and a little vibrato from the wheel
            method(p, 0, M_STRING, EX_BOW); noFilters(p); env(p, 0, 0.12F, 0.2F, 1.0F, 0.3F); p[genId(0, GN_F0 + 9)] = 0.6F;
            p[G_VIB_DEPTH] = 0.2F; p[G_VIB_WHEEL] = 0.0F; break;
        case 7: method(p, 0, M_STRING, EX_PLUCK); noFilters(p); env(p, 0, 0.001F, 0.3F, 1.0F, 0.4F); break;
        case 8: method(p, 0, M_STRING, EX_HAMMER); noFilters(p); env(p, 0, 0.001F, 0.3F, 1.0F, 0.5F); p[genId(0, GN_F0 + 9)] = 0.5F; break;
        case 9:   // a saw (generator 2) strikes the string of generator 1; the saw itself is not heard
            method(p, 0, M_STRING, EX_NOISE); p[genId(0, GN_SEL2)] = 2.0F; noFilters(p); env(p, 0, 0.02F, 0.2F, 1.0F, 0.4F);
            waveGen(p, 1, 2); mute(p, 1); p[genId(1, GN_AMPENV)] = 1.0F; break;
        case 10:   // two sine operators: the second one bends the first, and dies away quickly
            waveGen(p, 0, 0); waveGen(p, 1, 0); mute(p, 1); noFilters(p); link(p, 0, 1, L_FM, 0.3F);
            p[genId(1, GN_AMPENV)] = 2.0F; env(p, 0, 0.002F, 1.2F, 0.0F, 0.3F); env(p, 1, 0.001F, 0.5F, 0.0F, 0.2F);
            waveGen(p, 2, 0); mute(p, 2); ratio(p, 2, 14.0F); link(p, 0, 2, L_FM, 0.12F); p[genId(2, GN_AMPENV)] = 3.0F; env(p, 2, 0.001F, 0.08F, 0.0F, 0.1F); break;
        case 11:
            waveGen(p, 0, 0); waveGen(p, 1, 0); mute(p, 1); ratio(p, 1, 3.5F); noFilters(p); link(p, 0, 1, L_FM, 0.5F);
            p[genId(1, GN_AMPENV)] = 3.0F; env(p, 0, 0.001F, 2.5F, 0.0F, 1.5F); env(p, 2, 0.001F, 1.5F, 0.0F, 1.0F); break;
        case 12: {   // six sine operators in a chain, generators 1 and 3 are heard
            for (int g = 0; g < 6; ++g) { waveGen(p, g, 0); if (g != 0 && g != 2) mute(p, g); }
            const float r[6] = {1.0F, 2.0F, 1.0F, 3.0F, 1.0F, 4.0F};
            for (int g = 0; g < 6; ++g) ratio(p, g, r[g]);
            link(p, 0, 1, L_PM, 0.25F); link(p, 1, 2, L_PM, 0.2F); link(p, 2, 3, L_PM, 0.25F); link(p, 3, 4, L_PM, 0.15F); link(p, 4, 5, L_PM, 0.15F);
            p[genId(2, GN_FINE)] = 0.53F; level(p, 2, -6.0F);
            noFilters(p); env(p, 0, 0.4F, 0.5F, 0.8F, 1.0F); break;
        }
        case 13: waveGen(p, 0, 0); waveGen(p, 1, 0); mute(p, 1); ratio(p, 1, 1.41F); noFilters(p); link(p, 0, 1, L_RING, 0.8F); env(p, 0, 0.002F, 0.6F, 0.3F, 0.4F); break;
        case 14:
            waveGen(p, 0, 2); waveGen(p, 1, 2); mute(p, 1); ratio(p, 0, 2.7F); link(p, 0, 1, L_SYNC, 1.0F);
            filt(p, 0, FT_LP, 5000.0F, 0.2F); env(p, 0, 0.005F, 0.3F, 0.8F, 0.2F); break;
        case 15:   // an organ from the odd partials, a second one an octave below
            method(p, 0, M_ADD, AS_SQUARE); p[genId(0, GN_F0)] = 0.2F; method(p, 1, M_ADD, AS_SQUARE); p[genId(1, GN_F0)] = 0.1F; p[genId(1, GN_OCT)] = -1.0F; level(p, 1, -6.0F);
            noFilters(p); env(p, 0, 0.01F, 0.05F, 1.0F, 0.08F); p[genId(1, GN_AMPENV)] = 1.0F; break;
        case 16:   // a saw through a formant filter that slowly moves between the vowels
            waveGen(p, 0, 2); unison(p, 0, 4, 0.3F); filt(p, 0, FT_FORMANT, 1500.0F, 0.5F); p[filterId(0, FL_VOWEL)] = 0.3F;
            lfo(p, 0, LW_SINE, 0.25F); mod(p, 0, MS_LFO1, kDestFilterBase + 3, 0.3F); env(p, 0, 0.4F, 0.3F, 1.0F, 0.8F); break;
        case 17:   // a square and a sine an octave down, through a ladder filter that an envelope opens
            waveGen(p, 0, 4); waveGen(p, 1, 0); p[genId(1, GN_OCT)] = -1.0F; filt(p, 0, FT_LADDER, 500.0F, 0.35F);
            p[filterId(0, FL_ENV)] = 2.0F; p[filterId(0, FL_ENVAMT)] = 0.8F; env(p, 0, 0.002F, 0.2F, 0.9F, 0.15F); env(p, 1, 0.002F, 0.25F, 0.2F, 0.2F); break;
        case 18:
            waveGen(p, 0, 2); unison(p, 0, 4, 0.4F); waveGen(p, 1, 2); p[genId(1, GN_FINE)] = 0.52F; level(p, 1, -3.0F);
            filt(p, 0, FT_SVF, 2500.0F, 0.25F); lfo(p, 0, LW_TRI, 0.3F); mod(p, 0, MS_LFO1, kDestFilterBase, 0.3F); env(p, 0, 0.5F, 0.4F, 0.8F, 0.9F); break;
        case 19:   // two waves morph; an envelope moves the morph
            waveGen(p, 0, 2); p[genId(0, GN_SEL2)] = 32.0F; filt(p, 0, FT_LP, 8000.0F, 0.15F);
            mod(p, 0, MS_ENV2, 0 * kDestPerGen + 8, 1.0F); env(p, 0, 0.01F, 0.2F, 0.8F, 0.25F); env(p, 1, 0.3F, 0.4F, 0.5F, 0.3F); break;
        case 20:   // a soft additive chord is the source, the granular generator cuts it into grains
            method(p, 0, M_ADD, AS_SAW); mute(p, 0); p[genId(0, GN_F0)] = 0.3F; method(p, 1, M_GRAIN, 0); p[genId(1, GN_SEL1)] = 0.0F; env(p, 0, 0.3F, 0.5F, 1.0F, 1.2F); p[genId(1, GN_AMPENV)] = 1.0F; break;
        case 21:   // a saw is the source, the spectral generator blurs it
            waveGen(p, 0, 2); mute(p, 0); method(p, 1, M_SPECTRAL, 0); p[genId(1, GN_SEL1)] = 0.0F; p[genId(1, GN_SEL2)] = static_cast<float>(SP_BLUR);
            p[genId(1, GN_F0 + 3)] = 0.6F; env(p, 0, 0.3F, 0.5F, 1.0F, 1.0F); break;
        case 22:   // pink noise through a narrow band that a slow LFO moves
            method(p, 0, M_NOISE, NC_PINK); p[genId(0, GN_F0 + 1)] = 0.5F; p[genId(0, GN_F0 + 2)] = 0.3F;
            lfo(p, 0, LW_SMOOTH, 0.4F); mod(p, 0, MS_LFO1, 0 * kDestPerGen + 9, 0.4F); noFilters(p); env(p, 0, 0.3F, 0.3F, 1.0F, 0.6F); break;
        case 23: method(p, 0, M_MODAL, MA_BELL); noFilters(p); env(p, 0, 0.001F, 0.4F, 1.0F, 2.5F); break;
        case 24: method(p, 0, M_MODAL, MA_WOOD); noFilters(p); env(p, 0, 0.001F, 0.3F, 1.0F, 0.6F); break;
        case 25: method(p, 0, M_MODAL, MA_GLASS); noFilters(p); env(p, 0, 0.001F, 0.4F, 1.0F, 2.0F); break;
        case 26: {   // Rast on C: the 3rd and the 7th a quarter tone lower
            waveGen(p, 0, 2); unison(p, 0, 3, 0.25F); filt(p, 0, FT_LP, 3500.0F, 0.2F); env(p, 0, 0.35F, 0.4F, 0.8F, 0.7F);
            const int d[] = {4, -50, 11, -50}; tuning(p, 0, d, 2); break;
        }
        case 27: {   // Bayati on D: the 2nd degree a quarter tone lower, played by a reed
            wind(p, WI_ZURNA, 0.04F, 0.15F);
            const int d[] = {2, -50}; tuning(p, 2, d, 1); break;
        }
        default: break;
    }
    for (int k = 0; k < kParamCount; ++k) p[k] = clampParam(k, p[k]);
}

// ------------------------------------------------------------------------------------------------- loudness
float referenceLoudnessDb(const float* patch) {
    constexpr double sr = 48000.0;
    std::vector<float> p(patch, patch + kParamCount);
    auto shared = std::make_unique<Shared>();
    shared->files = userWaveTables().load(std::memory_order_acquire);
    shared->update(p.data());
    auto v = std::make_unique<Voice>();
    Inputs in;
    in.key = 60; in.velocity = 0.8F; in.gate = true; in.cc = nullptr;
    v->noteOn(p.data(), sr, in, 12345U, shared.get());
    const double inc = 261.6255653 / sr;
    const int total = static_cast<int>(sr);
    double sum = 0.0;
    int count = 0;
    for (int i = 0; i < total; ++i) {
        if (i % 64 == 0) { in.gate = i < static_cast<int>(0.85 * sr); v->setInputs(in, sr); }
        float l = 0.0F, r = 0.0F;
        v->tick(inc, l, r);
        if (i >= static_cast<int>(0.05 * sr) && i < static_cast<int>(0.85 * sr)) { sum += static_cast<double>(l) * l + static_cast<double>(r) * r; count += 2; }
    }
    const double rms = count > 0 ? std::sqrt(sum / count) : 0.0;
    return static_cast<float>(20.0 * std::log10(rms + 1.0e-9));
}

} // namespace silveton::sampler::suse
