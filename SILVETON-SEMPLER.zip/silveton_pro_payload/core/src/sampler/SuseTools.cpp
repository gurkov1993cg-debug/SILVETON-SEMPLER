// SILVETON_SUSE_V1 - names and display of the numbers of SILVETON SYNTH, the maths of the wave editor and the shape of an envelope.
// (The preset text and the factory presets are in SusePresets.cpp.)
#include "silveton/sampler/SuseTools.h"

#include "SuseDsp.h"
#include "SuseWaves.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace silveton::sampler::suse {

namespace {

constexpr double kPi = 3.14159265358979323846;

// the own knobs (GN_F0 + i) of every method - the order is the one of setMethod() and of the generators
const char* const kKnobWave[kGenFloats] = {"СМЕС А→Б", "СИМЕТРИЯ", "ЯРКОСТ", "ПРЕГЪВАНЕ", "ИЗКРИВЯВАНЕ", "ОГЪВАНЕ", "МАКС ХАРМОНИЦИ", "СУБ ОКТАВА", "ОБРАТНА ВРЪЗКА", "СМЕЩЕНИЕ", nullptr, nullptr, nullptr, nullptr};
const char* const kKnobAdd[kGenFloats] = {"ХАРМОНИЦИ", "НАКЛОН", "НЕЧЕТНИ/ЧЕТНИ", "ВРЪХ ЧЕСТОТА", "ВРЪХ ШИРИНА", "ВРЪХ СИЛА", "ФАЗОВ РАЗБРОЙ", "РАЗТЕГЛЯНЕ", "ИЗМЕСТВАНЕ", nullptr, nullptr, nullptr, nullptr, nullptr};
const char* const kKnobString[kGenFloats] = {"ЗАТИХВАНЕ", "ЗАГЛУШАВАНЕ", "РАЗСЕЙВАНЕ", "МЯСТО НА ЩИПКА", "ВЪЗБУЖДАНЕ", "НАТИСК НА ЛЪК", "СКОРОСТ НА ЛЪК", "МЯСТО НА ЛЪК", "НЕЛИНЕЙНОСТ", "КОРПУС", "ДЪЛЖИНА УДАР", "НАСТРОЙКА", nullptr, nullptr};
const char* const kKnobWind[kGenFloats] = {"ДЪХ", "УСТНИ", "ЗАГЛУШАВАНЕ", "ЯРКОСТ", "ШУМ", "ХРИПКОСТ", "ПРЕДУВАНЕ", "АТАКА", "ВИБРАТО", "ДЪХ ОТ КОНТРОЛЕР", "ТОН ОТ УСТНИ", nullptr, nullptr, nullptr};
const char* const kKnobModal[kGenFloats] = {"ЗАТИХВАНЕ", "НАКЛОН ЗАГЛУШ.", "НЕХАРМОНИЧНОСТ", "МЯСТО НА УДАР", "ТВЪРДОСТ", "БРОЙ ТОНОВЕ", "ЯРКОСТ", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};
const char* const kKnobNoise[kGenFloats] = {"НАКЛОН", "ЛЕНТА ЧЕСТОТА", "ЛЕНТА ШИРИНА", "ПУКАНЕ", "СКОРОСТ", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};
const char* const kKnobGrain[kGenFloats] = {"РАЗМЕР ЗЪРНО", "ГЪСТОТА", "ПОЗИЦИЯ", "ПОЗИЦИЯ СЛУЧАЙНО", "ВИСОЧИНА", "ВИСОЧИНА СЛУЧАЙНО", "ОБРАТНО", "ЗАМРАЗЯВАНЕ", "РАЗПРЪСКВАНЕ", "ОРИГИНАЛ", nullptr, nullptr, nullptr, nullptr};
const char* const kKnobSpec[kGenFloats] = {"КОЛИЧЕСТВО", "ПРЕМЕСТВАНЕ", "ПРАГ", "РАЗМАЗВАНЕ", "ЗАМРАЗЯВАНЕ", "НАКЛОН", "РАЗТЕГЛЯНЕ", "ОРИГИНАЛ", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};

constexpr Disp kPct{Disp::Pct, 0.0F, 1.0F, "%", 0};
constexpr Disp kBi{Disp::PctBi, -1.0F, 1.0F, "%", 0};
constexpr Disp kSwitch{Disp::Switch, 0.0F, 1.0F, "", 0};
Disp lin(float lo, float hi, const char* unit, int dec) { return Disp{Disp::Lin, lo, hi, unit, dec}; }
Disp lg(float lo, float hi, const char* unit, int dec) { return Disp{Disp::Log, lo, hi, unit, dec}; }
Disp whole(float lo, float hi, const char* unit = "") { return Disp{Disp::Whole, lo, hi, unit, 0}; }

// the display of the own knob i of a method (the maths are the ones of the generators)
Disp knobDisp(int method, int i) {
    switch (method) {
        case M_WAVE:
            switch (i) {
                case 1: return lin(2.0F, 98.0F, "%", 0);              // the pulse width of the symmetry knob
                case 2: case 9: return kBi;
                case 6: return Disp{Disp::Log, 1.0F, 512.0F, " харм.", 0};
                default: return kPct;
            }
        case M_ADD:
            switch (i) {
                case 0: return whole(1.0F, 64.0F, " харм.");
                case 1: return lin(-12.0F, 12.0F, " dB/окт", 1);
                case 2: return kBi;
                case 3: return lg(100.0F, 8000.0F, " Hz", 0);
                case 4: return lin(0.1F, 1.6F, " окт", 1);
                case 5: return lin(0.0F, 24.0F, " dB", 0);
                case 8: return lin(-200.0F, 200.0F, " Hz", 0);
                default: return kPct;
            }
        case M_STRING:
            switch (i) {
                case 0: return lg(0.05F, 30.0F, " с", 2);
                case 10: return lin(1.0F, 40.0F, " мс", 0);
                case 11: return lin(-50.0F, 50.0F, " цента", 0);
                default: return kPct;
            }
        case M_WIND:
            switch (i) {
                case 7: return lg(0.01F, 0.5F, " с", 3);
                case 10: return kBi;
                default: return kPct;
            }
        case M_MODAL:
            switch (i) {
                case 0: return lg(0.05F, 20.0F, " с", 2);
                case 5: return whole(1.0F, 32.0F, " тона");
                default: return kPct;
            }
        case M_NOISE:
            switch (i) {
                case 0: return kBi;
                case 1: return lg(40.0F, 12000.0F, " Hz", 0);
                default: return kPct;
            }
        case M_GRAIN:
            switch (i) {
                case 0: return Disp{Disp::Log, 5.0F, 120.0F, " мс", 0};
                case 1: return lg(1.0F, 200.0F, " /с", 0);
                case 4: return lin(-24.0F, 24.0F, " полут.", 1);
                case 5: return lin(0.0F, 12.0F, " полут.", 1);
                case 7: return kSwitch;
                default: return kPct;
            }
        case M_SPECTRAL:
            switch (i) {
                case 1: return Disp{Disp::Log, 0.25F, 4.0F, "x", 2};
                case 4: return kSwitch;
                case 5: return lin(-12.0F, 12.0F, " dB", 1);
                case 6: return lin(0.5F, 1.5F, "x", 2);
                default: return kPct;
            }
        default: return kPct;
    }
}

// the section of a patch id
struct Where { int region; int index; int off; };   // region: 0 global, 1 gen, 2 link, 3 filter, 4 env, 5 lfo, 6 step, 7 mod, 8 ctl, 9 tune, 10 draw
Where where(int id) noexcept {
    if (id < kGenBase) return {0, 0, id};
    if (id < kLinkBase) return {1, (id - kGenBase) / kGenStride, (id - kGenBase) % kGenStride};
    if (id < kFilterBase) return {2, (id - kLinkBase) / 2, (id - kLinkBase) % 2};
    if (id < kEnvBase) return {3, (id - kFilterBase) / kFilterStride, (id - kFilterBase) % kFilterStride};
    if (id < kLfoBase) return {4, (id - kEnvBase) / kEnvStride, (id - kEnvBase) % kEnvStride};
    if (id < kStepBase) return {5, (id - kLfoBase) / kLfoStride, (id - kLfoBase) % kLfoStride};
    if (id < kModBase) return {6, 0, id - kStepBase};
    if (id < kCtlBase) return {7, (id - kModBase) / kModStride, (id - kModBase) % kModStride};
    if (id < kTuneBase) return {8, (id - kCtlBase) / kCtlStride, (id - kCtlBase) % kCtlStride};
    if (id < kDrawBase) return {9, 0, id - kTuneBase};
    return {10, (id - kDrawBase) / kDrawLen, (id - kDrawBase) % kDrawLen};
}

int methodOf(const float* p, int g) noexcept {
    return p == nullptr ? M_OFF : std::clamp(static_cast<int>(std::lround(p[genId(g, GN_METHOD)])), 0, kMethods - 1);
}

float clampf1(float v) { return std::clamp(v, 0.0F, 1.0F); }

}  // namespace

// ------------------------------------------------------------------------------------------------- names
const char* methodKnobName(int method, int i) noexcept {
    if (i < 0 || i >= kGenFloats) return nullptr;
    switch (method) {
        case M_WAVE: return kKnobWave[i];
        case M_ADD: return kKnobAdd[i];
        case M_STRING: return kKnobString[i];
        case M_WIND: return kKnobWind[i];
        case M_MODAL: return kKnobModal[i];
        case M_NOISE: return kKnobNoise[i];
        case M_GRAIN: return kKnobGrain[i];
        case M_SPECTRAL: return kKnobSpec[i];
        default: return nullptr;
    }
}

const char* selLabel(int method, int sel) noexcept {
    switch (method) {
        case M_WAVE: return sel == GN_SEL1 ? "ВЪЛНА А" : (sel == GN_SEL2 ? "ВЪЛНА Б" : (sel == GN_SEL3 ? "ВИД ИЗКРИВЯВАНЕ" : (sel == GN_SEL4 ? "ВИД ОГЪВАНЕ" : nullptr)));
        case M_ADD: return sel == GN_SEL1 ? "РЕД НА ХАРМОНИЦИТЕ" : nullptr;   // (the second choice of the additive generator is not used by the sound)
        case M_STRING: return sel == GN_SEL1 ? "ВЪЗБУДИТЕЛ" : (sel == GN_SEL2 ? "ВЪЗБУДЕН ОТ" : nullptr);
        case M_WIND: return sel == GN_SEL1 ? "ИНСТРУМЕНТ" : nullptr;
        case M_MODAL: return sel == GN_SEL1 ? "МАТЕРИАЛ" : (sel == GN_SEL2 ? "ВЪЗБУДЕН ОТ" : nullptr);
        case M_NOISE: return sel == GN_SEL1 ? "ЦВЯТ НА ШУМА" : nullptr;
        case M_GRAIN: return sel == GN_SEL1 ? "ИЗТОЧНИК" : (sel == GN_SEL2 ? "ФОРМА НА ЗЪРНОТО" : nullptr);
        case M_SPECTRAL: return sel == GN_SEL1 ? "ИЗТОЧНИК" : (sel == GN_SEL2 ? "ДЕЙСТВИЕ" : nullptr);
        default: return nullptr;
    }
}

std::string selChoiceName(int method, int sel, int c) {
    static const char* const shaper[kShapers] = {"ИЗКЛ.", "ТАНХ", "АРКТАНГЕНС", "ЧЕБИШЕВ 3", "СИНУС", "СТЕПЕН", "ГРУБО (БИТОВЕ)", "ИЗПРАВЯНЕ"};
    static const char* const pd[kPhaseDists] = {"ИЗКЛ.", "ЗЪБЧАТО", "ИМПУЛСНО", "РЕЗОНАНТНО", "УСУКВАНЕ", "ДВОЙНО"};
    static const char* const series[kAddSeries] = {"ЗЪБЧАТА", "КВАДРАТ", "ТРИЪГЪЛНИК", "РАВНИ", "ПРОСТИ", "1/КОРЕН"};
    static const char* const exciter[kExciters] = {"ЩИПВАНЕ", "ЧУК", "ЛЪК", "ШУМ", "ИМПУЛС"};
    static const char* const wind[kWinds] = {"КЛАРИНЕТ", "САКСОФОН", "ЗУРНА", "КАВАЛ", "МЕДНИ"};
    static const char* const material[kMaterials] = {"ПРЪТ", "ПЛОЧА", "КАМБАНА", "ТРЪБА", "ДЪРВО", "СТЪКЛО"};
    static const char* const colour[kNoiseColors] = {"БЯЛ", "РОЗОВ", "КАФЯВ", "СИН", "ПУКАНЕ", "СТЪПАЛА"};
    static const char* const window[4] = {"ХАН", "ТРИЪГЪЛНИК", "ГАУС", "ПЛОСЪК ВРЪХ"};
    static const char* const spec[kSpectralOps] = {"ЗАМРАЗЯВАНЕ", "РАЗМАЗВАНЕ", "ПРЕМЕСТВАНЕ", "РАЗТЕГЛЯНЕ", "ВРАТА", "НАКЛОН", "ГРЕБЕН", "ШЕПОТ"};
    const auto gen = [](int k) { return "ОСЦ " + std::to_string(k); };
    switch (method) {
        case M_WAVE:
            if (sel == GN_SEL3) return shaper[std::clamp(c, 0, kShapers - 1)];
            if (sel == GN_SEL4) return pd[std::clamp(c, 0, kPhaseDists - 1)];
            return waveName(c);
        case M_ADD: return series[std::clamp(c, 0, kAddSeries - 1)];
        case M_STRING: return sel == GN_SEL1 ? exciter[std::clamp(c, 0, kExciters - 1)] : (c <= 0 ? std::string("СОБСТВЕН") : gen(c));
        case M_WIND: return wind[std::clamp(c, 0, kWinds - 1)];
        case M_MODAL: return sel == GN_SEL1 ? material[std::clamp(c, 0, kMaterials - 1)] : (c <= 0 ? std::string("СОБСТВЕН") : gen(c));
        case M_NOISE: return colour[std::clamp(c, 0, kNoiseColors - 1)];
        case M_GRAIN: return sel == GN_SEL1 ? gen(c + 1) : window[std::clamp(c, 0, 3)];
        case M_SPECTRAL: return sel == GN_SEL1 ? gen(c + 1) : spec[std::clamp(c, 0, kSpectralOps - 1)];
        default: return std::to_string(c);
    }
}

const char* linkTypeName(int t) noexcept {
    static const char* const n[kLinkTypes] = {"ИЗКЛ.", "PM", "FM", "AM", "РИНГ", "СИНХР.", "ОГЪВ.", "ФИЛТ.FM"};
    return n[std::clamp(t, 0, kLinkTypes - 1)];
}
// what a link does (the maths are the ones of Voice::runGen: modOut of the source into the target)
const char* linkTypeHelp(int t) noexcept {
    static const char* const n[kLinkTypes] = {
        "Няма връзка.",
        "PM (фазова): звукът на източника движи фазата на целта.",
        "FM (честотна): звукът на източника движи честотата на целта.",
        "AM (сила): силата на целта следва звука на източника.",
        "РИНГ (ринг модулация): целта се умножава със звука на източника.",
        "СИНХРОН: целта почва отначало всеки път, когато източникът завърши период.",
        "ОГЪВАНЕ: източникът огъва формата на вълната на целта.",
        "ФИЛТЪР FM: източникът движи честотата на собствения филтър на целта."};
    return n[std::clamp(t, 0, kLinkTypes - 1)];
}
const char* routeName(int r) noexcept {
    static const char* const n[kRoutes] = {"БЕЗ ФИЛТЪР", "ФИЛТЪР А", "ФИЛТЪР Б", "А + Б"};
    return n[std::clamp(r, 0, kRoutes - 1)];
}
const char* ownFilterName(int t) noexcept {
    static const char* const n[kOwnFilters] = {"ИЗКЛ.", "LP", "HP", "BP", "NOTCH"};
    return n[std::clamp(t, 0, kOwnFilters - 1)];
}
const char* filterTypeName(int t) noexcept {
    static const char* const n[kFilterTypes] = {"ИЗКЛ.", "LP", "HP", "BP", "NOTCH", "СТЪЛБА", "ПЛАВЕН", "РЕЗОНАНСЕН", "ГЛАСНИ"};
    return n[std::clamp(t, 0, kFilterTypes - 1)];
}
// what a filter type does (the maths are the ones of ShFilter in SuseDsp.h)
const char* filterTypeHelp(int t) noexcept {
    static const char* const n[kFilterTypes] = {
        "ИЗКЛ. — филтърът не работи.",
        "LP (нисък) — пропуска ниските тонове и реже високите.",
        "HP (висок) — пропуска високите тонове и реже ниските.",
        "BP (лентов) — пропуска само ивица около CUTOFF.",
        "NOTCH (пречка) — реже ивица около CUTOFF, останалото минава.",
        "СТЪЛБА — нисък филтър с 4 стъпала и обратна връзка.",
        "ПЛАВЕН — преминава плавно от нисък през лентов към висок (ПРЕХОД).",
        "РЕЗОНАНСЕН — нисък филтър с много силен, остър резонанс.",
        "ГЛАСНИ — три върха като гласните А Е И О У; ГЛАСНА ги премества."};
    return n[std::clamp(t, 0, kFilterTypes - 1)];
}
const char* methodHelp(int m) noexcept {
    static const char* const n[kMethods] = {
        "Този осцилатор е изключен.",
        "Две вълни А и Б, които смесваш и огъваш.",
        "Събира до 64 чисти тона (хармоници) по избран ред.",
        "Модел на струна: щипване, чук или лък.",
        "Модел на духов инструмент: дъх и уста.",
        "Модел на ударено тяло: прът, плоча, камбана, тръба, дърво, стъкло.",
        "Шум в избран цвят.",
        "Нарязва звука на друг осцилатор на малки зърна и ги пренарежда.",
        "Променя звука на друг осцилатор в спектъра му: замрази, размаж, премести."};
    return n[std::clamp(m, 0, kMethods - 1)];
}
const char* lfoWaveName(int w) noexcept {
    static const char* const n[kLfoWaves] = {"СИНУС", "ТРИЪГЪЛНИК", "ЗЪБЧАТА", "ОБР. ЗЪБЧАТА", "КВАДРАТ", "S&H СЛУЧАЙНО", "ПЛАВНО СЛУЧАЙНО"};
    return n[std::clamp(w, 0, kLfoWaves - 1)];
}
const char* modSourceName(int s) noexcept {
    static const char* const n[kModSources] = {"НЯМА", "ОБВИВКА 1", "ОБВИВКА 2", "ОБВИВКА 3", "ОБВИВКА 4", "LFO 1", "LFO 2", "LFO 3", "LFO 4", "СТЪПКИ",
                                               "ВЕЛОСИТИ", "НОТА", "ДЪХ CC2", "ЕКСПРЕСИЯ CC11", "МОД КОЛЕЛО", "АФТЪРТЪЧ", "ПОЛИ АФТЪРТЪЧ", "ПИЧ БЕНД", "СЛУЧАЙНО"};
    return n[std::clamp(s, 0, kModSources - 1)];
}
const char* priorityName(int p) noexcept {
    static const char* const n[3] = {"ПОСЛЕДНА", "НАЙ-ВИСОКА", "НАЙ-НИСКА"};
    return n[std::clamp(p, 0, 2)];
}

bool destUsable(int k, const float* p) noexcept {
    k = std::clamp(k, 0, kDestCount - 1);
    if (k >= kDestFilterBase) return true;
    const int g = k / kDestPerGen, s = k % kDestPerGen;
    const int m = methodOf(p, g);
    if (m == M_OFF) return false;
    if (s < 8) return true;
    return methodKnobName(m, s - 8) != nullptr;
}

std::string destName(int k, const float* p) {
    k = std::clamp(k, 0, kDestCount - 1);
    if (k < kDestFilterBase) {
        const int g = k / kDestPerGen, s = k % kDestPerGen;
        static const char* const base[8] = {"СИЛА", "ПАНОРАМА", "ТОН", "ФИНО", "ФИЛТЪР ЧЕСТ.", "ФИЛТЪР РЕЗ.", "РАЗСТРОЙКА", "ФАЗА"};
        std::string nm = "ОСЦ " + std::to_string(g + 1) + ": ";
        if (s < 8) return nm + base[s];
        const char* kn = methodKnobName(methodOf(p, g), s - 8);
        return kn != nullptr ? nm + kn : nm + "РЕГУЛАТОР " + std::to_string(s - 7);
    }
    if (k < kDestLfoBase) {
        static const char* const n[4] = {"CUTOFF", "РЕЗОНАНС", "ДРАЙВ", "ГЛАСНА"};
        const int i = k - kDestFilterBase;
        return std::string(i / 4 == 0 ? "ФИЛТЪР А: " : "ФИЛТЪР Б: ") + n[i % 4];
    }
    if (k < kDestGlobalBase) return "LFO " + std::to_string(k - kDestLfoBase + 1) + ": СКОРОСТ";
    if (k < kDestAllPitch) {
        static const char* const n[4] = {"ОБЩА СИЛА", "ВИБРАТО: ДЪЛБОЧИНА", "ТРЕМОЛО: ДЪЛБОЧИНА", "ШИРИНА"};
        return n[k - kDestGlobalBase];
    }
    return "ТОН НА ВСИЧКО";
}

std::string patchSummary(const float* p) {
    std::string s;
    for (int g = 0; g < kGens; ++g) {
        const int m = methodOf(p, g);
        if (m == M_OFF) continue;
        std::string name = methodName(m);
        if (s.find(name) != std::string::npos) continue;
        if (!s.empty()) s += " · ";
        s += name;
    }
    return s.empty() ? "ТИШИНА" : s;
}

// ------------------------------------------------------------------------------------------------- display
const char* paramName(int id, const float* p) noexcept {
    if (id < 0 || id >= kParamCount) return nullptr;
    const Where w = where(id);
    switch (w.region) {
        case 0:
            switch (w.off) {
                case G_LEVEL: return "ОБЩА СИЛА"; case G_FILTER_LINK: return "ФИЛТРИ ПОРЕДНО"; case G_PRIORITY: return "ПРИОРИТЕТ НА НОТИТЕ"; case G_RETRIG: return "ОБВИВКИ ОТНАЧАЛО";
                case G_KEEP_RES: return "ПАЗИ РЕЗОНАНСА"; case G_VOICES: return "БРОЙ ГЛАСОВЕ"; case G_VIB_RATE: return "ВИБРАТО СКОРОСТ"; case G_VIB_DEPTH: return "ВИБРАТО ДЪЛБОЧИНА";
                case G_VIB_DELAY: return "ВИБРАТО ЗАКЪСН."; case G_VIB_WHEEL: return "ВИБРАТО ОТ КОЛЕЛО"; case G_TREM_RATE: return "ТРЕМОЛО СКОРОСТ"; case G_TREM_DEPTH: return "ТРЕМОЛО ДЪЛБОЧИНА";
                case G_WIDTH: return "ШИРИНА"; case G_VEL_CURVE: return "КРИВА НА ВЕЛОСИТИ"; case G_DRIVE: return "ДРАЙВ";
                case E_BEND_UP_ID: return "ПИЧ БЕНД НАГОРЕ"; case E_BEND_DOWN_ID: return "ПИЧ БЕНД НАДОЛУ";
                default: return nullptr;
            }
        case 1: {
            const int m = methodOf(p, w.index);
            switch (w.off) {
                case GN_METHOD: return "МЕТОД"; case GN_ROUTE: return "КЪМ"; case GN_FTYPE: return "СОБСТВЕН ФИЛТЪР";
                case GN_SEL1: case GN_SEL2: case GN_SEL3: case GN_SEL4: return selLabel(m, w.off);
                case GN_OCT: return "ОКТАВА"; case GN_SEMI: return "ПОЛУТОН"; case GN_UNISON: return "ЮНИСОН"; case GN_SYNC: return "СИНХРОН";
                case GN_FIXED: return "ФИКСИРАНА ЧЕСТОТА"; case GN_AMPENV: return "ОБВИВКА НА СИЛАТА"; case GN_FENV: return "ОБВИВКА НА ФИЛТЪРА"; case GN_PENV: return "ОБВИВКА НА ТОНА";
                case GN_LEVEL: return "СИЛА"; case GN_PAN: return "ПАНОРАМА"; case GN_FINE: return "ФИНО"; case GN_RATIO: return "СЪОТНОШЕНИЕ"; case GN_FIXHZ: return "ЧЕСТОТА";
                case GN_PHASE: return "ФАЗА"; case GN_FCUT: return "CUTOFF"; case GN_FRES: return "РЕЗОНАНС"; case GN_VELLEV: return "ВЕЛОСИТИ→СИЛА";
                case GN_UNIDET: return "РАЗСТРОЙКА"; case GN_UNISPR: return "РАЗПРЪСКВАНЕ"; case GN_SYNCR: return "СИНХР. СЪОТНОШЕНИЕ"; case GN_FENVAMT: return "ОБВИВКА→CUTOFF";
                case GN_PENVAMT: return "ОБВИВКА→ТОН"; case GN_FKEY: return "СЛЕДВА НОТАТА"; case GN_MUTE: return "ЗАГЛУШЕН";
                default: return w.off >= GN_F0 && w.off < GN_F0 + kGenFloats ? methodKnobName(m, w.off - GN_F0) : nullptr;
            }
        }
        case 2: return w.off == 0 ? "ВРЪЗКА" : "КОЛКО";
        case 3: {
            static const char* const n[] = {"ТИП", "CUTOFF", "РЕЗОНАНС", "ДРАЙВ", "СЛЕДВА НОТАТА", "ВЕЛОСИТИ→CUTOFF", "ОБВИВКА", "ОБВИВКА→CUTOFF", "ГЛАСНА", "ПРЕХОД"};
            return w.off < 10 ? n[w.off] : nullptr;
        }
        case 4:
            switch (w.off) {
                case EV_START: return "НАЧАЛНО НИВО"; case EV_SUS: return "ДЪРЖАНЕ ПРИ ТОЧКА"; case EV_REL: return "ПУСКАНЕ"; case EV_CURVE: return "КРИВА";
                case EV_LOOP: return "ПОВТАРЯНЕ"; case EV_KEYT: return "НОТА→ВРЕМЕ";
                default: return (w.off & 1) != 0 ? "ВРЕМЕ" : "НИВО";
            }
        case 5: {
            static const char* const n[] = {"ФОРМА", "СКОРОСТ", "ЗАБАВЯНЕ", "НАРАСТВАНЕ", "ФАЗА", "ЕДНОПОЛЮСЕН", "СЛУЧАЙНО НАЧАЛО", "НОТА→СКОРОСТ"};
            return w.off < 8 ? n[w.off] : nullptr;
        }
        case 6: return w.off == ST_LEN ? "ДЪЛЖИНА" : (w.off == ST_RATE ? "СКОРОСТ" : (w.off == ST_GLIDE ? "ПЛЪЗГАНЕ" : (w.off == ST_DIR ? "ПОСОКА" : "СТЪПКА")));
        case 7: return w.off == 0 ? "ИЗТОЧНИК" : (w.off == 1 ? "ЦЕЛ" : "КОЛКО");
        case 8: {
            static const char* const n[] = {"КОНТРОЛЕР", "КРИВА", "ЦЕЛ 1", "КОЛКО 1", "ЦЕЛ 2", "КОЛКО 2", "ЦЕЛ 3", "КОЛКО 3"};
            return n[w.off];
        }
        case 9: return w.off == TN_ON ? "ТУНИНГ" : (w.off == TN_ROOT ? "ОСНОВЕН ТОН" : (w.off == TN_MASTER ? "ОБЩА НАСТРОЙКА" : "ЦЕНТОВЕ НА НОТАТА"));
        default: return "ТОЧКА НА ВЪЛНА";
    }
}

Disp paramDisp(int id, const float* p) noexcept {
    if (id < 0 || id >= kParamCount) return kPct;
    const Where w = where(id);
    switch (w.region) {
        case 0:
            switch (w.off) {
                case G_LEVEL: return lin(rng::kLevelDbLo, rng::kLevelDbHi, " dB", 1);
                case G_FILTER_LINK: case G_RETRIG: case G_KEEP_RES: case G_VIB_WHEEL: return kSwitch;
                case G_PRIORITY: return whole(0.0F, 2.0F);
                case G_VOICES: return whole(1.0F, 24.0F);
                case G_VIB_RATE: return lg(rng::kVibRateLo, rng::kVibRateHi, " Hz", 1);
                case G_VIB_DEPTH: return lin(0.0F, rng::kVibDepthCents, " цента", 0);
                case G_VIB_DELAY: return lin(0.0F, 2.0F, " с", 2);
                case G_TREM_RATE: return lg(0.1F, 14.0F, " Hz", 1);
                case G_VEL_CURVE: return Disp{Disp::PctBi, -1.0F, 1.0F, "", 0};
                default: return kPct;
            }
        case 1: {
            const int m = methodOf(p, w.index);
            switch (w.off) {
                case GN_LEVEL: return Disp{Disp::Db, rng::kGenDbLo, rng::kGenDbHi, " dB", 1};
                case GN_PAN: return kBi;
                case GN_FINE: return lin(-100.0F, 100.0F, " цента", 0);
                case GN_RATIO: return lg(rng::kRatioLo, rng::kRatioHi, "x", 3);
                case GN_FIXHZ: return lg(rng::kFixHzLo, rng::kFixHzHi, " Hz", 1);
                case GN_PHASE: return lin(0.0F, 360.0F, "°", 0);
                case GN_FCUT: return lg(rng::kCutLo, rng::kCutHi, " Hz", 0);
                case GN_UNIDET: return lin(0.0F, rng::kUniDetCents, " цента", 0);
                case GN_SYNCR: return lin(1.0F, 8.0F, "x", 2);
                case GN_FENVAMT: return lin(-rng::kFenvOct, rng::kFenvOct, " oct", 1);
                case GN_PENVAMT: return lin(-rng::kPenvSemis, rng::kPenvSemis, " st", 1);
                case GN_OCT: return whole(-3.0F, 3.0F);
                case GN_SEMI: return whole(-24.0F, 24.0F, " st");
                case GN_UNISON: return whole(1.0F, 4.0F);
                case GN_SYNC: case GN_FIXED: case GN_MUTE: return kSwitch;
                default:
                    if (w.off >= GN_F0 && w.off < GN_F0 + kGenFloats) return knobDisp(m, w.off - GN_F0);
                    return kPct;
            }
        }
        case 2: return w.off == 0 ? whole(0.0F, static_cast<float>(kLinkTypes - 1)) : kPct;
        case 3:
            switch (w.off) {
                case FL_CUT: return lg(rng::kCutLo, rng::kCutHi, " Hz", 0);
                case FL_VEL: return lin(0.0F, 4.0F, " oct", 1);
                case FL_ENVAMT: return lin(-rng::kFenvOct, rng::kFenvOct, " oct", 1);
                case FL_KEY: return kPct;
                default: return kPct;
            }
        case 4:
            if (w.off == EV_REL || (w.off >= 1 && w.off <= 10 && (w.off & 1) != 0)) return Disp{Disp::Time, 0.0F, 1.0F, " s", 2};
            if (w.off == EV_CURVE || w.off == EV_KEYT) return kBi;
            if (w.off == EV_LOOP) return kSwitch;
            return kPct;
        case 5:
            switch (w.off) {
                case LF_RATE: return lg(rng::kLfoLo, rng::kLfoHi, " Hz", 2);
                case LF_DELAY: case LF_FADE: return lin(0.0F, rng::kLfoTimeHi, " с", 2);
                case LF_PHASE: return lin(0.0F, 360.0F, "°", 0);
                case LF_UNI: case LF_FREE: return kSwitch;
                default: return kPct;
            }
        case 6:
            if (w.off == ST_RATE) return lg(rng::kStepLo, rng::kStepHi, " Hz", 2);
            if (w.off >= ST_STEPS) return kBi;
            return w.off == ST_LEN || w.off == ST_DIR ? whole(0.0F, 15.0F) : kPct;
        case 7: return w.off == 2 ? kBi : whole(0.0F, 1.0F);
        case 8: return (w.off == CT_A1 || w.off == CT_A2 || w.off == CT_A3) ? kBi : whole(0.0F, 1.0F);
        case 9:
            if (w.off == TN_MASTER) return lin(-100.0F, 100.0F, " цента", 0);
            if (w.off >= TN_CENTS) return lin(-100.0F, 100.0F, " цента", 0);
            return w.off == TN_ON ? kSwitch : whole(0.0F, 11.0F);
        default: return kBi;
    }
}

float dispFromNorm(const Disp& d, float t) noexcept {
    switch (d.kind) {
        case Disp::Pct: return t * 100.0F;
        case Disp::PctBi: return (t - 0.5F) * 200.0F;
        case Disp::Lin: case Disp::Db: return d.lo + t * (d.hi - d.lo);
        case Disp::Log: return d.lo * std::pow(d.hi / d.lo, t);
        case Disp::Time: return envTimeOf(t);
        default: return t;
    }
}
float dispToNorm(const Disp& d, float v) noexcept {
    float t = 0.0F;
    switch (d.kind) {
        case Disp::Pct: t = v / 100.0F; break;
        case Disp::PctBi: t = v / 200.0F + 0.5F; break;
        case Disp::Lin: case Disp::Db: t = (v - d.lo) / (d.hi - d.lo); break;
        case Disp::Log: t = std::log(std::max(v, d.lo) / d.lo) / std::log(d.hi / d.lo); break;
        case Disp::Time: t = v <= 0.0F ? 0.0F : std::log10(std::max(v, rng::kTimeLo) / rng::kTimeLo) / 4.0F; break;
        default: t = v; break;
    }
    return clampf1(t);
}

std::string dispText(const Disp& d, float t) {
    char b[48];
    switch (d.kind) {
        case Disp::Switch: return t >= 0.5F ? "ВКЛ." : "ИЗКЛ.";
        case Disp::Whole: std::snprintf(b, sizeof b, "%d%s", static_cast<int>(std::lround(t)), d.unit); return b;
        case Disp::Pct: std::snprintf(b, sizeof b, "%d%%", static_cast<int>(std::lround(t * 100.0F))); return b;
        case Disp::PctBi: {
            const int v = static_cast<int>(std::lround((t - 0.5F) * 200.0F));
            std::snprintf(b, sizeof b, "%+d%s", v, d.unit); return v == 0 ? std::string("0") : std::string(b);
        }
        case Disp::Db: if (t <= 0.002F) return "ТИХО"; std::snprintf(b, sizeof b, "%+.1f dB", static_cast<double>(dispFromNorm(d, t))); return b;
        case Disp::Time: {
            const float s = envTimeOf(t);
            if (s <= 0.0F) return "0 мс";
            if (s < 1.0F) std::snprintf(b, sizeof b, "%.0f мс", static_cast<double>(s * 1000.0F)); else std::snprintf(b, sizeof b, "%.2f с", static_cast<double>(s));
            return b;
        }
        default: {
            const float v = dispFromNorm(d, t);
            const bool big = d.kind == Disp::Log && std::strcmp(d.unit, " Hz") == 0 && v >= 1000.0F;
            if (big) { std::snprintf(b, sizeof b, "%.2f kHz", static_cast<double>(v / 1000.0F)); return b; }
            if (std::strcmp(d.unit, " с") == 0 && v < 1.0F && v >= 0.001F && d.decimals >= 2) { std::snprintf(b, sizeof b, "%.0f мс", static_cast<double>(v * 1000.0F)); return b; }
            const bool sign = d.kind == Disp::Lin && d.lo < 0.0F;
            double shown = static_cast<double>(v);
            if (std::fabs(shown) < 0.5 * std::pow(10.0, -d.decimals)) shown = 0.0;   // never "-0.0"
            std::snprintf(b, sizeof b, sign ? "%+.*f%s" : "%.*f%s", d.decimals, shown, d.unit);
            return b;
        }
    }
}

// ------------------------------------------------------------------------------------------------- the wave editor
const char* waveOpName(int op) noexcept {
    static const char* const n[kWaveOps] = {"ОГЛЕДАЛО", "ПРЕОБРЪЩАНЕ", "СИМЕТРИЯ ЧЕТНА", "СИМЕТРИЯ НЕЧЕТНА", "САМО НЕЧЕТНИ", "САМО ЧЕТНИ", "ЗАГЛАЖДАНЕ", "НОРМАЛИЗИРАНЕ"};
    return n[std::clamp(op, 0, kWaveOps - 1)];
}
const char* combineName(int c) noexcept {
    static const char* const n[kCombines] = {"СМЕСВАНЕ", "ПО СПЕКТЪР", "УМНОЖЕНИЕ", "СУМА"};
    return n[std::clamp(c, 0, kCombines - 1)];
}

void waveNormalize(float* x) noexcept {
    double mean = 0.0;
    for (int i = 0; i < kDrawLen; ++i) mean += static_cast<double>(x[i]);
    mean /= kDrawLen;
    float pk = 0.0F;
    for (int i = 0; i < kDrawLen; ++i) { x[i] -= static_cast<float>(mean); pk = std::max(pk, std::fabs(x[i])); }
    if (pk > 1.0e-6F) for (int i = 0; i < kDrawLen; ++i) x[i] /= pk;
}

void waveHarmonics(const float* x, float* amp, float* phase) noexcept {
    for (int k = 1; k <= kEditHarmonics; ++k) {
        double re = 0.0, im = 0.0;
        for (int n = 0; n < kDrawLen; ++n) {
            const double a = 2.0 * kPi * k * n / kDrawLen;
            re += static_cast<double>(x[n]) * std::cos(a);
            im -= static_cast<double>(x[n]) * std::sin(a);
        }
        re *= 2.0 / kDrawLen; im *= 2.0 / kDrawLen;
        amp[k - 1] = static_cast<float>(std::sqrt(re * re + im * im));
        phase[k - 1] = amp[k - 1] > 1.0e-6F ? static_cast<float>(std::atan2(im, re)) : 0.0F;
    }
}

void waveFromHarmonics(const float* amp, const float* phase, float* x) noexcept {
    float pk = 0.0F;
    for (int n = 0; n < kDrawLen; ++n) {
        double v = 0.0;
        for (int k = 1; k <= kEditHarmonics; ++k) v += static_cast<double>(amp[k - 1]) * std::cos(2.0 * kPi * k * n / kDrawLen + static_cast<double>(phase[k - 1]));
        x[n] = static_cast<float>(v);
        pk = std::max(pk, std::fabs(x[n]));
    }
    if (pk > 1.0F) for (int n = 0; n < kDrawLen; ++n) x[n] /= pk;
}

void waveApplyOp(int op, float* x) noexcept {
    float t[kDrawLen];
    std::memcpy(t, x, sizeof t);
    constexpr int N = kDrawLen;
    switch (op) {
        case WO_MIRROR: for (int i = 0; i < N; ++i) x[i] = t[(N - i) % N]; break;
        case WO_INVERT: for (int i = 0; i < N; ++i) x[i] = -t[i]; break;
        case WO_SYM_EVEN: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] + t[(N - i) % N]); break;
        case WO_SYM_ODD: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] - t[(N - i) % N]); break;
        case WO_ODD_HARM: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] - t[(i + N / 2) % N]); break;
        case WO_EVEN_HARM: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] + t[(i + N / 2) % N]); break;
        case WO_SMOOTH: for (int i = 0; i < N; ++i) x[i] = 0.25F * t[(i + N - 1) % N] + 0.5F * t[i] + 0.25F * t[(i + 1) % N]; break;
        default: break;
    }
    if (op == WO_NORMALIZE || op == WO_ODD_HARM || op == WO_EVEN_HARM || op == WO_SYM_EVEN || op == WO_SYM_ODD) {
        float pk = 0.0F;
        for (int i = 0; i < N; ++i) pk = std::max(pk, std::fabs(x[i]));
        if (op == WO_NORMALIZE) waveNormalize(x);
        else if (pk > 1.0e-6F) for (int i = 0; i < N; ++i) x[i] /= pk;   // the result keeps a full-size wave
    }
}

void waveCombine(int mode, const float* a, const float* b, float t, float* out) noexcept {
    t = clampf1(t);
    float r[kDrawLen];
    switch (mode) {
        case CM_SPECTRUM: {
            float aa[kEditHarmonics], pa[kEditHarmonics], ab[kEditHarmonics], pb[kEditHarmonics], am[kEditHarmonics], pm[kEditHarmonics];
            waveHarmonics(a, aa, pa); waveHarmonics(b, ab, pb);
            for (int k = 0; k < kEditHarmonics; ++k) {
                am[k] = aa[k] + (ab[k] - aa[k]) * t;
                float d = pb[k] - pa[k];
                while (d > static_cast<float>(kPi)) d -= static_cast<float>(2.0 * kPi);
                while (d < -static_cast<float>(kPi)) d += static_cast<float>(2.0 * kPi);
                pm[k] = pa[k] + d * t;
            }
            waveFromHarmonics(am, pm, r);
            break;
        }
        case CM_MULTIPLY: for (int i = 0; i < kDrawLen; ++i) r[i] = a[i] * (1.0F + t * (b[i] - 1.0F)); break;   // t = 0: a unchanged, t = 1: a x b
        case CM_ADD: for (int i = 0; i < kDrawLen; ++i) r[i] = a[i] + b[i] * t; break;   // t = 0: a, t = 1: a + b
        default: for (int i = 0; i < kDrawLen; ++i) r[i] = a[i] + (b[i] - a[i]) * t; break;   // CM_MORPH
    }
    if (mode == CM_MULTIPLY || mode == CM_ADD) {
        float pk = 0.0F;
        for (int i = 0; i < kDrawLen; ++i) pk = std::max(pk, std::fabs(r[i]));
        if (pk > 1.0e-6F) for (int i = 0; i < kDrawLen; ++i) r[i] /= pk;
    }
    for (int i = 0; i < kDrawLen; ++i) out[i] = std::clamp(r[i], -1.0F, 1.0F);
}

void waveChoicePoints(int choice, const float* patch, float* pts) noexcept {
    if (choice >= 0 && choice < kMathWaves) { waveCycle(choice, pts, kDrawLen); return; }
    if (choice >= kWaveDrawn0 && choice < kWaveFile0 && patch != nullptr) {
        for (int i = 0; i < kDrawLen; ++i) pts[i] = (clampf1(patch[drawId(choice - kWaveDrawn0, i)]) - 0.5F) * 2.0F;
        return;
    }
    for (int i = 0; i < kDrawLen; ++i) pts[i] = 0.0F;
}

// ------------------------------------------------------------------------------------------------- the shape of an envelope
namespace {
EnvCfg cookEnv(const float* patch, int e) {
    EnvCfg c;
    const float* row = patch + envId(e, 0);
    c.start = clampf1(row[EV_START]);
    for (int i = 0; i < kEnvPoints; ++i) { c.t[i] = envTimeOf(clampf1(row[envT(i)])); c.l[i] = clampf1(row[envL(i)]); }
    c.sus = std::clamp(static_cast<int>(std::lround(row[EV_SUS])), 0, kEnvPoints - 1);
    c.rel = envTimeOf(clampf1(row[EV_REL]));
    c.curve = (clampf1(row[EV_CURVE]) - 0.5F) * 2.0F;
    c.loop = false;   // the drawing shows one run
    return c;
}
}  // namespace

float envelopePointTime(const float* patch, int e, int pt) noexcept {
    const EnvCfg c = cookEnv(patch, std::clamp(e, 0, kEnvs - 1));
    float t = 0.0F;
    for (int i = 0; i <= std::clamp(pt, 0, kEnvPoints - 1); ++i) t += c.t[i];
    return t;
}

int envelopeSchematic(const float* patch, int e, int n, float* out, EnvPart* parts) noexcept {
    e = std::clamp(e, 0, kEnvs - 1);
    const EnvCfg c = cookEnv(patch, e);
    struct Seg { int kind; int point; float from; float to; float w; };
    Seg seg[kEnvPartsMax];
    int k = 0;
    // a part is 0.4 .. 1.0 wide by its time (1 ms .. 10 s); a time of 0 is a jump (a thin part); the held level has its own width
    const auto width = [](float t) { return t <= 0.0F ? 0.12F : 0.4F + 0.6F * clampf1(std::log10(t / rng::kTimeLo) / 4.0F); };
    float level = c.start;
    for (int i = 0; i <= c.sus && k < kEnvPartsMax - 3; ++i) { seg[k++] = {i == 0 ? 0 : 1, i, level, c.l[i], width(c.t[i])}; level = c.l[i]; }
    seg[k++] = {2, c.sus, level, level, 0.9F};
    for (int i = c.sus + 1; i < kEnvPoints && k < kEnvPartsMax - 1; ++i) {
        if (c.t[i] <= 0.0F) continue;   // a point after the sustain point counts only when it has a time
        seg[k++] = {3, i, level, c.l[i], width(c.t[i])};
        level = c.l[i];
    }
    seg[k++] = {4, kEnvPoints, level, 0.0F, width(c.rel)};
    float sum = 0.0F;
    for (int i = 0; i < k; ++i) sum += seg[i].w;
    float x = 0.0F;
    for (int i = 0; i < k; ++i) {
        const float x1 = i == k - 1 ? 1.0F : x + seg[i].w / sum;
        parts[i] = EnvPart{x, x1, seg[i].kind, seg[i].point};
        x = x1;
    }
    for (int j = 0; j < n; ++j) {
        const float xx = n > 1 ? static_cast<float>(j) / static_cast<float>(n - 1) : 0.0F;
        int s = 0;
        while (s < k - 1 && xx > parts[s].x1) ++s;
        const float u = parts[s].x1 > parts[s].x0 ? std::clamp((xx - parts[s].x0) / (parts[s].x1 - parts[s].x0), 0.0F, 1.0F) : 1.0F;
        out[j] = seg[s].kind == 2 ? seg[s].from : seg[s].from + (seg[s].to - seg[s].from) * EnvState::ease(u, c.curve);
    }
    return k;
}

void envelopePreview(const float* patch, int e, int n, float* out, float* totalSec, float* releaseAtSec) {
    e = std::clamp(e, 0, kEnvs - 1);
    const EnvCfg c = cookEnv(patch, e);
    constexpr double sr = 2000.0;
    float attack = 0.0F;
    for (int i = 0; i <= c.sus; ++i) attack += c.t[i];
    const float hold = 0.15F + 0.2F * attack;
    float relTime = c.rel;
    for (int i = std::min(c.sus + 1, kEnvPoints); i < kEnvPoints; ++i) relTime += c.t[i];
    const float total = std::max(0.05F, attack + hold + relTime);
    if (totalSec != nullptr) *totalSec = total;
    if (releaseAtSec != nullptr) *releaseAtSec = attack + hold;
    EnvState s;
    s.begin(c, sr, 1.0F);
    const int steps = static_cast<int>(total * static_cast<float>(sr)) + 1;
    const int relAt = static_cast<int>((attack + hold) * static_cast<float>(sr));
    std::vector<float> run(static_cast<std::size_t>(steps), 0.0F);
    for (int i = 0; i < steps; ++i) {
        if (i == relAt) s.release(c, sr, 1.0F);
        run[static_cast<std::size_t>(i)] = s.tick(c, sr, 1.0F);
    }
    for (int i = 0; i < n; ++i) {
        const std::size_t k = std::min<std::size_t>(run.size() - 1, static_cast<std::size_t>(static_cast<double>(i) * static_cast<double>(run.size() - 1) / std::max(1, n - 1)));
        out[i] = run[k];
    }
}

} // namespace silveton::sampler::suse
