// SILVETON_SUSE_V1 - names and display of the numbers of SILVETON SYNTH, the maths of the wave editor and the shape of an envelope.
// (The preset text and the factory presets are in SusePresets.cpp.)
#include "silveton/sampler/SuseTools.h"

#include "SuseDsp.h"
#include "SuseWaves.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace silveton::sampler::suse {

namespace {

constexpr double kPi = 3.14159265358979323846;

// the own knobs (GN_F0 + i) of every method - the order is the one of setMethod() and of the generators
const char* const kKnobWave[kGenFloats] = {"MORPH", "SYMMETRY", "TILT", "FOLD", "SHAPE", "PHASE DIST", "HARM LIMIT", "SUB", "SELF FB", "BIAS", nullptr, nullptr, nullptr, nullptr};
const char* const kKnobAdd[kGenFloats] = {"PARTIALS", "TILT", "ODD / EVEN", "FORMANT Hz", "FORMANT W", "FORMANT GAIN", "PHASE SPREAD", "STRETCH", "SHIFT", nullptr, nullptr, nullptr, nullptr, nullptr};
const char* const kKnobString[kGenFloats] = {"DECAY", "DAMPING", "DISPERSION", "PICK POS", "EXCITE", "BOW PRESS", "BOW SPEED", "BOW POS", "NONLIN", "BODY", "EXC LEN", "TUNE", nullptr, nullptr};
const char* const kKnobWind[kGenFloats] = {"BREATH", "EMBOUCHURE", "DAMPING", "BRIGHT", "NOISE", "GROWL", "OVERBLOW", "ATTACK", "VIBRATO", "BREATH CTL", "LIP TUNE", nullptr, nullptr, nullptr};
const char* const kKnobModal[kGenFloats] = {"DECAY", "DAMP TILT", "INHARM", "STRIKE POS", "HARDNESS", "MODES", "BRIGHT", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};
const char* const kKnobNoise[kGenFloats] = {"TILT", "BAND Hz", "BANDWIDTH", "CRACKLE", "RATE", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};
const char* const kKnobGrain[kGenFloats] = {"SIZE", "DENSITY", "POSITION", "POS RANDOM", "PITCH", "PITCH RANDOM", "REVERSE", "FREEZE", "SPREAD", "DRY", nullptr, nullptr, nullptr, nullptr};
const char* const kKnobSpec[kGenFloats] = {"AMOUNT", "SHIFT", "THRESHOLD", "BLUR", "FREEZE", "TILT", "STRETCH", "DRY", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};

constexpr Disp kPct{Disp::Pct, 0.0F, 1.0F, "%", 0};
constexpr Disp kBi{Disp::PctBi, -1.0F, 1.0F, "%", 0};
constexpr Disp kSwitch{Disp::Switch, 0.0F, 1.0F, "", 0};
Disp lin(float lo, float hi, const char* unit, int dec) { return Disp{Disp::Lin, lo, hi, unit, dec}; }
Disp lg(float lo, float hi, const char* unit, int dec) { return Disp{Disp::Log, lo, hi, unit, dec}; }
Disp whole(float lo, float hi, const char* unit = "") { return Disp{Disp::Whole, lo, hi, unit, 0}; }

// the display of the own knob i of a method (the maths are the ones of the generators)
Disp knobDisp(int method, int i) {
    switch (method) {
        case M_WAVE:
            switch (i) {
                case 1: return lin(2.0F, 98.0F, "%", 0);              // the pulse width of the symmetry knob
                case 2: case 9: return kBi;
                case 6: return Disp{Disp::Log, 1.0F, 512.0F, " harm", 0};
                default: return kPct;
            }
        case M_ADD:
            switch (i) {
                case 0: return whole(1.0F, 64.0F, " partials");
                case 1: return lin(-12.0F, 12.0F, " dB/oct", 1);
                case 2: return kBi;
                case 3: return lg(100.0F, 8000.0F, " Hz", 0);
                case 4: return lin(0.1F, 1.6F, " oct", 1);
                case 5: return lin(0.0F, 24.0F, " dB", 0);
                case 8: return lin(-200.0F, 200.0F, " Hz", 0);
                default: return kPct;
            }
        case M_STRING:
            switch (i) {
                case 0: return lg(0.05F, 30.0F, " s", 2);
                case 10: return lin(1.0F, 40.0F, " ms", 0);
                case 11: return lin(-50.0F, 50.0F, " c", 0);
                default: return kPct;
            }
        case M_WIND:
            switch (i) {
                case 7: return lg(0.01F, 0.5F, " s", 3);
                case 10: return kBi;
                default: return kPct;
            }
        case M_MODAL:
            switch (i) {
                case 0: return lg(0.05F, 20.0F, " s", 2);
                case 5: return whole(1.0F, 32.0F, " modes");
                default: return kPct;
            }
        case M_NOISE:
            switch (i) {
                case 0: return kBi;
                case 1: return lg(40.0F, 12000.0F, " Hz", 0);
                default: return kPct;
            }
        case M_GRAIN:
            switch (i) {
                case 0: return Disp{Disp::Log, 5.0F, 120.0F, " ms", 0};
                case 1: return lg(1.0F, 200.0F, " /s", 0);
                case 4: return lin(-24.0F, 24.0F, " st", 1);
                case 5: return lin(0.0F, 12.0F, " st", 1);
                case 7: return kSwitch;
                default: return kPct;
            }
        case M_SPECTRAL:
            switch (i) {
                case 1: return Disp{Disp::Log, 0.25F, 4.0F, "x", 2};
                case 4: return kSwitch;
                case 5: return lin(-12.0F, 12.0F, " dB", 1);
                case 6: return lin(0.5F, 1.5F, "x", 2);
                default: return kPct;
            }
        default: return kPct;
    }
}

// the section of a patch id
struct Where { int region; int index; int off; };   // region: 0 global, 1 gen, 2 link, 3 filter, 4 env, 5 lfo, 6 step, 7 mod, 8 ctl, 9 tune, 10 draw
Where where(int id) noexcept {
    if (id < kGenBase) return {0, 0, id};
    if (id < kLinkBase) return {1, (id - kGenBase) / kGenStride, (id - kGenBase) % kGenStride};
    if (id < kFilterBase) return {2, (id - kLinkBase) / 2, (id - kLinkBase) % 2};
    if (id < kEnvBase) return {3, (id - kFilterBase) / kFilterStride, (id - kFilterBase) % kFilterStride};
    if (id < kLfoBase) return {4, (id - kEnvBase) / kEnvStride, (id - kEnvBase) % kEnvStride};
    if (id < kStepBase) return {5, (id - kLfoBase) / kLfoStride, (id - kLfoBase) % kLfoStride};
    if (id < kModBase) return {6, 0, id - kStepBase};
    if (id < kCtlBase) return {7, (id - kModBase) / kModStride, (id - kModBase) % kModStride};
    if (id < kTuneBase) return {8, (id - kCtlBase) / kCtlStride, (id - kCtlBase) % kCtlStride};
    if (id < kDrawBase) return {9, 0, id - kTuneBase};
    return {10, (id - kDrawBase) / kDrawLen, (id - kDrawBase) % kDrawLen};
}

int methodOf(const float* p, int g) noexcept {
    return p == nullptr ? M_OFF : std::clamp(static_cast<int>(std::lround(p[genId(g, GN_METHOD)])), 0, kMethods - 1);
}

float clampf1(float v) { return std::clamp(v, 0.0F, 1.0F); }

}  // namespace

// ------------------------------------------------------------------------------------------------- names
const char* methodKnobName(int method, int i) noexcept {
    if (i < 0 || i >= kGenFloats) return nullptr;
    switch (method) {
        case M_WAVE: return kKnobWave[i];
        case M_ADD: return kKnobAdd[i];
        case M_STRING: return kKnobString[i];
        case M_WIND: return kKnobWind[i];
        case M_MODAL: return kKnobModal[i];
        case M_NOISE: return kKnobNoise[i];
        case M_GRAIN: return kKnobGrain[i];
        case M_SPECTRAL: return kKnobSpec[i];
        default: return nullptr;
    }
}

const char* selLabel(int method, int sel) noexcept {
    switch (method) {
        case M_WAVE: return sel == GN_SEL1 ? "WAVE A" : (sel == GN_SEL2 ? "WAVE B" : (sel == GN_SEL3 ? "SHAPER" : (sel == GN_SEL4 ? "PHASE DIST" : nullptr)));
        case M_ADD: return sel == GN_SEL1 ? "SERIES" : nullptr;   // (the second choice of the additive generator is not used by the sound)
        case M_STRING: return sel == GN_SEL1 ? "EXCITER" : (sel == GN_SEL2 ? "EXCITED BY" : nullptr);
        case M_WIND: return sel == GN_SEL1 ? "INSTRUMENT" : nullptr;
        case M_MODAL: return sel == GN_SEL1 ? "MATERIAL" : (sel == GN_SEL2 ? "EXCITED BY" : nullptr);
        case M_NOISE: return sel == GN_SEL1 ? "COLOUR" : nullptr;
        case M_GRAIN: return sel == GN_SEL1 ? "SOURCE" : (sel == GN_SEL2 ? "WINDOW" : nullptr);
        case M_SPECTRAL: return sel == GN_SEL1 ? "SOURCE" : (sel == GN_SEL2 ? "OPERATION" : nullptr);
        default: return nullptr;
    }
}

std::string selChoiceName(int method, int sel, int c) {
    static const char* const shaper[kShapers] = {"OFF", "TANH", "ATAN", "CHEBY 3", "SINE", "POWER", "CRUSH", "RECTIFY"};
    static const char* const pd[kPhaseDists] = {"OFF", "SAW BEND", "PULSE BEND", "RESONANT", "TWIST", "DOUBLE"};
    static const char* const series[kAddSeries] = {"SAW", "SQUARE", "TRIANGLE", "EQUAL", "PRIME", "1/SQRT"};
    static const char* const exciter[kExciters] = {"PLUCK", "HAMMER", "BOW", "NOISE", "IMPULSE"};
    static const char* const wind[kWinds] = {"CLARINET", "SAX", "ZURNA", "KAVAL", "BRASS"};
    static const char* const material[kMaterials] = {"BAR", "PLATE", "BELL", "TUBE", "WOOD", "GLASS"};
    static const char* const colour[kNoiseColors] = {"WHITE", "PINK", "BROWN", "BLUE", "CRACKLE", "STEPS"};
    static const char* const window[4] = {"HANN", "TRIANGLE", "GAUSS", "FLAT TOP"};
    static const char* const spec[kSpectralOps] = {"FREEZE", "BLUR", "SHIFT", "STRETCH", "GATE", "TILT", "COMB", "WHISPER"};
    const auto gen = [](int k) { return "GEN " + std::to_string(k); };
    switch (method) {
        case M_WAVE:
            if (sel == GN_SEL3) return shaper[std::clamp(c, 0, kShapers - 1)];
            if (sel == GN_SEL4) return pd[std::clamp(c, 0, kPhaseDists - 1)];
            return waveName(c);
        case M_ADD: return series[std::clamp(c, 0, kAddSeries - 1)];
        case M_STRING: return sel == GN_SEL1 ? exciter[std::clamp(c, 0, kExciters - 1)] : (c <= 0 ? std::string("OWN") : gen(c));
        case M_WIND: return wind[std::clamp(c, 0, kWinds - 1)];
        case M_MODAL: return sel == GN_SEL1 ? material[std::clamp(c, 0, kMaterials - 1)] : (c <= 0 ? std::string("OWN") : gen(c));
        case M_NOISE: return colour[std::clamp(c, 0, kNoiseColors - 1)];
        case M_GRAIN: return sel == GN_SEL1 ? gen(c + 1) : window[std::clamp(c, 0, 3)];
        case M_SPECTRAL: return sel == GN_SEL1 ? gen(c + 1) : spec[std::clamp(c, 0, kSpectralOps - 1)];
        default: return std::to_string(c);
    }
}

const char* linkTypeName(int t) noexcept {
    static const char* const n[kLinkTypes] = {"OFF", "PM", "FM", "AM", "RING", "SYNC", "WARP", "FILT FM"};
    return n[std::clamp(t, 0, kLinkTypes - 1)];
}
const char* routeName(int r) noexcept {
    static const char* const n[kRoutes] = {"DRY", "FILTER A", "FILTER B", "A + B"};
    return n[std::clamp(r, 0, kRoutes - 1)];
}
const char* ownFilterName(int t) noexcept {
    static const char* const n[kOwnFilters] = {"OFF", "LP", "HP", "BP", "NOTCH"};
    return n[std::clamp(t, 0, kOwnFilters - 1)];
}
const char* filterTypeName(int t) noexcept {
    static const char* const n[kFilterTypes] = {"OFF", "LP", "HP", "BP", "NOTCH", "LADDER", "SVF", "RESONANT", "FORMANT"};
    return n[std::clamp(t, 0, kFilterTypes - 1)];
}
const char* lfoWaveName(int w) noexcept {
    static const char* const n[kLfoWaves] = {"SINE", "TRIANGLE", "SAW", "REV SAW", "SQUARE", "S&H", "SMOOTH RND"};
    return n[std::clamp(w, 0, kLfoWaves - 1)];
}
const char* modSourceName(int s) noexcept {
    static const char* const n[kModSources] = {"NONE", "ENV 1", "ENV 2", "ENV 3", "ENV 4", "LFO 1", "LFO 2", "LFO 3", "LFO 4", "STEP",
                                               "VELOCITY", "KEY", "BREATH CC2", "EXPR CC11", "MOD WHEEL", "AFTERTOUCH", "POLY AT", "PITCH BEND", "RANDOM"};
    return n[std::clamp(s, 0, kModSources - 1)];
}
const char* priorityName(int p) noexcept {
    static const char* const n[3] = {"LAST", "HIGHEST", "LOWEST"};
    return n[std::clamp(p, 0, 2)];
}

bool destUsable(int k, const float* p) noexcept {
    k = std::clamp(k, 0, kDestCount - 1);
    if (k >= kDestFilterBase) return true;
    const int g = k / kDestPerGen, s = k % kDestPerGen;
    const int m = methodOf(p, g);
    if (m == M_OFF) return false;
    if (s < 8) return true;
    return methodKnobName(m, s - 8) != nullptr;
}

std::string destName(int k, const float* p) {
    k = std::clamp(k, 0, kDestCount - 1);
    if (k < kDestFilterBase) {
        const int g = k / kDestPerGen, s = k % kDestPerGen;
        static const char* const base[8] = {"LEVEL", "PAN", "PITCH", "FINE", "OWN CUT", "OWN RES", "DETUNE", "PHASE"};
        std::string nm = "G" + std::to_string(g + 1) + " ";
        if (s < 8) return nm + base[s];
        const char* kn = methodKnobName(methodOf(p, g), s - 8);
        return kn != nullptr ? nm + kn : nm + "KNOB " + std::to_string(s - 7);
    }
    if (k < kDestLfoBase) {
        static const char* const n[4] = {"CUT", "RES", "DRIVE", "VOWEL"};
        const int i = k - kDestFilterBase;
        return std::string("FILTER ") + (i / 4 == 0 ? "A " : "B ") + n[i % 4];
    }
    if (k < kDestGlobalBase) return "LFO " + std::to_string(k - kDestLfoBase + 1) + " RATE";
    if (k < kDestAllPitch) {
        static const char* const n[4] = {"MASTER LEVEL", "VIBRATO DEPTH", "TREMOLO DEPTH", "WIDTH"};
        return n[k - kDestGlobalBase];
    }
    return "ALL PITCH";
}

std::string patchSummary(const float* p) {
    std::string s;
    for (int g = 0; g < kGens; ++g) {
        const int m = methodOf(p, g);
        if (m == M_OFF) continue;
        std::string name = methodName(m);
        if (s.find(name) != std::string::npos) continue;
        if (!s.empty()) s += " · ";
        s += name;
    }
    return s.empty() ? "SILENT" : s;
}

// ------------------------------------------------------------------------------------------------- display
const char* paramName(int id, const float* p) noexcept {
    if (id < 0 || id >= kParamCount) return nullptr;
    const Where w = where(id);
    switch (w.region) {
        case 0:
            switch (w.off) {
                case G_LEVEL: return "LEVEL"; case G_FILTER_LINK: return "FILTERS"; case G_PRIORITY: return "PRIORITY"; case G_RETRIG: return "RETRIGGER";
                case G_KEEP_RES: return "KEEP RESONANCE"; case G_VOICES: return "VOICES"; case G_VIB_RATE: return "VIB RATE"; case G_VIB_DEPTH: return "VIB DEPTH";
                case G_VIB_DELAY: return "VIB DELAY"; case G_VIB_WHEEL: return "VIB BY WHEEL"; case G_TREM_RATE: return "TREM RATE"; case G_TREM_DEPTH: return "TREM DEPTH";
                case G_WIDTH: return "WIDTH"; case G_VEL_CURVE: return "VEL CURVE"; case G_DRIVE: return "DRIVE";
                case E_BEND_UP_ID: return "BEND +"; case E_BEND_DOWN_ID: return "BEND −";
                default: return nullptr;
            }
        case 1: {
            const int m = methodOf(p, w.index);
            switch (w.off) {
                case GN_METHOD: return "METHOD"; case GN_ROUTE: return "ROUTE"; case GN_FTYPE: return "OWN FILTER";
                case GN_SEL1: case GN_SEL2: case GN_SEL3: case GN_SEL4: return selLabel(m, w.off);
                case GN_OCT: return "OCTAVE"; case GN_SEMI: return "SEMITONE"; case GN_UNISON: return "UNISON"; case GN_SYNC: return "SYNC";
                case GN_FIXED: return "FIXED Hz"; case GN_AMPENV: return "AMP ENV"; case GN_FENV: return "CUT ENV"; case GN_PENV: return "PITCH ENV";
                case GN_LEVEL: return "LEVEL"; case GN_PAN: return "PAN"; case GN_FINE: return "FINE"; case GN_RATIO: return "RATIO"; case GN_FIXHZ: return "FREQ";
                case GN_PHASE: return "PHASE"; case GN_FCUT: return "CUTOFF"; case GN_FRES: return "RESON"; case GN_VELLEV: return "VEL→LEVEL";
                case GN_UNIDET: return "DETUNE"; case GN_UNISPR: return "SPREAD"; case GN_SYNCR: return "SYNC RATIO"; case GN_FENVAMT: return "ENV→CUT";
                case GN_PENVAMT: return "ENV→PITCH"; case GN_FKEY: return "KEY TRACK"; case GN_MUTE: return "MUTE";
                default: return w.off >= GN_F0 && w.off < GN_F0 + kGenFloats ? methodKnobName(m, w.off - GN_F0) : nullptr;
            }
        }
        case 2: return w.off == 0 ? "LINK" : "AMOUNT";
        case 3: {
            static const char* const n[] = {"TYPE", "CUTOFF", "RESON", "DRIVE", "KEY TRACK", "VEL→CUT", "ENVELOPE", "ENV→CUT", "VOWEL", "MORPH"};
            return w.off < 10 ? n[w.off] : nullptr;
        }
        case 4:
            switch (w.off) {
                case EV_START: return "START"; case EV_SUS: return "SUSTAIN AT"; case EV_REL: return "RELEASE"; case EV_CURVE: return "CURVE";
                case EV_LOOP: return "LOOP"; case EV_KEYT: return "KEY→TIME";
                default: return (w.off & 1) != 0 ? "TIME" : "LEVEL";
            }
        case 5: {
            static const char* const n[] = {"WAVE", "RATE", "DELAY", "FADE", "PHASE", "UNIPOLAR", "RANDOM START", "KEY→RATE"};
            return w.off < 8 ? n[w.off] : nullptr;
        }
        case 6: return w.off == ST_LEN ? "LENGTH" : (w.off == ST_RATE ? "RATE" : (w.off == ST_GLIDE ? "GLIDE" : (w.off == ST_DIR ? "DIRECTION" : "STEP")));
        case 7: return w.off == 0 ? "SOURCE" : (w.off == 1 ? "TARGET" : "AMOUNT");
        case 8: {
            static const char* const n[] = {"CONTROLLER", "CURVE", "TARGET 1", "AMOUNT 1", "TARGET 2", "AMOUNT 2", "TARGET 3", "AMOUNT 3"};
            return n[w.off];
        }
        case 9: return w.off == TN_ON ? "TUNING" : (w.off == TN_ROOT ? "ROOT" : (w.off == TN_MASTER ? "MASTER TUNE" : "NOTE CENTS"));
        default: return "WAVE POINT";
    }
}

Disp paramDisp(int id, const float* p) noexcept {
    if (id < 0 || id >= kParamCount) return kPct;
    const Where w = where(id);
    switch (w.region) {
        case 0:
            switch (w.off) {
                case G_LEVEL: return lin(rng::kLevelDbLo, rng::kLevelDbHi, " dB", 1);
                case G_FILTER_LINK: case G_RETRIG: case G_KEEP_RES: case G_VIB_WHEEL: return kSwitch;
                case G_PRIORITY: return whole(0.0F, 2.0F);
                case G_VOICES: return whole(1.0F, 24.0F);
                case G_VIB_RATE: return lg(rng::kVibRateLo, rng::kVibRateHi, " Hz", 1);
                case G_VIB_DEPTH: return lin(0.0F, rng::kVibDepthCents, " c", 0);
                case G_VIB_DELAY: return lin(0.0F, 2.0F, " s", 2);
                case G_TREM_RATE: return lg(0.1F, 14.0F, " Hz", 1);
                case G_VEL_CURVE: return Disp{Disp::PctBi, -1.0F, 1.0F, "", 0};
                default: return kPct;
            }
        case 1: {
            const int m = methodOf(p, w.index);
            switch (w.off) {
                case GN_LEVEL: return Disp{Disp::Db, rng::kGenDbLo, rng::kGenDbHi, " dB", 1};
                case GN_PAN: return kBi;
                case GN_FINE: return lin(-100.0F, 100.0F, " c", 0);
                case GN_RATIO: return lg(rng::kRatioLo, rng::kRatioHi, "x", 3);
                case GN_FIXHZ: return lg(rng::kFixHzLo, rng::kFixHzHi, " Hz", 1);
                case GN_PHASE: return lin(0.0F, 360.0F, "°", 0);
                case GN_FCUT: return lg(rng::kCutLo, rng::kCutHi, " Hz", 0);
                case GN_UNIDET: return lin(0.0F, rng::kUniDetCents, " c", 0);
                case GN_SYNCR: return lin(1.0F, 8.0F, "x", 2);
                case GN_FENVAMT: return lin(-rng::kFenvOct, rng::kFenvOct, " oct", 1);
                case GN_PENVAMT: return lin(-rng::kPenvSemis, rng::kPenvSemis, " st", 1);
                case GN_OCT: return whole(-3.0F, 3.0F);
                case GN_SEMI: return whole(-24.0F, 24.0F, " st");
                case GN_UNISON: return whole(1.0F, 4.0F);
                case GN_SYNC: case GN_FIXED: case GN_MUTE: return kSwitch;
                default:
                    if (w.off >= GN_F0 && w.off < GN_F0 + kGenFloats) return knobDisp(m, w.off - GN_F0);
                    return kPct;
            }
        }
        case 2: return w.off == 0 ? whole(0.0F, static_cast<float>(kLinkTypes - 1)) : kPct;
        case 3:
            switch (w.off) {
                case FL_CUT: return lg(rng::kCutLo, rng::kCutHi, " Hz", 0);
                case FL_VEL: return lin(0.0F, 4.0F, " oct", 1);
                case FL_ENVAMT: return lin(-rng::kFenvOct, rng::kFenvOct, " oct", 1);
                case FL_KEY: return kPct;
                default: return kPct;
            }
        case 4:
            if (w.off == EV_REL || (w.off >= 1 && w.off <= 10 && (w.off & 1) != 0)) return Disp{Disp::Time, 0.0F, 1.0F, " s", 2};
            if (w.off == EV_CURVE || w.off == EV_KEYT) return kBi;
            if (w.off == EV_LOOP) return kSwitch;
            return kPct;
        case 5:
            switch (w.off) {
                case LF_RATE: return lg(rng::kLfoLo, rng::kLfoHi, " Hz", 2);
                case LF_DELAY: case LF_FADE: return lin(0.0F, rng::kLfoTimeHi, " s", 2);
                case LF_PHASE: return lin(0.0F, 360.0F, "°", 0);
                case LF_UNI: case LF_FREE: return kSwitch;
                default: return kPct;
            }
        case 6:
            if (w.off == ST_RATE) return lg(rng::kStepLo, rng::kStepHi, " Hz", 2);
            if (w.off >= ST_STEPS) return kBi;
            return w.off == ST_LEN || w.off == ST_DIR ? whole(0.0F, 15.0F) : kPct;
        case 7: return w.off == 2 ? kBi : whole(0.0F, 1.0F);
        case 8: return (w.off == CT_A1 || w.off == CT_A2 || w.off == CT_A3) ? kBi : whole(0.0F, 1.0F);
        case 9:
            if (w.off == TN_MASTER) return lin(-100.0F, 100.0F, " c", 0);
            if (w.off >= TN_CENTS) return lin(-100.0F, 100.0F, " c", 0);
            return w.off == TN_ON ? kSwitch : whole(0.0F, 11.0F);
        default: return kBi;
    }
}

float dispFromNorm(const Disp& d, float t) noexcept {
    switch (d.kind) {
        case Disp::Pct: return t * 100.0F;
        case Disp::PctBi: return (t - 0.5F) * 200.0F;
        case Disp::Lin: case Disp::Db: return d.lo + t * (d.hi - d.lo);
        case Disp::Log: return d.lo * std::pow(d.hi / d.lo, t);
        case Disp::Time: return envTimeOf(t);
        default: return t;
    }
}
float dispToNorm(const Disp& d, float v) noexcept {
    float t = 0.0F;
    switch (d.kind) {
        case Disp::Pct: t = v / 100.0F; break;
        case Disp::PctBi: t = v / 200.0F + 0.5F; break;
        case Disp::Lin: case Disp::Db: t = (v - d.lo) / (d.hi - d.lo); break;
        case Disp::Log: t = std::log(std::max(v, d.lo) / d.lo) / std::log(d.hi / d.lo); break;
        case Disp::Time: t = v <= 0.0F ? 0.0F : std::log10(std::max(v, rng::kTimeLo) / rng::kTimeLo) / 4.0F; break;
        default: t = v; break;
    }
    return clampf1(t);
}

std::string dispText(const Disp& d, float t) {
    char b[48];
    switch (d.kind) {
        case Disp::Switch: return t >= 0.5F ? "ON" : "OFF";
        case Disp::Whole: std::snprintf(b, sizeof b, "%d%s", static_cast<int>(std::lround(t)), d.unit); return b;
        case Disp::Pct: std::snprintf(b, sizeof b, "%d%%", static_cast<int>(std::lround(t * 100.0F))); return b;
        case Disp::PctBi: {
            const int v = static_cast<int>(std::lround((t - 0.5F) * 200.0F));
            std::snprintf(b, sizeof b, "%+d%s", v, d.unit); return v == 0 ? std::string("0") : std::string(b);
        }
        case Disp::Db: if (t <= 0.002F) return "-inf"; std::snprintf(b, sizeof b, "%+.1f dB", static_cast<double>(dispFromNorm(d, t))); return b;
        case Disp::Time: {
            const float s = envTimeOf(t);
            if (s <= 0.0F) return "0 ms";
            if (s < 1.0F) std::snprintf(b, sizeof b, "%.0f ms", static_cast<double>(s * 1000.0F)); else std::snprintf(b, sizeof b, "%.2f s", static_cast<double>(s));
            return b;
        }
        default: {
            const float v = dispFromNorm(d, t);
            const bool big = d.kind == Disp::Log && std::strcmp(d.unit, " Hz") == 0 && v >= 1000.0F;
            if (big) { std::snprintf(b, sizeof b, "%.2f kHz", static_cast<double>(v / 1000.0F)); return b; }
            if (d.unit[0] == ' ' && d.unit[1] == 's' && d.unit[2] == '\0' && v < 1.0F && v >= 0.001F && d.decimals >= 2) { std::snprintf(b, sizeof b, "%.0f ms", static_cast<double>(v * 1000.0F)); return b; }
            const bool sign = d.kind == Disp::Lin && d.lo < 0.0F;
            std::snprintf(b, sizeof b, sign ? "%+.*f%s" : "%.*f%s", d.decimals, static_cast<double>(v), d.unit);
            return b;
        }
    }
}

// ------------------------------------------------------------------------------------------------- the wave editor
const char* waveOpName(int op) noexcept {
    static const char* const n[kWaveOps] = {"MIRROR", "INVERT", "SYM EVEN", "SYM ODD", "ODD HARM", "EVEN HARM", "SMOOTH", "NORMALIZE"};
    return n[std::clamp(op, 0, kWaveOps - 1)];
}
const char* combineName(int c) noexcept {
    static const char* const n[kCombines] = {"MORPH", "SPECTRUM", "MULTIPLY", "ADD"};
    return n[std::clamp(c, 0, kCombines - 1)];
}

void waveNormalize(float* x) noexcept {
    double mean = 0.0;
    for (int i = 0; i < kDrawLen; ++i) mean += static_cast<double>(x[i]);
    mean /= kDrawLen;
    float pk = 0.0F;
    for (int i = 0; i < kDrawLen; ++i) { x[i] -= static_cast<float>(mean); pk = std::max(pk, std::fabs(x[i])); }
    if (pk > 1.0e-6F) for (int i = 0; i < kDrawLen; ++i) x[i] /= pk;
}

void waveHarmonics(const float* x, float* amp, float* phase) noexcept {
    for (int k = 1; k <= kEditHarmonics; ++k) {
        double re = 0.0, im = 0.0;
        for (int n = 0; n < kDrawLen; ++n) {
            const double a = 2.0 * kPi * k * n / kDrawLen;
            re += static_cast<double>(x[n]) * std::cos(a);
            im -= static_cast<double>(x[n]) * std::sin(a);
        }
        re *= 2.0 / kDrawLen; im *= 2.0 / kDrawLen;
        amp[k - 1] = static_cast<float>(std::sqrt(re * re + im * im));
        phase[k - 1] = amp[k - 1] > 1.0e-6F ? static_cast<float>(std::atan2(im, re)) : 0.0F;
    }
}

void waveFromHarmonics(const float* amp, const float* phase, float* x) noexcept {
    float pk = 0.0F;
    for (int n = 0; n < kDrawLen; ++n) {
        double v = 0.0;
        for (int k = 1; k <= kEditHarmonics; ++k) v += static_cast<double>(amp[k - 1]) * std::cos(2.0 * kPi * k * n / kDrawLen + static_cast<double>(phase[k - 1]));
        x[n] = static_cast<float>(v);
        pk = std::max(pk, std::fabs(x[n]));
    }
    if (pk > 1.0F) for (int n = 0; n < kDrawLen; ++n) x[n] /= pk;
}

void waveApplyOp(int op, float* x) noexcept {
    float t[kDrawLen];
    std::memcpy(t, x, sizeof t);
    constexpr int N = kDrawLen;
    switch (op) {
        case WO_MIRROR: for (int i = 0; i < N; ++i) x[i] = t[(N - i) % N]; break;
        case WO_INVERT: for (int i = 0; i < N; ++i) x[i] = -t[i]; break;
        case WO_SYM_EVEN: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] + t[(N - i) % N]); break;
        case WO_SYM_ODD: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] - t[(N - i) % N]); break;
        case WO_ODD_HARM: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] - t[(i + N / 2) % N]); break;
        case WO_EVEN_HARM: for (int i = 0; i < N; ++i) x[i] = 0.5F * (t[i] + t[(i + N / 2) % N]); break;
        case WO_SMOOTH: for (int i = 0; i < N; ++i) x[i] = 0.25F * t[(i + N - 1) % N] + 0.5F * t[i] + 0.25F * t[(i + 1) % N]; break;
        default: break;
    }
    if (op == WO_NORMALIZE || op == WO_ODD_HARM || op == WO_EVEN_HARM || op == WO_SYM_EVEN || op == WO_SYM_ODD) {
        float pk = 0.0F;
        for (int i = 0; i < N; ++i) pk = std::max(pk, std::fabs(x[i]));
        if (op == WO_NORMALIZE) waveNormalize(x);
        else if (pk > 1.0e-6F) for (int i = 0; i < N; ++i) x[i] /= pk;   // the result keeps a full-size wave
    }
}

void waveCombine(int mode, const float* a, const float* b, float t, float* out) noexcept {
    t = clampf1(t);
    float r[kDrawLen];
    switch (mode) {
        case CM_SPECTRUM: {
            float aa[kEditHarmonics], pa[kEditHarmonics], ab[kEditHarmonics], pb[kEditHarmonics], am[kEditHarmonics], pm[kEditHarmonics];
            waveHarmonics(a, aa, pa); waveHarmonics(b, ab, pb);
            for (int k = 0; k < kEditHarmonics; ++k) {
                am[k] = aa[k] + (ab[k] - aa[k]) * t;
                float d = pb[k] - pa[k];
                while (d > static_cast<float>(kPi)) d -= static_cast<float>(2.0 * kPi);
                while (d < -static_cast<float>(kPi)) d += static_cast<float>(2.0 * kPi);
                pm[k] = pa[k] + d * t;
            }
            waveFromHarmonics(am, pm, r);
            break;
        }
        case CM_MULTIPLY: for (int i = 0; i < kDrawLen; ++i) r[i] = a[i] * (1.0F + t * (b[i] - 1.0F)); break;   // t = 0: a unchanged, t = 1: a x b
        case CM_ADD: for (int i = 0; i < kDrawLen; ++i) r[i] = a[i] + b[i] * t; break;   // t = 0: a, t = 1: a + b
        default: for (int i = 0; i < kDrawLen; ++i) r[i] = a[i] + (b[i] - a[i]) * t; break;   // CM_MORPH
    }
    if (mode == CM_MULTIPLY || mode == CM_ADD) {
        float pk = 0.0F;
        for (int i = 0; i < kDrawLen; ++i) pk = std::max(pk, std::fabs(r[i]));
        if (pk > 1.0e-6F) for (int i = 0; i < kDrawLen; ++i) r[i] /= pk;
    }
    for (int i = 0; i < kDrawLen; ++i) out[i] = std::clamp(r[i], -1.0F, 1.0F);
}

void waveChoicePoints(int choice, const float* patch, float* pts) noexcept {
    if (choice >= 0 && choice < kMathWaves) { waveCycle(choice, pts, kDrawLen); return; }
    if (choice >= kWaveDrawn0 && choice < kWaveFile0 && patch != nullptr) {
        for (int i = 0; i < kDrawLen; ++i) pts[i] = (clampf1(patch[drawId(choice - kWaveDrawn0, i)]) - 0.5F) * 2.0F;
        return;
    }
    for (int i = 0; i < kDrawLen; ++i) pts[i] = 0.0F;
}

// ------------------------------------------------------------------------------------------------- the shape of an envelope
namespace {
EnvCfg cookEnv(const float* patch, int e) {
    EnvCfg c;
    const float* row = patch + envId(e, 0);
    c.start = clampf1(row[EV_START]);
    for (int i = 0; i < kEnvPoints; ++i) { c.t[i] = envTimeOf(clampf1(row[envT(i)])); c.l[i] = clampf1(row[envL(i)]); }
    c.sus = std::clamp(static_cast<int>(std::lround(row[EV_SUS])), 0, kEnvPoints - 1);
    c.rel = envTimeOf(clampf1(row[EV_REL]));
    c.curve = (clampf1(row[EV_CURVE]) - 0.5F) * 2.0F;
    c.loop = false;   // the drawing shows one run
    return c;
}
}  // namespace

float envelopePointTime(const float* patch, int e, int pt) noexcept {
    const EnvCfg c = cookEnv(patch, std::clamp(e, 0, kEnvs - 1));
    float t = 0.0F;
    for (int i = 0; i <= std::clamp(pt, 0, kEnvPoints - 1); ++i) t += c.t[i];
    return t;
}

void envelopePreview(const float* patch, int e, int n, float* out, float* totalSec, float* releaseAtSec) {
    e = std::clamp(e, 0, kEnvs - 1);
    const EnvCfg c = cookEnv(patch, e);
    constexpr double sr = 2000.0;
    float attack = 0.0F;
    for (int i = 0; i <= c.sus; ++i) attack += c.t[i];
    const float hold = 0.15F + 0.2F * attack;
    float relTime = c.rel;
    for (int i = std::min(c.sus + 1, kEnvPoints); i < kEnvPoints; ++i) relTime += c.t[i];
    const float total = std::max(0.05F, attack + hold + relTime);
    if (totalSec != nullptr) *totalSec = total;
    if (releaseAtSec != nullptr) *releaseAtSec = attack + hold;
    EnvState s;
    s.begin(c, sr, 1.0F);
    const int steps = static_cast<int>(total * static_cast<float>(sr)) + 1;
    const int relAt = static_cast<int>((attack + hold) * static_cast<float>(sr));
    std::vector<float> run(static_cast<std::size_t>(steps), 0.0F);
    for (int i = 0; i < steps; ++i) {
        if (i == relAt) s.release(c, sr, 1.0F);
        run[static_cast<std::size_t>(i)] = s.tick(c, sr, 1.0F);
    }
    for (int i = 0; i < n; ++i) {
        const std::size_t k = std::min<std::size_t>(run.size() - 1, static_cast<std::size_t>(static_cast<double>(i) * static_cast<double>(run.size() - 1) / std::max(1, n - 1)));
        out[i] = run[k];
    }
}

} // namespace silveton::sampler::suse
