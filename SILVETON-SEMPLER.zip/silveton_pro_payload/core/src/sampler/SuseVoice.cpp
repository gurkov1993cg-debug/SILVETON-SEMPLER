// SILVETON_SUSE_V1 - the voice of SILVETON SYNTH: control (modulation, envelopes, tuning) and the mix. The generators are in SuseGens.cpp.
#include "SuseVoice.h"

namespace silveton::sampler::suse {

namespace {
float velCurve(float v, float t) noexcept { return std::pow(clampf(v, 0.0F, 1.0F), std::pow(2.0F, (t - 0.5F) * 2.0F)); }
}  // namespace

float Voice::timeScale(int e) const noexcept {
    const float k = (p_[envId(e, EV_KEYT)] - 0.5F) * 2.0F;
    return k == 0.0F ? 1.0F : std::pow(2.0F, -k * static_cast<float>(keyNow_ - 60) / 24.0F);
}

void Voice::cookEnvelope(int e) noexcept {
    EnvCfg& c = envCfg_[static_cast<std::size_t>(e)];
    const float* row = p_ + envId(e, 0);
    if (std::memcmp(row, c.raw, sizeof(float) * kEnvStride) == 0 && started_) return;
    std::memcpy(c.raw, row, sizeof(float) * kEnvStride);
    c.start = clampf(row[EV_START], 0.0F, 1.0F);
    for (int i = 0; i < kEnvPoints; ++i) { c.t[i] = envTimeOf(clampf(row[envT(i)], 0.0F, 1.0F)); c.l[i] = clampf(row[envL(i)], 0.0F, 1.0F); }
    c.sus = std::clamp(static_cast<int>(std::lround(row[EV_SUS])), 0, kEnvPoints - 1);
    c.rel = envTimeOf(clampf(row[EV_REL], 0.0F, 1.0F));
    c.curve = (clampf(row[EV_CURVE], 0.0F, 1.0F) - 0.5F) * 2.0F;
    c.loop = row[EV_LOOP] >= 0.5F;
}

void Voice::startEnvelopes() noexcept {
    for (int e = 0; e < kEnvs; ++e) {
        cookEnvelope(e);
        env_[static_cast<std::size_t>(e)] = EnvState{};
        env_[static_cast<std::size_t>(e)].begin(envCfg_[static_cast<std::size_t>(e)], sr_, timeScale(e));
        envNow_[static_cast<std::size_t>(e)] = env_[static_cast<std::size_t>(e)].level;
    }
}

void Voice::resetGen(int g) noexcept {
    Gen& G = gen_[static_cast<std::size_t>(g)];
    std::fill(mem_[static_cast<std::size_t>(g)].begin(), mem_[static_cast<std::size_t>(g)].end(), 0.0F);
    const std::uint32_t seed = G.rng * 2654435761U + static_cast<std::uint32_t>(g) * 97U + 1U;
    const double mc = G.mulCur, md = G.mulDlt; const float gc = G.gainCur, gd = G.gainDlt, pl = G.panLCur, pld = G.panLDlt, pr = G.panRCur, prd = G.panRDlt;
    const int am = G.aMethod; const int as[4] = {G.aSel[0], G.aSel[1], G.aSel[2], G.aSel[3]}; const int au = G.aUni, af = G.aFtype;
    const double incNow = G.incNow;
    G = Gen{};
    G.rng = seed | 1U; G.sRng = seed ^ 0x9E3779B9U;
    G.mulCur = mc; G.mulDlt = md; G.gainCur = gc; G.gainDlt = gd; G.panLCur = pl; G.panLDlt = pld; G.panRCur = pr; G.panRDlt = prd;
    G.aMethod = am; for (int i = 0; i < 4; ++i) G.aSel[i] = as[i]; G.aUni = au; G.aFtype = af;
    G.incNow = incNow; G.started = true; G.fade = 1.0F;
    G.strDamp = 1.0F;
}

void Voice::noteOn(const float* params, double sampleRate, const Inputs& in, std::uint32_t seed, const Shared* shared) noexcept {
    p_ = params; shared_ = shared; sr_ = sampleRate; in_ = in; keyNow_ = in.key;
    finished_ = false; killing_ = false; killGain_ = 1.0F; pos_ = kChunk; peak_ = 0.0F; lastInc_ = 0.0;
    rng_ = seed | 1U; started_ = false;
    for (auto& e : envCfg_) std::memset(e.raw, 0xFF, sizeof(e.raw));
    startEnvelopes();
    started_ = true;
    for (int l = 0; l < kLfos; ++l) {
        lfo_[static_cast<std::size_t>(l)] = LfoState{};
        lfo_[static_cast<std::size_t>(l)].rng = (seed + static_cast<std::uint32_t>(l) * 7919U) | 1U;
        lfo_[static_cast<std::size_t>(l)].ph = p_[lfoId(l, LF_PHASE)];
        if (p_[lfoId(l, LF_FREE)] >= 0.5F && p_[lfoId(l, LF_FREE)] < 1.5F) lfo_[static_cast<std::size_t>(l)].ph = static_cast<double>((seed >> 8) & 0xFFFFU) / 65536.0;
    }
    step_ = StepState{}; step_.rng = seed | 1U;
    vibPh_ = 0.0; tremPh_ = 0.0; vibAge_ = 0.0F; vibSemis_ = 0.0F; tremGain_ = tremGainPrev_ = 1.0F;
    modAdd_.fill(0.0F); pitchMod_.fill(0.0F); nLinks_.fill(0); modOut_.fill(0.0F);
    for (int g = 0; g < kGens; ++g) {
        Gen& G = gen_[static_cast<std::size_t>(g)];
        G = Gen{};
        G.rng = (seed * 747796405U + static_cast<std::uint32_t>(g) * 2891336453U) | 1U;
        G.sRng = G.rng ^ 0xA5A5A5A5U;
        std::fill(mem_[static_cast<std::size_t>(g)].begin(), mem_[static_cast<std::size_t>(g)].end(), 0.0F);
        G.aMethod = std::clamp(static_cast<int>(std::lround(p_[genId(g, GN_METHOD)])), 0, kMethods - 1);
        for (int s = 0; s < 4; ++s) G.aSel[s] = static_cast<int>(std::lround(p_[genId(g, GN_SEL1 + s)]));
        G.aUni = std::clamp(static_cast<int>(std::lround(p_[genId(g, GN_UNISON)])), 1, 4);
        G.aFtype = std::clamp(static_cast<int>(std::lround(p_[genId(g, GN_FTYPE)])), 0, kOwnFilters - 1);
        G.fade = 1.0F; G.started = true; G.gainCur = -1.0F;   // -1: the first chunk takes its level at once
        for (int u = 0; u < 4; ++u) G.ph[u] = static_cast<double>(p_[genId(g, GN_PHASE)]) + (u == 0 ? 0.0 : static_cast<double>((G.rng >> (u * 4)) & 0xFFU) / 256.0);
    }
    for (auto& f : flt_) for (auto& c : f) c.reset();
    for (int f = 0; f < kFilters; ++f) { fltType_[static_cast<std::size_t>(f)] = std::clamp(static_cast<int>(std::lround(p_[filterId(f, FL_TYPE)])), 0, kFilterTypes - 1); fltFade_[static_cast<std::size_t>(f)] = 1.0F; fltFadeDir_[static_cast<std::size_t>(f)] = 0; }
    masterGain_ = masterPrev_ = -1.0F;
}

void Voice::setInputs(const Inputs& in, double sampleRate) noexcept {
    sr_ = sampleRate;
    const bool wasGate = in_.gate;
    const int oldKey = keyNow_;
    in_ = in;
    if (wasGate && !in.gate) {
        for (int e = 0; e < kEnvs; ++e) env_[static_cast<std::size_t>(e)].release(envCfg_[static_cast<std::size_t>(e)], sr_, timeScale(e));
        for (int g = 0; g < kGens; ++g) gen_[static_cast<std::size_t>(g)].strDamp = 0.0F;   // the damper touches the strings
    }
    if (in.gate && in.key != oldKey) {   // LEGATO: the same voice goes to a new key
        keyNow_ = in.key;
        if (p_[G_RETRIG] >= 0.5F) {
            for (int e = 0; e < kEnvs; ++e) {
                EnvState& s = env_[static_cast<std::size_t>(e)];
                s.stage = 0; s.gate = true; s.goTo(envCfg_[static_cast<std::size_t>(e)], 0, sr_, timeScale(e));
            }
        }
        if (p_[G_KEEP_RES] < 0.5F) {   // the strings / tubes / modes start again
            for (int g = 0; g < kGens; ++g) {
                Gen& G = gen_[static_cast<std::size_t>(g)];
                if (G.aMethod == M_STRING || G.aMethod == M_WIND || G.aMethod == M_MODAL) {
                    const int am = G.aMethod; const int a0 = G.aSel[0], a1 = G.aSel[1], a2 = G.aSel[2], a3 = G.aSel[3];
                    resetGen(g);
                    G.aMethod = am; G.aSel[0] = a0; G.aSel[1] = a1; G.aSel[2] = a2; G.aSel[3] = a3;
                }
            }
        }
    }
}

void Voice::tick(double inc, float& l, float& r) noexcept {
    if (pos_ >= kChunk) { renderChunk(inc); pos_ = 0; }
    l = bufL_[pos_]; r = bufR_[pos_]; ++pos_;
}

void Voice::updateControl(double inc) noexcept {
    const float* p = p_;
    const double chunkSec = static_cast<double>(kChunk) / sr_;
    for (int e = 0; e < kEnvs; ++e) cookEnvelope(e);
    // ---- the LFOs and the step modulator (their rates take the modulation of the chunk before)
    for (int l = 0; l < kLfos; ++l) {
        const float rt = clampf(p[lfoId(l, LF_RATE)] + modAdd_[static_cast<std::size_t>(kDestLfoBase + l)], 0.0F, 1.0F);
        float hz = mapLog(rt, rng::kLfoLo, rng::kLfoHi);
        const float kf = p[lfoId(l, LF_KEYF)];
        if (kf > 0.0F) hz *= std::pow(2.0F, kf * static_cast<float>(keyNow_ - 60) / 12.0F);
        const bool uni = p[lfoId(l, LF_UNI)] >= 0.5F;
        src_[static_cast<std::size_t>(MS_LFO1 + l)] = lfo_[static_cast<std::size_t>(l)].tick(
            std::clamp(static_cast<int>(std::lround(p[lfoId(l, LF_WAVE)])), 0, kLfoWaves - 1), hz, chunkSec, !uni,
            p[lfoId(l, LF_DELAY)] * rng::kLfoTimeHi, p[lfoId(l, LF_FADE)] * rng::kLfoTimeHi);
    }
    {
        const int len = std::clamp(static_cast<int>(std::lround(p[stepId(ST_LEN)])), 1, kStepCount);
        const int dir = std::clamp(static_cast<int>(std::lround(p[stepId(ST_DIR)])), 0, 3);
        step_.ph += static_cast<double>(mapLog(p[stepId(ST_RATE)], rng::kStepLo, rng::kStepHi)) * chunkSec;
        while (step_.ph >= 1.0) {
            step_.ph -= 1.0;
            if (dir == 0) step_.idx = (step_.idx + 1) % len;
            else if (dir == 1) step_.idx = (step_.idx + len - 1) % len;
            else if (dir == 2) { step_.idx += step_.dir; if (step_.idx >= len - 1) { step_.idx = len - 1; step_.dir = -1; } if (step_.idx <= 0) { step_.idx = 0; step_.dir = 1; } if (len == 1) step_.idx = 0; }
            else step_.idx = static_cast<int>((lcg(step_.rng) >> 8) % static_cast<std::uint32_t>(len));
        }
        step_.idx = std::clamp(step_.idx, 0, len - 1);
        const float target = (clampf(p[stepId(ST_STEPS + step_.idx)], 0.0F, 1.0F) - 0.5F) * 2.0F;
        const float gl = p[stepId(ST_GLIDE)];
        step_.cur += (target - step_.cur) * (1.0F - gl * 0.98F);
        src_[MS_STEP] = step_.cur;
    }
    // ---- the sources
    src_[MS_NONE] = 0.0F;
    for (int e = 0; e < kEnvs; ++e) src_[static_cast<std::size_t>(MS_ENV1 + e)] = envNow_[static_cast<std::size_t>(e)];
    src_[MS_VELOCITY] = velCurve(in_.velocity, p[G_VEL_CURVE]);
    src_[MS_KEY] = clampf(static_cast<float>(keyNow_ - 60) / 60.0F, -1.0F, 1.0F);
    src_[MS_BREATH] = in_.breath; src_[MS_EXPRESSION] = in_.expression; src_[MS_WHEEL] = in_.wheel;
    src_[MS_AFTERTOUCH] = in_.pressure; src_[MS_POLYAT] = in_.polyPressure; src_[MS_BEND] = in_.bend; src_[MS_RANDOM] = in_.random;
    // ---- the matrix and the controllers
    modAdd_.fill(0.0F); pitchMod_.fill(0.0F);
    const auto apply = [&](int dst, float v) noexcept {
        if (v == 0.0F) return;
        const Dest d = destOf(dst);
        if (d.id >= 0) modAdd_[static_cast<std::size_t>(dst)] += v;
        else pitchMod_[static_cast<std::size_t>(std::clamp(d.gen, 0, kGens))] += v * rng::kModPitchSemis;
    };
    for (int m = 0; m < kMods; ++m) {
        const int s = static_cast<int>(std::lround(p[modId(m, 0)]));
        if (s <= 0 || s >= kModSources) continue;
        const float amt = (clampf(p[modId(m, 2)], 0.0F, 1.0F) - 0.5F) * 2.0F;
        apply(static_cast<int>(std::lround(p[modId(m, 1)])), src_[static_cast<std::size_t>(s)] * amt);
    }
    for (int c = 0; c < kCtls; ++c) {
        const int s = static_cast<int>(std::lround(p[ctlId(c, CT_SRC)]));
        if (s <= 0) continue;
        float v = 0.0F;
        if (s <= 128) v = in_.cc != nullptr ? in_.cc[s - 1] : 0.0F;
        else if (s == kCtlSrcAftertouch) v = in_.pressure;
        else v = 0.5F + 0.5F * in_.bend;
        const int curve = static_cast<int>(std::lround(p[ctlId(c, CT_CURVE)]));
        if (curve == 1) v = v * v; else if (curve == 2) v = std::sqrt(clampf(v, 0.0F, 1.0F));
        for (int k = 0; k < 3; ++k) {
            const float amt = (clampf(p[ctlId(c, CT_A1 + 2 * k)], 0.0F, 1.0F) - 0.5F) * 2.0F;
            if (amt != 0.0F) apply(static_cast<int>(std::lround(p[ctlId(c, CT_D1 + 2 * k)])), v * amt);
        }
    }
    const auto gv = [&](int g, int off) noexcept {
        float v = p[genId(g, off)];
        const int s = destSlotOfOffset(off);
        if (s >= 0) v += modAdd_[static_cast<std::size_t>(g * kDestPerGen + s)];
        return clampf(v, 0.0F, 1.0F);
    };
    // ---- vibrato / tremolo / tuning
    {
        vibAge_ += static_cast<float>(chunkSec);
        vibPh_ += static_cast<double>(mapLog(p[G_VIB_RATE], rng::kVibRateLo, rng::kVibRateHi)) * chunkSec;
        vibPh_ -= std::floor(vibPh_);
        const float delay = p[G_VIB_DELAY] * 2.0F;
        const float depth = clampf(p[G_VIB_DEPTH] + modAdd_[static_cast<std::size_t>(kDestGlobalBase + 1)], 0.0F, 1.0F) * rng::kVibDepthCents * (p[G_VIB_WHEEL] >= 0.5F ? in_.wheel : 1.0F);
        const float fade = vibAge_ < delay ? 0.0F : clampf((vibAge_ - delay) / 0.3F, 0.0F, 1.0F);
        vibSemis_ = sinT(vibPh_) * depth * 0.01F * fade;
        tremPh_ += static_cast<double>(mapLog(p[G_TREM_RATE], 0.1F, 14.0F)) * chunkSec;
        tremPh_ -= std::floor(tremPh_);
        const float td = clampf(p[G_TREM_DEPTH] + modAdd_[static_cast<std::size_t>(kDestGlobalBase + 2)], 0.0F, 1.0F);
        tremGainPrev_ = tremGain_;
        tremGain_ = 1.0F - td * (0.5F + 0.5F * sinT(tremPh_));
        float cents = (p[tuneId(TN_MASTER)] - 0.5F) * 200.0F;
        if (p[tuneId(TN_ON)] >= 0.5F) {
            const int root = std::clamp(static_cast<int>(std::lround(p[tuneId(TN_ROOT)])), 0, 11);
            const int degree = ((keyNow_ - root) % 12 + 12) % 12;
            cents += (clampf(p[tuneId(TN_CENTS + degree)], 0.0F, 1.0F) - 0.5F) * 200.0F;
        }
        tuneCents_ = cents;
    }
    // ---- the generators
    const float velShaped = src_[MS_VELOCITY];
    float lifeRelease = 0.0F;
    unsigned lifeMask = 1U;   // envelope 1 always keeps the voice alive
    for (int g = 0; g < kGens; ++g) {
        GenCtl& c = ctl_[static_cast<std::size_t>(g)];
        Gen& G = gen_[static_cast<std::size_t>(g)];
        const GenCtl prevCtl = c;
        c.method = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_METHOD)])), 0, kMethods - 1);
        c.route = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_ROUTE)])), 0, kRoutes - 1);
        c.ftype = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_FTYPE)])), 0, kOwnFilters - 1);
        for (int s = 0; s < 4; ++s) c.sel[s] = static_cast<int>(std::lround(p[genId(g, GN_SEL1 + s)]));
        c.unison = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_UNISON)])), 1, 4);
        c.ampEnv = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_AMPENV)])), 0, kEnvs);
        c.fEnv = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_FENV)])), 0, kEnvs);
        c.pEnv = std::clamp(static_cast<int>(std::lround(p[genId(g, GN_PENV)])), 0, kEnvs);
        c.audible = p[genId(g, GN_MUTE)] < 0.5F;
        c.sync = p[genId(g, GN_SYNC)] >= 0.5F;
        c.fixedHz = p[genId(g, GN_FIXED)] >= 0.5F;
        const float vl = p[genId(g, GN_VELLEV)];
        float gain = genGainOf(gv(g, GN_LEVEL)) * (1.0F - vl + vl * velShaped);
        if (c.method == M_OFF) gain = 0.0F;
        const float pan = gv(g, GN_PAN) * 2.0F - 1.0F;
        c.panL = std::cos((pan + 1.0F) * 0.78539816F); c.panR = std::sin((pan + 1.0F) * 0.78539816F);
        double semis = static_cast<double>(p[genId(g, GN_OCT)]) * 12.0 + static_cast<double>(p[genId(g, GN_SEMI)]) + static_cast<double>(gv(g, GN_FINE) - 0.5F) * 2.0;
        double pitchOnly = semis + static_cast<double>(pitchMod_[static_cast<std::size_t>(g)] + pitchMod_[kGens]) + static_cast<double>(vibSemis_);
        if (c.pEnv > 0) pitchOnly += static_cast<double>((p[genId(g, GN_PENVAMT)] - 0.5F) * 2.0F * rng::kPenvSemis * envNow_[static_cast<std::size_t>(c.pEnv - 1)]);
        const double ratio = static_cast<double>(mapLog(p[genId(g, GN_RATIO)], rng::kRatioLo, rng::kRatioHi));
        c.mul = ratio * std::pow(2.0, (pitchOnly + static_cast<double>(tuneCents_) / 100.0) / 12.0);
        c.fixedInc = static_cast<double>(mapLog(p[genId(g, GN_FIXHZ)], rng::kFixHzLo, rng::kFixHzHi)) / sr_ * std::pow(2.0, pitchOnly / 12.0);
        for (int i = 0; i < kGenFloats; ++i) c.f[i] = gv(g, GN_F0 + i);
        c.phase = gv(g, GN_PHASE);
        c.uniDet = gv(g, GN_UNIDET) * rng::kUniDetCents;
        c.uniSpread = p[genId(g, GN_UNISPR)];
        c.syncRatio = mapLin(p[genId(g, GN_SYNCR)], 1.0F, 8.0F);
        // the own filter: its cutoff follows the key and an envelope
        float fo = (p[genId(g, GN_FKEY)]) * static_cast<float>(keyNow_ - 60) / 12.0F;
        if (c.fEnv > 0) fo += (p[genId(g, GN_FENVAMT)] - 0.5F) * 2.0F * 6.0F * envNow_[static_cast<std::size_t>(c.fEnv - 1)];
        c.ownHz = clampf(mapLog(gv(g, GN_FCUT), rng::kCutLo, rng::kCutHi) * std::pow(2.0F, fo), 20.0F, 20000.0F);
        c.ownQ = qOf(gv(g, GN_FRES));
        // the ramps of the chunk
        const bool first = G.gainCur < 0.0F;
        const double newMul = c.fixedHz ? c.fixedInc : c.mul;
        if (first) { G.gainCur = gain; G.gainDlt = 0.0F; G.mulCur = newMul; G.mulDlt = 0.0; G.panLCur = c.panL; G.panRCur = c.panR; G.panLDlt = G.panRDlt = 0.0F; }
        else {
            G.gainDlt = (gain - G.gainCur) / static_cast<float>(kChunk);
            G.mulDlt = (newMul - G.mulCur) / static_cast<double>(kChunk);
            G.panLDlt = (c.panL - G.panLCur) / static_cast<float>(kChunk); G.panRDlt = (c.panR - G.panRCur) / static_cast<float>(kChunk);
        }
        // the choices that need a fade when they change
        const bool changed = c.method != G.aMethod || c.sel[0] != G.aSel[0] || c.sel[1] != G.aSel[1] || c.sel[2] != G.aSel[2] || c.sel[3] != G.aSel[3] || c.unison != G.aUni || c.ftype != G.aFtype;
        if (changed && !G.fadingOut) {
            G.fadingOut = true;
            GenCtl& h = hold_[static_cast<std::size_t>(g)];
            h = prevCtl;   // the old method goes on with the knobs it had until it is quiet
            h.method = G.aMethod; h.unison = G.aUni; h.ftype = G.aFtype;
            for (int s = 0; s < 4; ++s) h.sel[s] = G.aSel[s];
        }
        if (c.method != M_OFF) {
            if (c.ampEnv > 0) { lifeMask |= 1U << (c.ampEnv - 1); } 
        }
        // the mip level for the wave tables is chosen in prepareGen
        prepareGen(g, G.fadingOut ? hold_[static_cast<std::size_t>(g)] : c, inc);
    }
    // ---- links between the generators
    for (int d = 0; d < kGens; ++d) {
        int n = 0;
        for (int s = 0; s < kGens; ++s) {
            const int t = static_cast<int>(std::lround(p[linkType(d, s)]));
            const float a = clampf(p[linkAmt(d, s)], 0.0F, 1.0F);
            if (t <= 0 || t >= kLinkTypes || a <= 0.0F || ctl_[static_cast<std::size_t>(d)].method == M_OFF || ctl_[static_cast<std::size_t>(s)].method == M_OFF) continue;
            links_[static_cast<std::size_t>(d)][static_cast<std::size_t>(n++)] = Link{s, t, a};
        }
        nLinks_[static_cast<std::size_t>(d)] = n;
    }
    // ---- the shared filters
    series_ = p[G_FILTER_LINK] >= 0.5F;
    for (int f = 0; f < kFilters; ++f) {
        const auto F = static_cast<std::size_t>(f);
        const int type = std::clamp(static_cast<int>(std::lround(p[filterId(f, FL_TYPE)])), 0, kFilterTypes - 1);
        if (type != fltType_[F] && fltFadeDir_[F] == 0) fltFadeDir_[F] = -1;
        const int base = kDestFilterBase + f * 4;
        float oct = (p[filterId(f, FL_KEY)]) * static_cast<float>(keyNow_ - 60) / 12.0F + p[filterId(f, FL_VEL)] * 4.0F * velShaped;
        const int fe = std::clamp(static_cast<int>(std::lround(p[filterId(f, FL_ENV)])), 0, kEnvs);
        if (fe > 0) oct += (p[filterId(f, FL_ENVAMT)] - 0.5F) * 2.0F * rng::kFenvOct * envNow_[static_cast<std::size_t>(fe - 1)];
        const float cutT = clampf(p[filterId(f, FL_CUT)] + modAdd_[static_cast<std::size_t>(base)], 0.0F, 1.0F);
        const float hz = clampf(mapLog(cutT, rng::kCutLo, rng::kCutHi) * std::pow(2.0F, oct), 20.0F, 20000.0F);
        const float res = clampf(p[filterId(f, FL_RES)] + modAdd_[static_cast<std::size_t>(base + 1)], 0.0F, 1.0F);
        const float drv = clampf(p[filterId(f, FL_DRIVE)] + modAdd_[static_cast<std::size_t>(base + 2)], 0.0F, 1.0F);
        const float vow = clampf(p[filterId(f, FL_VOWEL)] + modAdd_[static_cast<std::size_t>(base + 3)], 0.0F, 1.0F);
        const int useType = fltFadeDir_[F] != 0 ? fltType_[F] : type;
        for (auto& ch : flt_[F]) ch.setup(useType, hz, res, drv, vow, p[filterId(f, FL_MORPH)], sr_);
    }
    // ---- the output stage
    {
        const float lv = clampf(p[G_LEVEL] + modAdd_[static_cast<std::size_t>(kDestGlobalBase)], 0.0F, 1.0F);
        const float g = std::pow(10.0F, mapLin(lv, rng::kLevelDbLo, rng::kLevelDbHi) / 20.0F);
        masterPrev_ = masterGain_ < 0.0F ? g : masterGain_;
        masterGain_ = g;
        width_ = clampf(p[G_WIDTH] + modAdd_[static_cast<std::size_t>(kDestGlobalBase + 3)], 0.0F, 1.0F) * 2.0F;
        drive_ = p[G_DRIVE];
    }
    // how long the sound may ring after the key: the longest release among the envelopes that keep the voice
    for (int e = 0; e < kEnvs; ++e) {
        if ((lifeMask & (1U << e)) == 0U) continue;
        const EnvCfg& c = envCfg_[static_cast<std::size_t>(e)];
        float r = c.rel;
        for (int i = std::min(c.sus + 1, kEnvPoints); i < kEnvPoints; ++i) r += c.t[i];
        lifeRelease = std::max(lifeRelease, r * timeScale(e));
    }
    releaseSec_ = lifeRelease;
    lifeMask_ = lifeMask;
}

void Voice::renderChunk(double inc) noexcept {
    inc = std::fabs(inc) > 1.0e-9 ? inc : 1.0e-9;
    updateControl(inc);
    lastInc_ = inc;
    const float gStep = 1.0F / static_cast<float>(kChunk);
    float pk = 0.0F;
    for (int i = 0; i < kChunk; ++i) {
        for (int e = 0; e < kEnvs; ++e) envNow_[static_cast<std::size_t>(e)] = env_[static_cast<std::size_t>(e)].tick(envCfg_[static_cast<std::size_t>(e)], sr_, timeScale(e));
        float dryL = 0.0F, dryR = 0.0F, aL = 0.0F, aR = 0.0F, bL = 0.0F, bR = 0.0F;
        for (int g = 0; g < kGens; ++g) {
            Gen& G = gen_[static_cast<std::size_t>(g)];
            const GenCtl& c = ctl_[static_cast<std::size_t>(g)];
            if (G.aMethod == M_OFF && !G.fadingOut && c.method == M_OFF) { modOut_[static_cast<std::size_t>(g)] = 0.0F; continue; }
            float side = 0.0F;
            float y = 0.0F;
            genSample(g, c, G, i, y, side);
            // level, envelope and the fade of a switch
            float env = 1.0F;
            if (c.ampEnv > 0) env = envNow_[static_cast<std::size_t>(c.ampEnv - 1)];
            G.gainCur += G.gainDlt; G.panLCur += G.panLDlt; G.panRCur += G.panRDlt;
            const float k = G.gainCur * env * G.fade;
            const float m = y * k, s = side * k;
            modOut_[static_cast<std::size_t>(g)] = m;
            if (!c.audible) continue;
            const float l = m * G.panLCur + s, r = m * G.panRCur - s;
            switch (c.route) {
                case R_DRY: dryL += l; dryR += r; break;
                case R_A: aL += l; aR += r; break;
                case R_B: bL += l; bR += r; break;
                default: aL += l * 0.7071F; aR += r * 0.7071F; bL += l * 0.7071F; bR += r * 0.7071F; break;
            }
        }
        // the shared filters (a change of type fades the filter out and in)
        float outL = dryL, outR = dryR;
        float fL[kFilters], fR[kFilters];
        const float inL[kFilters] = {aL, bL}, inR[kFilters] = {aR, bR};
        for (int f = 0; f < kFilters; ++f) {
            const auto F = static_cast<std::size_t>(f);
            float xl = inL[f], xr = inR[f];
            if (series_ && f == 1) { xl += fL[0]; xr += fR[0]; }
            fL[f] = flt_[F][0].run(xl); fR[f] = flt_[F][1].run(xr);
            if (fltFadeDir_[F] != 0) {
                fltFade_[F] += static_cast<float>(fltFadeDir_[F]) * static_cast<float>(1.0 / (0.003 * sr_));
                if (fltFadeDir_[F] < 0 && fltFade_[F] <= 0.0F) {
                    fltFade_[F] = 0.0F; fltFadeDir_[F] = 1;
                    fltType_[F] = std::clamp(static_cast<int>(std::lround(p_[filterId(f, FL_TYPE)])), 0, kFilterTypes - 1);
                    flt_[F][0].reset(); flt_[F][1].reset();
                } else if (fltFadeDir_[F] > 0 && fltFade_[F] >= 1.0F) { fltFade_[F] = 1.0F; fltFadeDir_[F] = 0; }
                fL[f] *= fltFade_[F]; fR[f] *= fltFade_[F];
            }
        }
        if (series_) { outL += fL[1]; outR += fR[1]; if (fltType_[1] == FT_OFF) { outL += fL[0]; outR += fR[0]; } }
        else { outL += fL[0] + fL[1]; outR += fR[0] + fR[1]; }
        // master: level, width, drive, tremolo, soft limit
        const float mg = masterPrev_ + (masterGain_ - masterPrev_) * static_cast<float>(i + 1) * gStep;
        const float tg = tremGainPrev_ + (tremGain_ - tremGainPrev_) * static_cast<float>(i + 1) * gStep;
        float mid = 0.5F * (outL + outR), sd = 0.5F * (outL - outR) * width_;
        float l = (mid + sd) * mg * tg, r = (mid - sd) * mg * tg;
        if (drive_ > 0.0F) { const float dk = 1.0F + 5.0F * drive_; l = tanhF(l * dk) / tanhF(dk * 0.7F) * 0.7F; r = tanhF(r * dk) / tanhF(dk * 0.7F) * 0.7F; }
        l = soft(l); r = soft(r);
        if (killing_) { killGain_ *= static_cast<float>(std::exp(-1.0 / (0.004 * sr_))); l *= killGain_; r *= killGain_; }
        bufL_[i] = l; bufR_[i] = r;
        pk = std::max(pk, std::max(std::fabs(l), std::fabs(r)));
    }
    // the guard: a NaN or an Inf anywhere starts the voice from silence
    float chk = 0.0F;
    for (int i = 0; i < kChunk; ++i) chk += bufL_[i] + bufR_[i];
    if (!std::isfinite(chk)) {
        for (int i = 0; i < kChunk; ++i) bufL_[i] = bufR_[i] = 0.0F;
        for (int g = 0; g < kGens; ++g) resetGen(g);
        for (auto& f : flt_) for (auto& c : f) c.reset();
        modOut_.fill(0.0F);
        pk = 0.0F;
    }
    peak_ = std::max(pk, peak_ * 0.98F);
    // finished: released and the envelopes that keep the voice are over
    if (!in_.gate) {
        bool alive = false;
        for (int e = 0; e < kEnvs; ++e) if ((lifeMask_ & (1U << e)) != 0U && !env_[static_cast<std::size_t>(e)].done()) alive = true;
        if (!alive) finished_ = true;
    }
    if (killing_ && killGain_ < 1.0e-4F) finished_ = true;
}

} // namespace silveton::sampler::suse
