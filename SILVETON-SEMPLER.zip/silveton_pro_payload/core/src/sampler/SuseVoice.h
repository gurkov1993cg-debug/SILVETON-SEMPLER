#pragma once
// SILVETON_SUSE_V1 - one voice of SILVETON SYNTH (see SuseDsp.h for the rules and the tools it is made of).
#include "SuseDsp.h"

namespace silveton::sampler::suse {

// What the voice needs to know about the player, once per audio block.
struct Inputs {
    float velocity{1.0F};          // 0..1
    int key{60};
    bool gate{true};               // the key is held, or the sustain pedal holds it
    float breath{1.0F}, expression{1.0F}, wheel{0.0F}, pressure{0.0F}, polyPressure{0.0F}, bend{0.0F};   // bend -1..1
    const float* cc{nullptr};      // 128 controller values 0..1 (may be null)
    float random{0.0F};            // -1..1, one number per note
};

// The drawn waves of one place, made into band-limited tables (built when the points change) and the user's file waves.
struct Shared {
    std::array<std::array<float, kLevels * kTabStride>, kDrawnWaves> drawn{};
    std::array<std::uint32_t, kDrawnWaves> hash{};
    const UserWaveTables* files{nullptr};
    bool ready{false};
    void update(const float* p) noexcept {
        for (int w = 0; w < kDrawnWaves; ++w) {
            const std::uint32_t h = hashPoints(p + drawId(w, 0), kDrawLen);
            if (ready && h == hash[static_cast<std::size_t>(w)]) continue;
            float pts[kDrawLen];
            for (int i = 0; i < kDrawLen; ++i) pts[i] = (clampf(p[drawId(w, i)], 0.0F, 1.0F) - 0.5F) * 2.0F;
            buildDrawnTables(pts, drawn[static_cast<std::size_t>(w)].data());
            hash[static_cast<std::size_t>(w)] = h;
        }
        ready = true;
    }
};

class Voice {
public:
    // ---------------------------------------------------------------- the life of a note
    void noteOn(const float* params, double sampleRate, const Inputs& in, std::uint32_t seed, const Shared* shared) noexcept;
    void setParams(const float* params) noexcept { p_ = params; }
    void setInputs(const Inputs& in, double sampleRate) noexcept;          // once per audio block (also handles key off and legato)
    // One sample; inc = cycles per sample of the key (glide, bend ... included). extL / extR = the recording of this note at this sample
    // (SILVETON_SUSE_SAMPLE_V1: what a СЕМПЪЛ generator sounds; 0 on an engine place). The voice works in chunks of kChunk samples, so the
    // sound comes out kChunk samples (a third of a millisecond) after its input went in - the same for every generator of the voice.
    void tick(double inc, float extL, float extR, float& l, float& r) noexcept;
    void tick(double inc, float& l, float& r) noexcept { tick(inc, 0.0F, 0.0F, l, r); }
    [[nodiscard]] bool finished() const noexcept { return finished_; }
    [[nodiscard]] float releaseSeconds() const noexcept { return releaseSec_; }   // the longest release of the envelopes that shape the sound
    [[nodiscard]] bool gateOn() const noexcept { return in_.gate; }
    [[nodiscard]] float lastPeak() const noexcept { return peak_; }
    void panicFade() noexcept { killing_ = true; }

private:
    struct Link { int src; int type; float amt; };
    struct GenCtl {
        int method{0}; bool audible{false}; int route{1}, ftype{0}; int sel[4]{0, 0, 0, 0}; int unison{1};
        int ampEnv{0}, fEnv{0}, pEnv{0};
        float gain{0.0F}, panL{0.7F}, panR{0.7F};
        double mul{1.0};
        bool fixedHz{false}; double fixedInc{0.0};
        float f[kGenFloats]{};
        float phase{0.0F};
        float uniDet{0.0F}, uniSpread{0.0F}, syncRatio{1.0F};
        bool sync{false};
        float ownHz{1000.0F}, ownQ{1.0F};
        int level{0};   // the mip level of the wave A / B tables
    };
    struct Gen {
        int aMethod{0}, aSel[4]{0, 0, 0, 0}, aUni{1}, aFtype{0};
        float fade{0.0F};
        bool fadingOut{false}, started{false};
        double mulCur{1.0}, mulDlt{0.0};
        float gainCur{0.0F}, gainDlt{0.0F}, panLCur{0.7F}, panLDlt{0.0F}, panRCur{0.7F}, panRDlt{0.0F};
        double incNow{0.0};
        double pitchPh{0.0};
        bool wrapped{false};
        // WAVE
        double ph[4]{0.0, 0.0, 0.0, 0.0}, phSub{0.0}, phSync{0.0};
        float lastY{0.0F}, dcX{0.0F}, dcY{0.0F}, tiltLp{0.0F};
        // the own filter (mid and side)
        Svf own, ownS;
        // per-chunk constants of the method and its tables
        float k[16]{};
        double kd[4]{};
        const float* tabA{nullptr};
        const float* tabB{nullptr};
        int ownType{0};
        float holdMag{0.0F};
        // ADDITIVE (the partial state lives in mem)
        int addN{0};
        float addNorm{1.0F};
        // STRING
        int wN{0}, wB{0};
        float lpZ{0.0F}, apZ[2]{0.0F, 0.0F}, apY[2]{0.0F, 0.0F}, nlEnv{0.0F}, bodyA[2]{0.0F, 0.0F}, bodyB[2]{0.0F, 0.0F};
        int excLeft{0}, excTotal{0};
        float excLp{0.0F}, bowVel{0.0F}, bowSmooth{0.0F}, strDamp{1.0F};
        // WIND
        int wW{0}, wJ{0};
        float pm{0.0F}, dcA{0.0F}, dcB{0.0F}, windLp{0.0F}, windLp2{0.0F}, windOut{0.0F}, vibPh{0.0F}, growlPh{0.0F}, jetLp{0.0F}, bellZ{0.0F};
        Svf lip, bell;
        float hpX{0.0F}, hpY{0.0F};
        int bellSet{0};
        float regSm{0.0F};
        // MODAL
        float strikeLeft{0.0F}; int strikeN{0}; float strikeTotal{1.0F};
        int modalCount{0};
        // NOISE
        std::uint32_t rng{12345U};
        float pink[3]{0.0F, 0.0F, 0.0F}, brown{0.0F}, nzHold{0.0F}, nzPrev{0.0F}, nzLp{0.0F};
        int nzCount{0};
        Svf band;
        // GRANULAR
        int gW{0};
        double gTimer{0.0};
        struct Grain { bool on{false}; double pos{0.0}; double inc{1.0}; int age{0}, len{1}; float pan{0.5F}; };
        Grain grains[24];
        // SPECTRAL
        int sW{0}, sHop{0}, sRead{0};
        std::uint32_t sRng{1U};
        float sPhase0{0.0F};
        // SAMPLE (SILVETON_SUSE_SAMPLE_V1): the moving delay lives in mem (left half L, right half R)
        int smpW{0};
        float smpLp[2]{0.0F, 0.0F}, smpDcX[2]{0.0F, 0.0F}, smpDcY[2]{0.0F, 0.0F};
    };

    void resetGen(int g) noexcept;
    void applyChoices(int g, const GenCtl& c) noexcept;
    void updateControl(double inc) noexcept;
    void renderChunk(double inc) noexcept;
    void genSample(int g, const GenCtl& c, Gen& G, int i, float& outRaw, float& outSide) noexcept;
    float waveSample(Gen& G, const GenCtl& c, double pmCycles, float fm, float warp, bool syncHit, float& side) noexcept;
    float addSample(Gen& G, const GenCtl& c) noexcept;
    float stringSample(int g, Gen& G, const GenCtl& c) noexcept;
    float windSample(Gen& G, const GenCtl& c) noexcept;
    float modalSample(int g, Gen& G, const GenCtl& c) noexcept;
    float noiseSample(Gen& G, const GenCtl& c) noexcept;
    float grainSample(int g, Gen& G, const GenCtl& c, float& side) noexcept;
    float spectralSample(int g, Gen& G, const GenCtl& c) noexcept;
    float sampleSample(int g, Gen& G, const GenCtl& c, double pmCycles, int i, float& side) noexcept;   // SILVETON_SUSE_SAMPLE_V1
    void prepareGen(int g, GenCtl& c, double inc) noexcept;
    void switchChoices(int g, const GenCtl& c) noexcept;
    void prepareString(Gen& G, const GenCtl& c) noexcept;
    void prepareWind(Gen& G, const GenCtl& c) noexcept;
    void prepareModal(Gen& G, const GenCtl& c) noexcept;
    void prepareAdd(Gen& G, const GenCtl& c) noexcept;
    const float* tableFor(int wave, int level) const noexcept;
    void startEnvelopes() noexcept;
    float timeScale(int e) const noexcept;
    void cookEnvelope(int e) noexcept;

    const float* p_{nullptr};
    const Shared* shared_{nullptr};
    double sr_{48000.0};
    Inputs in_{};
    bool finished_{false}, killing_{false}, started_{false};
    float killGain_{1.0F};
    int pos_{0};
    float bufL_[kChunk]{}, bufR_[kChunk]{};
    float inL_[kChunk]{}, inR_[kChunk]{};   // SILVETON_SUSE_SAMPLE_V1: the recording of the chunk being gathered
    float releaseSec_{0.3F};
    float peak_{0.0F};
    double lastInc_{0.0};
    std::uint32_t rng_{1U};
    int keyNow_{60};
    // modulation
    std::array<EnvCfg, kEnvs> envCfg_{};
    std::array<EnvState, kEnvs> env_{};
    std::array<float, kEnvs> envNow_{};
    std::array<LfoState, kLfos> lfo_{};
    StepState step_{};
    std::array<float, kModSources> src_{};
    std::array<float, kDestCount> modAdd_{};
    std::array<float, kGens + 1> pitchMod_{};
    std::array<GenCtl, kGens> ctl_{};
    // the player turns an own knob of a string / a struck body while the key is down: it is struck again when the knob rests
    std::array<std::array<float, kGenFloats>, kGens> knobSeen_{};
    std::array<float, kGens> reStrike_{};
    bool knobSeenValid_{false};
    std::array<GenCtl, kGens> hold_{};   // the settings an old method keeps while it fades out (a switch must not change the sound before it ends)
    std::array<Gen, kGens> gen_{};
    std::array<std::array<Link, kGens>, kGens> links_{};
    std::array<int, kGens> nLinks_{};
    std::array<float, kGens> raw_{}, modOut_{};
    // vibrato / tremolo
    double vibPh_{0.0}, tremPh_{0.0};
    float vibAge_{0.0F};
    float vibSemis_{0.0F}, tremGain_{1.0F}, tremGainPrev_{1.0F};
    // output stage
    std::array<std::array<ShFilter, 2>, kFilters> flt_{};
    std::array<int, kFilters> fltType_{};
    std::array<float, kFilters> fltFade_{};
    std::array<int, kFilters> fltFadeDir_{};
    float masterGain_{1.0F}, masterPrev_{1.0F}, width_{1.0F}, drive_{0.0F};
    bool series_{false};
    float tuneCents_{0.0F};
    unsigned lifeMask_{1U};
    std::array<std::array<float, kMemSize>, kGens> mem_{};
};

} // namespace silveton::sampler::suse
