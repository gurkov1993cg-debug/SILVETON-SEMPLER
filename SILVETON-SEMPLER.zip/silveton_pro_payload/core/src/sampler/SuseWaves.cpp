// SILVETON_SUSE_V1 - the 64 calculated waves (see SuseWaves.h). Every wave is a formula of the phase 0..1; the formula is
// sampled 16384 times, turned into its harmonics by an FFT (so edges and corners are exact), and each level keeps only the
// harmonics it may have. Nothing here is a recording.
#include "SuseWaves.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <mutex>

namespace silveton::sampler::suse {

namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr int kFftN = 16384;

const char* const kWaveNames[kWaveChoices] = {
    "SINE", "TRIANGLE", "SAW", "REVERSE SAW", "SQUARE", "PULSE 25", "PULSE 12", "TRAPEZOID",
    "PARABOLIC", "EXP RISE", "EXP FALL", "HALF SINE", "RECT SINE", "CLIPPED SINE", "FOLDED SINE", "DOUBLE SAW",
    "DOUBLE PULSE", "GAUSS PULSE", "SINE CUBED", "ROUND SQUARE", "TANH SINE", "TANH TRI", "SAW SQUARED", "SAW CUBED",
    "ODD HARM", "EVEN HARM", "PRIME HARM", "FIBONACCI", "SQUARE NUMS", "OCTAVES", "RISING SPEC", "FORMANT A",
    "FORMANT I", "FORMANT O", "FORMANT E", "CZ RES SAW", "CZ RES TRI", "CZ RES TRAP", "CZ DBL SINE", "CZ SAW PULSE",
    "SINC PULSE", "LORENTZ PULSE", "SECH PULSE", "COSINE POW", "STAIRS 4", "STAIRS TRI 8", "FM 1:1", "PM 1:2",
    "FM 1:3", "RING 2x3", "AM 1:5", "CHEBY T5", "FOLDED TRI", "FOLDED SAW", "RANDOM STEPS", "RANDOM SMOOTH",
    "SKEW SINE", "SPIKES", "SOFT SQUARE", "SINE 1+2", "SINE 1+3", "HARMONIC 1-4", "COMB SAW", "NOISE HARM",
    "DRAW 1", "DRAW 2", "DRAW 3", "DRAW 4",
    "USER 1", "USER 2", "USER 3", "USER 4", "USER 5", "USER 6", "USER 7", "USER 8",
    "USER 9", "USER 10", "USER 11", "USER 12", "USER 13", "USER 14", "USER 15", "USER 16"};

// the seeded waves: made once, read-only afterwards
struct Seeded {
    std::array<double, 16> steps{};
    std::array<double, 8> smooth{};
    std::array<double, 25> amp{};
    std::array<double, 25> phase{};
    Seeded() {
        std::uint32_t s = 1U;
        for (auto& v : steps) v = static_cast<double>(lcgf(s));
        s = 7U;
        for (auto& v : smooth) v = static_cast<double>(lcgf(s));
        s = 99U;
        for (std::size_t i = 1; i < amp.size(); ++i) {
            amp[i] = (0.3 + 0.7 * std::fabs(static_cast<double>(lcgf(s)))) / std::sqrt(static_cast<double>(i));
            phase[i] = static_cast<double>(lcgf(s)) * kPi;
        }
    }
};
const Seeded& seeded() { static const Seeded s; return s; }

double tri(double ph) { return ph < 0.25 ? 4.0 * ph : (ph < 0.75 ? 2.0 - 4.0 * ph : 4.0 * ph - 4.0); }
double fold(double v) { return std::asin(std::sin(v * kPi * 0.5)) * 2.0 / kPi; }
double sgn(double v) { return v < 0.0 ? -1.0 : 1.0; }
double smoothstep(double t) { t = std::clamp(t, 0.0, 1.0); return t * t * (3.0 - 2.0 * t); }

// the formula of wave w at the phase ph (0..1). Any DC and level is removed afterwards.
double waveFn(int w, double ph) {
    const double x = 2.0 * kPi * ph;
    switch (w) {
        case 0: return std::sin(x);
        case 1: return tri(ph);
        case 2: return 2.0 * ph - 1.0;
        case 3: return 1.0 - 2.0 * ph;
        case 4: return ph < 0.5 ? 1.0 : -1.0;
        case 5: return ph < 0.25 ? 1.0 : -1.0;
        case 6: return ph < 0.125 ? 1.0 : -1.0;
        case 7:
            if (ph < 0.2) return -1.0 + 2.0 * ph / 0.2;
            if (ph < 0.5) return 1.0;
            if (ph < 0.7) return 1.0 - 2.0 * (ph - 0.5) / 0.2;
            return -1.0;
        case 8: return (2.0 * ph - 1.0) * (2.0 * ph - 1.0);
        case 9: return std::exp(4.0 * ph);
        case 10: return std::exp(-4.0 * ph);
        case 11: return std::max(std::sin(x), 0.0);
        case 12: return std::fabs(std::sin(x)) * (ph < 0.5 ? 1.0 : 0.6);
        case 13: return std::clamp(1.6 * std::sin(x), -1.0, 1.0);
        case 14: return fold(2.2 * std::sin(x));
        case 15: { const double r = 2.0 * (2.0 * ph - std::floor(2.0 * ph)) - 1.0; return ph < 0.5 ? r : 0.5 * r; }
        case 16: return (ph < 0.1 ? 1.0 : 0.0) + ((ph >= 0.5 && ph < 0.7) ? 1.0 : 0.0);
        case 17: { const double d = (ph - 0.5) / 0.08; return std::exp(-d * d); }
        case 18: { const double s = std::sin(x); return s * s * s; }
        case 19: { const double s = std::sin(x); return sgn(s) * std::pow(std::fabs(s), 0.4); }
        case 20: return std::tanh(3.0 * std::sin(x));
        case 21: return std::tanh(3.0 * tri(ph));
        case 22: { const double s = 2.0 * ph - 1.0; return sgn(s) * s * s; }
        case 23: { const double s = 2.0 * ph - 1.0; return s * s * s; }
        case 24: { double s = 0.0; for (int n = 1; n <= 15; n += 2) s += std::sin(n * x) / std::sqrt(static_cast<double>(n)); return s; }
        case 25: { double s = 0.5 * std::sin(x); for (int n = 2; n <= 16; n += 2) s += std::sin(n * x) / n; return s; }
        case 26: { static constexpr int pr[] = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23}; double s = 0.0; for (int n : pr) s += std::sin(n * x) / n; return s; }
        case 27: { static constexpr int fb[] = {1, 2, 3, 5, 8, 13, 21, 34, 55, 89}; double s = 0.0; for (int n : fb) s += std::sin(n * x) / std::sqrt(static_cast<double>(n)); return s; }
        case 28: { double s = 0.0; for (int k = 1; k <= 9; ++k) s += std::sin(k * k * x) / static_cast<double>(k); return s; }
        case 29: { double s = 0.0; for (int n = 1; n <= 64; n *= 2) s += std::sin(n * x); return s; }
        case 30: { double s = 0.0; for (int n = 1; n <= 12; ++n) s += std::sin(n * x) * std::sqrt(static_cast<double>(n)); return s; }
        case 31: return std::sin(x * 8.0) * std::exp(-5.0 * ph);
        case 32: return std::sin(x * 16.0) * std::exp(-7.0 * ph);
        case 33: return std::sin(x * 4.0) * std::exp(-4.0 * ph);
        case 34: return std::sin(x * 11.0) * std::exp(-6.0 * ph);
        case 35: return std::sin(x * 6.0) * (1.0 - ph);
        case 36: return (std::sin(x * 6.0) + 0.35 * std::sin(x)) * (1.0 - std::fabs(2.0 * ph - 1.0));
        case 37: return (std::sin(x * 6.0) + 0.35 * std::sin(x)) * std::min(1.0, 3.0 * (1.0 - std::fabs(2.0 * ph - 1.0)));
        case 38: return ph < 0.5 ? std::sin(2.0 * x) : 0.0;
        case 39: return ph < 0.5 ? 4.0 * ph - 1.0 : -1.0;
        case 40: { const double a = 10.0 * kPi * (ph - 0.5); return std::fabs(a) < 1.0e-9 ? 1.0 : std::sin(a) / a; }
        case 41: { const double d = 12.0 * (ph - 0.5); return 1.0 / (1.0 + d * d); }
        case 42: return 1.0 / std::cosh(10.0 * (ph - 0.5));
        case 43: { const double c = 0.5 * (1.0 + std::cos(x)); return c * c * c * c; }
        case 44: return std::floor(4.0 * ph) / 3.0 * 2.0 - 1.0;
        case 45: return std::round(tri(ph) * 3.5) / 3.5;
        case 46: return std::sin(x + 2.0 * std::sin(x));
        case 47: return std::sin(x + 3.0 * std::sin(2.0 * x));
        case 48: return std::sin(x + 1.5 * std::sin(3.0 * x));
        case 49: return std::sin(2.0 * x) * std::sin(3.0 * x);
        case 50: return std::sin(x) * (1.0 + 0.8 * std::sin(5.0 * x));
        case 51: { const double t = tri(ph); return 16.0 * std::pow(t, 5) - 20.0 * t * t * t + 5.0 * t; }
        case 52: return fold(3.4 * tri(ph));
        case 53: return fold(2.5 * (2.0 * ph - 1.0));
        case 54: return seeded().steps[static_cast<std::size_t>(std::min(15, static_cast<int>(ph * 16.0)))];
        case 55: {
            const double f = ph * 8.0; const int i = static_cast<int>(f); const double t = f - i;
            const auto& s = seeded().smooth;
            const double y0 = s[static_cast<std::size_t>((i + 7) & 7)], y1 = s[static_cast<std::size_t>(i & 7)], y2 = s[static_cast<std::size_t>((i + 1) & 7)], y3 = s[static_cast<std::size_t>((i + 2) & 7)];
            return y1 + 0.5 * t * (y2 - y0 + t * (2.0 * y0 - 5.0 * y1 + 4.0 * y2 - y3 + t * (3.0 * (y1 - y2) + y3 - y0)));
        }
        case 56: { const double pw = 0.2; const double q = ph < pw ? ph / (2.0 * pw) : 0.5 + (ph - pw) / (2.0 * (1.0 - pw)); return std::sin(2.0 * kPi * q); }
        case 57: {
            const double d1 = std::min(ph, 1.0 - ph), d2 = std::fabs(ph - 0.5);
            return std::max(0.0, 1.0 - d1 / 0.06) - std::max(0.0, 1.0 - d2 / 0.06);
        }
        case 58:
            if (ph < 0.1) return smoothstep(ph / 0.1) * 2.0 - 1.0;
            if (ph < 0.5) return 1.0;
            if (ph < 0.6) return 1.0 - 2.0 * smoothstep((ph - 0.5) / 0.1);
            return -1.0;
        case 59: return std::sin(x) + 0.5 * std::sin(2.0 * x + 0.5 * kPi);
        case 60: return std::sin(x) + 0.5 * std::sin(3.0 * x);
        case 61: return std::sin(x) + std::sin(2.0 * x) + std::sin(3.0 * x) + std::sin(4.0 * x);
        case 62: { double s = 0.0; for (int n = 1; n <= 40; ++n) if (n % 3 != 0) s += std::sin(n * x) / n; return s; }
        case 63: { const auto& sd = seeded(); double s = 0.0; for (std::size_t n = 1; n <= 24; ++n) s += sd.amp[n] * std::sin(static_cast<double>(n) * x + sd.phase[n]); return s; }
        default: return 0.0;
    }
}

// in-place complex FFT (n a power of two)
void fft(double* re, double* im, int n, bool inverse) {
    for (int i = 1, j = 0; i < n; ++i) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
    }
    for (int len = 2; len <= n; len <<= 1) {
        const double ang = 2.0 * kPi / len * (inverse ? 1.0 : -1.0);
        const double wr = std::cos(ang), wi = std::sin(ang);
        for (int i = 0; i < n; i += len) {
            double cr = 1.0, ci = 0.0;
            for (int k = 0; k < len / 2; ++k) {
                const int a = i + k, b = i + k + len / 2;
                const double tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
                re[b] = re[a] - tr; im[b] = im[a] - ti;
                re[a] += tr; im[a] += ti;
                const double nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
            }
        }
    }
}

// gentle taper over the top quarter of a level's harmonics (less ringing at the edges of the wave)
double taper(int h, int top) {
    const double from = 0.75 * top;
    if (h <= from) return 1.0;
    return 0.5 * (1.0 + std::cos(kPi * (h - from) / (top - from + 1.0)));
}

// the levels of one wave from its harmonic coefficients a[h] (cos) and b[h] (sin), h = 1..maxH
void makeLevels(const double* a, const double* b, int maxH, float* dst, double scale) {
    std::vector<double> re(kTab), im(kTab);
    for (int lvl = 0; lvl < kLevels; ++lvl) {
        const int top = std::min(levelHarmonics(lvl), maxH);
        std::fill(re.begin(), re.end(), 0.0); std::fill(im.begin(), im.end(), 0.0);
        for (int h = 1; h <= top; ++h) {
            const double t = taper(h, levelHarmonics(lvl));
            re[static_cast<std::size_t>(h)] = 0.5 * a[h] * t; im[static_cast<std::size_t>(h)] = -0.5 * b[h] * t;
            re[static_cast<std::size_t>(kTab - h)] = re[static_cast<std::size_t>(h)]; im[static_cast<std::size_t>(kTab - h)] = -im[static_cast<std::size_t>(h)];
        }
        fft(re.data(), im.data(), kTab, true);
        float* t = dst + static_cast<std::size_t>(lvl) * kTabStride;
        for (int i = 0; i < kTab; ++i) t[i] = static_cast<float>(re[static_cast<std::size_t>(i)] * scale);
        t[kTab] = t[0];
    }
}

MathTables build() {
    MathTables m;
    m.t.assign(static_cast<std::size_t>(kMathWaves) * kLevels * kTabStride, 0.0F);
    std::vector<double> re(kFftN), im(kFftN);
    std::array<double, kTab / 2 + 1> a{}, b{};
    for (int w = 0; w < kMathWaves; ++w) {
        for (int i = 0; i < kFftN; ++i) { re[static_cast<std::size_t>(i)] = waveFn(w, static_cast<double>(i) / kFftN); im[static_cast<std::size_t>(i)] = 0.0; }
        fft(re.data(), im.data(), kFftN, false);
        for (int h = 1; h <= kTab / 2 - 1; ++h) {
            a[static_cast<std::size_t>(h)] = 2.0 * re[static_cast<std::size_t>(h)] / kFftN;
            b[static_cast<std::size_t>(h)] = -2.0 * im[static_cast<std::size_t>(h)] / kFftN;
        }
        // the level with all harmonics decides the scale: its highest point becomes 1
        float* dst = m.t.data() + static_cast<std::size_t>(w) * kLevels * kTabStride;
        makeLevels(a.data(), b.data(), kTab / 2 - 1, dst, 1.0);
        double peak = 1.0e-9;
        for (int i = 0; i < kTab; ++i) peak = std::max(peak, static_cast<double>(std::fabs(dst[i])));
        makeLevels(a.data(), b.data(), kTab / 2 - 1, dst, 1.0 / peak);
    }
    return m;
}

} // namespace

int levelHarmonics(int level) noexcept {
    return std::max(1, static_cast<int>(std::floor(512.0 / std::pow(2.0, 0.5 * std::clamp(level, 0, kLevels - 1)))));
}

int levelFor(double inc) noexcept {
    const double maxH = 0.46 / std::max(inc, 1.0e-9);
    for (int l = 0; l < kLevels; ++l) if (static_cast<double>(levelHarmonics(l)) <= maxH) return l;
    return kLevels - 1;
}

const MathTables& mathTables() {
    static const MathTables t = build();
    return t;
}

void buildDrawnTables(const float* points, float* dst) noexcept {
    // the 64 points -> harmonics 1..31 (the discrete Fourier transform of one cycle)
    std::array<double, 33> a{}, b{};
    for (int h = 1; h <= 31; ++h) {
        double ca = 0.0, cb = 0.0;
        for (int i = 0; i < kDrawLen; ++i) {
            const double th = 2.0 * kPi * h * i / kDrawLen;
            const double v = static_cast<double>(points[i]);
            ca += v * std::cos(th); cb += v * std::sin(th);
        }
        a[static_cast<std::size_t>(h)] = 2.0 * ca / kDrawLen; b[static_cast<std::size_t>(h)] = 2.0 * cb / kDrawLen;
    }
    // the sine table for the synthesis (made on first use; the same for every wave)
    static const std::array<float, kTab> sine = [] { std::array<float, kTab> s{}; for (int i = 0; i < kTab; ++i) s[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(2.0 * kPi * i / kTab)); return s; }();
    int builtTop = -1;
    for (int lvl = 0; lvl < kLevels; ++lvl) {
        float* t = dst + static_cast<std::size_t>(lvl) * kTabStride;
        const int top = std::min(31, levelHarmonics(lvl));
        if (top == builtTop && lvl > 0) {   // the same harmonics as the level before: copy
            const float* prev = dst + static_cast<std::size_t>(lvl - 1) * kTabStride;
            std::copy(prev, prev + kTabStride, t);
            continue;
        }
        builtTop = top;
        for (int i = 0; i < kTab; ++i) t[i] = 0.0F;
        for (int h = 1; h <= top; ++h) {
            const float ta = static_cast<float>(a[static_cast<std::size_t>(h)] * taper(h, std::max(top, 4))), tb = static_cast<float>(b[static_cast<std::size_t>(h)] * taper(h, std::max(top, 4)));
            for (int i = 0; i < kTab; ++i) {
                const int ix = (h * i) & (kTab - 1);
                t[i] += ta * sine[static_cast<std::size_t>((ix + kTab / 4) & (kTab - 1))] + tb * sine[static_cast<std::size_t>(ix)];
            }
        }
        t[kTab] = t[0];
    }
}

std::uint32_t hashPoints(const float* points, int n) noexcept {
    std::uint32_t h = 2166136261U;
    for (int i = 0; i < n; ++i) {
        const float v = points[i];
        std::uint32_t u;
        static_assert(sizeof(u) == sizeof(v), "float is 32 bits");
        __builtin_memcpy(&u, &v, sizeof(u));
        h = (h ^ u) * 16777619U;
    }
    return h;
}

const char* waveName(int w) noexcept {
    return kWaveNames[std::clamp(w, 0, kWaveChoices - 1)];
}

void waveCycle(int w, float* out, int n) noexcept {
    const float* t = mathTables().table(std::clamp(w, 0, kMathWaves - 1), 0);
    for (int i = 0; i < n; ++i) {
        const double x = static_cast<double>(i) * kTab / static_cast<double>(n);
        const int i0 = static_cast<int>(x);
        const float f = static_cast<float>(x - i0);
        out[i] = t[i0] + (t[i0 + 1] - t[i0]) * f;
    }
}

} // namespace silveton::sampler::suse
