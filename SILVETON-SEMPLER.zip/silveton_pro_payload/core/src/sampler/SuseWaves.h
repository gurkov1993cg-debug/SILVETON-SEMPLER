#pragma once
// SILVETON_SUSE_V1 - the calculated waves of SILVETON SYNTH: 64 different waves, each made from a formula (never from a recording),
// as band-limited tables: kLevels versions of each wave, with fewer and fewer harmonics (half an octave apart), so a high note
// reads a table that has nothing above half the sample rate (no aliasing from the oscillator itself).
#include "silveton/sampler/SuseDefs.h"

#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton::sampler::suse {

constexpr int kTab = 1024;               // points of one cycle
constexpr int kTabStride = kTab + 1;     // + one guard point (= the first), for the interpolation
constexpr int kLevels = 19;              // half an octave apart: 512, 362, 256 ... 1 harmonics

// the highest harmonic of a level (512 >> level/2)
[[nodiscard]] int levelHarmonics(int level) noexcept;
// the level for a note that advances `inc` cycles per sample (the smallest one that has no harmonic above 0.46 of the sample rate)
[[nodiscard]] int levelFor(double inc) noexcept;

struct MathTables {
    std::vector<float> t;   // [wave][level][kTabStride]
    [[nodiscard]] const float* table(int wave, int level) const noexcept {
        return t.data() + (static_cast<std::size_t>(wave) * kLevels + static_cast<std::size_t>(level)) * kTabStride;
    }
};
// built once (the first call, on the control thread: SamplerEngine's constructor and the tests call it), only read afterwards
[[nodiscard]] const MathTables& mathTables();

// A drawn wave (kDrawLen points -1..1) made into its kLevels tables: `dst` holds kLevels * kTabStride floats. No allocation.
// The points are read as one cycle and kept band-limited to 31 harmonics (what 64 points can hold).
void buildDrawnTables(const float* points, float* dst) noexcept;
[[nodiscard]] std::uint32_t hashPoints(const float* points, int n) noexcept;

// A pure, deterministic number generator for the seeded waves and the noise of the generators (no global state).
inline std::uint32_t lcg(std::uint32_t& s) noexcept { s = s * 1664525U + 1013904223U; return s; }
inline float lcgf(std::uint32_t& s) noexcept { return static_cast<float>(static_cast<std::int32_t>(lcg(s))) * (1.0F / 2147483648.0F); }

} // namespace silveton::sampler::suse
