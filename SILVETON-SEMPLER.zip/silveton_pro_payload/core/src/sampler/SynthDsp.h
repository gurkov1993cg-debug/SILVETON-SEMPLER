#pragma once
// SILVETON_SYNTH_CLEAN_V1 (Цветомир, 03.11.2026: "искам максимално качество на звука без гадни честоти")
//
// Two pieces that keep SILVETON SYNTH free of frequencies that are not part of the sound. Measured first (alias.cpp / eng.cpp against a
// 192 kHz reference of the same note): the harmonics themselves were clean (-105 dBc floor), but
//   - the filter block (DRIVE; the LADDER / KORG35 saturation) folded its own harmonics back into the audible band (down to -33 dBc), and
//   - the unison's moving delay taps used LINEAR interpolation, which modulates and bends everything above a few kHz (-28 dB error at 5 kHz).
//
//  1) FracDelay  - a delay tap read with a 24-point Kaiser-windowed sinc (256 phases, the coefficients interpolated between phases):
//                  error < -98 dB up to 15 kHz at 48 kHz (linear: -28 dB at 5 kHz, -16 dB at 10 kHz).
//  2) Oversampler4 - the nonlinear filter block runs at four times the sample rate (two linear-phase half-band FIR stages, 96 dB stop band,
//                  flat to 19 kHz at 48 kHz), so what the saturation makes above the audible band can no longer fold into it.
//
// Plain C++17, no allocation after construction, no locks: the tables are built the first time a voice is made (the sampler's constructor).
#include <array>
#include <cmath>
#include <cstddef>

namespace silveton::sampler::synth::dsp {

namespace detail {
inline double bessel0(double x) noexcept {   // modified Bessel function I0 (the Kaiser window)
    double sum = 1.0, term = 1.0; const double q = x * x * 0.25;
    for (int k = 1; k < 60; ++k) { term *= q / (static_cast<double>(k) * static_cast<double>(k)); sum += term; if (term < sum * 1.0e-17) break; }
    return sum;
}
inline double kaiser(double u, double beta) noexcept {   // u in -1..1
    const double a = 1.0 - u * u;
    return a <= 0.0 ? 0.0 : bessel0(beta * std::sqrt(a)) / bessel0(beta);
}
inline double sincPi(double x) noexcept { return std::fabs(x) < 1.0e-12 ? 1.0 : std::sin(3.14159265358979323846 * x) / (3.14159265358979323846 * x); }
}  // namespace detail

// ---- 1) the fractional delay ------------------------------------------------------------------------------------------------------
constexpr int kFdTaps = 24;         // 12 samples before the read position, 12 after
constexpr int kFdBefore = 11;       // the first tap sits this many samples before floor(position)
constexpr int kFdPhases = 256;      // positions between two samples (the coefficients are interpolated between them)
constexpr int kFdLatency = 12;      // the read position must lie at least this many samples behind the newest sample

struct FracTable {
    float c[kFdPhases + 1][kFdTaps];
    FracTable() noexcept {
        for (int p = 0; p <= kFdPhases; ++p) {
            const double mu = static_cast<double>(p) / kFdPhases; double sum = 0.0; double row[kFdTaps];
            for (int j = 0; j < kFdTaps; ++j) {
                const double t = static_cast<double>(j - kFdBefore);   // sample offset against floor(position)
                row[j] = detail::sincPi(mu - t) * detail::kaiser((mu - t) / 12.0, 9.5); sum += row[j];
            }
            for (int j = 0; j < kFdTaps; ++j) c[p][j] = static_cast<float>(row[j] / sum);   // unity gain at DC, exactly
        }
    }
};
inline const FracTable& fracTable() noexcept { static const FracTable t; return t; }

// y = x(pos), pos = i + mu measured in samples of a ring buffer of `len` entries (a power of two); `i` is the index of floor(pos).
inline float fracRead(const float* buf, int len, int i, float mu) noexcept {
    const FracTable& tb = fracTable();
    const float fp = mu * static_cast<float>(kFdPhases);
    int p = static_cast<int>(fp); if (p > kFdPhases - 1) p = kFdPhases - 1; if (p < 0) p = 0;
    const float fr = fp - static_cast<float>(p);
    const float* a = tb.c[p]; const float* b = tb.c[p + 1];
    float c[kFdTaps];
    for (int j = 0; j < kFdTaps; ++j) c[j] = a[j] + (b[j] - a[j]) * fr;
    const int mask = len - 1; const int s = (i - kFdBefore) & mask; float acc = 0.0F;
    if (s + kFdTaps <= len) { const float* x = buf + s; for (int j = 0; j < kFdTaps; ++j) acc += x[j] * c[j]; }
    else { int idx = s; for (int j = 0; j < kFdTaps; ++j) { acc += buf[idx] * c[j]; idx = (idx + 1) & mask; } }
    return acc;
}

// ---- 2) the oversampler ------------------------------------------------------------------------------------------------------------
// A half-band FIR of N = 4m + 3 taps (centre 2m+1): every second tap is zero, the centre is 1/2. Polyphase:
//   up 2x  : y[2j] = sum_k 2 h[2k] x[j-k]  (k = 0 .. 2m+1),  y[2j+1] = x[j-m]
//   down 2x: out[j] = sum_k h[2k] u[2j-2k] + 1/2 u[2j-(2m+1)]
template <int M>
struct HalfBandKernel {
    static constexpr int kLong = 2 * M + 2;   // taps of the long branch
    std::array<float, kLong> h{};             // h[2k]
    explicit HalfBandKernel(double beta) noexcept {
        const int n = 4 * M + 3, centre = 2 * M + 1;
        for (int k = 0; k < kLong; ++k) {
            const int idx = 2 * k; const double d = static_cast<double>(idx - centre);
            const double v = 0.5 * detail::sincPi(d * 0.5) * detail::kaiser(d / (static_cast<double>(n - 1) * 0.5), beta);
            h[static_cast<std::size_t>(k)] = static_cast<float>(v);
        }
    }
};

constexpr int pow2Above(int n) noexcept { int p = 1; while (p < n) p <<= 1; return p; }

// The history is kept twice (every sample is written at pos and at pos + kHist), so the last kLong samples are always one straight run in memory.
template <int M>
class Up2 {
public:
    explicit Up2(const HalfBandKernel<M>* k) noexcept : k_(k) {}
    void reset() noexcept { x_.fill(0.0F); pos_ = 0; }
    void process(float in, float out[2]) noexcept {
        pos_ = (pos_ + 1) & kMask; x_[static_cast<std::size_t>(pos_)] = in; x_[static_cast<std::size_t>(pos_ + kHist)] = in;
        const float* w = &x_[static_cast<std::size_t>(pos_ + kHist)];   // w[-k] = x[j-k]
        float acc = 0.0F;   // the taps are symmetric: tap k and tap 2M+1-k share a coefficient
        for (int k = 0; k <= M; ++k) acc += k_->h[static_cast<std::size_t>(k)] * (w[-k] + w[-(2 * M + 1 - k)]);
        out[0] = 2.0F * acc;
        out[1] = w[-M];
    }
private:
    static constexpr int kHist = pow2Above(HalfBandKernel<M>::kLong + 1), kMask = kHist - 1;
    const HalfBandKernel<M>* k_;
    std::array<float, 2 * kHist> x_{};
    int pos_{0};
};

template <int M>
class Down2 {
public:
    explicit Down2(const HalfBandKernel<M>* k) noexcept : k_(k) {}
    void reset() noexcept { e_.fill(0.0F); o_.fill(0.0F); pos_ = 0; }
    // `a` is the older of the two high-rate samples (u[2j-1]), `b` the newer (u[2j])
    float process(float a, float b) noexcept {
        pos_ = (pos_ + 1) & kMask;
        e_[static_cast<std::size_t>(pos_)] = b; e_[static_cast<std::size_t>(pos_ + kHist)] = b;
        o_[static_cast<std::size_t>(pos_)] = a; o_[static_cast<std::size_t>(pos_ + kHist)] = a;
        const float* w = &e_[static_cast<std::size_t>(pos_ + kHist)];
        float acc = 0.0F;
        for (int k = 0; k <= M; ++k) acc += k_->h[static_cast<std::size_t>(k)] * (w[-k] + w[-(2 * M + 1 - k)]);
        return acc + 0.5F * o_[static_cast<std::size_t>(pos_ + kHist - M)];
    }
private:
    static constexpr int kHist = pow2Above(HalfBandKernel<M>::kLong + 1), kMask = kHist - 1;
    const HalfBandKernel<M>* k_;
    std::array<float, 2 * kHist> e_{}, o_{};
    int pos_{0};
};

constexpr int kStage1M = 15;   // 63 taps at twice the rate: flat to 19 kHz, about 95 dB down from 29 kHz (at 48 kHz)
constexpr int kStage2M = 5;    // 23 taps at four times the rate
// group delay of the whole round trip in samples of the base rate: stage 1 (2 x 31 at 2x) + stage 2 (2 x 11 at 4x)
constexpr int kOs4Latency = (2 * (2 * kStage1M + 1)) / 2 + ((2 * (2 * kStage2M + 1) + 2) / 4);   // 31 + 6 = 37 (the true value is 36.5)

// SILVETON_SYNTH_CLEAN_V1 - NO ADDED LATENCY (Цветомир, 03.11.2026: "каквото правиш ... да не се отразява на латенцията").
// The sinc reads of the unison and the half-band filters of the oversampler each hold the sound back by a FIXED number of samples. The dry
// sum of the filter block is held back by the same kOs4Latency (so the fade between dry and filtered stays aligned), and a note starts with its
// whole chain kPreRoll samples AHEAD: the voice calculates the first kPreRoll samples before it gives out the first one. What leaves the voice
// at the first sample is the first sample of the note - exactly where it was before this work.
constexpr int kPreRoll = kFdLatency + kOs4Latency;

struct Os4Kernels {
    HalfBandKernel<kStage1M> s1{9.5};
    HalfBandKernel<kStage2M> s2{9.5};
};
inline const Os4Kernels& os4Kernels() noexcept { static const Os4Kernels k; return k; }

// one channel: x (base rate) -> 4x -> f() on each of the four samples -> back to the base rate
class Oversampler4 {
public:
    Oversampler4() noexcept : u1_(&os4Kernels().s1), u2_(&os4Kernels().s2), d1_(&os4Kernels().s1), d2_(&os4Kernels().s2) {}
    void reset() noexcept { u1_.reset(); u2_.reset(); d1_.reset(); d2_.reset(); }
    template <class F>
    float run(float x, F&& f) noexcept {
        float a[2]; u1_.process(x, a);
        float mid[2];
        for (int i = 0; i < 2; ++i) {
            float c[2]; u2_.process(a[i], c);
            const float y0 = f(c[0]); const float y1 = f(c[1]);
            mid[i] = d2_.process(y0, y1);
        }
        return d1_.process(mid[0], mid[1]);
    }
private:
    Up2<kStage1M> u1_;
    Up2<kStage2M> u2_;
    Down2<kStage1M> d1_;
    Down2<kStage2M> d2_;
};

}  // namespace silveton::sampler::synth::dsp
