// SILVETON_SYNTH_V1 - see SynthVoice.h
#include "SynthVoice.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler::synth {

namespace {
constexpr double kTwoPi = 6.283185307179586;
constexpr double kFrameMs = 5.0;              // the teacher's frame
constexpr double kTailBlendRows = 10.0;       // SILVETON_FULLTRACK_V1: a short loop - the last 50 ms of the track go over into the steady snapshot
constexpr float kTargetEarRms = 0.16F;        // every note of every model, by ear (a sine of this RMS is about -13 dBFS)
constexpr int kSine = 4096;   // 2^12 entries: the top 12 bits of the integer phase pick the entry, the rest interpolate
inline float clampf(float x, float lo, float hi) noexcept { return x < lo ? lo : (x > hi ? hi : x); }
inline float tanhF(float x) noexcept {
    if (x > 4.0F) return 1.0F;
    if (x < -4.0F) return -1.0F;
    const float x2 = x * x;
    return x * (27.0F + x2) / (27.0F + 9.0F * x2);
}
inline std::uint32_t lcg(std::uint32_t& s) noexcept { s = s * 1664525U + 1013904223U; return s; }
inline float noiseOf(std::uint32_t& s) noexcept { return static_cast<float>(lcg(s) >> 8) / 8388608.0F - 1.0F; }
// the ear's sensitivity (the A curve), power, 1 at 1 kHz
inline double earPower(double hz) noexcept {
    const double f2 = hz * hz;
    const double num = 12194.0 * 12194.0 * f2 * f2;
    const double den = (f2 + 20.6 * 20.6) * std::sqrt((f2 + 107.7 * 107.7) * (f2 + 737.9 * 737.9)) * (f2 + 12194.0 * 12194.0);
    const double a = num / den * 1.2589;
    return a * a;
}
// one sine table for every note (built the first time a voice is made - in the sampler's constructor, never on the audio thread)
const float* sineTable() noexcept {
    static const std::array<float, kSine + 1> t = [] {
        std::array<float, kSine + 1> a{};
        for (int i = 0; i <= kSine; ++i) a[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(kTwoPi * static_cast<double>(i) / kSine));
        return a;
    }();
    return t.data();
}
inline float sineAt(const float* t, std::uint32_t ph) noexcept {
    const std::uint32_t i = ph >> 20;
    const float f = static_cast<float>(ph & 0xFFFFFU) * (1.0F / 1048576.0F);
    return t[i] + (t[i + 1] - t[i]) * f;
}
// the track of a zone at a (fractional) row: dB of harmonic k (0-based), rows interpolated
inline double trackAt(const ZoneShape& z, double row, int k, int rows) noexcept {
    if (rows <= 0 || k >= z.trackH) return -200.0;
    const int r0 = std::clamp(static_cast<int>(row), 0, rows - 1);
    const int r1 = std::min(r0 + 1, rows - 1);
    const double f = std::clamp(row - r0, 0.0, 1.0);
    const double a = model::harmTrackDb(z.harmTrack[static_cast<std::size_t>(r0) * static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]);
    const double b = model::harmTrackDb(z.harmTrack[static_cast<std::size_t>(r1) * static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]);
    if (a < -150.0 || b < -150.0) return f < 0.5 ? a : b;
    return a + (b - a) * f;
}
inline float scoopAt(const ZoneShape& z, double tSec) noexcept {
    const double fr = tSec * 1000.0 / model::kScoopFrameMs;
    if (fr >= model::kScoopFrames - 1) return 0.0F;
    const int i = static_cast<int>(fr); const float f = static_cast<float>(fr - i);
    return z.scoop[i] + (z.scoop[i + 1] - z.scoop[i]) * f;
}
// Play the ACTUAL acoustic pitch movement over the entire learned note,
// not only its first 300 ms. At loop boundaries follow the same timebase as
// the learned harmonics. Old electronic models never use this function.
inline float capturedPitchAt(const ZoneShape& z, double tSec) noexcept {
    const int n = static_cast<int>(z.synthPitchRows.size());
    if (n == 0) return 0.0F;
    double row = std::max(0.0, tSec * 1000.0 / kFrameMs);
    if (row >= static_cast<double>(n)) {
        if (!z.fullTrack) return 0.0F;
        if (z.looped && z.loopMs >= model::kLongLoopMs) {
            const int length = std::clamp(static_cast<int>(z.loopMs / kFrameMs + 0.5), 1, n);
            const double begin = static_cast<double>(n - length);
            row = begin + std::fmod(std::max(0.0, row - begin), static_cast<double>(length));
        } else row = static_cast<double>(n - 1);
    }
    const int i = std::clamp(static_cast<int>(row), 0, n - 1);
    const int next = std::min(i + 1, n - 1);
    const float part = static_cast<float>(std::clamp(row - i, 0.0, 1.0));
    return static_cast<float>(z.synthPitchRows[static_cast<std::size_t>(i)]) * (1.0F - part)
        + static_cast<float>(z.synthPitchRows[static_cast<std::size_t>(next)]) * part;
}
// Both sides of a type transition retain the complete, equally delayed 4x path.
inline float filterSample(dsp::Oversampler4& os, model::Ladder& ladder, model::Korg35& korg,
                          model::Svf& svf, int type, float drive, float input) noexcept {
    const float pre = 1.0F + 4.0F * drive, post = 1.0F / (1.0F + 1.2F * drive);
    return os.run(input, [&](float v) noexcept -> float {
        if (drive > 0.0F) v = tanhF(v * pre) * post;
        if (type == 1) return ladder.run(v, drive);
        if (type == 2) return korg.run(v);
        return svf.run(v, type);
    });
}
}  // namespace

Voice::Voice() noexcept { (void)sineTable(); (void)dsp::fracTable(); (void)dsp::os4Kernels(); }   // all tables are built here, never on the audio thread

void Voice::prepareZone() noexcept {
    zoneFresh_ = false;
    steadyDb_.fill(-200.0F); steadyRef_ = 1.0F; peakRefDb_ = -200.0F;
    if (zone_ == nullptr || !zone_->ok || zone_->trackRows <= 0) return;
    const ZoneShape& z = *zone_;
    if (z.synthPrecomputed) {
        steadyDb_ = z.synthSteadyDb;
        steadyRef_ = z.synthSteadyRef;
        peakRefDb_ = z.synthPeakRefDb;
        return;
    }
    // Compatibility for unparsed / hand-constructed test zones.
    const int loopRows = std::max(1, z.trackRows - z.attackRows);
    double mx = 1e-12;
    for (int k = 0; k < std::min(kMaxH, z.trackH); ++k) {
        double a = 0.0;
        for (int r = z.attackRows; r < z.trackRows; ++r) a += std::pow(10.0, model::harmTrackDb(z.harmTrack[static_cast<std::size_t>(r) * static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]) / 20.0);
        a /= loopRows;
        steadyDb_[static_cast<std::size_t>(k)] = a > 1e-9 ? static_cast<float>(20.0 * std::log10(a)) : -200.0F;
        mx = std::max(mx, a);
    }
    steadyRef_ = static_cast<float>(mx);
    peakRefDb_ = -200.0F;   // SILVETON_FULLTRACK_V1: the strongest harmonic of the loudest 100 ms - the full track is played against it
    if (z.fullTrack) for (int k = 0; k < std::min(kMaxH, z.trackH); ++k) peakRefDb_ = std::max(peakRefDb_, z.peakDb[k]);
}

void Voice::noteOn(const float* params, double sampleRate, const Inputs& in, const ZoneShape* zone, std::uint32_t seed) noexcept {
    p_ = params; sr_ = sampleRate; in_ = in; key_ = in.key; zone_ = zone; zoneFresh_ = true;
    rng_ = seed | 1U; pos_ = kChunk; t_ = 0.0; pitchSemis_ = 0.0; peak_ = 0.0F; needControl_ = true;
    n_ = 0; nLive_ = 0; ph_.fill(0U); ampNow_.fill(0.0F); ampTick_.fill(0.0F); level_ = 0.0F; filtMix_ = 0.0F;
    fmNow_.fill(0.0F); fmTick_.fill(0.0F); modPh_ = 0U; ratioQ_ = 256U; fmOn_ = false;   // SILVETON_SYNTH_FM_OFFSET_V1
    noiseNow_.fill(0.0F); noiseTick_.fill(0.0F); noiseLp_.fill(0.0F); noiseActive_ = false;
    for (int i = 0; i < 3; ++i) {
        const double fc = i == 0 ? 500.0 : i == 1 ? 2000.0 : 8000.0;
        noiseAlpha_[static_cast<std::size_t>(i)] = static_cast<float>(1.0 - std::exp(-6.283185307179586 * fc / sr_));
    }
    // the harmonics start at scattered phases (one phase for all would make a needle-like wave)
    for (int k = 0; k < kMaxH; ++k) ph_[static_cast<std::size_t>(k)] = lcg(rng_);
    for (int i = 0; i < kUniLen; ++i) uniL_[i] = 0.0F;
    osL_.reset(); filtWasOn_ = false; filterTail_.left = 0;
    for (int i = 0; i < kDryLen; ++i) dryD_[i] = 0.0F;
    dryW_ = 0; primed_ = false;
    uniW_ = 0; uniPh1_ = 0.0; uniPh2_ = 0.37; uniAmt_ = uniDepth_ = uniAmtWant_ = uniDepthWant_ = 0.0F;
    lifeState_ = 0.0; lifeCentsRms_ = 0.0F; vibPh_ = 0.0;
    filtEnv_ = model::Env{}; filtEnv_.trigger(); ladderL_.reset(); korgL_.reset(); svfL_.reset();
    filtType_ = 0; lastFiltType_ = 3; cutHz_ = -1.0F; res_ = clampf(p_[E_RESO], 0.0F, 1.0F); drive_ = 0.0F; filtGain_ = 1.0F;
    pos_ = kChunk;   // the first tick does the first control step with the real increment
}

void Voice::setInputs(const Inputs& in, double sampleRate) noexcept {
    sr_ = sampleRate;
    const bool wasGate = in_.gate;
    in_ = in;
    if (wasGate && !in.gate) filtEnv_.release();
    if (in.gate && in.key != key_) key_ = in.key;
}

// what the filter takes from the spectrum as it stands, so it can be given back (power, by ear)
float Voice::gainOfFilter(double f0) const noexcept {
    if (filtType_ == 0 || n_ <= 0) return 1.0F;
    const int type = filtType_; const double cut = std::max(20.0F, cutHz_);
    double all = 0.0, after = 0.0;
    for (int k = 0; k < n_; ++k) {
        const double hz = f0 * (k + 1);
        const double w = static_cast<double>(ampNow_[static_cast<std::size_t>(k)]) * ampNow_[static_cast<std::size_t>(k)] * earPower(hz);
        const double r = hz / cut;
        double resp;
        if (type == 4) resp = 1.0 / (1.0 + std::pow(1.0 / std::max(r, 1e-6), 4.0));
        else if (type == 5) { const double lr = std::log2(std::max(r, 1e-6)); resp = 1.0 / (1.0 + lr * lr * 4.0); }
        else resp = 1.0 / (1.0 + std::pow(r, type == 1 ? 8.0 : 4.0));
        all += w; after += w * resp;
    }
    if (all <= 0.0 || after <= 0.0) return 1.0F;
    return static_cast<float>(std::clamp(std::sqrt(all / after), 0.05, 4.0));   // at most +12 dB back
}

void Voice::control(double inc) noexcept {
    const float* p = p_;
    const double f0 = std::max(1.0, inc * sr_);   // the note that sounds, Hz
    const float chunkSec = static_cast<float>(kChunk) / static_cast<float>(sr_);
    if (zoneFresh_) prepareZone();
    const bool have = zone_ != nullptr && zone_->ok && zone_->trackRows > 0 && zone_->trackH > 0;
    // ---- the harmonics: how many, and their amplitudes at this moment
    std::array<float, kMaxH> want{};
    int n = 0;
    // SILVETON_SYNTH_FM_OFFSET_V1: OFFSET - the note begins this many ms inside the learned sound (the harmonics, the attack rows AND the pitch curve of the attack)
    const double offMs = static_cast<double>(clampf(p[SY_OFFSET], 0.0F, 1000.0F));
    if (have && zone_->fullTrack && zone_->attackRows >= 1 && peakRefDb_ > -150.0F) {
        // ---- SILVETON_FULLTRACK_V1: the sound as TEACHER heard it, from its first row to its last (5 ms a row, the real speed). After the
        // last row: a long loop goes round again with its own movement (the last loop-length of the track), a short loop holds the steady
        // snapshot (the last 50 ms blend into it), a sound with no loop is over (its last row stays). No knob: this is the sound.
        const ZoneShape& z = *zone_;
        const int maxH = std::clamp(static_cast<int>(p[SY_HARMONICS] + 0.5F), 4, kMaxH);
        n = std::min({maxH, z.trackH, kMaxH});
        while (n > 0 && f0 * n > sr_ * 0.45) --n;
        const int A = z.attackRows;
        const double rowNow = (t_ * 1000.0 + offMs) / kFrameMs;
        double row = rowNow;
        double wSteady = 0.0;   // 1 = the steady snapshot instead of the row
        if (rowNow >= A) {
            if (z.looped && z.loopMs >= model::kLongLoopMs) {
                const int lr = std::clamp(static_cast<int>(z.loopMs / kFrameMs + 0.5), 1, A);
                const double start = static_cast<double>(A - lr);
                row = start + std::fmod(rowNow - start, static_cast<double>(lr));
            } else row = static_cast<double>(A - 1);
        }
        if (z.looped && z.loopMs < model::kLongLoopMs) wSteady = clampf(static_cast<float>((rowNow - (A - kTailBlendRows)) / kTailBlendRows), 0.0F, 1.0F);
        const float bright = clampf(p[SY_BRIGHT], -6.0F, 6.0F);
        const double refDb = static_cast<double>(peakRefDb_);
        for (int k = 0; k < n; ++k) {
            double nowDb = trackAt(z, row, k, A);
            const double stDb = steadyDb_[static_cast<std::size_t>(k)];
            double dbv;
            if (wSteady <= 0.0) dbv = nowDb;
            else if (nowDb < -150.0 && stDb < -150.0) dbv = -200.0;
            else { const double a = nowDb < -150.0 ? stDb - 60.0 : nowDb, b = stDb < -150.0 ? nowDb - 60.0 : stDb; dbv = a + wSteady * (b - a); }
            if (dbv < -150.0) { want[static_cast<std::size_t>(k)] = 0.0F; continue; }
            double db = dbv - refDb;
            db += bright * std::log2(f0 * (k + 1) / 1000.0);
            want[static_cast<std::size_t>(k)] = static_cast<float>(std::pow(10.0, std::clamp(db, -90.0, 24.0) / 20.0));
        }
        // the one loudness by ear: the loudest 100 ms of the track is brought to kTargetEarRms (as BRIGHT leaves it)
        double ear = 0.0;
        for (int k = 0; k < n; ++k) {
            const double pk = z.peakDb[k];
            if (pk < -150.0) continue;
            const double a = std::pow(10.0, std::clamp(pk - refDb + bright * std::log2(f0 * (k + 1) / 1000.0), -90.0, 24.0) / 20.0);
            ear += 0.5 * a * a * earPower(f0 * (k + 1));
        }
        level_ = ear > 1e-12 ? static_cast<float>(kTargetEarRms / std::sqrt(ear)) : 0.0F;
        level_ = std::min(level_, 8.0F);
    } else if (have) {
        const ZoneShape& z = *zone_;
        const int maxH = std::clamp(static_cast<int>(p[SY_HARMONICS] + 0.5F), 4, kMaxH);
        n = std::min({maxH, z.trackH, kMaxH});
        while (n > 0 && f0 * n > sr_ * 0.45) --n;
        // where in the track: the attack rows, then the steady rows cycled (the sound keeps living)
        const double tMs = t_ * 1000.0 + offMs;
        const double attackMs = z.attackRows * kFrameMs;
        double row;
        if (tMs < attackMs) row = tMs / kFrameMs;
        else {
            const int loopRows = std::max(1, z.trackRows - z.attackRows);
            double lr = std::fmod((tMs - attackMs) / kFrameMs, static_cast<double>(2 * loopRows));
            if (lr > loopRows) lr = 2 * loopRows - lr;   // back and forth: no jump at the end of the steady rows
            row = z.attackRows + lr;
        }
        const float shape = clampf(p[SY_SHAPE], 0.0F, 2.0F);
        const float bright = clampf(p[SY_BRIGHT], -6.0F, 6.0F);
        // SILVETON_SYNTH_TUNE_V1 (Цветомир, 03.11.2026 18:26): the FORMANT SHIFT of the engine is gone - the sampler's own TUNE does it now
        // (SamplerEngine.cpp playKeyFor: the zone of the sounding key moves, the pitch stays). The harmonic k takes the envelope at index k.
        const double refDb = 20.0 * std::log10(std::max(static_cast<double>(steadyRef_), 1e-9));
        for (int k = 0; k < n; ++k) {
            // One-to-one harmonic indexing needs no neighbour. n is bounded by
            // both trackH and kMaxH, including teacher files with 49..64 harmonics.
            double nowDb = trackAt(z, row, k, z.trackRows);
            double stDb = steadyDb_[static_cast<std::size_t>(k)];
            if (stDb < -150.0 && nowDb < -150.0) { want[static_cast<std::size_t>(k)] = 0.0F; continue; }
            if (stDb < -150.0) stDb = nowDb;
            if (nowDb < -150.0) nowDb = stDb - 60.0;
            double db = stDb + shape * (nowDb - stDb) - refDb;                    // against the strongest steady harmonic
            db += bright * std::log2(f0 * (k + 1) / 1000.0);                      // BRIGHT: a tilt
            want[static_cast<std::size_t>(k)] = static_cast<float>(std::pow(10.0, std::clamp(db, -90.0, 24.0) / 20.0));
        }
        // the one loudness by ear: the steady spectrum (as BRIGHT leaves it) is brought to kTargetEarRms
        double ear = 0.0;
        for (int k = 0; k < n; ++k) {
            const double stDb = steadyDb_[static_cast<std::size_t>(k)];
            if (stDb < -150.0) continue;
            const double a = std::pow(10.0, std::clamp(stDb - refDb + bright * std::log2(f0 * (k + 1) / 1000.0), -90.0, 24.0) / 20.0);
            ear += 0.5 * a * a * earPower(f0 * (k + 1));
        }
        level_ = ear > 1e-12 ? static_cast<float>(kTargetEarRms / std::sqrt(ear)) : 0.0F;
        level_ = std::min(level_, 8.0F);
    }
    n_ = n;
    int live = 0;
    for (int k = 0; k < kMaxH; ++k) {
        const float target = k < n ? want[static_cast<std::size_t>(k)] * level_ : 0.0F;
        float& now = ampNow_[static_cast<std::size_t>(k)];
        if (needControl_) { now = target; ampTick_[static_cast<std::size_t>(k)] = 0.0F; }
        else ampTick_[static_cast<std::size_t>(k)] = (target - now) / static_cast<float>(kChunk);
        if (target > 2.0e-5F || now > 2.0e-5F) live = k + 1;   // below -94 dBFS a harmonic is not worth the arithmetic
    }
    nLive_ = live;
    // SVOSC004 acoustic detail: apply the measured eight-band noise curve,
    // precombined into four octave-spanning bands at bank load. No transcendental
    // math or memory allocation occurs at audio rate. Electronic/old models
    // have no noise table and retain their exact previous synthesis.
    {
        std::array<float, 4> target{};
        if (have && !zone_->synthNoiseRows.empty() && zone_->synthNoiseRows.size() >= static_cast<std::size_t>(zone_->trackRows)) {
            const ZoneShape& z = *zone_;
            const double rowNow = (t_ * 1000.0 + offMs) / kFrameMs;
            double row = rowNow;
            if (rowNow >= z.attackRows) {
                if (z.fullTrack && z.looped && z.loopMs >= model::kLongLoopMs) {
                    const int length = std::clamp(static_cast<int>(z.loopMs / kFrameMs + 0.5), 1, z.attackRows);
                    const double from = static_cast<double>(z.attackRows - length);
                    row = from + std::fmod(std::max(0.0, rowNow - from), static_cast<double>(length));
                } else if (z.fullTrack) row = static_cast<double>(std::max(0, z.attackRows - 1));
                else row = z.attackRows + std::fmod(std::max(0.0, rowNow - z.attackRows),
                             static_cast<double>(std::max(1, z.trackRows - z.attackRows)));
            }
            const int r0 = std::clamp(static_cast<int>(row), 0, z.trackRows - 1);
            const int r1 = std::min(r0 + 1, z.trackRows - 1);
            const float t = static_cast<float>(std::clamp(row - r0, 0.0, 1.0));
            const float normalise = level_ * z.synthNoiseRefGain;
            for (int b = 0; b < 4; ++b) {
                const float a = z.synthNoiseRows[static_cast<std::size_t>(r0)][static_cast<std::size_t>(b)];
                const float c = z.synthNoiseRows[static_cast<std::size_t>(r1)][static_cast<std::size_t>(b)];
                target[static_cast<std::size_t>(b)] = std::min(0.3F, std::max(0.0F, (a + t * (c - a)) * normalise));
            }
        }
        noiseActive_ = false;
        for (int b = 0; b < 4; ++b) {
            float& now = noiseNow_[static_cast<std::size_t>(b)];
            const float want = target[static_cast<std::size_t>(b)];
            if (needControl_) { now = want; noiseTick_[static_cast<std::size_t>(b)] = 0.0F; }
            else noiseTick_[static_cast<std::size_t>(b)] = (want - now) / static_cast<float>(kChunk);
            if (now > 1.0e-6F || want > 1.0e-6F) noiseActive_ = true;
        }
    }
    // ---- SILVETON_SYNTH_FM_OFFSET_V1: the FM index of every harmonic (in turns), glided over the chunk. A harmonic gets at most the index whose sidebands
    // (index + 1 of them, RATIO x the note apart) still fit under the Nyquist - so the high harmonics take less, and nothing folds back.
    {
        const float fm = clampf(p[SY_FM], 0.0F, 8.0F);
        const float ratio = clampf(p[SY_RATIO], 0.25F, 16.0F);
        ratioQ_ = static_cast<std::uint32_t>(ratio * 256.0F + 0.5F);
        const double fmHz = f0 * static_cast<double>(ratio);
        const double room = sr_ * 0.5 * 0.96;
        bool any = false;
        for (int k = 0; k < kMaxH; ++k) {
            float target = 0.0F;
            if (fm > 0.0005F && k < live) {
                const double idxMax = (room - f0 * static_cast<double>(k + 1)) / fmHz - 1.0;
                target = static_cast<float>(std::min(static_cast<double>(fm), std::max(0.0, idxMax)) / kTwoPi);
            }
            float& now = fmNow_[static_cast<std::size_t>(k)];
            if (needControl_) { now = target; fmTick_[static_cast<std::size_t>(k)] = 0.0F; }
            else fmTick_[static_cast<std::size_t>(k)] = (target - now) / static_cast<float>(kChunk);
            if (target > 1.0e-5F || now > 1.0e-5F) any = true;
        }
        fmOn_ = any;
    }
    // ---- the pitch: the scoop of the attack, the life, the vibrato
    {
        double semis = 0.0;
        if (have) {
            const ZoneShape& z = *zone_;
            // For expressive acoustic models, Teacher's pitch curve already
            // contains measured vibrato and drift. Do not add artificial
            // vibrato/life on top of it (that would double these movements).
            const bool measured = !z.synthPitchRows.empty();
            const float cents = measured ? capturedPitchAt(z, t_ + offMs * 0.001)
                                         : scoopAt(z, t_ + offMs * 0.001);
            semis += static_cast<double>(cents * clampf(p[SY_SCOOP], 0.0F, 2.0F)) / 100.0;
            lifeCentsRms_ = measured ? 0.0F : z.lifeCents * clampf(p[SY_LIFE], 0.0F, 2.0F);
            const float vibK = measured ? 0.0F : clampf(p[SY_VIBRATO], 0.0F, 2.0F);
            if (z.vibratoCents > 0.0F && vibK > 0.0F) {
                vibPh_ += kTwoPi * static_cast<double>(z.vibratoHz) * chunkSec; if (vibPh_ > kTwoPi) vibPh_ -= kTwoPi;
                semis += std::sin(vibPh_) * static_cast<double>(z.vibratoCents * vibK) / 100.0;
            }
        } else lifeCentsRms_ = 0.0F;
        if (lifeCentsRms_ > 0.0F) {
            const double c = std::exp(-kTwoPi * 6.0 * chunkSec);
            lifeState_ = lifeState_ * c + static_cast<double>(noiseOf(rng_)) * (1.0 - c);
            const double gain = std::sqrt(3.0 * (1.0 + c) / (1.0 - c));
            semis += lifeState_ * gain * static_cast<double>(lifeCentsRms_) / 100.0;
        }
        pitchSemis_ = semis;
    }
    // ---- the unison: two moving copies of the sum (slides, never jumps)
    {
        const float u = have ? zone_->unisonCents * clampf(p[SY_UNISON], 0.0F, 2.0F) : 0.0F;
        uniAmtWant_ = u >= 1.0F ? clampf(u / 12.0F, 0.0F, 1.0F) : 0.0F;
        uniDepthWant_ = static_cast<float>(static_cast<double>(u) * 0.000577 / (kTwoPi * 0.7) * sr_);
        uniDepthWant_ = std::min(uniDepthWant_, kUniDepthMax);
        if (needControl_) { uniAmt_ = uniAmtWant_; uniDepth_ = uniDepthWant_; }
        else { uniAmt_ += (uniAmtWant_ - uniAmt_) * 0.15F; uniDepth_ += (uniDepthWant_ - uniDepth_) * 0.15F; if (uniAmt_ < 0.002F && uniAmtWant_ <= 0.0F) uniAmt_ = 0.0F; }
    }
    // ---- the filter block
    {
        filtEnv_.setTimes(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], sr_);
        int wantedType = std::clamp(static_cast<int>(p[E_FILT_TYPE] + 0.5F), 0, 5);
        // Finish the current 4 ms fade before adopting a subsequent type. The
        // latest parameter wins at the next control step; no states are reused
        // from a filter that was last heard earlier in the note.
        if (wantedType != 0 && wantedType != lastFiltType_) {
            if (filterTail_.left > 0) wantedType = lastFiltType_;
            else {
                if (!needControl_ && filtWasOn_ && filtMix_ > 0.0F) {
                    filterTail_.ladder = ladderL_; filterTail_.korg = korgL_; filterTail_.svf = svfL_; filterTail_.os = osL_;
                    filterTail_.type = lastFiltType_; filterTail_.drive = drive_; filterTail_.gain = filtGain_;
                    filterTail_.total = std::max(1, static_cast<int>(sr_ * 0.004));
                    filterTail_.left = filterTail_.total;
                }
                ladderL_.reset(); korgL_.reset(); svfL_.reset(); osL_.reset(); filtWasOn_ = false;
                lastFiltType_ = wantedType;
            }
        } else if (wantedType != 0 && !filtWasOn_) {
            // Re-entering the same type after a complete OFF fade also starts
            // from fresh integrators. The existing dry/wet fade warms the path.
            ladderL_.reset(); korgL_.reset(); svfL_.reset(); osL_.reset();
        }
        filtType_ = wantedType;
        drive_ = clampf(p[E_DRIVE], 0.0F, 1.0F);
        const float fenv = filtEnv_.level;
        float oct = clampf(p[E_KEYTRACK], -1.0F, 1.0F) * static_cast<float>(key_ - 60) / 12.0F + clampf(p[E_FEG_AMT], -8.0F, 8.0F) * fenv +
                    clampf(p[E_VEL_CUT], 0.0F, 8.0F) * clampf(in_.velocity, 0.0F, 1.0F);
        if (have && zone_->vibratoCents > 0.0F) oct += clampf(p[E_LFO_CUT], 0.0F, 4.0F) * static_cast<float>(std::sin(vibPh_));
        const float cutTarget = clampf(clampf(p[E_CUTOFF], 20.0F, 20000.0F) * std::exp2(oct), 20.0F, 20000.0F);
        cutHz_ = cutHz_ <= 0.0F ? cutTarget : std::exp(std::log(cutHz_) + (std::log(cutTarget) - std::log(cutHz_)) * 0.45F);
        res_ += (clampf(p[E_RESO], 0.0F, 1.0F) - res_) * 0.45F;
        if (filtType_ == 1) ladderL_.set(cutHz_, res_, sr_ * 4.0);   // the block runs at 4x
        else if (filtType_ == 2) korgL_.set(cutHz_, res_, sr_ * 4.0);
        else if (filtType_ >= 3) svfL_.set(cutHz_, res_, sr_ * 4.0);
        const float gTarget = gainOfFilter(f0);
        filtGain_ = needControl_ ? gTarget : filtGain_ + (gTarget - filtGain_) * 0.3F;
        const float mixWant = filtType_ != 0 ? 1.0F : 0.0F;
        if (needControl_) filtMix_ = mixWant;
        else filtMix_ += (mixWant - filtMix_) * 0.12F;   // switched under a note: the block fades in / out over about 8 ms
        if (filtMix_ < 0.002F && mixWant <= 0.0F) filtMix_ = 0.0F;
    }
    needControl_ = false;
}

void Voice::tick(double inc, float& l, float& r) noexcept {
    if (p_ == nullptr) { l = r = 0.0F; return; }
    if (!primed_) {   // SILVETON_SYNTH_CLEAN_V1: the start of the note - the chain runs dsp::kPreRoll samples ahead, so nothing is late
        primed_ = true;
        float a = 0.0F, b = 0.0F;
        for (int i = 0; i < dsp::kPreRoll; ++i) advance(inc, a, b);
    }
    advance(inc, l, r);
}

void Voice::advance(double inc, float& l, float& r) noexcept {
    if (pos_ >= kChunk) { control(inc); pos_ = 0; }
    ++pos_;
    t_ += 1.0 / sr_;
    filtEnv_.tick();
    // the harmonics: integer phases (a turn = 2^32), each harmonic k turns k times as fast as the note
    const float* st = sineTable();
    const auto inc32 = static_cast<std::uint32_t>(static_cast<std::uint64_t>(std::clamp(inc, 0.0, 0.5) * 4294967296.0));
    float sum = 0.0F;
    std::uint32_t step = 0U;
    if (!fmOn_) {
        for (int k = 0; k < nLive_; ++k) {
            step += inc32;   // = inc32 * (k + 1), wrapping like the phase itself
            std::uint32_t& ph = ph_[static_cast<std::size_t>(k)];
            ph += step;
            float& a = ampNow_[static_cast<std::size_t>(k)];
            a += ampTick_[static_cast<std::size_t>(k)];
            sum += a * sineAt(st, ph);
        }
    } else {
        // SILVETON_SYNTH_FM_OFFSET_V1: the same, with the phase of every harmonic swung by the modulator (RATIO x the note)
        const float m = sineAt(st, modPh_);
        modPh_ += static_cast<std::uint32_t>((static_cast<std::uint64_t>(inc32) * ratioQ_) >> 8);
        for (int k = 0; k < nLive_; ++k) {
            step += inc32;
            std::uint32_t& ph = ph_[static_cast<std::size_t>(k)];
            ph += step;
            float& a = ampNow_[static_cast<std::size_t>(k)];
            a += ampTick_[static_cast<std::size_t>(k)];
            float& fk = fmNow_[static_cast<std::size_t>(k)];
            fk += fmTick_[static_cast<std::size_t>(k)];
            const auto pm = static_cast<std::uint32_t>(static_cast<std::int64_t>(m * fk * 4294967296.0F));   // turns -> the integer phase (wraps)
            sum += a * sineAt(st, ph + pm);
        }
    }
    // Four cheap one-pole filters split the noise into 0-500, 500-2k,
    // 2k-8k, and 8k+ Hz. No separate neural renderer, audio buffer, or DSP
    // thread. Voice remains silent when its learned noise track is empty.
    if (noiseActive_) {
        const float white = noiseOf(rng_);
        for (int i = 0; i < 3; ++i) {
            float& st = noiseLp_[static_cast<std::size_t>(i)];
            st += noiseAlpha_[static_cast<std::size_t>(i)] * (white - st);
        }
        const float band[4] = {noiseLp_[0], noiseLp_[1] - noiseLp_[0],
                               noiseLp_[2] - noiseLp_[1], white - noiseLp_[2]};
        for (int i = 0; i < 4; ++i) {
            const std::size_t j = static_cast<std::size_t>(i);
            noiseNow_[j] += noiseTick_[j];
            sum += band[i] * noiseNow_[j];
        }
    }
    l = sum; r = sum;
    // SILVETON_SYNTH_CLEAN_V1: the calculated sum is MONO - left and right are the same number all the way through the unison and the filter
    // block (the two filters and the two delay lines always held the same values) - so they are calculated once and the right is a copy.
    // The unison: the dry sum is read dsp::kFdLatency samples back so the moving taps can be read with a 24-point sinc.
    uniL_[uniW_] = l;
    {
        const int dryIdx = (uniW_ - dsp::kFdLatency) & (kUniLen - 1);
        const float dl0 = uniL_[dryIdx];
        if (uniAmt_ > 0.0F) {
            uniPh1_ += kTwoPi * 0.7 / sr_; if (uniPh1_ > kTwoPi) uniPh1_ -= kTwoPi;
            uniPh2_ += kTwoPi * 0.9 / sr_; if (uniPh2_ > kTwoPi) uniPh2_ -= kTwoPi;
            const double d1 = 8.0 + uniDepth_ * (1.0 + std::sin(uniPh1_)), d2 = 8.0 + uniDepth_ * (1.0 + std::sin(uniPh2_ + 2.1));
            const auto tap = [&](double d) noexcept {
                const double rp = static_cast<double>(uniW_) - static_cast<double>(dsp::kFdLatency) - d;
                const double fl = std::floor(rp);
                return dsp::fracRead(uniL_, kUniLen, static_cast<int>(fl), static_cast<float>(rp - fl));
            };
            const float wet = uniAmt_ * 0.5F, dry = std::sqrt(std::max(0.0F, 1.0F - 2.0F * wet * wet));
            l = dl0 * dry + (tap(d1) + tap(d2)) * wet;
        } else l = dl0;
    }
    if (++uniW_ >= kUniLen) uniW_ = 0;
    // The dry sum waits as long as the 4x path takes (dsp::kOs4Latency), so the fade between the two stays in step.
    dryD_[dryW_] = l;
    const float dryAligned = dryD_[(dryW_ - dsp::kOs4Latency) & (kDryLen - 1)];
    dryW_ = (dryW_ + 1) & (kDryLen - 1);
    // The filter block (fades in and out when switched under a note). The drive and the filters run at 4x the sample rate, so what their
    // saturation makes above the audible band cannot fold back into it.
    if (filtType_ != 0 || filtMix_ > 0.0F) {
        if (!filtWasOn_) { osL_.reset(); filtWasOn_ = true; }
        const int type = filtType_ != 0 ? filtType_ : lastFiltType_;   // switched OFF: the filter that was on fades out (its coefficients stay as they were)
        float fl = filterSample(osL_, ladderL_, korgL_, svfL_, type, drive_, l);
        fl *= filtGain_;
        if (filterTail_.left > 0) {
            const float old = filterSample(filterTail_.os, filterTail_.ladder, filterTail_.korg,
                                           filterTail_.svf, filterTail_.type, filterTail_.drive, l) * filterTail_.gain;
            const float t = static_cast<float>(filterTail_.total - filterTail_.left) / static_cast<float>(filterTail_.total);
            const float w = t * t * t * (10.0F + t * (-15.0F + t * 6.0F));   // zero slope and curvature at both ends
            fl = old + (fl - old) * w;
            --filterTail_.left;
        }
        l = dryAligned * (1.0F - filtMix_) + fl * filtMix_;
    } else { filtWasOn_ = false; filterTail_.left = 0; l = dryAligned; }
    r = l;
    if (!std::isfinite(l) || !std::isfinite(r)) {
        l = r = 0.0F;
        ladderL_.reset(); korgL_.reset(); svfL_.reset(); osL_.reset(); filterTail_.left = 0;
        for (int i = 0; i < kUniLen; ++i) uniL_[i] = 0.0F;
        for (int i = 0; i < kDryLen; ++i) dryD_[i] = 0.0F;
    }
    peak_ = std::max(std::max(std::fabs(l), std::fabs(r)), peak_ * 0.9995F);
}

}  // namespace silveton::sampler::synth
