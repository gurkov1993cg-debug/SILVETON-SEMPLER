// SILVETON_SYNTH_V1 - see SynthVoice.h
#include "SynthVoice.h"

#include <algorithm>
#include <cmath>

namespace silveton::sampler::synth {

namespace {
constexpr double kTwoPi = 6.283185307179586;
constexpr double kFrameMs = 5.0;              // the teacher's frame
constexpr float kTargetEarRms = 0.16F;        // every note of every model, by ear (a sine of this RMS is about -13 dBFS)
constexpr int kSine = 4096;   // 2^12 entries: the top 12 bits of the integer phase pick the entry, the rest interpolate
inline float clampf(float x, float lo, float hi) noexcept { return x < lo ? lo : (x > hi ? hi : x); }
inline float tanhF(float x) noexcept {
    if (x > 4.0F) return 1.0F;
    if (x < -4.0F) return -1.0F;
    const float x2 = x * x;
    return x * (27.0F + x2) / (27.0F + 9.0F * x2);
}
inline std::uint32_t lcg(std::uint32_t& s) noexcept { s = s * 1664525U + 1013904223U; return s; }
inline float noiseOf(std::uint32_t& s) noexcept { return static_cast<float>(lcg(s) >> 8) / 8388608.0F - 1.0F; }
// the ear's sensitivity (the A curve), power, 1 at 1 kHz
inline double earPower(double hz) noexcept {
    const double f2 = hz * hz;
    const double num = 12194.0 * 12194.0 * f2 * f2;
    const double den = (f2 + 20.6 * 20.6) * std::sqrt((f2 + 107.7 * 107.7) * (f2 + 737.9 * 737.9)) * (f2 + 12194.0 * 12194.0);
    const double a = num / den * 1.2589;
    return a * a;
}
// one sine table for every note (built the first time a voice is made - in the sampler's constructor, never on the audio thread)
const float* sineTable() noexcept {
    static const std::array<float, kSine + 1> t = [] {
        std::array<float, kSine + 1> a{};
        for (int i = 0; i <= kSine; ++i) a[static_cast<std::size_t>(i)] = static_cast<float>(std::sin(kTwoPi * static_cast<double>(i) / kSine));
        return a;
    }();
    return t.data();
}
inline float sineAt(const float* t, std::uint32_t ph) noexcept {
    const std::uint32_t i = ph >> 20;
    const float f = static_cast<float>(ph & 0xFFFFFU) * (1.0F / 1048576.0F);
    return t[i] + (t[i + 1] - t[i]) * f;
}
// the track of a zone at a (fractional) row: dB of harmonic k (0-based), rows interpolated
inline double trackAt(const ZoneShape& z, double row, int k) noexcept {
    if (z.trackRows <= 0 || k >= z.trackH) return -200.0;
    const int r0 = std::clamp(static_cast<int>(row), 0, z.trackRows - 1);
    const int r1 = std::min(r0 + 1, z.trackRows - 1);
    const double f = std::clamp(row - r0, 0.0, 1.0);
    const double a = model::harmTrackDb(z.harmTrack[static_cast<std::size_t>(r0) * static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]);
    const double b = model::harmTrackDb(z.harmTrack[static_cast<std::size_t>(r1) * static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]);
    if (a < -150.0 || b < -150.0) return f < 0.5 ? a : b;
    return a + (b - a) * f;
}
inline float scoopAt(const ZoneShape& z, double tSec) noexcept {
    const double fr = tSec * 1000.0 / model::kScoopFrameMs;
    if (fr >= model::kScoopFrames - 1) return 0.0F;
    const int i = static_cast<int>(fr); const float f = static_cast<float>(fr - i);
    return z.scoop[i] + (z.scoop[i + 1] - z.scoop[i]) * f;
}
}  // namespace

Voice::Voice() noexcept { (void)sineTable(); }

void Voice::prepareZone() noexcept {
    zoneFresh_ = false;
    steadyDb_.fill(-200.0F); steadyRef_ = 1.0F;
    if (zone_ == nullptr || !zone_->ok || zone_->trackRows <= 0) return;
    const ZoneShape& z = *zone_;
    const int loopRows = std::max(1, z.trackRows - z.attackRows);
    double mx = 1e-12;
    for (int k = 0; k < std::min(kMaxH, z.trackH); ++k) {
        double a = 0.0;
        for (int r = z.attackRows; r < z.trackRows; ++r) a += std::pow(10.0, model::harmTrackDb(z.harmTrack[static_cast<std::size_t>(r) * static_cast<std::size_t>(z.trackH) + static_cast<std::size_t>(k)]) / 20.0);
        a /= loopRows;
        steadyDb_[static_cast<std::size_t>(k)] = a > 1e-9 ? static_cast<float>(20.0 * std::log10(a)) : -200.0F;
        mx = std::max(mx, a);
    }
    steadyRef_ = static_cast<float>(mx);
}

void Voice::noteOn(const float* params, double sampleRate, const Inputs& in, const ZoneShape* zone, std::uint32_t seed) noexcept {
    p_ = params; sr_ = sampleRate; in_ = in; key_ = in.key; zone_ = zone; zoneFresh_ = true;
    rng_ = seed | 1U; pos_ = kChunk; t_ = 0.0; pitchSemis_ = 0.0; peak_ = 0.0F; needControl_ = true;
    n_ = 0; nLive_ = 0; ph_.fill(0U); ampNow_.fill(0.0F); ampTick_.fill(0.0F); level_ = 0.0F; filtMix_ = 0.0F;
    // the harmonics start at scattered phases (one phase for all would make a needle-like wave)
    for (int k = 0; k < kMaxH; ++k) ph_[static_cast<std::size_t>(k)] = lcg(rng_);
    for (int i = 0; i < kUniLen; ++i) { uniL_[i] = uniR_[i] = 0.0F; }
    uniW_ = 0; uniPh1_ = 0.0; uniPh2_ = 0.37; uniAmt_ = uniDepth_ = uniAmtWant_ = uniDepthWant_ = 0.0F;
    lifeState_ = 0.0; lifeCentsRms_ = 0.0F; vibPh_ = 0.0;
    filtEnv_ = model::Env{}; filtEnv_.trigger(); ladderL_.reset(); ladderR_.reset(); svfL_.reset(); svfR_.reset();
    filtType_ = 0; cutHz_ = -1.0F; res_ = clampf(p_[E_RESO], 0.0F, 1.0F); drive_ = 0.0F; filtGain_ = 1.0F;
    pos_ = kChunk;   // the first tick does the first control step with the real increment
}

void Voice::setInputs(const Inputs& in, double sampleRate) noexcept {
    sr_ = sampleRate;
    const bool wasGate = in_.gate;
    in_ = in;
    if (wasGate && !in.gate) filtEnv_.release();
    if (in.gate && in.key != key_) key_ = in.key;
}

// what the filter takes from the spectrum as it stands, so it can be given back (power, by ear)
float Voice::gainOfFilter(double f0) const noexcept {
    if (filtType_ == 0 || n_ <= 0) return 1.0F;
    const int type = filtType_; const double cut = std::max(20.0F, cutHz_);
    double all = 0.0, after = 0.0;
    for (int k = 0; k < n_; ++k) {
        const double hz = f0 * (k + 1);
        const double w = static_cast<double>(ampNow_[static_cast<std::size_t>(k)]) * ampNow_[static_cast<std::size_t>(k)] * earPower(hz);
        const double r = hz / cut;
        double resp;
        if (type == 4) resp = 1.0 / (1.0 + std::pow(1.0 / std::max(r, 1e-6), 4.0));
        else if (type == 5) { const double lr = std::log2(std::max(r, 1e-6)); resp = 1.0 / (1.0 + lr * lr * 4.0); }
        else resp = 1.0 / (1.0 + std::pow(r, type == 1 ? 8.0 : 4.0));
        all += w; after += w * resp;
    }
    if (all <= 0.0 || after <= 0.0) return 1.0F;
    return static_cast<float>(std::clamp(std::sqrt(all / after), 0.05, 4.0));   // at most +12 dB back
}

void Voice::control(double inc) noexcept {
    const float* p = p_;
    const double f0 = std::max(1.0, inc * sr_);   // the note that sounds, Hz
    const float chunkSec = static_cast<float>(kChunk) / static_cast<float>(sr_);
    if (zoneFresh_) prepareZone();
    const bool have = zone_ != nullptr && zone_->ok && zone_->trackRows > 0 && zone_->trackH > 0;
    // ---- the harmonics: how many, and their amplitudes at this moment
    std::array<float, kMaxH> want{};
    int n = 0;
    if (have) {
        const ZoneShape& z = *zone_;
        const int maxH = std::clamp(static_cast<int>(p[SY_HARMONICS] + 0.5F), 4, kMaxH);
        n = std::min({maxH, z.trackH, kMaxH});
        while (n > 0 && f0 * n > sr_ * 0.45) --n;
        // where in the track: the attack rows, then the steady rows cycled (the sound keeps living)
        const double tMs = t_ * 1000.0;
        const double attackMs = z.attackRows * kFrameMs;
        double row;
        if (tMs < attackMs) row = tMs / kFrameMs;
        else {
            const int loopRows = std::max(1, z.trackRows - z.attackRows);
            double lr = std::fmod((tMs - attackMs) / kFrameMs, static_cast<double>(2 * loopRows));
            if (lr > loopRows) lr = 2 * loopRows - lr;   // back and forth: no jump at the end of the steady rows
            row = z.attackRows + lr;
        }
        const float shape = clampf(p[SY_SHAPE], 0.0F, 2.0F);
        const float bright = clampf(p[SY_BRIGHT], -6.0F, 6.0F);
        const double shift = std::pow(2.0, -shiftSemis(p) / 12.0);   // FORMANT SHIFT: harmonic k takes the envelope at index k * 2^(-s/12)
        const double refDb = 20.0 * std::log10(std::max(static_cast<double>(steadyRef_), 1e-9));
        for (int k = 0; k < n; ++k) {
            // the envelope at the (shifted) harmonic index, now and steady
            const double j = (k + 1) * shift - 1.0;
            double nowDb, stDb;
            if (j < 0.0 || j > z.trackH - 1) { nowDb = stDb = -200.0; }
            else {
                const int j0 = static_cast<int>(j), j1 = std::min(j0 + 1, z.trackH - 1); const double jf = j - j0;
                const double a0 = trackAt(z, row, j0), a1 = trackAt(z, row, j1);
                nowDb = (a0 < -150.0 || a1 < -150.0) ? (jf < 0.5 ? a0 : a1) : a0 + (a1 - a0) * jf;
                const double s0 = steadyDb_[static_cast<std::size_t>(j0)], s1 = steadyDb_[static_cast<std::size_t>(j1)];
                stDb = (s0 < -150.0 || s1 < -150.0) ? (jf < 0.5 ? s0 : s1) : s0 + (s1 - s0) * jf;
            }
            if (stDb < -150.0 && nowDb < -150.0) { want[static_cast<std::size_t>(k)] = 0.0F; continue; }
            if (stDb < -150.0) stDb = nowDb;
            if (nowDb < -150.0) nowDb = stDb - 60.0;
            double db = stDb + shape * (nowDb - stDb) - refDb;                    // against the strongest steady harmonic
            db += bright * std::log2(f0 * (k + 1) / 1000.0);                      // BRIGHT: a tilt
            want[static_cast<std::size_t>(k)] = static_cast<float>(std::pow(10.0, std::clamp(db, -90.0, 24.0) / 20.0));
        }
        // the one loudness by ear: the steady spectrum (as BRIGHT and the shift leave it) is brought to kTargetEarRms
        double ear = 0.0;
        for (int k = 0; k < n; ++k) {
            const double j = (k + 1) * shift - 1.0;
            double stDb = -200.0;
            if (j >= 0.0 && j <= z.trackH - 1) {
                const int j0 = static_cast<int>(j), j1 = std::min(j0 + 1, z.trackH - 1); const double jf = j - j0;
                const double s0 = steadyDb_[static_cast<std::size_t>(j0)], s1 = steadyDb_[static_cast<std::size_t>(j1)];
                stDb = (s0 < -150.0 || s1 < -150.0) ? (jf < 0.5 ? s0 : s1) : s0 + (s1 - s0) * jf;
            }
            if (stDb < -150.0) continue;
            const double a = std::pow(10.0, std::clamp(stDb - refDb + bright * std::log2(f0 * (k + 1) / 1000.0), -90.0, 24.0) / 20.0);
            ear += 0.5 * a * a * earPower(f0 * (k + 1));
        }
        level_ = ear > 1e-12 ? static_cast<float>(kTargetEarRms / std::sqrt(ear)) : 0.0F;
        level_ = std::min(level_, 8.0F);
    }
    n_ = n;
    int live = 0;
    for (int k = 0; k < kMaxH; ++k) {
        const float target = k < n ? want[static_cast<std::size_t>(k)] * level_ : 0.0F;
        float& now = ampNow_[static_cast<std::size_t>(k)];
        if (needControl_) { now = target; ampTick_[static_cast<std::size_t>(k)] = 0.0F; }
        else ampTick_[static_cast<std::size_t>(k)] = (target - now) / static_cast<float>(kChunk);
        if (target > 2.0e-5F || now > 2.0e-5F) live = k + 1;   // below -94 dBFS a harmonic is not worth the arithmetic
    }
    nLive_ = live;
    // ---- the pitch: the scoop of the attack, the life, the vibrato
    {
        double semis = 0.0;
        if (have) {
            const ZoneShape& z = *zone_;
            semis += static_cast<double>(scoopAt(z, t_) * clampf(p[SY_SCOOP], 0.0F, 2.0F)) / 100.0;
            lifeCentsRms_ = z.lifeCents * clampf(p[SY_LIFE], 0.0F, 2.0F);
            const float vibK = clampf(p[SY_VIBRATO], 0.0F, 2.0F);
            if (z.vibratoCents > 0.0F && vibK > 0.0F) {
                vibPh_ += kTwoPi * static_cast<double>(z.vibratoHz) * chunkSec; if (vibPh_ > kTwoPi) vibPh_ -= kTwoPi;
                semis += std::sin(vibPh_) * static_cast<double>(z.vibratoCents * vibK) / 100.0;
            }
        } else lifeCentsRms_ = 0.0F;
        if (lifeCentsRms_ > 0.0F) {
            const double c = std::exp(-kTwoPi * 6.0 * chunkSec);
            lifeState_ = lifeState_ * c + static_cast<double>(noiseOf(rng_)) * (1.0 - c);
            const double gain = std::sqrt(3.0 * (1.0 + c) / (1.0 - c));
            semis += lifeState_ * gain * static_cast<double>(lifeCentsRms_) / 100.0;
        }
        pitchSemis_ = semis;
    }
    // ---- the unison: two moving copies of the sum (slides, never jumps)
    {
        const float u = have ? zone_->unisonCents * clampf(p[SY_UNISON], 0.0F, 2.0F) : 0.0F;
        uniAmtWant_ = u >= 1.0F ? clampf(u / 12.0F, 0.0F, 1.0F) : 0.0F;
        uniDepthWant_ = static_cast<float>(static_cast<double>(u) * 0.000577 / (kTwoPi * 0.7) * sr_);
        uniDepthWant_ = std::min(uniDepthWant_, static_cast<float>(kUniLen / 2 - 8));
        if (needControl_) { uniAmt_ = uniAmtWant_; uniDepth_ = uniDepthWant_; }
        else { uniAmt_ += (uniAmtWant_ - uniAmt_) * 0.15F; uniDepth_ += (uniDepthWant_ - uniDepth_) * 0.15F; if (uniAmt_ < 0.002F && uniAmtWant_ <= 0.0F) uniAmt_ = 0.0F; }
    }
    // ---- the filter block
    {
        filtEnv_.setTimes(p[E_FEG_A], p[E_FEG_D], p[E_FEG_S], p[E_FEG_R], sr_);
        filtType_ = std::clamp(static_cast<int>(p[E_FILT_TYPE] + 0.5F), 0, 5);
        drive_ = clampf(p[E_DRIVE], 0.0F, 1.0F);
        const float fenv = filtEnv_.level;
        float oct = clampf(p[E_KEYTRACK], -1.0F, 1.0F) * static_cast<float>(key_ - 60) / 12.0F + clampf(p[E_FEG_AMT], -8.0F, 8.0F) * fenv +
                    clampf(p[E_VEL_CUT], 0.0F, 8.0F) * clampf(in_.velocity, 0.0F, 1.0F);
        if (have && zone_->vibratoCents > 0.0F) oct += clampf(p[E_LFO_CUT], 0.0F, 4.0F) * static_cast<float>(std::sin(vibPh_));
        const float cutTarget = clampf(clampf(p[E_CUTOFF], 20.0F, 20000.0F) * std::exp2(oct), 20.0F, 20000.0F);
        cutHz_ = cutHz_ <= 0.0F ? cutTarget : std::exp(std::log(cutHz_) + (std::log(cutTarget) - std::log(cutHz_)) * 0.45F);
        res_ += (clampf(p[E_RESO], 0.0F, 1.0F) - res_) * 0.45F;
        if (filtType_ == 1 || filtType_ == 2) { ladderL_.set(cutHz_, res_, sr_); ladderR_.set(cutHz_, res_, sr_); }
        else if (filtType_ >= 3) { svfL_.set(cutHz_, res_, sr_); svfR_.set(cutHz_, res_, sr_); }
        const float gTarget = gainOfFilter(f0);
        filtGain_ = needControl_ ? gTarget : filtGain_ + (gTarget - filtGain_) * 0.3F;
        const float mixWant = filtType_ != 0 ? 1.0F : 0.0F;
        if (needControl_) filtMix_ = mixWant;
        else filtMix_ += (mixWant - filtMix_) * 0.12F;   // switched under a note: the block fades in / out over about 8 ms
        if (filtMix_ < 0.002F && mixWant <= 0.0F) filtMix_ = 0.0F;
    }
    needControl_ = false;
}

void Voice::tick(double inc, float& l, float& r) noexcept {
    if (p_ == nullptr) { l = r = 0.0F; return; }
    if (pos_ >= kChunk) { control(inc); pos_ = 0; }
    ++pos_;
    t_ += 1.0 / sr_;
    filtEnv_.tick();
    // the harmonics: integer phases (a turn = 2^32), each harmonic k turns k times as fast as the note
    const float* st = sineTable();
    const auto inc32 = static_cast<std::uint32_t>(static_cast<std::uint64_t>(std::clamp(inc, 0.0, 0.5) * 4294967296.0));
    float sum = 0.0F;
    std::uint32_t step = 0U;
    for (int k = 0; k < nLive_; ++k) {
        step += inc32;   // = inc32 * (k + 1), wrapping like the phase itself
        std::uint32_t& ph = ph_[static_cast<std::size_t>(k)];
        ph += step;
        float& a = ampNow_[static_cast<std::size_t>(k)];
        a += ampTick_[static_cast<std::size_t>(k)];
        sum += a * sineAt(st, ph);
    }
    l = sum; r = sum;
    // the unison
    uniL_[uniW_] = l; uniR_[uniW_] = r;
    if (uniAmt_ > 0.0F) {
        uniPh1_ += kTwoPi * 0.7 / sr_; if (uniPh1_ > kTwoPi) uniPh1_ -= kTwoPi;
        uniPh2_ += kTwoPi * 0.9 / sr_; if (uniPh2_ > kTwoPi) uniPh2_ -= kTwoPi;
        const double d1 = 8.0 + uniDepth_ * (1.0 + std::sin(uniPh1_)), d2 = 8.0 + uniDepth_ * (1.0 + std::sin(uniPh2_ + 2.1));
        const auto tap = [&](const float* buf, double d) noexcept {
            double rp = static_cast<double>(uniW_) - d; if (rp < 0.0) rp += kUniLen;
            const int i0 = static_cast<int>(rp); const float f = static_cast<float>(rp - i0);
            const int i1 = i0 + 1 >= kUniLen ? 0 : i0 + 1;
            return buf[i0] + (buf[i1] - buf[i0]) * f;
        };
        const float wet = uniAmt_ * 0.5F, dry = std::sqrt(std::max(0.0F, 1.0F - 2.0F * wet * wet));
        l = l * dry + (tap(uniL_, d1) + tap(uniL_, d2)) * wet;
        r = r * dry + (tap(uniR_, d1) + tap(uniR_, d2)) * wet;
    }
    if (++uniW_ >= kUniLen) uniW_ = 0;
    // the filter block (fades in and out when switched under a note)
    if (filtType_ != 0 || filtMix_ > 0.0F) {
        float fl = l, fr = r;
        if (drive_ > 0.0F) { fl = tanhF(fl * (1.0F + 4.0F * drive_)) / (1.0F + 1.2F * drive_); fr = tanhF(fr * (1.0F + 4.0F * drive_)) / (1.0F + 1.2F * drive_); }
        const int type = filtType_ != 0 ? filtType_ : 3;
        if (type <= 2) { fl = ladderL_.run(fl, drive_); fr = ladderR_.run(fr, drive_); }
        else { fl = svfL_.run(fl, type); fr = svfR_.run(fr, type); }
        fl *= filtGain_; fr *= filtGain_;
        l = l * (1.0F - filtMix_) + fl * filtMix_; r = r * (1.0F - filtMix_) + fr * filtMix_;
    }
    if (!std::isfinite(l) || !std::isfinite(r)) {
        l = r = 0.0F;
        ladderL_.reset(); ladderR_.reset(); svfL_.reset(); svfR_.reset();
        for (int i = 0; i < kUniLen; ++i) { uniL_[i] = uniR_[i] = 0.0F; }
    }
    peak_ = std::max(std::max(std::fabs(l), std::fabs(r)), peak_ * 0.9995F);
}

}  // namespace silveton::sampler::synth
