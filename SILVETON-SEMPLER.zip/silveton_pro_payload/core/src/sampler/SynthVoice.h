#pragma once
// SILVETON_SYNTH_V1 - the note of SILVETON SYNTH: the sound is CALCULATED from what SILVETON TEACHER learned - no recording.
//
// For the note that sounds, the zone of the chosen model is taken (by key). Its harmonics are played as the teacher heard them, frame by
// frame: the attack rows (5 ms each) rise the way the real sound rose, then the steady rows cycle while the key is held (the sound keeps
// living). Every harmonic is a sine of its own at k times the note (the sampler gives the note's increment - so the place's octave,
// transpose, fine tune, portamento, legato and bend all work as for any note). On top: the model's pitch curve of the attack (SCOOP),
// its life and vibrato, its unison (two moving copies); BRIGHT tilts the spectrum; the TIMBRE moves by the TUNE of the sampler (the zone
// of the key that sounds is taken, the pitch stays - SamplerEngine.cpp synthTuneKeys), HARMONICS says how many are calculated. The FILTER block (ModelVoice.h: Env, Ladder,
// Svf) pays its loudness back.
//
// EVERY note of EVERY model comes out at the SAME loudness as the ear hears it (the A curve): the spectrum is levelled to one target
// before the sampler's own velocity, level and envelope. So no model and no key is louder than another (Цветомир: "абсолютно всички
// модели трябва да бъдат с еднаква сила").
#include "ModelVoice.h"
#include "SynthDsp.h"
#include "silveton/sampler/ModelBank.h"
#include "silveton/sampler/ModelDefs.h"
#include <array>
#include <cstdint>

namespace silveton::sampler::synth {

using model::Inputs;
using model::ZoneShape;
constexpr int kMaxH = model::kHarmonics;   // 48
constexpr int kChunk = model::kChunk;      // 32 samples between two control steps

class Voice {
public:
    Voice() noexcept;
    void noteOn(const float* params, double sampleRate, const Inputs& in, const ZoneShape* zone, std::uint32_t seed) noexcept;
    void setParams(const float* params) noexcept { p_ = params; }
    void setZone(const ZoneShape* zone) noexcept { if (zone != zone_) { zone_ = zone; zoneFresh_ = true; } }   // mid-note: it glides there
    void setInputs(const Inputs& in, double sampleRate) noexcept;
    [[nodiscard]] double pitchSemis() const noexcept { return pitchSemis_; }   // the scoop, the life, the vibrato of this block
    // `inc` = the fundamental's phase increment in cycles a sample, as the sampler plays this note right now
    void tick(double inc, float& l, float& r) noexcept;
    [[nodiscard]] float lastPeak() const noexcept { return peak_; }
    [[nodiscard]] int harmonicsNow() const noexcept { return nLive_; }   // (tests)

private:
    void control(double inc) noexcept;
    void advance(double inc, float& l, float& r) noexcept;   // one sample of the chain (tick() runs dsp::kPreRoll of them ahead at the start of a note)
    void prepareZone() noexcept;
    float gainOfFilter(double f0) const noexcept;

    const float* p_{nullptr};
    const ZoneShape* zone_{nullptr};
    bool zoneFresh_{true};
    double sr_{48000.0};
    Inputs in_{};
    int key_{60};
    bool needControl_{true};
    std::uint32_t rng_{1U};
    int pos_{kChunk};
    double t_{0.0};
    double pitchSemis_{0.0};
    float peak_{0.0F};
    // the harmonics
    int n_{0};                                   // how many are calculated for this note
    std::array<std::uint32_t, kMaxH> ph_{};      // phase of each, a whole turn = 2^32 (integer: fast, never drifts)
    int nLive_{0};                               // the last harmonic that still has an amplitude worth calculating
    float filtMix_{0.0F};                        // the filter block fades in / out over a few chunks when it is switched (no click)
    std::array<float, kMaxH> ampNow_{}, ampTick_{};
    std::array<float, kMaxH> steadyDb_{};        // the steady part of the zone (the mean of its loop rows), dB
    float steadyRef_{1.0F};                      // the strongest steady harmonic (linear) - the track is relative to it
    float peakRefDb_{-200.0F};                   // SILVETON_FULLTRACK_V1: the strongest harmonic of the loudest 100 ms (dB) - a full track is relative to it
    float level_{0.0F};                          // what brings the steady spectrum to the one loudness by ear
    // the pitch
    double lifeState_{0.0};
    float lifeCentsRms_{0.0F};
    double vibPh_{0.0};
    // the unison: two moving taps on the sum
    // SILVETON_SYNTH_CLEAN_V1: a power of two; the dry sum is read dsp::kFdLatency samples back and the taps are 24-point sinc reads
    static constexpr int kUniLen = 2048;
    static constexpr float kUniDepthMax = 504.0F;   // samples (what 1024 / 2 - 8 always allowed)
    float uniL_[kUniLen]{};   // (the calculated sum is mono: one delay line)
    int uniW_{0};
    double uniPh1_{0.0}, uniPh2_{0.37};
    float uniAmt_{0.0F}, uniDepth_{0.0F}, uniAmtWant_{0.0F}, uniDepthWant_{0.0F};
    // the filter block (the filter pieces of ModelVoice.h)
    model::Env filtEnv_;
    model::Ladder ladderL_;   // (one filter: the sum is mono, the right output is a copy of the left)
    model::Svf svfL_;
    int filtType_{0};
    int lastFiltType_{3};   // the filter that fades out when the block is switched OFF
    float cutHz_{20000.0F}, res_{0.0F}, drive_{0.0F}, filtGain_{1.0F};
    // SILVETON_SYNTH_CLEAN_V1: the filter block (DRIVE, LADDER / KORG35 saturation, the filters) runs at 4x the sample rate
    dsp::Oversampler4 osL_;
    bool filtWasOn_{false};
    // SILVETON_SYNTH_CLEAN_V1: the dry sum waits as long as the oversampled path takes (aligned fade); the note's chain runs dsp::kPreRoll ahead
    static constexpr int kDryLen = 64;   // a power of two above dsp::kOs4Latency
    float dryD_[kDryLen]{};
    int dryW_{0};
    bool primed_{false};
};

}  // namespace silveton::sampler::synth
