// SILVETON_USER_WAVES_V1 - reads the folder SILVETON_OSC and makes the user's waves (see UserWaves.h).
#include "silveton/sampler/UserWaves.h"

#include "silveton/sampler/AudioFileLoader.h"

#include <dirent.h>
#include <sys/stat.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>

namespace silveton::sampler {

std::atomic<const UserWaveTables*>& userWaveTables() noexcept {
    static std::atomic<const UserWaveTables*> p{nullptr};
    return p;
}

namespace {

constexpr double kPi = 3.14159265358979323846264338327950288;
constexpr int kTabSize = kUserTabSize;
constexpr int kTabLevels = kUserTabLevels;
constexpr long long kMaxFileBytes = 2LL * 1024 * 1024;   // a LAB wavetable of 32 frames is 128 KB; a long recording is not a wave

std::mutex gMutex;
UserWaveReport gReport;
std::string gSignature;
std::vector<std::unique_ptr<UserWaveTables>> gKeep;   // every set ever handed to the engines stays alive
std::array<ProgramPtr, kUserWaveCount> gPrograms{};    // SILVETON_OSC_SOUND_V1: the waves as SOUNDs

struct Info { bool exists{false}; bool dir{false}; long long size{0}; long long mtime{0}; };
Info statOf(const std::string& path) {
    struct stat st {};
    Info i;
    if (::stat(path.c_str(), &st) != 0) return i;
    i.exists = true;
    i.dir = S_ISDIR(st.st_mode);
    i.size = static_cast<long long>(st.st_size);
    i.mtime = static_cast<long long>(st.st_mtime);
    return i;
}

std::vector<std::string> listDir(const std::string& dir) {
    std::vector<std::string> out;
    DIR* d = ::opendir(dir.c_str());
    if (d == nullptr) return out;
    while (const dirent* e = ::readdir(d)) {
        const std::string n = e->d_name;
        if (n.empty() || n[0] == '.') continue;   // ".", ".." and hidden files (macOS "._" copies)
        out.push_back(n);
    }
    ::closedir(d);
    return out;
}

std::string lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}
bool isWavName(const std::string& n) {
    const std::string l = lower(n);
    return (l.size() > 4U && l.compare(l.size() - 4U, 4U, ".wav") == 0) || (l.size() > 5U && l.compare(l.size() - 5U, 5U, ".wave") == 0);
}
std::string withoutExt(const std::string& n) {
    const std::size_t dot = n.rfind('.');
    return dot == std::string::npos ? n : n.substr(0U, dot);
}
std::string join(const std::string& a, const std::string& b) { return a.empty() || a.back() == '/' ? a + b : a + "/" + b; }

// the LAB's other files: they are not waves of their own
bool labHelperFile(const std::string& n) {
    const std::string l = lower(n);
    return l.rfind("wavetable_c", 0) == 0 || l.rfind("preview_c", 0) == 0;
}

struct ZoneFile { int low{0}; int top{127}; std::string path; std::vector<double> cycle; };   // a file, or a cycle already read
struct Candidate { std::string name; std::vector<ZoneFile> zones; std::string why; };

// zones.txt of a KMP made into waves by the LAB: "low top original file" per line ('#' = a remark, the first line a title)
bool readZones(const std::string& dir, const std::string& zonesTxt, std::vector<ZoneFile>& out, std::string& sig, std::string& why) {
    std::ifstream in(zonesTxt);
    if (!in) { why = "zones.txt не се чете"; return false; }
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#' || line.rfind("SILVETON", 0) == 0) continue;
        std::istringstream ls(line);
        int low = 0, top = 0, orig = 0;
        std::string file;
        if (!(ls >> low >> top >> orig >> file)) continue;
        if (low < 0 || top > 127 || low > top || file.find('/') != std::string::npos) continue;
        const std::string p = join(dir, file);
        const Info i = statOf(p);
        if (!i.exists || i.dir) continue;
        sig += p + "|" + std::to_string(i.size) + "|" + std::to_string(i.mtime) + "\n";
        out.push_back({low, top, p, {}});
        if (out.size() >= static_cast<std::size_t>(kUserWaveMaxZones)) break;
    }
    std::sort(out.begin(), out.end(), [](const ZoneFile& a, const ZoneFile& b) { return a.top < b.top; });
    if (out.empty()) { why = "в zones.txt няма зони с файлове"; return false; }
    return true;
}

// one cycle of a WAV (mono); false + why when it is not one
bool readCycle(const std::string& path, long long bytes, std::vector<double>& cycle, std::string& why) {
    if (bytes > kMaxFileBytes) { why = "твърде голям файл - това не е една вълна"; return false; }
    const AudioLoadResult r = AudioFileLoader::loadWav(path);
    if (!r.ok()) { why = "не се чете (" + r.error + ")"; return false; }
    const SampleData& s = *r.sample;
    const std::size_t ch = std::max<std::size_t>(1U, s.channels);
    const std::size_t frames = s.interleaved.size() / ch;
    std::size_t use = 0U;
    if (frames >= 2048U && frames % 2048U == 0U) use = 2048U;          // a LAB file: frames of 2048, the first one
    else if (frames >= 16U && frames <= 4096U) use = frames;            // the whole file is one cycle
    if (use == 0U) { why = "не е една вълна (" + std::to_string(frames) + " проби)"; return false; }
    cycle.assign(use, 0.0);
    double peak = 0.0;
    for (std::size_t i = 0U; i < use; ++i) {
        double v = 0.0;
        for (std::size_t c = 0U; c < ch; ++c) v += static_cast<double>(s.interleaved[i * ch + c]);
        cycle[i] = v / static_cast<double>(ch);
        peak = std::max(peak, std::fabs(cycle[i]));
    }
    if (peak < 1.0e-6) { why = "тиха (няма звук)"; return false; }
    return true;
}

// the ten versions of one cycle, as the table waves have them: version lvl keeps the harmonics 1 .. 512 >> lvl.
// The harmonics are measured on the cycle itself (no resampling), the DC is dropped, the loudest point of the full
// version is +-1.
void makeTables(const std::vector<double>& x, float* dst) {
    const int len = static_cast<int>(x.size());
    const int maxH = std::min(kTabSize / 2 - 1, len / 2 - 1);   // (the half of the table length itself would be a cosine at its Nyquist)
    std::vector<double> cs(static_cast<std::size_t>(len)), sn(static_cast<std::size_t>(len));
    for (int j = 0; j < len; ++j) {
        const double th = 2.0 * kPi * static_cast<double>(j) / static_cast<double>(len);
        cs[static_cast<std::size_t>(j)] = std::cos(th);
        sn[static_cast<std::size_t>(j)] = std::sin(th);
    }
    std::vector<double> a(static_cast<std::size_t>(maxH) + 1U, 0.0), b(static_cast<std::size_t>(maxH) + 1U, 0.0);
    for (int n = 1; n <= maxH; ++n) {
        double re = 0.0, im = 0.0;
        long long idx = 0;
        for (int j = 0; j < len; ++j) {
            const auto k = static_cast<std::size_t>(idx);
            re += x[static_cast<std::size_t>(j)] * cs[k];
            im += x[static_cast<std::size_t>(j)] * sn[k];
            idx += n;
            if (idx >= len) idx -= len;
        }
        a[static_cast<std::size_t>(n)] = 2.0 * re / static_cast<double>(len);
        b[static_cast<std::size_t>(n)] = 2.0 * im / static_cast<double>(len);
    }
    std::vector<double> tc(static_cast<std::size_t>(kTabSize)), ts(static_cast<std::size_t>(kTabSize));
    for (int i = 0; i < kTabSize; ++i) {
        const double th = 2.0 * kPi * static_cast<double>(i) / static_cast<double>(kTabSize);
        tc[static_cast<std::size_t>(i)] = std::cos(th);
        ts[static_cast<std::size_t>(i)] = std::sin(th);
    }
    std::vector<double> acc(static_cast<std::size_t>(kTabLevels), 0.0);
    for (int i = 0; i < kTabSize; ++i) {
        double sum = 0.0;
        std::fill(acc.begin(), acc.end(), 0.0);
        for (int n = 1; n <= kTabSize / 2; ++n) {
            if (n <= maxH) {
                const auto k = static_cast<std::size_t>((static_cast<long long>(n) * i) % kTabSize);
                sum += a[static_cast<std::size_t>(n)] * tc[k] + b[static_cast<std::size_t>(n)] * ts[k];
            }
            for (int lvl = 0; lvl < kTabLevels; ++lvl) if (n == ((kTabSize / 2) >> lvl)) acc[static_cast<std::size_t>(lvl)] = sum;
        }
        for (int lvl = 0; lvl < kTabLevels; ++lvl) dst[static_cast<std::size_t>(lvl) * (kTabSize + 1U) + static_cast<std::size_t>(i)] = static_cast<float>(acc[static_cast<std::size_t>(lvl)]);
    }
    float peak = 1.0e-6F;
    for (int i = 0; i < kTabSize; ++i) peak = std::max(peak, std::fabs(dst[i]));
    for (int lvl = 0; lvl < kTabLevels; ++lvl) {
        float* t = dst + static_cast<std::size_t>(lvl) * (kTabSize + 1U);
        for (int i = 0; i < kTabSize; ++i) t[i] /= peak;
        t[kTabSize] = t[0];
    }
}

// SILVETON_OSC.sv - all the waves in one file, as the LAB writes it (the layout is in the LAB's OscillatorCore.h):
// "SVOSC001" | u32 waves | per wave: u16 name bytes, name, u16 zones, per zone: u8 low, u8 top, u8 original key, u8 0,
// u32 samples, f32 samples[] | "SVOSCEND" (little-endian)
bool readOscFile(const std::string& path, long long bytes, std::vector<Candidate>& out, std::string& why) {
    if (bytes < 20 || bytes > 64LL * 1024 * 1024) { why = "SILVETON_OSC.sv е с грешен размер"; return false; }
    std::ifstream in(path, std::ios::binary);
    std::vector<unsigned char> b(static_cast<std::size_t>(bytes));
    if (!in.read(reinterpret_cast<char*>(b.data()), static_cast<std::streamsize>(b.size()))) { why = "SILVETON_OSC.sv не се чете"; return false; }
    if (std::memcmp(b.data(), "SVOSC001", 8) != 0 || std::memcmp(b.data() + b.size() - 8U, "SVOSCEND", 8) != 0) {
        why = "SILVETON_OSC.sv не е от лабораторията (или е повреден)"; return false;
    }
    const std::size_t end = b.size() - 8U;
    std::size_t pos = 8U;
    bool bad = false;
    const auto need = [&](std::size_t n) { if (pos + n > end) bad = true; return !bad; };
    const auto u16 = [&]() -> unsigned { if (!need(2U)) return 0U; const unsigned v = b[pos] | (static_cast<unsigned>(b[pos + 1U]) << 8U); pos += 2U; return v; };
    const auto u32 = [&]() -> std::uint32_t {
        if (!need(4U)) return 0U;
        std::uint32_t v = 0U;
        for (std::size_t i = 0U; i < 4U; ++i) v |= static_cast<std::uint32_t>(b[pos + i]) << (8U * i);
        pos += 4U;
        return v;
    };
    const std::uint32_t waves = u32();
    for (std::uint32_t w = 0U; w < waves && !bad; ++w) {
        const unsigned nameLen = u16();
        if (!need(nameLen)) break;
        Candidate c{std::string(reinterpret_cast<const char*>(b.data() + pos), nameLen), {}, ""};
        pos += nameLen;
        const unsigned zones = u16();
        for (unsigned z = 0U; z < zones && !bad; ++z) {
            if (!need(4U)) break;
            ZoneFile zf{std::min<int>(b[pos], 127), std::min<int>(b[pos + 1U], 127), "", {}};
            pos += 4U;
            const std::uint32_t n = u32();
            if (n < 16U || n > 4096U || !need(static_cast<std::size_t>(n) * 4U)) { bad = true; break; }
            zf.cycle.resize(n);
            double peak = 0.0;
            for (std::uint32_t i = 0U; i < n; ++i) {
                const std::uint32_t u = u32();
                float f = 0.0F;
                std::memcpy(&f, &u, sizeof f);
                zf.cycle[i] = std::isfinite(f) ? static_cast<double>(f) : 0.0;
                peak = std::max(peak, std::fabs(zf.cycle[i]));
            }
            if (peak >= 1.0e-6 && zf.low <= zf.top && c.zones.size() < static_cast<std::size_t>(kUserWaveMaxZones)) c.zones.push_back(std::move(zf));
        }
        std::sort(c.zones.begin(), c.zones.end(), [](const ZoneFile& x, const ZoneFile& y) { return x.top < y.top; });
        if (c.zones.empty()) c.why = "без вълни";
        out.push_back(std::move(c));
    }
    if (bad) { why = "SILVETON_OSC.sv е отрязан или повреден"; return !out.empty(); }
    return true;
}

// SILVETON_OSC_SOUND_V1: one zone sample of a wave as a SOUND - one cycle of table `t` (its ten versions) for the octave of
// `root`, a few periods long and looped (like the built-in waves: one period = P frames at 96 kHz, the harmonics stop below
// the period's own Nyquist).
SamplePtr cycleSample(const float* t, int root, const std::string& name) {
    const double f = 440.0 * std::pow(2.0, (root - 69) / 12.0);
    const auto period = static_cast<std::size_t>(std::max(16L, std::lround(96000.0 / f)));
    const int nMax = static_cast<int>(period / 2U) - 1;
    int lvl = 0;
    while (lvl < kTabLevels - 1 && ((kTabSize / 2) >> lvl) > nMax) ++lvl;
    const float* w = t + static_cast<std::size_t>(lvl) * (kTabSize + 1U);
    constexpr std::size_t periods = 4U;
    auto s = std::make_shared<SampleData>();
    s->name = name + " " + std::to_string(root);
    s->sampleRate = static_cast<std::uint32_t>(std::lround(static_cast<double>(period) * f));
    s->channels = 1U;
    s->rootKey = static_cast<std::uint8_t>(root);
    s->interleaved.assign(period * periods, 0.0F);
    s->totalFrames = period * periods;
    s->loop.enabled = true; s->loop.startFrame = 0U; s->loop.endFrame = period * periods; s->loop.crossfadeFrames = 0U;
    std::vector<float> one(period);
    float peak = 1.0e-6F;
    for (std::size_t i = 0U; i < period; ++i) {
        const double x = static_cast<double>(i) * kTabSize / static_cast<double>(period);
        const int k = std::min(static_cast<int>(x), kTabSize - 1);
        const auto fr = static_cast<float>(x - static_cast<double>(k));
        constexpr int m = kTabSize - 1;
        const float y0 = w[(k - 1) & m], y1 = w[k], y2 = w[k + 1], y3 = w[(k + 2) & m];
        const float c1 = 0.5F * (y2 - y0), c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3, c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
        one[i] = ((c3 * fr + c2) * fr + c1) * fr + y1;
        peak = std::max(peak, std::fabs(one[i]));
    }
    for (std::size_t p = 0U; p < periods; ++p)
        for (std::size_t i = 0U; i < period; ++i) s->interleaved[p * period + i] = one[i] / peak * 0.5F;
    return s;
}

// a wave as a SOUND: for every zone of the wave and every octave in it a looped cycle sample
ProgramPtr waveProgram(const UserWaveTables& b, int k, const std::string& name) {
    const auto& zones = b.zones[static_cast<std::size_t>(k)];
    if (zones.empty()) return nullptr;
    auto ms = std::make_shared<Multisample>();
    ms->name = "U" + std::to_string(k + 1) + " " + name;
    int low = 0;
    for (const auto& z : zones) {
        const int zLow = std::max(low, 0), zTop = std::min(std::max(z.top, zLow), 127);
        for (int root = 12; root <= 120; root += 12) {
            const int rLow = root == 12 ? 0 : root - 6, rTop = root == 120 ? 127 : root + 5;
            const int a = std::max(zLow, rLow), e = std::min(zTop, rTop);
            if (a > e) continue;
            SampleZone sz{};
            sz.sample = cycleSample(b.table(z.table, 0), root, ms->name);
            sz.rootKey = static_cast<std::uint8_t>(root);
            sz.keyLow = static_cast<std::uint8_t>(a);
            sz.keyHigh = static_cast<std::uint8_t>(e);
            sz.velocityLow = 1U; sz.velocityHigh = 127U;
            ms->zones.push_back(sz);
        }
        low = zTop + 1;
        if (low > 127) break;
    }
    if (ms->zones.empty()) return nullptr;
    auto prog = std::make_shared<Program>();
    prog->name = ms->name;
    ProgramLayer layer{};
    layer.name = prog->name;
    layer.multisample = ms;
    layer.ampEnvelope = EnvelopeParams{0.003F, 0.05F, 1.0F, 0.08F};
    prog->layers.push_back(layer);
    return prog;
}

} // namespace

ProgramPtr userWaveProgram(int k) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (k < 0 || k >= kUserWaveCount) return nullptr;
    return gPrograms[static_cast<std::size_t>(k)];
}

UserWaveReport loadUserWaves(const std::string& folder) {
    UserWaveReport rep;
    rep.folder = folder;
    const Info fi = statOf(folder);
    rep.folderFound = fi.exists;   // the file SILVETON_OSC.sv or the folder SILVETON_OSC
    std::vector<Candidate> cands;
    std::string signature = folder + "\n";
    if (fi.exists && !fi.dir) {
        signature += std::to_string(fi.size) + "|" + std::to_string(fi.mtime) + "\n";
        std::string why;
        if (!readOscFile(folder, fi.size, cands, why) || !why.empty()) rep.skipped.push_back(why);
    } else if (rep.folderFound) {
        std::vector<std::string> names = listDir(folder);
        std::sort(names.begin(), names.end(), [](const std::string& x, const std::string& y) {
            const std::string lx = lower(x), ly = lower(y);
            return lx != ly ? lx < ly : x < y;
        });
        for (const std::string& n : names) {
            const std::string p = join(folder, n);
            const Info i = statOf(p);
            if (i.dir) {
                // a KMP made into waves by the LAB: one wave per zone (zones.txt)
                std::string zonesTxt;
                for (const std::string& f : listDir(p)) if (lower(f) == "zones.txt") zonesTxt = join(p, f);
                if (!zonesTxt.empty()) {
                    Candidate c{n, {}, ""};
                    const Info zi = statOf(zonesTxt);
                    signature += zonesTxt + "|" + std::to_string(zi.size) + "|" + std::to_string(zi.mtime) + "\n";
                    readZones(p, zonesTxt, c.zones, signature, c.why);
                    cands.push_back(c);
                    continue;
                }
                // a LAB folder: its wavetable (first frame) or its single cycle
                std::string pick;
                for (const std::string& want : {std::string("wavetable_2048.wav"), std::string("single_cycle.wav")}) {
                    for (const std::string& f : listDir(p)) {
                        if (lower(f) == want) { pick = join(p, f); break; }
                    }
                    if (!pick.empty()) break;
                }
                if (pick.empty()) { cands.push_back({n, {}, "в папката няма single_cycle.wav / wavetable_2048.wav / zones.txt"}); continue; }
                const Info pi = statOf(pick);
                signature += pick + "|" + std::to_string(pi.size) + "|" + std::to_string(pi.mtime) + "\n";
                cands.push_back({n, {{0, 127, pick, {}}}, ""});
            } else if (i.exists && isWavName(n)) {
                if (labHelperFile(n)) { cands.push_back({withoutExt(n), {}, "помощен файл на лабораторията - сложи цялата ѝ папка"}); continue; }
                signature += p + "|" + std::to_string(i.size) + "|" + std::to_string(i.mtime) + "\n";
                cands.push_back({withoutExt(n), {{0, 127, p, {}}}, ""});
            }
        }
    }

    std::lock_guard<std::mutex> lock(gMutex);
    if (signature == gSignature) return gReport;   // nothing changed: the waves stay as they are
    auto bank = std::make_unique<UserWaveTables>();
    // first every cycle is read (the number of tables is known only then), then the tables are made
    struct Ready { int wave; int low; int top; std::vector<double> cycle; };
    std::vector<Ready> ready;
    int k = 0;
    for (const Candidate& c : cands) {
        if (!c.why.empty()) { rep.skipped.push_back(c.name + " - " + c.why); continue; }
        if (k >= kUserWaveCount) { rep.skipped.push_back(c.name + " - местата са само 16"); continue; }
        std::size_t got = 0U;
        std::string firstWhy;
        for (const ZoneFile& z : c.zones) {
            Ready r{k, z.low, z.top, {}};
            std::string why;
            if (z.path.empty()) r.cycle = z.cycle;   // from SILVETON_OSC.sv
            else if (!readCycle(z.path, statOf(z.path).size, r.cycle, why)) { if (firstWhy.empty()) firstWhy = why; continue; }
            ready.push_back(std::move(r));
            ++got;
        }
        if (got == 0U) { rep.skipped.push_back(c.name + " - " + firstWhy); continue; }
        if (got < c.zones.size()) rep.skipped.push_back(c.name + " - " + std::to_string(c.zones.size() - got) + " зони без вълна (" + firstWhy + ")");
        rep.names.push_back(c.name);
        rep.zoneCounts.push_back(static_cast<int>(got));
        ++k;
    }
    bank->t.assign(ready.size() * static_cast<std::size_t>(kTabLevels) * (kTabSize + 1U), 0.0F);
    for (std::size_t i = 0U; i < ready.size(); ++i) {
        makeTables(ready[i].cycle, const_cast<float*>(bank->table(static_cast<int>(i), 0)));
        auto& zs = bank->zones[static_cast<std::size_t>(ready[i].wave)];
        zs.push_back({ready[i].low, ready[i].top, static_cast<int>(i)});
        bank->present[static_cast<std::size_t>(ready[i].wave)] = true;
    }
    const UserWaveTables* published = nullptr;
    gPrograms.fill(nullptr);
    if (k > 0) {
        for (int w = 0; w < k; ++w) gPrograms[static_cast<std::size_t>(w)] = waveProgram(*bank, w, rep.names[static_cast<std::size_t>(w)]);   // SILVETON_OSC_SOUND_V1
        published = bank.get();
        gKeep.push_back(std::move(bank));
    }
    userWaveTables().store(published, std::memory_order_release);
    gSignature = signature;
    gReport = rep;
    return rep;
}

UserWaveReport userWaveReport() {
    std::lock_guard<std::mutex> lock(gMutex);
    return gReport;
}

std::string userWaveName(int k) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (k < 0 || static_cast<std::size_t>(k) >= gReport.names.size()) return {};
    return gReport.names[static_cast<std::size_t>(k)];
}

} // namespace silveton::sampler
