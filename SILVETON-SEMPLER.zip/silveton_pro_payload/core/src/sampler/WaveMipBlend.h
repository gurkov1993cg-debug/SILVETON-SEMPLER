// SILVETON_WAVE_MIP_SMOOTH_V1
// Independent, allocation-free wavetable mip transitions. The richer table is
// used only when ALL of its harmonics lie inside the existing 0.45*Fs guard.
#pragma once

#include <algorithm>
#include <cmath>

namespace eng {

struct WaveMipChoice {
    int level;
    float highWeight;  // weight of this level; (1 - highWeight) belongs to level+1
};

inline WaveMipChoice waveMipChoice(double increment, int tableSize, int levels) noexcept {
    const double allowedHarmonics = 0.45 / std::max(increment, 1.0e-6);
    int level = 0;
    while (level < levels - 1 && static_cast<double>((tableSize / 2) >> level) > allowedHarmonics) ++level;
    if (level == levels - 1) return {level, 1.0F};
    const double currentHarmonics = static_cast<double>((tableSize / 2) >> level);
    // Fade in the extra harmonics within [H, 1.35H]. At H the lower-harmonic
    // table is the only active one, so crossing to the next mip is continuous.
    // Beyond 1.35H there is no second read and no extra audio-thread cost.
    const double t = std::clamp((allowedHarmonics / currentHarmonics - 1.0) / 0.35, 0.0, 1.0);
    return {level, static_cast<float>(t * t * (3.0 - 2.0 * t))};
}

// Circular Catmull-Rom interpolation. All tables have a duplicated last point
// and a power-of-two size; no state, allocations or branch-dependent memory.
inline float waveMipCubic(const float* table, double phase, int tableSize) noexcept {
    const double x = (phase - std::floor(phase)) * static_cast<double>(tableSize);
    const int i = std::min(static_cast<int>(x), tableSize - 1);
    const float f = static_cast<float>(x - static_cast<double>(i));
    const int mask = tableSize - 1;
    const float y0 = table[(i - 1) & mask], y1 = table[i], y2 = table[i + 1], y3 = table[(i + 2) & mask];
    const float c1 = 0.5F * (y2 - y0);
    const float c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3;
    const float c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
    return ((c3 * f + c2) * f + c1) * f + y1;
}

inline float waveMipRead(const float* high, const float* low, double phase,
                         float highWeight, int tableSize) noexcept {
    const float a = waveMipCubic(high, phase, tableSize);
    if (highWeight >= 1.0F || low == nullptr) return a;
    const float b = waveMipCubic(low, phase, tableSize);
    // Explicit normalization to unity at both ends; no level pumping.
    return b + (a - b) * highWeight;
}

} // namespace eng
