// SILVETON_TRANSWAVE_V1 - cutting single-cycle frames out of the user's recordings (control thread only).
#include "silveton/sampler/WaveTable.h"

#include "silveton/sampler/SampleStream.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace silveton::sampler {
namespace {

constexpr double kPi = 3.14159265358979323846;

// Read access to the frames of one recording: the whole file through the mapped memory when there is one, else what is in RAM.
struct Src {
    const SampleData* s{nullptr};
    RawPcmView raw{};
    std::int64_t frames{0};
    int channels{1};

    explicit Src(const SampleData& sample) : s(&sample) {
        channels = std::clamp<int>(sample.channels, 1, 2);
        frames = static_cast<std::int64_t>(sample.frameCount());
        if (sample.stream != nullptr) {
            raw = sample.stream->rawView();
            if (raw.data != nullptr && (raw.channels < 1U || raw.format == RawPcmView::kNone)) raw = RawPcmView{};
        }
        if (raw.data != nullptr) frames = std::min<std::int64_t>(frames > 0 ? frames : static_cast<std::int64_t>(raw.frames), static_cast<std::int64_t>(raw.frames));
    }

    [[nodiscard]] float at(std::int64_t f, int c) const noexcept {
        if (f < 0 || f >= frames) return 0.0F;
        if (raw.data != nullptr) {
            const int cc = std::min<int>(c, static_cast<int>(raw.channels) - 1);
            const std::uint8_t* p = raw.data + static_cast<std::size_t>(f) * raw.frameBytes() + static_cast<std::size_t>(cc) * raw.bytesPerSample();
            if (raw.format == RawPcmView::kPcm16) {
                const auto v = static_cast<std::int16_t>(static_cast<std::uint16_t>(p[0]) | static_cast<std::uint16_t>(p[1]) << 8U);
                return static_cast<float>(v) * (1.0F / 32768.0F);
            }
            if (raw.format == RawPcmView::kPcm24) {
                std::int32_t v = static_cast<std::int32_t>(static_cast<std::uint32_t>(p[0]) | static_cast<std::uint32_t>(p[1]) << 8U | static_cast<std::uint32_t>(p[2]) << 16U);
                if ((v & 0x800000) != 0) v -= 0x1000000;
                return static_cast<float>(v) * (1.0F / 8388608.0F);
            }
            float v = 0.0F;
            std::memcpy(&v, p, sizeof v);
            return v;
        }
        const std::uint64_t pre = s->preloadedFrameCount();
        if (static_cast<std::uint64_t>(f) < pre) {
            const int cc = std::min(c, static_cast<int>(s->channels) - 1);
            return s->interleaved[static_cast<std::size_t>(f) * s->channels + static_cast<std::size_t>(cc)];
        }
        if (s->stream != nullptr) return s->stream->readFrame(static_cast<std::uint64_t>(f), static_cast<std::uint16_t>(std::min(c, static_cast<int>(s->stream->channels()) - 1)));
        return 0.0F;
    }

    [[nodiscard]] float mono(std::int64_t f) const noexcept {
        return channels == 2 ? 0.5F * (at(f, 0) + at(f, 1)) : at(f, 0);
    }

    // 4-point Hermite
    [[nodiscard]] float read(double pos, int c) const noexcept {
        const auto i = static_cast<std::int64_t>(std::floor(pos));
        const auto t = static_cast<float>(pos - static_cast<double>(i));
        const float y0 = at(i - 1, c), y1 = at(i, c), y2 = at(i + 1, c), y3 = at(i + 2, c);
        const float c1 = 0.5F * (y2 - y0);
        const float c2 = y0 - 2.5F * y1 + 2.0F * y2 - 0.5F * y3;
        const float c3 = 0.5F * (y3 - y0) + 1.5F * (y1 - y2);
        return ((c3 * t + c2) * t + c1) * t + y1;
    }

    [[nodiscard]] float readMono(double pos) const noexcept {
        return channels == 2 ? 0.5F * (read(pos, 0) + read(pos, 1)) : read(pos, 0);
    }
};

// Period of the recording in frames: the expected one (from the root key) refined by autocorrelation near `centre`.
double estimatePeriod(const Src& s, double expected, double centre) {
    if (expected < 4.0 || expected > 20000.0) return 0.0;
    const double window = std::min(6.0 * expected, 0.5 * static_cast<double>(s.frames));
    if (window < 2.5 * expected) return expected;
    double a = centre - window * 0.5;
    a = std::clamp(a, 0.0, static_cast<double>(s.frames) - window - 2.0 * expected);
    if (a < 0.0) a = 0.0;
    const int dec = std::max(1, static_cast<int>(expected / 96.0));
    const auto n = static_cast<std::int64_t>(window / dec);
    if (n < 16) return expected;
    std::vector<float> x(static_cast<std::size_t>(n) + static_cast<std::size_t>(std::ceil(1.2 * expected / dec)) + 4U);
    for (std::size_t i = 0; i < x.size(); ++i) x[i] = s.mono(static_cast<std::int64_t>(a) + static_cast<std::int64_t>(i) * dec);
    const int lagLo = std::max(2, static_cast<int>(std::floor(expected * 0.9 / dec)));
    const int lagHi = static_cast<int>(std::ceil(expected * 1.1 / dec));
    double e0 = 0.0;
    for (std::int64_t i = 0; i < n; ++i) e0 += static_cast<double>(x[static_cast<std::size_t>(i)]) * x[static_cast<std::size_t>(i)];
    if (e0 < 1.0e-9) return expected;
    std::vector<double> r(static_cast<std::size_t>(lagHi - lagLo + 3), 0.0);
    int best = -1;
    double bestR = -1.0;
    for (int lag = lagLo - 1; lag <= lagHi + 1; ++lag) {
        double num = 0.0, e1 = 0.0;
        for (std::int64_t i = 0; i < n; ++i) {
            const double y = x[static_cast<std::size_t>(i) + static_cast<std::size_t>(lag)];
            num += static_cast<double>(x[static_cast<std::size_t>(i)]) * y;
            e1 += y * y;
        }
        const double v = (e1 > 1.0e-12) ? num / std::sqrt(e0 * e1) : 0.0;
        r[static_cast<std::size_t>(lag - lagLo + 1)] = v;
        if (lag >= lagLo && lag <= lagHi && v > bestR) { bestR = v; best = lag; }
    }
    if (best < 0 || bestR < 0.25) return expected;
    const auto idx = static_cast<std::size_t>(best - lagLo + 1);
    const double ym = r[idx - 1], y0 = r[idx], yp = r[idx + 1];
    const double den = ym - 2.0 * y0 + yp;
    const double off = std::abs(den) > 1.0e-12 ? std::clamp(0.5 * (ym - yp) / den, -1.0, 1.0) : 0.0;
    double period = (static_cast<double>(best) + off) * dec;
    if (dec > 1) {   // the decimated search is coarse: look again at full resolution around it
        double bestFine = -2.0, bestLag = period;
        for (double lag = period - dec; lag <= period + dec; lag += 0.5) {
            double num = 0.0, e1 = 0.0, e2 = 0.0;
            const auto m = static_cast<std::int64_t>(std::min(window, 3.0 * expected));
            for (std::int64_t i = 0; i < m; i += 2) {
                const double p = a + static_cast<double>(i);
                const double u = s.readMono(p), w = s.readMono(p + lag);
                num += u * w; e1 += u * u; e2 += w * w;
            }
            const double v = (e1 > 1.0e-12 && e2 > 1.0e-12) ? num / std::sqrt(e1 * e2) : 0.0;
            if (v > bestFine) { bestFine = v; bestLag = lag; }
        }
        period = bestLag;
    }
    if (period < expected * 0.85 || period > expected * 1.15) return expected;
    return period;
}

double expectedPeriod(const SampleZone& zone) {
    const SampleData& sd = *zone.sample;
    const double rootHz = 440.0 * std::pow(2.0, (static_cast<double>(zone.rootKey) - 69.0) / 12.0) *
                          std::pow(2.0, -static_cast<double>(zone.tuneCents + sd.fineTuneCents) / 1200.0);
    return static_cast<double>(sd.sampleRate) / std::max(1.0, rootHz);
}

// The start of a cycle moved to the next rising zero crossing, so neighbouring frames start in a similar phase.
double alignStart(const Src& s, double start, double period) {
    const auto first = static_cast<std::int64_t>(std::floor(start));
    const auto last = static_cast<std::int64_t>(std::ceil(start + period));
    float prev = s.mono(first);
    for (std::int64_t i = first; i < last; ++i) {
        const float next = s.mono(i + 1);
        if (prev <= 0.0F && next > 0.0F) {
            const double frac = static_cast<double>(-prev) / static_cast<double>(next - prev);
            return static_cast<double>(i) + frac;
        }
        prev = next;
    }
    return start;
}

struct FramePlan {
    const SampleData* sample{nullptr};
    double start{0.0};
    double period{0.0};
};

std::uint64_t fnv(std::uint64_t h, const void* data, std::size_t n) noexcept {
    const auto* p = static_cast<const std::uint8_t*>(data);
    for (std::size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}
template <class T> std::uint64_t fnvv(std::uint64_t h, const T& v) noexcept { return fnv(h, &v, sizeof v); }

int clampFrames(const ToneExtra& x) noexcept { return std::clamp<int>(x.waveFrames, 2, kWaveMaxFrames); }

} // namespace

const SampleZone* waveSourceZone(const Program& program, int key) noexcept {
    const SampleZone* first = nullptr;
    for (const auto& layer : program.layers) {
        if (!layer.enabled || layer.multisample == nullptr) continue;
        for (const auto& z : layer.multisample->zones) {
            if (z.sample == nullptr || !z.sample->valid()) continue;
            if (first == nullptr) first = &z;
            if (z.matches(static_cast<std::uint8_t>(std::clamp(key, 0, 127)), 100U)) return &z;
        }
    }
    return first;
}

std::uint64_t waveKey(const SampleZone& zone, const ToneExtra& x) noexcept {
    if (x.waveMode != kWaveModeAuto && x.waveMode != kWaveModeMulti) return 0U;
    if (zone.sample == nullptr || !zone.sample->valid()) return 0U;
    std::uint64_t h = 1469598103934665603ULL;
    h = fnvv(h, static_cast<int>(x.waveMode));
    h = fnvv(h, static_cast<const void*>(zone.sample.get()));
    h = fnvv(h, zone.rootKey);
    h = fnvv(h, zone.tuneCents);
    h = fnvv(h, zone.sample->fineTuneCents);
    h = fnvv(h, x.waveStart);
    if (x.waveMode == kWaveModeAuto) {
        h = fnvv(h, x.waveSpan);
        h = fnvv(h, clampFrames(x));
    } else {
        if (x.waveSources == nullptr) return 0U;
        int found = 0;
        for (int i = 0; i < kWaveSlots; ++i) {
            const auto idx = static_cast<std::size_t>(i);
            if (x.waveSlot[idx] == 0U || idx >= x.waveSources->size() || (*x.waveSources)[idx] == nullptr) continue;
            const SampleZone* z = waveSourceZone(*(*x.waveSources)[idx], zone.rootKey);
            if (z == nullptr) continue;
            h = fnvv(h, static_cast<const void*>(z->sample.get()));
            h = fnvv(h, z->rootKey);
            h = fnvv(h, z->tuneCents);
            ++found;
        }
        if (found < 2) return 0U;
    }
    return h == 0U ? 1U : h;
}

WaveTablePtr buildWaveTable(const SampleZone& zone, const ToneExtra& x) {
    if (waveKey(zone, x) == 0U) return nullptr;
    std::vector<FramePlan> plan;
    int channels = std::clamp<int>(zone.sample->channels, 1, 2);
    if (x.waveMode == kWaveModeAuto) {
        const Src src(*zone.sample);
        const double total = static_cast<double>(src.frames);
        const double p0 = expectedPeriod(zone);
        if (total < 8.0 || p0 < 4.0 || p0 > 20000.0) return nullptr;
        const double a = std::clamp(static_cast<double>(x.waveStart), 0.0, 1.0) * total;
        double len = std::clamp(static_cast<double>(x.waveSpan), 0.0, 1.0) * total;
        len = std::max(len, 2.5 * p0);
        const double period = estimatePeriod(src, p0, a + std::min(len, total - a) * 0.5);
        if (period < 4.0) return nullptr;
        const int n = clampFrames(x);
        const double usable = std::max(0.0, std::min(len, total - a) - 1.3 * period);
        for (int k = 0; k < n; ++k) {
            FramePlan f;
            f.sample = zone.sample.get();
            f.period = period;
            f.start = std::max(0.0, std::min(a + usable * static_cast<double>(k) / static_cast<double>(n - 1), total - 1.3 * period));
            plan.push_back(f);
        }
    } else {
        if (x.waveSources == nullptr) return nullptr;
        for (int i = 0; i < kWaveSlots; ++i) {
            const auto idx = static_cast<std::size_t>(i);
            if (x.waveSlot[idx] == 0U || idx >= x.waveSources->size() || (*x.waveSources)[idx] == nullptr) continue;
            const SampleZone* z = waveSourceZone(*(*x.waveSources)[idx], zone.rootKey);
            if (z == nullptr) continue;
            const Src src(*z->sample);
            const double total = static_cast<double>(src.frames);
            const double p0 = expectedPeriod(*z);
            if (total < 8.0 || p0 < 4.0 || p0 > 20000.0) continue;
            const double a = std::clamp(static_cast<double>(x.waveStart), 0.0, 1.0) * std::max(0.0, total - 1.3 * p0);
            const double period = estimatePeriod(src, p0, a + 1.5 * p0);
            if (period < 4.0) continue;
            FramePlan f;
            f.sample = z->sample.get();
            f.period = period;
            f.start = a;
            plan.push_back(f);
            channels = std::max(channels, std::clamp<int>(z->sample->channels, 1, 2));
        }
        if (plan.size() < 2U) return nullptr;
    }
    double pmax = 0.0;
    for (const auto& f : plan) pmax = std::max(pmax, f.period);
    int length = 128;
    while (length < pmax && length < 2048) length <<= 1;
    const auto frames = static_cast<int>(plan.size());
    if (static_cast<std::size_t>(frames) * static_cast<std::size_t>(length) * static_cast<std::size_t>(channels) > 4U * 1024U * 1024U) return nullptr;

    auto table = std::make_shared<WaveTable>();
    table->frames = frames;
    table->length = length;
    table->channels = channels;
    table->data.assign(static_cast<std::size_t>(frames) * static_cast<std::size_t>(length) * static_cast<std::size_t>(channels), 0.0F);
    std::vector<double> rms(plan.size(), 0.0);
    for (int k = 0; k < frames; ++k) {
        const FramePlan& f = plan[static_cast<std::size_t>(k)];
        const Src src(*f.sample);
        const double s0 = alignStart(src, f.start, f.period);
        float* out = table->data.data() + static_cast<std::size_t>(k) * static_cast<std::size_t>(length) * static_cast<std::size_t>(channels);
        double sumSq = 0.0;
        for (int c = 0; c < channels; ++c) {
            const int sc = std::min(c, src.channels - 1);
            const float endGap = src.read(s0 + f.period, sc) - src.read(s0, sc);
            double mean = 0.0;
            for (int j = 0; j < length; ++j) {
                float v = src.read(s0 + f.period * static_cast<double>(j) / static_cast<double>(length), sc);
                v -= endGap * static_cast<float>(j) / static_cast<float>(length);   // the end meets the start: a clean cycle
                out[static_cast<std::size_t>(j) * static_cast<std::size_t>(channels) + static_cast<std::size_t>(c)] = v;
                mean += static_cast<double>(v);
            }
            mean /= static_cast<double>(length);
            for (int j = 0; j < length; ++j) {
                float& v = out[static_cast<std::size_t>(j) * static_cast<std::size_t>(channels) + static_cast<std::size_t>(c)];
                v -= static_cast<float>(mean);
                sumSq += static_cast<double>(v) * static_cast<double>(v);
            }
        }
        rms[static_cast<std::size_t>(k)] = std::sqrt(sumSq / static_cast<double>(length * channels));
    }
    // every frame the same loudness (the loudness belongs to the envelope), at the average of the frames
    double target = 0.0;
    int counted = 0;
    for (const double r : rms) if (r > 1.0e-6) { target += r; ++counted; }
    if (counted == 0) return nullptr;
    target /= counted;
    for (int k = 0; k < frames; ++k) {
        const double r = rms[static_cast<std::size_t>(k)];
        const float g = r > 1.0e-6 ? static_cast<float>(std::clamp(target / r, 0.25, 4.0)) : 1.0F;
        float* out = table->data.data() + static_cast<std::size_t>(k) * static_cast<std::size_t>(length) * static_cast<std::size_t>(channels);
        for (int j = 0; j < length * channels; ++j) out[j] *= g;
    }
    return table;
}

std::shared_ptr<const WaveTableMap> WaveTableCache::refresh(const EngineState& state) {
    auto next = std::make_shared<WaveTableMap>();
    std::size_t totalFloats = 0;
    const auto visit = [&](const ToneExtra& x, const ProgramPtr& program) {
        if (x.waveMode == kWaveModeOff || program == nullptr) return;
        for (const auto& layer : program->layers) {
            if (!layer.enabled || layer.multisample == nullptr) continue;
            for (const auto& zone : layer.multisample->zones) {
                const std::uint64_t key = waveKey(zone, x);
                if (key == 0U || next->count(key) != 0U) continue;
                WaveTablePtr table;
                const auto old = cache_.find(key);
                if (old != cache_.end()) table = old->second;
                else if (totalFloats < 64U * 1024U * 1024U) table = buildWaveTable(zone, x);
                if (table != nullptr) totalFloats += table->data.size();
                (*next)[key] = table;
            }
        }
    };
    for (const auto& u : state.combi.uppers) {
        visit(u.toneExtra, u.program);
        for (const auto& l : u.layers) if (l.enabled) visit(l.tone.x, l.program);
    }
    cache_ = *next;
    if (next->empty()) return nullptr;
    return next;
}

} // namespace silveton::sampler
