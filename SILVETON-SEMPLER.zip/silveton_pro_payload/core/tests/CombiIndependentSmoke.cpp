#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SetPackage.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
#include <memory>
#include <vector>
using namespace silveton::sampler;

static float measure(bool independent, std::uint8_t fadeIn=0U) {
    auto state=std::make_shared<EngineState>();
    auto& upper=state->combi.uppers[0];
    upper.enabled=true;
    upper.midiChannel=0U;
    upper.program=builtinWaveProgram(4);
    upper.velocityLow=1U; upper.velocityHigh=20U;
    upper.independentLayerRanges=independent;
    auto& l=upper.layers[0];
    l.enabled=true;l.program=builtinWaveProgram(4);
    l.velocityLow=64U;l.velocityHigh=127U;
    l.velocityFadeIn=fadeIn;
    SamplerEngine e;
    e.prepare(48000.0,128U);
    e.setState(state);
    e.postNoteOn(0U,69U,70U);
    std::vector<float> out(256U,0.0F);
    e.render(out.data(),128U);
    float sum=0.0F;
    for(float x:out)sum+=std::abs(x);
    return sum;
}
// SILVETON_VELOCITY_FADE_NO_HOLE_V1: FADE IN / FADE OUT are the crossfade with a NEIGHBOUR sound of the Upper. One Upper,
// ОСНОВЕН + L1 (the same wave, in phase - their levels add up linearly).
struct Setup { int baseLo=1, baseHi=20; int l1Lo=64, l1Hi=127; std::uint8_t l1In=0U, l1Out=0U, baseOut=0U; bool l1On=true; bool independent=true; bool crossfade=false; };
static float level(const Setup& c, std::uint8_t vel) {
    auto state=std::make_shared<EngineState>();
    auto& upper=state->combi.uppers[0];
    upper.enabled=true; upper.midiChannel=0U; upper.program=builtinWaveProgram(4);
    upper.velocityLow=static_cast<std::uint8_t>(c.baseLo); upper.velocityHigh=static_cast<std::uint8_t>(c.baseHi);
    upper.velocityFadeOut=c.baseOut; upper.independentLayerRanges=c.independent; upper.velocityShape.crossfade=c.crossfade;
    auto& l=upper.layers[0];
    l.enabled=c.l1On; l.program=builtinWaveProgram(4);
    l.velocityLow=static_cast<std::uint8_t>(c.l1Lo); l.velocityHigh=static_cast<std::uint8_t>(c.l1Hi);
    l.velocityFadeIn=c.l1In; l.velocityFadeOut=c.l1Out; l.velocityShape.crossfade=c.crossfade;
    SamplerEngine e; e.prepare(48000.0,128U); e.setState(state); e.postNoteOn(0U,69U,vel);
    std::vector<float> out(256U,0.0F); e.render(out.data(),128U);
    float sum=0.0F; for(float x:out) sum+=std::abs(x); return sum;
}
static bool near(float a, float b, float tol) { return std::abs(a-b) <= tol*std::max(std::abs(a),std::abs(b)); }

int main() {
    const float independent=measure(true);
    const float linked=measure(false);
    const float faded=measure(true,32U);
    std::cout<<"Independent="<<independent<<" linked="<<linked<<" faded="<<faded<<"\n";
    assert(independent > 0.001F); // L1 is audible outside ОСНОВЕН velocity range.
    assert(linked < 0.0001F);     // Legacy linked mode gates the whole Upper.
    // 1. one sound alone at this strength: there is nothing to cross into - no hole, it plays at full level (user request 27.10.2026)
    assert(near(faded, independent, 0.01F));

    // 2. two overlapping sounds: ОСНОВЕН 1..90 and L1 64..127 with FADE IN 32 - at 70 L1 comes in at (70 - 64 + 1) / 32
    Setup s; s.baseHi=90;
    Setup off=s; off.l1On=false;
    const float base=level(off,70U), full=level(s,70U);
    Setup in=s; in.l1In=32U;
    const float withIn=level(in,70U);
    const float partIn=(withIn-base)/(full-base);
    std::cout<<"fade in part="<<partIn<<" (expected "<<(7.0F/32.0F)<<")\n";
    assert(full > base*1.5F && near(partIn, 7.0F/32.0F, 0.05F));
    // 3. FADE OUT the same way: ОСНОВЕН 1..127, L1 64..127 with FADE OUT 32 - at 120 L1 is at (127 - 120 + 1) / 32
    Setup so; so.baseHi=127; so.l1Out=32U;
    Setup soOff=so; soOff.l1On=false; Setup soFull=so; soFull.l1Out=0U;
    const float partOut=(level(so,120U)-level(soOff,120U))/(level(soFull,120U)-level(soOff,120U));
    std::cout<<"fade out part="<<partOut<<" (expected "<<(8.0F/32.0F)<<")\n";
    assert(near(partOut, 8.0F/32.0F, 0.05F));
    // 4. no jump at the edges: at the bottom of L1's FADE IN the sum is just ОСНОВЕН + a little of L1, never louder than both
    { const float b64=level(off,64U), f64=level(s,64U), i64=level(in,64U); assert(i64 <= f64*1.001F && i64 >= b64*0.999F); }
    // 5. CROSSFADE on both: ОСНОВЕН fades out, L1 fades in - where both would add above 1 the pair is brought back to 1,
    //    so the overlap is never louder than one sound alone
    Setup xf; xf.baseHi=127; xf.baseOut=32U; xf.l1In=32U; xf.crossfade=true;
    Setup single=xf; single.l1On=false; single.baseOut=0U;
    const float one=level(single,110U), both=level(xf,110U);
    std::cout<<"crossfade one="<<one<<" both="<<both<<"\n";
    assert(both <= one*1.01F && both >= one*0.5F);
    // 6. the Upper's own range: velocities outside every range are silent (an empty zone stays empty)
    Setup gap; gap.baseHi=40; gap.l1Lo=80;
    assert(level(gap,60U) < 1.0e-4F);
    std::cout<<"velocity fade checks passed\n";
}
