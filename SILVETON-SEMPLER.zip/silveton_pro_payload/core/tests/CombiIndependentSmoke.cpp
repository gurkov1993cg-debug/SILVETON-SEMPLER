#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SetPackage.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
#include <memory>
#include <vector>
using namespace silveton::sampler;

static float measure(bool independent, std::uint8_t fadeIn=0U) {
    auto state=std::make_shared<EngineState>();
    auto& upper=state->combi.uppers[0];
    upper.enabled=true;
    upper.midiChannel=0U;
    upper.program=builtinWaveProgram(4);
    upper.velocityLow=1U; upper.velocityHigh=20U;
    upper.independentLayerRanges=independent;
    auto& l=upper.layers[0];
    l.enabled=true;l.program=builtinWaveProgram(4);
    l.velocityLow=64U;l.velocityHigh=127U;
    l.velocityFadeIn=fadeIn;
    SamplerEngine e;
    e.prepare(48000.0,128U);
    e.setState(state);
    e.postNoteOn(0U,69U,70U);
    std::vector<float> out(256U,0.0F);
    e.render(out.data(),128U);
    float sum=0.0F;
    for(float x:out)sum+=std::abs(x);
    return sum;
}
int main() {
    const float independent=measure(true);
    const float linked=measure(false);
    const float faded=measure(true,32U);
    std::cout<<"Independent="<<independent<<" linked="<<linked<<" faded="<<faded<<"\n";
    assert(independent > 0.001F); // L1 is audible outside ОСНОВЕН velocity range.
    assert(linked < 0.0001F);     // Legacy linked mode gates the whole Upper.
    assert(faded > 0.0F && faded < independent*0.4F);
}
