#include "silveton/sampler/SamplerEngine.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <vector>

using namespace silveton::sampler;

namespace {
constexpr double kPi = 3.14159265358979323846;
constexpr double kRate = 96000.0;
constexpr std::uint32_t kBlock = 96U;
using Block = std::array<float, kBlock * 2U>;

std::shared_ptr<SampleData> sineSample(bool stereo = false, std::uint64_t loopStart = 0U,
                                       std::uint32_t crossfade = 0U, bool badSeam = false) {
    auto s = std::make_shared<SampleData>();
    s->sampleRate = 48000U; s->channels = stereo ? 2U : 1U; s->rootKey = 69U;
    s->totalFrames = loopStart + 4800U;
    s->loop = {true, loopStart, s->totalFrames, crossfade};
    s->interleaved.resize(static_cast<std::size_t>(s->totalFrames) * s->channels);
    for (std::uint64_t f = 0U; f < s->totalFrames; ++f) {
        const double phase = 2.0 * kPi * 440.0 * static_cast<double>(f) / s->sampleRate;
        const double seamOffset = badSeam && f >= loopStart + 2400U ? 0.6 : 0.0;
        s->interleaved[static_cast<std::size_t>(f) * s->channels] = static_cast<float>(0.4 * std::sin(phase) + seamOffset);
        if (stereo) s->interleaved[static_cast<std::size_t>(f) * 2U + 1U] = static_cast<float>(0.2 * std::cos(phase) - 0.5 * seamOffset);
    }
    return s;
}

std::shared_ptr<EngineState> stateFor(const SamplePtr& sample) {
    auto ms = std::make_shared<Multisample>();
    SampleZone z; z.sample = sample; z.rootKey = sample->rootKey; ms->zones.push_back(z);
    auto p = std::make_shared<Program>();
    ProgramLayer l; l.multisample = ms; l.ampEnvelope = {0.0F, 0.0F, 1.0F, 0.02F}; p->layers.push_back(l);
    auto s = std::make_shared<EngineState>();
    auto& u = s->combi.uppers[0]; u.program = p; u.enabled = true; u.midiChannel = 0U; u.breathEnabled = false;
    s->global.masterGainDb = 0.0F;
    return s;
}

void renderBlocks(SamplerEngine& e, int blocks) {
    Block out{};
    for (int b = 0; b < blocks; ++b) e.render(out.data(), kBlock);
}

void testFilteredReleases() {
    // Every combination is a real active note/pedal followed by a live filter
    // change; unlike a filter-before-NoteOn test this detects a stuck note.
    for (int filter = 0; filter < 3; ++filter) {
        for (bool zeroVelocity : {false, true}) {
            SamplerEngine e; e.prepare(kRate, kBlock);
            auto s = stateFor(sineSample()); e.setState(s);
            assert(e.postNoteOn(0U, 69U, 100U)); renderBlocks(e, 5);
            assert(e.activeVoiceCount() == 1U);
            auto n = std::make_shared<EngineState>(*s);
            if (filter == 0) n->global.filterNotes = true;
            if (filter == 1) n->global.midiInputChannelMask = 0U;
            if (filter == 2) { n->global.filterNotes = true; n->global.midiInputChannelMask = 0U; }
            e.setState(n); renderBlocks(e, 1);
            assert(e.postNoteOn(0U, 72U, 100U)); renderBlocks(e, 1);
            assert(e.activeVoiceCount() == 1U); // filters still refuse NEW notes
            assert(zeroVelocity ? e.postNoteOn(0U, 69U, 0U) : e.postNoteOff(0U, 69U));
            renderBlocks(e, 150);
            assert(e.activeVoiceCount() == 0U);
        }
    }
    // The configured damper CC and reversed polarity must work through CC and
    // channel filters, while a filtered pedal press must not latch sustain.
    for (const std::uint8_t cc : {std::uint8_t{64U}, std::uint8_t{66U}}) {
        for (bool reversed : {false, true}) {
            for (int filter = 0; filter < 3; ++filter) {
                SamplerEngine e; e.prepare(kRate, kBlock);
                auto s = stateFor(sineSample()); s->global.damperCc = cc; s->global.damperPolarityReversed = reversed;
                e.setState(s); assert(e.postNoteOn(0U, 69U, 100U));
                assert(e.postControlChange(0U, cc, reversed ? 0U : 127U));
                assert(e.postNoteOff(0U, 69U)); renderBlocks(e, 80);
                assert(e.activeVoiceCount() == 1U);
                auto n = std::make_shared<EngineState>(*s);
                n->global.filterControlChange = filter != 1;
                if (filter != 0) n->global.midiInputChannelMask = 0U;
                e.setState(n); renderBlocks(e, 1);
                assert(e.postControlChange(0U, cc, reversed ? 127U : 0U));
                renderBlocks(e, 150); assert(e.activeVoiceCount() == 0U);
            }
        }
    }
    // Safety All-Off must remain effective even with every input filter set.
    for (const std::uint8_t cc : {std::uint8_t{120U}, std::uint8_t{123U}}) {
        SamplerEngine e; e.prepare(kRate, kBlock); auto s = stateFor(sineSample()); e.setState(s);
        assert(e.postNoteOn(0U, 69U, 100U)); renderBlocks(e, 5);
        auto n = std::make_shared<EngineState>(*s); n->global.filterNotes = true;
        n->global.filterControlChange = true; n->global.midiInputChannelMask = 0U; e.setState(n);
        assert(e.postControlChange(0U, cc, 0U)); renderBlocks(e, 2); assert(e.activeVoiceCount() == 0U);
    }
    for (bool channelFilter : {false, true}) {
        SamplerEngine e; e.prepare(kRate, kBlock); auto s = stateFor(sineSample()); e.setState(s);
        assert(e.postNoteOn(0U, 69U, 100U)); renderBlocks(e, 5);
        auto n = std::make_shared<EngineState>(*s);
        n->global.filterControlChange = !channelFilter;
        if (channelFilter) n->global.midiInputChannelMask = 0U;
        e.setState(n); assert(e.postControlChange(0U, 64U, 127U)); renderBlocks(e, 1);
        assert(e.postNoteOff(0U, 69U)); renderBlocks(e, 150);
        assert(e.activeVoiceCount() == 0U); // the filtered pedal press did not latch
    }
    // Releasing the top mono key under a note filter must not retrigger the
    // lower key that is still in its stack (new notes remain forbidden).
    {
        SamplerEngine e; e.prepare(kRate, kBlock); auto s = stateFor(sineSample());
        s->combi.uppers[0].voiceMode = UpperVoiceMode::Mono; e.setState(s);
        assert(e.postNoteOn(0U, 67U, 100U)); renderBlocks(e, 20);
        assert(e.postNoteOn(0U, 69U, 100U)); renderBlocks(e, 20);
        auto n = std::make_shared<EngineState>(*s); n->global.filterNotes = true; e.setState(n);
        assert(e.postNoteOff(0U, 69U)); renderBlocks(e, 150); assert(e.activeVoiceCount() == 0U);
        assert(e.postNoteOff(0U, 67U)); renderBlocks(e, 1);
    }
    std::puts("PASS releases across note/channel/CC filters, custom/reversed damper, zero-velocity NOTE ON, All-Off and mono stack");
}

float maxStep(const std::vector<float>& out, std::size_t centre, std::size_t radius, std::size_t channel) {
    float peak = 0.0F;
    for (std::size_t f = centre - radius; f < centre + radius; ++f)
        peak = std::max(peak, std::abs(out[f * 2U + channel] - out[(f - 1U) * 2U + channel]));
    return peak;
}

std::vector<float> renderLoop(const SamplePtr& sample, std::uint8_t key, std::size_t frames) {
    SamplerEngine e; e.prepare(kRate, kBlock); e.setState(stateFor(sample));
    assert(e.postNoteOn(0U, key, 127U)); Block b{};
    std::vector<float> out; out.reserve(frames * 2U + b.size());
    while (out.size() < frames * 2U) { e.render(b.data(), kBlock); out.insert(out.end(), b.begin(), b.end()); }
    return out;
}

void testLoopSeams() {
    for (bool stereo : {false, true}) {
        for (const std::uint64_t start : {std::uint64_t{0U}, std::uint64_t{2400U}}) {
            for (const std::uint8_t key : {std::uint8_t{69U}, std::uint8_t{81U}, std::uint8_t{93U}}) {
                const double ratio = 0.5 * std::exp2((static_cast<int>(key) - 69) / 12.0);
                const std::size_t firstWrap = static_cast<std::size_t>(static_cast<double>(start + 4800U) / ratio);
                const std::size_t period = static_cast<std::size_t>(4800.0 / ratio);
                const std::size_t frames = firstWrap + 2U * period + 192U;
                auto plain = sineSample(stereo, start, 0U, false);
                auto smooth = sineSample(stereo, start, 240U, false);
                const auto a = renderLoop(plain, key, frames), b = renderLoop(smooth, key, frames);
                // A seamless source stays close to itself, with no artificial
                // 20x/30x reset spike introduced by enabling CROSSFADE.
                float delta = 0.0F;
                for (std::size_t i = 0; i < b.size(); ++i) delta = std::max(delta, std::abs(a[i] - b[i]));
                assert(delta < 0.0015F);
                for (const auto ch : {std::size_t{0U}, std::size_t{1U}}) {
                    for (std::size_t cycle = 0U; cycle < 3U; ++cycle) {
                        const auto at = firstWrap + cycle * period;
                        assert(maxStep(b, at, 24U, ch) < maxStep(a, at, 24U, ch) * 1.10F + 0.0001F);
                    }
                }
                // The unmodified attack/prefix remains bit-for-bit unchanged.
                const std::size_t beforeFade = static_cast<std::size_t>(static_cast<double>(start + 4800U - 240U - 64U) / ratio);
                for (std::size_t f = 0; f < beforeFade; ++f) {
                    assert(a[f * 2U] == b[f * 2U]); assert(a[f * 2U + 1U] == b[f * 2U + 1U]);
                }
                // A deliberately bad endpoint is de-clicked without changing
                // the original loop's period. First and later wraps are tested.
                const auto rough = renderLoop(sineSample(stereo, start, 0U, true), key, frames);
                const auto repaired = renderLoop(sineSample(stereo, start, 240U, true), key, frames);
                for (std::size_t cycle = 0U; cycle < 3U; ++cycle) {
                    const auto at = firstWrap + cycle * period;
                    for (const auto ch : {std::size_t{0U}, std::size_t{1U}})
                        assert(maxStep(repaired, at, 24U, ch) < maxStep(rough, at, 24U, ch) * 0.35F);
                }
                for (std::size_t f = firstWrap + 100U; f < firstWrap + period; ++f) {
                    assert(std::abs(repaired[f * 2U] - repaired[(f + period) * 2U]) < 0.000002F);
                    assert(std::abs(repaired[f * 2U + 1U] - repaired[(f + period) * 2U + 1U]) < 0.000002F);
                }
            }
        }
    }
    // Both interpolation APIs use the original kernel when no correction is
    // requested; a zero-width crossfade is exactly the old/bypass read path.
    SincInterpolator ip(InterpolationQuality::Studio);
    const auto s = sineSample(true, 0U, 0U);
    const auto zero = SincInterpolator::prepareLoopCrossfade(*s);
    for (const double ratio : {0.5, 0.731, 1.0, 2.0}) for (double p = 4650.25; p < 4850.0; p += 0.73) {
        float al, ar, bl, br; ip.readStereo(*s, p, ratio, true, al, ar);
        ip.readStereo(*s, p, ratio, true, bl, br, &zero); assert(al == bl && ar == br);
    }
    std::puts("PASS period-preserving loop seams: first/repeated loops, mono/stereo, loop start zero/nonzero, ratios 0.5/1/2, seamless source, bad source, unchanged attack/bypass");
}

void testLimiter() {
    assert(!GlobalState{}.limiterEnabled);
    auto sample = sineSample(true);
    // Channels have a fixed 1:0.25 amplitude ratio for the stereo-link check.
    for (std::size_t f = 0; f < sample->interleaved.size() / 2U; ++f)
        sample->interleaved[f * 2U + 1U] = sample->interleaved[f * 2U] * 0.25F;
    auto base = stateFor(sample);
    for (int u = 1; u < kUpperCount; ++u) base->combi.uppers[static_cast<std::size_t>(u)] = base->combi.uppers[0];
    base->global.masterGainDb = 6.0F;
    auto changedCeiling = std::make_shared<EngineState>(*base); changedCeiling->global.limiterCeilingDb = -12.0F;
    auto limited = std::make_shared<EngineState>(*base); limited->global.limiterEnabled = true; limited->global.limiterCeilingDb = -6.0F;
    SamplerEngine dry, bypass, on;
    for (auto* e : {&dry, &bypass, &on}) e->prepare(kRate, kBlock);
    dry.setState(base); bypass.setState(changedCeiling); on.setState(limited);
    for (auto* e : {&dry, &bypass, &on}) assert(e->postNoteOn(0U, 69U, 127U));
    Block d{}, b{}, x{}; float dryPeak = 0.0F, wetPeak = 0.0F, reduction = 0.0F;
    const float ceiling = std::pow(10.0F, -6.0F / 20.0F);
    for (int block = 0; block < 100; ++block) {
        dry.render(d.data(), kBlock); bypass.render(b.data(), kBlock); on.render(x.data(), kBlock);
        float minimumMeasuredGain = 1.0F;
        for (std::size_t i = 0; i < d.size(); ++i) {
            assert(d[i] == b[i]); // inactive ceiling cannot change any sample
            dryPeak = std::max(dryPeak, std::abs(d[i])); wetPeak = std::max(wetPeak, std::abs(x[i]));
            assert(std::abs(x[i]) <= ceiling + 0.000001F);
            if (std::abs(d[i]) > 0.00001F)
                minimumMeasuredGain = std::min(minimumMeasuredGain, std::abs(x[i] / d[i]));
        }
        for (std::size_t f = 0; f < kBlock; ++f) {
            assert(std::abs(x[f * 2U + 1U] - x[f * 2U] * 0.25F) < 0.000001F);
            // No lookahead: each nonzero output corresponds to this input frame.
            if (d[f * 2U] == 0.0F) assert(x[f * 2U] == 0.0F);
            else assert(d[f * 2U] * x[f * 2U] > 0.0F);
        }
        reduction = std::max(reduction, on.meters().limiterGainReductionDb);
        assert(std::abs(on.meters().limiterGainReductionDb + 20.0F * std::log10(minimumMeasuredGain)) < 0.001F);
        assert(dry.meters().limiterGainReductionDb == 0.0F);
    }
    assert(dryPeak > 1.0F && wetPeak > ceiling * 0.99F && reduction > 6.0F);
    // Disabling an already active limiter restores the original samples at the
    // next block boundary, without a hidden remaining release attenuation.
    on.setState(base); dry.render(d.data(), kBlock); on.render(x.data(), kBlock);
    assert(d == x); assert(on.meters().limiterGainReductionDb == 0.0F);
    // With the limiter active again, its release recovers after the signal ends.
    on.setState(limited); renderBlocks(on, 10); assert(on.postNoteOff(0U, 69U));
    renderBlocks(on, 1200); assert(on.meters().limiterGainReductionDb < 0.01F);
    std::printf("Limiter measured: dry peak %.6f, limited peak %.6f, ceiling %.6f, maximum gain reduction %.3f dB\n",
                dryPeak, wetPeak, ceiling, reduction);
    std::puts("PASS optional stereo-linked limiter: peak ceiling, gain reduction, release, zero lookahead, unchanged/default bypass");
}
} // namespace

int main() {
    testFilteredReleases();
    testLoopSeams();
    testLimiter();
    return 0;
}
