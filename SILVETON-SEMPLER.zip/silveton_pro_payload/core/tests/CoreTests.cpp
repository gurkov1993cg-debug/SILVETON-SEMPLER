#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include "silveton/NativeMidiEngine.h"
#include "silveton/Ribbon.h"
#include "silveton/Portamento.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

using namespace silveton;

static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

static int countNotes(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    int n = 0;
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) ++n;
    }
    return n;
}

static bool hasCc(const std::vector<MidiMessage>& v, int ch, int cc, int value) {
    for (const auto& m : v) {
        if (m.channel() == ch && m.command() == 0xB0 && int(m.data1) == cc && int(m.data2) == value) return true;
    }
    return false;
}

static int lastBendFor(const std::vector<MidiMessage>& v, int ch) {
    int value = -1;
    for (const auto& m : v) if (m.channel() == ch && m.isPitchBend()) value = m.pitchBend14();
    return value;
}

static void scanCMajor(MidiRouter& router, std::int64_t t) {
    auto start = router.setThirdScanning(true);
    (void)start;
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), t + 0).empty());
    assert(router.process(MidiMessage::noteOn(0, 64, 100), t + 100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), t + 200).empty());
    assert(!router.thirdScanning());
    assert(router.third().scanState() == ThirdModule::ScanState::WaitingForRelease);
    assert(router.process(MidiMessage::noteOffZero(0, 60), t + 300).empty());
    assert(router.process(MidiMessage::noteOffZero(0, 64), t + 400).empty());
    assert(router.process(MidiMessage::noteOffZero(0, 67), t + 500).empty());
    assert(router.third().scanState() == ThirdModule::ScanState::Locked);
    assert(router.third().enabled());
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    // Exact low-level MIDI encoding.
    const auto u1 = MidiMessage::noteOn(0, 60, 100);
    const auto u2 = MidiMessage::noteOn(1, 60, 100);
    const auto u3 = MidiMessage::noteOn(2, 60, 100);
    assert(u1.status == 0x90 && u2.status == 0x91 && u3.status == 0x92);
    const auto off0 = MidiMessage::noteOffZero(0, 60);
    assert(off0.status == 0x90 && off0.data1 == 0x3C && off0.data2 == 0x00 && off0.isNoteOff());
    const MidiMessage velocityZero{0x90, 0x3C, 0x00, 3};
    assert(velocityZero.isNoteOff());

    const auto bend0 = MidiMessage::pitchBend(0, 8192);
    const auto bend1 = MidiMessage::pitchBend(1, 8192);
    const auto bend2 = MidiMessage::pitchBend(2, 8192);
    assert(bend0.status == 0xE0 && bend0.data1 == 0x00 && bend0.data2 == 0x40);
    assert(bend1.status == 0xE1 && bend1.data1 == 0x00 && bend1.data2 == 0x40);
    assert(bend2.status == 0xE2 && bend2.data1 == 0x00 && bend2.data2 == 0x40);
    const auto bendMax = MidiMessage::pitchBend(0, 16383);
    assert(bendMax.data1 == 0x7F && bendMax.data2 == 0x7F);

    // Local-Control-OFF baseline: with all modules inactive the three Upper
    // channels are a semantic byte-for-byte bridge. No CC5/CC65/RPN/Pitch
    // injection is allowed merely because the app is connected.
    NativeMidiEngine bridgeEngine;
    assert(!bridgeEngine.router().portamento().config().enabled);
    const std::vector<MidiMessage> bridgeInput = {
        MidiMessage{0x90, 0x3C, 0x64, 3},
        MidiMessage{0x91, 0x3E, 0x55, 3},
        MidiMessage{0x92, 0x40, 0x48, 3},
        MidiMessage{0xB0, 0x01, 0x33, 3},
        MidiMessage{0xC1, 0x12, 0x00, 2},
        MidiMessage{0xE2, 0x7F, 0x3F, 3},
        MidiMessage{0x90, 0x3C, 0x00, 3},
        MidiMessage{0x91, 0x3E, 0x00, 3},
        MidiMessage{0x92, 0x40, 0x00, 3}
    };
    std::int64_t bridgeTime = 100;
    for (const auto& in : bridgeInput) {
        const auto out = bridgeEngine.handleMidiIn(in.status, in.data1, in.data2, in.size, bridgeTime++);
        assert(out.size() == 1);
        assert(out[0].status == in.status);
        assert(out[0].data1 == in.data1);
        assert(out[0].data2 == in.data2);
        assert(out[0].size == in.size);
    }
    // State-cleaning channel-mode messages remain transparent when Ribbon's
    // pitch transport is inactive: no surprise E0/E1/E2 center is appended.
    bridgeEngine.handleMidiIn(0x90, 60, 100, 3, bridgeTime++);
    const auto cc123Bridge = bridgeEngine.handleMidiIn(0xB0, 123, 0, 3, bridgeTime++);
    assert(cc123Bridge.size() == 1);
    assert(cc123Bridge[0].status == 0xB0 && cc123Bridge[0].data1 == 123 && cc123Bridge[0].data2 == 0);
    assert(bridgeEngine.router().activeNoteRefs(0, 60) == 0);
    // TIME portamento: changing the time is state-only. Enabling it forces the
    // PA600's own (rate-based) portamento OFF on U1/U2/U3 with CC65 = 0.
    const auto quietTime = bridgeEngine.router().setPortamentoTimeMs(100);
    assert(quietTime.empty());
    const auto bridgePortaOn = bridgeEngine.router().setPortamentoEnabled(true);
    assert(bridgePortaOn.size() == 3);
    for (int ch = 0; ch < 3; ++ch) {
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].status == std::uint8_t(0xB0 | ch));
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].data1 == 65);
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].data2 == 127);   // Korg portamento ON
    }
    const auto bridgePortaOff = bridgeEngine.router().setPortamentoEnabled(false);
    assert(bridgePortaOff.size() == 3 && hasCc(bridgePortaOff, 0, 65, 0) && hasCc(bridgePortaOff, 2, 65, 0));
    {
        MidiRouter r;
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        assert(hasCc(r.syncPortamentoChannel(2), 2, 65, 127));
        // PORTAMENTO ON = automatic MONO: 72 ends 60; the interval gets its
        // CC#5 before the note; never a Pitch Bend.
        auto n1 = r.process(MidiMessage::noteOn(0, 60, 100), 0);
        auto n2 = r.process(MidiMessage::noteOn(0, 72, 100), 1000);
        assert(n1.size() == 1 && n2.size() == 3 && lastBendFor(n2, 0) == -1);
        assert(n2[0].isControlChange() && n2[0].data1 == 5);
        assert(hasNote(n2, 0, 72, true) && hasNote(n2, 0, 60, false));
    }

    // ---- Local OFF: TERCA takes its notes from U3 itself ------------------
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        assert(r.tercaSource() == 2);
        // SCAN works from any Upper (here only U2 is transmitted).
        r.setThirdScanning(true);
        for (int n : {60, 64, 67}) r.process(MidiMessage::noteOn(1, n, 90), 1);
        for (int n : {60, 64, 67}) r.process(MidiMessage::noteOffZero(1, n), 2);
        assert(r.third().tonalityValid() && r.third().scanCell() == ThirdModule::ScanCell::MajorUp);

        // U1/U2 keys never create a third and are passed unchanged.
        auto k1u = r.process(MidiMessage::noteOn(0, 60, 100), 1000);
        auto k2u = r.process(MidiMessage::noteOn(1, 60, 100), 1001);
        assert(k1u.size() == 1 && hasNote(k1u, 0, 60, true));
        assert(k2u.size() == 1 && hasNote(k2u, 1, 60, true));
        // The U3 key is consumed and becomes its third: C -> E on U3 only.
        auto k3u = r.process(MidiMessage::noteOn(2, 60, 100), 1002);
        assert(k3u.size() == 1 && k3u[0].status == 0x92 && k3u[0].data1 == 64 && k3u[0].data2 == 100);
        r.process(MidiMessage::noteOffZero(0, 60), 2000);
        r.process(MidiMessage::noteOffZero(1, 60), 2001);
        auto u3off = r.process(MidiMessage::noteOffZero(2, 60), 2002);
        assert(hasNote(u3off, 2, 64, false) && !hasNote(u3off, 2, 60, false));

        // U3 glides along its own thirds: D on U3 -> F; the CC#5 is for E -> F.
        auto d = r.process(MidiMessage::noteOn(2, 62, 100), 1000000);
        assert(hasNote(d, 2, 65, true) && lastBendFor(d, 2) == -1);
        assert(d.size() == 2 && d[0].channel() == 2 && d[0].isControlChange() && d[0].data1 == 5 &&
               d[0].data2 == r.portamento().model().ccFor(1.0, 100.0));
        r.process(MidiMessage::noteOffZero(2, 62), 1100000);

        // U3 muted on the PA600 and not transmitted: U1/U2 alone -> no third.
        auto onlyU1 = r.process(MidiMessage::noteOn(0, 64, 100), 2000000);
        for (const auto& m : onlyU1) assert(m.channel() != 2);
        r.process(MidiMessage::noteOffZero(0, 64), 2100000);

        // CC123 on U1 no longer touches U3; CC123 on U3 cleans U3.
        r.process(MidiMessage::noteOn(2, 60, 100), 3000000);
        auto k1 = r.process(MidiMessage::controlChange(0, 123, 0), 3000100);
        for (const auto& m : k1) assert(m.channel() == 0);
        auto k3 = r.process(MidiMessage::controlChange(2, 123, 0), 3000200);
        assert(hasCc(k3, 2, 123, 0));
        assert(r.activeNoteRefs(2, 64) == 0);
    }

    // ---- TERCA toggle never makes U3 glide across raw <-> terca lines ------
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(2, 72, 100), 0);          // raw U3 line at 72
        r.process(MidiMessage::noteOffZero(2, 72), 1000);
        scanCMajor(r, 2000);                                    // TERCA now owns U3
        auto c = r.process(MidiMessage::noteOn(2, 60, 100), 100000);
        assert(hasNote(c, 2, 64, true));
        for (const auto& m : c) assert(!(m.isControlChange() && m.data1 == 5));   // no glide from 72
    }

    // activeNotes/lastNote reference counting: 9n NN 00 is a real Note Off.
    MidiRouter notes;
    notes.process(MidiMessage::noteOn(0, 60, 100), 0);
    notes.process(MidiMessage::noteOn(0, 60, 110), 1);
    assert(notes.activeNoteRefs(0, 60) == 2);
    assert(notes.lastNote(0) == 60);
    notes.process(MidiMessage{0x90, 60, 0, 3}, 2);
    assert(notes.activeNoteRefs(0, 60) == 1);
    notes.process(MidiMessage::noteOff(0, 60, 0), 3);
    assert(notes.activeNoteRefs(0, 60) == 0);
    assert(notes.lastNote(0) == -1);

    // Non-Upper stays transparent.
    auto pass = notes.process(MidiMessage::noteOn(3, 48, 100), 4);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // SCAN cancel: scan Note On and its later release never leak.
    MidiRouter scanCancel;
    scanCancel.setThirdScanning(true);
    assert(scanCancel.process(MidiMessage::noteOn(0, 60, 100), 10000).empty());
    scanCancel.setThirdScanning(false);
    assert(!scanCancel.thirdScanning());
    assert(scanCancel.process(MidiMessage::noteOffZero(0, 60), 10100).empty());
    auto normalAfterCancel = scanCancel.process(MidiMessage::noteOn(0, 62, 100), 10200);
    assert(hasNote(normalAfterCancel, 0, 62, true));

    // Fixed C-major tonality; TERCA is strictly U3, never U2.
    MidiRouter harmony;
    scanCMajor(harmony, 20000);
    // Local OFF: the U3 key is the source; it is consumed and replaced by its third.
    auto cOn = harmony.process(MidiMessage::noteOn(2, 60, 100), 21000);
    assert(!hasNote(cOn, 2, 60, true));
    assert(hasNote(cOn, 2, 64, true));
    assert(!hasNote(cOn, 1, 64, true));
    const MidiMessage* tercOn = nullptr;
    for (const auto& m : cOn) if (m.channel() == 2 && m.isNoteOn()) tercOn = &m;
    assert(tercOn != nullptr && tercOn->status == 0x92 && tercOn->data1 == 0x40 && tercOn->data2 == 0x64);

    auto cOff = harmony.process(MidiMessage{0x92, 60, 0, 3}, 21100);
    assert(!hasNote(cOff, 2, 60, false));
    bool exactTercaOff = false;
    for (const auto& m : cOff) {
        if (m.status == 0x92 && m.data1 == 0x40 && m.data2 == 0x00) exactTercaOff = true;
    }
    assert(exactTercaOff);

    // C-major mapping and out-of-scale policy.
    const int src[7] = {60, 62, 64, 65, 67, 69, 71};
    const int dst[7] = {64, 65, 67, 69, 71, 72, 74};
    for (int i = 0; i < 7; ++i) {
        auto on = harmony.process(MidiMessage::noteOn(2, src[i], 90), 22000 + i * 100);
        assert(hasNote(on, 2, dst[i], true));
        auto off = harmony.process(MidiMessage::noteOffZero(2, src[i]), 22100 + i * 100);
        assert(hasNote(off, 2, dst[i], false));
    }
    // Out-of-scale note in C major: C# gets the in-scale minor third E.
    auto outside = harmony.process(MidiMessage::noteOn(2, 61, 100), 23000);
    assert(hasNote(outside, 2, 64, true));
    harmony.process(MidiMessage::noteOffZero(2, 61), 23100);

    // The wheel is never swallowed by SCAN (centre during SCAN must arrive).
    {
        MidiRouter w;
        w.process(MidiMessage::pitchBend(0, 16000), 1);
        w.setThirdScanning(true);
        auto centre = w.process(MidiMessage::pitchBend(0, 8192), 2);
        assert(lastBendFor(centre, 0) == 8192);
        w.setThirdScanning(false);
    }

    // Generated TERCA ownership: duplicate source note cannot be killed early.
    auto dup1 = harmony.process(MidiMessage::noteOn(2, 60, 100), 24000);
    auto dup2 = harmony.process(MidiMessage::noteOn(2, 60, 100), 24100);
    assert(countNotes(dup1, 2, 64, true) == 1);
    assert(countNotes(dup2, 2, 64, true) == 0);
    // TERCA ON = automatic MONO line: a repeated key is one key, so the first
    // release ends the third and the stray second release produces nothing.
    auto dupOff1 = harmony.process(MidiMessage::noteOffZero(2, 60), 24200);
    assert(countNotes(dupOff1, 2, 64, false) == 1);
    auto dupOff2 = harmony.process(MidiMessage::noteOffZero(2, 60), 24300);
    for (const auto& m : dupOff2) assert(!m.isNoteOn());
    assert(harmony.activeNoteRefs(2, 64) == 0);

    // While TERCA owns U3 a raw U3 key becomes its third (A# -> D in C major);
    // with TERCA OFF, U3 is a completely normal Upper again.
    auto ownedU3 = harmony.process(MidiMessage::noteOn(2, 70, 100), 25000);
    assert(!hasNote(ownedU3, 2, 70, true) && hasNote(ownedU3, 2, 74, true));
    harmony.process(MidiMessage::noteOffZero(2, 70), 25050);
    harmony.setThirdEnabled(false);
    auto freeU3 = harmony.process(MidiMessage::noteOn(2, 70, 100), 25100);
    assert(freeU3.size() == 1 && hasNote(freeU3, 2, 70, true));
    harmony.process(MidiMessage::noteOffZero(2, 70), 25200);

    // CC123 on U3 terminates generated U3 state.
    harmony.setThirdEnabled(true);
    auto gen = harmony.process(MidiMessage::noteOn(2, 62, 100), 26000);
    assert(hasNote(gen, 2, 65, true));
    auto allOffU3 = harmony.process(MidiMessage::controlChange(2, 123, 0), 26100);
    assert(hasCc(allOffU3, 2, 123, 0));
    assert(harmony.activeNoteRefs(2, 65) == 0);
    auto afterKill = harmony.process(MidiMessage::noteOffZero(2, 62), 26200);
    for (const auto& m : afterKill) assert(!m.isNoteOn());

    // With pitch transport disabled (the Local-OFF baseline), physical Pitch
    // Bend is byte-for-byte transparent and Ribbon produces no background
    // output. This is the bridge state before Ribbon is actually touched.
    MidiRouter transparentBridge;
    const MidiMessage rawPitch{0xE0, 0x7F, 0x7F, 3};
    const auto rawPitchOut = transparentBridge.process(rawPitch, 29000);
    assert(rawPitchOut.size() == 1);
    assert(rawPitchOut[0].status == 0xE0 && rawPitchOut[0].data1 == 0x7F && rawPitchOut[0].data2 == 0x7F);
    transparentBridge.ribbonMove(1.0, 29100);
    assert(transparentBridge.poll(35000).empty());

    // A physical wheel position seen while the bridge is transparent must be
    // remembered. Switching to the +/-12 Ribbon transport must preserve the
    // same musical +/-2 wheel offset instead of jumping to center/full scale.
    MidiRouter heldWheelRouter;
    const auto heldRaw = heldWheelRouter.process(MidiMessage::pitchBend(0, 16383), 29500);
    assert(lastBendFor(heldRaw, 0) == 16383);
    const auto heldEnable = heldWheelRouter.setPitchTransportEnabled(true);
    assert(lastBendFor(heldEnable, 0) == 9557);

    // Ribbon remains an independent smooth 14-bit lane on all Uppers once the
    // Android layer has intentionally enabled the +/-12 pitch transport.
    MidiRouter ribbonRouter;
    auto enablePitchTransport = ribbonRouter.setPitchTransportEnabled(true);
    assert(lastBendFor(enablePitchTransport, 0) == 8192);
    assert(lastBendFor(enablePitchTransport, 1) == 8192);
    assert(lastBendFor(enablePitchTransport, 2) == 8192);
    ribbonRouter.ribbon().setRangeSemitones(3);
    ribbonRouter.ribbon().setSensitivity(1.0);
    ribbonRouter.ribbonMove(1.0, 30000);
    int last = 8192;
    for (std::int64_t t = 32000; t <= 250000; t += 2000) {
        const auto step = ribbonRouter.poll(t);
        const int b0 = lastBendFor(step, 0);
        if (b0 >= 0) {
            assert(b0 >= last);
            last = b0;
            assert(lastBendFor(step, 1) == b0);
            assert(lastBendFor(step, 2) == b0);
        }
    }
    assert(last > 8192);
    ribbonRouter.ribbonMove(0.0, 252000);
    int center = -1;
    for (std::int64_t t = 254000; t <= 600000; t += 2000) {
        const auto step = ribbonRouter.poll(t);
        const int b0 = lastBendFor(step, 0);
        if (b0 >= 0) center = b0;
    }
    assert(center == 8192);

    // Physical bend is composed with Ribbon and portamento never touches it.
    const auto manual = ribbonRouter.process(MidiMessage::pitchBend(0, 16383), 610000);
    const int manualBend = lastBendFor(manual, 0);
    assert(manualBend > 8192);
    const auto forcedPitch = ribbonRouter.syncPitchChannel(0);
    assert(lastBendFor(forcedPitch, 0) == manualBend);

    // Panic: exact known note releases + CC123 + CC120 + centered pitch, state clear.
    MidiRouter panicRouter;
    panicRouter.process(MidiMessage::noteOn(0, 60, 100), 0);
    panicRouter.process(MidiMessage::noteOn(1, 64, 100), 1);
    auto panic = panicRouter.panic();
    assert(hasNote(panic, 0, 60, false));
    assert(hasNote(panic, 1, 64, false));
    for (int ch = 0; ch < 3; ++ch) {
        assert(hasCc(panic, ch, 123, 0));
        assert(hasCc(panic, ch, 120, 0));
        assert(lastBendFor(panic, ch) == 8192);
        assert(panicRouter.lastNote(ch) == -1);
    }
    assert(panicRouter.activeNoteRefs(0, 60) == 0);
    assert(panicRouter.activeNoteRefs(1, 64) == 0);

    // JNI-facing native class uses the same authoritative router and treats
    // 90 NN 00 as Note Off.
    NativeMidiEngine native;
    assert(!native.router().monoEnabled());
    native.handleMidiIn(0x90, 60, 100, 3, 0);
    assert(native.router().activeNoteRefs(0, 60) == 1);
    native.handleMidiIn(0x90, 60, 0, 3, 1);
    assert(native.router().activeNoteRefs(0, 60) == 0);
    assert(native.router().lastNote(0) == -1);


    // ---------------------------------------------------------------------
    // TERCA: all six SCAN cells, all 12 tonalities, explicit expected notes.
    // Expected tables are written out by hand for tonic C and transposed.
    // ---------------------------------------------------------------------
    struct CellCase {
        ThirdModule::ScanCell cell;
        int scanPcs[3];
        int dir;
        int src[7];
        int dst[7];
    };
    const CellCase cellCases[6] = {
        {ThirdModule::ScanCell::MajorUp,    {0, 4, 7}, +1,
         {60, 62, 64, 65, 67, 69, 71}, {64, 65, 67, 69, 71, 72, 74}},
        {ThirdModule::ScanCell::MajorDown,  {0, 2, 4}, -1,
         {60, 62, 64, 65, 67, 69, 71}, {57, 59, 60, 62, 64, 65, 67}},
        {ThirdModule::ScanCell::MinorUp,    {0, 3, 7}, +1,
         {60, 62, 63, 65, 67, 68, 70}, {63, 65, 67, 68, 70, 72, 74}},
        {ThirdModule::ScanCell::MinorDown,  {0, 2, 3}, -1,
         {60, 62, 63, 65, 67, 68, 70}, {56, 58, 60, 62, 63, 65, 67}},
        {ThirdModule::ScanCell::PhrygianUp, {0, 1, 3}, +1,
         {60, 61, 63, 65, 67, 68, 70}, {63, 65, 67, 68, 70, 72, 73}},
        {ThirdModule::ScanCell::HijazUp,    {0, 1, 4}, +1,
         {60, 61, 64, 65, 67, 68, 70}, {64, 65, 67, 68, 70, 72, 73}},
    };
    for (const auto& cc : cellCases) {
        for (int root = 0; root < 12; ++root) {
            for (int local = 0; local < 1; ++local) {   // Local OFF only
                MidiRouter r;
                r.setThirdScanning(true);
                // Scan in a different octave and in inversion (top note first,
                // highest note dropped an octave) to prove pitch-class matching.
                const int n0 = 72 + ((root + cc.scanPcs[2]) % 12);
                const int n1 = 48 + ((root + cc.scanPcs[0]) % 12);
                const int n2 = 60 + ((root + cc.scanPcs[1]) % 12);
                r.process(MidiMessage::noteOn(0, n0, 90), 1);
                r.process(MidiMessage::noteOn(0, n1, 90), 2);
                r.process(MidiMessage::noteOn(0, n2, 90), 3);
                r.process(MidiMessage::noteOffZero(0, n0), 4);
                r.process(MidiMessage::noteOffZero(0, n1), 5);
                r.process(MidiMessage::noteOffZero(0, n2), 6);
                assert(r.third().scanState() == ThirdModule::ScanState::Locked);
                assert(r.third().tonalityValid());
                assert(r.third().scanCell() == cc.cell);
                assert(r.third().rootPitchClass() == root);
                assert(r.third().direction() == cc.dir);
                assert(r.thirdScanResult() == 1 + root + 12 * static_cast<int>(cc.cell));
                const int srcCh = r.tercaSource();          // U3 in Local OFF, U1 in Local ON
                assert(srcCh == (local == 1 ? 0 : 2));
                for (int i = 0; i < 7; ++i) {
                    const int s = cc.src[i] + root;
                    const int d = cc.dst[i] + root;
                    auto on = r.process(MidiMessage::noteOn(srcCh, s, 100), 100 + i);
                    assert(hasNote(on, 2, d, true));
                    assert(countNotes(on, 2, d, true) == 1);
                    // The source key itself is never sent: only its third.
                    assert(on.size() == 1);
                    auto off = r.process(MidiMessage::noteOffZero(srcCh, s), 200 + i);
                    assert(hasNote(off, 2, d, false));
                }
                // Every out-of-scale note also gets a third: the minor third if
                // it lands in the scale, else the major third, else minor.
                for (int pc = 0; pc < 12; ++pc) {
                    bool inScale = false;
                    for (int i = 0; i < 7; ++i) if ((cc.src[i] - 60) == pc) inScale = true;
                    if (inScale) continue;
                    auto scaleHas = [&](int rel) {
                        const int m = ((rel % 12) + 12) % 12;
                        for (int i = 0; i < 7; ++i) if ((cc.src[i] - 60) == m) return true;
                        return false;
                    };
                    int delta = 3 * cc.dir;
                    if (!scaleHas(pc + 3 * cc.dir) && scaleHas(pc + 4 * cc.dir)) delta = 4 * cc.dir;
                    const int s = 60 + ((root + pc) % 12);
                    auto chrom = r.process(MidiMessage::noteOn(srcCh, s, 100), 300 + pc);
                    assert(hasNote(chrom, 2, s + delta, true));
                    auto chromOff = r.process(MidiMessage::noteOffZero(srcCh, s), 400 + pc);
                    assert(hasNote(chromOff, 2, s + delta, false));
                }
            }
        }
    }
    // Non-triad / unknown shapes never lock.
    {
        MidiRouter r;
        r.setThirdScanning(true);
        r.process(MidiMessage::noteOn(0, 60, 90), 1);
        r.process(MidiMessage::noteOn(0, 66, 90), 2);
        r.process(MidiMessage::noteOn(0, 70, 90), 3);
        assert(r.thirdScanning());
        assert(!r.third().tonalityValid());
    }


    // ---------------------------------------------------------------------
    // MONO legato
    // ---------------------------------------------------------------------
    {
        // Local OFF, plain Upper: legato order = new note on, then old note off.
        MidiRouter r;
        r.setMonoEnabled(true);
        auto a = r.process(MidiMessage::noteOn(0, 60, 100), 1);
        assert(a.size() == 1 && hasNote(a, 0, 60, true));
        auto b = r.process(MidiMessage::noteOn(0, 62, 90), 2);
        assert(b.size() == 2 && b[0].isNoteOn() && b[0].data1 == 62 && b[1].isNoteOff() && b[1].data1 == 60);
        // Release the newest while 60 is still held: back to 60 (velocity 100).
        auto c = r.process(MidiMessage::noteOffZero(0, 62), 3);
        assert(c.size() == 2 && c[0].isNoteOn() && c[0].data1 == 60 && c[0].data2 == 100);
        assert(c[1].isNoteOff() && c[1].data1 == 62);
        // Releasing a silent held key produces nothing.
        r.process(MidiMessage::noteOn(0, 64, 100), 4);                 // 64 sounds, 60 held
        auto silent = r.process(MidiMessage::noteOffZero(0, 60), 5);
        assert(silent.empty());
        auto lastOff = r.process(MidiMessage::noteOffZero(0, 64), 6);
        assert(lastOff.size() == 1 && lastOff[0].isNoteOff() && lastOff[0].data1 == 64);
        for (int n = 0; n < 128; ++n) assert(r.activeNoteRefs(0, n) == 0);

        // A Note Off for a key pressed before MONO was enabled passes through.
        MidiRouter late;
        late.process(MidiMessage::noteOn(0, 70, 100), 1);
        late.setMonoEnabled(true);
        auto lateOff = late.process(MidiMessage::noteOffZero(0, 70), 2);
        assert(lateOff.size() == 1 && lateOff[0].isNoteOff() && lateOff[0].data1 == 70);
        assert(late.activeNoteRefs(0, 70) == 0);
    }
    {
        // Local OFF TERCA from U3 in MONO: only one third at a time, never mixed.
        MidiRouter r;
        r.setMonoEnabled(true);
        scanCMajor(r, 1);
        auto c = r.process(MidiMessage::noteOn(2, 60, 100), 1000);
        assert(hasNote(c, 2, 64, true));
        auto d = r.process(MidiMessage::noteOn(2, 62, 100), 2000);      // legato D
        assert(hasNote(d, 2, 65, true) && hasNote(d, 2, 64, false));
        assert(r.activeNoteRefs(2, 64) == 0 && r.activeNoteRefs(2, 65) == 1);
        auto back = r.process(MidiMessage::noteOffZero(2, 62), 3000);  // back to C
        assert(hasNote(back, 2, 64, true) && hasNote(back, 2, 65, false));
        auto end = r.process(MidiMessage::noteOffZero(2, 60), 4000);
        assert(hasNote(end, 2, 64, false));
        for (int n = 0; n < 128; ++n) assert(r.activeNoteRefs(2, n) == 0);
    }
    {
        // MONO + TIME portamento: legato glides (CC#5, on 62, off 60), the
        // return to the held key glides back; never a Pitch Bend.
        MidiRouter r;
        r.setMonoEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(0, 60, 100), 0);
        auto up = r.process(MidiMessage::noteOn(0, 62, 100), 1000000);
        assert(up.size() == 3 && up[0].isControlChange() && up[0].data1 == 5);
        assert(up[1].isNoteOn() && up[1].data1 == 62 && up[2].isNoteOff() && up[2].data1 == 60);
        auto ret = r.process(MidiMessage::noteOffZero(0, 62), 2000000); // back to 60
        assert(lastBendFor(ret, 0) == -1 && hasNote(ret, 0, 60, true) && hasNote(ret, 0, 62, false));
    }
    // ---- Automatic MONO: on with PORTAMENTO, off (poly chords) without it ---
    {
        MidiRouter r;                                     // app MONO flag off
        auto c1 = r.process(MidiMessage::noteOn(0, 60, 100), 1);
        auto c2 = r.process(MidiMessage::noteOn(0, 64, 100), 2);
        assert(c2.size() == 1 && hasNote(c2, 0, 64, true));       // poly: chord kept
        r.process(MidiMessage::noteOffZero(0, 60), 3);
        r.process(MidiMessage::noteOffZero(0, 64), 4);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(0, 60, 100), 10);
        auto leg = r.process(MidiMessage::noteOn(0, 62, 100), 20);
        assert(hasNote(leg, 0, 62, true) && hasNote(leg, 0, 60, false)); // mono: 60 ends
        r.process(MidiMessage::noteOffZero(0, 62), 30);
        r.process(MidiMessage::noteOffZero(0, 60), 40);
        for (int n = 0; n < 128; ++n) assert(r.activeNoteRefs(0, n) == 0);
        (void)c1;
    }


    // ---------------------------------------------------------------------
    // RIBBON module
    // ---------------------------------------------------------------------
    {
        auto settle = [](Ribbon& rb, std::int64_t& t, int ms) {
            for (int i = 0; i < ms / 2; ++i) { t += 2000; rb.advance(t); }
            return rb.currentSemitoneOffset();
        };
        // ABSOLUTE: position is pitch; centre dead zone.
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.rangeSemitones = 12;
            rb.setSettings(s);
            std::int64_t t = 1000;
            rb.touchDown(1.0, t);
            assert(std::abs(rb.targetSemitoneOffset() - 12.0) < 1e-9);
            rb.touchMove(0.005, t);   // inside the 0.008 dead zone
            assert(rb.targetSemitoneOffset() == 0.0);
            rb.touchMove(-1.0, t);
            assert(std::abs(rb.targetSemitoneOffset() + 12.0) < 1e-9);
            // RETURN: the finger stays -> the pitch settles there; lifting it
            // springs back exactly to 0.
            assert(std::abs(settle(rb, t, 500) + 12.0) < 1e-6);
            rb.touchUp(t);
            assert(settle(rb, t, 500) == 0.0 && !rb.active());
        }
    }
    // ---- MIDI bandwidth budget: continuous data can never flood the PA600 ---
    {
        // PITCH BEND: notes on 3 Uppers + a fast ribbon, 1 s, poll every 2 ms.
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 300;
        r.setPortamentoConfig(pc);
        Ribbon::Settings s;
        s.rangeSemitones = 12;
        r.setRibbonSettings(s);
        long pbPoll = 0;
        std::int64_t t = 0;
        r.ribbonTouch(0, 0.0, t);
        for (int i = 0; i < 500; ++i) {
            t += 2000;
            if (i % 50 == 0) for (int ch = 0; ch < 3; ++ch) r.process(MidiMessage::noteOn(ch, 60 + (i / 50) % 12, 100), t);
            r.ribbonTouch(1, std::sin(i * 0.03), t);
            for (const auto& m : r.poll(t)) if (m.isPitchBend()) ++pbPoll;
        }
        assert(pbPoll <= 3 * 100 + 3);                    // <= 100 Hz per Upper
    }


    // ---------------------------------------------------------------------
    // PORTAMENTO, Korg engine: equal time via CC#5 per note, no Pitch Bend
    // ---------------------------------------------------------------------
    {
        KorgGlideModel m;
        // Measured-style model: t = b(cc) * interval.
        m.setPoints({{20, 0.0, 5.0}, {60, 0.0, 20.0}, {100, 0.0, 60.0}}, true);
        assert(m.calibrated());
        for (double interval : {2.0, 5.0, 7.0, 12.0}) {   // reachable with this model
            const int cc = m.ccFor(interval, 120.0);
            const double got = m.timeFor(cc, interval);
            // Within one CC step of the requested time.
            const double step = std::abs(m.timeFor(std::min(127, cc + 1), interval) - m.timeFor(cc, interval)) + 1.0;
            assert(std::abs(got - 120.0) <= step);
        }
        assert(m.ccFor(12.0, 120.0) < m.ccFor(2.0, 120.0));   // wide interval -> faster rate
        assert(m.ccFor(12.0, 0.0) == 0);
        // Manual BALANCE: the CC#5 gap between semitone and octave grows with it.
        KorgGlideModel manualModel;
        manualModel.setManualBalance(8.0);
        const int gap8 = manualModel.ccFor(1.0, 40.0) - manualModel.ccFor(12.0, 40.0);
        manualModel.setManualBalance(16.0);
        const int gap16 = manualModel.ccFor(1.0, 40.0) - manualModel.ccFor(12.0, 40.0);
        assert(!manualModel.calibrated() && gap8 > 0 && gap16 > gap8);
        // Octave and semitone produce the same modelled time (within one CC step).
        for (double iv : {1.0, 3.0, 7.0, 12.0}) {
            const int ccv = manualModel.ccFor(iv, 40.0);
            assert(std::abs(manualModel.timeFor(ccv, iv) - 40.0) <= 40.0 * 0.12);
        }

        MidiRouter r;
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 120;
        r.setPortamentoConfig(pc);
        r.portamento().model().setPoints(m.points(), true);
        auto on = r.setPortamentoEnabled(true);
        for (int ch = 0; ch < 3; ++ch) assert(hasCc(on, ch, 65, 127));
        auto first = r.process(MidiMessage::noteOn(0, 60, 100), 0);
        assert(first.size() == 1 && first[0].isNoteOn());          // nothing to glide from
        r.process(MidiMessage::noteOffZero(0, 60), 1000);
        auto oct = r.process(MidiMessage::noteOn(0, 72, 100), 2000);
        assert(oct.size() == 2 && oct[0].isControlChange() && oct[0].data1 == 5 && oct[1].isNoteOn());
        assert(oct[0].data2 == m.ccFor(12.0, 120.0));
        r.process(MidiMessage::noteOffZero(0, 72), 3000);
        auto step = r.process(MidiMessage::noteOn(0, 74, 100), 4000);
        assert(step[0].data1 == 5 && step[0].data2 == m.ccFor(2.0, 120.0));
        r.process(MidiMessage::noteOffZero(0, 74), 5000);
        auto same = r.process(MidiMessage::noteOn(0, 76, 100), 6000);   // same interval -> same CC#5
        assert(same.size() == 1 && same[0].isNoteOn());
        // Nothing on the Pitch Bend lane, ever.
        for (const auto* v : {&first, &oct, &step, &same})
            for (const auto& msg : *v) assert(!msg.isPitchBend() && !(msg.isControlChange() && (msg.data1 == 100 || msg.data1 == 101)));
        auto poll = r.poll(100000);
        assert(poll.empty());
        // Program Change re-sync re-asserts CC#5 and CC65 for that Upper.
        auto sync = r.syncPortamentoChannel(0);
        assert(sync.size() == 2 && sync[0].data1 == 5 && sync[1].data1 == 65 && sync[1].data2 == 127);
        auto off = r.setPortamentoEnabled(false);
        for (int ch = 0; ch < 3; ++ch) assert(hasCc(off, ch, 65, 0));
    }
    {
        // TERCA on U3 + Korg portamento: U3's CC#5 follows the interval of the thirds.
        MidiRouter r;
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 120;
        r.setPortamentoConfig(pc);
        KorgGlideModel m;
        m.setPoints({{20, 0.0, 5.0}, {60, 0.0, 20.0}, {100, 0.0, 60.0}}, true);
        r.portamento().model().setPoints(m.points(), true);
        scanCMajor(r, 1);
        r.process(MidiMessage::noteOn(2, 60, 100), 1000);            // E
        r.process(MidiMessage::noteOffZero(2, 60), 2000);
        auto g = r.process(MidiMessage::noteOn(2, 67, 100), 3000);    // G -> B: third moves E->B = 7
        int cc3 = -1;
        for (const auto& msg : g) if (msg.channel() == 2 && msg.isControlChange() && msg.data1 == 5) cc3 = msg.data2;
        assert(cc3 == m.ccFor(7.0, 120.0));
        assert(hasNote(g, 2, 71, true));
    }


    // ---- Ribbon has its own range; the blend's Pitch Bend range is restored exactly ----
    {
        auto rpn0 = [](const std::vector<MidiMessage>& v, int ch) {
            int st = 0, val = -1;
            for (const auto& m : v) {
                if (!m.isControlChange() || m.channel() != ch) continue;
                if (m.data1 == 101) st = (m.data2 == 0) ? 1 : 0;
                else if (m.data1 == 100) st = (st == 1 && m.data2 == 0) ? 2 : 0;
                else if (m.data1 == 6 && st == 2) val = m.data2;
            }
            return val;
        };
        MidiRouter r;
        r.setBlendNative(true);
        // PA600 report on sound change: Program Change, RPN 1 = 64, then RPN 0 = 1 (this blend is +-1).
        auto pcOf = [](int ch) { return MidiMessage{static_cast<std::uint8_t>(0xC0 | ch), 5, 0, 2}; };
        for (int ch = 0; ch < 3; ++ch) {
            r.observeReport(pcOf(ch));
            for (auto m : {MidiMessage::controlChange(ch, 101, 0), MidiMessage::controlChange(ch, 100, 1), MidiMessage::controlChange(ch, 6, 64),
                           MidiMessage::controlChange(ch, 101, 0), MidiMessage::controlChange(ch, 100, 0), MidiMessage::controlChange(ch, 6, 1)})
                assert(r.observeReport(m).empty());
            assert(r.learnedBendRange(ch) == 1);
        }
        Ribbon::Settings s;
        s.rangeSemitones = 12;
        s.smoothMs = 0;
        assert(r.setRibbonSettings(s).empty());           // Ribbon not in use: nothing written
        // Ribbon in use: RPN 0 = B + Rr = 1 + 12 = 13 (wheel and Ribbon never clip).
        // The writes are spread: U1 at once, U2 and U3 on the next two polls,
        // never one long burst.
        auto en = r.setPitchTransportEnabled(true);
        assert(rpn0(en, 0) == 13 && rpn0(en, 1) == -1 && rpn0(en, 2) == -1);
        auto p1 = r.poll(2000);
        assert(rpn0(p1, 1) == 13 && rpn0(p1, 2) == -1);
        auto p2 = r.poll(4000);
        assert(rpn0(p2, 2) == 13);
        auto p3 = r.poll(6000);
        for (int ch = 0; ch < 3; ++ch) assert(rpn0(p3, ch) == -1);   // done, nothing more
        // The wheel keeps the blend's meaning: full up = +1 st = 8192 + 8192/13.
        auto w = r.process(MidiMessage::pitchBend(0, 16383), 10);
        assert(std::abs(lastBendFor(w, 0) - (8192 + 630)) <= 2);
        r.process(MidiMessage::pitchBend(0, 8192), 20);
        // Ribbon +6 st (half of its own 12) = 8192 + 8192*6/13, independent of the blend's +-1.
        r.ribbonTouch(0, 0.008 + 0.5 * 0.992, 100000);
        std::vector<MidiMessage> all;
        for (std::int64_t tt = 102000; tt < 200000; tt += 2000) { auto o = r.poll(tt); all.insert(all.end(), o.begin(), o.end()); }
        assert(std::abs(lastBendFor(all, 0) - (8192 + 3781)) <= 3);
        // A new sound (range 2) while the Ribbon is in use: the PA600 set 2, the app writes 2 + 12.
        r.observeReport(pcOf(0));
        r.observeReport(MidiMessage::controlChange(0, 101, 0));
        r.observeReport(MidiMessage::controlChange(0, 100, 0));
        auto upd = r.observeReport(MidiMessage::controlChange(0, 6, 2));
        assert(r.learnedBendRange(0) == 2 && rpn0(upd, 0) == 14);
        // The PA600's reset of all channels also reports RPN 0 (= 2): not a Sound,
        // B stays; the app writes its own R again because the PA600 dropped it.
        r.observeReport(MidiMessage::controlChange(1, 101, 0), 5000000);
        r.observeReport(MidiMessage::controlChange(1, 100, 0), 5000000);
        auto rs = r.observeReport(MidiMessage::controlChange(1, 6, 2), 5000000);
        assert(r.learnedBendRange(1) == 1 && rpn0(rs, 1) == 13);
        // Ribbon rests: every Upper back to EXACTLY its blend's range (U1 2, U2/U3 1), raw wheel.
        r.ribbonTouch(2, 0.0, 300000);
        for (std::int64_t tt = 302000; tt < 500000; tt += 2000) r.poll(tt);
        auto rest = r.setPitchTransportEnabled(false);
        assert(rpn0(rest, 0) == 2 && rpn0(rest, 1) == 1 && rpn0(rest, 2) == 1);
        // Ribbon RANGE smaller than the blend's: R = B + Rr is still written, so
        // the Ribbon gives its full RANGE on top of any wheel position.
        MidiRouter q;
        q.setBlendNative(true);
        q.observeReport(pcOf(1));
        q.observeReport(MidiMessage::controlChange(1, 101, 0));
        q.observeReport(MidiMessage::controlChange(1, 100, 0));
        q.observeReport(MidiMessage::controlChange(1, 6, 12));
        Ribbon::Settings small;
        small.rangeSemitones = 2;
        q.setRibbonSettings(small);
        auto e2 = q.setPitchTransportEnabled(true);
        assert(rpn0(e2, 0) == 4);                     // U1 unknown -> B 2 + 2
        auto e3 = q.poll(2000);
        assert(rpn0(e3, 1) == 14);                    // U2 blend 12 + 2
        q.poll(4000);
        auto l2 = q.setPitchTransportEnabled(false);
        assert(rpn0(l2, 0) == 2 && rpn0(l2, 1) == 12 && rpn0(l2, 2) == 2);
        // PANIC while the Ribbon range is raised restores the blend's value.
        MidiRouter pz;
        pz.setBlendNative(true);
        pz.setRibbonSettings(s);
        pz.setPitchTransportEnabled(true);
        pz.poll(2000);
        pz.poll(4000);                                  // all three raised by now
        auto pp = pz.panic();
        for (int ch = 0; ch < 3; ++ch) assert(rpn0(pp, ch) == 2);
        // PANIC right after the first write: only U1 was raised, only U1 is restored,
        // and nothing is written later.
        MidiRouter pe;
        pe.setBlendNative(true);
        pe.setRibbonSettings(s);
        pe.setPitchTransportEnabled(true);
        auto pq = pe.panic();
        assert(rpn0(pq, 0) == 2 && rpn0(pq, 1) == -1 && rpn0(pq, 2) == -1);
        for (int i = 1; i < 5; ++i) assert(pe.poll(i * 2000).empty());
    }
    // ---- Golden: Ribbon follow = old HQ critically damped trajectory (36 ms / 60 ms) ----
    {
        Ribbon rb;
        Ribbon::Settings s;
        s.rangeSemitones = 2;
        s.smoothMs = 36;
        s.returnMs = 60;
        rb.setSettings(s);
        // Reference: the HQ formula step by step, 2 ms steps, target +2 (right end).
        double v = 0.0, vel = 0.0;
        const double target = 2.0, dt = 0.002;
        std::int64_t t = 1000;
        rb.advance(t);
        rb.touchDown(1.0, t);
        bool overshoot = false;
        for (int i = 0; i < 60; ++i) {
            t += 2000;
            const double sm = 36 * 1.0e-3 / 3.0, om = 2.0 / sm, x = om * dt;
            const double e = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x);
            const double ch = v - target, tmp = (vel + om * ch) * dt;
            vel = (vel - om * tmp) * e;
            v = target + (ch + tmp) * e;
            const auto u = rb.advance(t);
            if (u.valid) assert(std::abs(u.semitones - std::min(v, 2.0)) < 0.02);
            if (u.valid && u.semitones > 2.0 + 1e-9) overshoot = true;
        }
        assert(!overshoot);
    }
    // ---- Ribbon: no inaudible (< 1 cent) Pitch Bend steps; the rest value is exact ----
    {
        MidiRouter r;
        r.setBlendNative(true);
        Ribbon::Settings s;
        s.rangeSemitones = 2;
        r.setRibbonSettings(s);
        r.setPitchTransportEnabled(true);
        std::array<int, 3> lastPb{{-1, -1, -1}};
        long count = 0;
        bool tinyStep = false;
        std::int64_t t = 1000;
        r.ribbonTouch(0, 0.0, t);
        // Very slow drag: 0 -> +1 semitone over 4 s, then hold, then release.
        for (int i = 0; i < 2000; ++i) {
            t += 2000;
            r.ribbonTouch(1, 0.008 + (i / 2000.0) * 0.5 * 0.992, t);
            for (const auto& m : r.poll(t)) {
                if (!m.isPitchBend()) continue;
                const int ch = m.channel();
                if (ch < 0 || ch > 2) continue;
                const auto c = static_cast<std::size_t>(ch);
                // R = B 2 + Rr 2 = 4 -> 1 cent = 8192 / 400 ~ 20 units.
                if (lastPb[c] >= 0 && std::abs(m.pitchBend14() - lastPb[c]) < 20) tinyStep = true;
                lastPb[c] = m.pitchBend14();
                ++count;
            }
        }
        assert(!tinyStep);
        assert(count < 3 * 110);                   // ~100 audible 1-cent steps per Upper, not 2000
        r.ribbonTouch(2, 0.0, t);
        std::array<int, 3> rest{{-1, -1, -1}};
        for (int i = 0; i < 500; ++i) {
            t += 2000;
            for (const auto& m : r.poll(t)) if (m.isPitchBend() && m.channel() >= 0 && m.channel() < 3) rest[static_cast<std::size_t>(m.channel())] = m.pitchBend14();
        }
        for (int ch = 0; ch < 3; ++ch) assert(rest[static_cast<std::size_t>(ch)] == 8192);
    }
    // ---- Portamento follows the blend (CC#65 report right before the Program Change) ----
    {
        MidiRouter r;
        auto pc = [](int ch, int prog) { return MidiMessage{static_cast<std::uint8_t>(0xC0 | ch), static_cast<std::uint8_t>(prog), 0, 2}; };
        auto cc5On = [](const std::vector<MidiMessage>& v, int ch) {
            for (const auto& m : v) if (m.isControlChange() && m.channel() == ch && m.data1 == 5) return true;
            return false;
        };
        auto report = [&](int ch, int porta, std::int64_t t) {
            std::vector<MidiMessage> out;
            for (auto m : {MidiMessage::controlChange(ch, 65, porta), MidiMessage::controlChange(ch, 5, 40)}) {
                auto o = r.observeReport(m, t); out.insert(out.end(), o.begin(), o.end());
            }
            auto o = r.observeReport(pc(ch, 3), t + 300); out.insert(out.end(), o.begin(), o.end());
            return out;
        };
        // Blend: U1 portamento ON, U2 OFF, U3 ON. Nothing is sent (the PA600 already switched).
        assert(report(0, 127, 1000).empty());
        assert(report(1, 0, 1500).empty());
        assert(report(2, 127, 2000).empty());
        assert(r.portamento().activeMask() == 5);
        assert(r.portamento().config().enabled);
        // U1 glides with the app's equal-time CC#5; U2 plays untouched.
        r.process(MidiMessage::noteOn(0, 60, 100), 10000);
        r.process(MidiMessage::noteOff(0, 60), 20000);
        assert(cc5On(r.process(MidiMessage::noteOn(0, 72, 100), 30000), 0));
        r.process(MidiMessage::noteOff(0, 72), 40000);
        r.process(MidiMessage::noteOn(1, 60, 100), 50000);
        r.process(MidiMessage::noteOff(1, 60), 60000);
        assert(!cc5On(r.process(MidiMessage::noteOn(1, 72, 100), 70000), 1));
        r.process(MidiMessage::noteOff(1, 72), 80000);
        // App PORTA OFF: CC#65 0 only on the Uppers that had it -> the PA600 turns it off too.
        auto off = r.setPortamentoEnabled(false);
        int offs = 0;
        for (const auto& m : off) if (m.isControlChange() && m.data1 == 65) { assert(m.data2 == 0 && m.channel() != 1); ++offs; }
        assert(offs == 2 && r.portamento().activeMask() == 0);
        // App PORTA ON again: back on the blend's Uppers (U1, U3).
        auto on = r.setPortamentoEnabled(true);
        int ons = 0;
        for (const auto& m : on) if (m.isControlChange() && m.data1 == 65) { assert(m.data2 == 127 && m.channel() != 1); ++ons; }
        assert(ons == 2 && r.portamento().activeMask() == 5);
        // Piano blend (no portamento on any Upper): the app's PORTA goes OFF by itself.
        assert(report(0, 0, 100000).empty());
        assert(report(1, 0, 100500).empty());
        assert(report(2, 0, 101000).empty());
        assert(r.portamento().activeMask() == 0 && !r.portamento().config().enabled);
        r.process(MidiMessage::noteOn(0, 60, 100), 110000);
        r.process(MidiMessage::noteOff(0, 60), 120000);
        assert(!cc5On(r.process(MidiMessage::noteOn(0, 67, 100), 130000), 0));
        r.process(MidiMessage::noteOff(0, 67), 140000);
        // The player switches PORTA ON on a blend without it: all three Uppers.
        auto all = r.setPortamentoEnabled(true);
        int n65 = 0;
        for (const auto& m : all) if (m.isControlChange() && m.data1 == 65 && m.data2 == 127) ++n65;
        assert(n65 == 3 && r.portamento().activeMask() == 7);
        // An echo of the app's own CC#65 long before a Program Change is not a report.
        r.observeReport(MidiMessage::controlChange(0, 65, 0), 200000);
        r.observeReport(pc(0, 9), 200000 + MidiRouter::kReportWindowUs + 1000);
        assert(r.portamento().activeMask() == 7);
        // A Program Change without any CC#65 report changes nothing.
        r.observeReport(pc(1, 9), 900000);
        assert(r.portamento().activeMask() == 7);
        // Blend with portamento only on U2 while the app was OFF: only U2.
        r.setPortamentoEnabled(false);
        report(0, 0, 1000000); report(1, 127, 1000500); report(2, 0, 1001000);
        assert(r.portamento().activeMask() == 2);
    }

    // ---- Accompaniment zone: below C4 nothing of the app touches the notes ----
    {
        MidiRouter r;
        r.setSplitNote(60);
        auto has5 = [](const std::vector<MidiMessage>& v) {
            for (const auto& m : v) if (m.isControlChange() && m.data1 == 5) return true;
            return false;
        };
        auto pcm = [](int ch) { return MidiMessage{static_cast<std::uint8_t>(0xC0 | ch), 1, 0, 2}; };
        // Blend with portamento on U1 (automatic MONO + CC#5 on U1 above the split).
        r.observeReport(MidiMessage::controlChange(0, 65, 127), 0);
        r.observeReport(pcm(0), 100);
        assert(r.portamento().activeOn(0));
        // Left-hand chord on U1 below C4: every note returned as played, no MONO cut, no CC#5.
        std::vector<MidiMessage> chord;
        std::int64_t t = 10000;
        for (int n : {48, 52, 55}) { auto o = r.process(MidiMessage::noteOn(0, n, 80), t += 10000); chord.insert(chord.end(), o.begin(), o.end()); }
        assert(chord.size() == 3);
        for (int n : {48, 52, 55}) assert(hasNote(chord, 0, n, true));
        assert(!has5(chord));
        // Right hand above C4 still glides with the app's CC#5, and never cuts the left hand.
        r.process(MidiMessage::noteOn(0, 72, 100), t += 10000);
        auto rh = r.process(MidiMessage::noteOn(0, 79, 100), t += 10000);
        assert(has5(rh) && hasNote(rh, 0, 72, false));
        for (int n : {48, 52, 55}) assert(!hasNote(rh, 0, n, false));
        r.process(MidiMessage::noteOff(0, 79), t += 10000);
        for (int n : {48, 52, 55}) {
            auto off = r.process(MidiMessage::noteOff(0, n), t += 10000);
            assert(off.size() == 1 && hasNote(off, 0, n, false));
        }
        // U2 one octave down: learned from the same key arriving on U1 and U2.
        r.process(MidiMessage::noteOn(0, 64, 91), 2000000);
        r.process(MidiMessage::noteOn(1, 52, 91), 2000600);
        assert(r.upperOctaveOffset(1) == -1);
        r.process(MidiMessage::noteOff(0, 64), 2100000);
        r.process(MidiMessage::noteOff(1, 52), 2100100);
        // Key B3 (U1 59, U2 47) is accompaniment on both; key D4 (U2 50) is not.
        auto a1 = r.process(MidiMessage::noteOn(0, 59, 70), 3000000);
        auto a2 = r.process(MidiMessage::noteOn(1, 47, 70), 3000500);
        assert(a1.size() == 1 && a2.size() == 1);
        r.process(MidiMessage::noteOff(0, 59), 3100000);
        r.process(MidiMessage::noteOff(1, 47), 3100100);


        // TERCA on U3: the thirds' safety sweep never sends All Notes Off while the
        // left hand holds accompaniment on U3.
        MidiRouter t3;
        t3.setSplitNote(60);
        t3.setThirdEnabled(true);
        t3.setThirdScanning(true);
        for (int n : {60, 64, 67}) t3.process(MidiMessage::noteOn(1, n, 90), 1);
        for (int n : {60, 64, 67}) t3.process(MidiMessage::noteOffZero(1, n), 2);
        assert(t3.third().ownsRawUpper3());
        auto low = t3.process(MidiMessage::noteOn(2, 48, 80), 1000);
        assert(low.size() == 1 && hasNote(low, 2, 48, true));      // plays as itself, no third
        auto hi = t3.process(MidiMessage::noteOn(2, 72, 90), 2000);
        assert(hasNote(hi, 2, 76, true));                           // C5 -> E5 third
        auto hiOff = t3.process(MidiMessage::noteOffZero(2, 72), 3000);
        assert(hasNote(hiOff, 2, 76, false));
        for (const auto& m : hiOff) assert(!(m.isControlChange() && m.data1 == 123));
        auto lowOff = t3.process(MidiMessage::noteOffZero(2, 48), 4000);
        assert(lowOff.size() == 1 && hasNote(lowOff, 2, 48, false));
        // Without accompaniment held the sweep is complete again.
        t3.process(MidiMessage::noteOn(2, 72, 90), 5000);
        auto sweep = t3.process(MidiMessage::noteOffZero(2, 72), 6000);
        bool cc123 = false;
        for (const auto& m : sweep) if (m.isControlChange() && m.data1 == 123) cc123 = true;
        assert(cc123);
    }

    std::cout << "SILVETON LIVE MIDI full low-level regression tests passed\n";
    return 0;
}
