#include "SynthVoice.h"
#include "silveton/sampler/ModelBank.h"
#include "silveton/sampler/ModelDefs.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>
#include <unistd.h>

using namespace silveton::sampler;
namespace {
constexpr double kRate = 96000.0;
struct ZoneSpec { int rows; std::uint8_t flags; };
using SoundSpec = std::vector<ZoneSpec>;
void put16(std::vector<std::uint8_t>& b, unsigned v) {
    b.push_back(static_cast<std::uint8_t>(v & 255U));
    b.push_back(static_cast<std::uint8_t>((v >> 8) & 255U));
}
void put32(std::vector<std::uint8_t>& b, unsigned v) {
    for (int i = 0; i < 4; ++i) b.push_back(static_cast<std::uint8_t>((v >> (8 * i)) & 255U));
}
void putFloat(std::vector<std::uint8_t>& b, float v) {
    std::uint32_t bits; std::memcpy(&bits, &v, sizeof(bits)); put32(b, bits);
}
std::vector<std::uint8_t> makeBank(const std::vector<SoundSpec>& sounds, bool v2 = false) {
    const char* magic = v2 ? "SVOSC002" : "SVOSC003";
    std::vector<std::uint8_t> b(magic, magic + 8);
    put32(b, static_cast<unsigned>(sounds.size()));
    for (std::size_t si = 0; si < sounds.size(); ++si) {
        const std::string name = "model_" + std::to_string(si);
        put16(b, static_cast<unsigned>(name.size())); b.insert(b.end(), name.begin(), name.end());
        put16(b, 0); put16(b, static_cast<unsigned>(sounds[si].size()));
        for (const auto& z : sounds[si]) {
            b.insert(b.end(), {0, 127, 60, z.flags});
            float nums[40]{}; nums[0] = 200.0F; nums[11] = 200.0F;
            for (int i = 0; i < (v2 ? 32 : 40); ++i) putFloat(b, nums[i]);
            constexpr int H = 24, L = 32;
            put16(b, H); put16(b, static_cast<unsigned>(z.rows)); put16(b, L); putFloat(b, 5.0F);
            if ((z.flags & 1U) == 0U) continue;
            for (int r = 0; r < z.rows + L; ++r) for (int h = 1; h <= H; ++h) {
                const double db = -6.0 * std::log2(static_cast<double>(h)) - 240.0 * std::max(0, std::min(r, z.rows - 1)) * 0.005;
                b.push_back(static_cast<std::uint8_t>(std::clamp(std::lround(-2.0 * db), 0L, 254L)));
            }
            b.insert(b.end(), static_cast<std::size_t>(z.rows + L) * 8U, 255U);
            b.insert(b.end(), static_cast<std::size_t>(z.rows), 0U);
        }
    }
    const char* end = "SVOSCEND"; b.insert(b.end(), end, end + 8);
    return b;
}
std::shared_ptr<const model::LearnedModels> parsed(const std::vector<std::uint8_t>& b) {
    auto bank = model::parseLearnedModels(b, "regression.sv");
    assert(bank && bank->error.empty());
    return bank;
}
std::vector<float> render(const model::ZoneShape& zone) {
    std::array<float, kEngineParamCountLegacy> p{};
    synth::setDefaults(p.data());
    p[E_FILT_TYPE] = 0.0F;
    p[synth::SY_LIFE] = p[synth::SY_UNISON] = p[synth::SY_SCOOP] = p[synth::SY_VIBRATO] = 0.0F;
    synth::Voice voice; model::Inputs in; in.key = 60;
    voice.noteOn(p.data(), kRate, in, &zone, 11U);
    std::vector<float> audio(57600U);
    for (float& l : audio) { float r; voice.tick(200.0 / kRate, l, r); assert(std::isfinite(l)); }
    return audio;
}
void sameSound(const model::ZoneShape& a, const model::ZoneShape& b) {
    assert(a.fullTrack == b.fullTrack);
    assert(a.harmTrack == b.harmTrack);
    assert(a.trackH == b.trackH && a.trackRows == b.trackRows && a.attackRows == b.attackRows);
    assert(std::equal(std::begin(a.peakDb), std::end(a.peakDb), std::begin(b.peakDb)));
    assert(render(a) == render(b));
}
void testDeletionKeepsPlayback(bool v2) {
    // The middle model is the only legacy-format evidence that both short sounds
    // are full tracks. Deleting it must preserve both their data AND their audio.
    const auto original = makeBank({{{40, 1}}, {{200, 1}}, {{60, 1}}}, v2);
    const auto before = parsed(original);
    assert(before->models[0].zones[0].fullTrack);
    std::vector<std::uint8_t> cut; std::string why;
    assert(model::removeSoundsFromBytes(original, {1}, cut, why));
    const auto after = parsed(cut);
    assert(after->models.size() == 2U);
    sameSound(before->models[0].zones[0], after->models[0].zones[0]);
    sameSound(before->models[2].zones[0], after->models[1].zones[0]);
    std::vector<std::uint8_t> twice;
    assert(model::removeSoundsFromBytes(cut, {0}, twice, why));
    sameSound(before->models[2].zones[0], parsed(twice)->models[0].zones[0]);
    std::vector<std::uint8_t> unchanged;
    assert(model::removeSoundsFromBytes(cut, {}, unchanged, why) && unchanged == cut);
    std::vector<std::uint8_t> empty;
    assert(model::removeSoundsFromBytes(cut, {0, 1}, empty, why));
    assert(parsed(empty)->models.empty());

    char file[] = "/tmp/silveton-model-playback-XXXXXX";
    const int fd = ::mkstemp(file); assert(fd >= 0); ::close(fd);
    { std::ofstream out(file, std::ios::binary | std::ios::trunc);
      out.write(reinterpret_cast<const char*>(original.data()), static_cast<std::streamsize>(original.size()));
      assert(out.good()); }
    assert(model::removeLearnedSounds(file, {1}).empty());
    auto disk = model::loadLearnedModels(file);
    assert(disk->error.empty() && disk->models.size() == 2U);
    sameSound(before->models[0].zones[0], disk->models[0].zones[0]);
    std::vector<std::uint8_t> diskBytes;
    { std::ifstream in(file, std::ios::binary); diskBytes.assign(std::istreambuf_iterator<char>(in), {}); }
    assert(diskBytes == cut);
    assert(!model::removeLearnedSounds(file, {7}).empty());
    { std::ifstream in(file, std::ios::binary);
      const std::vector<std::uint8_t> still(std::istreambuf_iterator<char>(in), {});
      assert(still == diskBytes); }
    assert(std::remove(file) == 0);
    std::ifstream unfinished(std::string(file) + ".new"); assert(!unfinished);
    std::printf("PASS %s deletion preserves short model PCM and on-disk mode\n", v2 ? "SVOSC002" : "SVOSC003");
}
void testExplicitModesAndLegacyCompatibility() {
    constexpr std::uint8_t full = 1U | model::kZonePlaybackExplicit | model::kZonePlaybackFullTrack;
    constexpr std::uint8_t steady = 1U | model::kZonePlaybackExplicit;
    const auto shortOld = parsed(makeBank({{{40, 1}}, {{60, 1}}}));
    assert(!shortOld->models[0].zones[0].fullTrack && !shortOld->models[1].zones[0].fullTrack);
    const auto shortFull = parsed(makeBank({{{40, full}}}));
    assert(shortFull->models[0].zones[0].fullTrack);
    assert(render(shortOld->models[0].zones[0]) != render(shortFull->models[0].zones[0]));
    // An explicitly steady long model must not reinterpret an unmarked short one.
    const auto mixed = parsed(makeBank({{{200, steady}, {40, full}, {0, 0}, {0, full}}, {{40, 1}}}));
    assert(!mixed->models[0].zones[0].fullTrack && mixed->models[0].zones[1].fullTrack);
    assert(!mixed->models[0].zones[2].fullTrack && !mixed->models[0].zones[3].fullTrack);
    assert(!mixed->models[1].zones[0].fullTrack);
    // Explicit per-zone modes stay independent even with unmarked long data.
    const auto bytes = makeBank({{{40, full}, {60, steady}}, {{200, 1}}});
    const auto before = parsed(bytes);
    std::vector<std::uint8_t> cut; std::string why;
    assert(model::removeSoundsFromBytes(bytes, {1}, cut, why));
    const auto after = parsed(cut);
    sameSound(before->models[0].zones[0], after->models[0].zones[0]);
    sameSound(before->models[0].zones[1], after->models[0].zones[1]);
    // Old unmarked steady banks also keep identical audio after an actual edit.
    const auto oldBytes = makeBank({{{40, 1}}, {{60, 1}}});
    assert(model::removeSoundsFromBytes(oldBytes, {1}, cut, why));
    sameSound(shortOld->models[0].zones[0], parsed(cut)->models[0].zones[0]);
    std::puts("PASS explicit full/steady per-zone modes and legacy compatibility");
}
} // namespace

int main() {
    testDeletionKeepsPlayback(false);
    testDeletionKeepsPlayback(true);
    testExplicitModesAndLegacyCompatibility();
    std::puts("Model playback regressions passed");
}
