// SILVETON_MODEL_V1 - the model engine checked with numbers: a learned file made here, a blend made here, the note's change towards
// the model (tone, loudness, pitch, breath, unison), the levelling, TUNE, the filter.
#include "ModelVoice.h"
#include "SynthVoice.h"
#include "silveton/sampler/ModelAnalyze.h"
#include "silveton/sampler/ModelBank.h"

#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <memory>
#include <vector>

using namespace silveton::sampler;
using namespace silveton::sampler::model;

static int g_checks = 0, g_fail = 0;
#define CHECK(cond, ...) do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("FAIL line %d: %s  ", __LINE__, #cond); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

namespace {
constexpr double kPi = 3.14159265358979323846;
constexpr double kSr = 48000.0;

// ---- a learned file written the way the teacher writes it (SVOSC003), one sound, one zone over the whole keyboard
void put16(std::vector<std::uint8_t>& b, unsigned v) { b.push_back(static_cast<std::uint8_t>(v & 255U)); b.push_back(static_cast<std::uint8_t>((v >> 8) & 255U)); }
void put32(std::vector<std::uint8_t>& b, unsigned v) { for (int i = 0; i < 4; ++i) b.push_back(static_cast<std::uint8_t>((v >> (8 * i)) & 255U)); }
void putF(std::vector<std::uint8_t>& b, float f) { unsigned x; std::memcpy(&x, &f, 4); put32(b, x); }
struct Teach { double f0 = 261.6; double tiltDbOct = -12.0; float scoopCents = -40.0F; float breathDb = -25.0F; float chiffDb = -10.0F; float unison = 0.0F; float life = 0.0F; float vibHz = 0.0F, vibCents = 0.0F; float attackMs = 20.0F; bool swell = false; };
std::vector<std::uint8_t> learnedFile(const Teach& t) {
    std::vector<std::uint8_t> b;
    const char* magic = "SVOSC003"; b.insert(b.end(), magic, magic + 8);
    put32(b, 1);
    const std::string name = "TEACHER", slot = "TEST";
    put16(b, static_cast<unsigned>(name.size())); b.insert(b.end(), name.begin(), name.end());
    put16(b, static_cast<unsigned>(slot.size())); b.insert(b.end(), slot.begin(), slot.end());
    put16(b, 1);
    b.push_back(0); b.push_back(127); b.push_back(60); b.push_back(1 | 2);
    float n[40] = {}; n[0] = static_cast<float>(t.f0); n[1] = 0.0F; n[2] = t.scoopCents; n[3] = t.vibHz; n[4] = t.vibCents; n[5] = t.life; n[7] = t.attackMs; n[11] = 200.0F; n[32] = t.unison;
    for (int i = 0; i < 40; ++i) putF(b, n[i]);
    const int H = 32, A = 60, L = 32;
    put16(b, H); put16(b, A); put16(b, L); putF(b, 5.0F);
    // the harmonics: a 1/k^x tilt; the attack rises (or swells) in loudness
    for (int r = 0; r < A + L; ++r) {
        float levelDb = 0.0F;
        if (r < A) { const double tt = r * 5.0 / 1000.0; levelDb = t.swell ? static_cast<float>(-12.0 * (1.0 - std::min(1.0, tt / 0.28))) : static_cast<float>(tt < t.attackMs / 1000.0 ? -30.0 * (1.0 - tt / (t.attackMs / 1000.0)) : 0.0); }
        for (int k = 1; k <= H; ++k) { const double db = t.tiltDbOct * std::log2(static_cast<double>(k)) + levelDb; b.push_back(static_cast<std::uint8_t>(std::min(255.0, std::round(-2.0 * db)))); }
    }
    // the noise: eight bands, a breath that sits in bands 4-5 (2-8 kHz); the attack has a chiff in bands 4-7 for the first 8 rows
    for (int r = 0; r < A + L; ++r) for (int tb = 0; tb < 8; ++tb) {
        double db = -120.0;
        if (tb >= 4 && tb <= 5) db = t.breathDb;
        if (r < 8 && tb >= 4) db = std::max(db, static_cast<double>(t.chiffDb));
        b.push_back(static_cast<std::uint8_t>(std::min(255.0, std::round(-2.0 * db))));
    }
    for (int r = 0; r < A; ++r) { const double tt = r * 5.0 / 1000.0; const double c = tt < 0.08 ? t.scoopCents * (1.0 - tt / 0.08) : 0.0; b.push_back(static_cast<std::uint8_t>(static_cast<std::int8_t>(std::lround(c)))); }
    const char* end = "SVOSCEND"; b.insert(b.end(), end, end + 8);
    return b;
}

// ---- a blend: a band-limited saw at a root key, 2 s, a loop in the last second
std::shared_ptr<SampleData> sawSample(int rootKey, double tiltPow = 1.0, double seconds = 2.0) {
    auto s = std::make_shared<SampleData>();
    s->sampleRate = 48000; s->channels = 1; s->rootKey = static_cast<std::uint8_t>(rootKey);
    const double f0 = 440.0 * std::pow(2.0, (rootKey - 69) / 12.0);
    const int n = static_cast<int>(seconds * kSr);
    s->interleaved.resize(static_cast<std::size_t>(n));
    std::vector<double> ph(40, 0.0);
    for (int i = 0; i < n; ++i) {
        double y = 0; for (int k = 1; k <= 40; ++k) { if (k * f0 > 20000) break; ph[static_cast<std::size_t>(k - 1)] += f0 * k / kSr; if (ph[static_cast<std::size_t>(k - 1)] >= 1) ph[static_cast<std::size_t>(k - 1)] -= 1; y += std::sin(2 * kPi * ph[static_cast<std::size_t>(k - 1)]) / std::pow(k, tiltPow); }
        const double t = i / kSr; const double env = t < 0.005 ? t / 0.005 : 1.0;
        s->interleaved[static_cast<std::size_t>(i)] = static_cast<float>(y * env * 0.3);
    }
    s->loop.enabled = true; s->loop.startFrame = static_cast<std::uint64_t>(kSr * 1.0); s->loop.endFrame = static_cast<std::uint64_t>(n);
    s->totalFrames = static_cast<std::uint64_t>(n);
    return s;
}

std::vector<double> spectrumDb(const std::vector<float>& x, std::size_t from, std::size_t n) {
    std::vector<std::complex<double>> a(n);
    for (std::size_t i = 0; i < n; ++i) a[i] = std::complex<double>((from + i < x.size() ? x[from + i] : 0.0F) * (0.5 - 0.5 * std::cos(2 * kPi * (static_cast<double>(i) + 0.5) / static_cast<double>(n))), 0.0);
    // a slow DFT is fine for the test sizes used (n = 4096)
    const std::size_t half = n / 2; std::vector<double> out(half, 0.0);
    std::vector<std::complex<double>> f(n);
    for (std::size_t i = 1, j = 0; i < n; ++i) { std::size_t bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) std::swap(a[i], a[j]); }
    for (std::size_t len = 2; len <= n; len <<= 1) { const double ang = -2 * kPi / static_cast<double>(len); const std::complex<double> wl(std::cos(ang), std::sin(ang)); for (std::size_t i = 0; i < n; i += len) { std::complex<double> w(1, 0); for (std::size_t j = 0; j < len / 2; ++j) { const std::complex<double> u = a[i + j], v = a[i + j + len / 2] * w; a[i + j] = u + v; a[i + j + len / 2] = u - v; w *= wl; } } }
    for (std::size_t k = 0; k < half; ++k) out[k] = 20 * std::log10(std::abs(a[k]) + 1e-9);
    return out;
}
double centroidHz(const std::vector<double>& db, double sr) { double n = 0, d = 0; for (std::size_t k = 1; k < db.size(); ++k) { const double p = std::pow(10.0, db[k] / 10.0); n += p * static_cast<double>(k) * sr / (2.0 * static_cast<double>(db.size())); d += p; } return d > 0 ? n / d : 0; }
double rmsOf(const std::vector<float>& x, std::size_t from, std::size_t to) { double e = 0; std::size_t m = 0; for (std::size_t i = from; i < to && i < x.size(); ++i) { e += static_cast<double>(x[i]) * x[i]; ++m; } return m ? std::sqrt(e / static_cast<double>(m)) : 0; }
bool allFinite(const std::vector<float>& v) { for (float f : v) if (!std::isfinite(f)) return false; return true; }
// SILVETON_MODEL_EAR_V1: the loudness as the ear hears it (the A curve over the spectrum) - what the engine keeps equal
double earDb(const std::vector<float>& x, std::size_t from) {
    const auto sp = spectrumDb(x, from, 4096);
    double e = 0.0;
    for (std::size_t k = 1; k < sp.size(); ++k) {
        const double hz = static_cast<double>(k) * kSr / 4096.0, f2 = hz * hz;
        const double a = 12194.0 * 12194.0 * f2 * f2 / ((f2 + 20.6 * 20.6) * std::sqrt((f2 + 107.7 * 107.7) * (f2 + 737.9 * 737.9)) * (f2 + 12194.0 * 12194.0)) * 1.2589;
        e += std::pow(10.0, sp[k] / 10.0) * a * a;
    }
    return 10.0 * std::log10(e + 1e-18);
}

// run the voice over the sample itself (as the sampler would read it at the root key), with params
struct Run { std::vector<float> out; std::vector<double> semis; };
Run runVoice(const SampleData& s, const float* p, const ZoneShape* mz, const ZoneShape* bz, double seconds, int key = 60) {
    Voice v; Inputs in; in.key = key; in.velocity = 0.8F; in.gate = true;
    v.noteOn(p, kSr, in, mz, bz, 99U);
    Run r; const int n = static_cast<int>(seconds * kSr);
    for (int i = 0; i < n; ++i) {
        const std::size_t idx = static_cast<std::size_t>(i) % s.interleaved.size();
        float l = s.interleaved[idx], rr = l;
        if (i % 128 == 0) { v.setInputs(in, kSr); r.semis.push_back(v.pitchSemis()); }
        v.tick(l, rr);
        r.out.push_back(l);
    }
    return r;
}
}  // namespace

int main() {
    // ---- 1) the learned file
    const Teach dark;   // a dark teacher (-12 dB/oct), a scoop of -40 cents, breath -25 dB in 2-8 kHz
    const auto lm = parseLearnedModels(learnedFile(dark), "test.sv");
    CHECK(lm->error.empty() && lm->models.size() == 1 && lm->models[0].name == "TEACHER" && lm->models[0].slot == "TEST", "the file is read (%s)", lm->error.c_str());
    const ModelShape& m = lm->models[0];
    CHECK(m.zones.size() == 1 && m.zones[0].ok && m.zoneFor(60) == 0 && m.zoneFor(10) == 0, "one zone over the keyboard");
    const ZoneShape& mz = m.zones[0];
    {
        // the tone curve: -12 dB an octave from the first harmonic up
        const float t1 = mz.tone[static_cast<int>(std::lround(bandOfHz(static_cast<float>(dark.f0))))], t4 = mz.tone[static_cast<int>(std::lround(bandOfHz(static_cast<float>(dark.f0 * 4))))];
        CHECK(std::fabs((t4 - t1) + 24.0F) < 4.0F, "the tone falls 24 dB over two octaves (%.1f)", t4 - t1);
        CHECK(mz.tone[0] < -100.0F, "below the first harmonic: no information");
        CHECK(mz.level[0] < -20.0F && std::fabs(mz.level[10]) < 1.0F, "the loudness curve: quiet at the start (%.1f), steady by 100 ms (%.1f)", mz.level[0], mz.level[10]);
        CHECK(std::fabs(mz.scoop[0] + 40.0F) < 2.0F && mz.scoop[20] == 0.0F, "the scoop: -40 c at the start (%.0f), gone by 100 ms", mz.scoop[0]);
        CHECK(std::fabs(mz.breathDb[2] + 25.0F) < 4.0F && mz.breathDb[0] < -100.0F, "the breath sits in the high band (%.1f) and nowhere low (%.1f)", mz.breathDb[2], mz.breathDb[0]);
        CHECK(mz.chiffDb[2] > mz.breathDb[2] + 10.0F, "the chiff stands above the breath (%.1f vs %.1f)", mz.chiffDb[2], mz.breathDb[2]);
        CHECK(std::fabs(mz.steadyRms - 0.74F) < 0.15F, "the steady loudness of the model (%.2f)", mz.steadyRms);
    }
    {
        std::vector<std::uint8_t> old(learnedFile(dark)); std::memcpy(old.data(), "SVOSC001", 8);
        CHECK(!parseLearnedModels(old, "x")->error.empty(), "an old LAB file is refused with a reason");
        std::vector<std::uint8_t> cut(learnedFile(dark)); cut.resize(cut.size() / 2);
        CHECK(!parseLearnedModels(cut, "x")->error.empty(), "a cut file is refused");
    }
    // ---- 2) measuring a blend
    const auto saw = sawSample(60);
    const ZoneShape bz = analyzeSample(*saw, 60, 0.0F);
    CHECK(bz.ok && std::fabs(bz.f0Hz - 261.6F) < 2.0F, "the saw blend is measured (%.1f Hz)", bz.f0Hz);
    {
        const float t1 = bz.tone[static_cast<int>(std::lround(bandOfHz(261.6F)))], t4 = bz.tone[static_cast<int>(std::lround(bandOfHz(1046.0F)))];
        CHECK(std::fabs((t4 - t1) + 12.0F) < 4.0F, "a saw falls 12 dB over two octaves (%.1f)", t4 - t1);
        CHECK(bz.steadyRms > 0.1F && bz.steadyRms < 0.6F, "its loudness (%.2f)", bz.steadyRms);
        CHECK(std::fabs(bz.level[50]) < 1.0F, "its loudness curve is flat once it plays (%.1f)", bz.level[50]);
    }
    {
        Program prog; ProgramLayer layer; auto ms = std::make_shared<Multisample>(); SampleZone z; z.sample = saw; z.keyLow = 0; z.keyHigh = 127; z.rootKey = 60; ms->zones.push_back(z);
        layer.multisample = ms; prog.layers.push_back(layer);
        const auto shape = analyzeBlend(prog);
        CHECK(shape->entries.size() == 1 && shape->shapeOf(saw.get()) != nullptr && shape->shapeOf(saw.get())->ok, "a program is measured sample by sample");
    }
    // ---- 3) the note: amount 0 = the blend untouched; amount 1 = towards the model
    float P[kEngineParamCountLegacy]; setDefaults(P);
    P[MO_SHAPE] = 1.0F; P[MO_SCOOP] = 1.0F;   // (the start values are SHAPE 0 / SCOOP 23 % - SILVETON_MODEL_START_V1; these checks want the learned attack in full)
    P[MO_MODEL] = 1.0F; P[MO_AMOUNT] = 0.0F;
    const Run plain = runVoice(*saw, P, &mz, &bz, 1.0);
    CHECK(allFinite(plain.out), "finite");
    {
        double diff = 0; for (std::size_t i = 24000; i < 36000; ++i) diff = std::max(diff, std::fabs(static_cast<double>(plain.out[i]) - saw->interleaved[i]));
        CHECK(diff < 1e-4, "AMOUNT 0: the blend passes untouched (max difference %.6f)", diff);
    }
    P[MO_AMOUNT] = 1.0F;
    const Run full = runVoice(*saw, P, &mz, &bz, 1.0);
    CHECK(allFinite(full.out), "finite with the model");
    const auto spPlain = spectrumDb(plain.out, 24000, 4096), spFull = spectrumDb(full.out, 24000, 4096);
    const double cPlain = centroidHz(spPlain, kSr), cFull = centroidHz(spFull, kSr);
    CHECK(cFull < cPlain * 0.7, "the dark model darkens the saw (centroid %.0f -> %.0f Hz)", cPlain, cFull);
    {
        const double rPlain = rmsOf(plain.out, 24000, 48000), rFull = rmsOf(full.out, 24000, 48000);
        const double earD = earDb(full.out, 24000) - earDb(plain.out, 24000);
        CHECK(std::fabs(earD) < 1.5, "the loudness stays as the ear hears it (%.2f dB by ear, %.2f dB power)", earD, 20 * std::log10(rFull / rPlain));
        CHECK(std::fabs(20 * std::log10(rFull / rPlain)) < 6.0, "... and the power stays within reason (%.2f dB)", 20 * std::log10(rFull / rPlain));
        // the model's attack: quiet at the very start, the saw itself is loud at once
        const double early = rmsOf(full.out, 96, 480), late = rmsOf(full.out, 24000, 48000);
        CHECK(early < late * 0.5, "the model's slow start is laid on the saw (%.3f early vs %.3f steady)", early, late);
        // the scoop: the pitch starts 40 cents down and comes up
        CHECK(full.semis.front() < -0.25 && std::fabs(full.semis[60]) < 0.02, "the scoop (%.2f st at the start, %.3f at 160 ms)", full.semis.front(), full.semis[60]);
        // SILVETON_MODEL_NO_BREATH_V1: the teacher's breath (-25 dB in 2-8 kHz here) is NOT added - between the harmonics nothing new
        const double f0 = 261.6; const std::size_t binH = static_cast<std::size_t>(std::lround(12.5 * f0 / (kSr / 4096)));   // between the 12th and 13th harmonic (~3.3 kHz)
        CHECK(spFull[binH] < spPlain[binH] + 3.0, "no breath is added between the harmonics (%.1f -> %.1f dB)", spPlain[binH], spFull[binH]);
    }
    // ---- 4) the knobs: BRIGHT, SHAPE off, SCOOP off, BREATH down, UNISON; none of them changes the loudness
    {
        float Q[kEngineParamCountLegacy]; std::memcpy(Q, P, sizeof Q);
        Q[MO_BRIGHT] = 6.0F; const Run bright = runVoice(*saw, Q, &mz, &bz, 1.0);
        const double cB = centroidHz(spectrumDb(bright.out, 24000, 4096), kSr);
        CHECK(cB > cFull * 1.25, "BRIGHT +6 makes it brighter again (%.0f -> %.0f Hz)", cFull, cB);
        const double dBb = earDb(bright.out, 24000) - earDb(plain.out, 24000);
        CHECK(std::fabs(dBb) < 1.5, "... and as loud by ear (%.2f dB)", dBb);
        Q[MO_BRIGHT] = -6.0F; const Run dark9 = runVoice(*saw, Q, &mz, &bz, 1.0);
        const double dBd = earDb(dark9.out, 24000) - earDb(plain.out, 24000);
        CHECK(std::fabs(dBd) < 1.5, "BRIGHT -6: as loud by ear (%.2f dB)", dBd);
        std::memcpy(Q, P, sizeof Q); Q[MO_SHAPE] = 0.0F; const Run noShape = runVoice(*saw, Q, &mz, &bz, 0.3);
        CHECK(rmsOf(noShape.out, 96, 480) > rmsOf(full.out, 96, 480) * 2.0, "SHAPE 0: the saw's own quick start is back");
        std::memcpy(Q, P, sizeof Q); Q[MO_SCOOP] = 0.0F; const Run noScoop = runVoice(*saw, Q, &mz, &bz, 0.1);
        CHECK(std::fabs(noScoop.semis.front()) < 0.01, "SCOOP 0: no scoop");

        // a teacher with unison: the blend gets two moving copies, the loudness stays, nothing explodes
        Teach uni = dark; uni.unison = 10.0F; const auto lmU = parseLearnedModels(learnedFile(uni), "u.sv");
        const Run u2 = runVoice(*saw, P, &lmU->models[0].zones[0], &bz, 3.2);
        const Run f2 = runVoice(*saw, P, &mz, &bz, 3.2);
        const double dBu = 20 * std::log10(rmsOf(u2.out, 24000, 153600) / rmsOf(f2.out, 24000, 153600));   // over whole beats of the two copies
        CHECK(allFinite(u2.out) && std::fabs(dBu) < 1.5, "UNISON: finite and as loud on the whole (%.2f dB)", dBu);
        double maxd = 0; for (std::size_t i = 24000; i < 36000; ++i) maxd = std::max(maxd, std::fabs(static_cast<double>(u2.out[i]) - full.out[i]));
        CHECK(maxd > 0.01, "UNISON changes the sound (%.3f)", maxd);
        // life and vibrato of the teacher move the pitch
        Teach live = dark; live.life = 6.0F; live.vibHz = 5.0F; live.vibCents = 20.0F; const auto lmL = parseLearnedModels(learnedFile(live), "l.sv");
        const Run lv = runVoice(*saw, P, &lmL->models[0].zones[0], &bz, 1.0);
        double hi = -9, lo = 9; for (std::size_t i = 100; i < lv.semis.size(); ++i) { hi = std::max(hi, lv.semis[i]); lo = std::min(lo, lv.semis[i]); }
        CHECK(hi > 0.12 && lo < -0.12, "life + vibrato move the pitch both ways (%.2f .. %.2f st)", lo, hi);
        // a swelling teacher: the saw swells
        Teach sw = dark; sw.swell = true; const auto lmS = parseLearnedModels(learnedFile(sw), "s.sv");
        const Run swell = runVoice(*saw, P, &lmS->models[0].zones[0], &bz, 0.6);
        CHECK(rmsOf(swell.out, 480, 2400) < rmsOf(swell.out, 20000, 28000) * 0.6, "SWELL: the saw grows (%.3f -> %.3f)", rmsOf(swell.out, 480, 2400), rmsOf(swell.out, 20000, 28000));
    }
    // ---- 5) the filter block pays back what it takes
    {
        float Q[kEngineParamCountLegacy]; std::memcpy(Q, P, sizeof Q); Q[MO_AMOUNT] = 0.0F;
        Q[E_FILT_TYPE] = 1.0F; Q[E_CUTOFF] = 600.0F; Q[E_RESO] = 0.2F;
        const Run lp = runVoice(*saw, Q, &mz, &bz, 1.0);
        const double cL = centroidHz(spectrumDb(lp.out, 24000, 4096), kSr);
        CHECK(allFinite(lp.out) && cL < cPlain * 0.6, "LADDER 600 Hz darkens (%.0f -> %.0f)", cPlain, cL);
        const double dB = earDb(lp.out, 24000) - earDb(plain.out, 24000);
        CHECK(std::fabs(dB) < 3.0, "... and the loudness is paid back by ear (%.2f dB)", dB);
        Q[E_FILT_TYPE] = 4.0F; Q[E_CUTOFF] = 2000.0F; const Run hp = runVoice(*saw, Q, &mz, &bz, 1.0);
        CHECK(allFinite(hp.out) && centroidHz(spectrumDb(hp.out, 24000, 4096), kSr) > cPlain * 1.3, "HP 12 brightens");
    }
    // ---- 6) a model without a blend measurement, a blend without a model, both missing: nothing explodes
    {
        const Run a = runVoice(*saw, P, &mz, nullptr, 0.5); CHECK(allFinite(a.out), "model without blend: finite");
        const Run b = runVoice(*saw, P, nullptr, &bz, 0.5); CHECK(allFinite(b.out), "blend without model: finite");
        double diff = 0; for (std::size_t i = 12000; i < 24000; ++i) diff = std::max(diff, std::fabs(static_cast<double>(b.out[i]) - saw->interleaved[i]));
        CHECK(diff < 1e-4, "no model = untouched (%.6f)", diff);
        const Run c = runVoice(*saw, P, nullptr, nullptr, 0.5); CHECK(allFinite(c.out), "nothing: finite");
    }
    // ---- 7) CPU: 16 notes of the model engine
    {
        Voice vs[16]; Inputs in; in.key = 60; in.velocity = 0.8F;
        for (auto& v : vs) v.noteOn(P, kSr, in, &mz, &bz, 5U);
        const auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < 48000; ++i) { const float x = saw->interleaved[static_cast<std::size_t>(i)]; for (auto& v : vs) { float l = x, r = x; v.tick(l, r); } }
        const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::printf("  16 model notes: %.1f%% of real time (%.3f s for 1 s)\n", sec * 100.0, sec);
        CHECK(sec < 0.6, "16 notes fit in real time here (%.2f s)", sec);
    }
    // ---- 8) SILVETON_MODEL_CLEAN_V1: the REAL built-in models, and nothing clicks: every knob jumps to its far end while the
    //      note sounds, the model is changed mid-note - the sample-to-sample steps of the output stay those of the plain saw
    {
        const auto built = builtinLearnedModels();
        CHECK(built->error.empty() && built->models.size() == 11, "the built-in models: 11 (%zu) %s", built->models.size(), built->error.c_str());
        if (built->models.size() == 11) CHECK(built->models[3].name == "Radi Cz Casio So" && built->models[10].name == "Radi Expert Mode", "MODEL 4 .. 11 in the teacher's order");
        const ZoneShape* z1 = nullptr; const ZoneShape* z2 = nullptr; const ZoneShape* z3 = nullptr;
        if (built->models.size() >= 3) {
            z1 = &built->models[0].zones[static_cast<std::size_t>(built->models[0].zoneFor(60))];
            z2 = &built->models[1].zones[static_cast<std::size_t>(built->models[1].zoneFor(60))];
            z3 = &built->models[2].zones[static_cast<std::size_t>(built->models[2].zoneFor(60))];
            CHECK(!z1->pitchDoubt && !z3->pitchDoubt, "Radi Pa5x and Musi 43: the learned pitch is in the harmonics");
            CHECK(z2->pitchDoubt, "Radi Taksim 2024: no fundamental in the harmonics (learned in another octave) - its tone is not applied");
        }
        if (z1 != nullptr && z2 != nullptr && z3 != nullptr) {
            const auto stepMax = [](const std::vector<float>& x, std::size_t from, std::size_t to) { double m = 0; for (std::size_t i = std::max<std::size_t>(from, 1); i < to && i < x.size(); ++i) m = std::max(m, std::fabs(static_cast<double>(x[i]) - x[i - 1])); return m; };
            float Q[64]; setDefaults(Q); Q[MO_MODEL] = 1.0F; Q[MO_AMOUNT] = 0.0F;
            const Run plain = runVoice(*saw, Q, z1, &bz, 1.0);
            const double plainStep = stepMax(plain.out, 4800, plain.out.size());
            // the same note, the knobs and the model thrown about every 100 ms
            Voice v; Inputs in; in.key = 60; in.velocity = 0.8F; in.gate = true;
            float R[64]; setDefaults(R); R[MO_MODEL] = 1.0F;
            v.noteOn(R, kSr, in, z1, &bz, 7U);
            std::vector<float> out; const int n = static_cast<int>(2.4 * kSr);
            for (int i = 0; i < n; ++i) {
                const int seg = i / 4800;   // 100 ms
                if (i % 4800 == 0) {
                    switch (seg) {
                        case 1: R[MO_AMOUNT] = 0.0F; break;
                        case 2: R[MO_AMOUNT] = 1.0F; break;
                        case 3: R[MO_BRIGHT] = 6.0F; break;
                        case 4: R[MO_BRIGHT] = -6.0F; break;
                        case 5: R[MO_BRIGHT] = 0.0F; R[MO_FORMANT] = 2.0F; break;
                        case 6: R[MO_FORMANT] = 1.0F; v.setModel(z3); break;
                        case 7: v.setModel(z2); break;
                        case 8: v.setModel(z1); R[MO_UNISON] = 2.0F; break;
                        case 9: R[MO_UNISON] = 0.0F; break;
                        case 10: R[MO_SHAPE] = 2.0F; break;
                        case 11: R[MO_SHAPE] = 1.0F; R[MO_LIFE] = 2.0F; R[MO_VIBRATO] = 2.0F; break;
                        case 12: R[MO_LIFE] = 1.0F; R[MO_VIBRATO] = 1.0F; R[E_FILT_TYPE] = 1.0F; R[E_CUTOFF] = 600.0F; R[E_RESO] = 0.7F; break;
                        case 13: R[E_CUTOFF] = 8000.0F; break;
                        case 14: R[E_FILT_TYPE] = 0.0F; break;
                        case 15: R[MO_AMOUNT] = 0.0F; break;
                        default: break;
                    }
                }
                const std::size_t idx = static_cast<std::size_t>(i) % saw->interleaved.size();
                float l = saw->interleaved[idx], rr = l;
                if (i % 128 == 0) v.setInputs(in, kSr);
                v.tick(l, rr); out.push_back(l);
            }
            CHECK(allFinite(out), "knob storm: finite");
            // a click = a sample step that sticks out of the sound around it. (BRIGHT +6 makes the saw's own edges steeper: the steps
            // of a settled bright saw are legitimately larger, so each change is judged against the settled sound before and after it)
            double worst = 0; int worstSeg = -1;
            for (int seg = 1; seg < 16; ++seg) {
                const std::size_t at = static_cast<std::size_t>(seg) * 4800U;
                const double atChange = stepMax(out, at, at + 960U);                                               // the first 20 ms after the change
                const double settled = std::max(stepMax(out, at - 960U, at), stepMax(out, at + 3840U, at + 4800U));   // the 20 ms before, the last 20 ms after
                const double ratio = atChange / std::max(settled, 1e-6);
                if (ratio > worst) { worst = ratio; worstSeg = seg; }
            }
            CHECK(worst < 1.35, "the first 20 ms after every change: no click (worst step ratio %.2f at %d00 ms)", worst, worstSeg);
            CHECK(stepMax(out, 4800, out.size()) < plainStep * 4.0, "nothing wild anywhere (%.3f vs plain %.3f)", stepMax(out, 4800, out.size()), plainStep);
            // AMOUNT 0 at the end = the plain saw again, as loud
            const double dBend = 20 * std::log10(rmsOf(out, static_cast<std::size_t>(2.0 * kSr), static_cast<std::size_t>(2.4 * kSr)) / rmsOf(plain.out, 24000, 48000));
            CHECK(std::fabs(dBend) < 1.0, "after the storm, AMOUNT 0: the plain saw as loud as before (%.2f dB)", dBend);
            // the Taksim zone (another octave): as loud as the plain saw, no comb
            float T[64]; setDefaults(T); T[MO_MODEL] = 2.0F;
            const Run tak = runVoice(*saw, T, z2, &bz, 1.0);
            const double dBt = 20 * std::log10(rmsOf(tak.out, 24000, 48000) / rmsOf(plain.out, 24000, 48000));
            CHECK(allFinite(tak.out) && std::fabs(dBt) < 1.5, "a model learned in another octave: the sound stays whole and as loud (%.2f dB)", dBt);
        }
    }
    // ---- 9) SILVETON_SYNTH_V1: the note calculated from the learned model - it plays the learned harmonics at the note, every model and
    //      every key at the same loudness by ear, FORMANT SHIFT and HARMONICS do what they say, nothing clicks, 16 notes fit
    {
        const auto built = builtinLearnedModels();
        const auto zoneOf = [&](int m, int key) -> const ZoneShape* { const auto& ms = built->models[static_cast<std::size_t>(m - 1)]; const int z = ms.zoneFor(key); return z >= 0 ? &ms.zones[static_cast<std::size_t>(z)] : nullptr; };
        const ZoneShape* z1 = zoneOf(1, 60);
        CHECK(z1 != nullptr && z1->trackRows > 0 && z1->trackH >= 32 && static_cast<int>(z1->harmTrack.size()) == z1->trackRows * z1->trackH, "the harmonics frame by frame are kept (%d rows x %d)", z1 ? z1->trackRows : 0, z1 ? z1->trackH : 0);
        float S[kEngineParamCountLegacy]; silveton::sampler::synth::setDefaults(S); S[MO_MODEL] = 1.0F;
        const auto runSynth = [&](const float* params, const ZoneShape* z, int key, double seconds, std::vector<double>* semis = nullptr) {
            silveton::sampler::synth::Voice v; Inputs in; in.key = key; in.velocity = 0.8F; in.gate = true;
            v.noteOn(params, kSr, in, z, 11U);
            const double inc = 440.0 * std::pow(2.0, (key - 69) / 12.0) / kSr;
            std::vector<float> out; const int n = static_cast<int>(seconds * kSr);
            for (int i = 0; i < n; ++i) { float l = 0.0F, r = 0.0F; if (i % 128 == 0) { v.setInputs(in, kSr); if (semis) semis->push_back(v.pitchSemis()); } v.tick(inc, l, r); out.push_back(l); }
            return out;
        };
        const std::vector<float> a = runSynth(S, z1, 60, 1.0);
        CHECK(allFinite(a), "synth: finite");
        {   // the learned harmonics, at the note: the output's harmonics against the zone's steady ones (dB against the strongest)
            const auto sp = spectrumDb(a, 24000, 8192);
            const double binHz = kSr / 8192.0;
            double mx = -999.0; std::vector<double> got(24, -200.0);
            for (int k = 1; k <= 24; ++k) { const auto b = static_cast<std::size_t>(std::lround(261.63 * k / binHz)); double m = -999.0; for (std::size_t j = b - 2; j <= b + 2; ++j) m = std::max(m, sp[j]); got[static_cast<std::size_t>(k - 1)] = m; mx = std::max(mx, m); }
            double err = 0.0; int cnt = 0;
            for (int k = 1; k <= 24; ++k) { const float want = z1->harmDb[k - 1]; if (want < -40.0F) continue; const double d = (got[static_cast<std::size_t>(k - 1)] - mx) - want; err += d * d; ++cnt; }
            const double rms = cnt ? std::sqrt(err / cnt) : 99.0;
            CHECK(cnt >= 6 && rms < 3.0, "synth plays the learned harmonics (%d of them, RMS error %.1f dB)", cnt, rms);
            // the pitch: the fundamental is the note
            std::size_t best = 0; for (std::size_t j = 1; j < 400; ++j) if (sp[j] > sp[best]) best = j;
            const double peakHz = static_cast<double>(best) * binHz;
            const bool onNote = std::fabs(peakHz - 261.63) < binHz * 2.5 || std::fabs(peakHz - 523.25) < binHz * 2.5 || std::fabs(peakHz - 784.9) < binHz * 2.5;
            CHECK(onNote, "the strongest line is a harmonic of the note (%.0f Hz)", peakHz);
        }
        {   // the one loudness by ear: models 1, 4, 7, 9 and keys 48 / 60 / 72
            const double ref = earDb(a, 24000);
            double worst = 0.0;
            for (int m : {4, 7, 9, 11}) { const ZoneShape* z = zoneOf(m, 60); if (!z) continue; float Q[kEngineParamCountLegacy]; std::memcpy(Q, S, sizeof Q); Q[MO_MODEL] = static_cast<float>(m); const double d = earDb(runSynth(Q, z, 60, 1.0), 24000) - ref; worst = std::max(worst, std::fabs(d)); }
            CHECK(worst < 1.0, "every model as loud by ear (worst %.2f dB)", worst);
            double worstKey = 0.0;
            for (int key : {48, 72, 84}) { const ZoneShape* z = zoneOf(1, key); if (!z) continue; const double d = earDb(runSynth(S, z, key, 1.0), 24000) - ref; worstKey = std::max(worstKey, std::fabs(d)); }
            CHECK(worstKey < 1.0, "every key as loud by ear (worst %.2f dB)", worstKey);
        }
        {   // FORMANT SHIFT +12 moves the spectrum up, HARMONICS 8 takes the top away, BRIGHT +6 brightens - all as loud
            const double c0 = centroidHz(spectrumDb(a, 24000, 4096), kSr);
            float Q[kEngineParamCountLegacy]; std::memcpy(Q, S, sizeof Q); Q[silveton::sampler::synth::SY_SHIFT] = 12.0F;
            const auto up = runSynth(Q, z1, 60, 1.0); const double cUp = centroidHz(spectrumDb(up, 24000, 4096), kSr);
            CHECK(cUp > c0 * 1.2, "FORMANT SHIFT +12 moves the timbre up (%.0f -> %.0f Hz)", c0, cUp);
            CHECK(std::fabs(earDb(up, 24000) - earDb(a, 24000)) < 1.0, "... as loud (%.2f dB)", earDb(up, 24000) - earDb(a, 24000));
            std::memcpy(Q, S, sizeof Q); Q[silveton::sampler::synth::SY_HARMONICS] = 8.0F;
            const auto few = runSynth(Q, z1, 60, 1.0);
            const auto spF = spectrumDb(few, 24000, 4096); const auto spA = spectrumDb(a, 24000, 4096);
            const auto b12 = static_cast<std::size_t>(std::lround(261.63 * 12 / (kSr / 4096)));
            CHECK(spF[b12] < spA[b12] - 20.0, "HARMONICS 8: the 12th harmonic is gone (%.1f -> %.1f dB)", spA[b12], spF[b12]);
            std::memcpy(Q, S, sizeof Q); Q[MO_BRIGHT] = 6.0F;
            const auto br = runSynth(Q, z1, 60, 1.0);
            CHECK(centroidHz(spectrumDb(br, 24000, 4096), kSr) > c0 * 1.15 && std::fabs(earDb(br, 24000) - earDb(a, 24000)) < 1.0, "BRIGHT +6: brighter and as loud");
        }
        {   // the knob storm: nothing clicks (shift, bright, harmonics, model, shape thrown about every 100 ms)
            silveton::sampler::synth::Voice v; Inputs in; in.key = 60; in.velocity = 0.8F; in.gate = true;
            float R[kEngineParamCountLegacy]; std::memcpy(R, S, sizeof R);
            v.noteOn(R, kSr, in, z1, 5U);
            const double inc = 261.63 / kSr;
            std::vector<float> out; const int n = static_cast<int>(1.6 * kSr);
            for (int i = 0; i < n; ++i) {
                const int seg = i / 4800;
                if (i % 4800 == 0) {
                    switch (seg) {
                        case 1: R[silveton::sampler::synth::SY_SHIFT] = 12.0F; break;
                        case 2: R[silveton::sampler::synth::SY_SHIFT] = -12.0F; break;
                        case 3: R[silveton::sampler::synth::SY_SHIFT] = 0.0F; R[MO_BRIGHT] = 6.0F; break;
                        case 4: R[MO_BRIGHT] = -6.0F; break;
                        case 5: R[MO_BRIGHT] = 0.0F; R[silveton::sampler::synth::SY_HARMONICS] = 6.0F; break;
                        case 6: R[silveton::sampler::synth::SY_HARMONICS] = 48.0F; v.setZone(zoneOf(7, 60)); break;
                        case 7: v.setZone(zoneOf(1, 60)); R[MO_UNISON] = 2.0F; break;
                        case 8: R[MO_UNISON] = 0.0F; R[E_FILT_TYPE] = 1.0F; R[E_CUTOFF] = 500.0F; R[E_RESO] = 0.6F; break;
                        case 9: R[E_CUTOFF] = 9000.0F; break;
                        case 10: R[E_FILT_TYPE] = 0.0F; break;
                        default: break;
                    }
                }
                float l = 0.0F, r = 0.0F; if (i % 128 == 0) v.setInputs(in, kSr); v.tick(inc, l, r); out.push_back(l);
            }
            CHECK(allFinite(out), "synth storm: finite");
            const auto stepMax = [](const std::vector<float>& x, std::size_t from, std::size_t to) { double m = 0; for (std::size_t i = std::max<std::size_t>(from, 1); i < to && i < x.size(); ++i) m = std::max(m, std::fabs(static_cast<double>(x[i]) - x[i - 1])); return m; };
            double worst = 0; int worstSeg = -1;
            for (int seg = 1; seg < 11; ++seg) {
                const std::size_t at = static_cast<std::size_t>(seg) * 4800U;
                const double atChange = stepMax(out, at, at + 960U), settled = std::max(stepMax(out, at - 960U, at), stepMax(out, at + 3840U, at + 4800U));
                const double ratio = atChange / std::max(settled, 1e-6); if (ratio > worst) { worst = ratio; worstSeg = seg; }
            }
            CHECK(worst < 1.35, "synth: no click at any change (worst step ratio %.2f at %d00 ms)", worst, worstSeg);
        }
        {   // 16 notes in real time
            silveton::sampler::synth::Voice vs[16]; Inputs in; in.key = 48; in.velocity = 0.8F; in.gate = true;
            for (auto& v : vs) v.noteOn(S, kSr, in, zoneOf(1, 48), 3U);
            const double inc = 130.81 / kSr;
            const auto t0 = std::chrono::steady_clock::now();
            float acc = 0.0F;
            for (int i = 0; i < 48000; ++i) for (auto& v : vs) { float l = 0.0F, r = 0.0F; v.tick(inc, l, r); acc += l; }
            const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
            std::printf("  16 synth notes (48 harmonics, C3): %.1f%% of real time (%.3f s for 1 s)  [%g]\n", sec * 100.0, sec, static_cast<double>(acc) * 0.0);
            CHECK(sec < 0.8, "16 synth notes fit in real time here (%.2f s)", sec);
        }
    }
    std::printf("%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
