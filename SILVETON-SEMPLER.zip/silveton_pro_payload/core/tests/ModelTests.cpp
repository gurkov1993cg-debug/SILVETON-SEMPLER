// SILVETON_MODEL_V1 / SILVETON_SYNTH_V1 - the learned models and SILVETON SYNTH checked with numbers: a learned file made here, the
// built-in models, the note calculated from the model (harmonics, loudness by ear, FORMANT SHIFT, HARMONICS, BRIGHT, no clicks, 16 notes).
// (The checks of SILVETON MODEL, the engine that bent a recording towards a model, went with it on 03.11.2026.)
#include "ModelVoice.h"
#include "SynthVoice.h"
#include "ModelFixtures.h"
#include "silveton/sampler/ModelBank.h"

#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <memory>
#include <vector>

using namespace silveton::sampler;
using namespace silveton::sampler::model;

static int g_checks = 0, g_fail = 0;
#define CHECK(cond, ...) do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("FAIL line %d: %s  ", __LINE__, #cond); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

namespace {
constexpr double kPi = 3.14159265358979323846;
constexpr double kSr = 48000.0;

// ---- a learned file written the way the teacher writes it (SVOSC003), one sound, one zone over the whole keyboard
void put16(std::vector<std::uint8_t>& b, unsigned v) { b.push_back(static_cast<std::uint8_t>(v & 255U)); b.push_back(static_cast<std::uint8_t>((v >> 8) & 255U)); }
void put32(std::vector<std::uint8_t>& b, unsigned v) { for (int i = 0; i < 4; ++i) b.push_back(static_cast<std::uint8_t>((v >> (8 * i)) & 255U)); }
void putF(std::vector<std::uint8_t>& b, float f) { unsigned x; std::memcpy(&x, &f, 4); put32(b, x); }
struct Teach { double f0 = 261.6; double tiltDbOct = -12.0; float scoopCents = -40.0F; float breathDb = -25.0F; float chiffDb = -10.0F; float unison = 0.0F; float life = 0.0F; float vibHz = 0.0F, vibCents = 0.0F; float attackMs = 20.0F; bool swell = false; };
std::vector<std::uint8_t> learnedFile(const Teach& t) {
    std::vector<std::uint8_t> b;
    const char* magic = "SVOSC003"; b.insert(b.end(), magic, magic + 8);
    put32(b, 1);
    const std::string name = "TEACHER", slot = "TEST";
    put16(b, static_cast<unsigned>(name.size())); b.insert(b.end(), name.begin(), name.end());
    put16(b, static_cast<unsigned>(slot.size())); b.insert(b.end(), slot.begin(), slot.end());
    put16(b, 1);
    b.push_back(0); b.push_back(127); b.push_back(60); b.push_back(1 | 2);
    float n[40] = {}; n[0] = static_cast<float>(t.f0); n[1] = 0.0F; n[2] = t.scoopCents; n[3] = t.vibHz; n[4] = t.vibCents; n[5] = t.life; n[7] = t.attackMs; n[11] = 200.0F; n[32] = t.unison;
    for (int i = 0; i < 40; ++i) putF(b, n[i]);
    const int H = 32, A = 60, L = 32;
    put16(b, H); put16(b, A); put16(b, L); putF(b, 5.0F);
    // the harmonics: a 1/k^x tilt; the attack rises (or swells) in loudness
    for (int r = 0; r < A + L; ++r) {
        float levelDb = 0.0F;
        if (r < A) { const double tt = r * 5.0 / 1000.0; levelDb = t.swell ? static_cast<float>(-12.0 * (1.0 - std::min(1.0, tt / 0.28))) : static_cast<float>(tt < t.attackMs / 1000.0 ? -30.0 * (1.0 - tt / (t.attackMs / 1000.0)) : 0.0); }
        for (int k = 1; k <= H; ++k) { const double db = t.tiltDbOct * std::log2(static_cast<double>(k)) + levelDb; b.push_back(static_cast<std::uint8_t>(std::min(255.0, std::round(-2.0 * db)))); }
    }
    // the noise: eight bands, a breath that sits in bands 4-5 (2-8 kHz); the attack has a chiff in bands 4-7 for the first 8 rows
    for (int r = 0; r < A + L; ++r) for (int tb = 0; tb < 8; ++tb) {
        double db = -120.0;
        if (tb >= 4 && tb <= 5) db = t.breathDb;
        if (r < 8 && tb >= 4) db = std::max(db, static_cast<double>(t.chiffDb));
        b.push_back(static_cast<std::uint8_t>(std::min(255.0, std::round(-2.0 * db))));
    }
    for (int r = 0; r < A; ++r) { const double tt = r * 5.0 / 1000.0; const double c = tt < 0.08 ? t.scoopCents * (1.0 - tt / 0.08) : 0.0; b.push_back(static_cast<std::uint8_t>(static_cast<std::int8_t>(std::lround(c)))); }
    const char* end = "SVOSCEND"; b.insert(b.end(), end, end + 8);
    return b;
}


// SILVETON_FULLTRACK_V1: a full-track file as TEACHER 2.1 writes it - the rows run from the start of the sound to its END.
// The sound dies away at `dbPerSec`; `tailFloorDb` is where it stops dying (a held tail). Harmonics 1..H with a 1/k tilt.
struct Full { int rows = 600; double dbPerSec = -24.0; double tailFloorDb = -90.0; bool looped = false; float loopMs = 0.0F; double f0 = 261.6; double lengthSec() const { return rows * 0.005; } };
std::vector<std::uint8_t> fullFile(const Full& t, bool secondZoneSteady = false) {
    std::vector<std::uint8_t> b;
    const char* magic = "SVOSC003"; b.insert(b.end(), magic, magic + 8);
    put32(b, 1);
    const std::string name = "FULL", slot = "TEST";
    put16(b, static_cast<unsigned>(name.size())); b.insert(b.end(), name.begin(), name.end());
    put16(b, static_cast<unsigned>(slot.size())); b.insert(b.end(), slot.begin(), slot.end());
    put16(b, secondZoneSteady ? 2 : 1);
    for (int zi = 0; zi < (secondZoneSteady ? 2 : 1); ++zi) {
        const bool steadyZone = zi == 1;   // zone 2: a sound that does not die (the loudness must come out the same)
        b.push_back(steadyZone ? 70 : 0); b.push_back(steadyZone ? 127 : 69); b.push_back(steadyZone ? 72 : 60); b.push_back(static_cast<std::uint8_t>(1 | ((steadyZone || t.looped) ? 2 : 0)));
        float n[40] = {}; n[0] = static_cast<float>(t.f0); n[11] = 200.0F; n[29] = static_cast<float>(t.rows * 5.0); n[31] = steadyZone ? 1000.0F : t.loopMs;
        for (int i = 0; i < 40; ++i) putF(b, n[i]);
        const int H = 24, A = t.rows, L = 32;
        put16(b, H); put16(b, A); put16(b, L); putF(b, 5.0F);
        const auto rowDb = [&](int r) { if (steadyZone) return 0.0; return std::max(t.tailFloorDb, t.dbPerSec * (r * 0.005)); };
        for (int r = 0; r < A + L; ++r) {
            const double lv = r < A ? rowDb(r) : rowDb(A - 1);
            for (int k = 1; k <= H; ++k) { const double db = -6.0 * std::log2(static_cast<double>(k)) + lv; b.push_back(static_cast<std::uint8_t>(std::min(254.0, std::round(-2.0 * db)))); }
        }
        for (int r = 0; r < A + L; ++r) for (int tb = 0; tb < 8; ++tb) b.push_back(255);
        for (int r = 0; r < A; ++r) b.push_back(0);
    }
    const char* end = "SVOSCEND"; b.insert(b.end(), end, end + 8);
    return b;
}

std::vector<double> spectrumDb(const std::vector<float>& x, std::size_t from, std::size_t n) {
    std::vector<std::complex<double>> a(n);
    for (std::size_t i = 0; i < n; ++i) a[i] = std::complex<double>((from + i < x.size() ? x[from + i] : 0.0F) * (0.5 - 0.5 * std::cos(2 * kPi * (static_cast<double>(i) + 0.5) / static_cast<double>(n))), 0.0);
    // a slow DFT is fine for the test sizes used (n = 4096)
    const std::size_t half = n / 2; std::vector<double> out(half, 0.0);
    std::vector<std::complex<double>> f(n);
    for (std::size_t i = 1, j = 0; i < n; ++i) { std::size_t bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) std::swap(a[i], a[j]); }
    for (std::size_t len = 2; len <= n; len <<= 1) { const double ang = -2 * kPi / static_cast<double>(len); const std::complex<double> wl(std::cos(ang), std::sin(ang)); for (std::size_t i = 0; i < n; i += len) { std::complex<double> w(1, 0); for (std::size_t j = 0; j < len / 2; ++j) { const std::complex<double> u = a[i + j], v = a[i + j + len / 2] * w; a[i + j] = u + v; a[i + j + len / 2] = u - v; w *= wl; } } }
    for (std::size_t k = 0; k < half; ++k) out[k] = 20 * std::log10(std::abs(a[k]) + 1e-9);
    return out;
}
double centroidHz(const std::vector<double>& db, double sr) { double n = 0, d = 0; for (std::size_t k = 1; k < db.size(); ++k) { const double p = std::pow(10.0, db[k] / 10.0); n += p * static_cast<double>(k) * sr / (2.0 * static_cast<double>(db.size())); d += p; } return d > 0 ? n / d : 0; }
bool allFinite(const std::vector<float>& v) { for (float f : v) if (!std::isfinite(f)) return false; return true; }
// SILVETON_MODEL_EAR_V1: the loudness as the ear hears it (the A curve over the spectrum) - what the engine keeps equal
double earDb(const std::vector<float>& x, std::size_t from) {
    const auto sp = spectrumDb(x, from, 4096);
    double e = 0.0;
    for (std::size_t k = 1; k < sp.size(); ++k) {
        const double hz = static_cast<double>(k) * kSr / 4096.0, f2 = hz * hz;
        const double a = 12194.0 * 12194.0 * f2 * f2 / ((f2 + 20.6 * 20.6) * std::sqrt((f2 + 107.7 * 107.7) * (f2 + 737.9 * 737.9)) * (f2 + 12194.0 * 12194.0)) * 1.2589;
        e += std::pow(10.0, sp[k] / 10.0) * a * a;
    }
    return 10.0 * std::log10(e + 1e-18);
}

}  // namespace

int main() {
    // ---- 1) the learned file
    const Teach dark;   // a dark teacher (-12 dB/oct), a scoop of -40 cents
    const auto lm = parseLearnedModels(learnedFile(dark), "test.sv");
    CHECK(lm->error.empty() && lm->models.size() == 1 && lm->models[0].name == "TEACHER" && lm->models[0].slot == "TEST", "the file is read (%s)", lm->error.c_str());
    const ModelShape& shape1 = lm->models[0];
    CHECK(shape1.zones.size() == 1 && shape1.zones[0].ok && shape1.zoneFor(60) == 0 && shape1.zoneFor(10) == 0, "one zone over the keyboard");
    const ZoneShape& mz = shape1.zones[0];
    {
        // the tone curve: -12 dB an octave from the first harmonic up
        const float t1 = mz.tone[static_cast<int>(std::lround(bandOfHz(static_cast<float>(dark.f0))))], t4 = mz.tone[static_cast<int>(std::lround(bandOfHz(static_cast<float>(dark.f0 * 4))))];
        CHECK(std::fabs((t4 - t1) + 24.0F) < 4.0F, "the tone falls 24 dB over two octaves (%.1f)", t4 - t1);
        CHECK(mz.tone[0] < -100.0F, "below the first harmonic: no information");
        CHECK(mz.level[0] < -20.0F && std::fabs(mz.level[10]) < 1.0F, "the loudness curve: quiet at the start (%.1f), steady by 100 ms (%.1f)", mz.level[0], mz.level[10]);
        CHECK(std::fabs(mz.scoop[0] + 40.0F) < 2.0F && mz.scoop[20] == 0.0F, "the scoop: -40 c at the start (%.0f), gone by 100 ms", mz.scoop[0]);
        CHECK(std::fabs(mz.breathDb[2] + 25.0F) < 4.0F && mz.breathDb[0] < -100.0F, "the breath sits in the high band (%.1f) and nowhere low (%.1f)", mz.breathDb[2], mz.breathDb[0]);
        CHECK(mz.chiffDb[2] > mz.breathDb[2] + 10.0F, "the chiff stands above the breath (%.1f vs %.1f)", mz.chiffDb[2], mz.breathDb[2]);
        CHECK(std::fabs(mz.steadyRms - 0.74F) < 0.15F, "the steady loudness of the model (%.2f)", mz.steadyRms);
    }
    {
        std::vector<std::uint8_t> old(learnedFile(dark)); std::memcpy(old.data(), "SVOSC001", 8);
        CHECK(!parseLearnedModels(old, "x")->error.empty(), "an old LAB file is refused with a reason");
        std::vector<std::uint8_t> cut(learnedFile(dark)); cut.resize(cut.size() / 2);
        CHECK(!parseLearnedModels(cut, "x")->error.empty(), "a cut file is refused");
    }
    // ---- 2) the 11 real sounds the sampler used to carry inside (now TEST DATA: nothing is built into the sampler any more)
    {
        const auto built = fixtureLearnedModels();
        CHECK(built->error.empty() && built->models.size() == 11, "the 11 test sounds (%zu) %s", built->models.size(), built->error.c_str());
        if (built->models.size() == 11) CHECK(built->models[3].name == "Radi Cz Casio So" && built->models[10].name == "Radi Expert Mode", "MODEL 4 .. 11 in the teacher's order");
        if (built->models.size() >= 3) {
            const ZoneShape* z1 = &built->models[0].zones[static_cast<std::size_t>(built->models[0].zoneFor(60))];
            const ZoneShape* z2 = &built->models[1].zones[static_cast<std::size_t>(built->models[1].zoneFor(60))];
            const ZoneShape* z3 = &built->models[2].zones[static_cast<std::size_t>(built->models[2].zoneFor(60))];
            CHECK(!z1->pitchDoubt && !z3->pitchDoubt, "Radi Pa5x and Musi 43: the learned pitch is in the harmonics");
            CHECK(z2->pitchDoubt, "Radi Taksim 2024: no fundamental in the harmonics (learned in another octave) - SYNTH plays it as learned");
        }
    }
    // ---- 2b) SILVETON_MODELS_FROM_FILE_V1: the models are exactly the sounds of the file; they can be taken out of it for good
    {
        const std::vector<std::uint8_t> all = fixtureModelFileBytes();
        const auto full = parseLearnedModels(all, "all.sv");
        CHECK(full->error.empty() && full->models.size() == 11 && full->total == 11, "the file of 11 sounds: %zu models, total %zu", full->models.size(), full->total);
        // some are taken out: the rest stay in the order of the file, with everything they held
        std::vector<std::uint8_t> cut; std::string why;
        CHECK(removeSoundsFromBytes(all, {0, 4, 10}, cut, why), "three sounds taken out of the bytes (%s)", why.c_str());
        const auto less = parseLearnedModels(cut, "less.sv");
        CHECK(less->error.empty() && less->models.size() == 8 && less->total == 8, "8 sounds are left (%zu)", less->models.size());
        if (less->models.size() == 8) {
            const int keep[8] = {1, 2, 3, 5, 6, 7, 8, 9};
            bool same = true;
            for (int k = 0; k < 8; ++k) {
                const ModelShape& a = less->models[static_cast<std::size_t>(k)]; const ModelShape& b = full->models[static_cast<std::size_t>(keep[k])];
                same = same && a.name == b.name && a.slot == b.slot && a.zones.size() == b.zones.size();
                for (std::size_t z = 0; z < a.zones.size() && z < b.zones.size(); ++z) same = same && a.zones[z].harmTrack == b.zones[z].harmTrack && a.zones[z].lowKey == b.zones[z].lowKey && a.zones[z].f0Hz == b.zones[z].f0Hz;
            }
            CHECK(same, "the sounds that stay are the same, in the same order");
            CHECK(less->models[0].name == full->models[1].name && less->models[7].name == full->models[9].name, "the first that stays is the second of the file, the last is the tenth");
        }
        // the same sound twice in the list counts once; nothing out = the same file; all out = an empty file that reads as no models
        std::vector<std::uint8_t> twice, none, everything;
        CHECK(removeSoundsFromBytes(all, {2, 2}, twice, why) && parseLearnedModels(twice, "t")->models.size() == 10, "a sound named twice goes once");
        CHECK(removeSoundsFromBytes(all, {}, none, why) && none == all, "nothing taken out: the same bytes");
        CHECK(removeSoundsFromBytes(all, {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}, everything, why), "all taken out");
        { const auto e = parseLearnedModels(everything, "e.sv"); CHECK(e->error.empty() && e->models.empty() && e->total == 0, "a file with no sounds reads as no models"); }
        std::vector<std::uint8_t> bad;
        CHECK(!removeSoundsFromBytes(all, {11}, bad, why) && !why.empty(), "a place that is not in the file is refused (%s)", why.c_str());
        CHECK(!removeSoundsFromBytes(all, {-1}, bad, why), "a place under 0 is refused");
        { std::vector<std::uint8_t> half(all.begin(), all.begin() + static_cast<std::ptrdiff_t>(all.size() / 2)); CHECK(!removeSoundsFromBytes(half, {0}, bad, why), "a cut file is refused"); }
        { std::vector<std::uint8_t> lab(all); std::memcpy(lab.data(), "SVOSC001", 8); CHECK(!removeSoundsFromBytes(lab, {0}, bad, why), "a LAB wave file is refused"); }
        // on a file on the disk: the old file is replaced only by a complete new one
        const std::string path = "/tmp/silveton_models_delete_test.sv";
        { std::ofstream o(path.c_str(), std::ios::binary | std::ios::trunc); o.write(reinterpret_cast<const char*>(all.data()), static_cast<std::streamsize>(all.size())); }
        CHECK(removeLearnedSounds(path, {1, 2}).empty(), "two sounds taken out of the file");
        { const auto d = loadLearnedModels(path); CHECK(d->error.empty() && d->models.size() == 9 && d->models[0].name == full->models[0].name && d->models[1].name == full->models[3].name, "the file on the disk holds 9, in order (%zu)", d->models.size()); }
        { std::ifstream t((path + ".new").c_str()); CHECK(!t, "no half-made file is left beside it"); }
        const std::string beforeErr = removeLearnedSounds(path, {99});
        CHECK(!beforeErr.empty() && loadLearnedModels(path)->models.size() == 9, "a wrong place: refused, the file stays as it was (%s)", beforeErr.c_str());
        CHECK(!removeLearnedSounds("/tmp/silveton_models_not_there.sv", {0}).empty(), "no file: the reason");
        CHECK(removeLearnedSounds(path, {}).empty() && loadLearnedModels(path)->models.size() == 9, "nothing to take out: nothing is done");
        std::remove(path.c_str());
    }
    // ---- 3) SILVETON_SYNTH_V1: the note calculated from the learned model - it plays the learned harmonics at the note, every model and
    //      every key at the same loudness by ear, FORMANT SHIFT and HARMONICS do what they say, nothing clicks, 16 notes fit
    {
        const auto built = fixtureLearnedModels();
        const auto zoneOf = [&](int m, int key) -> const ZoneShape* { const auto& ms = built->models[static_cast<std::size_t>(m - 1)]; const int z = ms.zoneFor(key); return z >= 0 ? &ms.zones[static_cast<std::size_t>(z)] : nullptr; };
        const ZoneShape* z1 = zoneOf(1, 60);
        CHECK(z1 != nullptr && z1->trackRows > 0 && z1->trackH >= 32 && static_cast<int>(z1->harmTrack.size()) == z1->trackRows * z1->trackH, "the harmonics frame by frame are kept (%d rows x %d)", z1 ? z1->trackRows : 0, z1 ? z1->trackH : 0);
        float S[kEngineParamCountLegacy]; silveton::sampler::synth::setDefaults(S); S[MO_MODEL] = 1.0F;
        const auto runSynth = [&](const float* params, const ZoneShape* z, int key, double seconds, std::vector<double>* semis = nullptr) {
            silveton::sampler::synth::Voice v; Inputs in; in.key = key; in.velocity = 0.8F; in.gate = true;
            v.noteOn(params, kSr, in, z, 11U);
            const double inc = 440.0 * std::pow(2.0, (key - 69) / 12.0) / kSr;
            std::vector<float> out; const int n = static_cast<int>(seconds * kSr);
            for (int i = 0; i < n; ++i) { float l = 0.0F, r = 0.0F; if (i % 128 == 0) { v.setInputs(in, kSr); if (semis) semis->push_back(v.pitchSemis()); } v.tick(inc, l, r); out.push_back(l); }
            return out;
        };
        const std::vector<float> a = runSynth(S, z1, 60, 1.0);
        CHECK(allFinite(a), "synth: finite");
        {   // the learned harmonics, at the note: the output's harmonics against the zone's steady ones (dB against the strongest)
            const auto sp = spectrumDb(a, 24000, 8192);
            const double binHz = kSr / 8192.0;
            double mx = -999.0; std::vector<double> got(24, -200.0);
            for (int k = 1; k <= 24; ++k) { const auto b = static_cast<std::size_t>(std::lround(261.63 * k / binHz)); double m = -999.0; for (std::size_t j = b - 2; j <= b + 2; ++j) m = std::max(m, sp[j]); got[static_cast<std::size_t>(k - 1)] = m; mx = std::max(mx, m); }
            double err = 0.0; int cnt = 0;
            for (int k = 1; k <= 24; ++k) { const float want = z1->harmDb[k - 1]; if (want < -40.0F) continue; const double d = (got[static_cast<std::size_t>(k - 1)] - mx) - want; err += d * d; ++cnt; }
            const double rms = cnt ? std::sqrt(err / cnt) : 99.0;
            CHECK(cnt >= 6 && rms < 3.0, "synth plays the learned harmonics (%d of them, RMS error %.1f dB)", cnt, rms);
            // the pitch: the fundamental is the note
            std::size_t best = 0; for (std::size_t j = 1; j < 400; ++j) if (sp[j] > sp[best]) best = j;
            const double peakHz = static_cast<double>(best) * binHz;
            const bool onNote = std::fabs(peakHz - 261.63) < binHz * 2.5 || std::fabs(peakHz - 523.25) < binHz * 2.5 || std::fabs(peakHz - 784.9) < binHz * 2.5;
            CHECK(onNote, "the strongest line is a harmonic of the note (%.0f Hz)", peakHz);
        }
        {   // the one loudness by ear: models 1, 4, 7, 9 and keys 48 / 60 / 72
            const double ref = earDb(a, 24000);
            double worst = 0.0;
            for (int m : {4, 7, 9, 11}) { const ZoneShape* z = zoneOf(m, 60); if (!z) continue; float Q[kEngineParamCountLegacy]; std::memcpy(Q, S, sizeof Q); Q[MO_MODEL] = static_cast<float>(m); const double d = earDb(runSynth(Q, z, 60, 1.0), 24000) - ref; worst = std::max(worst, std::fabs(d)); }
            CHECK(worst < 1.0, "every model as loud by ear (worst %.2f dB)", worst);
            double worstKey = 0.0;
            for (int key : {48, 72, 84}) { const ZoneShape* z = zoneOf(1, key); if (!z) continue; const double d = earDb(runSynth(S, z, key, 1.0), 24000) - ref; worstKey = std::max(worstKey, std::fabs(d)); }
            CHECK(worstKey < 1.0, "every key as loud by ear (worst %.2f dB)", worstKey);
        }
        {   // the old FORMANT SHIFT id is retired (03.11.2026 18:26 - the sampler's TUNE moves the timbre now: SamplerTests testSynthInSampler):
            // the number in a saved blend changes nothing. HARMONICS 8 takes the top away, BRIGHT +6 brightens - all as loud
            const double c0 = centroidHz(spectrumDb(a, 24000, 4096), kSr);
            float Q[kEngineParamCountLegacy]; std::memcpy(Q, S, sizeof Q); Q[silveton::sampler::synth::SY_SHIFT] = 12.0F;
            const auto up = runSynth(Q, z1, 60, 1.0); const double cUp = centroidHz(spectrumDb(up, 24000, 4096), kSr);
            CHECK(std::fabs(cUp - c0) < c0 * 0.01, "the retired FORMANT SHIFT number changes nothing (%.0f -> %.0f Hz)", c0, cUp);
            CHECK(std::fabs(earDb(up, 24000) - earDb(a, 24000)) < 0.1, "... as loud (%.2f dB)", earDb(up, 24000) - earDb(a, 24000));
            std::memcpy(Q, S, sizeof Q); Q[silveton::sampler::synth::SY_HARMONICS] = 8.0F;
            const auto few = runSynth(Q, z1, 60, 1.0);
            const auto spF = spectrumDb(few, 24000, 4096); const auto spA = spectrumDb(a, 24000, 4096);
            const auto b12 = static_cast<std::size_t>(std::lround(261.63 * 12 / (kSr / 4096)));
            CHECK(spF[b12] < spA[b12] - 20.0, "HARMONICS 8: the 12th harmonic is gone (%.1f -> %.1f dB)", spA[b12], spF[b12]);
            std::memcpy(Q, S, sizeof Q); Q[MO_BRIGHT] = 6.0F;
            const auto br = runSynth(Q, z1, 60, 1.0);
            CHECK(centroidHz(spectrumDb(br, 24000, 4096), kSr) > c0 * 1.15 && std::fabs(earDb(br, 24000) - earDb(a, 24000)) < 1.0, "BRIGHT +6: brighter and as loud");
        }
        {   // the knob storm: nothing clicks (shift, bright, harmonics, model, shape, unison, the filter thrown about every 100 ms)
            // Whether a change shows as a step depends on WHERE in the wave it lands, so the whole storm is played at several moments of change
            // and the worst of them counts (one fixed moment is a lottery: the same cutoff sweep gave 1.2 .. 2.1 at different moments).
            // A real click is a step several times the sound's own steps (the filter switched off used to give 3.1 at the wrong moment). The one
            // change that is allowed a bigger step is the OPENING of a resonant filter (seg 9: cutoff 500 -> 9000 Hz at reso 0.6): the filter
            // rings as it should - that is its sound, not a click.
            double worst = 0.0, worstSweep = 0.0; int worstSeg = -1, worstOff = 0; bool finite = true;
            for (const int off : {0, 7, 19, 41, 67, 97, 131, 173}) {
                silveton::sampler::synth::Voice v; Inputs in; in.key = 60; in.velocity = 0.8F; in.gate = true;
                float R[kEngineParamCountLegacy]; std::memcpy(R, S, sizeof R);
                v.noteOn(R, kSr, in, z1, 5U);
                const double inc = 261.63 / kSr;
                std::vector<float> out; const int n = static_cast<int>(1.6 * kSr);
                for (int i = 0; i < n; ++i) {
                    const int seg = i / 4800;
                    if (i % 4800 == off) {
                        switch (seg) {
                            case 1: v.setZone(zoneOf(1, 65)); break;   // the TUNE slider moves the zone of the sounding key (5 up, then 12 down)
                            case 2: v.setZone(zoneOf(1, 48)); break;
                            case 3: v.setZone(zoneOf(1, 60)); R[MO_BRIGHT] = 6.0F; break;
                            case 4: R[MO_BRIGHT] = -6.0F; break;
                            case 5: R[MO_BRIGHT] = 0.0F; R[silveton::sampler::synth::SY_HARMONICS] = 6.0F; break;
                            case 6: R[silveton::sampler::synth::SY_HARMONICS] = 48.0F; v.setZone(zoneOf(7, 60)); break;
                            case 7: v.setZone(zoneOf(1, 60)); R[MO_UNISON] = 2.0F; break;
                            case 8: R[MO_UNISON] = 0.0F; R[E_FILT_TYPE] = 1.0F; R[E_CUTOFF] = 500.0F; R[E_RESO] = 0.6F; break;
                            case 9: R[E_CUTOFF] = 9000.0F; break;
                            case 10: R[E_FILT_TYPE] = 0.0F; break;
                            default: break;
                        }
                    }
                    float l = 0.0F, r = 0.0F; if (i % 128 == 0) v.setInputs(in, kSr); v.tick(inc, l, r); out.push_back(l);
                }
                finite = finite && allFinite(out);
                const auto stepMax = [](const std::vector<float>& x, std::size_t from, std::size_t to) { double m = 0; for (std::size_t i = std::max<std::size_t>(from, 1); i < to && i < x.size(); ++i) m = std::max(m, std::fabs(static_cast<double>(x[i]) - x[i - 1])); return m; };
                for (int seg = 1; seg < 11; ++seg) {
                    const std::size_t at = static_cast<std::size_t>(seg) * 4800U + static_cast<std::size_t>(off);
                    const double atChange = stepMax(out, at, at + 960U), settled = std::max(stepMax(out, at - 960U, at), stepMax(out, at + 3840U, at + 4800U));
                    const double ratio = atChange / std::max(settled, 1e-6);
                    if (seg == 9) worstSweep = std::max(worstSweep, ratio);
                    else if (ratio > worst) { worst = ratio; worstSeg = seg; worstOff = off; }
                }
            }
            CHECK(finite, "synth storm: finite");
            CHECK(worst < 1.35, "synth: no click at any change (worst step ratio %.2f at %d00 ms, moment +%d)", worst, worstSeg, worstOff);
            CHECK(worstSweep < 2.0, "synth: a resonant filter opening rings but does not click (step ratio %.2f)", worstSweep);
        }
        {   // 16 notes in real time
            silveton::sampler::synth::Voice vs[16]; Inputs in; in.key = 48; in.velocity = 0.8F; in.gate = true;
            for (auto& v : vs) v.noteOn(S, kSr, in, zoneOf(1, 48), 3U);
            const double inc = 130.81 / kSr;
            const auto t0 = std::chrono::steady_clock::now();
            float acc = 0.0F;
            for (int i = 0; i < 48000; ++i) for (auto& v : vs) { float l = 0.0F, r = 0.0F; v.tick(inc, l, r); acc += l; }
            const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
            std::printf("  16 synth notes (48 harmonics, C3): %.1f%% of real time (%.3f s for 1 s)  [%g]\n", sec * 100.0, sec, static_cast<double>(acc) * 0.0);
            CHECK(sec < 0.8, "16 synth notes fit in real time here (%.2f s)", sec);
        }
    }

    // ---- 4) SILVETON_FULLTRACK_V1 (Цветомир, 04.11.2026: "искам звукът да излезе както го е направил тийчър"): a file with the whole sound is
    //      played from its first row to its last; the loudest moment of every sound is the same loudness by ear; a long loop goes round with
    //      its own movement, a short one holds the steady snapshot, a sound with no loop ends. A file of the old kind plays as before.
    {
        float S[kEngineParamCountLegacy]; silveton::sampler::synth::setDefaults(S);
        const auto render = [&](const ZoneShape* z, double seconds) {
            silveton::sampler::synth::Voice v; Inputs in; in.key = 60; in.velocity = 0.8F; in.gate = true;
            v.noteOn(S, kSr, in, z, 11U);
            const double inc = 261.63 / kSr;
            std::vector<float> out; const int n = static_cast<int>(seconds * kSr);
            for (int i = 0; i < n; ++i) { float l = 0.0F, r = 0.0F; if (i % 128 == 0) v.setInputs(in, kSr); v.tick(inc, l, r); out.push_back(l); }
            return out;
        };
        const auto earAt = [&](const std::vector<float>& x, double sec) { return earDb(x, static_cast<std::size_t>(sec * kSr)); };
        // 4a) a sound that dies away at -24 dB a second, 3 s long, no loop
        Full dying;
        const auto lmD = parseLearnedModels(fullFile(dying, true), "full.sv");
        CHECK(lmD->error.empty() && lmD->models.size() == 1 && lmD->models[0].zones.size() == 2, "full-track file read (%s)", lmD->error.c_str());
        const ZoneShape& zd = lmD->models[0].zones[0];
        const ZoneShape& zs = lmD->models[0].zones[1];
        CHECK(zd.fullTrack && zs.fullTrack && zd.attackRows == 600 && !zd.looped && zs.looped && std::fabs(zs.loopMs - 1000.0F) < 0.5F, "a track longer than 0.6 s = a full-track file (rows %d, looped %d, loop %.0f ms)", zd.attackRows, (int)zd.looped, zs.loopMs);
        CHECK(zd.peakDb[0] > -2.0F && zd.peakDb[0] <= 0.0F, "the loudest 100 ms of a dying sound is its start (%.1f dB)", zd.peakDb[0]);
        const std::vector<float> d = render(&zd, 3.6);
        CHECK(allFinite(d), "full track: finite");
        // the level follows the real decay: -24 dB a second (ear level, 85 ms windows)
        {
            const double e0 = earAt(d, 0.02), e1 = earAt(d, 0.52), e2 = earAt(d, 1.02), e3 = earAt(d, 1.52), e4 = earAt(d, 2.02);
            std::printf("  full track, dying sound (-24 dB/s): ear level 0 / %.1f / %.1f / %.1f / %.1f dB at 0.5 / 1 / 1.5 / 2 s; after its end %.1f dB\n", e1 - e0, e2 - e0, e3 - e0, e4 - e0, earAt(d, 3.2) - e0);
            CHECK(std::fabs((e1 - e0) + 12.0) < 1.5 && std::fabs((e2 - e0) + 24.0) < 1.5 && std::fabs((e3 - e0) + 36.0) < 2.0 && std::fabs((e4 - e0) + 48.0) < 2.5,
                  "the sound dies away as recorded: 0 / %.1f / %.1f / %.1f / %.1f dB (want -12 / -24 / -36 / -48)", e1 - e0, e2 - e0, e3 - e0, e4 - e0);
        }
        // the loudest moment is as loud as the loudest moment of a sound that does not die (zone 2, key 72 is a tone that holds)
        {
            const ZoneShape* hold = &zs;
            silveton::sampler::synth::Voice v; Inputs in; in.key = 72; in.velocity = 0.8F; in.gate = true; v.noteOn(S, kSr, in, hold, 11U);
            const double inc = 261.63 / kSr; std::vector<float> h; for (int i = 0; i < 48000; ++i) { float l = 0.0F, r = 0.0F; if (i % 128 == 0) v.setInputs(in, kSr); v.tick(inc, l, r); h.push_back(l); }
            const double eh = earAt(h, 0.5), ed = earAt(d, 0.02);
            std::printf("  loudest moment: dying sound %.1f dB, held sound %.1f dB (by ear)\n", ed, eh);
            CHECK(std::fabs(ed - eh) < 2.0, "the loudest moment of a dying sound is as loud as a held one (%.1f vs %.1f dB)", ed, eh);
            double mx = 0.0; for (float f : d) mx = std::max(mx, static_cast<double>(std::fabs(f)));
            CHECK(mx < 1.2, "a dying sound does not shoot over (peak %.2f)", mx);
        }
        // no loop: after its last row the sound is over
        CHECK(earAt(d, 3.2) < earAt(d, 0.02) - 55.0, "no loop: the sound is over after its end (%.1f dB against the start)", earAt(d, 3.2) - earAt(d, 0.02));
        // 4b) a long loop (1000 ms) at the end of a held tail: it goes round again with the movement of the last second
        {
            Full lp; lp.looped = true; lp.loopMs = 1000.0F; lp.dbPerSec = -24.0; lp.tailFloorDb = -40.0;   // dies to -40 dB at 1.67 s, holds
            const auto lmL = parseLearnedModels(fullFile(lp), "long.sv");
            const ZoneShape& zl = lmL->models[0].zones[0];
            const std::vector<float> o = render(&zl, 6.0);
            const double a = earAt(o, 2.2), b2 = earAt(o, 4.2), c = earAt(o, 5.2);
            CHECK(zl.looped && std::fabs(b2 - a) < 1.5 && std::fabs(c - a) < 1.5 && a > earAt(o, 0.02) - 45.0, "a long loop keeps sounding after the last row (%.1f / %.1f / %.1f dB)", a, b2, c);
        }
        // 4c) a short loop (100 ms): after the last row the steady snapshot is held - it does not move
        {
            Full sh; sh.looped = true; sh.loopMs = 100.0F; sh.dbPerSec = -24.0; sh.tailFloorDb = -30.0;
            const auto lmS = parseLearnedModels(fullFile(sh), "short.sv");
            const ZoneShape& zq = lmS->models[0].zones[0];
            const std::vector<float> o = render(&zq, 5.0);
            const double a = earAt(o, 3.6), b2 = earAt(o, 4.4), mid = earAt(o, 2.0);
            CHECK(std::fabs(b2 - a) < 0.5 && std::fabs(a - mid) < 2.0 && a > -80.0, "a short loop holds the steady snapshot (%.1f / %.1f dB, before the end %.1f)", a, b2, mid);
            // and nothing clicks where the track goes over into the snapshot (3 s)
            double step = 0.0, base = 0.0;
            for (std::size_t i = static_cast<std::size_t>(2.9 * kSr); i < static_cast<std::size_t>(3.1 * kSr); ++i) step = std::max(step, std::fabs(static_cast<double>(o[i]) - o[i - 1]));
            for (std::size_t i = static_cast<std::size_t>(1.0 * kSr); i < static_cast<std::size_t>(1.2 * kSr); ++i) base = std::max(base, std::fabs(static_cast<double>(o[i]) - o[i - 1]));
            CHECK(step < base * 2.0 + 0.02, "the track goes over into the snapshot without a click (step %.4f, normal %.4f)", step, base);
        }
        // 4c2) 16 full-track notes in real time (the work of a note is not more than before)
        {
            silveton::sampler::synth::Voice vs[16]; Inputs in; in.key = 60; in.velocity = 0.8F; in.gate = true;
            for (auto& v : vs) v.noteOn(S, kSr, in, &zd, 3U);
            const double inc = 130.81 / kSr;
            const auto t0 = std::chrono::steady_clock::now();
            float acc = 0.0F;
            for (int i = 0; i < 48000; ++i) for (auto& v : vs) { float l = 0.0F, r = 0.0F; v.tick(inc, l, r); acc += l; }
            const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
            std::printf("  16 full-track notes (24 harmonics, C3): %.1f%% of real time (%.3f s for 1 s)  [%g]\n", sec * 100.0, sec, static_cast<double>(acc) * 0.0);
            CHECK(sec < 0.8, "16 full-track notes fit in real time here (%.2f s)", sec);
        }
        // 4d) a short sound (less than 0.6 s) in a full-track file is full-track too: the file decides, not the length of the sound
        {
            Full tiny; tiny.rows = 40;   // 200 ms
            std::vector<std::uint8_t> two = fullFile(dying, false);   // a long one makes the file a full-track file ...
            const auto lmT = parseLearnedModels(fullFile(tiny), "tiny.sv");
            CHECK(lmT->models[0].zones[0].attackRows == 40 && !lmT->models[0].zones[0].fullTrack, "a file with only short tracks is read as the old kind (as TEACHER 2.0 wrote them)");
            CHECK(lmD->models[0].zones[0].fullTrack, "(and one with a long track is full-track)");
            (void)two;
        }
        // 4e) the old kind plays as before: the steady spectrum, SHAPE still read (0 = static)
        {
            const auto lmO = parseLearnedModels(learnedFile(Teach{}), "old.sv");
            const ZoneShape& zo = lmO->models[0].zones[0];
            CHECK(!zo.fullTrack, "a file of the old kind is not full-track");
        }
    }
    std::printf("%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
