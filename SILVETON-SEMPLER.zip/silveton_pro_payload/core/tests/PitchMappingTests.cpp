#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/SoloPresets.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace silveton::sampler;

namespace {
constexpr double kPi = 3.14159265358979323846;
constexpr std::uint8_t kKey = 69U;
enum class Source { Pcm, Factory, Learned };

void require(bool ok, const char* message) {
    if (!ok) throw std::runtime_error(message);
}

ProgramPtr sineProgram() {
    auto sample = std::make_shared<SampleData>();
    sample->sampleRate = 48000U;
    sample->channels = 1U;
    sample->rootKey = kKey;
    // 44 complete periods make a seamless PCM loop at exactly 440 Hz.
    sample->totalFrames = 4800U;
    sample->loop = {true, 0U, sample->totalFrames, 0U};
    sample->interleaved.resize(static_cast<std::size_t>(sample->totalFrames));
    for (std::size_t i = 0; i < sample->interleaved.size(); ++i)
        sample->interleaved[i] = static_cast<float>(.3 * std::sin(2.0 * kPi * 440.0 * static_cast<double>(i) / 48000.0));
    auto ms = std::make_shared<Multisample>();
    SampleZone zone;
    zone.sample = sample;
    zone.rootKey = kKey;
    ms->zones.push_back(zone);
    auto program = std::make_shared<Program>();
    ProgramLayer layer;
    layer.multisample = ms;
    layer.ampEnvelope = {0.0F, 0.0F, 1.0F, .02F};
    program->layers.push_back(layer);
    return program;
}

std::shared_ptr<const solo::Model> sineModel() {
    auto model = std::make_shared<solo::Model>();
    solo::Cell cell;
    cell.at.key = kKey;
    cell.at.phase = solo::Phase::Sustain;
    cell.sound.db.fill(-90.0F);
    cell.sound.db[0] = 0.0F;
    cell.sound.rmsDb = -18.0F;
    cell.count = 1U;
    model->cells.push_back(cell);
    model->prepare();
    return model;
}

std::shared_ptr<EngineState> stateFor(Source kind, int sound) {
    auto state = std::make_shared<EngineState>();
    auto& upper = state->combi.part(0);
    upper.enabled = true;
    upper.expressionEnabled = false;
    upper.voiceMode = UpperVoiceMode::Legato;
    upper.portaTime = 0U;
    upper.portamentoSec = 0.0F;
    upper.pitchBendRange = 7;
    upper.toneAttackMs = upper.toneDecayMs = 0.0F;
    upper.toneSustain = 1.0F;
    upper.toneReleaseMs = 20.0F;
    if (sound > 0) {
        auto& layer = upper.layers[static_cast<std::size_t>(sound - 1)];
        layer.enabled = true;
        layer.tone.attackMs = layer.tone.decayMs = 0.0F;
        layer.tone.sustain = 1.0F;
        layer.tone.releaseMs = 20.0F;
    }
    auto& source = soundSource(upper, sound);
    if (kind == Source::Pcm) source.program = sineProgram();
    else {
        source.engine = engineDefaults(EngineType::Solo);
        source.commonProcessing = true;
        source.engine.p[solo::MorphX] = source.engine.p[solo::MorphY] = 0.0F;
        source.engine.p[solo::Brightness] = source.engine.p[solo::Hollow] = 0.0F;
        source.engine.p[solo::Air] = source.engine.p[solo::Response] = 0.0F;
        if (kind == Source::Learned) source.soloModel = sineModel();
    }
    state->global.limiterEnabled = false;
    state->global.masterTuneHz = 442.0F;
    state->global.transposeSemitones = 3;
    state->global.scaleOffsetsCents[9] = -23.0F; // A: the played key, before transposition.
    upper.transposeSemitones = -2;
    upper.octave = 1;
    upper.tuneCents = 17.0F;
    if (sound > 0) {
        auto& layer = upper.layers[static_cast<std::size_t>(sound - 1)];
        layer.transposeSemitones = 5;
        layer.octave = -1;
        layer.tuneCents = -11.0F;
    }
    return state;
}

std::vector<float> render(SamplerEngine& engine, double rate, double seconds = .3) {
    std::vector<float> output;
    const auto frames = static_cast<std::size_t>(rate * seconds);
    output.reserve((frames + 96U) * 2U);
    std::array<float, 192U> block{};
    for (std::size_t f = 0; f < frames; f += 96U) {
        engine.render(block.data(), 96U);
        output.insert(output.end(), block.begin(), block.end());
    }
    return output;
}

// Normalized autocorrelation around two expected cycles avoids choosing a
// strong factory overtone as the fundamental. Parabolic interpolation keeps
// the check tighter than one sample, including fine tune at 96 kHz.
void expectPitch(SamplerEngine& engine, double rate, double semis, double cents,
                 double masterHz, const std::string& label) {
    const double expected = masterHz * std::exp2(semis / 12.0 + cents / 1200.0);
    const auto stereo = render(engine, rate);
    std::vector<double> x;
    for (std::size_t i = stereo.size() / 2U; i < stereo.size(); i += 2U)
        x.push_back(.5 * (stereo[i] + stereo[i + 1U]));
    const double center = 2.0 * rate / expected;
    const int lo = std::max(2, static_cast<int>(center * .94));
    const int hi = static_cast<int>(center * 1.06) + 2;
    std::vector<double> ac(static_cast<std::size_t>(hi + 2));
    double energy = 0.0;
    for (double value : x) energy += value * value;
    require(energy > 1.e-8, "silent pitch test");
    for (int lag = lo - 1; lag <= hi + 1; ++lag) {
        double aa = 0.0, bb = 0.0, ab = 0.0;
        for (std::size_t i = 0; i + static_cast<std::size_t>(hi + 2) < x.size(); ++i) {
            const double a = x[i], b = x[i + static_cast<std::size_t>(lag)];
            aa += a * a;
            bb += b * b;
            ab += a * b;
        }
        ac[static_cast<std::size_t>(lag)] = ab / std::sqrt(aa * bb + 1.e-30);
    }
    int best = lo;
    for (int lag = lo + 1; lag <= hi; ++lag)
        if (ac[static_cast<std::size_t>(lag)] > ac[static_cast<std::size_t>(best)]) best = lag;
    const double a = ac[static_cast<std::size_t>(best - 1)];
    const double b = ac[static_cast<std::size_t>(best)];
    const double c = ac[static_cast<std::size_t>(best + 1)];
    const double actual = 2.0 * rate / (best + .5 * (a - c) / (a - 2.0 * b + c));
    const double error = 1200.0 * std::log2(actual / expected);
    if (!std::isfinite(error) || std::abs(error) > 1.5)
        throw std::runtime_error(label + ": pitch error " + std::to_string(error) + " cents");
}

void mapping(Source kind, int sound, double rate) {
    const std::string label = std::to_string(static_cast<int>(kind)) + "/" + std::to_string(sound) + "/" + std::to_string(rate);
    SamplerEngine engine;
    engine.prepare(rate, 96U);
    engine.setScaleUppers(1);
    auto state = stateFor(kind, sound);
    engine.setState(state);
    require(engine.postNoteOn(0U, kKey, 100U), "note on rejected");
    // MAIN: +3 global -2 Upper +12 MAIN octave. Layer: +3 -2 +5 -12;
    // MAIN octave must not leak into L1..L4, and layer fine tune is additive.
    const double initialSemis = sound == 0 ? 13.0 : -6.0;
    const double initialCents = sound == 0 ? -6.0 : -17.0;
    expectPitch(engine, rate, initialSemis, initialCents, 442.0, label + " initial");
    engine.postPitchBend(0U, 8191);
    expectPitch(engine, rate, initialSemis + 7.0, initialCents, 442.0, label + " bend up");
    engine.postPitchBend(0U, -8192);
    expectPitch(engine, rate, initialSemis - 7.0, initialCents, 442.0, label + " bend down");
    engine.postPitchBend(0U, 0);

    auto edited = std::make_shared<EngineState>(*state);
    auto& upper = edited->combi.part(0);
    edited->global.transposeSemitones = 1;
    edited->global.masterTuneHz = 438.0F;
    edited->global.scaleOffsetsCents[9] = -41.0F;
    upper.transposeSemitones = -4;
    upper.octave = -1;
    upper.tuneCents = -31.0F;
    if (sound > 0) {
        auto& layer = upper.layers[static_cast<std::size_t>(sound - 1)];
        layer.transposeSemitones = -3;
        layer.octave = 1;
        layer.tuneCents = 29.0F;
    }
    engine.setState(edited);
    const double editedSemis = sound == 0 ? -15.0 : 6.0;
    const double editedCents = sound == 0 ? -72.0 : -43.0;
    // PCM keeps its selected multisample zone until the next key press. Fine
    // tune, scale and master tuning are live for all sources. SOLO also moves
    // a held oscillator when octave/transpose changes.
    expectPitch(engine, rate, kind == Source::Pcm ? initialSemis : editedSemis,
                editedCents, 438.0, label + " held edit");
    require(engine.postNoteOff(0U, kKey), "note off rejected");
    render(engine, rate, .2);
    require(engine.activeVoiceCount() == 0U, "transposed note did not release using the original MIDI key");
    require(engine.postNoteOn(0U, kKey, 100U), "second note on rejected");
    expectPitch(engine, rate, editedSemis, editedCents, 438.0, label + " next note");
    engine.postNoteOff(0U, kKey);
    render(engine, rate, .2);
    require(engine.activeVoiceCount() == 0U, "second transposed note did not release");
}
} // namespace

int main() {
    try {
        for (Source source : {Source::Pcm, Source::Factory, Source::Learned}) {
            for (int sound = 0; sound <= 4; ++sound) mapping(source, sound, 48000.0);
            for (int sound : {0, 4}) mapping(source, sound, 96000.0);
        }
        std::cout << "PASS combined global/Upper/layer transpose, independent octave, fine/master/scale tune, +/-bend, live edits and original-key release for PCM/factory/learned MAIN+L1-L4 at 48/96 kHz\n";
    } catch (const std::exception& error) {
        std::cerr << "FAIL " << error.what() << '\n';
        return 1;
    }
}
