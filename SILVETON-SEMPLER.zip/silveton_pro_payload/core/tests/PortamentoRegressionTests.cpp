#include "silveton/sampler/SamplerEngine.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace silveton::sampler;

namespace {
constexpr double kSampleRate = 96000.0;
constexpr std::uint32_t kBlock = 96U;
int checks = 0;

void check(bool condition, const char* message) {
    ++checks;
    if (!condition) throw std::runtime_error(message);
}

double noteHz(int key) { return 440.0 * std::exp2((key - 69.0) / 12.0); }

std::shared_ptr<EngineState> tone(UpperVoiceMode voiceMode, PortamentoMode portaMode,
                                  int isolatedRightKey = -1) {
    auto sample = std::make_shared<SampleData>();
    sample->sampleRate = 48000U;
    sample->channels = 1U;
    sample->rootKey = 69U;
    sample->interleaved.resize(48000U);
    for (std::size_t i = 0; i < sample->interleaved.size(); ++i)
        sample->interleaved[i] = static_cast<float>(0.5 * std::sin(2.0 * 3.14159265358979323846 * 440.0 * static_cast<double>(i) / 48000.0));
    sample->totalFrames = 48000U;
    sample->loop.enabled = true;
    sample->loop.endFrame = 48000U;
    auto multisample = std::make_shared<Multisample>();
    auto zone = [&](int lo, int hi, float pan) {
        if (lo > hi) return;
        SampleZone z{};
        z.sample = sample; z.rootKey = 69U;
        z.keyLow = static_cast<std::uint8_t>(lo); z.keyHigh = static_cast<std::uint8_t>(hi);
        z.velocityLow = 1U; z.velocityHigh = 127U; z.pan = pan;
        multisample->zones.push_back(z);
    };
    if (isolatedRightKey < 0) zone(0, 127, 0.0F);
    else {
        // Isolate one new note acoustically while other physical keys remain
        // held on the same part. This avoids inferring pitch from a chord mix.
        zone(0, isolatedRightKey - 1, -1.0F);
        zone(isolatedRightKey, isolatedRightKey, 1.0F);
        zone(isolatedRightKey + 1, 127, -1.0F);
    }
    auto program = std::make_shared<Program>();
    ProgramLayer layer{};
    layer.multisample = multisample;
    layer.filter.mode = FilterMode::Bypass;
    layer.ampEnvelope = {0.0F, 0.01F, 1.0F, 0.02F};
    program->layers.push_back(layer);
    auto state = std::make_shared<EngineState>();
    auto& upper = state->combi.uppers[0];
    upper.program = program; upper.enabled = true; upper.midiChannel = 0U;
    upper.breathEnabled = false; upper.voiceMode = voiceMode;
    upper.portaMode = portaMode; upper.portamentoSec = 0.05F;
    upper.portaTime = 40U; upper.portaFingered = true;
    state->global.masterGainDb = 0.0F; state->global.limiterEnabled = false;
    return state;
}

void prepare(SamplerEngine& engine, const std::shared_ptr<EngineState>& state) {
    engine.prepare(kSampleRate, kBlock);
    engine.setPortamentoNear(0.0F);
    engine.setState(state);
}

void on(SamplerEngine& engine, int key, int channel = 0) {
    check(engine.postNoteOn(static_cast<std::uint8_t>(channel), static_cast<std::uint8_t>(key), 100U), "NoteOn rejected");
}
void off(SamplerEngine& engine, int key, int channel = 0) {
    check(engine.postNoteOff(static_cast<std::uint8_t>(channel), static_cast<std::uint8_t>(key)), "NoteOff rejected");
}

std::vector<float> render(SamplerEngine& engine, int milliseconds, int channel = 0) {
    std::array<float, kBlock * 2U> stereo{};
    std::vector<float> output;
    output.reserve(static_cast<std::size_t>(milliseconds) * kBlock);
    for (int b = 0; b < milliseconds; ++b) {
        engine.render(stereo.data(), kBlock);
        for (std::uint32_t i = 0U; i < kBlock; ++i) output.push_back(stereo[i * 2U + channel]);
    }
    return output;
}

double frequency(const std::vector<float>& output, double centerMs, double widthMs = 10.0) {
    const auto begin = static_cast<std::size_t>(std::max(0.0, centerMs - widthMs / 2.0) * 96.0);
    const auto end = std::min(output.size(), static_cast<std::size_t>((centerMs + widthMs / 2.0) * 96.0));
    std::size_t count = 0U;
    double first = 0.0, last = 0.0;
    for (auto i = begin + 1U; i < end; ++i) if (output[i - 1U] < 0.0F && output[i] >= 0.0F) {
        const double crossing = static_cast<double>(i - 1U) + static_cast<double>(-output[i - 1U]) / (output[i] - output[i - 1U]);
        if (count == 0U) first = crossing;
        last = crossing; ++count;
    }
    return count < 2U ? 0.0 : static_cast<double>(count - 1U) * kSampleRate / (last - first);
}

void atNote(const std::vector<float>& output, double ms, int key, const char* message) {
    const double hz = frequency(output, ms);
    check(hz > 0.0 && std::abs(1200.0 * std::log2(hz / noteHz(key))) < 2.0, message);
}

void interruptedSilveton() {
    for (auto mode : {UpperVoiceMode::Mono, UpperVoiceMode::Legato})
        for (float balance : {5.0F, 11.0F, 35.0F}) for (float nearMs : {0.0F, 90.0F}) {
            auto state = tone(mode, PortamentoMode::Silveton);
            SamplerEngine engine; prepare(engine, state);
            engine.setPortamentoBalance(balance); engine.setPortamentoNear(nearMs);
            on(engine, 69); render(engine, 200);
            on(engine, 81); render(engine, 10);
            on(engine, 82); const auto output = render(engine, 130);
            // The last key interval is one semitone: its intended duration is
            // 50 ms, or 90 ms with NEAR. A fast interruption must not multiply it.
            atNote(output, nearMs > 0.0F ? 110.0 : 70.0, 82, "Interrupted SILVETON exceeded TIME/NEAR");
            check(engine.activeVoiceCount() == 1U, "Interrupted mono glide added a voice");
        }
}

void interruptedReturn() {
    for (auto mode : {UpperVoiceMode::Mono, UpperVoiceMode::Legato}) {
        SamplerEngine engine; prepare(engine, tone(mode, PortamentoMode::Silveton));
        on(engine, 69); render(engine, 200);
        on(engine, 81); render(engine, 10);
        off(engine, 81); const auto back = render(engine, 35);
        // The audible pitch only travelled 2.4 of the 12 semitones. Returning
        // retains the existing shorter glide, rather than restarting 50 ms.
        atNote(back, 22.0, 69, "Return to a held key lost its shorter glide");
        check(engine.activeVoiceCount() == 1U, "Held-key return lost the mono line");
        on(engine, 81); render(engine, 10); on(engine, 70);
        const auto reversal = render(engine, 35);
        atNote(reversal, 22.0, 70, "Direction reversal failed to arrive");
        off(engine, 70); render(engine, 70); off(engine, 81); render(engine, 70);
        off(engine, 69); render(engine, 60);
        check(engine.activeVoiceCount() == 0U, "Mono keys remained after release");
    }
}

void releasedPolyStartsFresh() {
    for (auto mode : {PortamentoMode::Silveton, PortamentoMode::Kronos, PortamentoMode::Instrument, PortamentoMode::Bass}) {
        SamplerEngine engine; prepare(engine, tone(UpperVoiceMode::Poly, mode));
        on(engine, 69); render(engine, 100); on(engine, 81); render(engine, 5);
        off(engine, 69); off(engine, 81); render(engine, 25);
        check(engine.activeVoiceCount() == 0U, "Release fixture still has voices");
        on(engine, 72); const auto output = render(engine, 35);
        atNote(output, 15.0, 72, "Released POLY chord leaked its old glide anchor");
    }
}

void sustainDoesNotHoldChord() {
    for (auto mode : {PortamentoMode::Silveton, PortamentoMode::Kronos}) {
        SamplerEngine engine; prepare(engine, tone(UpperVoiceMode::Poly, mode, 72));
        engine.postControlChange(0U, 64U, 127U);
        on(engine, 69); render(engine, 100); on(engine, 81); render(engine, 5);
        off(engine, 69); off(engine, 81); render(engine, 5);
        check(engine.activeVoiceCount() == 2U, "Sustain fixture did not retain its voices");
        on(engine, 72); const auto output = render(engine, 35, 1);
        atNote(output, 15.0, 72, "Sustain was mistaken for a physically held POLY key");
        check(engine.activeVoiceCount() == 3U, "New note incorrectly cut sustained voices");
        off(engine, 72); engine.postControlChange(0U, 64U, 0U); render(engine, 60);
        check(engine.activeVoiceCount() == 0U, "Damper release left voices behind");
    }
}

void filteredReleaseClearsKeys() {
    for (bool disableChannel : {false, true}) {
        auto state = tone(UpperVoiceMode::Poly, PortamentoMode::Kronos);
        SamplerEngine engine; prepare(engine, state);
        on(engine, 69); render(engine, 100); on(engine, 81); render(engine, 5);
        auto filtered = std::make_shared<EngineState>(*state);
        if (disableChannel) filtered->global.midiInputChannelMask = 0U;
        else filtered->global.filterNotes = true;
        engine.setState(filtered);
        off(engine, 69);
        check(engine.postNoteOn(0U, 81U, 0U), "Velocity-zero release rejected");
        render(engine, 25);
        check(engine.activeVoiceCount() == 0U, "Filtered release left a voice behind");
        engine.setState(state); on(engine, 72); const auto output = render(engine, 35);
        atNote(output, 15.0, 72, "Filtered releases left stale physical-key memory");
    }
}

void boundedChordWindow() {
    {
        SamplerEngine engine; prepare(engine, tone(UpperVoiceMode::Poly, PortamentoMode::Silveton, 81));
        on(engine, 69); render(engine, 40); on(engine, 81);
        const auto output = render(engine, 35, 1);
        atNote(output, 15.0, 81, "Notes in the first rolled chord no longer share its empty anchor");
    }
    {
        SamplerEngine engine; prepare(engine, tone(UpperVoiceMode::Poly, PortamentoMode::Silveton, 81));
        on(engine, 69); render(engine, 40); on(engine, 72); render(engine, 40); on(engine, 81);
        const auto output = render(engine, 80, 1);
        const double early = frequency(output, 15.0);
        check(early > 530.0 && early < 750.0, "Successive NoteOns extended the POLY chord window beyond 50 ms");
        atNote(output, 65.0, 81, "New chord group did not reach its note");
        check(engine.activeVoiceCount() == 3U, "POLY chord lost a held voice");
    }
    {
        SamplerEngine engine; prepare(engine, tone(UpperVoiceMode::Poly, PortamentoMode::Silveton, 81));
        on(engine, 60); render(engine, 100); on(engine, 69); render(engine, 40); on(engine, 81);
        const auto output = render(engine, 80, 1);
        const double early = frequency(output, 15.0);
        check(early > 310.0 && early < 430.0, "Rolled chord failed to share the preceding held-key anchor");
        atNote(output, 65.0, 81, "Shared chord glide did not arrive");
    }
}

void kronosAlwaysPreserved() {
    auto state = tone(UpperVoiceMode::Poly, PortamentoMode::Kronos);
    state->combi.uppers[0].portaFingered = false;
    SamplerEngine engine; prepare(engine, state);
    on(engine, 69); render(engine, 100); on(engine, 81); render(engine, 5);
    off(engine, 69); off(engine, 81); render(engine, 25);
    on(engine, 72); const auto output = render(engine, 450);
    check(frequency(output, 15.0) > 800.0, "KRONOS always-glide forgot the last key after release");
    atNote(output, 425.0, 72, "KRONOS always-glide did not arrive");
}

void physicalKeyOutlivesSample() {
    auto state = tone(UpperVoiceMode::Poly, PortamentoMode::Silveton);
    auto program = std::const_pointer_cast<Program>(state->combi.uppers[0].program);
    auto multisample = std::const_pointer_cast<Multisample>(program->layers[0].multisample);
    SampleZone high = multisample->zones[0]; high.keyLow = 70U;
    auto shortSample = std::make_shared<SampleData>(*high.sample);
    shortSample->interleaved.resize(4800U); shortSample->totalFrames = 4800U; shortSample->loop.enabled = false;
    multisample->zones[0].sample = shortSample; multisample->zones[0].keyHigh = 69U;
    multisample->zones.push_back(high);
    SamplerEngine engine; prepare(engine, state);
    on(engine, 69); render(engine, 150);
    check(engine.activeVoiceCount() == 0U, "Finite sample did not reach EOF");
    on(engine, 81); const auto output = render(engine, 80);
    check(frequency(output, 15.0) < 700.0, "POLY forgot a physically held key when its sample ended");
    atNote(output, 65.0, 81, "EOF-following glide did not arrive");
}

void enableAfterOrdinaryPoly() {
    auto state = tone(UpperVoiceMode::Poly, PortamentoMode::Silveton, 81);
    state->combi.uppers[0].portamentoSec = 0.0F;
    SamplerEngine engine; prepare(engine, state); on(engine, 69); render(engine, 100);
    auto enabled = std::make_shared<EngineState>(*state); enabled->combi.uppers[0].portamentoSec = 0.05F;
    engine.setState(enabled); on(engine, 81); const auto output = render(engine, 80, 1);
    check(frequency(output, 15.0) < 700.0, "Enabling PORTA lost an already held POLY key");
    atNote(output, 65.0, 81, "Enabled glide did not arrive");
}

void cleanupAndChannelChange() {
    for (int cleanup : {120, 123}) {
        SamplerEngine engine; prepare(engine, tone(UpperVoiceMode::Poly, PortamentoMode::Silveton));
        on(engine, 69); render(engine, 100); on(engine, 81); render(engine, 5);
        engine.postControlChange(0U, static_cast<std::uint8_t>(cleanup), 0U); render(engine, 1);
        on(engine, 72); const auto output = render(engine, 35);
        atNote(output, 15.0, 72, "All-off cleanup left a POLY chord anchor");
    }
    auto state = tone(UpperVoiceMode::Poly, PortamentoMode::Silveton, 72);
    SamplerEngine engine; prepare(engine, state);
    on(engine, 69); render(engine, 100); on(engine, 81); render(engine, 5);
    auto moved = std::make_shared<EngineState>(*state); moved->combi.uppers[0].midiChannel = 1U;
    engine.setState(moved); on(engine, 72, 1);
    const auto output = render(engine, 35, 1);
    atNote(output, 15.0, 72, "New MIDI channel inherited the old channel's chord keys");
    off(engine, 69); off(engine, 81); off(engine, 72, 1); render(engine, 60);
    check(engine.activeVoiceCount() == 0U, "Channel-change cleanup left voices behind");
}
} // namespace

int main() {
    struct Test { const char* name; void (*run)(); };
    const Test tests[] = {
        {"interrupted SILVETON bound", interruptedSilveton},
        {"interrupted reverse and held-key return", interruptedReturn},
        {"released POLY starts fresh", releasedPolyStartsFresh},
        {"sustain does not hold chord", sustainDoesNotHoldChord},
        {"filtered and velocity-zero releases", filteredReleaseClearsKeys},
        {"bounded first-note chord window", boundedChordWindow},
        {"KRONOS always-glide", kronosAlwaysPreserved},
        {"physical key survives sample EOF", physicalKeyOutlivesSample},
        {"enable after ordinary POLY", enableAfterOrdinaryPoly},
        {"all-off and MIDI channel cleanup", cleanupAndChannelChange}
    };
    int failures = 0;
    for (const auto& test : tests) {
        try { test.run(); std::cout << "PASS " << test.name << '\n'; }
        catch (const std::exception& error) {
            ++failures; std::cerr << "FAIL " << test.name << ": " << error.what() << '\n';
        }
    }
    std::cout << "Portamento regression: " << checks << " checks, " << failures << " failed groups; 96000 Hz / 96 frames\n";
    return failures == 0 ? 0 : 1;
}
