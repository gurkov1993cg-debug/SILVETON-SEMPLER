#include "silveton/sampler/SamplerEngine.h"

#include <array>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <memory>
#include <thread>

using namespace silveton::sampler;
namespace {
thread_local bool inRender = false;
std::atomic<unsigned> created{0U}, destroyed{0U}, destroyedOnAudio{0U};

template<class T>
std::shared_ptr<T> tracked() {
    created.fetch_add(1U);
    return std::shared_ptr<T>(new T, [](T* p) {
        if (inRender) destroyedOnAudio.fetch_add(1U);
        delete p;
        destroyed.fetch_add(1U);
    });
}

void render(SamplerEngine& e, std::array<float, 192>& out) {
    inRender = true;
    e.render(out.data(), 96U);
    inRender = false;
}

std::shared_ptr<EngineState> makeState() {
    auto sample = std::make_shared<SampleData>();
    sample->sampleRate = 48000;
    sample->channels = 1;
    sample->rootKey = 69;
    sample->totalFrames = 4800;
    sample->loop = {true, 0, 4800, 0};
    sample->interleaved.resize(4800);
    for (std::size_t i = 0; i < sample->interleaved.size(); ++i)
        sample->interleaved[i] = 0.2F * std::sin(6.283185307179586 * 440.0 * i / 48000.0);
    auto ms = std::make_shared<Multisample>();
    SampleZone zone;
    zone.sample = sample;
    zone.rootKey = 69;
    ms->zones.push_back(zone);
    auto program = std::make_shared<Program>();
    ProgramLayer layer;
    layer.multisample = ms;
    layer.ampEnvelope = {0.0F, 0.0F, 1.0F, 0.005F};
    program->layers.push_back(layer);
    auto s = tracked<EngineState>();
    auto& u = s->combi.uppers[0];
    u.enabled = true;
    u.breathEnabled = false;
    u.program = program;
    return s;
}

void publicationAndRetirement() {
    std::array<float, 192> out{};
    {
        SamplerEngine e;
        e.prepare(96000.0, 96U);
        auto first = makeState();
        e.setState(first);
        render(e, out);
        assert(e.state() == first);
        e.setState(nullptr); // must keep the current sound
        render(e, out);
        assert(e.state() == first);
        first.reset();
        for (int i = 0; i < 100; ++i) {
            auto s = makeState();
            e.setState(s);
            s.reset();
            e.setWaveTables(tracked<WaveTableMap>());
            e.setLearnedModels(tracked<model::LearnedModels>());
            render(e, out);
        }
        assert(destroyed.load() > 0U); // reclaim during use, not just at destruction
        e.setWaveTables(nullptr);
        e.setLearnedModels(nullptr);
        render(e, out);
        e.reset();
        assert(e.activeVoiceCount() == 0U);
        e.prepare(48000.0, 96U);
        assert(e.meters().peakLeft == 0.0F);
    }
    assert(destroyedOnAudio.load() == 0U);
    assert(destroyed.load() == created.load());
}

void repeatedGraphPublication() {
    std::array<float, 192> out{};
    const auto initialDestroyed = destroyed.load();
    {
        SamplerEngine e;
        auto state = tracked<EngineState>();
        auto waves = tracked<WaveTableMap>();
        auto models = tracked<model::LearnedModels>();
        for (int i = 0; i < 32; ++i) {
            e.setState(state); e.setWaveTables(waves); e.setLearnedModels(models);
            render(e, out);
        }
        state.reset(); waves.reset(); models.reset();
        e.setState(std::make_shared<EngineState>());
        e.setWaveTables(nullptr); e.setLearnedModels(nullptr);
        render(e, out);
        // A control publication deterministically collects the retired duplicate
        // pins, without depending on the background thread's wake-up time.
        e.setState(std::make_shared<EngineState>());
        assert(destroyed.load() == initialDestroyed + 3U);
        auto pair = tracked<std::array<EngineState, 2>>();
        e.setState(std::shared_ptr<const EngineState>(pair, &(*pair)[0]));
        render(e, out);
        e.setState(std::shared_ptr<const EngineState>(pair, &(*pair)[1]));
        render(e, out);
        pair.reset();
        e.setState(std::make_shared<EngineState>());
        render(e, out);
        e.setState(std::make_shared<EngineState>());
        assert(destroyed.load() == initialDestroyed + 4U);
    }
    assert(destroyedOnAudio.load() == 0U);
    assert(destroyed.load() == created.load());
}

void heldWaveOwnership() {
    std::array<float, 192> out{};
    {
        SamplerEngine e;
        e.prepare(96000.0, 96U);
        auto s = makeState();
        s->combi.uppers[0].toneExtra.waveMode = kWaveModeAuto;
        const auto& zone = s->combi.uppers[0].program->layers[0].multisample->zones[0];
        const auto key = waveKey(zone, s->combi.uppers[0].toneExtra);
        assert(key != 0U);
        auto table = tracked<WaveTable>();
        table->frames = 1;
        table->length = 32;
        table->channels = 1;
        table->data.resize(32);
        for (std::size_t i = 0; i < 32; ++i) table->data[i] = 0.2F * std::sin(6.283185307179586 * i / 32.0);
        auto map = tracked<WaveTableMap>();
        map->emplace(key, table);
        e.setWaveTables(map);
        e.setState(s);
        assert(e.postNoteOn(0U, 69U, 100U));
        render(e, out);
        assert(e.activeVoiceCount() == 1U);
        table.reset(); map.reset(); s.reset();
        // Replace the map while its table still belongs to a sounding voice.
        e.setWaveTables(nullptr);
        render(e, out);
        for (int i = 0; i < 8; ++i) { e.setWaveTables(nullptr); render(e, out); }
        assert(e.postPanic());
        render(e, out);
        assert(e.activeVoiceCount() == 0U);
        e.setState(makeState());
        render(e, out);
    }
    assert(destroyedOnAudio.load() == 0U);
    assert(destroyed.load() == created.load());
}

void concurrentPublishAndTelemetry() {
    {
        SamplerEngine e;
        e.prepare(96000.0, 96U);
        e.setAnalyzerTap(0, true);
        auto base = makeState();
        e.setState(base);
        std::atomic<bool> publishingDone{false}, renderDone{false};
        std::atomic<unsigned> blocks{0U}, reads{0U};
        std::thread audio([&] {
            std::array<float, 192> out{};
            unsigned tail = 0U;
            while (!publishingDone.load(std::memory_order_acquire) || tail++ < 100U) {
                render(e, out);
                for (float v : out) assert(std::isfinite(v));
                blocks.fetch_add(1U, std::memory_order_release);
            }
            renderDone.store(true, std::memory_order_release);
        });
        std::thread observer([&] {
            std::array<float, 128> spectrum{};
            do {
                const auto m = e.meters();
                assert(std::isfinite(m.peakLeft) && std::isfinite(m.peakRight));
                assert(m.activeVoices <= 128U && e.activeVoiceCount() <= 128U);
                assert(m.coresWorking >= 1U && m.coresWorking <= 8U);
                e.readAnalyzer(spectrum.data(), spectrum.size());
                for (float v : spectrum) assert(std::isfinite(v));
                const auto current = e.state();
                assert(current != nullptr);
                reads.fetch_add(1U);
            } while (!renderDone.load(std::memory_order_acquire));
        });
        for (int i = 0; i < 1200; ++i) {
            auto next = tracked<EngineState>();
            *next = *base;
            next->global.masterGainDb = -6.0F - static_cast<float>(i % 12);
            e.setState(next);
            if (i % 16 == 0) assert(e.postNoteOn(0U, 69U, 100U));
            if (i % 16 == 8) assert(e.postNoteOff(0U, 69U));
            if (i % 32 == 0) {
                e.setWaveTables(tracked<WaveTableMap>());
                e.setLearnedModels(tracked<model::LearnedModels>());
            }
        }
        publishingDone.store(true, std::memory_order_release);
        audio.join(); observer.join();
        assert(blocks.load() >= 100U && reads.load() > 0U);
        assert(e.postPanic());
        std::array<float, 192> out{};
        render(e, out);
        assert(e.activeVoiceCount() == 0U);
        base.reset();
    }
    assert(destroyedOnAudio.load() == 0U);
    assert(destroyed.load() == created.load());
}
} // namespace

int main() {
    publicationAndRetirement();
    repeatedGraphPublication();
    heldWaveOwnership();
    concurrentPublishAndTelemetry();
    std::printf("Realtime safety passed: %u tracked objects reclaimed, %u on audio; concurrent publication/meters/analyzer and held-wave lifetime checked\n",
        destroyed.load(), destroyedOnAudio.load());
}
