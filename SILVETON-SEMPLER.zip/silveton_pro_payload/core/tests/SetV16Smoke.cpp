#include "silveton/sampler/SetPackage.h"
#include <cassert>
#include <iostream>
using namespace silveton::sampler;
int main(){
  SetData data; data.name="Compatibility Smoke";
  CombiSlot cs;cs.address={1,1,1};cs.combi.name="PRESET";
  auto& u=cs.combi.uppers[0];
  u.velocityLow=15;u.velocityHigh=120;u.velocityFadeIn=12;u.velocityFadeOut=13;u.velocityResponse=1.4f;
  u.independentLayerRanges=true;u.portaMode=PortamentoMode::Instrument;u.oscillatorMode=OscillatorMode::Bass;u.portaTime=45;
  auto& l=u.layers[2];l.velocityLow=35;l.velocityHigh=90;l.velocityFadeIn=7;l.velocityFadeOut=11;l.velocityResponse=0.75f;
  data.combis.push_back(cs);
  const auto s=SetPackage::save("/tmp/silveton_v16_smoke.svset",data);
  if(!s.success){std::cerr<<s.error<<"\n";return 1;}
  const auto r=SetPackage::load("/tmp/silveton_v16_smoke.svset");
  if(!r.ok()){std::cerr<<r.error<<"\n";return 2;}
  const auto& o=r.data.combis.front().combi.uppers[0];
  assert(o.velocityFadeIn==12 && o.velocityFadeOut==13 && o.velocityResponse==1.4f);
  assert(o.independentLayerRanges && o.portaMode==PortamentoMode::Instrument && o.oscillatorMode==OscillatorMode::Bass && o.portaTime==45);
  assert(o.layers[2].velocityFadeIn==7 && o.layers[2].velocityFadeOut==11 && o.layers[2].velocityResponse==0.75f);
  std::cout<<"PASS SET v16 roundtrip and instrument mode\n";
}
