#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SoloPresets.h"
#include "silveton/sampler/SoloModel.h"
#include <vector>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace silveton::sampler;
std::vector<float> run(SamplerEngine& e){std::vector<float>x(24000);for(int i=0;i<12000;i+=96)e.render(x.data()+2*i,96);return x;}
double estimatePitch(const std::vector<float>& stereo,double expected,double sr){
 std::vector<double> x;for(std::size_t i=stereo.size()/2;i<stereo.size();i+=2)x.push_back(stereo[i]);
 const int center=static_cast<int>(2*sr/expected);const int lo=std::max(2,static_cast<int>(center*.9)),hi=static_cast<int>(center*1.1)+2;
 std::vector<double> ac(static_cast<std::size_t>(hi+2));
 for(int lag=lo-1;lag<=hi+1;++lag){double aa=0,bb=0,ab=0;for(std::size_t i=0;i+static_cast<std::size_t>(hi+2)<x.size();++i){const double a=x[i],b=x[i+static_cast<std::size_t>(lag)];ab+=a*b;aa+=a*a;bb+=b*b;}ac[static_cast<std::size_t>(lag)]=ab/std::sqrt(aa*bb+1e-30);}
 int best=lo;for(int lag=lo;lag<=hi;++lag)if(ac[static_cast<std::size_t>(lag)]>ac[static_cast<std::size_t>(best)])best=lag;
 const double a=ac[static_cast<std::size_t>(best-1)],b=ac[static_cast<std::size_t>(best)],c=ac[static_cast<std::size_t>(best+1)];
 return 2*sr/(best+.5*(a-c)/(a-2*b+c));
}
void pitch(SamplerEngine& e,int key){auto x=run(e);const double hz=440*std::exp2((key-69)/12.);double cents=1200*std::log2(estimatePitch(x,hz,48000)/hz);std::cout<<"key "<<key<<" cents "<<cents<<std::endl;if(!std::isfinite(cents)||std::abs(cents)>1.5)throw std::runtime_error("bend latched/wrong pitch");}
void sharedUpperBend(){
 auto model=std::make_shared<solo::Model>();solo::Cell cell;cell.at.key=69;cell.at.phase=solo::Phase::Sustain;
 cell.sound.db.fill(-90);cell.sound.db[0]=0;cell.sound.rmsDb=-18;cell.count=1;model->cells.push_back(cell);model->prepare();
 for(int place=0;place<=5;++place){ // all five trained source positions and factory MAIN
  const int sound=place%5;SamplerEngine e;e.prepare(48000,128);auto s=std::make_shared<EngineState>();
  auto& u=s->combi.part(0);u.enabled=true;u.expressionEnabled=false;u.voiceMode=UpperVoiceMode::Legato;
  auto& src=soundSource(u,sound);src.engine=engineDefaults(EngineType::Solo);src.commonProcessing=true;
  src.engine.p[solo::Brightness]=src.engine.p[solo::Hollow]=src.engine.p[solo::Air]=src.engine.p[solo::Response]=0;
  if(place<5)src.soloModel=model;
  if(sound>0)u.layers[static_cast<std::size_t>(sound-1)].enabled=true;
  s->global.limiterEnabled=false;u.pitchBendRange=7;e.setState(s);e.postNoteOn(0,69,100);
  std::cout<<"COMMON SOURCE "<<place<<" hidden range=2, UPPER range=7\n";
  e.postPitchBend(0,8191);pitch(e,76);e.postPitchBend(0,-8192);pitch(e,62);
  for(int range:{12,0,1,24}){
   s=std::make_shared<EngineState>(*s);s->combi.part(0).pitchBendRange=static_cast<std::int8_t>(range);e.setState(s);
   e.postPitchBend(0,8191);pitch(e,69+range);e.postPitchBend(0,-8192);pitch(e,69-range);
  }
  e.postPitchBend(0,0);pitch(e,69);e.postNoteOff(0,69);run(e);
 }
 std::cout<<"PASS shared UPPER bend for trained MAIN/L1-L4 and factory SOLO: +/-1/7/12/24, zero, held-note updates and centre\n";
}
int main(){try{SamplerEngine e;e.prepare(48000,128);auto s=std::make_shared<EngineState>();auto&u=s->combi.part(7);solo::preset(u,0);u.portaTime=0;u.engine.p[solo::MorphX]=u.engine.p[solo::MorphY]=u.engine.p[solo::Brightness]=u.engine.p[solo::Hollow]=u.engine.p[solo::Air]=u.engine.p[solo::Response]=0;u.engine.p[E_BEND_UP]=7;u.engine.p[E_BEND_DOWN]=12;s->global.limiterEnabled=false;e.setState(s);e.postNoteOn(0,69,100);e.postPitchBend(0,8191);pitch(e,76);
 s=std::make_shared<EngineState>(*s);s->combi.name="changed while wheel held";s->combi.part(7).engine.p[E_BEND_UP]=12;e.setState(s);pitch(e,81);
 s=std::make_shared<EngineState>(*s);s->combi.part(7).engine.p[E_BEND_UP]=7;e.setState(s);pitch(e,76);
 s=std::make_shared<EngineState>(*s);s->global.pitchBendEnabled=false;e.setState(s);pitch(e,69); // must release audible bend on disable
 e.postPitchBend(0,0);run(e);s=std::make_shared<EngineState>(*s);s->global.pitchBendEnabled=true;e.setState(s);pitch(e,69);
 e.postPitchBend(0,-8192);pitch(e,57);e.postNoteOn(0,72,100);pitch(e,60);e.postNoteOff(0,72);pitch(e,57);e.postPitchBend(0,0);pitch(e,69);
 e.postPitchBend(0,8191);pitch(e,76);s=std::make_shared<EngineState>(*s);s->global.filterPitchBend=true;e.setState(s);pitch(e,69);e.postPitchBend(0,0);run(e);s=std::make_shared<EngineState>(*s);s->global.filterPitchBend=false;e.setState(s);pitch(e,69);
 e.postPitchBend(0,8191);pitch(e,76);s=std::make_shared<EngineState>(*s);s->global.midiInputChannelMask=2;e.setState(s);pitch(e,69);e.postPitchBend(0,0);run(e);s=std::make_shared<EngineState>(*s);s->global.midiInputChannelMask=65535;e.setState(s);pitch(e,69);
 e.postNoteOff(0,69);run(e);if(e.activeVoiceCount()!=0)throw std::runtime_error("stuck voice");std::cout<<"PASS bend changes, enable/filter/channel transitions and held-note return\n";
 sharedUpperBend();
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
