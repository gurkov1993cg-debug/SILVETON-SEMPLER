#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SoloPresets.h"
#include "silveton/sampler/SetPackage.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <fstream>
#include <iterator>
using namespace silveton::sampler;
void check(bool v,const char* s){if(!v)throw std::runtime_error(s);}
std::vector<float> run(SamplerEngine& e){std::vector<float>x(48000);for(int i=0;i<24000;i+=96)e.render(x.data()+2*i,96);return x;}
double estimate(const std::vector<float>& a,double hz){
 const int mid=static_cast<int>(96000/hz),lo=std::max(2,mid-5),hi=mid+5;std::vector<double> v(static_cast<std::size_t>(hi+2));
 for(int lag=lo-1;lag<=hi+1;++lag){double ab=0,aa=0,bb=0;for(int n=14000;n<23500-hi;++n){double x=a[2*n],y=a[2*(n+lag)];ab+=x*y;aa+=x*x;bb+=y*y;}v[static_cast<std::size_t>(lag)]=ab/std::sqrt(aa*bb+1e-30);}
 int best=lo;for(int n=lo;n<=hi;++n)if(v[n]>v[best])best=n;
 double a0=v[best-1],b=v[best],c=v[best+1];return 96000/(best+.5*(a0-c)/(a0-2*b+c));
}
void pitch(SamplerEngine& e,int key){double expected=440*std::exp2((key-69)/12.);double error=1200*std::log2(estimate(run(e),expected)/expected);std::cout<<"MIDI "<<key<<": "<<error<<" cents\n";check(std::isfinite(error)&&std::abs(error)<1.5,"octave/bend pitch wrong");}
int main(int argc,char** argv){try{
 for(int i=1;i<argc;++i){
  auto old=SetPackage::load(argv[i]);check(old.ok(),"historical SET failed to load");int active=0;
  for(const auto& c:old.data.combis)for(int u=0;u<kPartCount;++u)active+=c.combi.part(u).engine.type==EngineType::Solo;
  std::string path=argv[i];bool keep=path.find("PERSONAL")!=std::string::npos||path.find("ANALOG_ONE")!=std::string::npos;
  check(keep?active>0:active==0,"historical source migration wrong");
  std::cout<<path<<": "<<active<<" current SOLO rows\n";
 }

 for(int i=-1;i<256;++i)check(engineTypeOf(i)==(i==13?EngineType::Solo:EngineType::Off),"retired ID still executable");
 SetData d;d.name="SOLO compatibility";Combi c;solo::preset(c.part(7),1);c.part(7).octave=-2;c.part(7).engine.p[E_BEND_UP]=7;c.part(7).engine.p[E_BEND_DOWN]=12;
 d.combis.push_back({{0,0,1},c});d.performance=PerformanceSnapshot{c,SlotAddress{0,0,0},0,true};
 check(SetPackage::save("/tmp/solo_clean_compat.SVSET",d).success,"SET save");auto r=SetPackage::load("/tmp/solo_clean_compat.SVSET");check(r.ok()&&r.data.performance.has_value(),"SET load");
 for(const auto* u:{&r.data.combis[0].combi.part(7),&r.data.performance->combi.part(7)})check(u->engine.type==EngineType::Solo&&u->octave==-2&&u->engine.p[E_BEND_UP]==7&&u->engine.p[E_BEND_DOWN]==7,"single range/octave SET persistence");
 // A former trained/procedural SOLO row is consumed, then disabled.
 d.combis[0].combi.part(7).engine.p[20]=0;d.combis[0].combi.part(7).engine.p[19]=3;d.performance->combi=d.combis[0].combi;
 check(SetPackage::save("/tmp/solo_removed_compat.SVSET",d).success,"retired row save");r=SetPackage::load("/tmp/solo_removed_compat.SVSET");check(r.ok()&&r.data.combis[0].combi.part(7).engine.type==EngineType::Off&&r.data.performance->combi.part(7).engine.type==EngineType::Off,"removed SOLO source misinterpreted");
 SamplerEngine e;e.prepare(48000,128);auto st=std::make_shared<EngineState>();solo::preset(st->combi.part(7),0);auto& u=st->combi.part(7);u.portaTime=0;u.engine.p[solo::Air]=u.engine.p[solo::Response]=0;u.engine.p[E_BEND_UP]=u.engine.p[E_BEND_DOWN]=7;st->global.limiterEnabled=false;e.setState(st);e.postNoteOn(0,69,100);pitch(e,69);
 st=std::make_shared<EngineState>(*st);st->combi.part(7).octave=1;e.setState(st);pitch(e,81);e.postPitchBend(0,8191);pitch(e,88);e.postPitchBend(0,-8192);pitch(e,74);e.postPitchBend(0,0);pitch(e,81);
 st=std::make_shared<EngineState>(*st);st->combi.part(7).octave=-1;e.setState(st);pitch(e,57);e.postNoteOff(0,69);run(e);check(e.activeVoiceCount()==0,"stuck voice");
 std::cout<<"PASS only SOLO, retired rows OFF, SET range/octave, live octave and symmetric bend\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
