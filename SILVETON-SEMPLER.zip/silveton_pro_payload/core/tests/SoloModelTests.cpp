#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SoloPresets.h"
#include "silveton/sampler/SamplerEngine.h"
#include "SoloVoice.h"
#include <cassert>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <new>
static bool forbidAllocation=false;
void* operator new(std::size_t n){assert(!forbidAllocation);if(void*p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}
using namespace silveton::sampler;
int main(){
 auto m=std::make_shared<solo::Model>();m->name="Live model";m->releaseMs=80;
 for(int phase=0;phase<4;++phase)for(int cc=0;cc<2;++cc){solo::Cell c;c.at.phase=static_cast<solo::Phase>(phase);c.at.key=69;c.at.ageMs=phase==1?300:25;c.at.breath=float(cc);c.count=5;c.sound.db.fill(-90);c.sound.db[0]=0;c.sound.db[1]=cc?-3:-30;c.sound.rmsDb=-18;m->cells.push_back(c);}m->prepare();
 SetData set;set.name="Live";CombiSlot cs;cs.address={0,0,0};solo::preset(cs.combi.part(7),0);cs.combi.part(7).soloModel=m;set.combis.push_back(cs);set.performance=PerformanceSnapshot{};set.performance->combi=cs.combi;
 const std::string path="/tmp/silveton_live_set_test.svset";auto saved=SetPackage::save(path,set);assert(saved.success);auto loaded=SetPackage::load(path);assert(loaded.ok());assert(loaded.data.combis[0].combi.part(7).soloModel);assert(loaded.data.performance->combi.part(7).soloModel->name=="Live model");std::remove(path.c_str());
 auto run=[&](float cc){solo::Inputs in;in.key=in.registerKey=69;in.model=m.get();in.breath=cc;solo::Voice v;std::array<float,64>p{};solo::defaults(p.data());p[solo::LevelDb]=0;p[solo::ReleaseMs]=80;v.noteOn(p.data(),48000,in,1);std::vector<float>x;for(int i=0;i<24000;++i){float l,r;forbidAllocation=true;v.tick(440./48000,l,r);forbidAllocation=false;x.push_back((l+r)*.5F);}in.gate=false;v.setInputs(in,48000);for(int i=0;i<10000;++i){float l,r;forbidAllocation=true;v.tick(440./48000,l,r);forbidAllocation=false;}assert(v.finished());return x;};
 auto low=run(0),high=run(1);double delta=0,power=0;for(std::size_t i=8000;i<low.size();++i){delta+=std::pow(low[i]-high[i],2);power+=high[i]*high[i];}assert(power>1&&delta/power>.05);
 // Check that the normal sampler routing can play an imported model without a sample bank.
 SamplerEngine e;e.prepare(48000,128);auto state=std::make_shared<EngineState>();state->combi=cs.combi;e.setState(state);assert(e.postNoteOn(0,69,100));float block[256];double energy=0;for(int b=0;b<120;++b){e.render(block,128);for(float v:block){assert(std::isfinite(v));energy+=v*v;}}assert(energy>1);
 e.postNoteOff(0,69);for(int b=0;b<120;++b)e.render(block,128);assert(e.activeVoiceCount()==0);
 std::cout<<"PASS embedded models in COMBI and performance SET, MIDI controller changes audio, release, bank-free SOLO rendering\n";
}
