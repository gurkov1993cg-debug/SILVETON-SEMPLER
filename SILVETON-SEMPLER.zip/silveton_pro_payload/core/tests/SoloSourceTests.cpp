#include "SoloVoice.h"
#include "silveton/sampler/SoloPresets.h"
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SetPackage.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <new>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>
static thread_local bool trackAllocations=false;
static thread_local std::size_t allocationCount=0;
void* operator new(std::size_t n){if(trackAllocations)++allocationCount;if(void* p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void operator delete(void* p) noexcept {std::free(p);}
void operator delete(void* p,std::size_t) noexcept {std::free(p);}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete[](void* p) noexcept {::operator delete(p);}
void operator delete[](void* p,std::size_t) noexcept {::operator delete(p);}
using namespace silveton::sampler;
namespace so=silveton::sampler::solo;
using Params=std::array<float,kEngineParamCount>;
void require(bool x,const char* why){if(!x)throw std::runtime_error(why);}
double rms(const std::vector<float>& x){double s=0;for(float v:x){require(std::isfinite(v),"nonfinite output");s+=v*v;}return std::sqrt(s/x.size());}
double diff(const std::vector<float>& x,const std::vector<float>& y){double s=0;require(x.size()==y.size(),"unequal buffers");for(std::size_t i=0;i<x.size();++i){const double d=x[i]-y[i];s+=d*d;}return std::sqrt(s/x.size());}
std::vector<float> direct(const Params& p,double sr=48000,int key=62,float velocity=.85F,float breath=.7F,bool gesture=true){
 so::Voice voice;so::Inputs in;in.key=key;in.velocity=velocity;in.breath=breath;
 voice.noteOn(p.data(),sr,in,731);std::vector<float> out(static_cast<std::size_t>(sr*.6));
 for(std::size_t i=0;i<out.size();++i){if(gesture&&i==out.size()/3){in.key+=5;in.velocity=.55F;voice.setInputs(in,sr);}float r;voice.tick(440*std::exp2((in.key-69)/12.)/sr,out[i],r);require(std::abs(out[i])<=1,"output outside range");}
 return out;
}
void wave(const std::string& name,const std::vector<float>& x,int channels=1){
 double peak=0;for(float v:x)peak=std::max(peak,std::abs(static_cast<double>(v)));
 require(peak>1e-5,"silent render");const double gain=.85/peak;
 std::ofstream f(name,std::ios::binary);require(bool(f),"open wav failed");
 const auto w16=[&](unsigned v){f.put(static_cast<char>(v&255));f.put(static_cast<char>((v>>8)&255));};
 const auto w32=[&](unsigned v){w16(v&65535);w16(v>>16);};
 f.write("RIFF",4);w32(static_cast<unsigned>(x.size()*2+36));f.write("WAVEfmt ",8);w32(16);w16(1);w16(static_cast<unsigned>(channels));w32(48000);w32(static_cast<unsigned>(96000*channels));w16(static_cast<unsigned>(2*channels));w16(16);f.write("data",4);w32(static_cast<unsigned>(x.size()*2));
 for(float v:x)w16(static_cast<unsigned>(static_cast<std::int16_t>(std::lround(v*gain*32767))));
 require(bool(f),"wav write failed");
}
void macros(){
 Params p{};so::defaults(p.data());const auto baseline=direct(p);
 require(rms(baseline)>.005,"baseline silent");
 require(diff(baseline,direct(p))==0,"not deterministic");
 for(int id:{so::MorphX,so::MorphY,so::Brightness,so::Hollow,so::Formant,so::Focus,so::Air,so::Response,so::AttackMs,so::LevelDb}){
  auto q=p;q[id]=so::parameter(id)->hi;const double d=diff(baseline,direct(q));
  std::cout<<"macro "<<id<<" RMS difference "<<d<<'\n';require(d>.00002,"inactive macro");
 }
 p[so::BreathMode]=1;auto q=p;q[so::BreathDepth]=0;
 require(diff(direct(p),direct(q))>.0001,"BC depth inactive");
 require(diff(direct(p,48000,62,.85F,0),direct(p,48000,62,.85F,1))>.001,"BC timbre inactive");
 p[so::BreathMode]=2;require(rms(direct(p,48000,62,.85F,0))==0,"BC gate leak");
 p[so::BreathMode]=0;require(diff(direct(p,48000,62,.2F),direct(p,48000,62,1))>.005,"velocity inactive");
 std::cout<<"PASS macros, deterministic synthesis, velocity and breath\n";
}
void stress(){
 Params p{};so::defaults(p.data());unsigned rng=83;
 for(double sr:{44100.,48000.,96000.}){
  so::Voice v;so::Inputs in;v.noteOn(p.data(),sr,in,1);
  for(int block=0;block<140;++block){
   for(int id=0;id<8;++id){rng=rng*1664525U+1013904223U;p[id]=static_cast<float>(rng&65535)/65535;}
   p[so::LevelDb]=6;v.setParams(p.data());in.key=12+(block*13)%108;in.velocity=.25F+.75F*(block%2);in.pressure=.9F;in.breath=.8F;v.setInputs(in,sr);
   for(int j=0;j<384;++j){float l,r;v.tick(440*std::exp2((in.key-69)/12.)/sr,l,r);if(!std::isfinite(l)||std::abs(l)>1||!std::isfinite(r)||std::abs(r)>1){std::cerr<<"stress rate "<<sr<<" block "<<block<<" sample "<<j<<" out "<<l<<","<<r<<"\n";throw std::runtime_error("stress unstable");}}
  }
 }
 so::defaults(p.data());
 for(double sr:{44100.,48000.,96000.})for(int key:{24,48,72,96,108})require(rms(direct(p,sr,key))>.0001,"register silent");
 for(int release:{0,5,95,700}){
  p[so::ReleaseMs]=static_cast<float>(release);so::Voice v;so::Inputs in;v.noteOn(p.data(),48000,in,1);float l,r;
  for(int n=0;n<12000;++n)v.tick(440./48000,l,r);
  in.gate=false;v.setInputs(in,48000);int n=0;while(!v.finished()&&n<50000){v.tick(440./48000,l,r);++n;}
  require(std::abs(n-(std::max(release,5)*48+40))<=3,"wrong release or stuck note");
 }
 std::cout<<"PASS parameter stress, 3 rates, range and release\n";
}
void history(){
 // Opposite approaches to the same final key. Compare with memory/response off
 // separately; this asserts a real path-dependent state, not only a static EQ.
 so::Source a,b;Params p{};so::defaults(p.data());a.prepare(96000,60,1);b.prepare(96000,72,.3);
 for(int i=0;i<24000;++i){if(i%16==0){a.controls(p.data(),261.625,0,0);b.controls(p.data(),523.25,0,0);}a.tick(261.625);b.tick(523.25);}
 a.note(67,.8);b.note(67,.8);require(std::abs(a.history()-b.history())>.005,"phrase history has no effect");
 std::cout<<"PASS phrase history differs after different note/velocity context\n";
}
void benchmark(){
 Params p{};so::defaults(p.data());p[so::MorphX]=p[so::MorphY]=p[so::Focus]=1;
 so::Voice v;so::Inputs in;v.noteOn(p.data(),48000,in,1);double sum=0;std::vector<double> times;
 auto start=std::chrono::steady_clock::now();
 for(int b=0;b<3750;++b){const auto t=std::chrono::steady_clock::now();for(int i=0;i<128;++i){float l,r;v.tick(440./48000,l,r);sum+=l;}times.push_back(std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-t).count());}
 const double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();std::sort(times.begin(),times.end());
 std::cout<<"BENCHMARK Linux host only: 10 s audio in "<<elapsed<<" s; average one-core ratio "<<100*elapsed/10<<"%; 128-frame p99 "<<times[times.size()*99/100]<<" us; max "<<times.back()<<" us; checksum "<<sum<<'\n';
}
Combi patch(){Combi c;c.name="SILVETON SOLO";so::preset(c.part(7),0);so::defaults(c.part(7).engine.p.data());c.part(7).name="SOLO";return c;}
void persistence(const std::string& path,bool testBend=true){
 SetData d;d.name="SILVETON SOLO";auto c=patch();if(testBend){c.part(7).engine.p[E_BEND_UP]=7;c.part(7).engine.p[E_BEND_DOWN]=7;}
 d.combis.push_back({{0,0,0},c});d.performance=PerformanceSnapshot{c,SlotAddress{0,0,0},0,false};
 SetList list;list.name=d.name;list.entries.push_back({1,"SOLO",0,0,0});d.lists.push_back({{0,0,0},list});
 require(SetPackage::save(path,d).success,"SET save failed");const auto r=SetPackage::load(path);
 require(r.ok()&&r.data.performance.has_value(),"SET load failed");require(r.data.performance->combi.part(7).engine.p==c.part(7).engine.p,"SET changed parameters");
 std::cout<<"PASS SET exact restoration and independent pitch-bend ranges\n";
}
double pitch(const std::vector<float>& stereo,double expected,double sr){
 std::vector<double> x;for(std::size_t i=stereo.size()/2;i<stereo.size();i+=2)x.push_back(stereo[i]);
 const int center=static_cast<int>(sr/expected);const int lo=std::max(2,static_cast<int>(center*.9)),hi=static_cast<int>(center*1.1)+2;
 std::vector<double> ac(static_cast<std::size_t>(hi+2));
 for(int lag=lo-1;lag<=hi+1;++lag){double aa=0,bb=0,ab=0;for(std::size_t i=0;i+static_cast<std::size_t>(hi+2)<x.size();++i){const double a=x[i],b=x[i+static_cast<std::size_t>(lag)];ab+=a*b;aa+=a*a;bb+=b*b;}ac[static_cast<std::size_t>(lag)]=ab/std::sqrt(aa*bb+1e-30);}
 int best=lo;for(int lag=lo;lag<=hi;++lag)if(ac[static_cast<std::size_t>(lag)]>ac[static_cast<std::size_t>(best)])best=lag;
 const double a=ac[static_cast<std::size_t>(best-1)],b=ac[static_cast<std::size_t>(best)],c=ac[static_cast<std::size_t>(best+1)];
 return sr/(best+.5*(a-c)/(a-2*b+c));
}
void midi(){
 auto state=std::make_shared<EngineState>();state->combi=patch();auto& p=state->combi.part(7).engine.p;p[E_BEND_UP]=7;p[E_BEND_DOWN]=12;
 state->global.limiterEnabled=false;state->combi.part(7).portaTime=0;
 SamplerEngine e;e.prepare(48000,128);e.setState(state);
 auto run=[&](double secs){std::vector<float> x(static_cast<std::size_t>(secs*48000)*2);for(std::size_t i=0;i<x.size()/2;){const auto n=static_cast<unsigned>(std::min<std::size_t>(128,x.size()/2-i));e.render(x.data()+2*i,n);i+=n;}return x;};
 auto checkPitch=[&](int key){auto x=run(.3);const double expected=440*std::exp2((key-69)/12.),found=pitch(x,expected,48000);const double cents=1200*std::log2(found/expected);std::cout<<"MIDI key "<<key<<" pitch error "<<cents<<" cents\n";require(std::abs(cents)<2,"MIDI pitch error");require(e.activeVoiceCount()==1,"extra mono voices");};
 e.postNoteOn(0,69,100);checkPitch(69);e.postPitchBend(0,8191);checkPitch(76);e.postPitchBend(0,-8192);checkPitch(57);e.postPitchBend(0,0);
 e.postNoteOn(0,72,115);checkPitch(72);e.postNoteOff(0,72);checkPitch(69);
 std::array<float,256> scratch{};allocationCount=0;trackAllocations=true;for(int i=0;i<100;++i)e.render(scratch.data(),128);trackAllocations=false;require(allocationCount==0,"render allocated memory");
 e.postNoteOff(0,69);run(.5);require(e.activeVoiceCount()==0,"MIDI stuck note");
 std::cout<<"PASS actual SamplerEngine MIDI bend, legato return, no render allocation\n";
}
void demo(const std::string& dir){
 auto c=patch();auto state=std::make_shared<EngineState>();state->combi=c;state->global.limiterEnabled=false;
 SamplerEngine e;e.prepare(48000,128);e.setState(state);std::vector<float> audio;
 auto run=[&](int n){const auto start=audio.size();audio.resize(start+2*static_cast<std::size_t>(n));for(int i=0;i<n;){const int frames=std::min(128,n-i);e.render(audio.data()+start+2*static_cast<std::size_t>(i),static_cast<unsigned>(frames));i+=frames;}};
 const int notes[]={62,63,62,66,67,66,63,62,69,70,69,67,66,67,69,74};
 for(int pass=0;pass<3;++pass){
  state=std::make_shared<EngineState>(*state);
  auto& p=state->combi.part(7).engine.p;
  if(pass==1){p[so::MorphX]=.9F;p[so::MorphY]=.65F;p[so::Formant]=.78F;p[so::Focus]=.55F;}
  if(pass==2){p[so::MorphX]=.45F;p[so::MorphY]=.35F;p[so::Formant]=.4F;p[so::Focus]=.65F;p[so::Air]=1;p[so::Response]=1;}
  e.setState(state);
  for(int i=0;i<16;++i){const int key=notes[i];require(e.postNoteOn(0,static_cast<std::uint8_t>(key),static_cast<std::uint8_t>(i%4?85:118)),"note queue");if(i)require(e.postNoteOff(0,static_cast<std::uint8_t>(notes[i-1])),"off queue");
   if(pass==2)e.postPitchBend(0,i%4==0?4096:0);
   run(i%8==1||i%8==2?4364:13091);
  }
  e.postNoteOff(0,74);e.postPitchBend(0,0);run(19200);require(e.activeVoiceCount()==0,"stuck voice in demo");
 }
 wave(dir+"/SILVETON_ANALOG_ONE_DEMO.wav",audio,2);
 for(int key:{69,93,105})for(int edge=0;edge<2;++edge){
  Params p{};so::defaults(p.data());p[so::Response]=p[so::Air]=0;if(edge){p[so::MorphX]=p[so::MorphY]=.9F;p[so::Focus]=.6F;}
  so::Voice v;so::Inputs in;in.key=key;v.noteOn(p.data(),48000,in,1);std::vector<float> probe(48000);
  for(int i=0;i<96000;++i){float l,r;v.tick(440*std::exp2((key-69)/12.)/48000,l,r);if(i>=48000)probe[static_cast<std::size_t>(i-48000)]=l;}
  wave(dir+"/probe_"+std::to_string(key)+"_"+std::to_string(edge)+".wav",probe);
 }
 persistence(dir+"/SILVETON_ANALOG_ONE.SVSET",false);
 std::cout<<"PASS demo through SamplerEngine, no Teacher models loaded; "<<audio.size()/96000.<<" s\n";
}
int main(int argc,char** argv){try{macros();stress();history();midi();persistence("/tmp/solo_source_test.SVSET");benchmark();if(argc>1)demo(argv[1]);}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
