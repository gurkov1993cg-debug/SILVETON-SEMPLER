// SILVETON_SOLO_V1 - the tests of SILVETON SOLO: the voice is rendered and measured (pitch, spectrum, loudness, timing), the
// definitions are checked (pages, defaults, sounds, the glide curves). No sound is judged by ear here - that is the player's part.
#include "SoloVoice.h"
#include "silveton/sampler/SoloDefs.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace silveton::sampler;
using namespace silveton::sampler::solo;

namespace {

int g_fail = 0, g_checks = 0;
#define CHECK(cond, ...)                                                           \
    do {                                                                           \
        ++g_checks;                                                                \
        if (!(cond)) { ++g_fail; std::printf("FAIL line %d: %s  ", __LINE__, #cond); std::printf(__VA_ARGS__); std::printf("\n"); } \
    } while (0)

constexpr double kSr = 48000.0;
float P[kEngineParamCountLegacy];

double keyHz(int key) { return 440.0 * std::pow(2.0, (key - 69) / 12.0); }

struct Out { std::vector<float> l, r; };

// a note: held for relAt seconds, rendered secs seconds; the pitch of `key` (a glide can be given as a second key reached at glideSec)
Out render(const float* p, int key, double secs, double relAt, float vel = 0.8F, float wheel = 0.0F, float pressure = 0.0F, int toKey = -1, double glideAt = 0.0, double glideSec = 0.0) {
    Voice v;
    Inputs in; in.key = key; in.velocity = vel; in.gate = true; in.wheel = wheel; in.pressure = pressure;
    v.noteOn(p, kSr, in, 12345U);
    Out o;
    const int n = static_cast<int>(secs * kSr);
    double inc = keyHz(key) / kSr;
    for (int i = 0; i < n; ++i) {
        const double t = i / kSr;
        if (i % 64 == 0) {
            in.gate = t < relAt;
            if (toKey >= 0 && t >= glideAt) in.key = toKey;
            v.setInputs(in, kSr);
        }
        if (toKey >= 0 && t >= glideAt) {
            const double x = glideSec > 0.0 ? std::min(1.0, (t - glideAt) / glideSec) : 1.0;
            inc = std::exp2((static_cast<double>(key) + (toKey - key) * x - 69.0) / 12.0) * 440.0 / kSr;
        }
        float l, r; v.tick(inc, l, r);
        o.l.push_back(l); o.r.push_back(r);
        if (v.finished()) break;
    }
    return o;
}

void fftc(std::vector<std::complex<double>>& a) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) { size_t bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) std::swap(a[i], a[j]); }
    for (size_t len = 2; len <= n; len <<= 1) {
        const double ang = -2.0 * 3.14159265358979323846 / static_cast<double>(len);
        const std::complex<double> wl(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) { std::complex<double> w(1.0, 0.0); for (size_t k = 0; k < len / 2; ++k) { const auto u = a[i + k], v = a[i + k + len / 2] * w; a[i + k] = u + v; a[i + k + len / 2] = u - v; w *= wl; } }
    }
}
std::vector<double> spectrum(const std::vector<float>& x, size_t from, size_t n) {
    std::vector<std::complex<double>> a(n);
    for (size_t i = 0; i < n; ++i) {
        const double w = 0.5 - 0.5 * std::cos(2.0 * 3.14159265358979323846 * static_cast<double>(i) / static_cast<double>(n));
        a[i] = (from + i < x.size() ? static_cast<double>(x[from + i]) : 0.0) * w;
    }
    fftc(a);
    std::vector<double> m(n / 2);
    for (size_t i = 0; i < n / 2; ++i) m[i] = std::abs(a[i]) / static_cast<double>(n);
    return m;
}
double binHz(const std::vector<double>& m) { return kSr / (2.0 * static_cast<double>(m.size())); }
double bandEnergy(const std::vector<double>& m, double lo, double hi) {
    double e = 0.0; const double bh = binHz(m);
    for (size_t i = 1; i < m.size(); ++i) { const double f = static_cast<double>(i) * bh; if (f >= lo && f <= hi) e += m[i] * m[i]; }
    return e;
}
double db(double ratio) { return 20.0 * std::log10(ratio + 1e-20); }
double centroidHz(const std::vector<double>& m) {
    double num = 0.0, den = 0.0; const double bh = binHz(m);
    for (size_t i = 1; i < m.size(); ++i) { num += m[i] * static_cast<double>(i) * bh; den += m[i]; }
    return den > 0.0 ? num / den : 0.0;
}
// the pitch by autocorrelation in a window
double acfHz(const std::vector<float>& x, size_t from, size_t n, double lo, double hi) {
    const int lagMin = static_cast<int>(kSr / hi), lagMax = static_cast<int>(kSr / lo);
    double best = -1.0; int bestLag = lagMin;
    for (int lag = lagMin; lag <= lagMax; ++lag) {
        double c = 0.0, e1 = 0.0, e2 = 0.0;
        for (size_t i = from; i + static_cast<size_t>(lag) < from + n && i + static_cast<size_t>(lag) < x.size(); ++i) {
            c += static_cast<double>(x[i]) * x[i + static_cast<size_t>(lag)]; e1 += static_cast<double>(x[i]) * x[i]; e2 += static_cast<double>(x[i + static_cast<size_t>(lag)]) * x[i + static_cast<size_t>(lag)];
        }
        const double r = c / std::sqrt(std::max(e1 * e2, 1e-30));
        if (r > best) { best = r; bestLag = lag; }
    }
    return kSr / bestLag;
}
double cents(double f, double ref) { return 1200.0 * std::log2(f / ref); }
double peakOf(const std::vector<float>& x, size_t from = 0, size_t to = 0) { if (!to || to > x.size()) to = x.size(); double p = 0; for (size_t i = from; i < to; ++i) p = std::max(p, std::fabs(static_cast<double>(x[i]))); return p; }
double rmsOf(const std::vector<float>& x, size_t from, size_t to) { double e = 0; to = std::min(to, x.size()); for (size_t i = from; i < to; ++i) e += static_cast<double>(x[i]) * x[i]; return std::sqrt(e / static_cast<double>(std::max<size_t>(1, to - from))); }
bool allFinite(const Out& o, double lim = 2.0) { for (size_t i = 0; i < o.l.size(); ++i) if (!std::isfinite(o.l[i]) || !std::isfinite(o.r[i]) || std::fabs(o.l[i]) > lim || std::fabs(o.r[i]) > lim) return false; return true; }
// the ratio of the energy that is NOT at a harmonic of f0 (aliasing, noise) to the energy at the harmonics
double nonHarmonicDb(const std::vector<double>& m, double f0) {
    const double bh = binHz(m);
    double harm = 0.0, other = 0.0;
    for (size_t i = 2; i < m.size(); ++i) {
        const double f = static_cast<double>(i) * bh;
        const double k = f / f0;
        const bool near = std::fabs(k - std::round(k)) * f0 < 2.5 * bh;
        if (near) harm += m[i] * m[i]; else other += m[i] * m[i];
    }
    return db(std::sqrt(other / std::max(harm, 1e-30)));
}

void plain(float* p) {   // one saw, no filter, no unison, no envelopes to speak of
    setDefaults(p);
    p[SO_OSC1_WAVE] = W_SAW; p[SO_OSC1_LEVEL] = 0.8F; p[SO_OSC2_LEVEL] = 0.0F; p[SO_SUB_LEVEL] = 0.0F; p[SO_NOISE_LEVEL] = 0.0F;
    p[E_FILT_TYPE] = FL_OFF; p[E_UNISON] = 1.0F; p[E_ANALOG] = 0.0F; p[E_LFO_PITCH] = 0.0F; p[SO_VIB_WHEEL] = 0.0F; p[SO_VIB_AT] = 0.0F;
    p[SO_AMP_A] = 1.0F; p[SO_AMP_D] = 100.0F; p[SO_AMP_S] = 1.0F; p[SO_AMP_R] = 50.0F; p[SO_VEL_AMP] = 0.0F;
    p[E_DRIVE] = 0.0F; p[SO_OUT_DRIVE] = 0.0F; p[SO_WIDTH] = 0.5F; p[SO_DCW] = 0.0F;
}

// ------------------------------------------------------------------------------------------------ the tests
void testDefs() {
    std::printf("-- definitions: pages, ids, defaults, sounds\n");
    int seen[kEngineParamCountLegacy] = {};
    for (int pg = 0; pg < kPages; ++pg) {
        const EngineParamPage page_ = page(pg);
        CHECK(page_.count > 0 && page_.count <= 14, "page %d has %d knobs (the screen draws up to 14)", pg, page_.count);
        for (int i = 0; i < page_.count; ++i) {
            const EngineParamDef& d = page_.items[i];
            CHECK(d.id >= 0 && d.id < kEngineParamCountLegacy, "id %d in range", d.id);
            CHECK(seen[d.id] == 0, "id %d appears once (%s)", d.id, d.label);
            ++seen[d.id];
            CHECK(d.lo < d.hi && d.def >= d.lo && d.def <= d.hi, "%s: lo < def < hi", d.label);
            CHECK(d.label != nullptr && std::strlen(d.label) > 0 && d.hint != nullptr && std::strlen(d.hint) > 0, "%s has a label and a hint", d.label);
        }
    }
    CHECK(page(kPages).count == 0, "no page after the last");
    setDefaults(P);
    CHECK(P[SO_OSC1_WAVE] == 0.0F && P[E_SOURCE] == static_cast<float>(E_SRC_OWN) && P[E_BYPASS] == 0.0F, "defaults: own sound, not bypassed");
    for (int i = 0; i < kPresets; ++i) {
        float q[kEngineParamCountLegacy];
        setDefaults(q); q[E_BEND_UP] = 7.0F; q[E_BYPASS] = 1.0F;
        preset(i, q);
        CHECK(std::strlen(presetName(i)) > 0, "sound %d has a name", i);
        CHECK(q[E_BEND_UP] == 7.0F && q[E_BYPASS] == 1.0F, "sound %d keeps the three common keys", i);
        for (int pg = 0; pg < kPages; ++pg) {
            const EngineParamPage page_ = page(pg);
            for (int k = 0; k < page_.count; ++k) { const auto& d = page_.items[k]; CHECK(q[d.id] >= d.lo && q[d.id] <= d.hi, "sound %d: %s = %.2f inside %.2f..%.2f", i, d.label, q[d.id], d.lo, d.hi); }
        }
    }
    // the glide curves
    setDefaults(P); P[SO_GLIDE] = 100.0F;
    P[SO_GLIDE_STYLE] = GL_CZ;  CHECK(std::fabs(glideSeconds(P, 1.0) - 0.1F) < 1e-4F && std::fabs(glideSeconds(P, 24.0) - 0.1F) < 1e-4F, "CZ: the same time for a semitone and two octaves");
    P[SO_GLIDE_STYLE] = GL_DX;  CHECK(std::fabs(glideSeconds(P, 12.0) - 0.1F) < 1e-4F && std::fabs(glideSeconds(P, 24.0) - 0.2F) < 1e-4F && glideSeconds(P, 1.0) < 0.02F, "DX: a time per octave");
    P[SO_GLIDE_STYLE] = GL_JS1; CHECK(glideSeconds(P, 1.0) > glideSeconds(P, 12.0) && std::fabs(glideSeconds(P, 12.0) - 0.1F) < 1e-4F, "JS1: a semitone a little longer, far = TIME");
    P[SO_GLIDE_STYLE] = GL_JS2; CHECK(std::fabs(glideSeconds(P, 7.0) - 0.1F) < 1e-4F && musicalCurve(P), "JS2: TIME, the musical curve");
    P[SO_GLIDE] = 0.0F; CHECK(glideSeconds(P, 12.0) == 0.0F && !glideOn(P), "GLIDE 0 = no glide");
    P[SO_LEGATO] = LG_FINGERED; CHECK(fingered(P), "legato fingered");
}

void testPitchAndWaves() {
    std::printf("-- pitch and the waves\n");
    const char* names[kWaves] = {"saw", "pulse", "tri", "sine", "CZ saw", "CZ pulse", "CZ res I", "CZ res II"};
    for (int w = 0; w < kWaves; ++w) {
        plain(P); P[SO_OSC1_WAVE] = static_cast<float>(w); P[SO_DCW] = 0.7F; P[SO_DCW_S] = 1.0F; P[SO_DCW_KEY] = 0.0F; P[SO_DCW_VEL] = 0.0F;
        for (const int key : {45, 69}) {
            const Out o = render(P, key, 0.6, 0.5);
            CHECK(allFinite(o), "%s key %d finite", names[w], key);
            const double f = acfHz(o.l, static_cast<size_t>(0.3 * kSr), 8192, keyHz(key) * 0.7, keyHz(key) * 1.4);
            CHECK(std::fabs(cents(f, keyHz(key))) < 8.0, "%s key %d: pitch %.1f cents off", names[w], key, cents(f, keyHz(key)));
            CHECK(peakOf(o.l, static_cast<size_t>(0.2 * kSr), static_cast<size_t>(0.4 * kSr)) > 0.1, "%s key %d sounds", names[w], key);
        }
    }
    // band-limiting: a saw and a pulse at a high note have little energy that is not at a harmonic
    for (const int w : {W_SAW, W_PULSE}) {
        plain(P); P[SO_OSC1_WAVE] = static_cast<float>(w);
        const Out o = render(P, 96, 0.6, 0.5);   // C7 ~ 2093 Hz
        const auto m = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
        const double nh = nonHarmonicDb(m, keyHz(96));
        CHECK(nh < -25.0, "%s at C7: what is not a harmonic is %.1f dB below", names[w], nh);
    }
    // the CZ shape: more shape = a brighter sound (the envelope opens the wave the way a filter would)
    plain(P); P[SO_OSC1_WAVE] = W_CZ_SAW; P[SO_DCW_S] = 1.0F; P[SO_DCW_KEY] = 0.0F; P[SO_DCW_VEL] = 0.0F;
    P[SO_DCW] = 0.05F; auto o = render(P, 57, 0.6, 0.5); const double cLow = centroidHz(spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192));
    P[SO_DCW] = 0.95F; o = render(P, 57, 0.6, 0.5); const double cHigh = centroidHz(spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192));
    CHECK(cHigh > cLow * 2.5, "CZ saw: shape 5%% centroid %.0f Hz, 95%% centroid %.0f Hz", cLow, cHigh);
    // the CZ envelope: a long decay to 0 makes the sound darker with time
    P[SO_DCW] = 0.95F; P[SO_DCW_A] = 1.0F; P[SO_DCW_D] = 400.0F; P[SO_DCW_S] = 0.0F;
    o = render(P, 57, 1.6, 1.5);
    const double cEarly = centroidHz(spectrum(o.l, static_cast<size_t>(0.02 * kSr), 4096)), cLate = centroidHz(spectrum(o.l, static_cast<size_t>(1.2 * kSr), 4096));
    CHECK(cEarly > cLate * 1.8, "CZ envelope: early %.0f Hz, late %.0f Hz", cEarly, cLate);
    // the pulse width changes the sound; PWM moves it
    plain(P); P[SO_OSC1_WAVE] = W_PULSE; P[SO_PW] = 0.5F; o = render(P, 57, 0.6, 0.5);
    const auto m50 = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
    P[SO_PW] = 0.15F; o = render(P, 57, 0.6, 0.5);
    const auto m15 = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
    const double f0 = keyHz(57); const size_t b2 = static_cast<size_t>(std::lround(2.0 * f0 / binHz(m50)));
    CHECK(m50[b2] < 0.2 * m15[b2], "a 50%% pulse has no 2nd harmonic (%.4f), a 15%% one has (%.4f)", m50[b2], m15[b2]);
    // sync: oscillator 2 at a fifth, synced, gives a sound with the harmonics of oscillator 1 (the pitch is that of 1)
    plain(P); P[SO_OSC1_LEVEL] = 0.0F; P[SO_OSC2_WAVE] = W_SAW; P[SO_OSC2_LEVEL] = 0.8F; P[SO_OSC2_SEMI] = 7.0F; P[SO_SYNC] = 1.0F;
    o = render(P, 57, 0.6, 0.5);
    const double fs = acfHz(o.l, static_cast<size_t>(0.3 * kSr), 8192, f0 * 0.7, f0 * 1.4);
    CHECK(std::fabs(cents(fs, f0)) < 10.0, "sync: the pitch is oscillator 1's (%.1f cents)", cents(fs, f0));
    P[SO_SYNC] = 0.0F; o = render(P, 57, 0.6, 0.5);
    const double fn = acfHz(o.l, static_cast<size_t>(0.3 * kSr), 8192, f0 * 1.2, f0 * 1.8);
    CHECK(std::fabs(cents(fn, f0 * std::pow(2.0, 7.0 / 12.0))) < 10.0, "no sync: oscillator 2 sounds at the fifth (%.1f cents)", cents(fn, f0 * std::pow(2.0, 7.0 / 12.0)));
    // the sub: an octave below
    plain(P); P[SO_OSC1_LEVEL] = 0.0F; P[SO_SUB_LEVEL] = 0.8F; o = render(P, 57, 0.6, 0.5);
    const double fsub = acfHz(o.l, static_cast<size_t>(0.3 * kSr), 8192, f0 * 0.35, f0 * 0.7);
    CHECK(std::fabs(cents(fsub, f0 * 0.5)) < 10.0, "sub: one octave down (%.1f cents)", cents(fsub, f0 * 0.5));
    // the octave keys
    plain(P); P[SO_OSC1_OCT] = 1.0F; o = render(P, 57, 0.6, 0.5);
    const double fo = acfHz(o.l, static_cast<size_t>(0.3 * kSr), 8192, f0 * 1.4, f0 * 2.8);
    CHECK(std::fabs(cents(fo, f0 * 2.0)) < 8.0, "ОКТАВА 1 = +1: an octave up (%.1f cents)", cents(fo, f0 * 2.0));
    // noise alone is not pitched and is finite
    plain(P); P[SO_OSC1_LEVEL] = 0.0F; P[SO_NOISE_LEVEL] = 1.0F; o = render(P, 57, 0.4, 0.3);
    CHECK(allFinite(o) && rmsOf(o.l, static_cast<size_t>(0.1 * kSr), static_cast<size_t>(0.3 * kSr)) > 0.05, "noise sounds and is finite");
}

void testFilterEnvelopesUnison() {
    std::printf("-- filter, envelopes, unison, vibrato, drive\n");
    const double f0 = keyHz(45);
    // the ladder: cutoff down = the high harmonics go; resonance = a peak at the cutoff
    plain(P); P[E_FILT_TYPE] = FL_LADDER24; P[E_KEYTRACK] = 0.0F; P[E_FEG_AMT] = 0.0F; P[E_VEL_CUT] = 0.0F; P[E_RESO] = 0.0F;
    P[E_CUTOFF] = 20000.0F; auto o = render(P, 45, 0.6, 0.5); const auto mo = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
    P[E_CUTOFF] = 500.0F; o = render(P, 45, 0.6, 0.5); const auto mc = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
    const double hiOpen = bandEnergy(mo, 2000.0, 8000.0), hiClosed = bandEnergy(mc, 2000.0, 8000.0);
    CHECK(db(std::sqrt(hiClosed / hiOpen)) < -30.0, "ladder 500 Hz: 2-8 kHz is %.1f dB down", db(std::sqrt(hiClosed / hiOpen)));
    P[E_CUTOFF] = 1000.0F; P[E_RESO] = 0.85F; o = render(P, 45, 0.6, 0.5); const auto mr = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
    CHECK(allFinite(o), "resonance: finite");
    const double nearCut = bandEnergy(mr, 850.0, 1150.0), belowCut = bandEnergy(mr, 300.0, 600.0);
    const double nearCut0 = bandEnergy(mc, 850.0, 1150.0), belowCut0 = bandEnergy(mc, 300.0, 600.0);
    CHECK(nearCut / belowCut > 1.5 * (nearCut0 / belowCut0), "resonance lifts the cutoff region (ratio %.2f vs %.2f)", nearCut / belowCut, nearCut0 / belowCut0);
    // the 12 dB types
    for (const int ft : {FL_LP12, FL_HP12, FL_BP12}) {
        P[E_FILT_TYPE] = static_cast<float>(ft); P[E_CUTOFF] = 1500.0F; P[E_RESO] = 0.2F; o = render(P, 45, 0.6, 0.5);
        CHECK(allFinite(o) && peakOf(o.l, static_cast<size_t>(0.2 * kSr), static_cast<size_t>(0.4 * kSr)) > 0.02, "filter type %d sounds and is finite", ft);
        const auto m = spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192);
        const double lo = bandEnergy(m, 100.0, 500.0), hi = bandEnergy(m, 5000.0, 12000.0);
        if (ft == FL_LP12) CHECK(db(std::sqrt(hi / lo)) < db(std::sqrt(bandEnergy(mo, 5000.0, 12000.0) / bandEnergy(mo, 100.0, 500.0))) - 15.0, "LP12 cuts the top");
        if (ft == FL_HP12) CHECK(lo < 0.3 * bandEnergy(mo, 100.0, 500.0), "HP12 cuts the bottom");
    }
    // the filter envelope: open at the start, closes in DECAY
    plain(P); P[E_FILT_TYPE] = FL_LADDER24; P[E_CUTOFF] = 400.0F; P[E_FEG_AMT] = 4.0F; P[E_FEG_A] = 1.0F; P[E_FEG_D] = 300.0F; P[E_FEG_S] = 0.0F; P[E_KEYTRACK] = 0.0F; P[E_VEL_CUT] = 0.0F;
    o = render(P, 45, 1.5, 1.4);
    const double bEarly = centroidHz(spectrum(o.l, static_cast<size_t>(0.01 * kSr), 4096)), bLate = centroidHz(spectrum(o.l, static_cast<size_t>(1.1 * kSr), 4096));
    CHECK(bEarly > bLate * 1.7, "filter envelope: early %.0f Hz, late %.0f Hz", bEarly, bLate);
    // key tracking: the same knob, a higher key opens more
    P[E_FEG_AMT] = 0.0F; P[E_KEYTRACK] = 1.0F; P[E_CUTOFF] = 800.0F;
    o = render(P, 45, 0.6, 0.5); const double kLow = centroidHz(spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192));
    o = render(P, 69, 0.6, 0.5); const double kHigh = centroidHz(spectrum(o.l, static_cast<size_t>(0.3 * kSr), 8192));
    CHECK(kHigh > kLow * 1.6, "key tracking: key 45 centroid %.0f, key 69 %.0f", kLow, kHigh);
    // the amplifier envelope: attack time, release time
    plain(P); P[SO_AMP_A] = 200.0F; P[SO_AMP_D] = 50.0F; P[SO_AMP_S] = 1.0F; P[SO_AMP_R] = 300.0F;
    o = render(P, 45, 1.5, 0.8);
    const double a50 = rmsOf(o.l, static_cast<size_t>(0.05 * kSr), static_cast<size_t>(0.07 * kSr)), a200 = rmsOf(o.l, static_cast<size_t>(0.25 * kSr), static_cast<size_t>(0.3 * kSr));
    CHECK(a50 < 0.6 * a200 && a50 > 0.05 * a200, "attack 200 ms: at 60 ms %.3f, at 270 ms %.3f", a50, a200);
    const double r100 = rmsOf(o.l, static_cast<size_t>(0.9 * kSr), static_cast<size_t>(0.92 * kSr)), r300 = rmsOf(o.l, static_cast<size_t>(1.1 * kSr), static_cast<size_t>(1.12 * kSr)), rEnd = rmsOf(o.l, static_cast<size_t>(1.4 * kSr), static_cast<size_t>(1.45 * kSr));
    CHECK(r100 > r300 && r300 > rEnd * 2.0 && rEnd < 0.05 * a200, "release 300 ms: %.3f -> %.3f -> %.4f", r100, r300, rEnd);
    CHECK(o.l.size() < static_cast<size_t>(1.5 * kSr), "the voice says it is finished once the release is over (%.2f s)", static_cast<double>(o.l.size()) / kSr);
    // velocity -> level
    plain(P); P[SO_VEL_AMP] = 1.0F;
    const double soft_ = rmsOf(render(P, 45, 0.4, 0.3, 0.3F).l, static_cast<size_t>(0.2 * kSr), static_cast<size_t>(0.3 * kSr));
    const double hard = rmsOf(render(P, 45, 0.4, 0.3, 1.0F).l, static_cast<size_t>(0.2 * kSr), static_cast<size_t>(0.3 * kSr));
    CHECK(soft_ < 0.45 * hard, "velocity: soft %.3f, hard %.3f", soft_, hard);
    // unison: two copies, spread - left and right differ; one copy - they are the same
    plain(P); P[E_UNISON] = 1.0F; o = render(P, 45, 0.5, 0.4);
    double diff1 = 0.0; for (size_t i = 0; i < o.l.size(); ++i) diff1 += std::fabs(o.l[i] - o.r[i]);
    P[E_UNISON] = 4.0F; P[E_UNI_DET] = 12.0F; P[E_UNI_SPREAD] = 1.0F; o = render(P, 45, 0.5, 0.4);
    double diff4 = 0.0; for (size_t i = 0; i < o.l.size(); ++i) diff4 += std::fabs(o.l[i] - o.r[i]);
    CHECK(diff1 < 1e-3 && diff4 > 100.0, "unison 1: mono (%.4f); unison 4 spread: stereo (%.1f)", diff1, diff4);
    CHECK(allFinite(o) && rmsOf(o.l, static_cast<size_t>(0.2 * kSr), static_cast<size_t>(0.4 * kSr)) > 0.1, "unison 4 is loud enough and finite");
    const double fu = acfHz(o.l, static_cast<size_t>(0.2 * kSr), 8192, f0 * 0.7, f0 * 1.4);
    CHECK(std::fabs(cents(fu, f0)) < 15.0, "unison keeps the pitch (%.1f cents)", cents(fu, f0));
    // vibrato: the wheel adds it; without the wheel and with depth 0 the pitch is steady
    plain(P); P[E_LFO_PITCH] = 0.0F; P[SO_VIB_WHEEL] = 100.0F; P[E_LFO_RATE] = 6.0F;
    o = render(P, 57, 1.0, 0.9, 0.8F, 1.0F);
    const double fA = acfHz(o.l, static_cast<size_t>(0.500 * kSr), 2048, keyHz(57) * 0.8, keyHz(57) * 1.25);
    const double fB = acfHz(o.l, static_cast<size_t>(0.583 * kSr), 2048, keyHz(57) * 0.8, keyHz(57) * 1.25);   // half a period of 6 Hz later
    CHECK(std::fabs(cents(fA, fB)) > 40.0, "wheel vibrato: the pitch moves (%.0f cents between two moments)", cents(fA, fB));
    o = render(P, 57, 1.0, 0.9, 0.8F, 0.0F);
    const double gA = acfHz(o.l, static_cast<size_t>(0.500 * kSr), 2048, keyHz(57) * 0.8, keyHz(57) * 1.25), gB = acfHz(o.l, static_cast<size_t>(0.583 * kSr), 2048, keyHz(57) * 0.8, keyHz(57) * 1.25);
    CHECK(std::fabs(cents(gA, gB)) < 5.0, "no wheel: steady (%.1f cents)", cents(gA, gB));
    // drive: louder in but never above 1
    plain(P); P[SO_OUT_DRIVE] = 1.0F; P[E_DRIVE] = 1.0F; P[E_UNISON] = 4.0F; o = render(P, 45, 0.4, 0.3);
    CHECK(peakOf(o.l) <= 1.0 && peakOf(o.r) <= 1.0, "drive: the output never passes 1 (%.3f)", peakOf(o.l));
}

void testLegatoAndLoad() {
    std::printf("-- legato, the pitch follows the glide, no clicks, fuzz, CPU\n");
    // legato: the key changes while held - no new attack (the level does not dip), the pitch follows what the sampler gives
    plain(P); P[SO_AMP_A] = 150.0F;
    Out o = render(P, 57, 1.2, 1.1, 0.8F, 0.0F, 0.0F, 64, 0.5, 0.08);
    const double before = rmsOf(o.l, static_cast<size_t>(0.45 * kSr), static_cast<size_t>(0.49 * kSr)), during = rmsOf(o.l, static_cast<size_t>(0.52 * kSr), static_cast<size_t>(0.56 * kSr)), after = rmsOf(o.l, static_cast<size_t>(0.8 * kSr), static_cast<size_t>(0.9 * kSr));
    CHECK(during > 0.8 * before && after > 0.8 * before, "legato: no dip of the level (%.3f %.3f %.3f)", before, during, after);
    const double fAfter = acfHz(o.l, static_cast<size_t>(0.8 * kSr), 8192, keyHz(64) * 0.7, keyHz(64) * 1.4);
    CHECK(std::fabs(cents(fAfter, keyHz(64))) < 8.0, "legato: the new key sounds (%.1f cents)", cents(fAfter, keyHz(64)));
    // a knob moves while a note sounds: no click (the biggest sample-to-sample step stays small)
    {
        plain(P); P[E_FILT_TYPE] = FL_LADDER24; P[E_CUTOFF] = 1200.0F;
        Voice v; Inputs in; in.key = 45; in.gate = true; v.noteOn(P, kSr, in, 7U);
        double maxStep = 0.0; float prev = 0.0F;
        for (int i = 0; i < static_cast<int>(1.0 * kSr); ++i) {
            if (i == static_cast<int>(0.5 * kSr)) { P[SO_OSC1_LEVEL] = 0.2F; P[E_CUTOFF] = 4000.0F; P[SO_PW] = 0.2F; }
            if (i % 64 == 0) v.setInputs(in, kSr);
            float l, r; v.tick(keyHz(45) / kSr, l, r);
            if (i > static_cast<int>(0.4 * kSr)) maxStep = std::max(maxStep, static_cast<double>(std::fabs(l - prev)));
            prev = l;
        }
        CHECK(maxStep < 0.35, "knobs turned under a note: biggest step %.3f", maxStep);
    }
    // fuzz: random knobs never give NaN / Inf / runaway
    {
        std::uint32_t s = 99U;
        int bad = 0;
        for (int t = 0; t < 60; ++t) {
            setDefaults(P);
            for (int pg = 0; pg < kPages; ++pg) {
                const EngineParamPage page_ = page(pg);
                for (int i = 0; i < page_.count; ++i) {
                    s = s * 1664525U + 1013904223U;
                    const float x = static_cast<float>(s >> 8) / 16777216.0F;
                    const auto& d = page_.items[i];
                    P[d.id] = d.kind == EngineKind::Hz || d.kind == EngineKind::Ms ? d.lo * std::pow(d.hi / std::max(d.lo, 0.01F), x) : d.lo + (d.hi - d.lo) * x;
                }
            }
            const int key = 30 + static_cast<int>((s >> 12) % 70U);
            const Out f = render(P, key, 0.5, 0.3, 0.9F, 0.5F, 0.5F);
            if (!allFinite(f, 1.2)) ++bad;
        }
        CHECK(bad == 0, "fuzz: %d of 60 random sounds misbehaved", bad);
    }
    // CPU: 16 notes of the fattest sound (unison 4, ladder) on this machine
    {
        setDefaults(P); preset(7, P);   // МЕКА СТРУНА: unison 4
        std::vector<Voice> vs(16);
        for (int k = 0; k < 16; ++k) { Inputs in; in.key = 40 + k * 2; in.gate = true; vs[static_cast<std::size_t>(k)].noteOn(P, kSr, in, static_cast<std::uint32_t>(k + 1)); }
        const auto t0 = std::chrono::steady_clock::now();
        float acc = 0.0F;
        const int n = static_cast<int>(kSr);
        for (int i = 0; i < n; ++i) {
            for (int k = 0; k < 16; ++k) {
                if (i % 64 == 0) { Inputs in; in.key = 40 + k * 2; in.gate = true; vs[static_cast<std::size_t>(k)].setInputs(in, kSr); }
                float l, r; vs[static_cast<std::size_t>(k)].tick(keyHz(40 + k * 2) / kSr, l, r); acc += l + r;
            }
        }
        const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::printf("  16 notes x unison 4 + ladder: %.1f%% of real time (%.3f s for 1 s)%s\n", sec * 100.0, sec, acc == 12345.0F ? "!" : "");
        CHECK(sec < 0.9, "16 fat notes fit in real time on this machine (%.2f)", sec);
    }
}

}  // namespace

int main() {
    testDefs();
    testPitchAndWaves();
    testFilterEnvelopesUnison();
    testLegatoAndLoad();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
