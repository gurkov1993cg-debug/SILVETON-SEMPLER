// Regression tests for audible chorus and octave changes; uses rendered output.
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SoloPresets.h"
#include "SoloSource.h"
#include <array>
#include <cmath>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>
using namespace silveton::sampler;
namespace {
constexpr double pi=3.14159265358979323846;
void require(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
std::vector<float> pump(SamplerEngine& e,int seconds){
 std::vector<float>x(static_cast<std::size_t>(seconds)*96000);
 for(std::size_t n=0;n<x.size()/2;n+=96)e.render(x.data()+2*n,96);
 return x;
}
std::shared_ptr<EngineState> state(int profile,int octave){
 auto s=std::make_shared<EngineState>();solo::preset(s->combi.part(7),profile);
 s->combi.part(7).octave=static_cast<std::int8_t>(octave);s->combi.part(7).portaTime=0;
 s->global.limiterEnabled=false;return s;
}
std::vector<float> render(int profile,int key,int octave){
 SamplerEngine e;e.prepare(48000,128);e.setState(state(profile,octave));
 require(e.postNoteOn(0,static_cast<std::uint8_t>(key),100),"note on rejected");return pump(e,2);
}
double relativeDifference(const std::vector<float>& a,const std::vector<float>& b){
 double error=0,power=0;require(a.size()==b.size(),"length mismatch");
 for(std::size_t i=a.size()-48000;i<a.size();++i){const double d=a[i]-b[i];error+=d*d;power+=static_cast<double>(b[i])*b[i];}
 require(power>1e-8,"silent reference");return std::sqrt(error/power);
}
double component(const std::vector<float>& x,double hz){
 double a=0,b=0;const int end=static_cast<int>(x.size()/2),begin=end-48000;
 for(int n=begin;n<end;++n){const double value=(x[2*n]+x[2*n+1])*.5;
  a+=value*std::cos(2*pi*hz*n/48000);b+=value*std::sin(2*pi*hz*n/48000);}
 return 2*std::hypot(a,b)/48000;
}
void transpositionEquivalence(){
 double worst=0;
 for(int profile=0;profile<3;++profile)for(int octave=-4;octave<=4;++octave){
  const double error=relativeDifference(render(profile,69,octave),render(profile,69+12*octave,0));
  worst=std::max(worst,error);require(error<1e-5,"same sounding note changes timbre with OCTAVE");
 }
 std::cout<<"PASS three profiles, octave -4..+4 equivalent to keyboard: max relative error "<<worst<<'\n';
}
void heldOctave(){
 for(int profile=0;profile<3;++profile){
  SamplerEngine e;e.prepare(48000,128);auto s=state(profile,0);e.setState(s);e.postNoteOn(0,69,100);pump(e,2);
  for(int octave:{1,-1,0}){
   s=std::make_shared<EngineState>(*s);s->combi.part(7).octave=static_cast<std::int8_t>(octave);e.setState(s);
   const auto current=pump(e,3),reference=render(profile,69,octave);const double hz=440*std::exp2(octave);
   // Measure sub + harmonics, not only periodicity (which can mistake octaves).
   for(double factor:{.5,1.,2.,3.,4.,5.,6.}){
    const double expected=component(reference,hz*factor),actual=component(current,hz*factor);
    require(std::abs(expected-actual)<.00005,"held octave spectrum differs from a newly played target note");
   }
   if(octave==1)require(component(current,220)<1e-5,"held octave kept the old sub-octave pitch");
   if(octave==-1)require(component(current,220)>.001,"held octave did not reach the lower register");
  }
  e.postNoteOff(0,69);pump(e,1);require(e.activeVoiceCount()==0,"stuck voice after octave changes");
 }
 std::cout<<"PASS live octave +/-/return without re-pressing the key; spectral pitch checks and note off\n";
}
void phaseAndStereo(){
 for(double rate:{44100.,48000.,96000.})for(float width:{0.F,.7F,1.F}){
  std::array<float,kEngineParamCount>p{};solo::factory(1,p.data());p[solo::MorphY]=width;
  // Freeze expressive colour: the held tone must repeat, including its sub-octave.
  p[solo::Air]=p[solo::Response]=0;solo::Source v;v.prepare(rate,67,1);
  const double hz=rate/128.;std::vector<double>x(static_cast<std::size_t>(rate)*3),right(x.size());
  for(std::size_t n=0;n<x.size();++n){if(n%64==0)v.controls(p.data(),hz,0,0);x[n]=v.tick(hz);right[n]=v.right();}
  double error=0,power=0;
  for(std::size_t n=static_cast<std::size_t>(rate)*2;n<x.size();++n){
   const double dl=x[n]-x[n-256],dr=right[n]-right[n-256];error+=dl*dl+dr*dr;power+=x[n]*x[n]+right[n]*right[n];}
  const double relative=std::sqrt(error/power);require(relative<1e-6,"uncommanded detune/chorus in steady tone");
 }
 // Width changes stereo distribution, while its mono sum is unchanged even during edits.
 solo::Source mono,wide;mono.prepare(48000,69,1);wide.prepare(48000,69,1);
 std::array<float,kEngineParamCount>p{};solo::defaults(p.data());auto q=p;double maxError=0,sideEnergy=0;
 for(int n=0;n<144000;++n){if(n%64==0){q[solo::MorphY]=(n/16000)%2?1.F:0.F;mono.controls(p.data(),440,0,0);wide.controls(q.data(),440,0,0);}
  double a=mono.tick(440),b=wide.tick(440),r=wide.right();maxError=std::max(maxError,std::abs(a-.5*(b+r)));sideEnergy+=(b-r)*(b-r);}
 require(maxError<1e-12&&sideEnergy>.01,"stereo changes mono timbre or width is inactive");
 std::cout<<"PASS no uncommanded beating at 44.1/48/96 kHz, static stereo and mono compatibility\n";
}
}
int main(){int failed=0;for(auto test:{transpositionEquivalence,heldOctave,phaseAndStereo}){
 try{test();}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';++failed;}}
 return failed?1:0;
}
