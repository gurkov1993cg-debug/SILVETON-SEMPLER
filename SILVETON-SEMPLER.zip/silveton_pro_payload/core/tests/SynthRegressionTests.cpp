// Focused regressions for teacher tracks above the rendered harmonic limit and
// the active SYNTH filter choices. Also run with -D_GLIBCXX_ASSERTIONS so the
// real H64 fixture detects a cache read beyond std::array<float, 48>.
#include "SynthVoice.h"
#include "ModelFixtures.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <vector>

using namespace silveton::sampler;

namespace {
int checks = 0, failures = 0;
#define CHECK(condition, ...) do { ++checks; if (!(condition)) { ++failures; std::printf("FAIL %d: ", __LINE__); std::printf(__VA_ARGS__); std::printf("\n"); } } while (false)
constexpr double kRate = 96000.0;
constexpr double kTwoPi = 6.283185307179586;
using Params = std::array<float, kEngineParamCountLegacy>;

Params parameters(int type = 0) {
    Params p{}; synth::setDefaults(p.data());
    p[synth::SY_LIFE] = p[synth::SY_VIBRATO] = p[synth::SY_SCOOP] = p[synth::SY_UNISON] = 0.0F;
    p[E_FILT_TYPE] = static_cast<float>(type);
    p[E_CUTOFF] = 1000.0F; p[E_RESO] = 0.55F; p[E_DRIVE] = 0.2F;
    return p;
}

model::ZoneShape steadyZone(int harmonics) {
    model::ZoneShape z;
    z.ok = true; z.f0Hz = 200.0F; z.trackH = harmonics;
    z.attackRows = 60; z.trackRows = z.attackRows + 32; z.looped = true;
    for (int row = 0; row < z.trackRows; ++row) {
        for (int h = 1; h <= harmonics; ++h) {
            z.harmTrack.push_back(static_cast<std::uint8_t>(std::lround(12.0 * std::log2(static_cast<double>(h)))));
        }
    }
    for (int h = 0; h < model::kHarmonics; ++h) z.peakDb[h] = h < harmonics ? static_cast<float>(-6.0 * std::log2(h + 1.0)) : -200.0F;
    return z;
}

model::ZoneShape firstHarmonics(const model::ZoneShape& z, int count) {
    model::ZoneShape out = z;
    out.trackH = count; out.harmTrack.clear();
    for (int row = 0; row < z.trackRows; ++row) {
        const auto first = z.harmTrack.begin() + static_cast<std::ptrdiff_t>(row * z.trackH);
        out.harmTrack.insert(out.harmTrack.end(), first, first + count);
    }
    return out;
}

std::vector<float> render(const model::ZoneShape& zone, const Params& p, int samples = 16384, double rate = kRate, double hz = 200.0) {
    synth::Voice v; model::Inputs in;
    in.key = 60; in.gate = true; in.velocity = 0.8F;
    v.noteOn(p.data(), rate, in, &zone, 11U);
    std::vector<float> result(static_cast<std::size_t>(samples));
    bool finite = true, mono = true;
    for (float& x : result) {
        float r = 0.0F; v.tick(hz / rate, x, r);
        finite = finite && std::isfinite(x) && std::isfinite(r);
        mono = mono && x == r;
    }
    CHECK(finite && mono, "render is finite and mono: H%d type %.0f rate %.0f", zone.trackH, p[E_FILT_TYPE], rate);
    CHECK(v.harmonicsNow() <= synth::kMaxH, "at most 48 harmonics rendered (got %d)", v.harmonicsNow());
    return result;
}

void harmonicBounds() {
    const auto bank = model::fixtureLearnedModels();
    CHECK(bank && bank->error.empty() && !bank->models.empty(), "real model fixture loads");
    if (!bank || !bank->error.empty() || bank->models.empty()) return;
    const auto& first = bank->models.front();
    const int zi = first.zoneFor(60);
    CHECK(zi >= 0, "real model has middle-C zone");
    if (zi < 0) return;
    const auto& real = first.zones[static_cast<std::size_t>(zi)];
    CHECK(real.trackH == 64 && !real.fullTrack, "real H64 legacy fixture exercises the formerly invalid neighbour read");
    std::printf("Real H64 fixture: %s, attack rows %d\n", first.name.c_str(), real.attackRows);
    const auto p = parameters();
    const auto actual = render(real, p, 65536, kRate, 110.0);
    const auto trimmed = render(firstHarmonics(real, 48), p, 65536, kRate, 110.0);
    CHECK(actual == trimmed, "discarded harmonics 49..64 never affect the rendered 48, including the steady rows");
    for (int h : {1, 48, 49, 64}) {
        auto z = steadyZone(h);
        for (bool full : {false, true}) {
            z.fullTrack = full;
            const auto x = render(z, p, 2048, kRate, 110.0);
            if (h > 48) CHECK(x == render(firstHarmonics(z, 48), p, 2048, kRate, 110.0), "H%d full=%d matches its first 48 harmonics", h, full ? 1 : 0);
        }
    }
}

double relativeResidual(const std::vector<float>& a, const std::vector<float>& b) {
    double aa = 0.0, ab = 0.0, bb = 0.0;
    for (std::size_t i = 4096; i < a.size(); ++i) { aa += static_cast<double>(a[i]) * a[i]; ab += static_cast<double>(a[i]) * b[i]; bb += static_cast<double>(b[i]) * b[i]; }
    if (aa <= 0.0 || bb <= 0.0) return 0.0;
    const double gain = ab / aa;
    double error = 0.0;
    for (std::size_t i = 4096; i < a.size(); ++i) { const double d = b[i] - gain * a[i]; error += d * d; }
    return std::sqrt(error / bb);
}

double korgToneGain(double hz) {
    model::Korg35 filter;
    constexpr double rate = kRate * 4.0;
    filter.set(1000.0F, 0.0F, rate);
    double input = 0.0, output = 0.0;
    for (int i = 0; i < 38400; ++i) {
        const float x = static_cast<float>(0.001 * std::sin(kTwoPi * hz * i / rate));
        const float y = filter.run(x);
        if (i >= 19200) { input += static_cast<double>(x) * x; output += static_cast<double>(y) * y; }
    }
    return std::sqrt(output / input);
}

void distinctFilters() {
    const auto z = steadyZone(48);
    const auto ladder = render(z, parameters(1), 32768);
    const auto korg = render(z, parameters(2), 32768);
    const double residual = relativeResidual(ladder, korg);
    std::printf("LADDER24/KORG35 residual after best scalar gain: %.9f\n", residual);
    CHECK(residual > 0.1, "KORG35 changes the transfer function, not just level (residual %.9f)", residual);
    const double pass = korgToneGain(500.0), low = korgToneGain(2000.0), high = korgToneGain(8000.0);
    const double fallDb = 20.0 * std::log10(low / high);
    std::printf("KORG35 low-level gain at 500 Hz %.6f; 2..8 kHz attenuation %.3f dB\n", pass, fallDb);
    CHECK(pass > 0.7 && pass < 0.9 && fallDb > 18.0 && fallDb < 30.0, "KORG35 is the two-pole low-pass topology, not the four-pole ladder");
}

void liveTypeChanges() {
    const auto z = steadyZone(48);
    // Changes land exactly on a control boundary after the note's pre-roll.
    constexpr int change = 8192 + (synth::kChunk - synth::dsp::kPreRoll % synth::kChunk) % synth::kChunk;
    double worstEarly = 0.0;
    for (int from = 1; from <= 5; ++from) for (int to = 1; to <= 5; ++to) {
        if (from == to) continue;
        auto before = parameters(from), after = before;
        synth::Voice stable, changing; model::Inputs in;
        stable.noteOn(before.data(), kRate, in, &z, 11U);
        changing.noteOn(after.data(), kRate, in, &z, 11U);
        bool firstSame = true, finite = true;
        double early = 0.0, peak = 0.0;
        for (int i = 0; i < change + 512; ++i) {
            if (i == change) after[E_FILT_TYPE] = static_cast<float>(to);
            float a = 0.0F, b = 0.0F, r = 0.0F;
            stable.tick(200.0 / kRate, a, r); changing.tick(200.0 / kRate, b, r);
            finite = finite && std::isfinite(a) && std::isfinite(b);
            peak = std::max(peak, std::fabs(static_cast<double>(a)));
            if (i == change) firstSame = a == b;
            if (i >= change && i < change + 16) early = std::max(early, std::fabs(static_cast<double>(a) - b));
        }
        worstEarly = std::max(worstEarly, early / std::max(peak, 1e-12));
        CHECK(finite && firstSame && early < peak * 0.003 + 1e-7, "type %d -> %d keeps outgoing continuity (early %.9g, peak %.9g)", from, to, early, peak);
    }
    std::printf("Worst first-16-sample type-change error / outgoing peak: %.9f\n", worstEarly);

    // Revisiting KORG35 must not resurrect integrators from its previous visit.
    // Once the crossfade ends, only the fresh incoming path can affect output.
    for (int middle : {0, 1, 3, 4, 5}) {
        auto history = parameters(2), fresh = parameters(middle);
        history[E_CUTOFF] = fresh[E_CUTOFF] = 200.0F;
        history[E_RESO] = fresh[E_RESO] = 0.85F;
        synth::Voice a, b; model::Inputs in;
        a.noteOn(history.data(), kRate, in, &z, 11U);
        b.noteOn(fresh.data(), kRate, in, &z, 11U);
        double maxAfter = 0.0;
        for (int i = 0; i < 20480; ++i) {
            if (i == 8192) history[E_FILT_TYPE] = static_cast<float>(middle);
            if (i == 16384) history[E_FILT_TYPE] = fresh[E_FILT_TYPE] = 2.0F;
            float x = 0.0F, y = 0.0F, r = 0.0F;
            a.tick(200.0 / kRate, x, r); b.tick(200.0 / kRate, y, r);
            if (i >= 16896) maxAfter = std::max(maxAfter, std::fabs(static_cast<double>(x) - y));
        }
        CHECK(maxAfter < 2e-6, "return to KORG35 via %d has no stale filter state (difference %.9g)", middle, maxAfter);
    }
    // Faster requests are coalesced without resetting a crossfade in progress;
    // after requests stop, the most recently requested mode must win.
    auto rapid = parameters(1), wanted = parameters(2);
    synth::Voice a, b; model::Inputs in;
    a.noteOn(rapid.data(), kRate, in, &z, 11U); b.noteOn(wanted.data(), kRate, in, &z, 11U);
    bool finite = true; double settled = 0.0;
    for (int i = 0; i < 32768; ++i) {
        if (i >= 2048 && i < 8192 && i % 64 == 0) rapid[E_FILT_TYPE] = static_cast<float>((i / 64) % 6);
        if (i == 8192) rapid[E_FILT_TYPE] = 2.0F;
        float x = 0.0F, y = 0.0F, r = 0.0F;
        a.tick(200.0 / kRate, x, r); b.tick(200.0 / kRate, y, r);
        finite = finite && std::isfinite(x) && std::isfinite(y);
        if (i >= 30000) settled = std::max(settled, std::fabs(static_cast<double>(x) - y));
    }
    CHECK(finite && settled < 2e-6, "rapid requests settle to the latest type (difference %.9g)", settled);
}

void korgExtremes() {
    const auto z = steadyZone(48);
    for (double rate : {44100.0, 48000.0, 96000.0, 192000.0}) {
        for (float cut : {20.0F, 20000.0F}) for (float res : {0.0F, 1.0F}) for (float drive : {0.0F, 1.0F}) {
            auto p = parameters(2); p[E_CUTOFF] = cut; p[E_RESO] = res; p[E_DRIVE] = drive;
            const auto x = render(z, p, 8192, rate, 110.0);
            float peak = 0.0F; for (float sample : x) peak = std::max(peak, std::fabs(sample));
            CHECK(peak < 32.0F, "KORG35 extrema remain bounded: rate %.0f cut %.0f res %.0f drive %.0f peak %.6f", rate, cut, res, drive, peak);
        }
    }
}
}  // namespace

int main() {
    harmonicBounds(); distinctFilters(); liveTypeChanges(); korgExtremes();
    std::printf("Synth regression: %d checks, %d failures\n", checks, failures);
    return failures == 0 ? 0 : 1;
}
