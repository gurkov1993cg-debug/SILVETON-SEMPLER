// SILVETON_VELOCITY_V1: the curves, compress / expand, velocity -> attack and the crossfade of one sound of an Upper
// (pure functions + the real engine + the SET file).
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/VelocityShape.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <functional>
#include <iostream>
#include <memory>
#include <vector>

using namespace silveton::sampler;

namespace {

int failures = 0;
#define CHECK(cond) do { if (!(cond)) { std::cerr << "FAILED " << __FILE__ << ":" << __LINE__ << "  " #cond "\n"; ++failures; } } while (0)

// Plays key 69 at `velocity` on Upper 1 and adds up what comes out (|x|) in the first `frames` frames.
float measure(const std::function<void(UpperPart&)>& setup, std::uint8_t velocity, std::uint32_t frames = 128U) {
    auto state = std::make_shared<EngineState>();
    auto& upper = state->combi.uppers[0];
    upper.enabled = true;
    upper.midiChannel = 0U;
    upper.program = builtinWaveProgram(4);
    setup(upper);
    SamplerEngine e;
    e.prepare(48000.0, 128U);
    e.setState(state);
    e.postNoteOn(0U, 69U, velocity);
    std::vector<float> out(static_cast<std::size_t>(frames) * 2U, 0.0F);
    e.render(out.data(), frames);
    float sum = 0.0F;
    for (const float x : out) sum += std::abs(x);
    return sum;
}

void pureFunctions() {
    // the default shape gives the input back, bit for bit
    const VelocityShape def{};
    CHECK(def.isDefault());
    for (int v = 0; v <= 127; ++v) {
        const float x = static_cast<float>(v) * (1.0F / 127.0F);
        CHECK(velocityShaped(def, x) == x);
    }
    // every ready curve: 0 -> 0, 1 -> 1, never goes down
    for (std::uint8_t c = 0U; c < 6U; ++c) {
        VelocityShape s; s.curve = c;
        CHECK(std::abs(velocityShaped(s, 0.0F)) < 1.0e-5F);
        CHECK(std::abs(velocityShaped(s, 1.0F) - 1.0F) < 1.0e-5F);
        float last = -1.0F;
        for (int v = 0; v <= 127; ++v) {
            const float y = velocityShaped(s, static_cast<float>(v) * (1.0F / 127.0F));
            CHECK(y >= last - 1.0e-6F);
            CHECK(y >= 0.0F && y <= 1.0F);
            last = y;
        }
    }
    // the character of each curve in the middle
    VelocityShape soft, hard, expo, logc, sc;
    soft.curve = 1U; hard.curve = 2U; expo.curve = 3U; logc.curve = 4U; sc.curve = 5U;
    CHECK(velocityShaped(soft, 0.5F) > 0.5F);
    CHECK(velocityShaped(hard, 0.5F) < 0.5F);
    CHECK(velocityShaped(expo, 0.5F) < velocityShaped(hard, 0.5F));
    CHECK(velocityShaped(logc, 0.5F) > velocityShaped(soft, 0.5F));
    CHECK(std::abs(velocityShaped(sc, 0.5F) - 0.5F) < 1.0e-5F);
    CHECK(velocityShaped(sc, 0.2F) < 0.2F && velocityShaped(sc, 0.8F) > 0.8F);
    // CUSTOM: the default points are a straight line; a drawn point bends it
    VelocityShape custom; custom.curve = 6U;
    for (int v = 0; v <= 127; v += 7) {
        const float x = static_cast<float>(v) * (1.0F / 127.0F);
        CHECK(std::abs(velocityShaped(custom, x) - x) < 0.01F);
    }
    custom.custom[4] = 100U;   // the middle (input 0.5)
    CHECK(std::abs(velocityShaped(custom, 0.5F) - 100.0F / 127.0F) < 1.0e-5F);
    CHECK(velocityShaped(custom, 0.25F) > 0.25F);
    // compress: everything goes to the middle; expand: it gets steeper and is cut at the ends
    VelocityShape comp; comp.compress = 1.0F;
    CHECK(std::abs(velocityShaped(comp, 0.0F) - 0.5F) < 1.0e-5F && std::abs(velocityShaped(comp, 1.0F) - 0.5F) < 1.0e-5F);
    comp.compress = 0.5F;
    CHECK(velocityShaped(comp, 0.0F) > 0.2F && velocityShaped(comp, 1.0F) < 0.8F);
    VelocityShape expand; expand.compress = -1.0F;
    CHECK(velocityShaped(expand, 0.25F) < 0.1F && velocityShaped(expand, 0.75F) > 0.9F);
    CHECK(std::abs(velocityShaped(expand, 0.5F) - 0.5F) < 1.0e-5F);
    // velocity -> attack: nothing at the hardest, the full time at the softest
    VelocityShape att; att.toAttack = 1.0F;
    CHECK(velocityAttackExtraMs(att, 1.0F) == 0.0F);
    CHECK(std::abs(velocityAttackExtraMs(att, 0.0F) - kVelocityAttackMaxMs) < 1.0e-3F);
    att.toAttack = 0.5F;
    CHECK(std::abs(velocityAttackExtraMs(att, 0.5F) - 0.25F * kVelocityAttackMaxMs) < 1.0e-3F);
    CHECK(velocityAttackExtraMs(VelocityShape{}, 0.0F) == 0.0F);
    // the fade: range 60..80, 20 steps in at the bottom, 20 out at the top
    CHECK(velocityFadeGain(60, 80, 0, 0, 70) == 1.0F);
    CHECK(std::abs(velocityFadeGain(60, 127, 20, 0, 70) - 11.0F / 20.0F) < 1.0e-6F);
    CHECK(std::abs(velocityFadeGain(1, 80, 0, 20, 70) - 11.0F / 20.0F) < 1.0e-6F);
    CHECK(velocityFadeGain(60, 127, 20, 0, 90) == 1.0F);
}

void engine() {
    const auto none = [](UpperPart&) {};
    const float linear = measure(none, 40U);
    CHECK(linear > 0.001F);
    // a SOFT curve is louder, a HARD one is quieter, with the same key press
    const float soft = measure([](UpperPart& u) { u.velocityShape.curve = 1U; }, 40U);
    const float hard = measure([](UpperPart& u) { u.velocityShape.curve = 2U; }, 40U);
    CHECK(soft > linear * 1.3F);
    CHECK(hard < linear * 0.7F);
    // nothing set = exactly what it was
    const float again = measure([](UpperPart& u) { u.velocityShape = VelocityShape{}; }, 40U);
    CHECK(again == linear);
    // CUSTOM that is a straight line is (nearly) the same as LINEAR
    const float line = measure([](UpperPart& u) { u.velocityShape.curve = 6U; }, 40U);
    CHECK(std::abs(line - linear) < linear * 0.02F);
    // compress 1 = every key press plays the same (the middle)
    const float c40 = measure([](UpperPart& u) { u.velocityShape.compress = 1.0F; }, 40U);
    const float c120 = measure([](UpperPart& u) { u.velocityShape.compress = 1.0F; }, 120U);
    CHECK(std::abs(c40 - c120) < c40 * 0.01F);
    // velocity -> attack: a soft note starts later
    const float quickStart = measure(none, 20U);
    const float slowStart = measure([](UpperPart& u) { u.velocityShape.toAttack = 1.0F; }, 20U);
    CHECK(slowStart < quickStart * 0.3F);
    const float hardNote = measure(none, 127U);
    const float hardNoteAttack = measure([](UpperPart& u) { u.velocityShape.toAttack = 1.0F; }, 127U);
    CHECK(std::abs(hardNote - hardNoteAttack) < hardNote * 1.0e-4F);

    // CROSSFADE: ОСНОВЕН 1..80 goes out over 20, L1 60..127 comes in over 20; at 70 both are at 11/20
    const auto twoSounds = [](bool crossfade) {
        return [crossfade](UpperPart& u) {
            u.velocityLow = 1U; u.velocityHigh = 80U; u.velocityFadeOut = 20U; u.velocityShape.crossfade = crossfade;
            auto& l = u.layers[0];
            l.enabled = true; l.program = builtinWaveProgram(4);
            l.velocityLow = 60U; l.velocityHigh = 127U; l.velocityFadeIn = 20U; l.velocityShape.crossfade = crossfade;
        };
    };
    const float summed = measure(twoSounds(false), 70U);
    const float crossed = measure(twoSounds(true), 70U);
    CHECK(std::abs(crossed / summed - 1.0F / 1.1F) < 0.01F);
    // a sound that plays alone keeps its own fade (only an overlap above 1 is brought back)
    const auto alone = [](bool crossfade) {
        return [crossfade](UpperPart& u) { u.velocityLow = 1U; u.velocityHigh = 80U; u.velocityFadeOut = 20U; u.velocityShape.crossfade = crossfade; };
    };
    CHECK(measure(alone(false), 70U) == measure(alone(true), 70U));
    // where the overlap does not add up above 1 nothing changes
    CHECK(std::abs(measure(twoSounds(true), 30U) - measure(twoSounds(false), 30U)) < 1.0e-6F);
}

void setFile() {
    SetData data; data.name = "Velocity shape";
    CombiSlot cs; cs.address = {1, 1, 1}; cs.combi.name = "VEL";
    auto& u = cs.combi.uppers[0];
    u.velocityShape.curve = 6U; u.velocityShape.custom = {{0, 9, 40, 50, 64, 90, 100, 120, 127}};
    u.velocityShape.compress = -0.4F; u.velocityShape.toAttack = 0.35F; u.velocityShape.crossfade = true;
    auto& l = u.layers[3];
    l.velocityShape.curve = 3U; l.velocityShape.compress = 0.6F; l.velocityShape.toAttack = 1.0F;
    data.combis.push_back(cs);
    const auto s = SetPackage::save("/tmp/silveton_velocity_shape_smoke.svset", data);
    if (!s.success) { std::cerr << s.error << "\n"; ++failures; return; }
    const auto r = SetPackage::load("/tmp/silveton_velocity_shape_smoke.svset");
    if (!r.ok()) { std::cerr << r.error << "\n"; ++failures; return; }
    const auto& o = r.data.combis.front().combi.uppers[0];
    CHECK(o.velocityShape == u.velocityShape);
    CHECK(o.layers[3].velocityShape == l.velocityShape);
    CHECK(o.layers[0].velocityShape == VelocityShape{});
    CHECK(r.data.combis.front().combi.uppers[1].velocityShape == VelocityShape{});
}

} // namespace

int main() {
    pureFunctions();
    engine();
    setFile();
    if (failures != 0) { std::cerr << failures << " checks failed\n"; return 1; }
    std::cout << "PASS velocity shape (curves, compress, attack, crossfade, SET v17)\n";
    return 0;
}
