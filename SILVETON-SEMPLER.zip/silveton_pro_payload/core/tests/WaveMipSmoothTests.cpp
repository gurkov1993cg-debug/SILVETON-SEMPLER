#include "../src/sampler/WaveMipBlend.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>

int main() {
    constexpr int N = 1024, Levels = 10;
    // Level selection and the no-alias rule at both sides of each border.
    for (int lvl = 0; lvl < Levels - 1; ++lvl) {
        const int h = (N / 2) >> lvl;
        const double border = 0.45 / static_cast<double>(h);
        const auto a = eng::waveMipChoice(std::nextafter(border, 0.0), N, Levels);
        const auto b = eng::waveMipChoice(border, N, Levels);
        const auto c = eng::waveMipChoice(std::nextafter(border, 1.0), N, Levels);
        assert(a.level == lvl && b.level == lvl && c.level == lvl + 1);
        assert(a.highWeight >= 0.0F && a.highWeight < 1.0e-4F);
        assert(b.highWeight == 0.0F);
        assert(c.highWeight >= 0.0F && c.highWeight <= 1.0F);
        const double maxH = 0.45 / border;
        assert(static_cast<double>(h) <= maxH + 1.0e-9);
    }
    // A richer wavetable containing extra harmonics MUST have exactly the same
    // output at the mip border as the lower table, even at arbitrary phases.
    std::array<float, N + 1> high{}, low{};
    constexpr double pi = 3.1415926535897932384626433832795;
    for (int i = 0; i < N; ++i) {
        const double p = 2.0 * pi * static_cast<double>(i) / N;
        low[i] = static_cast<float>(std::sin(p));
        high[i] = static_cast<float>(std::sin(p) + 0.4 * std::sin(27.0 * p));
    }
    low[N] = low[0]; high[N] = high[0];
    for (int lvl = 0; lvl < Levels - 1; ++lvl) {
        const double border = 0.45 / static_cast<double>((N / 2) >> lvl);
        const float before = eng::waveMipChoice(border * (1.0 - 1.0e-6), N, Levels).highWeight;
        const auto after = eng::waveMipChoice(border * (1.0 + 1.0e-6), N, Levels);
        assert(after.level == lvl + 1);
        for (int i = 0; i < 256; ++i) {
            const double phase = (static_cast<double>(i) + 0.37) / 256.0;
            const float hi = eng::waveMipRead(high.data(), low.data(), phase, before, N);
            // On the lower side of the boundary the formerly lower table
            // becomes the active table (not the previous high table).
            const float lo = eng::waveMipCubic(low.data(), phase, N);
            assert(std::isfinite(hi) && std::isfinite(lo));
            assert(std::fabs(hi - lo) < 1.0e-4F);
        }
    }
    // With the second lookup disabled, the output remains bit-identical to the
    // legacy cubic interpolation; no change to sustained steady-pitch notes.
    for (int i = 0; i < 1000; ++i) {
        const double ph = static_cast<double>(i) * 0.001213;
        assert(eng::waveMipRead(high.data(), low.data(), ph, 1.0F, N)
               == eng::waveMipCubic(high.data(), ph, N));
    }
    std::puts("PASS: wavetable mip crossover continuity, harmonic guard and legacy unity");
}
