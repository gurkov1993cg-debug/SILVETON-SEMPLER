#pragma once
// TEST DATA ONLY (SILVETON_MODELS_FROM_FILE_V1): the 11 learned sounds the sampler used to carry inside, kept for the checks.
#include "silveton/sampler/ModelBank.h"

#include <cstdint>
#include <memory>
#include <vector>

namespace silveton::sampler::model {
[[nodiscard]] std::shared_ptr<const LearnedModels> fixtureLearnedModels();   // the 11 sounds, parsed (MODEL 1 = Radi Pa5x Sound)
[[nodiscard]] std::vector<std::uint8_t> fixtureModelFileBytes();             // the same 11 sounds as one SILVETON_OSC.sv (SVOSC003)
}  // namespace silveton::sampler::model
