#!/usr/bin/env python3
"""Offline diagnostic comparison; requires NumPy, not used by the application.
Render both revisions with MonoQualityRender.cpp into separate directories.
Usage: python3 AnalyzeMonoQuality.py OLD_DIRECTORY NEW_DIRECTORY REPORT_JSON
"""
import json
import sys
from pathlib import Path
import numpy as np

old_dir, new_dir, report_path = map(Path, sys.argv[1:4])
measurements = []
for path in sorted(new_dir.glob('*.f32')):
    old = np.fromfile(old_dir / path.name, np.float32).astype(float)
    new = np.fromfile(path, np.float32).astype(float)
    sample_rate = int(path.stem.split('_')[-1])
    case = path.stem.rsplit('_', 1)[0]
    assert old.shape == new.shape == (sample_rate,)
    assert np.all(np.isfinite(new))
    row = dict(case=case, sample_rate=sample_rate,
               old_rms=float(np.sqrt(np.mean(old * old))),
               new_rms=float(np.sqrt(np.mean(new * new))))
    if case in ('legacy', 'glide'):
        row['maximum_sample_difference'] = float(np.max(abs(old - new)))
    else:
        fundamental = 997 if case in ('sync', 'sine') else 3001
        mask = np.ones(sample_rate // 2 + 1, dtype=bool)
        mask[:3] = False
        for harmonic in range(fundamental, sample_rate // 2 + 1, fundamental):
            mask[max(0, harmonic - 2):harmonic + 3] = False

        def residual(samples):
            spectrum = abs(np.fft.rfft(samples * np.hanning(sample_rate))) ** 2
            return float(10 * np.log10(spectrum[mask].sum() / spectrum[~mask].sum()))

        before, after = residual(old), residual(new)
        row.update(fundamental_hz=fundamental, old_inharmonic_db=before,
                   new_inharmonic_db=after, reduction_db=before - after)
    measurements.append(row)
assert len(measurements) == 24
report = dict(
    method='One-second float32 tone after two-second settling; Hann FFT; exclude DC and +/-2 bins around expected harmonics.',
    interpretation='Inharmonic-to-harmonic power ratio is an aliasing proxy for these periodic diagnostic tones. This is not an all-preset, all-setting guarantee or a listening score.',
    measurements=measurements)
report_path.write_text(json.dumps(report, indent=2) + '\n')
for row in measurements:
    if row['sample_rate'] == 48000 and 'reduction_db' in row:
        print('{}: {:.2f} -> {:.2f} dB, reduction {:.2f} dB'.format(row['case'], row['old_inharmonic_db'], row['new_inharmonic_db'], row['reduction_db']))
