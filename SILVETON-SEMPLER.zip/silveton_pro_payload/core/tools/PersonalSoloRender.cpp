// Offline audition through the SAME SamplerEngine used by the native Mac host.
// Same single SOLO source as the native host. No input PCM/model files.
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SoloPresets.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace silveton::sampler;
namespace {
constexpr double sr = 48000;
constexpr double beat = 60.0 / 165;
struct Note { int key; double beats; };
const Note phrase[] = {
    {62,.75},{63,.125},{62,.125},{66,.5},{67,.5},{66,.5},{63,.5},{62,1},
    {69,.5},{70,.125},{69,.125},{67,.25},{66,.5},{67,.5},{69,1},{74,1},
    {74,.5},{75,.125},{74,.125},{72,.25},{70,.5},{69,.5},{67,.5},{66,.5},{63,1},
    {62,.5},{66,.5},{63,.25},{62,.25},{60,.5},{62,2}
};
struct Event { int frame; int key; int velocity; };
std::vector<float> render(const Combi& combi) {
    auto state = std::make_shared<EngineState>(); state->combi = combi;
    state->global.masterGainDb = -6; state->global.limiterEnabled = false;
    SamplerEngine e; e.prepare(sr,128); e.setState(state);
    std::vector<Event> events; double time = .15;
    for (std::size_t i=0;i<sizeof(phrase)/sizeof(phrase[0]);++i) {
        const auto note = phrase[i]; const double end = time+note.beats*beat;
        events.push_back({static_cast<int>(std::lround(time*sr)),note.key, i%8==0?116:104});
        const bool sameNext = i+1<sizeof(phrase)/sizeof(phrase[0]) && phrase[i+1].key==note.key;
        // A short overlap produces legato; phrase boundaries rearticulate.
        const double overlap = sameNext || i==7 || i==15 || i==24 ? -.025 : .012;
        events.push_back({static_cast<int>(std::lround((end+overlap)*sr)),note.key,0});
        time = end;
    }
    std::stable_sort(events.begin(),events.end(),[](const Event& a,const Event& b){return a.frame<b.frame;});
    const int total = static_cast<int>((time+1.3)*sr);
    std::vector<float> out(static_cast<std::size_t>(total)*2);
    std::size_t next=0; int at=0;
    while(at<total) {
        while(next<events.size() && events[next].frame==at) {
            const auto ev=events[next++];
            const bool ok=ev.velocity ? e.postNoteOn(0,static_cast<std::uint8_t>(ev.key),static_cast<std::uint8_t>(ev.velocity))
                                     : e.postNoteOff(0,static_cast<std::uint8_t>(ev.key));
            if(!ok) throw std::runtime_error("MIDI event queue rejected a note");
        }
        const int until = next<events.size()?events[next].frame:total;
        const int frames = std::min({128,total-at,until-at});
        if(frames<=0) throw std::runtime_error("event schedule error");
        e.render(out.data()+2*at,static_cast<std::uint32_t>(frames)); at+=frames;
    }
    if(e.activeVoiceCount()!=0) throw std::runtime_error("stuck voice at end of phrase");
    return out;
}
void u16(std::ostream& f,std::uint16_t v) { f.put(static_cast<char>(v&255)); f.put(static_cast<char>(v>>8)); }
void u32(std::ostream& f,std::uint32_t v) { u16(f,static_cast<std::uint16_t>(v&65535)); u16(f,static_cast<std::uint16_t>(v>>16)); }
void wav(const std::string& path,const std::vector<float>& samples) {
    double peak=0,energy=0;
    for(float x:samples) { if(!std::isfinite(x))throw std::runtime_error("nonfinite audio"); peak=std::max(peak,std::abs(static_cast<double>(x))); energy+=x*x; }
    const double rms=std::sqrt(energy/static_cast<double>(samples.size()));
    if(rms<.0001 || peak<.001)throw std::runtime_error("silent demo");
    // One constant export gain for both dry and wet sections. No compressor.
    const double gain=std::min(std::pow(10.0,-19.0/20)/rms,std::pow(10.0,-1.0/20)/peak);
    std::ofstream f(path,std::ios::binary); if(!f)throw std::runtime_error("cannot open WAV");
    const auto bytes=static_cast<std::uint32_t>(samples.size()*2);
    f.write("RIFF",4); u32(f,36+bytes); f.write("WAVEfmt ",8); u32(f,16); u16(f,1); u16(f,2);
    u32(f,48000); u32(f,192000); u16(f,4); u16(f,16); f.write("data",4); u32(f,bytes);
    for(float x:samples) { const auto value=static_cast<std::int16_t>(std::lround(x*gain*32767)); u16(f,static_cast<std::uint16_t>(value)); }
    if(!f)throw std::runtime_error("WAV write failed");
    std::cout<<path<<": "<<samples.size()/2/sr<<" s, peak "<<20*std::log10(peak*gain)<<" dBFS, RMS "<<20*std::log10(rms*gain)<<" dBFS\n";
}
}
std::vector<float> held(const Combi& c,int key,double before,double duration,double total){
 auto st=std::make_shared<EngineState>();st->combi=c;st->global.limiterEnabled=false;st->global.masterGainDb=-6;
 SamplerEngine e;e.prepare(sr,128);e.setState(st);std::vector<float> out(static_cast<std::size_t>(total*sr)*2);
 const int on=static_cast<int>(before*sr),off=static_cast<int>((before+duration)*sr),end=static_cast<int>(out.size()/2);
 for(int at=0;at<end;){if(at==on)e.postNoteOn(0,static_cast<std::uint8_t>(key),100);if(at==off)e.postNoteOff(0,static_cast<std::uint8_t>(key));
  int n=std::min(128,end-at);if(at<on)n=std::min(n,on-at);if(at<off)n=std::min(n,off-at);e.render(out.data()+2*at,static_cast<std::uint32_t>(n));at+=n;}
 if(e.activeVoiceCount()!=0)throw std::runtime_error("stuck held-note render");
 return out;
}
int main(int argc,char** argv){try{
 if(argc!=3)throw std::runtime_error("usage: personal_solo_render AUDIO_DIR SET_PATH");
 SetData data;data.name="SILVETON SOLO";SetList list;list.name=data.name;std::vector<float> performance;
 const char* names[]={"STAVROS","DRUGO","MORPH"};
 for(int i=0;i<3;++i){Combi c;c.name=names[i];auto& u=c.part(7);solo::preset(u,0);solo::defaults(u.engine.p.data());u.name=names[i];
  if(i==1){u.engine.p[solo::MorphX]=1;u.engine.p[solo::MorphY]=.7F;}
  if(i==2){u.engine.p[solo::MorphX]=.5F;u.engine.p[solo::MorphY]=.35F;}
  const auto slot=static_cast<std::uint16_t>(i);data.combis.push_back({{0,0,slot},c});list.entries.push_back({static_cast<std::uint16_t>(i+1),names[i],0,0,slot});
  auto audio=render(c);wav(std::string(argv[1])+"/SOLO_"+names[i]+".wav",audio);performance.insert(performance.end(),audio.begin(),audio.end());performance.resize(performance.size()+48000,0);
  if(i==0)wav(std::string(argv[1])+"/STAVROS_HELD.wav",held(c,62,.068,2.189,2.4));
  if(i==1)wav(std::string(argv[1])+"/DRUGO_HELD.wav",held(c,62,.082,1.688,1.92));
 }
 data.lists.push_back({{0,0,0},list});data.performance=PerformanceSnapshot{data.combis[0].combi,SlotAddress{0,0,0},0,false};
 auto saved=SetPackage::save(argv[2],data);if(!saved.success)throw std::runtime_error(saved.error);
 auto loaded=SetPackage::load(argv[2]);if(!loaded.ok()||loaded.data.combis.size()!=3)throw std::runtime_error("SET roundtrip");
 for(int i=0;i<3;++i)if(loaded.data.combis[i].combi.part(7).engine.p!=data.combis[i].combi.part(7).engine.p)throw std::runtime_error("SET changed params");
 wav(std::string(argv[1])+"/SILVETON_SOLO_PLAY.wav",performance);
 std::cout<<"PASS three characters, same engine, SET roundtrip, no PCM or model bank, no stuck notes\n";
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
