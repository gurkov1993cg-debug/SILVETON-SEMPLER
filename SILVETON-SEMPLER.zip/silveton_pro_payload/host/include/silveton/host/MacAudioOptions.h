#pragma once
#include <cstdint>

namespace silveton::host {
// Apply on the control thread before opening/recovering the Mac output.
void setMacAudioPreferences(double rate, std::uint32_t frames);
}
