#pragma once
// SILVETON_MAC_NATIVE_API_V1
// The whole control surface of the sampler (the same ~140 calls the tablet screens use, with the same
// names as the tablet's NativeSamplerEngine). Arrays are plain std::vector. One sampler per program.
// Generated from the tablet bridge, then reviewed; the work is done in SamplerHost.cpp.

#include "silveton/host/HostIo.h"
#include "silveton/sampler/SamplerTypes.h"

#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::sampler { struct Combi; }

namespace silveton::host {

class NativeSamplerEngine {
public:
    silveton::sampler::SoundAssignment nativeSoundSource(int upper, int sound) const;
    bool nativeSetSoundSource(int upper, int sound, const silveton::sampler::SoundAssignment& source);
    bool nativeLoadSoloSound(int upper, int sound, const std::string& path);
    bool nativeSetSoundEngineParam(int upper, int sound, int id, float value);
    NativeSamplerEngine() { nativeSamplerInit(); }
    void nativeSamplerInit();
    bool nativeAudioOpen();
    bool nativeAudioStart();
    void nativeAudioStop();
    // Ignore physical MIDI while Manager auditions a private instrument.
    void nativeSetMidiPreviewIsolation(bool blocked);
    void nativeAudioClose();
    bool nativeAudioRecover();
    bool nativeAudioNeedsRecovery();
    bool nativeEnforceOutputRoute();
    void nativeSetPortaBalance(int balance);
    void nativeSetVoiceCeiling(int voices);
    void nativeSetPortaNear(int ms);
    std::string nativeBankInfo(const std::string& path);
    std::string nativeRemoveBankSounds(const std::string& path, const std::vector<int>& slots);
    bool nativeLoadAudio(const std::string& path);
    bool nativeLoadKmp(const std::string& path);
    std::vector<int> nativeImportKmpToLibrary(const std::string& path);
    std::vector<int> nativeImportKscToLibrary(const std::string& path);
    std::vector<int> nativeMultisampleIds();
    std::vector<std::string> nativeMultisampleNames();
    std::vector<int> nativeSampleIds();                              // SILVETON_SAMPLE_WAVE_V1
    std::vector<std::string> nativeSampleNames();
    bool nativeSampleWave(int id, std::vector<float>& points);      // 64 points -1..1 of the whole sample
    std::vector<std::string> nativeKscNames(const std::string& path);
    bool nativeLoadKscItem(const std::string& path, int index);
    bool nativeLoadSvBank(const std::string& path);
    bool nativeLoadSet(const std::string& path);
    bool nativeSaveUserPerformanceState(const std::string& path);
    bool nativeLoadUserPerformanceState(const std::string& path);
    bool nativeReplaceUserPerformanceState(const std::string& path);
    // SILVETON_SEND_V1 / SILVETON_PROJECT_V1 (only in the Manager's copy of the sampler)
    bool nativeAddBankSounds(const std::string& path);
    bool nativeSaveOpenCombi(const std::string& path);
    bool nativeLoadOpenCombi(const std::string& path);
    bool nativeWriteSoundCombi(int combiSlot, int soundSlot, const std::string& name);   // SILVETON_PASTE_V1
    // SILVETON_LIST_DELETE_SOUNDS_V1: the SOUND places (1..500) the COMBI uses that no other COMBI, no saved set (setPaths) and -
    // when countOpen - not the open COMBI uses; and taking SOUNDs out of the sampler (the open COMBI is bound again).
    // SILVETON_LIST_DELETE_GHOST_V1: "no other COMBI" = no other COMBI that is on the LIST (listedCombis = {bank, page, slot} of the
    // other LIST positions). A blend that was taken off the LIST earlier is only a ghost in BLENDS and does not keep a sound alive.
    std::vector<int> nativeSoundsOnlyInCombi(int bank, int page, int slot, bool countOpen, const std::vector<std::string>& setPaths,
                                             const std::vector<std::array<int, 3>>& listedCombis);
    bool nativeRemoveSoundPlaces(const std::vector<int>& places);
    bool nativeSaveBank(const std::string& path, int bank);
    bool nativeLoadBank(const std::string& path, int targetBank, bool overwrite);
    bool nativeWriteSample(int id, int upper, int layer, int zone, const std::string& name);
    bool nativeUpdateSampleMetadata(int id, const std::string& name, int rootKey, float fineTune);
    bool nativeTrimSample(int id, std::int64_t start, std::int64_t end);
    bool nativeNormalizeSample(int id, float targetDb);
    bool nativeReverseSample(int id);
    bool nativeFadeSample(int id, std::int64_t fadeIn, std::int64_t fadeOut);
    bool nativeSetSampleLoop(int id, std::int64_t start, std::int64_t end, int crossfade);
    bool nativeClearSampleLoop(int id);
    std::int64_t nativeSampleNearestZeroCrossing(int id, std::int64_t around, std::int64_t radius);
    bool nativeWriteMultisample(int id, int upper, int layer, const std::string& name);
    bool nativeRenameMultisample(int id, const std::string& name);
    bool nativeAddMultisampleZone(int id, int sampleId, int insertIndex, int keyLow, int keyHigh, int velLow, int velHigh, int rootKey, int transpose, float tune, float gain, float pan, bool oneShot, bool reverse, bool nonTranspose);
    bool nativeUpdateMultisampleZone(int id, int zoneIndex, int sampleId, int keyLow, int keyHigh, int velLow, int velHigh, int rootKey, int transpose, float tune, float gain, float pan, bool oneShot, bool reverse, bool nonTranspose);
    bool nativeRemoveMultisampleZone(int id, int zoneIndex);
    bool nativeMoveMultisampleZone(int id, int fromIndex, int toIndex);
    bool nativeClearMultisample(int id);
    bool nativeProgramSlotOccupied(int bank, int page, int slot);
    bool nativeCombiSlotOccupied(int bank, int page, int slot);
    bool nativeListSlotOccupied(int bank, int page, int slot);
    bool nativeRenameProgram(int bank, int page, int slot, const std::string& name);
    bool nativeRenameCombi(int bank, int page, int slot, const std::string& name);
    bool nativeRenameList(int bank, int page, int slot, const std::string& name);
    bool nativeCopyProgram(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite);
    bool nativeCopyCombi(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite);
    std::shared_ptr<const silveton::sampler::Combi> nativeStoredCombi(int bank, int page, int slot);
    bool nativeStoreCombiSnapshot(int bank, int page, int slot, const silveton::sampler::Combi& combi);
    bool nativeCopyList(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite);
    bool nativeMidi(int status, int d1, int d2);
    int nativeMidiDeviceCount();
    int nativeMidiLastError();
    std::int64_t nativeMidiActivitySerial();
    std::vector<int> nativeMidiLastMessage();
    int nativeMidiCcValue(int cc);                // SILVETON_PEDAL_CAL_V1: last value of a controller, -1 = none yet
    bool nativeBlendEdited();                     // SILVETON_SAVEQ_V1: the open BLEND was changed since it was recalled / written
    std::string nativeLastRecallMissing();        // SILVETON_OPEN_WITHOUT_SOUND_V1: "part<TAB>layer<TAB>name<TAB>number" lines of the last recall
    bool nativeAudioStarted();
    bool nativeTestInstrumentEnabled();
    bool nativeTestNoteOn(int note, int velocity);
    void nativeTestNoteOff(int note);
    bool nativePanic();
    std::vector<float> nativeMeters();
    std::vector<int> nativeAudioInfo();
    double nativeLatencyMs();
    int nativeLastAudioError();
    std::string nativeLastTextError();
    bool nativeSaveSet(const std::string& path);
    bool nativeSetSetName(const std::string& name);
    bool nativeWriteProgram(int bank, int page, int slot, int upper, const std::string& name);
    bool nativeUpdateProgramBasic(int bank, int page, int slot, bool mono, bool legato, float portamentoSec);
    bool nativeAddProgramLayer(int bank, int page, int slot, int multisampleId, const std::string& name);
    bool nativeRemoveProgramLayer(int bank, int page, int slot, int layer);
    bool nativeMoveProgramLayer(int bank, int page, int slot, int fromLayer, int toLayer);
    bool nativeAssignProgramMultisample(int bank, int page, int slot, int layer, int multisampleId);
    bool nativeUpdateProgramLayerBasic(int bank, int page, int slot, int layer, bool enabled, int keyLow, int keyHigh, int velocityLow, int velocityHigh, int velocityFadeIn, int velocityFadeOut, int transpose, float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled);
    bool nativeUpdateProgramAmpEnvelope(int bank, int page, int slot, int layer, float attack, float decay, float sustain, float release);
    bool nativeUpdateProgramPitch(int bank, int page, int slot, int layer, float amountCents, float attack, float decay, float sustain, float release);
    bool nativeUpdateProgramFilter(int bank, int page, int slot, int layer, int mode, float cutoffHz, float resonance, float keyTrack, float velocityAmount, float envelopeAmount, float lfoAmount, float attack, float decay, float sustain, float release);
    bool nativeUpdateProgramLfo(int bank, int page, int slot, int layer, int lfoIndex, int wave, float frequencyHz, float delaySec, float fadeSec, bool keySync, float pitchCents, float filterOctaves, float ampDepth);
    bool nativeWriteCombi(int bank, int page, int slot, const std::string& name);
    bool nativeUpdateUpperMain(int upper, bool enabled, bool solo, bool mute, float levelDb, float pan, int keyLow, int keyHigh, int voiceMode);
    bool nativeUpdateUpperTune(int upper, int octave, int transpose, float fineCents, int pitchBendRange, float portamentoSec);
    bool nativeUpdateUpperRange(int upper, int velocityLow, int velocityHigh);
    bool nativeUpdateUpperControl(int upper, bool breath, bool expression, bool aftertouch, bool damper, int midiChannel);
    bool nativeUpdateUpperTone(int upper, float attack, float decay, float sustain, float release, float cutoff, float resonance, float lfoRate, float lfoDepth, float eqLow, float eqMid, float eqHigh);
    bool nativeSetUpperToneParam(int upper, int param, float value);
    std::vector<float> nativeUpperState(int upper);
    std::string nativeUpperSoundName(int upper);
    std::string nativeCombiName();
    std::vector<int> nativeCombiCatalogSlots();
    std::vector<std::string> nativeCombiCatalogNames();
    std::vector<int> nativeSoundCatalogAddresses();
    std::vector<std::string> nativeSoundCatalogNames();
    bool nativeUpdateUpperFxSends(int upper, float send1, float send2);
    bool nativeUpdateUpperControllerRoute(int upper, int route, int source, int destination, int cc, float amount, bool bipolar);
    bool nativeUpdateCombiFx(int slot, int type, float wet, float timeMs, float feedback, float rateHz, float depth, float tone);
    bool nativeUpdateCombiFxRouting(int routing);
    bool nativeSetUpperParam(int upper, int id, float value);
    std::vector<float> nativeUpperParams(int upper);
    bool nativeSetLayerParam(int upper, int layer, int id, float value);
    bool nativeSetLayerSound(int upper, int layer, int slot);
    std::vector<float> nativeLayerParams(int upper, int layer);
    std::string nativeLayerName(int upper, int layer);
    std::vector<int> nativeSoundVelocityZones(int upper, int sound);   // SILVETON_OFS_V1: the lowest velocity of each velocity layer, hardest first
    int nativeUpperSoundSlot(int upper);   // SILVETON_LAYER_MOVE_V1: the SOUND of the basic place of an Upper (0 = none)
    bool nativeSetFxParam(int unit, int id, float value);
    std::vector<float> nativeFxParams(int unit);
    bool nativeSetSoundSynthParam(int upper, int sound, int id, float value);
    std::vector<float> nativeSoundSynthParams(int upper, int sound);
    // SILVETON_ENGINES_V1: the ENGINE of an Upper (id 0 = engine, 1..48 = its values; see core EngineDefs.h)
    bool nativeLoadSoloModel(int upper,const std::string& path);
    std::string nativeSoloModelName(int upper);
    bool nativeSetUpperEngineParam(int upper, int id, float value);
    bool nativeSetUpperEngineBlock(int upper, int firstId, const std::vector<float>& values);   // Atomic parameter update
    std::vector<float> nativeUpperEngineParams(int upper);
    // SILVETON_MODEL_V1: the learned models of SILVETON MODEL (SILVETON_OSC.sv of the teacher, next to the bank)
    bool nativeLoadLearnedModels(const std::string& file);   // false = not found / not readable (nativeLastTextError says why)
    std::vector<std::string> nativeLearnedModelNames();      // "name (slot)" per model, MODEL 1 first; empty = no file
    // SILVETON_MODELS_FROM_FILE_V1: what was read - the models the engine has, the sounds the file holds (more than the models when the file has
    // over 255), the zones of the models. All 0 = nothing read.
    void nativeLearnedModelsCounts(int& models, int& soundsInFile, int& zones);
    // SILVETON_TRANSWAVE_V1 (ids: see host/src/WaveHost.inc)
    bool nativeSetSoundWaveParam(int upper, int sound, int id, float value);
    std::vector<float> nativeSoundWaveParams(int upper, int sound);
    std::vector<float> nativeAnalyzerFrame(int upper, bool after);
    std::vector<float> nativeCombiFxState();
    std::string nativeBlendInfo(int bank, int page, int slot);   // SILVETON_BLEND_INFO_V1
    void nativeSetSetExtraText(const std::string& text);         // SILVETON_SET_ONE_FILE_V1: the T / Q text the next saved set carries
    std::string nativeLastLoadedSetExtraText();                  // ... and the one of the set that was read last
    void nativeStartScan(int mode);
    std::vector<int> nativeScanInfo();
    void nativeSetTerca(int upperMask, int root, int cell);
    void nativeSetScaleUppers(int upperMask);
    // A complete live tuning transaction, also stored with WRITE/SET.
    bool nativeSetScaleTuning(bool enabled, int upperMask, int tonic,
                              const std::vector<float>& cents, const std::string& name, bool markEdited = true);
    std::vector<float> nativeScaleTuning(); // stored, enabled, targets, tonic, 12 cents
    std::string nativeScaleName();
    std::vector<float> nativeGlobalState();
    bool nativeWriteGlobal();
    bool nativeUpdateGlobal(float tune, int transpose, float gain, float low, float mid, float high, bool limiter, float ceiling, int velocityCurve, int breathCc, int expressionCc, int damperCc, bool pitchBend, bool aftertouch);
    bool nativeUpdateGlobalAdvanced(int scaleRoot, const std::vector<float>& scaleOffsets, int midiChannelMask, bool filterNotes, bool filterCc, bool filterPitchBend, bool filterAftertouch, float breathMin, float breathMax, float breathCurve, float expressionMin, float expressionMax, float expressionCurve, bool damperReverse);
    bool nativeWriteList(int bank, int page, int slot, const std::string& listName, const std::vector<int>& numbers, const std::vector<std::string>& names, const std::vector<int>& combiAddresses);
    bool nativeSetListEntry(int lb, int lp, int ls, int index, int number, const std::string& name, int cb, int cp, int cs);
    bool nativeInsertListEntry(int lb, int lp, int ls, int index, int number, const std::string& name, int cb, int cp, int cs);
    bool nativeRemoveListEntry(int lb, int lp, int ls, int index);
    bool nativeMoveListEntry(int lb, int lp, int ls, int fromIndex, int toIndex);
    bool nativeMoveList(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite);
    bool nativeSetActiveListEntry(int lb, int lp, int ls, int index);
    bool nativeActivateListEntry(int lb, int lp, int ls, int index);
    int nativeActiveListEntry(int lb, int lp, int ls);
    std::vector<int> nativeListEntryNumbers(int lb, int lp, int ls);
    std::vector<std::string> nativeListEntryNames(int lb, int lp, int ls);
    std::vector<int> nativeListEntryCombiAddresses(int lb, int lp, int ls);
    bool nativeActivateProgram(int bank, int page, int slot, int upper);
    bool nativeAssignUpperSound(int bank, int page, int slot, int upper);
    bool nativeClearUpperSound(int upper);
    bool nativeClearPerformance();   // SILVETON_EMPTY_START_V1: ПРАЗНО - the blend's Uppers emptied, the engine places off, no open LIST position
    bool nativeActivateCombi(int bank, int page, int slot);
    bool nativeClearProgram(int bank, int page, int slot);
    bool nativeClearCombi(int bank, int page, int slot);
    bool nativeClearList(int bank, int page, int slot);
    // Mac additions (not in the tablet): the two outside doors can be replaced before nativeAudioOpen(), for tests.
    void setBackends(std::unique_ptr<AudioOutput> audio, std::unique_ptr<MidiInput> midi);
    std::string audioDeviceName();
    std::vector<std::string> midiSourceNames();
};

} // namespace silveton::host
