// Atomic SOLO parameter updates shared by both native hosts.
    bool setUpperEngineBlock(int upperIndex, int firstId, const std::vector<float>& values) {
        if (upperIndex < 0 || upperIndex >= kPartCount || firstId < 0 || values.empty() ||
            static_cast<std::size_t>(firstId) + values.size() > static_cast<std::size_t>(kEngineHostParamCount)) { setTextError("Invalid engine block"); return false; }
        for (const float v : values) if (!std::isfinite(v)) { setTextError("Invalid engine block"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.part(upperIndex);
        std::size_t at = 0U;
        if (firstId == 0) {
            if(values[0]!=0&&values[0]!=13){setTextError("This synth engine has been removed; select SOLO");return false;}
            const auto type = engineTypeOf(static_cast<int>(std::lround(values[0])));   // 11 (the removed SILVETON MODEL) means OFF
            if (type != u.engine.type) {
                u.engine = engineDefaults(type);
                if ((type == EngineType::Solo) && !u.hasAnySound()) { u.enabled = true; u.mute = false; }   // SILVETON_SYNTH_V1
            }
            at = 1U;
        }
        for (; at < values.size(); ++at) {
            const int id = firstId + static_cast<int>(at) - 1;   // the value id
            if (id < 0 || id >= kEngineParamCount) break;
            u.engine.p[static_cast<std::size_t>(id)] = engineClamp(u.engine.type, id, values[at]);
        }
        if(u.engine.chosen()){
            const int last=firstId+static_cast<int>(values.size())-1;
            const int source=firstId<=E_BEND_UP+1&&last>=E_BEND_UP+1?E_BEND_UP:E_BEND_DOWN;
            if(last>=E_BEND_UP+1)u.engine.p[E_BEND_UP]=u.engine.p[E_BEND_DOWN]=u.engine.p[source];
        }
        return installState(std::move(next));
    }
