// Shared public entry points used by both platform shells.
silveton::sampler::SoundAssignment NativeSamplerEngine::nativeSoundSource(int upper,int sound) const {return sampler().soundAssignment(upper,sound);}
bool NativeSamplerEngine::nativeSetSoundSource(int upper,int sound,const silveton::sampler::SoundAssignment& source) {return sampler().setSoundAssignment(upper,sound,source);}
bool NativeSamplerEngine::nativeLoadSoloSound(int upper,int sound,const std::string& path) {return sampler().loadSoloSound(upper,sound,path);}
bool NativeSamplerEngine::nativeSetSoundEngineParam(int upper,int sound,int id,float value) {return sampler().setSoundEngineParam(upper,sound,id,value);}
bool NativeSamplerEngine::nativeLoadSoloModel(int upper,const std::string& path){return sampler().loadSoloModel(upper,path);}
std::string NativeSamplerEngine::nativeSoloModelName(int upper){return sampler().soloModelName(upper);}
