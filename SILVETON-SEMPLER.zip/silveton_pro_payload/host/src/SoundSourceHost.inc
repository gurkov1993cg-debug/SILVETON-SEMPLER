// Shared sound assignment, trained SOLO import and SET restore for desktop and Android.
// Included inside the platform host class; device I/O stays in that platform.

    SoundAssignment soundAssignment(int upper, int sound) const {
        if(!state_ || upper<0 || upper>=kPartCount || sound<0 || sound>kUpperLayers) return {};
        return soundSource(state_->combi.part(upper),sound);
    }

    bool setSoundAssignment(int upper, int sound, const SoundAssignment& source) {
        if(upper<0 || upper>=kPartCount || sound<0 || sound>kUpperLayers){setTextError("Invalid sound place");return false;}
        auto next=std::make_shared<EngineState>(state_?*state_:EngineState{});
        auto& u=next->combi.part(upper);auto& dst=soundSource(u,sound);
        const bool occupied=dst.hasSource();dst=source;
        if(source.engine.chosen()&&source.commonProcessing) { dst.program.reset();dst.soundSlotId=0; }
        if(sound>0){auto& l=u.layers[static_cast<std::size_t>(sound-1)];if(!occupied)l.enabled=source.hasSource();if(!source.hasSource())l.enabled=false;}
        if(source.hasSource())u.enabled=true;
        return installState(std::move(next));
    }

    bool loadSoloSound(int upper,int sound,const std::string& path) {
        std::string error;auto model=solo::loadModel(path,error);if(!model){setTextError(error);return false;}
        SoundAssignment source;source.soloModel=model;source.name=model->name;source.commonProcessing=true;
        source.engine=engineDefaults(EngineType::Solo);solo::learnedDefaults(source.engine.p.data(),model->releaseMs);
        source.engine.p[solo::LevelDb]=0;
        return setSoundAssignment(upper,sound,source);
    }

    bool setSoundEngineParam(int upper,int sound,int id,float value) {
        if(upper<0||upper>=kPartCount||sound<0||sound>kUpperLayers||id<0||id>=kEngineParamCount||!std::isfinite(value)){setTextError("Invalid source parameter");return false;}
        auto next=std::make_shared<EngineState>(state_?*state_:EngineState{});
        auto& src=soundSource(next->combi.part(upper),sound);
        if(!src.engine.chosen()){setTextError("No SOLO source in this place");return false;}
        src.engine.p[static_cast<std::size_t>(id)]=engineClamp(src.engine.type,id,value);
        return installState(std::move(next));
    }

    bool loadSoloModel(int upperIndex,const std::string& path) {
        if(upperIndex<0||upperIndex>=kPartCount)return false;
        std::string error;std::shared_ptr<const solo::Model> model;
        if(!path.empty()){model=solo::loadModel(path,error);if(!model){setTextError(error);return false;}}
        auto next=std::make_shared<EngineState>(state_?*state_:EngineState{});auto&u=next->combi.part(upperIndex);u.soloModel=model;
        if(model){const auto bend=u.engine.p[E_BEND_UP];u.engine=engineDefaults(EngineType::Solo);solo::learnedDefaults(u.engine.p.data(),model->releaseMs);u.engine.p[E_BEND_UP]=u.engine.p[E_BEND_DOWN]=bend;
            u.engine.p[solo::ReleaseMs]=model->releaseMs;u.engine.p[solo::AttackMs]=1;u.engine.p[solo::LevelDb]=0;u.enabled=true;u.mute=false;u.voiceMode=UpperVoiceMode::Legato;u.name=model->name;u.portaTime=0;u.portamentoSec=0;u.expressionEnabled=false;u.breathEnabled=false;u.aftertouchEnabled=false;}
        return installState(std::move(next));
    }

    std::string soloModelName(int upperIndex) const {if(!state_||upperIndex<0||upperIndex>=kPartCount)return {};const auto&m=state_->combi.part(upperIndex).soloModel;return m?m->name:std::string{};}

    bool setLayerSound(int upperIndex, int layer, int slot) {
        if (upperIndex < 0 || upperIndex >= kPartCount || layer < 0 || layer >= kUpperLayers) { setTextError("Invalid layer"); return false; }
        if(slot<=0)return setSoundAssignment(upperIndex,layer+1,{});
        if(slot>65535){setTextError("Invalid sound slot");return false;}
        auto p=programForSlot(static_cast<std::uint16_t>(slot));
        if(!p){setTextError("SOUND slot is empty");return false;}
        SoundAssignment source;source.program=p;source.soundSlotId=static_cast<std::uint16_t>(slot);source.name=p->name;
        return setSoundAssignment(upperIndex,layer+1,source);
    }

    bool activateProgram(const SlotAddress& address, int upperIndex) {
        if (upperIndex < 0 || upperIndex >= kPartCount) { setTextError("Invalid Upper index"); return false; }
        const bool builtin = address.bank == 0U && address.page == 0U && isBuiltinSlot(address.slot);
        const auto program = builtin ? programForSlot(address.slot) : library_.program(address);
        if (program == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        SoundAssignment source;source.program=program;source.soundSlotId=address.slot;source.name=program->name;
        return setSoundAssignment(upperIndex,0,source);
    }

    bool clearUpperSound(int upperIndex) { return setSoundAssignment(upperIndex,0,{}); }

    bool clearPerformance() {
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        for (int i = 0; i < kPartCount; ++i) {
            auto& upper = next->combi.part(i);
            if (i < 7) {
                upper.program.reset();
                upper.soundSlotId = kNoSoundSlot;
                for (auto& l : upper.layers) { static_cast<SoundAssignment&>(l)={};l.enabled=false; }
                static_cast<SoundAssignment&>(upper)={};
            }
            upper.enabled = false;
            upper.solo = false;
            upper.mute = false;
        }
        next->combi.name = "EMPTY";   // the head of the screens says so
        activeListAddress_.reset();
        activeListEntry_ = -1;
        if (!installState(std::move(next), Mark::Clean)) return false;
        setTextError({});
        return true;
    }

    std::string upperSoundName(int upperIndex) const {
        if (upperIndex < 0 || upperIndex >= kPartCount || state_ == nullptr) return {};
        const auto& u=state_->combi.part(upperIndex);
        return u.engine.chosen()?u.name:(u.program?u.program->name:std::string{});
    }

    void rebindUpper(UpperPart& upper, const std::vector<SoundCandidate>& bankSounds) const {
        if (upper.soundSlotId != kNoSoundSlot) {
            upper.program = programForRemembered(upper.soundSlotId, upper.name, bankSounds);
            if (upper.program != nullptr) upper.name = upper.program->name; else if (!upper.hasAnySound() && !engineMakesOwnSound(upper.engine)) upper.enabled = false;
        }
        for (auto& l : upper.layers) {
            if (l.engine.chosen()) { l.program.reset(); continue; }
            if (l.soundSlotId == kNoSoundSlot) { l.program.reset(); l.enabled = false; continue; }
            l.program = programForRemembered(l.soundSlotId, l.name, bankSounds);
            if (l.program != nullptr) l.name = l.program->name; else l.enabled = false;
        }
        if (upper.program == nullptr && !upper.hasAnySound() && !engineMakesOwnSound(upper.engine)) upper.enabled = false;
    }

    std::vector<int> soundCatalogAddresses() const {
        std::vector<int> out;
        for (const auto& item : library_.programCatalog()) {
            out.push_back(static_cast<int>(item.address.bank));
            out.push_back(static_cast<int>(item.address.page));
            out.push_back(static_cast<int>(item.address.slot));
        }
        // Offer the existing oscillator programs through the same source picker.
        for(int i=0;i<kBuiltinWaveCount;++i){out.push_back(0);out.push_back(0);out.push_back(kBuiltinWaveFirstSlot+i);}
        return out;
    }

    std::vector<std::string> soundCatalogNames() const {
        std::vector<std::string> out;
        for (const auto& item : library_.programCatalog()) out.push_back(item.name);
        for(int i=0;i<kBuiltinWaveCount;++i)out.push_back(builtinWaveProgram(i)->name);
        return out;
    }

    bool loadUserPerformanceState(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        lastLoadedSetExtra_ = loaded.data.extra;
        pendingSetExtra_ = loaded.data.extra;

        const auto bankSounds = bankSoundCandidates();   // SILVETON_SOUND_BY_NAME_V1
        for (const auto& saved : loaded.data.combis) {
            Combi rebound = saved.combi;
            (void)rebindPerformanceCombi(rebound, bankSounds);
            if (!library_.writeCombi(saved.address, rebound)) {
                setTextError("Could not restore saved BLEND/COMBI");
                return false;
            }
        }
        for (const auto& saved : loaded.data.lists) {
            if (!library_.writeList(saved.address, saved.list)) {
                setTextError("Could not restore saved LIST");
                return false;
            }
        }
        // Startup merges the catalog before restoring SOLO session rows. Restore an
        // embedded trained PLACE only into an empty slot; a live bank refresh must
        // never replace an already playing SOLO.
        if(loaded.data.performance){
            auto next=std::make_shared<EngineState>(state_?*state_:EngineState{});bool changed=false;
            for(int i=0;i<kPartCount;++i){const auto&saved=loaded.data.performance->combi.part(i);
                if(!next->combi.part(i).hasAnySound() && saved.hasAnySound()){
                    next->combi.part(i)=saved;rebindUpper(next->combi.part(i),bankSounds);changed=true;
                }
            }
            if(changed&&!installState(std::move(next),Mark::Clean))return false;
        }
        setTextError({});
        return true;
    }
