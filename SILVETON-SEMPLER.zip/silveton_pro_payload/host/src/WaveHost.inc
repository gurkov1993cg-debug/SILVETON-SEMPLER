// SILVETON_TRANSWAVE_V1 - the TRANSWAVE settings of a sound and the wave tables of the state.
// Included INSIDE the host class of the tablet and of the generic host (they share this text).
    // Wave parameter ids: 0 mode (0 off, 1 AUTO, 2 MULTI)  1 frames  2 position  3 start  4 span  5 smooth  6 source (0 none, 1 ENV, 2 LFO, 3 VEL, 4 MOD WHEEL, 5 AFTERTOUCH, 6 NOTE)
    //                     7 amount  8 time ms  9 LFO Hz  10..17 SOUND slot of frame 1..8 (0 = empty)
    static constexpr int kWaveParamCount = 18;
    static void applyWave(ToneExtra& x, int id, float v) {
        const auto i8 = [](float f, int lo, int hi) { return static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(f)), lo, hi)); };
        switch (id) {
            case 0: x.waveMode = i8(v, 0, 2); break;
            case 1: x.waveFrames = i8(v, 2, 32); break;
            case 2: x.wavePos = std::clamp(v, 0.0F, 1.0F); break;
            case 3: x.waveStart = std::clamp(v, 0.0F, 1.0F); break;
            case 4: x.waveSpan = std::clamp(v, 0.02F, 1.0F); break;
            case 5: x.waveSmooth = std::clamp(v, 0.0F, 1.0F); break;
            case 6: x.waveSource = i8(v, 0, 6); break;
            case 7: x.waveAmount = std::clamp(v, -1.0F, 1.0F); break;
            case 8: x.waveTimeMs = std::clamp(v, 10.0F, 20000.0F); break;
            case 9: x.waveRateHz = std::clamp(v, 0.02F, 30.0F); break;
            default:
                if (id >= 10 && id < 10 + kWaveSlots) {
                    const int slot = static_cast<int>(std::lround(v));
                    const bool ok = slot == 0 || (slot >= 1 && slot <= static_cast<int>(kFixedSoundSlotCount)) ||
                                    (slot >= static_cast<int>(kBuiltinWaveFirstSlot) && slot < static_cast<int>(kBuiltinWaveFirstSlot) + kBuiltinWaveCount);
                    if (ok) x.waveSlot[static_cast<std::size_t>(id - 10)] = static_cast<std::uint16_t>(slot);
                }
                break;
        }
    }
    static void readWave(const ToneExtra& x, std::vector<float>& out) {
        out = {static_cast<float>(x.waveMode), static_cast<float>(x.waveFrames), x.wavePos, x.waveStart, x.waveSpan, x.waveSmooth, static_cast<float>(x.waveSource),
               x.waveAmount, x.waveTimeMs, x.waveRateHz};
        for (const auto slot : x.waveSlot) out.push_back(static_cast<float>(slot));
    }
    bool setSoundWaveParam(int upperIndex, int sound, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || sound < 0 || sound > kUpperLayers || id < 0 || id >= kWaveParamCount || !std::isfinite(v)) { setTextError("Invalid wave parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        if (sound == 0) applyWave(u.toneExtra, id, v);
        else applyWave(u.layers[static_cast<std::size_t>(sound - 1)].tone.x, id, v);
        return installState(std::move(next));
    }
    std::vector<float> soundWaveParams(int upperIndex, int sound) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kUpperCount || sound < 0 || sound > kUpperLayers || state_ == nullptr) return out;
        const auto& u = state_->combi.uppers[static_cast<std::size_t>(upperIndex)];
        readWave(sound == 0 ? u.toneExtra : u.layers[static_cast<std::size_t>(sound - 1)].tone.x, out);
        return out;
    }
    // Called by installState (before the state goes to the engine): finds the programs of the MULTI frames, makes the wave tables that are missing
    // (control thread, never the audio callback) and gives them to the engine. Older maps stay alive for a while so the audio thread never frees them.
    void prepareWaveTables(EngineState& s) {
        std::lock_guard<std::mutex> lock(waveMutex_);
        const auto resolve = [this](ToneExtra& x) {
            if (x.waveMode != kWaveModeMulti) { x.waveSources.reset(); return; }
            auto list = std::make_shared<std::vector<ProgramPtr>>(static_cast<std::size_t>(kWaveSlots));
            for (std::size_t i = 0; i < static_cast<std::size_t>(kWaveSlots); ++i) if (x.waveSlot[i] != 0U) (*list)[i] = programForSlot(x.waveSlot[i]);
            x.waveSources = std::move(list);
        };
        for (auto& u : s.combi.uppers) {
            resolve(u.toneExtra);
            for (auto& l : u.layers) resolve(l.tone.x);
        }
        auto tables = waveCache_.refresh(s);
        // SILVETON_FAST_DRAW_V1: the same tables as last time (or still none) - nothing goes to the engine, so a knob turn
        // or an EQ point does not make the sound part throw away a map every time
        const bool same = wavePublishedOnce_ && ((tables == nullptr && wavePublished_ == nullptr) ||
                                                 (tables != nullptr && wavePublished_ != nullptr && *tables == *wavePublished_));
        if (same) return;
        engine_.setWaveTables(tables);
        wavePublished_ = tables;
        wavePublishedOnce_ = true;
        if (tables != nullptr) { waveKeep_.push_back(tables); while (waveKeep_.size() > 8U) waveKeep_.pop_front(); }
    }
    std::shared_ptr<const WaveTableMap> wavePublished_;
    bool wavePublishedOnce_{false};
    WaveTableCache waveCache_;
    std::deque<std::shared_ptr<const WaveTableMap>> waveKeep_;
    std::mutex waveMutex_;
