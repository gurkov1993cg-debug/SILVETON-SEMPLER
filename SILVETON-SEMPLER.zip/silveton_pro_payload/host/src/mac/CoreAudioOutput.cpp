// SILVETON_MAC_COREAUDIO_V1 - the sound output of the Mac sampler (replaces the tablet's Direct ALSA).
// One AUHAL output unit bound to the default output device, stereo 32-bit float.
// Desktop default: 48 kHz / 256 frames; the Audio menu can request 96 kHz or 128/512 frames.
// Whatever the device really gives is reported back, not the requested settings.
#if defined(__APPLE__)

#include "silveton/host/HostIo.h"
#include "silveton/host/MacAudioOptions.h"

#include <AudioToolbox/AudioToolbox.h>
#include <CoreAudio/CoreAudio.h>

#if defined(__SSE__)
#include <xmmintrin.h>
#endif

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>
#include <vector>

namespace silveton::host {
namespace {
std::atomic<double> requestedRate{48000.0};
std::atomic<std::uint32_t> requestedFrames{256U};

AudioObjectPropertyAddress address(AudioObjectPropertySelector selector,
                                   AudioObjectPropertyScope scope = kAudioObjectPropertyScopeGlobal) {
    AudioObjectPropertyAddress a;
    a.mSelector = selector;
    a.mScope = scope;
    a.mElement = kAudioObjectPropertyElementMaster;
    return a;
}

template <class T>
bool getProperty(AudioObjectID object, AudioObjectPropertySelector selector, AudioObjectPropertyScope scope, T& value) {
    AudioObjectPropertyAddress a = address(selector, scope);
    UInt32 size = sizeof(T);
    return AudioObjectGetPropertyData(object, &a, 0, nullptr, &size, &value) == noErr;
}

template <class T>
bool setProperty(AudioObjectID object, AudioObjectPropertySelector selector, AudioObjectPropertyScope scope, const T& value) {
    AudioObjectPropertyAddress a = address(selector, scope);
    return AudioObjectSetPropertyData(object, &a, 0, nullptr, sizeof(T), &value) == noErr;
}

std::string deviceNameOf(AudioDeviceID device) {
    CFStringRef name = nullptr;
    AudioObjectPropertyAddress a = address(kAudioObjectPropertyName);
    UInt32 size = sizeof(name);
    if (AudioObjectGetPropertyData(device, &a, 0, nullptr, &size, &name) != noErr || name == nullptr) return {};
    char buffer[256];
    std::string out;
    if (CFStringGetCString(name, buffer, sizeof buffer, kCFStringEncodingUTF8)) out = buffer;
    CFRelease(name);
    return out;
}

class CoreAudioOutput final : public AudioOutput {
public:
    ~CoreAudioOutput() override { close(); }

    bool open(RenderFn fn, void* user, double wantedRate, std::uint32_t wantedFrames) override {
        close();
        wantedRate = requestedRate.load(std::memory_order_relaxed);
        wantedFrames = requestedFrames.load(std::memory_order_relaxed);
        fn_ = fn;
        user_ = user;
        error_.clear();
        xruns_.store(0, std::memory_order_relaxed);
        recover_.store(false, std::memory_order_relaxed);

        if (!getProperty(kAudioObjectSystemObject, kAudioHardwarePropertyDefaultOutputDevice, kAudioObjectPropertyScopeGlobal, device_) ||
            device_ == kAudioObjectUnknown) {
            return fail("there is no sound output device");
        }
        deviceName_ = deviceNameOf(device_);

        // The selected rate if available, else 48 kHz, else the device's current rate.
        chooseRate(wantedRate);
        Float64 rate = 0.0;
        if (!getProperty(device_, kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, rate) || rate < 8000.0) {
            return fail("the sound device reports no sample rate");
        }
        rate_ = rate;

        // The block size: as small as the device allows, around the wish.
        UInt32 frames = std::max<std::uint32_t>(wantedFrames, 16U);
        AudioValueRange range{};
        if (getProperty(device_, kAudioDevicePropertyBufferFrameSizeRange, kAudioObjectPropertyScopeGlobal, range)) {
            frames = static_cast<UInt32>(std::min(std::max(static_cast<Float64>(frames), range.mMinimum), range.mMaximum));
        }
        (void)setProperty(device_, kAudioDevicePropertyBufferFrameSize, kAudioObjectPropertyScopeGlobal, frames);
        UInt32 realFrames = 0;
        if (!getProperty(device_, kAudioDevicePropertyBufferFrameSize, kAudioObjectPropertyScopeGlobal, realFrames) || realFrames == 0U) {
            realFrames = frames;
        }
        frames_ = realFrames;

        AudioComponentDescription desc{};
        desc.componentType = kAudioUnitType_Output;
        desc.componentSubType = kAudioUnitSubType_HALOutput;
        desc.componentManufacturer = kAudioUnitManufacturer_Apple;
        AudioComponent component = AudioComponentFindNext(nullptr, &desc);
        if (component == nullptr || AudioComponentInstanceNew(component, &unit_) != noErr) return fail("no audio output unit");

        UInt32 on = 1, off = 0;
        if (AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Input, 1, &off, sizeof off) != noErr ||
            AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Output, 0, &on, sizeof on) != noErr) {
            return fail("cannot switch the output unit to playback");
        }
        if (AudioUnitSetProperty(unit_, kAudioOutputUnitProperty_CurrentDevice, kAudioUnitScope_Global, 0, &device_, sizeof device_) != noErr) {
            return fail("cannot bind the output unit to the sound device");
        }

        AudioStreamBasicDescription format{};
        format.mSampleRate = rate_;
        format.mFormatID = kAudioFormatLinearPCM;
        format.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
        format.mBytesPerPacket = 8;
        format.mFramesPerPacket = 1;
        format.mBytesPerFrame = 8;
        format.mChannelsPerFrame = 2;
        format.mBitsPerChannel = 32;
        if (AudioUnitSetProperty(unit_, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Input, 0, &format, sizeof format) != noErr) {
            return fail("the sound device does not accept stereo float");
        }
        UInt32 maxSlice = std::max<UInt32>(frames_ * 4U, 4096U);
        (void)AudioUnitSetProperty(unit_, kAudioUnitProperty_MaximumFramesPerSlice, kAudioUnitScope_Global, 0, &maxSlice, sizeof maxSlice);

        AURenderCallbackStruct callback{};
        callback.inputProc = &CoreAudioOutput::renderProc;
        callback.inputProcRefCon = this;
        if (AudioUnitSetProperty(unit_, kAudioUnitProperty_SetRenderCallback, kAudioUnitScope_Input, 0, &callback, sizeof callback) != noErr) {
            return fail("cannot set the render callback");
        }
        if (AudioUnitInitialize(unit_) != noErr) return fail("cannot initialise the output unit");
        initialised_ = true;

        // The system tells us when the load was too much for the device, and when the user changes the output.
        AudioObjectPropertyAddress overload = address(kAudioDeviceProcessorOverload, kAudioObjectPropertyScopeGlobal);
        if (AudioObjectAddPropertyListener(device_, &overload, &CoreAudioOutput::overloadProc, this) == noErr) overloadListener_ = true;
        AudioObjectPropertyAddress defaultOut = address(kAudioHardwarePropertyDefaultOutputDevice);
        if (AudioObjectAddPropertyListener(kAudioObjectSystemObject, &defaultOut, &CoreAudioOutput::deviceChangedProc, this) == noErr) defaultListener_ = true;
        AudioObjectPropertyAddress rateAddr = address(kAudioDevicePropertyNominalSampleRate);
        if (AudioObjectAddPropertyListener(device_, &rateAddr, &CoreAudioOutput::deviceChangedProc, this) == noErr) rateListener_ = true;

        opened_ = true;
        return true;
    }

    bool start() override {
        if (!opened_) return false;
        if (running_) return true;
        const OSStatus rc = AudioOutputUnitStart(unit_);
        if (rc != noErr) {
            error_ = "AudioOutputUnitStart failed (" + std::to_string(static_cast<int>(rc)) + ")";
            return false;
        }
        running_ = true;
        return true;
    }

    void stop() override {
        if (!opened_ || !running_) return;
        (void)AudioOutputUnitStop(unit_);
        running_ = false;
    }

    void close() override {
        if (unit_ != nullptr) {
            if (running_) (void)AudioOutputUnitStop(unit_);
            if (initialised_) (void)AudioUnitUninitialize(unit_);
            (void)AudioComponentInstanceDispose(unit_);
        }
        if (overloadListener_) {
            AudioObjectPropertyAddress a = address(kAudioDeviceProcessorOverload, kAudioObjectPropertyScopeGlobal);
            (void)AudioObjectRemovePropertyListener(device_, &a, &CoreAudioOutput::overloadProc, this);
        }
        if (defaultListener_) {
            AudioObjectPropertyAddress a = address(kAudioHardwarePropertyDefaultOutputDevice);
            (void)AudioObjectRemovePropertyListener(kAudioObjectSystemObject, &a, &CoreAudioOutput::deviceChangedProc, this);
        }
        if (rateListener_) {
            AudioObjectPropertyAddress a = address(kAudioDevicePropertyNominalSampleRate);
            (void)AudioObjectRemovePropertyListener(device_, &a, &CoreAudioOutput::deviceChangedProc, this);
        }
        unit_ = nullptr;
        initialised_ = overloadListener_ = defaultListener_ = rateListener_ = false;
        running_ = opened_ = false;
        rate_ = 0.0;
        frames_ = 0U;
    }

    [[nodiscard]] double sampleRate() const override { return opened_ ? rate_ : 0.0; }
    [[nodiscard]] std::uint32_t framesPerBurst() const override { return opened_ ? frames_ : 0U; }

    [[nodiscard]] double latencyMs() const override {
        if (!opened_ || rate_ <= 0.0) return -1.0;
        UInt32 deviceLatency = 0, safety = 0, streamLatency = 0;
        (void)getProperty(device_, kAudioDevicePropertyLatency, kAudioObjectPropertyScopeOutput, deviceLatency);
        (void)getProperty(device_, kAudioDevicePropertySafetyOffset, kAudioObjectPropertyScopeOutput, safety);
        // the first output stream of the device
        AudioObjectPropertyAddress streams = address(kAudioDevicePropertyStreams, kAudioObjectPropertyScopeOutput);
        UInt32 size = 0;
        if (AudioObjectGetPropertyDataSize(device_, &streams, 0, nullptr, &size) == noErr && size >= sizeof(AudioStreamID)) {
            std::vector<AudioStreamID> ids(size / sizeof(AudioStreamID));
            if (AudioObjectGetPropertyData(device_, &streams, 0, nullptr, &size, ids.data()) == noErr && !ids.empty()) {
                (void)getProperty(ids[0], kAudioStreamPropertyLatency, kAudioObjectPropertyScopeGlobal, streamLatency);
            }
        }
        const double total = static_cast<double>(deviceLatency) + safety + streamLatency + frames_;
        return total * 1000.0 / rate_;
    }

    [[nodiscard]] int xrunCount() const override { return xruns_.load(std::memory_order_relaxed); }
    [[nodiscard]] bool needsRecovery() const override { return recover_.load(std::memory_order_acquire); }
    [[nodiscard]] std::string deviceName() const override { return deviceName_; }
    [[nodiscard]] std::string lastError() const override { return error_; }

private:
    bool fail(const std::string& why) {
        error_ = why;
        close();
        return false;
    }

    // The selected rate, then 48 kHz; the device may need a moment to switch.
    void chooseRate(double wantedRate) {
        Float64 now = 0.0;
        (void)getProperty(device_, kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, now);
        for (const double candidate : {wantedRate, 48000.0}) {
            if (std::fabs(now - candidate) < 1.0) return;
            Float64 target = candidate;
            if (!setProperty(device_, kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, target)) continue;
            for (int i = 0; i < 50; ++i) {                       // up to half a second
                Float64 read = 0.0;
                if (getProperty(device_, kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, read) &&
                    std::fabs(read - candidate) < 1.0) {
                    return;
                }
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
        }
    }

    static OSStatus renderProc(void* ref, AudioUnitRenderActionFlags*, const AudioTimeStamp*, UInt32, UInt32 frames,
                               AudioBufferList* io) {
        auto* self = static_cast<CoreAudioOutput*>(ref);
#if defined(__SSE__)
        // tiny numbers in reverb tails cost extra time and are inaudible: flush them to zero
        _mm_setcsr(_mm_getcsr() | 0x8040U);
#endif
        if (io == nullptr || io->mNumberBuffers == 0U || io->mBuffers[0].mData == nullptr) return noErr;
        float* out = static_cast<float*>(io->mBuffers[0].mData);
        if (self->fn_ != nullptr) {
            self->fn_(self->user_, out, frames);
        } else {
            std::memset(out, 0, static_cast<std::size_t>(frames) * 2U * sizeof(float));
        }
        return noErr;
    }

    static OSStatus overloadProc(AudioObjectID, UInt32, const AudioObjectPropertyAddress*, void* ref) {
        static_cast<CoreAudioOutput*>(ref)->xruns_.fetch_add(1, std::memory_order_relaxed);
        return noErr;
    }

    static OSStatus deviceChangedProc(AudioObjectID, UInt32, const AudioObjectPropertyAddress*, void* ref) {
        static_cast<CoreAudioOutput*>(ref)->recover_.store(true, std::memory_order_release);
        return noErr;
    }

    RenderFn fn_{nullptr};
    void* user_{nullptr};
    AudioDeviceID device_{kAudioObjectUnknown};
    AudioComponentInstance unit_{nullptr};
    std::string deviceName_;
    std::string error_;
    double rate_{0.0};
    std::uint32_t frames_{0U};
    bool opened_{false};
    bool running_{false};
    bool initialised_{false};
    bool overloadListener_{false};
    bool defaultListener_{false};
    bool rateListener_{false};
    std::atomic<int> xruns_{0};
    std::atomic<bool> recover_{false};
};

} // namespace

std::unique_ptr<AudioOutput> makeCoreAudioOutput() { return std::make_unique<CoreAudioOutput>(); }

void setMacAudioPreferences(double rate, std::uint32_t frames) {
    requestedRate.store(rate == 96000.0 ? 96000.0 : 48000.0, std::memory_order_relaxed);
    requestedFrames.store(frames == 128U || frames == 512U ? frames : 256U, std::memory_order_relaxed);
}

} // namespace silveton::host
#endif
