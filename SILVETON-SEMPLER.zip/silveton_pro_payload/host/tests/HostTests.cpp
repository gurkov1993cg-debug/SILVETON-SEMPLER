// Tests of the Mac host: the doors (sound output / MIDI input) are replaced by the offline versions, so
// the whole chain  keyboard -> sampler -> sound  runs without any hardware.
#include "silveton/host/HostIo.h"
#include "silveton/host/MidiHeldState.h"
#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/sampler/SetPackage.h"

#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <limits>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::host;

#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

namespace {

void put16(std::ofstream& f, std::uint16_t v) { f.put(static_cast<char>(v & 0xFFU)); f.put(static_cast<char>(v >> 8U)); }
void put32(std::ofstream& f, std::uint32_t v) { put16(f, static_cast<std::uint16_t>(v & 0xFFFFU)); put16(f, static_cast<std::uint16_t>(v >> 16U)); }

// 16-bit mono sine wave, 48 kHz, 1 second, with a loop-friendly whole number of periods (440 Hz).
void writeSineWav(const std::string& path) {
    const std::uint32_t rate = 48000U, frames = 48000U;
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    f.write("RIFF", 4); put32(f, 36U + frames * 2U); f.write("WAVEfmt ", 8);
    put32(f, 16U); put16(f, 1U); put16(f, 1U); put32(f, rate); put32(f, rate * 2U); put16(f, 2U); put16(f, 16U);
    f.write("data", 4); put32(f, frames * 2U);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const double v = 0.5 * std::sin(2.0 * 3.14159265358979323846 * 440.0 * static_cast<double>(i) / rate);
        put16(f, static_cast<std::uint16_t>(static_cast<std::int16_t>(std::lround(v * 32767.0))));
    }
}

double energy(const std::vector<float>& v) {
    double e = 0.0;
    for (const float x : v) e += static_cast<double>(x) * static_cast<double>(x);
    return e;
}

void testMidiParser() {
    MidiByteParser p;
    std::vector<std::vector<int>> got;
    auto sink = [&](std::uint8_t s, std::uint8_t a, std::uint8_t b) { got.push_back({s, a, b}); };
    // note on, running-status note on, a real-time clock byte in the middle, note off by velocity 0
    for (const std::uint8_t b : {0x90, 60, 100, 61, 0xF8, 90, 0x80, 60, 0}) p.feed(b, sink);
    CHECK(got.size() == 3U);
    CHECK((got[0] == std::vector<int>{0x90, 60, 100}));
    CHECK((got[1] == std::vector<int>{0x90, 61, 90}));
    CHECK((got[2] == std::vector<int>{0x80, 60, 0}));
    // SysEx is skipped completely, a one-byte message (program change) is complete after one data byte
    got.clear();
    for (const std::uint8_t b : {0xF0, 1, 2, 3, 0xF7, 0xC3, 5, 0xB0, 7, 100}) p.feed(b, sink);
    CHECK(got.size() == 2U);
    CHECK((got[0] == std::vector<int>{0xC3, 5, 0}));
    CHECK((got[1] == std::vector<int>{0xB0, 7, 100}));
    // stray data bytes with no status are ignored
    MidiByteParser q;
    got.clear();
    for (const std::uint8_t b : {1, 2, 3}) q.feed(b, sink);
    CHECK(got.empty());
}

void testMidiDisconnectRelease() {
    MidiHeldState held;
    std::vector<std::vector<int>> got;
    auto sink = [&](std::uint8_t s, std::uint8_t a, std::uint8_t b) { got.push_back({s, a, b}); };
    held.track(0x90, 60, 100);
    held.track(0x90, 61, 100);
    held.track(0x90, 61, 0); // velocity zero releases the key
    held.track(0x9F, 127, 100);
    held.track(0xB0, 66, 127); // custom damper CC
    held.track(0xBF, 66, 0);   // pedal already up on another channel
    held.track(0xB0, 64, 127); // unrelated CC64 must not be released
    held.release(sink, 66, false);
    CHECK((got == std::vector<std::vector<int>>{{0x80, 60, 0}, {0xB0, 66, 0}, {0x8F, 127, 0}}));
    got.clear();
    held.release(sink, 66, false);
    CHECK(got.empty()); // a disconnected port is cleared

    // Reversed pedals use the high value for release; unseen controllers must
    // not look like a pressed reversed pedal just because their default is zero.
    held.track(0xB2, 67, 0);
    held.track(0xB3, 67, 127);
    held.track(0xB4, 66, 0);
    held.release(sink, 67, true);
    CHECK((got == std::vector<std::vector<int>>{{0xB2, 67, 127}}));

    got.clear();
    held.track(0xB0, 64, 127);
    held.release(sink, 64, false);
    CHECK((got == std::vector<std::vector<int>>{{0xB0, 64, 0}}));
}

void testGlobalRejectsNonFinite() {
    NativeSamplerEngine native;
    native.nativeSamplerInit();
    const auto before = native.nativeGlobalState();
    const float nan = std::numeric_limits<float>::quiet_NaN();
    const float infinity = std::numeric_limits<float>::infinity();
    for (const float bad : {nan, infinity, -infinity}) {
        for (std::size_t index = 0U; index < 6U; ++index) {
            std::array<float, 6U> values{{440.0F, -6.0F, 0.0F, 0.0F, 0.0F, -0.3F}};
            values[index] = bad;
            CHECK(!native.nativeUpdateGlobal(values[0], 0, values[1], values[2], values[3], values[4],
                true, values[5], 0, 2, 11, 64, true, true));
            CHECK(native.nativeGlobalState() == before);
        }
        std::vector<float> offsets(12U, 0.0F);
        offsets[5] = bad;
        CHECK(!native.nativeUpdateGlobalAdvanced(0, offsets, 65535, false, false, false, false,
            0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, false));
        CHECK(native.nativeGlobalState() == before);
        for (std::size_t index = 0U; index < 6U; ++index) {
            std::array<float, 6U> curves{{0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F}};
            curves[index] = bad;
            CHECK(!native.nativeUpdateGlobalAdvanced(0, std::vector<float>(12U, 0.0F), 65535,
                false, false, false, false, curves[0], curves[1], curves[2], curves[3], curves[4], curves[5], false));
            CHECK(native.nativeGlobalState() == before);
        }
    }
}

void testFailedWriteCheckpoint() {
    char tmpl[] = "/tmp/silveton-write-rollback-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string directory = tmpl;
    const std::string blocked = directory + "/not-a-directory";
    { std::ofstream file(blocked); file << "keep"; }

    NativeSamplerEngine native;
    CHECK(native.nativeActivateProgram(0, 0, 9002, 0));
    CHECK(native.nativeWriteCombi(0, 0, 1, "Stored before WRITE"));
    CHECK(native.nativeWriteList(0, 0, 0, "LIVE", {1}, {"Original row"}, {0, 0, 1}));
    CHECK(native.nativeActivateListEntry(0, 0, 0, 0));
    CHECK(native.nativeUpdateUpperTune(0, 1, -3, 17.0F, 7, 0.0F));
    std::vector<float> scale(12U, 0.0F);
    scale[4] = -37.0F;
    CHECK(native.nativeSetScaleTuning(true, 3, 4, scale, "Original scale", true));
    native.nativeSetSetExtraText("original metadata");
    CHECK(native.nativeBlendEdited());
    const auto upper = native.nativeUpperState(0);
    const auto global = native.nativeGlobalState();
    const auto tuning = native.nativeScaleTuning();
    const auto checkpoint = native.nativePerformanceCheckpoint();
    CHECK(checkpoint != nullptr);

    // Same sequence as WRITE: overwrite/create slots, replace/extend LIST,
    // activate the new position and finally hit an actual filesystem failure.
    CHECK(native.nativeWriteCombi(0, 0, 1, "Overwritten"));
    CHECK(native.nativeWriteCombi(0, 0, 2, "New slot"));
    CHECK(native.nativeSetListEntry(0, 0, 0, 0, 1, "Changed row", 0, 0, 2));
    CHECK(native.nativeInsertListEntry(0, 0, 0, 1, 2, "Added row", 0, 0, 1));
    CHECK(native.nativeActivateListEntry(0, 0, 0, 1));
    native.nativeSetSetExtraText("failed metadata");
    CHECK(!native.nativeBlendEdited());
    CHECK(!native.nativeSaveUserPerformanceState(blocked + "/state.SVSET"));
    const auto failure = native.nativeLastTextError();
    CHECK(!failure.empty());
    CHECK(native.nativeRestorePerformanceCheckpoint(checkpoint));
    CHECK(native.nativeLastTextError() == failure);
    CHECK(native.nativeStoredCombi(0, 0, 1)->name == "Stored before WRITE");
    CHECK(!native.nativeCombiSlotOccupied(0, 0, 2));
    CHECK((native.nativeListEntryNames(0, 0, 0) == std::vector<std::string>{"Original row"}));
    CHECK((native.nativeListEntryCombiAddresses(0, 0, 0) == std::vector<int>{0, 0, 1}));
    CHECK(native.nativeActiveListEntry(0, 0, 0) == 0);
    CHECK(native.nativeCombiName() == "Stored before WRITE");
    CHECK(native.nativeUpperState(0) == upper);
    CHECK(native.nativeGlobalState() == global);
    CHECK(native.nativeScaleTuning() == tuning);
    CHECK(native.nativeScaleName() == "Original scale");
    CHECK(native.nativeBlendEdited());

    const auto saved = directory + "/restored.SVSET";
    CHECK(native.nativeSaveUserPerformanceState(saved));
    const auto loaded = silveton::sampler::SetPackage::load(saved);
    CHECK(loaded.ok());
    CHECK(loaded.data.extra == "original metadata");
    CHECK(loaded.data.combis.size() == 1U);
    CHECK(loaded.data.performance.has_value() && loaded.data.performance->edited);
    CHECK(loaded.data.performance->activeListEntry == 0);
    CHECK(std::remove(saved.c_str()) == 0);
    CHECK(std::remove(blocked.c_str()) == 0);
    CHECK(::rmdir(directory.c_str()) == 0);
}

void testChain() {
    char tmpl[] = "/tmp/imak-host-test-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string dir = tmpl;
    const std::string wav = dir + "/sine.wav";
    writeSineWav(wav);

    NativeSamplerEngine native;
    auto audioOwned = std::make_unique<OfflineAudioOutput>(48000.0, 96U);
    auto midiOwned = std::make_unique<ManualMidiInput>();
    OfflineAudioOutput* audio = audioOwned.get();
    ManualMidiInput* midi = midiOwned.get();
    native.setBackends(std::move(audioOwned), std::move(midiOwned));

    CHECK(!native.nativeAudioNeedsRecovery());
    CHECK(native.nativeAudioOpen());
    CHECK(native.nativeAudioStart());
    CHECK(audio->running());
    const auto info = native.nativeAudioInfo();
    CHECK(info.size() == 7U);
    CHECK(info[0] == 48000);
    CHECK(info[1] == 96);
    CHECK(native.nativeLoadAudio(wav));

    // silence before any key
    CHECK(energy(audio->pump(4800)) < 1e-9);

    // key down -> sound
    midi->send(0x90, 69, 100);                       // A4 = the root of the sample
    const auto played = audio->pump(9600);
    CHECK(energy(played) > 1.0);
    for (const float x : played) CHECK(std::fabs(x) <= 1.0F);
    const auto meters = native.nativeMeters();
    CHECK(!meters.empty());
    CHECK(meters[0] > 0.01F || meters[1] > 0.01F);

    // SILVETON_TRANSWAVE_V1: AUTO makes the sound from frames of its own recording; MULTI takes the frames from other sounds (the built-in waves here)
    CHECK(native.nativeSetSoundWaveParam(0, 0, 1, 4.0F));
    CHECK(native.nativeSetSoundWaveParam(0, 0, 0, 1.0F));
    midi->send(0x90, 69, 100);
    const auto autoOut = audio->pump(9600);
    CHECK(energy(autoOut) > 1.0);
    midi->sendBytes({0x80, 69, 0});
    audio->pump(24000);
    CHECK(native.nativeSetSoundWaveParam(0, 0, 10, 9001.0F));   // SAW
    CHECK(native.nativeSetSoundWaveParam(0, 0, 11, 9005.0F));   // SINE
    CHECK(native.nativeSetSoundWaveParam(0, 0, 0, 2.0F));
    CHECK(native.nativeSetSoundWaveParam(0, 0, 2, 0.0F));
    midi->send(0x90, 69, 100);
    const auto sawOut = audio->pump(9600);
    CHECK(energy(sawOut) > 1.0);
    midi->sendBytes({0x80, 69, 0});
    audio->pump(24000);
    CHECK(!native.nativeSetSoundWaveParam(0, 0, 99, 1.0F));      // not a wave parameter
    {
        const auto wp = native.nativeSoundWaveParams(0, 0);
        CHECK(wp.size() == 18U && wp[0] == 2.0F && wp[10] == 9001.0F && wp[11] == 9005.0F);
    }
    CHECK(native.nativeSetSoundWaveParam(0, 0, 0, 0.0F));

    // key up through raw bytes -> the sound dies away
    midi->sendBytes({0x80, 69, 0});
    audio->pump(96000);
    CHECK(energy(audio->pump(4800)) < 1e-6);

    // the last MIDI message is remembered for the MIDI page
    const auto last = native.nativeMidiLastMessage();
    CHECK(last.size() == 3U);
    CHECK(last[0] == 0x80);

    // write the sound as a PROGRAM and a COMBI, save the whole set and read it back
    CHECK(native.nativeWriteProgram(0, 0, 0, 0, "TEST PROG"));
    CHECK(native.nativeWriteCombi(0, 0, 0, "TEST COMBI"));
    const std::string setPath = dir + "/test.SVSET";
    if (!native.nativeSaveSet(setPath)) std::fprintf(stderr, "save set: %s\n", native.nativeLastTextError().c_str());
    CHECK(native.nativeSaveSet(setPath));
    struct stat st{};
    CHECK(::stat(setPath.c_str(), &st) == 0 || ::stat((setPath + "/manifest.svs").c_str(), &st) == 0);
    CHECK(native.nativeLoadSet(setPath));
    midi->send(0x90, 69, 100);
    CHECK(energy(audio->pump(9600)) > 1.0);
    midi->send(0xB0, 123, 0);                        // all notes off
    midi->send(0xB0, 120, 0);                        // all sound off
    audio->pump(9600);

    // stop / start / close behave
    native.nativeAudioStop();
    CHECK(!audio->running());
    CHECK(native.nativeAudioStart());
    native.nativeAudioClose();
    CHECK(!audio->running());
    CHECK(native.nativeAudioInfo()[0] == 0);
    CHECK(native.nativeAudioRecover());              // nothing to recover
    CHECK(native.nativeAudioOpen());
    CHECK(native.nativeAudioStart());
    native.nativeAudioClose();

    std::string cmd = "rm -rf '" + dir + "'";
    CHECK(std::system(cmd.c_str()) == 0);
}

void testNoBackendsFallsBackToSilentDevices() {
    NativeSamplerEngine native;
    CHECK(native.nativeAudioOpen());                 // the platform default on Linux: silent offline output
    CHECK(native.nativeAudioStart());
    native.nativeAudioClose();
}

} // namespace

int main() {
    testMidiParser();
    testMidiDisconnectRelease();
    testGlobalRejectsNonFinite();
    testFailedWriteCheckpoint();
    testChain();
    testNoBackendsFallsBackToSilentDevices();
    std::puts("host tests passed");
    return 0;
}
