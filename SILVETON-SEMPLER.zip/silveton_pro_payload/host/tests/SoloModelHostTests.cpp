#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/sampler/SoloModel.h"
#include <cassert>
#include <fstream>
#include <cstdio>
#include <iostream>
using namespace silveton::host;
int main(){
 namespace so=silveton::sampler::solo;so::Model model;model.name="Teacher end-to-end";
 so::Cell c;c.at.phase=so::Phase::Sustain;c.at.key=69;c.at.ageMs=300;c.sound.db.fill(-90);c.sound.db[0]=0;c.sound.rmsDb=-18;c.count=3;model.cells.push_back(c);model.prepare();
 auto data=so::encodeModel(model);std::string path="/tmp/teacher_host_model.svsolo",set="/tmp/teacher_host_set.svset";std::ofstream f(path,std::ios::binary);f.write(reinterpret_cast<const char*>(data.data()),static_cast<std::streamsize>(data.size()));f.close();
 NativeSamplerEngine native;auto audio=std::make_unique<OfflineAudioOutput>(48000,96);auto*output=audio.get();auto midi=std::make_unique<ManualMidiInput>();auto*input=midi.get();native.setBackends(std::move(audio),std::move(midi));
 assert(native.nativeAudioOpen());assert(native.nativeAudioStart());assert(native.nativeLoadSoloModel(7,path));assert(native.nativeSoloModelName(7)==model.name);input->send(0x90,69,100);auto samples=output->pump(4800);double energy=0;for(float x:samples)energy+=x*x;assert(energy>1);input->send(0x80,69,0);output->pump(9600);
 assert(native.nativeSaveUserPerformanceState(set));assert(native.nativeLoadSoloModel(7,""));assert(native.nativeSoloModelName(7).empty());assert(native.nativeSetUpperEngineParam(7,0,0));assert(native.nativeLoadUserPerformanceState(set));assert(native.nativeSoloModelName(7)==model.name);
 assert(!native.nativeLoadSoloModel(7,path+"missing"));assert(native.nativeSoloModelName(7)==model.name); // failure never replaces a working model
 native.nativeAudioStop();native.nativeAudioClose();std::remove(path.c_str());std::remove(set.c_str());std::cout<<"PASS Teacher model -> native host -> MIDI -> audio -> automatic saved state -> restored model\n";
}
