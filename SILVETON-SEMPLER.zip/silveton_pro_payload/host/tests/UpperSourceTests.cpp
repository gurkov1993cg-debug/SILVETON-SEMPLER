#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/sampler/SoloModel.h"
#include "silveton/sampler/SoloDefs.h"
#include "silveton/sampler/SetPackage.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <unistd.h>
using namespace silveton::host;
using namespace silveton::sampler;
static double energy(const std::vector<float>& a){double x=0;for(float v:a){assert(std::isfinite(v));x+=v*v;}return x;}
int main(){
    NativeSamplerEngine n;auto output=std::make_unique<OfflineAudioOutput>(48000,128);auto* out=output.get();
    const auto addresses=n.nativeSoundCatalogAddresses();const auto names=n.nativeSoundCatalogNames();
    assert(addresses.size()==names.size()*3&&names.size()>=kBuiltinWaveCount);
    for(int i=0;i<kBuiltinWaveCount;++i){bool found=false;for(std::size_t j=2;j<addresses.size();j+=3)found|=addresses[j]==kBuiltinWaveFirstSlot+i;assert(found);}
    n.setBackends(std::move(output),std::make_unique<ManualMidiInput>());assert(n.nativeAudioOpen());assert(n.nativeAudioStart());
    solo::Model model;model.name="Upper source test";solo::Cell cell;cell.at.key=69;cell.at.phase=solo::Phase::Sustain;cell.at.ageMs=300;
    cell.sound.db.fill(-60);cell.sound.db[0]=0;cell.sound.db[2]=-9;cell.sound.rmsDb=-18;cell.count=1;model.cells.push_back(cell);model.prepare();
    const auto bytes=solo::encodeModel(model);const auto base=std::string("/tmp/silveton_upper_")+std::to_string(getpid());
    const auto path=base+".svsolo",set=base+".SVSET";
    {std::ofstream f(path,std::ios::binary);f.write(reinterpret_cast<const char*>(bytes.data()),bytes.size());}
    assert(n.nativeClearPerformance());
    // Every existing sound place can own a model. No bank sound is required.
    for(int sound=0;sound<5;++sound){
        assert(n.nativeLoadSoloSound(0,sound,path));const auto src=n.nativeSoundSource(0,sound);
        assert(src.soloModel&&src.commonProcessing&&src.name==model.name&&!src.program);
        if(sound>0)assert(n.nativeSetLayerParam(0,sound-1,13,20));
    }
    assert(n.nativeSetUpperToneParam(0,3,20));
    n.nativeMidi(0x90,69,100);assert(energy(out->pump(4800))>1);assert(n.nativeMeters().at(3)>=5);
    n.nativeMidi(0x80,69,0);out->pump(12000);assert(energy(out->pump(2400))<1e-8);
    // Layer-only synthesis shares the ordinary range, pan, filter and ADSR paths.
    assert(n.nativeClearPerformance());assert(n.nativeLoadSoloSound(0,2,path));
    assert(n.nativeSetLayerParam(0,1,6,65));assert(n.nativeSetLayerParam(0,1,7,75));assert(n.nativeSetLayerParam(0,1,2,-1));
    assert(n.nativeSetLayerParam(0,1,13,10));
    n.nativeMidi(0x90,50,100);assert(energy(out->pump(3000))<1e-9);n.nativeMidi(0x80,50,0);
    n.nativeMidi(0x90,69,100);auto a=out->pump(5000);double left=0,right=0;for(std::size_t i=0;i<a.size();i+=2){left+=a[i]*a[i];right+=a[i+1]*a[i+1];}assert(left>1&&right<left*.001);
    assert(n.nativeUpdateUpperMain(0,true,false,true,0,0,0,127,0));out->pump(2400);assert(energy(out->pump(2400))<1e-8);
    assert(n.nativeUpdateUpperMain(0,true,false,false,0,0,0,127,0));assert(energy(out->pump(4800))>1);
    n.nativeMidi(0x80,69,0);out->pump(6000);assert(energy(out->pump(2400))<1e-8);
    assert(n.nativeSetLayerParam(0,1,14,100));n.nativeMidi(0x90,69,100);auto filtered=energy(out->pump(4800));n.nativeMidi(0x80,69,0);out->pump(6000);
    assert(n.nativeSetLayerParam(0,1,14,20000));n.nativeMidi(0x90,69,100);auto open=energy(out->pump(4800));assert(filtered<open*.2);n.nativeMidi(0x80,69,0);out->pump(6000);
    const auto source=n.nativeSoundSource(0,2);assert(n.nativeSetSoundSource(1,4,source));assert(n.nativeSetSoundEngineParam(1,4,solo::Brightness,.73F));
    assert(n.nativeSaveUserPerformanceState(set));assert(n.nativeClearPerformance());assert(n.nativeReplaceUserPerformanceState(set));
    assert(n.nativeSoundSource(0,2).soloModel&&n.nativeSoundSource(1,4).soloModel);
    assert(std::abs(n.nativeSoundSource(1,4).engine.p[solo::Brightness]-.73F)<1e-6);
    assert(n.nativeLayerParams(0,1)[6]==65&&n.nativeLayerParams(0,1)[7]==75);
    assert(n.nativeSetLayerSound(0,1,9001));assert(!n.nativeSoundSource(0,2).soloModel&&!n.nativeSoundSource(0,2).engine.chosen());
    // All 35 existing positions can sound; the same preallocated voice pool is used.
    n.nativePanic();out->pump(512);assert(n.nativeClearPerformance());
    for(int u=0;u<7;++u)for(int s=0;s<5;++s){assert(n.nativeLoadSoloSound(u,s,path));if(s>0){assert(n.nativeSetLayerParam(u,s-1,6,0));assert(n.nativeSetLayerParam(u,s-1,7,127));}}
    n.nativeMidi(0x90,69,100);assert(energy(out->pump(3000))>1);assert(n.nativeMeters().at(3)>=35);
    n.nativeAudioStop();n.nativeAudioClose();std::remove(path.c_str());std::remove(set.c_str());
    std::cout<<"PASS shared MAIN/L1-L4 sources, mute, ranges, pan, release, filter, replace, copy and SET roundtrip; 35 source positions\n";
}
