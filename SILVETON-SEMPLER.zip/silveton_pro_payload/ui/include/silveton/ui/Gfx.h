#pragma once
// SILVETON_MAC_GFX_V1 - the drawing layer of the Mac sampler.
// A small software renderer with the same vocabulary as the tablet's Android Canvas / Paint / Path / Shader, so the
// screens could be carried over one to one. It draws into a plain pixel buffer (premultiplied BGRA, 0xAARRGGBB),
// which the Mac shell shows in its window and the tests write to PNG files. No system drawing library is used,
// so a picture is the same on the iMac and on the Linux test machine.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace silveton::ui {

// ------------------------------------------------------------------ colours (Android style: 0xAARRGGBB)
using ColorInt = std::uint32_t;

struct Color {
    static constexpr ColorInt argb(int a, int r, int g, int b) noexcept {
        return (static_cast<ColorInt>(a & 255) << 24) | (static_cast<ColorInt>(r & 255) << 16) |
               (static_cast<ColorInt>(g & 255) << 8) | static_cast<ColorInt>(b & 255);
    }
    static constexpr ColorInt rgb(int r, int g, int b) noexcept { return argb(255, r, g, b); }
    static constexpr int alpha(ColorInt c) noexcept { return static_cast<int>((c >> 24) & 255U); }
    static constexpr int red(ColorInt c) noexcept { return static_cast<int>((c >> 16) & 255U); }
    static constexpr int green(ColorInt c) noexcept { return static_cast<int>((c >> 8) & 255U); }
    static constexpr int blue(ColorInt c) noexcept { return static_cast<int>(c & 255U); }
    static constexpr ColorInt WHITE = 0xFFFFFFFFU;
    static constexpr ColorInt BLACK = 0xFF000000U;
    static constexpr ColorInt TRANSPARENT = 0x00000000U;
};

// ------------------------------------------------------------------ geometry
struct RectF {
    float left{0.0F}, top{0.0F}, right{0.0F}, bottom{0.0F};
    RectF() = default;
    RectF(float l, float t, float r, float b) : left(l), top(t), right(r), bottom(b) {}
    [[nodiscard]] float width() const noexcept { return right - left; }
    [[nodiscard]] float height() const noexcept { return bottom - top; }
    [[nodiscard]] float centerX() const noexcept { return (left + right) * 0.5F; }
    [[nodiscard]] float centerY() const noexcept { return (top + bottom) * 0.5F; }
    // Android: left <= x < right, top <= y < bottom
    [[nodiscard]] bool contains(float x, float y) const noexcept { return x >= left && x < right && y >= top && y < bottom; }
    [[nodiscard]] bool isEmpty() const noexcept { return !(left < right && top < bottom); }
    void set(float l, float t, float r, float b) noexcept { left = l; top = t; right = r; bottom = b; }
    void inset(float dx, float dy) noexcept { left += dx; top += dy; right -= dx; bottom -= dy; }
    void offset(float dx, float dy) noexcept { left += dx; top += dy; right += dx; bottom += dy; }
};

// whole pixels: left <= x < right, top <= y < bottom
struct IRect {
    int left{0}, top{0}, right{0}, bottom{0};
    IRect() = default;
    IRect(int l, int t, int r, int b) : left(l), top(t), right(r), bottom(b) {}
    [[nodiscard]] int width() const noexcept { return right - left; }
    [[nodiscard]] int height() const noexcept { return bottom - top; }
    [[nodiscard]] bool isEmpty() const noexcept { return !(left < right && top < bottom); }
    [[nodiscard]] long long area() const noexcept { return isEmpty() ? 0LL : static_cast<long long>(width()) * static_cast<long long>(height()); }
    [[nodiscard]] bool intersects(const IRect& o) const noexcept { return left < o.right && o.left < right && top < o.bottom && o.top < bottom; }
    [[nodiscard]] IRect united(const IRect& o) const noexcept {
        if (isEmpty()) return o;
        if (o.isEmpty()) return *this;
        return IRect(std::min(left, o.left), std::min(top, o.top), std::max(right, o.right), std::max(bottom, o.bottom));
    }
    [[nodiscard]] IRect intersected(const IRect& o) const noexcept {
        return IRect(std::max(left, o.left), std::max(top, o.top), std::min(right, o.right), std::min(bottom, o.bottom));
    }
    bool operator==(const IRect& o) const noexcept { return left == o.left && top == o.top && right == o.right && bottom == o.bottom; }
};

// ------------------------------------------------------------------ paint
enum class Style { Fill, Stroke, FillAndStroke };
enum class Cap { Butt, Round, Square };
enum class Align { Left, Center, Right };
enum class Face { Regular, Bold, Mono, MonoBold };
enum class TileMode { Clamp, Repeat };

class Shader {
public:
    enum class Kind { Linear, Radial, Sweep };
    Kind kind{Kind::Linear};
    float x0{0.0F}, y0{0.0F}, x1{0.0F}, y1{0.0F};   // linear: from-to
    float cx{0.0F}, cy{0.0F}, radius{1.0F};          // radial / sweep centre
    std::vector<ColorInt> colors;
    std::vector<float> positions;                    // empty = evenly spread
    TileMode tile{TileMode::Clamp};

    // Colour (premultiplied BGRA) of this shader at a point of the shader's own space.
    [[nodiscard]] ColorInt colorAt(float x, float y) const noexcept;
    // 0..1 position along the gradient of a point (before tiling)
    [[nodiscard]] float parameterAt(float x, float y) const noexcept;
    [[nodiscard]] ColorInt colorForParameter(float t) const noexcept;   // unpremultiplied ARGB
};
using ShaderPtr = std::shared_ptr<const Shader>;

ShaderPtr linearGradient(float x0, float y0, float x1, float y1, ColorInt c0, ColorInt c1, TileMode tile = TileMode::Clamp);
ShaderPtr linearGradient(float x0, float y0, float x1, float y1, const std::vector<ColorInt>& colors,
                         const std::vector<float>& positions, TileMode tile = TileMode::Clamp);
ShaderPtr radialGradient(float cx, float cy, float radius, ColorInt c0, ColorInt c1, TileMode tile = TileMode::Clamp);
ShaderPtr radialGradient(float cx, float cy, float radius, const std::vector<ColorInt>& colors,
                         const std::vector<float>& positions, TileMode tile = TileMode::Clamp);
ShaderPtr sweepGradient(float cx, float cy, const std::vector<ColorInt>& colors, const std::vector<float>& positions);

struct Paint {
    ColorInt color{Color::BLACK};
    Style style{Style::Fill};
    float strokeWidth{0.0F};
    Cap strokeCap{Cap::Butt};
    Align textAlign{Align::Left};
    float textSize{12.0F};
    Face typeface{Face::Regular};
    float letterSpacing{0.0F};      // in em, like Android's Paint.letterSpacing
    ShaderPtr shader{};
    bool antiAlias{true};

    // Width of the text as it would be drawn (advance of the letters + the letter spacing).
    [[nodiscard]] float measureText(const std::string& utf8) const;
    // Width of the first `count` letters (code points), starting at letter `from`.
    [[nodiscard]] float measureText(const std::string& utf8, int from, int count) const;
};

// ------------------------------------------------------------------ path (lines only, as the screens use it)
class Path {
public:
    void reset() { contours_.clear(); }
    void moveTo(float x, float y);
    void lineTo(float x, float y);
    void close();
    [[nodiscard]] bool isEmpty() const noexcept { return contours_.empty(); }

    struct Contour {
        std::vector<float> xy;   // x0,y0,x1,y1 ...
        bool closed{false};
    };
    [[nodiscard]] const std::vector<Contour>& contours() const noexcept { return contours_; }

private:
    std::vector<Contour> contours_;
};

// ------------------------------------------------------------------ images
struct Image {
    int width{0};
    int height{0};
    std::vector<std::uint32_t> pixels;   // premultiplied 0xAARRGGBB
};

// ------------------------------------------------------------------ what a draw call comes down to
namespace detail {
struct Matrix {
    float a{1.0F}, b{0.0F}, c{0.0F}, d{1.0F}, e{0.0F}, f{0.0F};   // x' = a x + c y + e ; y' = b x + d y + f
};
struct Poly {
    std::vector<float> xy;    // device space
};
// One raster operation of a picture: the geometry is already in device pixels, the colour source and the clip are fixed.
// A picture is a list of these; two pictures are compared operation by operation to find what changed (see FrameRenderer).
struct RasterOp {
    enum class Kind : std::uint8_t { Clear, Rect, Polys, Image };
    Kind kind{Kind::Polys};
    int clipL{0}, clipT{0}, clipR{0}, clipB{0};     // clip rectangle (device pixels)
    int areaL{0}, areaT{0}, areaR{0}, areaB{0};     // the pixels the operation can change (inside the clip)
    bool useShader{false};
    int alpha255{255};                              // paint alpha (applied to shader colours)
    std::uint32_t solid{0U};                        // premultiplied colour (Clear: the colour)
    ShaderPtr shader;
    Matrix inverse;                                 // device -> shader space (only with a shader)
    float rx0{0.0F}, ry0{0.0F}, rx1{0.0F}, ry1{0.0F};   // Rect / Image: destination in device space
    std::vector<Poly> polys;
    const Image* image{nullptr};                    // only valid while the picture is being drawn
    std::uint64_t hash{0U};                         // of everything above that changes a pixel
};
using DisplayList = std::vector<RasterOp>;
} // namespace detail

// ------------------------------------------------------------------ canvas
class Canvas {
public:
    // recordOnly: the canvas has no pixels; the draw calls are only written to a list (see beginRecording)
    Canvas(int width, int height, bool recordOnly = false);

    [[nodiscard]] int width() const noexcept { return width_; }
    [[nodiscard]] int height() const noexcept { return height_; }
    [[nodiscard]] const std::uint32_t* pixels() const noexcept { return pixels_.data(); }
    [[nodiscard]] std::uint32_t* pixels() noexcept { return pixels_.data(); }
    [[nodiscard]] const std::vector<std::uint32_t>& buffer() const noexcept { return pixels_; }
    Image takeImage();                                // moves the picture out (the canvas is empty afterwards)
    void clear(ColorInt color);

    void save();
    void restore();
    void translate(float dx, float dy);
    void scale(float sx, float sy);
    void rotate(float degrees, float px = 0.0F, float py = 0.0F);
    void clipRect(const RectF& r);                    // only without rotation

    void drawRect(const RectF& r, const Paint& paint);
    void drawRoundRect(const RectF& r, float rx, float ry, const Paint& paint);
    void drawCircle(float cx, float cy, float radius, const Paint& paint);
    void drawLine(float x0, float y0, float x1, float y1, const Paint& paint);
    void drawArc(const RectF& oval, float startDegrees, float sweepDegrees, bool useCenter, const Paint& paint);
    void drawPath(const Path& path, const Paint& paint);
    void drawText(const std::string& utf8, float x, float y, const Paint& paint);
    void drawImage(const Image& image, const RectF& dst, const Paint& paint);

    // ---- recording and replay (the "light drawing": only the parts of a picture that changed are drawn again)
    // While recording, the draw calls do not touch pixels; they are appended to `list`.
    void beginRecording(detail::DisplayList* list);
    void endRecording();
    // Back to the beginning of a picture: no clip, no transformation, nothing saved.
    void resetState();
    // Draws the operations of a list into the pixels, but only inside `window`: that part is cleared first. The result in
    // the window is exactly what drawing the whole list would give there.
    void replay(const detail::DisplayList& list, const IRect& window);

private:
    using Matrix = detail::Matrix;
    using Poly = detail::Poly;
    using RasterOp = detail::RasterOp;
    struct State {
        Matrix m;
        int clipL{0}, clipT{0}, clipR{0}, clipB{0};
    };
    struct SourceSetup {
        bool useShader{false};
        int alpha255{255};
        std::uint32_t solid{0U};
        ShaderPtr shader;
        Matrix inverse;
    };

    // draw call -> operation
    bool prepareSource(const Paint& paint);
    void emitPolys(std::vector<Poly>& polys);
    void emitRect(const RectF& deviceRect);
    void submit(RasterOp&& op);
    void takeSource(RasterOp& op) const;
    // operation -> pixels
    void rasterize(const RasterOp& op);
    void rasterPolys(const RasterOp& op);
    void rasterRect(const RasterOp& op);
    void rasterImage(const RasterOp& op);
    void blendPixel(int x, int y, float coverage);
    void fillSpan(int y, int x0, int x1, int cov255);   // pixels [x0, x1) of one row, all with the same coverage (0..255)
    void prepareLut();                                  // gradient lookup table for the current operation
    [[nodiscard]] std::uint32_t sourceAt(int x, int y);  // premultiplied colour of the current source (paint alpha applied)

    void strokeLinePolys(const float* xy, int pointCount, bool closed, float width, Cap cap, std::vector<Poly>& out) const;
    void addCircle(std::vector<Poly>& out, float cx, float cy, float rx, float ry, bool reverse) const;
    void addRoundRect(std::vector<Poly>& out, const RectF& r, float rx, float ry, bool reverse) const;
    void addArcBand(std::vector<Poly>& out, float cx, float cy, float rx, float ry, float startRad, float sweepRad,
                    float halfWidth, Cap cap) const;
    void mapPoint(float x, float y, float& ox, float& oy) const noexcept;
    [[nodiscard]] bool isAxisAligned() const noexcept;
    [[nodiscard]] float uniformScale() const noexcept;
    [[nodiscard]] ColorInt shaderPixel(const Shader& s, int x, int y) const noexcept;

    int width_{0};
    int height_{0};
    std::vector<std::uint32_t> pixels_;
    std::vector<State> stack_;
    State state_;
    std::vector<float> accumulation_;
    SourceSetup src_;                 // the source of the draw call in progress
    Matrix inverse_;                  // device -> shader space of the operation being drawn
    detail::DisplayList* recording_{nullptr};
    IRect window_;                    // the pixels that may be changed now (the whole canvas, or a part while replaying)
    const Shader* hashedShader_{nullptr};
    std::uint64_t hashedShaderValue_{0U};
    friend struct CanvasInternals;
};

// ------------------------------------------------------------------ light drawing
// Keeps a finished picture and, for each new picture, draws again only what is different:
//  1. the screens draw into a recording canvas (the draw calls become a list of raster operations, nothing is drawn yet);
//  2. the list is compared with the previous one (equal operations in the same place cost nothing);
//  3. only the changed areas are drawn into the picture, and those areas are reported, so that the shell can show just them.
// The result is exactly the picture that drawing everything would give.
class FrameRenderer {
public:
    FrameRenderer(int width, int height);
    ~FrameRenderer();
    FrameRenderer(const FrameRenderer&) = delete;
    FrameRenderer& operator=(const FrameRenderer&) = delete;

    [[nodiscard]] int width() const noexcept;
    [[nodiscard]] int height() const noexcept;
    [[nodiscard]] const Canvas& picture() const noexcept;     // the finished picture (complete after every update)
    // Draws one picture with `draw` (it gets a recording canvas of the same size). Returns the changed areas;
    // empty = the picture is the same as before. The first picture, and the first one after invalidate(), is all new.
    const std::vector<IRect>& update(const std::function<void(Canvas&)>& draw);
    [[nodiscard]] const std::vector<IRect>& changed() const noexcept;   // the result of the last update
    [[nodiscard]] IRect changedBounds() const noexcept;                 // one rectangle around all of them
    void invalidate();                                                  // the next picture is drawn completely
    // for tests and the measurements
    [[nodiscard]] const detail::DisplayList& lastList() const noexcept;
    [[nodiscard]] std::size_t lastOperationCount() const noexcept;
    [[nodiscard]] long long lastRepaintedPixels() const noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// ------------------------------------------------------------------ fonts and helpers
// Where the font files (Roboto, DejaVu) are. Must be set once before any text is measured or drawn.
void setFontDirectory(const std::string& directory);
// Is the font data available (the files were found)?
bool fontsReady();

// UTF-8 helpers (the screens work with UTF-8 strings; Cyrillic is 2 bytes per letter)
int utf8Length(const std::string& s);                              // number of code points
std::string utf8Prefix(const std::string& s, int codePoints);      // first n code points
std::string utf8Substring(const std::string& s, int from, int to); // code points [from, to)
std::string utf8Upper(const std::string& s);                       // Latin + Cyrillic upper case

// Writes the picture as a PNG (RGB, no alpha) - for the tests and the screenshots.
bool writePng(const std::string& path, const Canvas& canvas);
bool writePng(const std::string& path, const Image& image);

} // namespace silveton::ui
