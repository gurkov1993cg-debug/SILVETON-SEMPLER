#pragma once
// SILVETON_MAC_CONTROLLER_V1 - the Mac copy of the tablet's SamplerAppController (same names, same behaviour).
// It holds no screens: it sits between the screens and the sound engine, keeps the LIST / COMBI / SET files in the
// tablet's formats and remembers the small settings. Android-only parts (root, Direct ALSA, storage permissions,
// SharedPreferences) are replaced by the Mac ones: CoreAudio / CoreMIDI (inside the engine), folders, a settings file.

#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/ui/Support.h"

namespace silveton::ui {

// The part of the start-up that belongs to one kind of device and is not needed on the Mac: on the tablet it is the root
// set-up (SELinux, device permissions, CPU cores, realtime threads). Every call may take seconds, so the controller makes
// them only on the thread that starts and recovers the sound, never on the thread that draws.
class PlatformRuntime {
public:
    struct Result {
        bool ok{true};
        std::string message;
    };
    virtual ~PlatformRuntime() = default;
    virtual Result enter() { return {}; }                          // before the sound output is opened
    virtual Result refreshAudioPermissions() { return {}; }
    virtual Result refreshMidiPermissions() { return {}; }
    virtual Result refreshBankStorageAccess() { return {}; }       // all-files access for SILVETON_BANK.sv
    virtual void audioStarted() {}                                 // the sound threads exist now: lift them to realtime
    virtual void leave() {}                                        // the program ends: give the device back
    // Text for the red bar when the bank file is not found (empty = the standard text).
    virtual std::string bankNotFoundMessage(const Result& storageAccess) const { (void)storageAccess; return {}; }
};

// What the shell tells the controller about its surroundings.
struct ControllerEnv {
    std::string dataDir;                                   // private folder: settings file, safety copy of BLENDS
    std::vector<std::string> bankCandidates;              // where SILVETON_BANK.sv may be (first readable one wins)
    std::function<void(const std::string&)> statusChanged;     // text for the red warning bar; empty text = clear it
    std::function<void(int)> midiConnectionChanged;           // number of connected MIDI keyboards
    std::shared_ptr<PlatformRuntime> platform;                // optional: the root set-up of the tablet
    std::vector<std::string> olderStateCopies;                // older places of the BLENDS file, tried last when it is missing
};

class SamplerAppController {
public:
    static constexpr int TONE_ATTACK = 0;
    static constexpr int TONE_DECAY = 1;
    static constexpr int TONE_SUSTAIN = 2;
    static constexpr int TONE_RELEASE = 3;
    static constexpr int TONE_CUTOFF = 4;
    static constexpr int TONE_RESONANCE = 5;
    static constexpr float TONE_MAX_TIME_MS = 20000.0F;
    static constexpr float TONE_CUTOFF_OPEN_HZ = 20000.0F;
    static const std::vector<std::string>& TERCA_CELLS();
    static const std::vector<std::string>& NOTE_NAMES();

    struct MidiStatus {
        int deviceCount{0};
        int lastError{0};
        long long activitySerial{0};
        int status{0};
        int data1{0};
        int data2{0};
    };

    struct AudioStatus {
        int sampleRate{0};
        int framesPerBurst{0};
        int bufferSizeFrames{0};
        int xrunCount{0};
        int sharingMode{-1};
        int performanceMode{-1};
        int deviceId{-1};
        double estimatedLatencyMs{-1.0};
        float peakLeft{0.0F};
        float peakRight{0.0F};
        float limiterGainReductionDb{0.0F};
        int activeVoices{0};
        int droppedRealtimeEvents{0};
        float cpuLoadPercent{0.0F};
        int coresWorking{1};
    };

    struct SoundItem {
        int bank{0};
        int page{0};
        int slot{0};
        std::string name;
    };

    struct UpperState {
        bool enabled{false}, solo{false}, mute{false};
        float levelDb{0.0F}, pan{0.0F};
        int keyLow{0}, keyHigh{127};
        int velocityLow{1}, velocityHigh{127};
        int voiceMode{0};
        int octave{0}, transpose{0};
        float fineCents{0.0F};
        int pitchBendRange{2};
        float portamentoSec{0.0F};
        bool breath{false}, expression{false}, aftertouch{false}, damper{false};
        int midiChannel{0};
        float attackScale{1.0F}, decayScale{1.0F}, sustainScale{1.0F}, releaseScale{1.0F};
        float cutoffOctaves{0.0F}, resonanceOffset{0.0F}, lfoRateScale{1.0F}, lfoDepthScale{1.0F};
        float eqLowDb{0.0F}, eqMidDb{0.0F}, eqHighDb{0.0F};
        float fxSend1{0.0F}, fxSend2{0.0F};
        std::string soundName;
        // TONE page (absolute values). toneSet bit k = the Upper has its own value, otherwise the PROGRAM default is shown.
        float toneAttackMs{5.0F}, toneDecayMs{80.0F}, toneSustain{1.0F};
        float toneReleaseMs{120.0F}, toneCutoffHz{20000.0F}, toneResonance{0.0F};
        int toneSet{0};
    };

    struct FxState {
        int type{0};
        float wet{0.0F}, timeMs{0.0F}, feedback{0.0F}, rateHz{0.0F}, depth{0.0F}, tone{0.0F};
    };

    struct CombiFxState {
        FxState fx1;
        FxState fx2;
        int routing{0};
    };

    struct GlobalUiState {
        float masterTuneHz{440.0F};
        int transpose{0};
        float masterGainDb{0.0F};
        float eqLowDb{0.0F}, eqMidDb{0.0F}, eqHighDb{0.0F};
        bool limiterEnabled{false};
        float limiterCeilingDb{0.0F};
        int velocityCurve{0};
        int breathCc{2}, expressionCc{11}, damperCc{64};
        bool pitchBendEnabled{true}, aftertouchEnabled{true};
    };

    struct TercaState {
        int root{-1};
        int cell{-1};
    };

    struct GlobalAdvanced {
        int scaleRoot{0};
        std::vector<float> scaleCents;
        int midiInMask{0xFFFF};
        bool filterNotes{false}, filterCc{false}, filterBend{false}, filterAftertouch{false};
        float breathMin{0.0F}, breathMax{1.0F}, breathCurve{0.0F};
        float expressionMin{0.0F}, expressionMax{1.0F}, expressionCurve{0.0F};
        bool damperReversed{false};
    };

    struct ListItem {
        int number{0};
        std::string name;
        int combiBank{0};
        int combiPage{0};
        int combiSlot{0};
    };

    struct BankSound {
        int slot{0};
        std::string name;
        int samples{0};
        long long bytes{0};
    };

    struct BankInfo {
        std::string path;
        int sounds{0};
        int samples{0};
        long long audioBytes{0};
        long long fileBytes{0};
        std::vector<BankSound> list;
    };

    explicit SamplerAppController(ControllerEnv env);
    ~SamplerAppController();
    SamplerAppController(const SamplerAppController&) = delete;
    SamplerAppController& operator=(const SamplerAppController&) = delete;

    host::NativeSamplerEngine engine;

    // ---- settings kept between sessions
    int portaBalance() const { return portaBalanceValue_; }
    void setPortaBalance(int value, bool save = true);
    int voiceCeiling() const { return voiceCeilingValue_; }
    void setVoiceCeiling(int voices, bool save = true);
    int portaNear() const { return portaNearValue_; }
    void setPortaNear(int value, bool save = true);
    bool themeDark() const;
    void setThemeDark(bool dark);
    std::set<int> listFavourites() const;
    void saveListFavourites(const std::set<int>& favs);
    std::set<int> soundFavourites() const;
    void saveSoundFavourites(const std::set<int>& favs);
    std::vector<int> recentSounds() const;
    void rememberRecentSound(int slot);

    // ---- key range scan / TERCA / Q
    int keyScanUpper() const { return keyScanUpper_; }
    void startKeyScan(int upper);
    void cancelKeyScan();
    TercaState tercaState() const { return {tercaRoot_, tercaCell_}; }
    bool tercaOn(int upper) const;
    bool quarterOn(int upper) const;
    bool tercaChosen(int upper) const;
    bool quarterChosen(int upper) const;
    int quarterNotes() const { return scaleMask_; }
    bool tercaMasterOn() const { return tercaMaster_ && tercaUppers_ != 0; }
    bool scaleMasterOn() const { return scaleMaster_ && scaleUppers_ != 0; }
    bool hasTercaUppers() const { return tercaUppers_ != 0; }
    bool hasScaleUppers() const { return scaleUppers_ != 0; }
    void toggleTerca(int upper);
    void toggleQuarter(int upper);
    void toggleTercaMaster();
    void toggleScaleMaster();
    int pollScan();
    void startTercaScan();
    void startScaleScan();
    void cancelScan();
    std::vector<float> scaleCents() const;

    // ---- advanced GLOBAL
    std::optional<GlobalAdvanced> globalAdvanced();
    bool updateGlobalAdvanced(const GlobalAdvanced& a);
    bool stepGlobalTranspose(int step);

    // ---- life cycle
    bool start();
    void pauseAudio();
    bool resumeAudio();
    void close();
    // Called about four times a second from the shell: audio recovery and MIDI connection news (the tablet's two helper threads).
    void housekeeping();
    // The user chose another SILVETON_BANK.sv: remember it and load it.
    bool useBankFile(const std::string& path);
    // Grows every time a bank has been loaded (the screens then read everything again; on the tablet the bank loads before the first touch).
    int bankSerial() const { return bankSerial_.load(); }

    MidiStatus midiStatus();
    bool audioRunning();
    int audioLastError();
    bool testInstrumentEnabled();
    bool testEpNoteOn(int note = 60, int velocity = 110);
    void testEpNoteOff(int note = 60);
    bool panic();

    // ---- lists and catalogs
    std::vector<ListItem> listItems(int bank, int page, int slot);
    int activeListEntry(int bank, int page, int slot);
    bool activateListEntry(int bank, int page, int slot, int index);
    bool isEmptyListItem(const ListItem* item) const;
    bool isEmptyListItem(const ListItem& item) const { return isEmptyListItem(&item); }
    bool renameLiveListEntry(int index, const std::string& name);
    bool deleteLiveListEntry(int index);
    bool copyListEntryTo(int from, int to);
    bool moveListEntryTo(int from, int to);
    bool moveLiveListEntry(int fromIndex, int toIndex);
    bool copyLiveListEntry(const ListItem& item, int insertIndex);
    bool writeCombiSlot(int slot, const std::string& name);
    int firstFreeCombiSlot();
    int writeCombiToList(int position, const std::string& name);
    bool activateCombiAddress(int bank, int page, int slot);
    bool addCombiToList(int combiSlot, const std::string& name);
    std::vector<std::pair<int, std::string>> multisampleCatalog();
    std::vector<std::pair<int, std::string>> combiCatalog();
    std::vector<SoundItem> soundCatalog();

    // ---- bank info / sets
    std::optional<BankInfo> bankInfo();
    std::optional<std::string> deleteBankSounds(const std::vector<int>& slots);   // nullopt = done, else the reason
    std::string setsFolders() const;
    std::vector<std::string> savedSets();
    bool setExists(const std::string& name);
    std::optional<std::string> saveSetAs(const std::string& name);                // nullopt = saved, else the reason
    std::optional<std::string> loadSavedSet(const std::string& name);

    // ---- generic parameters
    bool setUpperParam(int upper, int id, float value);
    std::vector<float> upperParams(int upper);
    bool setLayerParam(int upper, int layer, int id, float value);
    bool setLayerSound(int upper, int layer, int slot);
    std::vector<float> layerParams(int upper, int layer);
    std::string layerName(int upper, int layer);
    bool setFxParam(int unit, int id, float value);
    std::vector<float> fxParams(int unit);
    std::vector<float> analyzerFrame(int upper, bool afterEq);
    bool setSoundSynthParam(int upper, int sound, int id, float value);
    std::vector<float> soundSynthParams(int upper, int sound);

    // ---- status
    std::vector<std::pair<float, float>> upperMeters();
    AudioStatus audioStatus();
    std::string combiName();
    std::string bankLoadError();

    // ---- Uppers
    std::optional<UpperState> upperState(int upper);
    bool setUpperTone(int upper, int param, float value);
    bool assignUpperSound(int upper, const SoundItem& item);
    bool clearUpperSound(int upper);
    bool updateUpperMain(int upper, const UpperState& s);
    bool updateUpperTune(int upper, const UpperState& s);
    bool updateUpperRange(int upper, const UpperState& s);
    bool updateUpperControl(int upper, const UpperState& s);
    bool updateUpperTone(int upper, const UpperState& s);
    bool updateUpperFx(int upper, const UpperState& s);
    std::optional<CombiFxState> combiFxState();
    bool updateCombiFx(int slot, const FxState& fx);
    bool updateCombiFxRouting(int routing);
    std::optional<GlobalUiState> globalUiState();
    std::optional<float> nudgeMasterGain(float stepDb);
    bool updateGlobalUi(const GlobalUiState& s);

private:
    bool nativeResult(bool ok);
    bool fail(const std::string& message);
    void status(const std::string& message) { if (env_.statusChanged) env_.statusChanged(message); }
    void startBankLoad();
    void loadDefaultBankOnce();
    int bankSoundCount();
    bool applyBankFile(const std::string& path);
    void applyScale();
    void applyScaleUppers();
    void applyTerca();
    void saveTercaScale();
    std::string bankDir();
    std::string userStateFile();
    std::string privateStateFile() const;
    std::string bankFile();
    bool saveUserState();
    bool persistLiveListEdits() { return saveUserState(); }
    bool setPresent(const std::string& f) const;
    bool copySet(const std::string& src, const std::string& dst) const;
    void backupUserState();
    void restoreUserStateIfMissing();
    bool renumberLiveList();
    bool ensureListLength(int count);
    bool trimListTail();
    std::string setFileName(const std::string& name) const;
    std::string setsDir();
    std::string setFile(const std::string& name);

    ControllerEnv env_;
    Prefs prefs_;
    std::atomic<bool> started_{false};
    std::atomic<bool> closed_{false};
    std::atomic<bool> bankLoading_{false};
    std::atomic<int> bankSerial_{0};
    bool defaultBankAttempted_{false};
    std::thread bankThread_;
    std::mutex bankThreadMutex_;
    int portaBalanceValue_{11};
    int voiceCeilingValue_{48};
    int portaNearValue_{90};
    int keyScanUpper_{-1};
    int lastKeySerial_{-1};
    int tercaUppers_{0}, scaleUppers_{0}, tercaRoot_{-1}, tercaCell_{-1}, scaleMask_{0};
    bool tercaMaster_{true}, scaleMaster_{true};
    int lastTercaSerial_{-1}, lastScaleSerial_{-1};
    std::mutex bankPathMutex_;
    std::string bankPath_;
    // life-cycle helper state (the tablet's runtime / midi status threads)
    bool runtimeRunning_{false};
    std::int64_t lastRecoveryPollMs_{0};
    std::int64_t lastMidiPermissionMs_{0};
    int lastMidiConnectionCount_{-1};
    int lastMidiError_{0};
};

} // namespace silveton::ui
