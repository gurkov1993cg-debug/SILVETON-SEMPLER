#pragma once
// SILVETON_MAC_CONTROLLER_V1 - the Mac copy of the tablet's SamplerAppController (same names, same behaviour).
// It holds no screens: it sits between the screens and the sound engine, keeps the LIST / COMBI / SET files in the
// tablet's formats and remembers the small settings. Android-only parts (root, Direct ALSA, storage permissions,
// SharedPreferences) are replaced by the Mac ones: CoreAudio / CoreMIDI (inside the engine), folders, a settings file.

#include <array>
#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "silveton/host/NativeSamplerEngine.h"
#include "silveton/sampler/UserWaves.h"
#include "silveton/ui/Support.h"

namespace silveton::ui {

// The part of the start-up that belongs to one kind of device and is not needed on the Mac: on the tablet it is the root
// set-up (SELinux, device permissions, CPU cores, realtime threads). Every call may take seconds, so the controller makes
// them only on the thread that starts and recovers the sound, never on the thread that draws.
class PlatformRuntime {
public:
    struct Result {
        bool ok{true};
        std::string message;
    };
    virtual ~PlatformRuntime() = default;
    virtual Result enter() { return {}; }                          // before the sound output is opened
    virtual Result refreshAudioPermissions() { return {}; }
    virtual Result refreshMidiPermissions() { return {}; }
    virtual Result refreshBankStorageAccess() { return {}; }       // all-files access for SILVETON_BANK.sv
    virtual void audioStarted() {}                                 // the sound threads exist now: lift them to realtime
    virtual void leave() {}                                        // the program ends: give the device back
    // Text for the red bar when the bank file is not found (empty = the standard text).
    virtual std::string bankNotFoundMessage(const Result& storageAccess) const { (void)storageAccess; return {}; }
};

// What the shell tells the controller about its surroundings.
struct ControllerEnv {
    std::string dataDir;                                   // private folder: settings file, safety copy of BLENDS
    std::vector<std::string> bankCandidates;              // where SILVETON_BANK.sv may be (first readable one wins)
    std::function<void(const std::string&)> statusChanged;     // text for the red warning bar; empty text = clear it
    std::function<void(int)> midiConnectionChanged;           // number of connected MIDI keyboards
    std::shared_ptr<PlatformRuntime> platform;                // optional: the root set-up of the tablet
    std::vector<std::string> olderStateCopies;                // older places of the BLENDS file, tried last when it is missing
};

class SamplerAppController {
public:
    static constexpr int TONE_ATTACK = 0;
    static constexpr int TONE_DECAY = 1;
    static constexpr int TONE_SUSTAIN = 2;
    static constexpr int TONE_RELEASE = 3;
    static constexpr int TONE_CUTOFF = 4;
    static constexpr int TONE_RESONANCE = 5;
    static constexpr float TONE_MAX_TIME_MS = 20000.0F;
    static constexpr float TONE_CUTOFF_OPEN_HZ = 20000.0F;
    static const std::vector<std::string>& TERCA_CELLS();
    static const std::vector<std::string>& NOTE_NAMES();

    struct MidiStatus {
        int deviceCount{0};
        int lastError{0};
        long long activitySerial{0};
        int status{0};
        int data1{0};
        int data2{0};
    };

    struct AudioStatus {
        int sampleRate{0};
        int framesPerBurst{0};
        int bufferSizeFrames{0};
        int xrunCount{0};
        int sharingMode{-1};
        int performanceMode{-1};
        int deviceId{-1};
        double estimatedLatencyMs{-1.0};
        float peakLeft{0.0F};
        float peakRight{0.0F};
        float limiterGainReductionDb{0.0F};
        int activeVoices{0};
        int droppedRealtimeEvents{0};
        float cpuLoadPercent{0.0F};
        int coresWorking{1};
    };

    struct SoundItem {
        int bank{0};
        int page{0};
        int slot{0};
        std::string name;
    };

    struct UpperState {
        bool enabled{false}, solo{false}, mute{false};
        float levelDb{0.0F}, pan{0.0F};
        int keyLow{0}, keyHigh{127};
        int velocityLow{1}, velocityHigh{127};
        int voiceMode{0};
        int octave{0}, transpose{0};
        float fineCents{0.0F};
        int pitchBendRange{2};
        float portamentoSec{0.0F};
        bool breath{false}, expression{false}, aftertouch{false}, damper{false};
        int midiChannel{0};
        float attackScale{1.0F}, decayScale{1.0F}, sustainScale{1.0F}, releaseScale{1.0F};
        float cutoffOctaves{0.0F}, resonanceOffset{0.0F}, lfoRateScale{1.0F}, lfoDepthScale{1.0F};
        float eqLowDb{0.0F}, eqMidDb{0.0F}, eqHighDb{0.0F};
        float fxSend1{0.0F}, fxSend2{0.0F};
        std::string soundName;
        // TONE page (absolute values). toneSet bit k = the Upper has its own value, otherwise the PROGRAM default is shown.
        float toneAttackMs{5.0F}, toneDecayMs{80.0F}, toneSustain{1.0F};
        float toneReleaseMs{120.0F}, toneCutoffHz{20000.0F}, toneResonance{0.0F};
        int toneSet{0};
    };

    struct FxState {
        int type{0};
        float wet{0.0F}, timeMs{0.0F}, feedback{0.0F}, rateHz{0.0F}, depth{0.0F}, tone{0.0F};
    };

    struct CombiFxState {
        FxState fx1;
        FxState fx2;
        int routing{0};
    };

    struct GlobalUiState {
        float masterTuneHz{440.0F};
        int transpose{0};
        float masterGainDb{0.0F};
        float eqLowDb{0.0F}, eqMidDb{0.0F}, eqHighDb{0.0F};
        bool limiterEnabled{false};
        float limiterCeilingDb{0.0F};
        int velocityCurve{0};
        int breathCc{2}, expressionCc{11}, damperCc{64};
        bool pitchBendEnabled{true}, aftertouchEnabled{true};
    };

    struct TercaState {
        int root{-1};
        int cell{-1};
    };

    struct GlobalAdvanced {
        int scaleRoot{0};
        std::vector<float> scaleCents;
        int midiInMask{0xFFFF};
        bool filterNotes{false}, filterCc{false}, filterBend{false}, filterAftertouch{false};
        float breathMin{0.0F}, breathMax{1.0F}, breathCurve{0.0F};
        float expressionMin{0.0F}, expressionMax{1.0F}, expressionCurve{0.0F};
        bool damperReversed{false};
    };

    struct ListItem {
        int number{0};
        std::string name;
        int combiBank{0};
        int combiPage{0};
        int combiSlot{0};
    };

    struct BankSound {
        int slot{0};
        std::string name;
        int samples{0};
        long long bytes{0};
    };

    struct BankInfo {
        std::string path;
        int sounds{0};
        int samples{0};
        long long audioBytes{0};
        long long fileBytes{0};
        std::vector<BankSound> list;
    };

    explicit SamplerAppController(ControllerEnv env);
    ~SamplerAppController();
    SamplerAppController(const SamplerAppController&) = delete;
    SamplerAppController& operator=(const SamplerAppController&) = delete;

    host::NativeSamplerEngine engine;

    // ---- settings kept between sessions
    int portaBalance() const { return portaBalanceValue_; }
    void setPortaBalance(int value, bool save = true);
    int voiceCeiling() const { return voiceCeilingValue_; }
    void setVoiceCeiling(int voices, bool save = true);
    int portaNear() const { return portaNearValue_; }
    void setPortaNear(int value, bool save = true);
    bool themeDark() const;
    void setThemeDark(bool dark);
    // SILVETON_COLOR_KEYS_V1: the colour of the screens (SETTINGS > GENERAL > THEME): 0 GRAPHITE, 1 LIGHT, 2 BLACK, 3 CLASSIC, 4 OLD
    int classicColor() const;
    void setClassicColor(int color);
    // SILVETON_PRO_UI_V1: the language of the screens, 0 БЪЛГАРСКИ (the default after installing), 1 ENGLISH
    int uiLanguage() const;
    int uiTheme() const;                 // SILVETON_THEMES_V1: 0 ГРАФИТ, 1 СВЕТЛА, 2 ЧЕРНА, 3 КЛАСИКА, 4 СТАРА; SILVETON_ONLY_OLD_V1: the default is 4 (only the old look is shown)
    void setUiTheme(int theme);
    void setUiLanguage(int lang);
    std::set<int> listFavourites() const;
    void saveListFavourites(const std::set<int>& favs);
    std::set<int> soundFavourites() const;
    void saveSoundFavourites(const std::set<int>& favs);
    std::vector<int> recentSounds() const;
    void rememberRecentSound(int slot);

    // ---- key range scan / TERCA / Q
    int keyScanUpper() const { return keyScanUpper_; }
    // SILVETON_KEYRANGE_V1: sound 0 = ОСНОВЕН, 1..4 = L1..L4; edge 0 = the pressed key becomes the LOWEST key, 1 = the HIGHEST key
    // (the other end moves only when the pressed key would cross it).
    int keyScanSound() const { return keyScanSound_; }
    int keyScanEdge() const { return keyScanEdge_; }
    void startKeyScan(int upper, int sound = 0, int edge = 1);
    void cancelKeyScan();
    TercaState tercaState() const { return {tercaRoot_, tercaCell_}; }
    bool tercaOn(int upper) const;
    bool quarterOn(int upper) const;
    bool tercaChosen(int upper) const;
    bool quarterChosen(int upper) const;
    int quarterNotes() const { return scaleMask_; }
    bool tercaMasterOn() const { return tercaMaster_ && tercaUppers_ != 0; }
    bool scaleMasterOn() const { return scaleMaster_ && scaleUppers_ != 0; }
    bool hasTercaUppers() const { return tercaUppers_ != 0; }
    bool hasScaleUppers() const { return scaleUppers_ != 0; }
    void toggleTerca(int upper);
    void toggleQuarter(int upper);
    void toggleTercaMaster();
    void toggleScaleMaster();
    int pollScan();
    void startTercaScan();
    void startScaleScan();
    void cancelScan();
    std::vector<float> scaleCents() const;

    // ---- SILVETON_SCALE_TUNING_V1: SCALE (a musical tuning) = 12 offsets in cents per real note; by hand, ready presets, your own saved ones.
    struct ScalePreset {
        std::string name;
        std::array<float, 12> cents;   // with the tonic C; "turn to the tonic" moves them
    };
    static const std::vector<ScalePreset>& scalePresets();
    static std::vector<float> scaleTurned(const std::array<float, 12>& cents, int tonic);
    const std::string& scaleName() const { return scaleName_; }
    void setScale(const std::vector<float>& cents, const std::string& name);   // clamps -100..+100, saves, sends to the sound engine
    void setScaleNote(int note, float cents);                                    // by hand: one real note (0 = C ... 11 = B)
    int userScaleCount() const { return static_cast<int>(userScales_.size()); }
    const std::string& userScaleName(int i) const { return userScales_[static_cast<std::size_t>(i)].name; }
    const std::vector<float>& userScaleCents(int i) const { return userScales_[static_cast<std::size_t>(i)].cents; }   // SILVETON_SCALE_PAGE_V1: the shape of a saved scale
    bool saveUserScale(const std::string& name);                                 // the current scale under a name (the same name = replaced)
    bool useUserScale(int i);
    bool deleteUserScale(int i);

    // ---- advanced GLOBAL
    std::optional<GlobalAdvanced> globalAdvanced();
    bool updateGlobalAdvanced(const GlobalAdvanced& a);
    bool stepGlobalTranspose(int step);

    // ---- life cycle
    bool start();
    void pauseAudio();
    void setMidiPreviewIsolation(bool blocked);
    bool resumeAudio();
    void close();
    // Called about four times a second from the shell: audio recovery and MIDI connection news (the tablet's two helper threads).
    void housekeeping();
    // The user chose another SILVETON_BANK.sv: remember it and load it.
    bool useBankFile(const std::string& path);
    // Grows every time a bank has been loaded (the screens then read everything again; on the tablet the bank loads before the first touch).
    int bankSerial() const { return bankSerial_.load(); }

    MidiStatus midiStatus();
    bool audioRunning();
    int audioLastError();
    bool testInstrumentEnabled();
    bool testEpNoteOn(int note = 60, int velocity = 110);
    void testEpNoteOff(int note = 60);
    bool panic();

    // ---- lists and catalogs
    std::vector<ListItem> listItems(int bank, int page, int slot);
    int activeListEntry(int bank, int page, int slot);
    bool activateListEntry(int bank, int page, int slot, int index);
    bool blendEdited();                    // SILVETON_SAVEQ_V1: the open BLEND was changed since it was recalled / written
    std::string lastRecallMissing();       // SILVETON_OPEN_WITHOUT_SOUND_V1: lines "part<TAB>layer<TAB>name<TAB>number" of sounds the last recall did not find
    int midiCcValue(int cc);               // SILVETON_PEDAL_CAL_V1: last value of a controller, -1 = none yet
    std::string takeNotice();              // SILVETON_STATE_RECOVER_V1: a message for the screen that is given out once
    const std::string& lastFailure() const { return lastFailure_; }   // SILVETON_WRITE_ERR_V1: why the last write / copy / move failed
    bool isEmptyListItem(const ListItem* item) const;
    bool isEmptyListItem(const ListItem& item) const { return isEmptyListItem(&item); }
    bool renameLiveListEntry(int index, const std::string& name);
    bool deleteLiveListEntry(int index);
    bool copyListEntryTo(int from, int to);
    bool moveListEntryTo(int from, int to);
    bool moveLiveListEntry(int fromIndex, int toIndex);
    bool copyLiveListEntry(const ListItem& item, int insertIndex);
    bool writeCombiSlot(int slot, const std::string& name);
    int firstFreeCombiSlot();
    int writeCombiToList(int position, const std::string& name);
    bool activateCombiAddress(int bank, int page, int slot);
    bool addCombiToList(int combiSlot, const std::string& name);
    std::vector<std::pair<int, std::string>> multisampleCatalog();
    // SILVETON_SAMPLE_WAVE_V1: the samples of the bank (id, name), and one of them as the 64 points of a drawn wave (the error text, or nullopt when ready)
    std::vector<std::pair<int, std::string>> sampleCatalog();
    std::optional<std::string> sampleAsWave(int id, std::vector<float>& points);
    std::vector<std::pair<int, std::string>> combiCatalog();
    std::vector<SoundItem> soundCatalog();

    // ---- bank info / sets
    std::optional<BankInfo> bankInfo();
    // SILVETON_USER_WAVES_V1: the user's own waves (folder SILVETON_OSC next to the bank) = USER 1..16 of the engines' oscillators.
    // Read again when a bank is loaded and by ОБНОВИ on the INFO page.
    silveton::sampler::UserWaveReport reloadUserWaves();
    // SILVETON_MODEL_V1: the learned models read with the waves (the same SILVETON_OSC.sv next to the bank): their names for the
    // МОДЕЛ key (MODEL 1 = the first), and a note why there are none ("" = there are)
    std::vector<std::string> learnedModelNames() const;
    std::string learnedModelsNote() const;
    silveton::sampler::UserWaveReport userWaves() const;
    std::optional<std::string> deleteBankSounds(const std::vector<int>& slots);   // nullopt = done, else the reason
    std::string setsFolders() const;
    std::vector<std::string> savedSets();
    bool setExists(const std::string& name);
    std::optional<std::string> saveSetAs(const std::string& name);                // nullopt = saved, else the reason
    std::optional<std::string> loadSavedSet(const std::string& name);
    // ---- SILVETON_SEND_V1 / SILVETON_PROJECT_V1 (only the Manager's copy of the sampler has these)
    std::optional<std::string> addSoundsFromBank(const std::string& path);   // the SOUNDs of a small bank go in at their places; nullopt = done
    std::string currentBankFile();                                            // the bank the sampler plays ("" = none)
    std::optional<std::string> saveProjectState(const std::string& dir);      // LIST, blends, global, T/Q, the open COMBI
    std::optional<std::string> loadProjectState(const std::string& dir);
    // The small bank files the Manager sent: they go in every time a bank is loaded, before the LIST, so the blends find them.
    void setExtraBankFiles(const std::vector<std::string>& files);
    void waitForBankLoad();                                                   // the first bank load of the start is finished
    // SILVETON_PASTE_V1: every SOUND (place, name) becomes a new BLEND in the LIST (only that SOUND on Upper 1, named like it),
    // in the empty LIST positions from `start` on (a position with a BLEND is skipped, never written over). first = the first one used.
    std::optional<std::string> pasteSoundsToList(const std::vector<std::pair<int, std::string>>& sounds, int start, int& first, int& count);
    // SILVETON_LIST_DELETE_SOUNDS_V1: the SOUNDs (place, name) that leave the sampler with LIST position `index`: the ones of its blend
    // that no other blend (BLENDS 1..500, a saved set, the open COMBI unless it is this blend) uses. Empty = only the position goes.
    std::vector<std::pair<int, std::string>> soundsOnlyInListEntry(int index);
    // The LIST position, its blend and those SOUNDs go at once (the bank on the disk is not written; they stay out after a restart too).
    std::optional<std::string> deleteListEntryWithSounds(int index, const std::vector<int>& places);
    // SILVETON_MULTI_DELETE_V1 (the Manager's copy): these SOUND places leave the sampler for good (the blends that used them play
    // without them); remembered as removed, so a bank reload does not bring them back. Empty = nothing to do.
    std::optional<std::string> deleteSounds(const std::vector<int>& places);
    void setRemovedSounds(const std::vector<int>& places);                     // taken out again after every bank load
    void setSoundsRemovedHandler(std::function<void(const std::vector<int>&)> handler);
    // SILVETON_PROJECT_SYNC_V1 (the Manager's copy): called every time the LIST / BLENDS / settings were written next to the bank
    // (from the thread that wrote them) - the Manager copies them into the open project at once.
    void setUserStateSavedHandler(std::function<void()> handler);

    // ---- generic parameters
    bool setUpperParam(int upper, int id, float value);
    std::vector<float> upperParams(int upper);
    bool setLayerParam(int upper, int layer, int id, float value);
    bool setLayerSound(int upper, int layer, int slot);
    std::vector<float> layerParams(int upper, int layer);
    std::string layerName(int upper, int layer);
    std::vector<int> soundVelocityZones(int upper, int sound);   // SILVETON_OFS_V1
    int upperSoundSlot(int upper);   // SILVETON_LAYER_MOVE_V1: the SOUND of the basic place (ОСНОВЕН) of an Upper, 0 = none
    bool setFxParam(int unit, int id, float value);
    std::vector<float> fxParams(int unit);
    std::vector<float> analyzerFrame(int upper, bool afterEq);
    bool setSoundSynthParam(int upper, int sound, int id, float value);
    std::vector<float> soundSynthParams(int upper, int sound);
    bool setUpperEngineParam(int upper, int id, float value);   // SILVETON_ENGINES_V1
    bool setUpperEngineBlock(int upper, int firstId, const std::vector<float>& values);   // SILVETON_SUSE_V1: many numbers in one new state
    std::vector<float> upperEngineParams(int upper);
    // ---- SILVETON_SUSE_V1: the presets, waves and the last session of SILVETON SYNTH (folder SILVETON_SUSE next to the bank).
    // A patch is the 960 numbers of the engine place (value ids 0..959). Every file has a version and a check sum.
    std::string suseFolder();
    std::vector<std::string> suseUserPresets();
    std::optional<std::string> suseSavePreset(const std::string& name, const std::vector<float>& patch);        // nullopt = done, else the reason
    std::optional<std::string> suseLoadPreset(const std::string& name, std::vector<float>& patch);
    std::optional<std::string> suseDeletePreset(const std::string& name);
    std::optional<std::string> suseExportBank(std::string& file);                                              // all the user presets in one file
    std::optional<std::string> suseImportBanks(int& count);                                                    // every .SUSB / .SUSP in SILVETON_SUSE/IMPORT
    std::vector<std::string> suseUserWaves();
    std::optional<std::string> suseSaveWave(const std::string& name, const std::vector<float>& points);       // 64 points -1..1
    std::optional<std::string> suseLoadWave(const std::string& name, std::vector<float>& points);
    void suseSaveSession();      // the patches of the 8 places, written after a change
    void suseRestoreSession();   // at the start: a place without an engine gets its last patch back
    bool setSoundWaveParam(int upper, int sound, int id, float value);   // SILVETON_TRANSWAVE_V1
    std::vector<float> soundWaveParams(int upper, int sound);

    // ---- status
    std::vector<std::pair<float, float>> upperMeters();
    AudioStatus audioStatus();
    std::string combiName();
    std::string bankLoadError();

    // ---- Uppers
    std::optional<UpperState> upperState(int upper);
    bool setUpperTone(int upper, int param, float value);
    bool assignUpperSound(int upper, const SoundItem& item);
    bool clearUpperSound(int upper);
    bool clearPerformance();   // SILVETON_EMPTY_START_V1: ПРАЗНО - nothing sounds (the blend's Uppers emptied, the engine places off)
    bool updateUpperMain(int upper, const UpperState& s);
    bool updateUpperTune(int upper, const UpperState& s);
    bool updateUpperRange(int upper, const UpperState& s);
    bool updateUpperControl(int upper, const UpperState& s);
    bool updateUpperTone(int upper, const UpperState& s);
    bool updateUpperFx(int upper, const UpperState& s);
    std::optional<CombiFxState> combiFxState();
    std::string blendInfo(const ListItem& item);   // SILVETON_BLEND_INFO_V1: what a stored BLEND holds (records split by TAB, see SamplerHost)
    bool updateCombiFx(int slot, const FxState& fx);
    bool updateCombiFxRouting(int routing);
    std::optional<GlobalUiState> globalUiState();
    std::optional<float> nudgeMasterGain(float stepDb);
    bool updateGlobalUi(const GlobalUiState& s);

private:
    bool nativeResult(bool ok);
    std::string lastFailure_;   // SILVETON_WRITE_ERR_V1
    std::mutex noticeMutex_;
    std::string notice_;        // SILVETON_STATE_RECOVER_V1
    bool recoverUserState(const std::string& userState);
    bool fail(const std::string& message);
    void status(const std::string& message) { if (env_.statusChanged) env_.statusChanged(message); }
    void startBankLoad();
    void loadDefaultBankOnce();
    int bankSoundCount();
    bool applyBankFile(const std::string& path);
    void applyScale();
    void applyScaleUppers();
    void applyTerca();
    void saveTercaScale();
    std::string bankDir();
    std::string userStateFile();
    std::string privateStateFile() const;
    std::string bankFile();
    bool saveUserState();
    std::string tqText() const;
    void applyTqFile(const std::string& tq);
    void applyTqText(const std::string& text);   // SILVETON_SET_ONE_FILE_V1
    bool persistLiveListEdits() { return saveUserState(); }
    bool setPresent(const std::string& f) const;
    bool copySet(const std::string& src, const std::string& dst) const;
    void backupUserState();
    void restoreUserStateIfMissing();
    bool renumberLiveList();
    bool ensureListLength(int count);
    bool trimListTail();
    std::string setFileName(const std::string& name) const;
    std::string setsDir();
    std::string setFile(const std::string& name);

    ControllerEnv env_;
    Prefs prefs_;
    std::atomic<bool> started_{false};
    std::atomic<bool> closed_{false};
    std::atomic<bool> bankLoading_{false};
    std::atomic<bool> userWavesAccessTried_{false};   // SILVETON_USER_WAVES_V1: the storage access asked once for SILVETON_OSC.sv
    std::string learnedModelsFile_;                   // SILVETON_MODEL_V1
    bool learnedModelsOk_{false};
    std::vector<std::string> learnedModelNames_;
    std::string learnedModelsNote_;
    std::atomic<int> bankSerial_{0};
    bool defaultBankAttempted_{false};
    std::thread bankThread_;
    std::mutex bankThreadMutex_;
    int portaBalanceValue_{11};
    int voiceCeilingValue_{48};
    int portaNearValue_{90};
    int keyScanUpper_{-1};
    int keyScanSound_{0};
    int keyScanEdge_{1};
    int lastKeySerial_{-1};
    int tercaUppers_{0}, scaleUppers_{0}, tercaRoot_{-1}, tercaCell_{-1}, scaleMask_{0};
    std::vector<float> scaleCentsNow_ = std::vector<float>(12U, 0.0F);   // SILVETON_SCALE_TUNING_V1
    std::string scaleName_;
    struct UserScale { std::string name; std::vector<float> cents; };
    std::vector<UserScale> userScales_;
    void loadUserScales(const std::string& text);
    std::string userScalesText() const;
    bool tercaMaster_{true}, scaleMaster_{true};
    int lastTercaSerial_{-1}, lastScaleSerial_{-1};
    std::mutex bankPathMutex_;
    std::vector<std::string> extraBankFiles_;   // SILVETON_SEND_V1
    std::vector<int> removedSounds_;              // SILVETON_LIST_DELETE_SOUNDS_V1
    std::function<void(const std::vector<int>&)> soundsRemoved_;
    std::function<void()> userStateSaved_;        // SILVETON_PROJECT_SYNC_V1
    std::mutex extraMutex_;
    void addExtraBankFiles();
    std::string bankPath_;
    // life-cycle helper state (the tablet's runtime / midi status threads)
    bool runtimeRunning_{false};
    std::int64_t lastRecoveryPollMs_{0};
    std::int64_t lastMidiPermissionMs_{0};
    int lastMidiConnectionCount_{-1};
    int lastMidiError_{0};
};

} // namespace silveton::ui
