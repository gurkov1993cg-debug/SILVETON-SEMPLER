#pragma once
// SILVETON_MAC_VIEW_V1 - the screens of the SILVETON SAMPLER, carried over from the tablet's SilvetonSamplerView.kt
// function by function (same names, same numbers, same colours). Everything is drawn in fixed 1340x800 design units
// and scaled uniformly; the mouse is mapped back into the same units. Every drawn control is a real hit.
//
// What the Mac shell does: calls draw() for every picture, hands over mouse / keyboard events, and calls tick().
// The dialogs of the tablet (Android AlertDialog) are drawn inside the same picture as overlays (see view/Members_Dialogs.inc).

#include <array>
#include <atomic>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "silveton/sampler/EngineDefs.h"   // SILVETON_ENGINES_V1: the labels and ranges of the ENGINE page
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/Support.h"

namespace silveton::ui::classic {

// Text options (the tablet's named arguments center = / face = / spacing = / maxWidth = / right =)
struct TextOpt {
    bool center_{false};
    bool right_{false};
    Face face_{Face::Regular};
    float spacing_{0.0F};
    float maxWidth_{std::numeric_limits<float>::infinity()};
    TextOpt& center(bool v = true) { center_ = v; return *this; }
    TextOpt& right(bool v = true) { right_ = v; return *this; }
    TextOpt& face(Face f) { face_ = f; return *this; }
    TextOpt& bold() { face_ = Face::Bold; return *this; }
    TextOpt& mono() { face_ = Face::Mono; return *this; }
    TextOpt& monoBold() { face_ = Face::MonoBold; return *this; }
    TextOpt& spacing(float s) { spacing_ = s; return *this; }
    TextOpt& maxW(float w) { maxWidth_ = w; return *this; }
};

class SilvetonSamplerView {
    friend struct ViewTestAccess;   // the screen tests reach inside to open pages and dialogs
public:
    using Ctrl = SamplerAppController;
    using UpperState = Ctrl::UpperState;
    using SoundItem = Ctrl::SoundItem;
    using ListItem = Ctrl::ListItem;
    using GlobalUiState = Ctrl::GlobalUiState;
    using FxState = Ctrl::FxState;
    using CombiFxState = Ctrl::CombiFxState;

    // SILVETON_LOOK_V2: relief keys everywhere (shadow, gradient face, light edge), glowing EQ curve.
    enum class Page { LIST, COMBI, EFFECTS, SETTINGS };

    explicit SilvetonSamplerView(Ctrl& sampler);
    // SILVETON_OLD_THEME_V1: this is the OLD look of the sampler, kept as a theme (СТАРА). The new themes are chosen on its SETTINGS page;
    // it calls this with 0 ГРАФИТ / 1 СВЕТЛА / 2 ЧЕРНА / 3 КЛАСИКА and the shell around it switches to the new screens.
    std::function<void(int)> onThemeRequest;
    ~SilvetonSamplerView();
    SilvetonSamplerView(const SilvetonSamplerView&) = delete;
    SilvetonSamplerView& operator=(const SilvetonSamplerView&) = delete;

    // ---------------------------------------------------------------- what the shell calls
    void setMidiConnections(int count);
    void setWarning(const std::string& message);     // empty = no warning; may be called from any thread
    void globalChangedOutside();                     // MASTER changed from outside the screen
    // SILVETON_PASTE_V1 (only in the Manager's copy): the LIST position chosen with a click (-1 = none), and the LIST page
    // with a short message after the Manager pasted sounds there as new BLENDs.
    int chosenListPosition() const { return listSelected; }
    void listPasted(int first, int count);
    // Right button on a LIST position offers ПОСТАВИ while the Manager has copied sounds (label = what; empty / no action = nothing copied).
    void setPasteOffer(const std::string& label, std::function<void(int position)> paste);
    // SILVETON_WORKFLOW_V1: the Mac shows its own small menu for a LIST position. listRowAt: the LIST position under a point of the
    // picture (-1 = none, also while a window of the screens is open); listRowInfo: its blend (false = empty) and the star;
    // listRowAction: 0 open in COMBI, 1 star on/off, 2 rename, 3 copy to, 4 move to, 5 delete (with the questions of the screens).
    int listRowAt(float rawX, float rawY) const;
    bool listRowInfo(int index, std::string& name, bool& favourite);
    void listRowAction(int index, int action);
    // SILVETON_COMBI_DROP_V1 (only in the Manager's copy): a SOUND dragged from the Manager can be put into ANY of the 35 places
    // of the COMBI page - every Upper has five (slot 0 = ОСНОВЕН, 1..4 = L1..L4). The screens themselves look exactly as before;
    // the Manager draws the drop places over the picture from these rectangles (picture pixels, origin top left).
    struct ComboSlot {
        int upper{0};
        int slot{0};
        float left{0.0F}, top{0.0F}, right{0.0F}, bottom{0.0F};
        std::string label;     // ОСНОВЕН / L1..L4
        std::string sound;     // the sound that is there now ("" = empty)
        bool contains(float x, float y) const { return x >= left && x < right && y >= top && y < bottom; }
    };
    Page page() const { return page_; }
    // Shows the COMBI page (closes the drop-down list). false = a window of the screens is open and the drop cannot start.
    bool prepareComboDrop();
    // The 35 places (empty while another page / window is in front).
    std::vector<ComboSlot> comboSlots();
    // The sound at `place` (1..500, as the Manager sent it) goes into the place: ОСНОВЕН = the Upper's own sound, L1..L4 = a layer.
    // The same calls the sound picker makes; the sound plays at once (the keyboard stays live). false = it did not work.
    bool dropSoundIntoSlot(int upper, int slot, int place, const std::string& name);
    // SILVETON_LAYER_MOVE_V1: the sound field of an Upper strip is the handle to drag the sound of that place (ОСНОВЕН or the layer the strip shows)
    // to another place. Only the SOUND moves or is copied; the settings of both places (level, pan, ranges, TONE ...) stay where they are.
    struct LayerSource { int upper{0}; int slot{0}; int sound{0}; std::string name; };
    std::optional<LayerSource> layerSourceAt(float rawX, float rawY);                   // picture pixels; none = no sound field with a sound there
    bool moveLayerSound(int fromUpper, int fromSlot, int toUpper, int toSlot, bool copy);   // copy = the source keeps its sound
    void selectedPlace(int& upper, int& slot) const;   // the Upper the COMBI page has selected and ОСНОВЕН (0) / L1..L4 (1..4) its strip shows
    // Draws one picture of the whole screen into the canvas (any size; the 1340x800 design is scaled to fit).
    void draw(Canvas& canvas);
    // Must the shell draw again now? (A touch or an animation asked for it, or the 100 ms refresh is due.)
    bool redrawDue(std::int64_t now) const;
    // The long-press timer and the repeat of the - / + keys in the dialogs. Call it at least every 30 ms.
    void tick(std::int64_t now);

    enum class PointerAction { Down, Move, Up, Cancel };
    // Left mouse button, in picture pixels (the same pixels the canvas has).
    void pointer(PointerAction action, float x, float y);
    // Right mouse button on a control = its reset (the tablet's double tap, or a finger on both - and +).
    void secondaryClick(float x, float y);
    // The tablet's ACTION_POINTER_DOWN: a second finger went down (picture pixels) while the first one is still held.
    // On a - / + pair that is the pair's reset; while a text / number page is open it types the key under the finger.
    void secondPointerDown(float x, float y);
    // The tablet shows a Toast for the volume keys; here it is a small pill inside the picture (about 2 seconds).
    // Call it from the thread that draws.
    void showToast(const std::string& message, int durationMs = 2000);
    // The tablet has no keyboard of its own: with this on, the text and number pages draw an on-screen keyboard
    // (Latin and Bulgarian БДС letters, digits) and take their input from it. The Mac keeps its real keyboard.
    void setSoftKeyboard(bool enabled);
    // When must the shell look at the view again at the latest (a draw is due, a long press or a held - / + key fires)?
    // 0 = now. In the same clock as nowMs().
    std::int64_t nextWorkMs() const;
    // Keyboard (for the text and number pages). text = typed letters (UTF-8), key = special key.
    enum class Key { None, Enter, Escape, Backspace, Delete, Left, Right, Up, Down, Tab };
    void keyDown(Key key);
    void typeText(const std::string& utf8);
    // Mouse wheel / trackpad scroll over a point (picture pixels); dy > 0 = content moves up (next page / further down).
    void wheel(float x, float y, float dy);

    // For tests and screenshots
    void setPage(Page p) { page_ = p; }
    Page pageForTests() const { return page_; }
    void selectUpperForTests(int u) { selectedUpper_ = u; }
    bool dialogOpen() const;
    void refreshAllForTests();

private:
    // ---------------------------------------------------------------- types
    // SILVETON_GUI_V4: the Upper editor edits one sound (basic / L1..L4) or the common Upper settings.
    enum class UpperTab { TUNE, RANGE, VELOCITY, CONTROL, TONE, FX, PORTA, EQ, WAVE, ENGINE };   // SILVETON_SYNTH_MENU_OFF_V1: SYNTH and MATRIX pages removed; SILVETON_ENGINES_V1: ENGINE
    enum class WriteTarget { LIST, BLEND };
    enum class WriteMode { WRITE, COPY, MOVE };

    struct Hit {
        RectF rect;
        std::function<void(float, float)> tap;
        std::function<void()> reset;
        std::function<void(float, float, bool)> drag;
    };
    struct PairHit {
        RectF a;
        RectF b;
        std::function<void()> reset;
    };
    struct SmoothRangeHit {
        RectF rect;
        float minValue{0.0F};
        float maxValue{1.0F};
        float step{0.0F};
        float low{0.0F};
        float high{0.0F};
        std::function<void(float, float)> onChange;
    };
    struct ListLongHit {
        RectF rect;
        std::function<void(float, float)> action;
    };
    struct PickerState {
        PickerState(int u, int l, int prevSlot, std::string prevName)
            : upper(u), layer(l), previousSlot(prevSlot), previousName(std::move(prevName)), chosenSlot(prevSlot) {}
        int upper;
        int layer;
        int previousSlot;
        std::string previousName;
        int page{0};
        std::string search;
        bool favOnly{false};
        bool recentOnly{false};
        int chosenSlot;
        bool markMode{false};     // SILVETON_MULTI_DELETE_V1: a tap marks a sound instead of choosing it; ИЗТРИЙ removes the marked ones
        std::set<int> marked;
    };
    // SILVETON_COPY_ALL_V1: COPY keeps EVERYTHING of an Upper; PASTE writes all of it to the target.
    struct UpperClip {
        int from{0};
        UpperState state;
        std::vector<float> params;
        std::vector<float> engine;   // SILVETON_ENGINES_V1
        std::vector<std::vector<float>> layerParams;
        std::vector<float> insert;
        std::optional<SoundItem> sound;
        bool terca{false};
        bool quarter{false};
    };

    using Opt = TextOpt;

    // ---------------------------------------------------------------- constants
    static constexpr float DESIGN_W = 1340.0F;
    static constexpr float DESIGN_H = 800.0F;
    // SILVETON_SLOW_DRAG_V1: knobs and faders move 2.5 x slower under the finger (finer).
    static constexpr float DRAG_SLOW = 2.5F;
    static constexpr int LIST_SIZE = 200;
    static constexpr int LIST_PER_PAGE = 30;
    static constexpr int LIST_PAGES = (LIST_SIZE + LIST_PER_PAGE - 1) / LIST_PER_PAGE;
    static constexpr float TOUCH_SLOP = 8.0F;              // design units (the mouse needs less than a finger)
    static constexpr std::int64_t LONG_PRESS_MS = 500;

    // ---------------------------------------------------------------- colours (the tablet's companion object)
    static inline ColorInt C_METAL_A = Color::rgb(217, 218, 222), C_METAL_B = Color::rgb(222, 223, 227);
    static inline ColorInt C_SIDE_A = Color::rgb(38, 40, 44), C_SIDE_B = Color::rgb(51, 54, 59);
    static inline ColorInt C_NAV_EDGE = Color::rgb(72, 76, 82), C_NAV_TEXT = Color::rgb(158, 163, 171);
    static inline ColorInt C_LOGO = Color::rgb(233, 196, 106);
    static constexpr ColorInt C_LCD_TOP = Color::rgb(13, 15, 13), C_LCD_BOT = Color::rgb(23, 26, 22);
    // SILVETON_SERIOUS_V1: displays and values are white / grey like on other instruments; colour only says "on" (green),
    // SOLO (yellow), MUTE / error (red), marked (blue).
    static constexpr ColorInt C_LCD = Color::rgb(232, 235, 240), C_LCD_DIM = Color::rgb(138, 144, 154);
    static constexpr ColorInt C_LCD_VALUE = Color::rgb(248, 249, 251), C_LCD_OK = Color::rgb(96, 200, 124), C_LCD_BAD = Color::rgb(255, 107, 94);
    static constexpr ColorInt C_VALUE = Color::rgb(238, 240, 244);   // a value printed on a dark board
    static inline ColorInt C_KEY_LIGHT = Color::rgb(236, 238, 241), C_KEY_LIGHT_EDGE = Color::rgb(185, 188, 194), C_KEY_TEXT = Color::rgb(48, 52, 58);
    static inline ColorInt C_STRIP = Color::rgb(236, 238, 241), C_STRIP_SEL = Color::WHITE, C_EMPTY_CARD = Color::rgb(226, 228, 232);
    static constexpr ColorInt C_BOARD_INK = Color::rgb(226, 228, 232), C_BOARD_INK_SOFT = Color::rgb(200, 204, 210);
    static inline ColorInt C_INK = Color::rgb(35, 38, 43), C_INK_SOFT = Color::rgb(48, 52, 58), C_LABEL_GREY = Color::rgb(100, 106, 116);
    static inline ColorInt C_SCALE = Color::rgb(100, 106, 116), C_EMPTY_TEXT = Color::rgb(104, 110, 120);
    static inline ColorInt C_TOGGLE = Color::rgb(223, 226, 230), C_TOGGLE_TEXT = Color::rgb(74, 80, 90), C_DARK_KEY = Color::rgb(43, 46, 51);
    static inline ColorInt C_TRACK_LIGHT = Color::rgb(201, 204, 209), C_METER_BG = Color::rgb(27, 29, 32);
    // the one colour that means "switched on / chosen": green (the frame of the chosen UPPER, lit keys, LEDs, active range)
    static constexpr ColorInt C_ACCENT = Color::rgb(52, 168, 96), C_ACCENT_DARK = Color::rgb(30, 118, 64), C_AMBER = Color::rgb(255, 179, 71);
    static constexpr ColorInt C_SOLO = Color::rgb(255, 215, 106), C_MUTE = Color::rgb(255, 107, 94), C_FREE = Color::rgb(46, 140, 80);
    static constexpr ColorInt C_GREEN = Color::rgb(60, 157, 90), C_YELLOW = Color::rgb(233, 196, 106), C_RED = Color::rgb(255, 107, 61);
    static inline ColorInt C_BOARD_TOP = Color::rgb(52, 55, 61), C_BOARD_BOT = Color::rgb(39, 41, 46), C_BOARD_EDGE = Color::rgb(85, 89, 95);
    static constexpr ColorInt C_SECTION = Color::argb(38, 0, 0, 0);
    static inline ColorInt C_SECTION_TITLE = Color::rgb(201, 204, 209);
    static inline ColorInt C_KNOB_LABEL = Color::rgb(170, 176, 184), C_HINT = Color::rgb(143, 148, 156);
    static inline ColorInt C_TAB = Color::rgb(201, 204, 209), C_TAB_TEXT = Color::rgb(62, 66, 74);
    static constexpr ColorInt C_KNOB_A = Color::rgb(75, 79, 86), C_KNOB_B = Color::rgb(42, 44, 49), C_KNOB_C = Color::rgb(32, 34, 38);
    static constexpr ColorInt C_PANIC = Color::rgb(179, 38, 30), C_PANIC_TOP = Color::rgb(224, 100, 92);
    static constexpr ColorInt C_WARN_BG = Color::rgb(179, 38, 30), C_WARN_TEXT = Color::WHITE;
    static constexpr ColorInt C_LED_OFF = Color::rgb(85, 85, 85);
    static inline ColorInt C_LED_OFF_LIGHT = Color::rgb(187, 187, 187);
    // SILVETON_THEME_V1: СВЕТЛА (the look above) / ТЪМНА (dark panel, wooden side, Rhodes knobs and faders, lit = on).
    static inline bool darkTheme = false;
    static constexpr ColorInt C_MARK = Color::rgb(70, 160, 235);
    static inline ColorInt C_NAV_ON_TEXT = Color::WHITE;
    static inline ColorInt C_KEY_DARK_FACE = Color::rgb(66, 70, 80), C_KEY_DARK_EDGE = Color::rgb(96, 100, 112), C_KEY_DARK_TEXT = Color::rgb(190, 194, 204);
    static inline ColorInt C_KEY_ON = Color::rgb(24, 26, 30);
    static void applyTheme(bool dark);

    // ---------------------------------------------------------------- state
    Ctrl& sampler;
    Paint paint;
    std::vector<std::shared_ptr<Hit>> hits;
    // SILVETON_GUI_V4 state
    int editSound = 0;                    // 0 basic sound, 1..4 layer (the sound the strip shows)
    // SILVETON_UPPER_MENU_V1: which sound every strip shows (0 = ОСНОВЕН, 1..4 = L1..L4)
    std::array<int, 7> stripSound{};
    int dropUpper = -1;                   // strip whose drop-down list is open
    bool markMode = false;                // SILVETON_MARK_LINK_V1: tapping a strip marks / unmarks it
    bool linkOn = false;                  // SILVETON_MARK_LINK_V1: marked Uppers follow every change
    std::array<bool, 7> marked{};
    std::array<std::optional<std::vector<float>>, 7> upperParamsCache;
    std::array<std::array<std::optional<std::vector<float>>, 4>, 7> layerParamsCache;
    std::array<std::array<std::optional<std::string>, 4>, 7> layerNameCache;
    int fxUnitFocus = 0;                  // EFFECTS page: 0..3 send slot, 4..10 INSERT of Upper 1..7
    std::array<std::optional<std::vector<float>>, 11> fxParamsCache;
    int eqBand = 2;                       // EQ page: 0 HP, 1..5 band, 6 LP
    bool analyzerOn = true;
    bool analyzerAfter = true;
    bool analyzerPeak = true;
    std::shared_ptr<PickerState> picker;
    std::vector<float> analyzerCurve;
    std::vector<float> analyzerHold;
    std::int64_t analyzerLastMs = 0;

    std::vector<float> uParams(int u);
    std::vector<float> lParams(int u, int l);
    std::string lName(int u, int l);
    std::vector<float> fxP(int unit);
    void dropParamCaches(int u);
    std::vector<int> linkTargets(int u) const;
    void setUParam(int u, int id, float v);
    void setUParamOne(int u, int id, float v);
    void setLParam(int u, int l, int id, float v);
    void setLParamOne(int u, int l, int id, float v);
    void setFxP(int unit, int id, float v);
    void setFxPOne(int unit, int id, float v);
    bool layerOn(int u, int l);
    int layerSlot(int u, int l);
    bool putSoundInSlot(int upper, int slot, int place, const std::string& name);   // SILVETON_LAYER_MOVE_V1
    float toneX(int u, int sound, int id);
    void setToneX(int u, int sound, int id, float v);
    static std::string soundLabel(int sound);
    static std::vector<UpperTab> tabsFor(int sound);

    // SILVETON_GUI_V3: a "-" / "+" pair; both pressed together = reset.
    std::vector<PairHit> pairHits;
    bool pairConsumed = false;
    int settingsTab = 0;                  // 0 ОБЩИ, 1 MIDI, 2 INFO
    std::optional<Ctrl::BankInfo> bankInfoCache;
    int scanMode = 0;                     // 0 none, 1 TERCA scan, 2 SCALE scan
    std::optional<UpperClip> copiedClip;
    Page page_ = Page::COMBI;
    UpperTab tab = UpperTab::TUNE;
    int selectedUpper_ = 0;
    std::optional<int> editingCombiSlot;
    // LIST position the sound in the engine was loaded from (-1 = not from the LIST).
    int loadedFromList = -1;
    int midiConnections = 0;
    std::optional<std::string> warning;
    std::mutex warningMutex_;
    std::optional<std::string> pendingWarning_;       // set from other threads, taken in draw()
    bool pendingWarningSet_ = false;
    int listPage = 0;
    int listFollowedActive = -2;
    // SILVETON_LIST_GRID_V1: LIST position chosen for STORE / EDIT (-1 = none).
    int listSelected = -1;
    std::string pasteLabel_;                          // SILVETON_PASTE_V1 (the Manager's copy)
    std::function<void(int)> pasteAction_;
    void showPasteMenu(int index);
    // SILVETON_LIST_V2: favourites (star), search by name, swipe for pages.
    std::set<int> listFavs;
    bool listFavOnly = false;
    std::string listSearch;
    bool listMarkMode_ = false;   // SILVETON_MULTI_DELETE_V1: a tap marks a LIST position; ИЗТРИЙ removes the marked blends with their own sounds
    std::set<int> listMarked_;

    std::vector<std::shared_ptr<SmoothRangeHit>> smoothRangeHits;
    std::shared_ptr<SmoothRangeHit> activeSmoothRange;
    bool activeSmoothRangeHigh = false;
    bool smoothActive = false;
    std::vector<ListLongHit> listLongHits;
    std::vector<std::pair<int, RectF>> listCells_;   // SILVETON_WORKFLOW_V1: LIST positions drawn now (index, rect)
    float listLongPressX = 0.0F;
    float listLongPressY = 0.0F;
    bool listLongPressArmed = false;
    bool listLongPressFired = false;
    std::int64_t listLongPressStartMs = 0;

    std::array<std::optional<UpperState>, 7> upperStates;
    // The sound last chosen on each Upper: its list opens there again.
    std::array<std::optional<SoundItem>, 7> lastPickedSound;
    std::optional<CombiFxState> fxState;
    std::optional<GlobalUiState> globalState;
    Ctrl::AudioStatus frameAudioStatus;
    std::vector<std::pair<float, float>> frameUpperMeters;
    Ctrl::MidiStatus frameMidiStatus;
    long long lastMidiSerial = 0;
    std::int64_t midiFlashUntilMs = 0;
    std::int64_t lastTelemetryMs = 0;

    std::shared_ptr<Hit> activeHit;
    bool pointerDown_ = false;
    float downX = 0.0F;
    float downY = 0.0F;
    std::int64_t downTimeMs = 0;
    bool dragMoved = false;
    std::int64_t lastTapTimeMs = 0;
    std::optional<RectF> lastTapRect;
    float touchSlop = TOUCH_SLOP;

    // Uniform design scale (1340x800 design units -> picture pixels).
    float uiScale = 1.0F;
    float uiOffsetX = 0.0F;
    float uiOffsetY = 0.0F;

    // LIST/COMBI identity data is not realtime telemetry. Cache it.
    std::string cachedCombiName = "COMBI";
    std::vector<ListItem> cachedListItems;
    int cachedActiveListEntry = -1;
    bool listCacheLoaded = false;
    int seenBankSerial_ = -1;             // the Mac loads the bank in the background: when it is ready, everything is read again

    // Korg-style WRITE screen (SILVETON_KORG_WRITE_V1).
    bool writeOpen = false;
    WriteMode writeMode = WriteMode::WRITE;
    int writeSource = -1;
    WriteTarget writeTarget = WriteTarget::LIST;
    std::string writeName;
    int writePage = 0;
    int writeSelected = -1;
    std::vector<ListItem> writeList;
    std::map<int, std::string> writeBlends;

    std::optional<std::string> flashText;
    std::int64_t flashUntilMs = 0;
    std::string toastText_;
    std::int64_t toastUntilMs_ = 0;
    bool softKeyboard_ = false;
    void drawToast(Canvas& c);

    // redraw bookkeeping (Kotlin: invalidate / postInvalidateOnAnimation / postInvalidateDelayed)
    void invalidate() { invalidated_ = true; }
    void postInvalidateOnAnimation() { invalidated_ = true; }
    bool invalidated_ = true;
    std::int64_t nextRedrawMs_ = 0;
    int widthPx_ = 0;
    int heightPx_ = 0;
    std::shared_ptr<Image> woodBitmap_;

    // ---------------------------------------------------------------- touch
    void handleTouch(PointerAction action, float x, float y);
    void onTouchEventBase(PointerAction action, float x, float y);
    bool handleSmoothRangeTouch(PointerAction action, float x, float y);
    void registerSmoothRange(const RectF& r, float minValue, float maxValue, float step, float low, float high, std::function<void(float, float)> onChange);
    void emitSmoothRange(SmoothRangeHit& hit, float x);
    static float quantizeControl(float value, float minValue, float maxValue, float step);
    void knobHit(const RectF& r, float value, float minV, float maxV, float step, float travel,
                 std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset,
                 std::function<void(float)> onFinal = nullptr);
    void faderHit(const RectF& r, float levelDb, float travel, std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset);
    static float faderT(float db);
    static float faderDb(float t);
    void hit(const RectF& r, std::function<void(float, float)> tap, std::function<void()> reset = nullptr,
             std::function<void(float, float, bool)> drag = nullptr);
    std::shared_ptr<Hit> hitAt(float x, float y);
    void listLongHit(const RectF& r, std::function<void(float, float)> action);
    const ListLongHit* listLongHitAt(float x, float y) const;
    bool isDown(const RectF& r) const;
    void hapticFeedback() {}

    // ---------------------------------------------------------------- frame
    void drawMetal(Canvas& c);
    std::shared_ptr<Image> wood();
    void drawSideNav(Canvas& c);
    void showOscPicker();   // SILVETON_OSC_SOUND_V1
    void drawHeader(Canvas& c);
    void commitGroup(int u, const UpperState& s, const std::function<bool(int, const UpperState&)>& send,
                     const std::function<UpperState(const UpperState&, const UpperState&, const UpperState&)>& merge);
    template <class T> static T chg(const T& o, const T& n, const T& c) { return n != o ? n : c; }
    void commitMain(int i, const UpperState& s);
    void commitTune(const UpperState& s);
    void commitRange(const UpperState& s);
    void commitControl(const UpperState& s) { commitControlFor(selectedUpper_, s); }
    void commitControlFor(int u, const UpperState& s);
    void commitTone(const UpperState& s);
    void commitUpperFx(const UpperState& s);
    void commitGlobal(const GlobalUiState& g);
    void refreshUpper(int i);
    void refreshAllUppers();
    void refreshFx();
    void refreshGlobal();
    void refreshListCache();
    void refreshEverything();

    // ---------------------------------------------------------------- drawing kit
    void fill(Canvas& c, const RectF& r, float radius, ColorInt color);
    void fillV(Canvas& c, const RectF& r, float radius, ColorInt top, ColorInt bottom);
    void shadow(Canvas& c, const RectF& r, float radius, float dy, int alpha);
    void line(Canvas& c, float x1, float y1, float x2, float y2, ColorInt color, float w);
    void text(Canvas& c, const std::string& s, float x, float y, float size, ColorInt color, const Opt& o = Opt());
    void soundNameText(Canvas& c, const RectF& r, const std::string& name, ColorInt color);
    float textWidth(const std::string& s, float size, Face face, float spacing = 0.0F);
    void led(Canvas& c, float x, float y, bool on, float radius, bool light = false);
    void navKey(Canvas& c, const RectF& r, bool on);
    void litGlow(Canvas& c, const RectF& r, float radius, ColorInt color);
    void lightKey(Canvas& c, const RectF& r, const std::string& label, bool enabled = true, float size = 12.0F, float radius = 8.0F);
    void darkKey(Canvas& c, const RectF& r, const std::string& label);
    void stripToggle(Canvas& c, const RectF& r, const std::string& label, bool on, ColorInt onColor, float size = 11.0F);
    // SILVETON_LIT_V1: every switched-on key is a lit key (orange like the frame of the chosen UPPER, or the key's own colour);
    // off keys stay grey. The same look for every on/off key of the program, so "on" is told at a glance.
    void litKey(Canvas& c, const RectF& r, float radius, ColorInt color, bool down);
    static ColorInt litFill(ColorInt onColor);
    static ColorInt litText(ColorInt fill);
    void segKey(Canvas& c, const RectF& r, const std::string& label, bool on, float size = 13.0F, bool withLed = false);
    void accentKey(Canvas& c, const RectF& r, const std::string& label, bool enabled);
    void switchKey(Canvas& c, const RectF& r, const std::string& title, const std::string& sub, bool on);
    void pageKey(Canvas& c, const RectF& r, const std::string& label, bool on, bool hasData, bool ledOn);
    void lcd(Canvas& c, const RectF& r, float radius = 10.0F);
    void board(Canvas& c, const RectF& r, bool squareTopLeft = false);
    void secTitle(Canvas& c, const RectF& sec, const std::string& title);
    void section(Canvas& c, const RectF& r, const std::string* title);
    void section(Canvas& c, const RectF& r, const std::string& title) { section(c, r, &title); }
    void section(Canvas& c, const RectF& r) { section(c, r, nullptr); }
    void knobControl(Canvas& c, float cx, float cy, float radius, float value, float minV, float maxV, float step, float travel,
                     bool bipolar, const std::string& valueText, const std::string& label, float hitW,
                     std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset,
                     std::function<void(float)> onFinal = nullptr);
    // the tablet's default hit width (radius * 2 + 120)
    void knobControl(Canvas& c, float cx, float cy, float radius, float value, float minV, float maxV, float step, float travel,
                     bool bipolar, const std::string& valueText, const std::string& label,
                     std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset,
                     std::function<void(float)> onFinal = nullptr) {
        knobControl(c, cx, cy, radius, value, minV, maxV, step, travel, bipolar, valueText, label, -1.0F, std::move(onChange),
                    std::move(exact), std::move(reset), std::move(onFinal));
    }
    void drawKnob(Canvas& c, float cx, float cy, float r, float t, bool bipolar, bool ring);
    void drawRhodesKnob(Canvas& c, float cx, float cy, float r, float tt, bool ticks);
    void stripMeter(Canvas& c, const RectF& r, float peak);
    void faderCap(Canvas& c, float cx, float cy, bool big = false);
    void drawRangeBar(Canvas& c, const RectF& r, float low, float high, float minV, float maxV);
    void drawMiniKeyboard(Canvas& c, const RectF& r, int low, int high);
    void drawGear(Canvas& c, float cx, float cy, float radius);
    static std::string midiNoteName(int note);
    static ColorInt colorWithAlpha(ColorInt color, int alpha);
    static ColorInt lighten(ColorInt color, int amount);
    static std::string signed_(int v);
    static std::string dbText(float db);
    static std::string voiceModeName(int m);
    static std::string effectName(int t);
    static std::string panText(float p);
    static std::string noteName(int key);

#include "silveton/ui/classic/view/Members_Combi.inc"
#include "silveton/ui/classic/view/Members_List.inc"
#include "silveton/ui/classic/view/Members_Effects.inc"
#include "silveton/ui/classic/view/Members_Settings.inc"
#include "silveton/ui/classic/view/Members_Dialogs.inc"
};

} // namespace silveton::ui::classic
