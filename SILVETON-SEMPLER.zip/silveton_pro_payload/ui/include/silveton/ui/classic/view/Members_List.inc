// SILVETON_MAC_VIEW_V1 - the LIST and WRITE pages (tablet SilvetonSamplerView.kt lines 2053-2581)
    // LIST
    void drawList(Canvas& c);
    std::vector<int> listVisible();
    std::optional<ListItem> realListItem(int index);
    void listGridCell(Canvas& c, const RectF& r, int idx, const std::optional<ListItem>& item, bool active, bool chosen, bool isMarked);   // SILVETON_NEW_LOOK_V1
    void openStore();   // SILVETON_LOGIC_V1: ЗАПИШИ
    void listStorePick(int idx);   // SILVETON_LIST_STORE_V1: the position was chosen on the LIST: the name, then (if taken) OVERWRITE, then it is written
    static std::string failureText(const std::string& raw);   // SILVETON_WRITE_ERR_V1: why a write / copy / move / delete failed, in words
    void remapFavourites(int from, int to, bool move);          // SILVETON_FAV_FOLLOW_V1
    void askSaveThen(std::function<void()> proceed);            // SILVETON_SAVEQ_V1
    void saveOpenThen(std::function<void()> proceed);
    void reportMissingSounds();                                 // SILVETON_OPEN_WITHOUT_SOUND_V1
    void saveSetAs();
    void loadSet();
    void listCard(Canvas& c, const RectF& r, const std::optional<ListItem>& item, int idx, bool selected);
    static std::string blendAddress(const ListItem& item);
    void editListCombi(const ListItem& item, int index);
    void showListContextMenu(int index, const ListItem& item);
    // SILVETON_LIST_MENU_V2: the menu works on the MARKED blends when there are some, else on the one that was held
    std::vector<int> listTargets(int index);
    void showBlendInfo(std::size_t k);                  // INFO of the blends in infoQueue_, one after the other
    void renameNext(std::size_t k);                     // RENAME of the blends in renameQueue_, one after the other
    void listEndMarking();
    void listPaintTouch(float x, float y, bool final);  // marking by dragging a finger over the cells
    void listDuplicate(const std::vector<int>& from);
    void listCutOffer(const std::vector<int>& from, const char* word = "CUT");
    void listCopyOffer(const std::vector<int>& from);   // SILVETON_LIST_DIRECT_V1
    bool listClipboardOffer(const std::vector<int>& from, bool cut, const std::string& word);
    void listToolbarAction(int which);
    void listPasteAt(int index);
    bool listPasteMode_ = false;                       // tap a destination without recalling its blend
    void listCancelPasteSelection() { listPasteMode_ = false; }
    void doCopyOrMoveMany(bool move, const std::vector<int>& from, int start);
    // SILVETON_NEW_LOOK_V1: the LIST page of the new look
    void listCellFace(Canvas& c, const RectF& r, int kind, bool ring);   // the face of a cell / row: 0 filled, 1 empty, 2 open (blue), 3 marked (amber)
    void listLitKey(Canvas& c, const RectF& r, const std::string& label, bool lit, float size);   // the T / Q switches
    void listScanKey(Canvas& c, const RectF& r, int mode, const std::string& sub);                // T SCAN / Q SCAN
    void drawListInfo(Canvas& c);                                        // the INFO of a blend, drawn over the LIST (modal)
    struct ListInfoView {                                                // what the INFO shows (read once when it is opened)
        std::string title;
        std::string name;
        std::string upNo[7], upName[7];                                  // sound number and name of each Upper ("" = none)
        std::vector<std::string> places;                                 // one line for each used SILVETON SYNTH place
        std::string sends, inserts;                                      // the used send / INSERT effects
        bool fav{false};
    };
    bool listInfoOpen_ = false;
    std::size_t listInfoK_ = 0U;                                         // which of infoQueue_ is shown
    ListInfoView listInfo_;
    std::vector<int> infoQueue_;
    std::vector<int> renameQueue_;
    std::vector<int> writeSources_;                     // COPY / MOVE of several blends: their positions (empty = the one in writeSource)
    int listPaintMode_ = -1;                            // -1 no drag, 1 the drag marks, 0 the drag unmarks
    float listPaintX_ = 0.0F, listPaintY_ = 0.0F;
    // WRITE / COPY / MOVE (Korg style)
    void openWrite(WriteTarget target, bool append);
    void openPositionPicker(WriteMode mode, int source);
    std::optional<std::string> writeListName(int pos);
    int firstFreeListPosition(int after = -1);
    void selectWriteTarget(WriteTarget target, bool append);
    std::optional<std::string> writeOccupiedName(int pos);
    void drawWriteScreen(Canvas& c);
    void writeCell(Canvas& c, const RectF& r, int number, const std::optional<std::string>& name, bool usable, bool selected, bool source = false);
    void confirmWrite();
    void doWriteList(int pos, const std::string& name);
    void doWriteBlend(int slot, const std::string& name);
    void doCopyOrMove(bool move, int from, int to);
#include "silveton/ui/classic/view/Members_Scale.inc"
