// SILVETON_NEW_LOOK_V1 - the approved new look (pictures in gui/png): colours, widgets, top bar, bottom nav.
// Every screen draws in the same 1340 x 800 design units. FRAME: top bar y 10..82, content y 96..698, nav bar y 706..782.
    static constexpr ColorInt NL_BLUE = Color::rgb(51, 160, 255), NL_BLUE_DARK = Color::rgb(23, 102, 201), NL_AMBER = Color::rgb(255, 163, 26);
    static constexpr ColorInt NL_RED = Color::rgb(229, 72, 77), NL_TXT = Color::rgb(233, 237, 242), NL_TXT2 = Color::rgb(163, 172, 183), NL_MUT = Color::rgb(109, 117, 127);
    static constexpr ColorInt NL_VALUE = Color::rgb(234, 243, 255);

    friend struct NewLookAccess;   // the new look picture test
    enum class NlBtn { Plain, Off, Sel, On, Red, Panic, Green };
    // chassis behind everything
    void nlChassis(Canvas& c);
    // a raised panel; title (blue small caps) is optional; sel = blue frame; dim = switched off look
    void nlPanel(Canvas& c, const RectF& r, const std::string& title = std::string(), bool sel = false, bool dim = false);
    // an inset well inside a panel
    void nlSub(Canvas& c, const RectF& r);
    // the black display
    void nlLcd(Canvas& c, const RectF& r, float radius = 7.0F);
    // a 3D key. state picks the colour: Plain (dark), Off (dark, dim text), Sel (blue), On (amber), Red, Panic, Green. lamp = the small bar at the top
    void nlBtn(Canvas& c, const RectF& r, const std::string& label, NlBtn state, float size = 14.0F, bool lamp = true);
    // black value box with a mono number
    void nlValue(Canvas& c, const RectF& r, const std::string& value, float size = 13.0F, ColorInt color = NL_VALUE);
    // knob: bezel, blue dots (value), silver cap, indicator. t 0..1; bipolar = dots from the middle; amber = amber indicator
    void nlKnob(Canvas& c, float cx, float cy, float r, float t, bool bipolar = false, bool amber = false, bool dots = true);
    // ribbed silver fader cap (cx, cy = its middle)
    void nlFaderCap(Canvas& c, float cx, float cy, float w = 44.0F, float h = 24.0F);
    // small caps label (blue = a panel title, grey = a control name)
    void nlLabel(Canvas& c, const std::string& s, float x, float y, bool center = true, ColorInt color = NL_TXT2, float size = 11.0F);
    void strokeRR(Canvas& c, const RectF& r, float radius, ColorInt color, float w);
    // top bar (logo, PREV, display, NEXT, SOUND SELECT, status, STORE, PANIC) and bottom nav (7 pages)
    void drawTopBar(Canvas& c);
    void drawBottomNav(Canvas& c);
    // SOUND SELECT / PREV / NEXT of the top bar
    void openListEntry(int index);          // the same as a tap on that LIST cell (asks about unsaved changes first)
    void stepBlend(int dir);                // PREV (-1) / NEXT (+1): the neighbouring filled position of the LIST
    // the COMBI page shows one of three screens: 0 LIVE, 1 MIXER, 2 SOUND EDIT
    int combiMode_ = 0;
    enum CombiMode { MODE_LIVE = 0, MODE_MIXER = 1, MODE_EDIT = 2 };
    void goPage(Page p, int combiMode = -1);

    // strip selection: touching anywhere inside one of these areas selects that UPPER (the touched key / knob still does its own job).
    // Every screen that shows UPPERs fills this list while it draws (it is emptied before each frame).
    std::vector<std::pair<RectF, int>> upperSelectAreas_;
    // the three screens of the COMBI page: LIVE, MIXER, SOUND EDIT (drawCombi picks by combiMode_)
    void drawCombiOld(Canvas& c);   // the old COMBI page (kept until every new screen is complete)
    enum EditGroup { EG_TUNE = 0, EG_RANGE, EG_VELOCITY, EG_FILTER, EG_ENVELOPE, EG_MODULATION, EG_WAVE, EG_EQ, EG_VOICE, EG_MIDICTL, EG_PARTTUNE, EG_COUNT };
    int editGroup_ = EG_VOICE;   // the common playing controls are the default editor
#include "silveton/ui/classic/view/Members_NLive.inc"
#include "silveton/ui/classic/view/Members_NEdit.inc"
#include "silveton/ui/classic/view/Members_NEdit2.inc"
#include "silveton/ui/classic/view/Members_NEngine.inc"
