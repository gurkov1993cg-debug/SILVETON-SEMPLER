// SILVETON_NEW_LOOK_V1 - SOUND EDIT frame and the groups SAMPLE (= drawEditTune), MULTISAMPLE (= drawEditRange), VELOCITY, FILTER, ENVELOPE, MODULATION
// (View_NEdit.cpp, View_Velocity.cpp)
    void drawSoundEdit(Canvas& c);   // chips of the 7 UPPERs, the group list, the content panel with SOUND selector, MARK / LINK / COPY / PASTE row
    void drawQuickControls(Canvas& c); // single page of the most used controls
    void drawEditPartTune(Canvas& c);   // Upper even decay and global SILVETON portamento setup
    void drawEditTune(Canvas& c);       // the group SAMPLE
    void drawEditRange(Canvas& c);      // the group MULTISAMPLE
    void drawEditVelocity(Canvas& c);   // View_Velocity.cpp
    void drawEditFilter(Canvas& c);
    void drawEditEnvelope(Canvas& c);
    void drawEditModulation(Canvas& c);

    // ---- small parts of these screens (also free to use in the other SOUND EDIT groups)
    static constexpr ColorInt NE_HINT = Color::rgb(138, 147, 157);   // the grey of the hint lines in the pictures (#8a939d)
    // a key of the pictures: Lit = a dark key with an amber lamp and amber text ("has a sound / is switched on", not the chosen one)
    enum class NeKey { Plain, Off, Sel, On, Lit };
    void neKey(Canvas& c, const RectF& r, const std::string& label, NeKey state, float size = 13.0F, bool lamp = true);
    // knob like knob() of the pictures: centre, outer size d, name above, value box below (vw = its width, 0 = 0.85 d); inert = only drawn (no touch);
    // hitW = width of the touch area (0 = a little wider than the knob and its value box)
    void neDial(Canvas& c, float cx, float cy, float d, const std::string& label, const std::string& valueText, float value, float minV, float maxV,
                float step, float travel, bool bipolar, std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset,
                float vw = 0.0F, float hitW = 0.0F, bool inert = false);
    // - [value] + like the pictures (label above); both keys together (or a double tap on the value) = onReset
    void neStepper(Canvas& c, float x, float y, const std::string& label, const std::string& value, std::function<void()> onMinus,
                   std::function<void()> onPlus, std::function<void()> onReset);
    void neStepper(Canvas& c, float x, float y, const std::string& label, const std::string& value, std::function<void()> onMinus,
                   std::function<void()> onPlus, std::function<void()> onReset, float width, float height,
                   float labelWidth, std::function<void()> onExact, float valueWidth = 0.0F);
    void neTouchSlider(Canvas& c, const RectF& r, bool vertical, float normalized,
                       std::function<void(float)> onChange, std::function<void()> onReset);
    static std::string neUpperName(int u);                           // "UPPER 1" .. "UPPER 6", "LOWER"
    // the ADSR picture of the ENVELOPE group (A D S R points are dragged) for the chosen sound
    void neAdsr(Canvas& c, const RectF& r, int u, int sound);
    void neTrack(Canvas& c, const RectF& r);                         // the dark groove of a bar
    // a bar with a blue part (lo..hi as 0..1 of the width), two amber handles and (velocity) the fade ramps as 0..1 of the width
    void neBar(Canvas& c, float x, float y, float w, float h, float lo, float hi, bool handles, float hr, bool dim, float fadeIn = 0.0F, float fadeOut = 0.0F);
    void neDashed(Canvas& c, const RectF& r, ColorInt color);       // the dashed frame
    void neKeyboard(Canvas& c, const RectF& r, int low, int high);  // all 128 keys, the range lit blue
    static UpperTab neTabOf(int group);                              // the old tab that goes with a group of the list (kept in `tab`)
    void neSetTranspose(int u, int sound, int v);                    // TRANSPOSE of the selected sound in QUICK CONTROLS
    void neSelectSound(int u, int k);                                // the SOUND selector: MAIN (0) / L1..L4; an empty place opens the sound list
    // Sound clipboard is deliberately separate from the complete PART clipboard.
    // CUT keeps the source intact until PASTE succeeds; destination settings stay put.
    struct SoundClip {
        silveton::sampler::SoundAssignment source;
        int upper{0}, slot{0}, bankSerial{0}, listEntry{-1};
        int soundId{0};
        std::string name, blendName;
        bool cut{false};
    };
    std::optional<SoundClip> copiedSound_;
    int soundSlotId(int upper, int slot);
    bool soundSlotHas(int upper,int slot) { return sampler.soundSource(upper,slot).hasSource(); }
    void moveLegacySolo(int upper,int sound);
    void drawSoloSource(Canvas& c,int upper,int sound);
    std::string soundSlotName(int upper, int slot);
    bool clearSoundSlot(int upper, int slot);
    void copySoundSlot(int upper, int slot, bool cut = false);
    void pasteSoundSlot(int upper, int slot);
    void applySoundPaste(const SoundClip& clip, int upper, int slot);
    void showSoundActions(int upper, int slot);
    void chooseSoundDestination(int upper, int slot);
    void drawSoundActions(Canvas& c, int upper, int slot);
    // the six legacy TONE values of a sound: 0 ATTACK 1 DECAY 2 SUSTAIN 3 RELEASE 4 CUTOFF 5 RESONANCE (-1 = the sound's own default)
    float neLegacy(int u, int sound, int k);
    void neSetLegacy(int u, int sound, int k, float v);
    void neLegacyExact(int u, int sound, int k);                     // the number page of one of them
    void neLegacyKnob(Canvas& c, float cx, float cy, float d, const std::string& label, int k);
    void neSoundRows(Canvas& c, int u, int sound, bool velocity);    // the five sounds as bars: KEY overlap (RANGE) or VELOCITY 1-127 (View_Velocity.cpp)

    // OFS: where the sound starts (ALL = START of the whole sound, MS1..MS4 = one value per velocity layer)
    int ofsSel_ = 0;
    struct NeZones { std::string key; std::vector<int> zones; bool valid{false}; };
    std::array<std::array<NeZones, 5>, 7> neZones_;
    std::vector<int> neVelZones(int u, int sound);
    float neOfsZone(int u, int sound, int k);
    void neSetOfsZone(int u, int sound, int k, float ms);
    void neSetOfsAll(int u, int sound, float ms);
    static std::string neOfsRange(const std::vector<int>& b, int k);
