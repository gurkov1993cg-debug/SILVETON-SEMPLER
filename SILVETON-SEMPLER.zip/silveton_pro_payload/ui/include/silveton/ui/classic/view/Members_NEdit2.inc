// SILVETON_NEW_LOOK_V1 - SOUND EDIT groups WAVE, EQ, VOICE, MIDI CONTROL (View_NEdit2.cpp, View_Eq.cpp)
    // each draws only the BODY inside the content panel (232,160,1088x490) in absolute design coordinates
    void drawEditWave(Canvas& c);
    void drawEditEq(Canvas& c);
    void drawEditVoice(Canvas& c);
    void drawEditMidiControl(Canvas& c);
    // small helpers of these four screens (same geometry as the picture generator)
    // text whose box TOP is at `top` (the generator places text by its top edge; this works out the baseline)
    void e2Text(Canvas& c, const std::string& s, float x, float top, float size, ColorInt color, const Opt& o = Opt());
    // small caps control name (grey), box top at `top`
    void e2Label(Canvas& c, const std::string& s, float x, float top);
    // knob like the picture: name above, blue dots, silver cap, black value box below. d = outer diameter, vw = value box width.
    // drag = value, hold the knob or tap the value = exact number, double tap = default
    void e2Knob(Canvas& c, float cx, float cy, float d, const std::string& label, const std::string& valueText, float value, float minV, float maxV,
                float step, float travel, bool bipolar, float vw, std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset);
    // the "lit" key of the pictures: a dark key with amber text and an amber lamp when on, grey text when off (sub = a small second line)
    void e2Lit(Canvas& c, const RectF& r, const std::string& label, const std::string& sub, bool on, float size, bool lamp = true);
    // EQ slider block at x (label, value box, - key, groove with fader cap, + key); y positions are fixed (522 / 548 / 562)
    void e2Slider(Canvas& c, float x, const std::string& label, const std::string& value, float t, std::function<void(float)> onDrag,
                  std::function<void()> plus, std::function<void()> minus, std::function<void()> exact);
