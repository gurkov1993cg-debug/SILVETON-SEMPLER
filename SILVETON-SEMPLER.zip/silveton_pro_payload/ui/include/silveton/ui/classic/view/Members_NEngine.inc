// Source selection uses the shared UPPER sound picker.
