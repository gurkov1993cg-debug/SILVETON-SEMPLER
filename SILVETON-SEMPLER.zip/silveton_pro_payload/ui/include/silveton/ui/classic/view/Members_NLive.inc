// SILVETON_NEW_LOOK_V1 - LIVE and MIXER screens (View_NLive.cpp)
    void drawLive(Canvas& c);
    void drawMixer(Canvas& c);

    // ---- helpers of these two screens (prefix lv)
    // look of a key: Off = grey text, Plain = normal, Lit = dark key with amber text and an amber lamp (the "lit" key of the pictures), On = amber key, Red = red key
    enum class LvLook { Off, Plain, Lit, On, Red };
    // what one strip shows: the sound chosen on its chips (0 = MAIN, 1..4 = L1..L4) and its values (the same numbers the old strip used)
    struct LvStrip {
        int ls{0};
        bool layerView{false}, lHas{false}, lOn{false}, empty{true}, live{false}, dim{false}, mute{false};
        std::vector<float> lp;
        std::string name;
        float pan{0.0F}, level{0.0F};
        int low{0}, high{127};
    };
    LvStrip lvStripData(int i, const UpperState& s);
    // the number of the sound in its place (asked from the engine only when the name changed, or once a second)
    int lvSoundSlot(int i, const std::string& name);
    std::array<std::string, 7> lvSlotName_;
    std::array<int, 7> lvSlotVal_{};
    std::array<std::int64_t, 7> lvSlotMs_{};
    // the peak of a meter on the scale of the fader (0 = -60 dB or less, 1 = +12 dB)
    static float lvMeterT(float peak);
    // a key; sub = a small second line (may be empty); spacing = letter spacing in em. Only draws; the caller registers the touch with hit(...)
    void lvKey(Canvas& c, const RectF& r, const std::string& label, const std::string& sub, LvLook look, float size, bool lamp, float spacing = 0.07F);
    // knob like the picture: name above, blue dots, silver cap, black value box below. diam = outer size in the picture (box top = centre + diam/2 - 2)
    void lvKnobFace(Canvas& c, float cx, float cy, float diam, float t01, bool bipolar, bool amber, const std::string& label, const std::string& value, float vw);
    // the 25 segments of one level meter (blue, amber, red) with its top at y
    void lvSegMeter(Canvas& c, float x, float y, float peak);
    // panel of one strip (blue frame = chosen UPPER, amber frame = marked), title, lamp; registers the "touch anywhere selects this UPPER" area
    void lvStripFrame(Canvas& c, const RectF& r, int i, const LvStrip& d);
    // the chips M, L1..L4 (amber = plays, blue ring = shown); a tap shows that sound (an empty place opens the sound picker)
    void lvChips(Canvas& c, float x, float y, float w, int i, const UpperState& s, const LvStrip& d);
    // ON / SOLO / MUTE of one strip; x = strip left, y = top of the keys
    void lvOnSoloMute(Canvas& c, float x, float y, float h, int i, const UpperState& s, const LvStrip& d);
    void lvLiveStrip(Canvas& c, const RectF& r, int i, const UpperState& s, std::pair<float, float> meter);
    void lvMixStrip(Canvas& c, const RectF& r, int i, const UpperState& s, std::pair<float, float> meter);
    // the 7 strips of one screen (+ the mark mode touch)
    void lvStrips(Canvas& c, bool mixer);
    // VOICE / PORTAMENTO / CONTROLLERS / PITCH BEND of the chosen UPPER (LIVE)
    void lvPanels(Canvas& c);
    // MARK / LINK / COPY U / PASTE U (four keys from x = 20, key height h, top y); the same row can be used by other screens
    void lvMarkRow(Canvas& c, float y, float h);
