    void openScalePage();
    void closeScalePage();
    bool scaleEngineTargets_{false};
    // SILVETON_SCALE_TUNING_V1: the SCALE key of the LIST row (musical tuning: by hand, ready ones, your own)
    void showScaleMenu();
    // SILVETON_SCALE_PAGE_V1 (Цветомир, 04.11.2026): SCALE is a page of its own (opened by the SCALE key of the LIST row): one octave of the keyboard (cents), ready scales + tonic, my scales
    bool scaleOpen_ = false;
    int scaleTonic_ = 0;                 // the tonic the ready scales are turned to
    int scaleSel_ = 0;                   // the note (0 = C ... 11 = B) that the keyboard has chosen for tuning
    int scaleOwnTop_ = 0;                // the first row of MY SCALES that is shown
    int scaleLivePc_ = -1;               // the note that a finger is moving now (-1 none) and the value it shows meanwhile
    float scaleLiveVal_ = 0.0F;
    void drawScalePage(Canvas& c);
    int scaleActivePreset() const;
    void scaleApplyPreset(int i);
    void scaleSpark(Canvas& c, float x, float cy, const std::vector<float>& cents);   // the little 12-bar picture of a scale
    void showScaleManual();
    void showScalePresets();
    void showScaleTonic(int preset);
    void showScaleOwn(bool deleting);
    std::string scaleTitle() const;
