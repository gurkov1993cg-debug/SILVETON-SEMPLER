    // Import is a read-only browser until the final action. Kept at the end of
    // the view so existing view members retain their offsets in preview builds.
    struct SetImportState {
        enum class Stage { Files, Blends, Destination, Confirm };
        struct Entry { std::string name, path; bool folder{false}; };
        Stage stage{Stage::Files};
        std::string directory, sourcePath, error;
        std::vector<Entry> entries;
        Ctrl::ListClipboard catalog;
        std::set<int> selected;
        int page{0}, fileSelected{-1}, destination{0}, paintMode{-1};
    };
    void openSetImport();
    void setImportBack();
    void setImportReadDirectory(const std::string& directory);
    void setImportOpenFile(const std::string& path);
    void setImportChooseDestination();
    void setImportApply();
    void drawSetImport(Canvas& c);
    std::shared_ptr<SetImportState> setImport_;
