// SILVETON_MAC_VIEW_V1 - the EFFECTS page (tablet SilvetonSamplerView.kt lines 2582-2721)
    void tapTempo(int unit);
    std::vector<std::int64_t> tapTimes;
