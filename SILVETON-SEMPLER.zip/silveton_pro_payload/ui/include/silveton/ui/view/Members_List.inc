// SILVETON_MAC_VIEW_V1 - the LIST and WRITE pages (tablet SilvetonSamplerView.kt lines 2053-2581)
    // LIST
    void drawList(Canvas& c);
    std::vector<int> listVisible();
    std::optional<ListItem> realListItem(int index);
    void listGridCell(Canvas& c, const RectF& r, int idx, const std::optional<ListItem>& item, bool active, bool chosen);
    void storeToList();
    void saveSetAs();
    void loadSet();
    void listCard(Canvas& c, const RectF& r, const std::optional<ListItem>& item, int idx, bool selected);
    static std::string blendAddress(const ListItem& item);
    void editListCombi(const ListItem& item, int index);
    void showListContextMenu(int index, const ListItem& item);
    // WRITE / COPY / MOVE (Korg style)
    void openWrite(WriteTarget target, bool append);
    void openPositionPicker(WriteMode mode, int source);
    std::optional<std::string> writeListName(int pos);
    int firstFreeListPosition(int after = -1);
    void selectWriteTarget(WriteTarget target, bool append);
    std::optional<std::string> writeOccupiedName(int pos);
    void drawWriteScreen(Canvas& c);
    void writeCell(Canvas& c, const RectF& r, int number, const std::optional<std::string>& name, bool usable, bool selected, bool source = false);
    void confirmWrite();
    void doWriteList(int pos, const std::string& name);
    void doWriteBlend(int slot, const std::string& name);
    void doCopyOrMove(bool move, int from, int to);
