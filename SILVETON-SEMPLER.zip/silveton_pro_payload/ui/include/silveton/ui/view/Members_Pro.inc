// SILVETON_PRO_UI_V1 - the professional frame: the top bar, the COMBI strips with the page keys below, the full ENGINE and FX
// pages, and the language of the screens (БЪЛГАРСКИ by default, ENGLISH from SETTINGS).
    Xf xf_{};                 // the transform the controls are drawn with right now
    Xf legacyXf_{};           // the one of the older page drawn in this picture (swipes of the LIST / picker)
    float downXd = 0.0F;      // where the finger went down, design units (downX / downY are in the touched control's own units)
    float downYd = 0.0F;
    void beginXf(Canvas& c, const Xf& x);
    void endXf(Canvas& c);
    static Xf fitXf(const RectF& from, const RectF& to);   // `from` (the old place) shown uniformly inside `to`, centred
    RectF stripRect(int i) const;                         // an Upper strip on the COMBI page (design units)
    bool fullPageTab() const { return tab == UpperTab::ENGINE || tab == UpperTab::FX || tab == UpperTab::EQ || tab == UpperTab::MIXER; }
    void drawTopBar(Canvas& c);
    void drawBottomTabs(Canvas& c);
    void drawEditorHeader(Canvas& c);
    void proPanel(Canvas& c, const RectF& r, const std::string& title, const std::string& sub = std::string());
    void proKey(Canvas& c, const RectF& r, const std::string& label, bool on, float size = 12.0F, ColorInt onColor = C_ACCENT);
    void proField(Canvas& c, const RectF& r, const std::string& value, float size = 14.0F, bool arrow = false);
    void drawEnginePage(Canvas& c, int u);
    void drawEngineVis(Canvas& c, const RectF& r, int u, int type);
    void engineBox(Canvas& c, const RectF& r, int u, const std::string& title, const std::vector<const ::silveton::sampler::EngineParamDef*>& items);
    void engineBend(Canvas& c, const RectF& r, int u, int id, const std::string& label);
    void drawFxPage(Canvas& c);
    // SILVETON_OFS_V1: OFS of the velocity layers (MS1 = the hardest .. MS4), on the TONE page and on ENGINE > OFS
    int ofsSel_ = 0;          // TONE page: 0 = ВСИЧКИ (START of the whole sound), 1..4 = MS1..MS4
    std::array<std::array<std::optional<std::vector<int>>, 5>, 7> velZoneCache_;
    std::vector<int> velZones(int u, int sound);
    float ofsZone(int u, int sound, int k);                 // ms, -1 = as ВСИЧКИ (START)
    void setOfsZone(int u, int sound, int k, float ms);
    void setOfsAll(int u, int sound, float ms);             // START for the whole sound (the layers follow it again)
    static std::string ofsRange(const std::vector<int>& bottoms, int k);
    void drawOfsPage(Canvas& c, const RectF& area, int u);
    void drawFxParams(Canvas& c, const RectF& r, int unit);
    // the language of the screens: 0 БЪЛГАРСКИ (default), 1 ENGLISH
    int uiLang_ = 0;
    std::unordered_map<std::string, std::string> trCache_;
    const std::string& tr(const std::string& s);
    void setLanguage(int lang);
    // SILVETON_THEMES_V1: the colour theme: 0 ГРАФИТ (default), 1 СВЕТЛА, 2 ЧЕРНА, 3 КЛАСИКА, 4 СТАРА
    int uiTheme_ = 0;
    void setTheme(int theme);
    // SILVETON_OLD_THEME_V1: theme 4 СТАРА = the whole old look of the sampler. It lives in classic_ and takes every call of the shell
    // (touch, drawing, keys ...) while it is on; its SETTINGS page asks to go back to one of the new themes (classicLeave_).
    std::unique_ptr<classic::SilvetonSamplerView> classic_;
    int classicLeave_ = -1;
    bool softKeyboardOn_ = false;
    std::string warningText_;                    // the last warning of the shell (under warningMutex_)
    std::atomic<unsigned> warningSerial_{0U};    // counts the warnings, so the old look gets them on the drawing thread
    unsigned warningApplied_ = 0U;
    void enterClassic();
    void settleClassic();
    void syncClassic();
