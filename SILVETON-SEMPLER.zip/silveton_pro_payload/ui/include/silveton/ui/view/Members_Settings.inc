// SILVETON_MAC_VIEW_V1 - the SETTINGS page (tablet SilvetonSamplerView.kt lines 2723-2928 and 3388-3470)
    void drawSettings(Canvas& c);
    void drawBankInfo(Canvas& c, const RectF& b);
    void drawMidiSettings(Canvas& c, const RectF& b);
    void showDeleteSounds(const Ctrl::BankInfo& info);
    void runDeleteSounds(const std::vector<int>& slots);
    void editGlobal(int i, const GlobalUiState& g);
    void resetGlobal(int i, const GlobalUiState& g);
    static float globalStep(int i);
    static float globalTravel(int i);
    static std::array<float, 3> globalSliderSpec(int i, const GlobalUiState& g);
    static GlobalUiState globalWithSliderValue(int i, const GlobalUiState& g, float v);
    static std::string globalValueText(int i, const GlobalUiState& g);
    static std::string mb(long long bytes);
