// SILVETON_MAC_GFX_V1 - fonts: loads the bundled font files and turns text into letter outlines.
#include "FontInternal.h"

#include "stb_truetype.h"

#include <cmath>
#include <fstream>
#include <iterator>
#include <map>
#include <memory>
#include <mutex>
#include <unordered_map>

namespace silveton::ui {
namespace detail {

std::vector<std::uint32_t> decodeUtf8(const std::string& s) {
    std::vector<std::uint32_t> out;
    out.reserve(s.size());
    std::size_t i = 0U;
    while (i < s.size()) {
        const auto c = static_cast<unsigned char>(s[i]);
        std::uint32_t cp = 0xFFFDU;
        std::size_t len = 1U;
        if (c < 0x80U) {
            cp = c;
        } else if ((c & 0xE0U) == 0xC0U && i + 1U < s.size()) {
            cp = (static_cast<std::uint32_t>(c & 0x1FU) << 6U) | (static_cast<unsigned char>(s[i + 1U]) & 0x3FU);
            len = 2U;
        } else if ((c & 0xF0U) == 0xE0U && i + 2U < s.size()) {
            cp = (static_cast<std::uint32_t>(c & 0x0FU) << 12U) | (static_cast<std::uint32_t>(static_cast<unsigned char>(s[i + 1U]) & 0x3FU) << 6U) |
                 (static_cast<unsigned char>(s[i + 2U]) & 0x3FU);
            len = 3U;
        } else if ((c & 0xF8U) == 0xF0U && i + 3U < s.size()) {
            cp = (static_cast<std::uint32_t>(c & 0x07U) << 18U) | (static_cast<std::uint32_t>(static_cast<unsigned char>(s[i + 1U]) & 0x3FU) << 12U) |
                 (static_cast<std::uint32_t>(static_cast<unsigned char>(s[i + 2U]) & 0x3FU) << 6U) | (static_cast<unsigned char>(s[i + 3U]) & 0x3FU);
            len = 4U;
        }
        out.push_back(cp);
        i += len;
    }
    return out;
}

std::string encodeUtf8(const std::vector<std::uint32_t>& cps, std::size_t from, std::size_t to) {
    std::string out;
    to = std::min(to, cps.size());
    for (std::size_t i = from; i < to; ++i) {
        const std::uint32_t cp = cps[i];
        if (cp < 0x80U) {
            out += static_cast<char>(cp);
        } else if (cp < 0x800U) {
            out += static_cast<char>(0xC0U | (cp >> 6U));
            out += static_cast<char>(0x80U | (cp & 0x3FU));
        } else if (cp < 0x10000U) {
            out += static_cast<char>(0xE0U | (cp >> 12U));
            out += static_cast<char>(0x80U | ((cp >> 6U) & 0x3FU));
            out += static_cast<char>(0x80U | (cp & 0x3FU));
        } else {
            out += static_cast<char>(0xF0U | (cp >> 18U));
            out += static_cast<char>(0x80U | ((cp >> 12U) & 0x3FU));
            out += static_cast<char>(0x80U | ((cp >> 6U) & 0x3FU));
            out += static_cast<char>(0x80U | (cp & 0x3FU));
        }
    }
    return out;
}

namespace {

struct FontFile {
    std::vector<unsigned char> data;
    stbtt_fontinfo info{};
    bool ok{false};
    std::unordered_map<std::uint32_t, std::unique_ptr<GlyphOutline>> outlines;   // by glyph index
};

struct FontBook {
    std::string directory;
    std::map<std::string, std::unique_ptr<FontFile>> files;
    bool loaded{false};

    FontFile* file(const std::string& name) {
        auto it = files.find(name);
        if (it != files.end()) return it->second.get();
        auto ff = std::make_unique<FontFile>();
        std::ifstream in(directory + "/" + name, std::ios::binary);
        if (in) {
            ff->data.assign(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
            const int offset = stbtt_GetFontOffsetForIndex(ff->data.data(), 0);
            if (offset >= 0 && stbtt_InitFont(&ff->info, ff->data.data(), offset) != 0) ff->ok = true;
        }
        FontFile* raw = ff.get();
        files[name] = std::move(ff);
        return raw;
    }
};

FontBook& book() {
    static FontBook b;
    return b;
}

// the font and its fallback for symbols
std::vector<FontFile*> chainFor(Face face) {
    FontBook& b = book();
    switch (face) {
        case Face::Regular: return {b.file("Roboto-Regular.ttf"), b.file("DejaVuSans.ttf")};
        case Face::Bold: return {b.file("Roboto-Bold.ttf"), b.file("DejaVuSans-Bold.ttf")};
        case Face::Mono: return {b.file("DejaVuSansMono.ttf"), b.file("DejaVuSans.ttf")};
        case Face::MonoBold: return {b.file("DejaVuSansMono-Bold.ttf"), b.file("DejaVuSans-Bold.ttf")};
    }
    return {};
}

void flattenQuad(std::vector<float>& c, float x0, float y0, float cx, float cy, float x1, float y1) {
    const float len = std::hypot(cx - x0, cy - y0) + std::hypot(x1 - cx, y1 - cy);
    const int n = std::clamp(static_cast<int>(std::ceil(std::sqrt(len / 14.0F))), 3, 20);
    for (int i = 1; i <= n; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(n);
        const float u = 1.0F - t;
        c.push_back(u * u * x0 + 2.0F * u * t * cx + t * t * x1);
        c.push_back(u * u * y0 + 2.0F * u * t * cy + t * t * y1);
    }
}

void flattenCubic(std::vector<float>& c, float x0, float y0, float c1x, float c1y, float c2x, float c2y, float x1, float y1) {
    const float len = std::hypot(c1x - x0, c1y - y0) + std::hypot(c2x - c1x, c2y - c1y) + std::hypot(x1 - c2x, y1 - c2y);
    const int n = std::clamp(static_cast<int>(std::ceil(std::sqrt(len / 14.0F))), 3, 24);
    for (int i = 1; i <= n; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(n);
        const float u = 1.0F - t;
        c.push_back(u * u * u * x0 + 3.0F * u * u * t * c1x + 3.0F * u * t * t * c2x + t * t * t * x1);
        c.push_back(u * u * u * y0 + 3.0F * u * u * t * c1y + 3.0F * u * t * t * c2y + t * t * t * y1);
    }
}

const GlyphOutline* outlineOf(FontFile& f, int glyph) {
    const auto key = static_cast<std::uint32_t>(glyph);
    auto it = f.outlines.find(key);
    if (it != f.outlines.end()) return it->second.get();
    auto out = std::make_unique<GlyphOutline>();
    int adv = 0, lsb = 0;
    stbtt_GetGlyphHMetrics(&f.info, glyph, &adv, &lsb);
    out->advance = static_cast<float>(adv);
    out->unitsPerEm = 1.0F / stbtt_ScaleForMappingEmToPixels(&f.info, 1.0F);
    stbtt_vertex* verts = nullptr;
    const int n = stbtt_GetGlyphShape(&f.info, glyph, &verts);
    std::vector<float>* cur = nullptr;
    float px = 0.0F, py = 0.0F;
    for (int i = 0; i < n; ++i) {
        const stbtt_vertex& v = verts[i];
        const auto x = static_cast<float>(v.x);
        const auto y = static_cast<float>(v.y);
        switch (v.type) {
            case STBTT_vmove:
                out->contours.emplace_back();
                cur = &out->contours.back();
                cur->push_back(x);
                cur->push_back(y);
                break;
            case STBTT_vline:
                if (cur != nullptr) { cur->push_back(x); cur->push_back(y); }
                break;
            case STBTT_vcurve:
                if (cur != nullptr) flattenQuad(*cur, px, py, static_cast<float>(v.cx), static_cast<float>(v.cy), x, y);
                break;
            case STBTT_vcubic:
                if (cur != nullptr) flattenCubic(*cur, px, py, static_cast<float>(v.cx), static_cast<float>(v.cy), static_cast<float>(v.cx1), static_cast<float>(v.cy1), x, y);
                break;
            default: break;
        }
        px = x;
        py = y;
    }
    if (verts != nullptr) stbtt_FreeShape(&f.info, verts);
    const GlyphOutline* raw = out.get();
    f.outlines[key] = std::move(out);
    return raw;
}

} // namespace

std::vector<ShapedGlyph> shapeText(const std::string& utf8, Face face, float sizePx) {
    std::vector<ShapedGlyph> out;
    const auto cps = decodeUtf8(utf8);
    out.reserve(cps.size());
    const auto chain = chainFor(face);
    for (const std::uint32_t cp : cps) {
        FontFile* use = nullptr;
        int glyph = 0;
        for (FontFile* f : chain) {
            if (f == nullptr || !f->ok) continue;
            const int g = stbtt_FindGlyphIndex(&f->info, static_cast<int>(cp));
            if (g != 0) { use = f; glyph = g; break; }
        }
        if (use == nullptr) {
            // not in any font: the first font's "missing letter" box, but nothing for blanks and controls
            for (FontFile* f : chain) if (f != nullptr && f->ok) { use = f; break; }
            glyph = 0;
            if (cp < 0x20U || cp == 0xA0U) { glyph = use != nullptr ? stbtt_FindGlyphIndex(&use->info, 0x20) : 0; }
        }
        ShapedGlyph g;
        if (use != nullptr) {
            g.outline = outlineOf(*use, glyph);
            g.scale = sizePx / g.outline->unitsPerEm;
            g.advancePx = g.outline->advance * g.scale;
        }
        out.push_back(g);
    }
    return out;
}

} // namespace detail

void setFontDirectory(const std::string& directory) {
    detail::FontBook& b = detail::book();
    if (b.directory != directory) {
        b.files.clear();
        b.directory = directory;
    }
}

bool fontsReady() {
    const auto chain = detail::chainFor(Face::Regular);
    return !chain.empty() && chain[0] != nullptr && chain[0]->ok;
}

} // namespace silveton::ui
