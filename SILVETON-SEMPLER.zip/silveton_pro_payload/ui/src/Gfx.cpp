// SILVETON_MAC_GFX_V1 - the software renderer behind Canvas / Paint / Path / Shader (see Gfx.h).
#include "silveton/ui/Gfx.h"

#include "FontInternal.h"

#include <atomic>
#include <cmath>
#include <cstring>
#include <limits>

#if defined(__SSE2__)
#include <emmintrin.h>
#endif

namespace silveton::ui {
namespace {

constexpr float kPi = 3.14159265358979323846F;

inline int div255(int x) noexcept { return (x + 128 + ((x + 128) >> 8)) >> 8; }

inline std::uint32_t premultiply(ColorInt c) noexcept {
    const int a = Color::alpha(c);
    if (a == 255) return c;
    if (a == 0) return 0U;
    const int r = div255(Color::red(c) * a);
    const int g = div255(Color::green(c) * a);
    const int b = div255(Color::blue(c) * a);
    return (static_cast<std::uint32_t>(a) << 24U) | (static_cast<std::uint32_t>(r) << 16U) | (static_cast<std::uint32_t>(g) << 8U) | static_cast<std::uint32_t>(b);
}

// two 8-bit values (bits 0-7 and 16-23) times k, divided by 255 with rounding - the same result as div255 for each of them
inline std::uint32_t mulDiv255x2(std::uint32_t x, std::uint32_t k) noexcept {
    const std::uint32_t v = x * k + 0x00800080U;
    return ((v + ((v >> 8) & 0x00FF00FFU)) >> 8) & 0x00FF00FFU;
}

// scale every channel of a premultiplied colour by k/255
inline std::uint32_t scalePremul(std::uint32_t c, int k) noexcept {
    if (k >= 255) return c;
    if (k <= 0) return 0U;
    const auto kk = static_cast<std::uint32_t>(k);
    return mulDiv255x2(c & 0x00FF00FFU, kk) | (mulDiv255x2((c >> 8) & 0x00FF00FFU, kk) << 8U);
}

// per-channel addition that stops at 255
inline std::uint32_t addSaturated(std::uint32_t a, std::uint32_t b) noexcept {
    const std::uint32_t low = (a & 0x7F7F7F7FU) + (b & 0x7F7F7F7FU);
    const std::uint32_t sum = ((a ^ b) & 0x80808080U) ^ low;                        // the sum of every channel modulo 256
    const std::uint32_t carry = ((a & b) | ((a | b) & ~sum)) & 0x80808080U;         // channels that went beyond 255
    return sum | ((carry >> 7U) * 255U);
}

// source (already premultiplied) over destination
inline std::uint32_t over(std::uint32_t dst, std::uint32_t src) noexcept {
    const std::uint32_t sa = src >> 24U;
    if (sa == 255U) return src;
    if (sa == 0U) return dst;
    const std::uint32_t inv = 255U - sa;
    const std::uint32_t scaled = mulDiv255x2(dst & 0x00FF00FFU, inv) | (mulDiv255x2((dst >> 8U) & 0x00FF00FFU, inv) << 8U);
    return addSaturated(scaled, src);
}

// one translucent colour over a run of pixels (the same arithmetic as over(), four pixels at a time where the CPU can)
inline void overSolidRun(std::uint32_t* p, int n, std::uint32_t src) noexcept {
    int i = 0;
#if defined(__SSE2__) && !defined(SILVETON_GFX_FORCE_GENERIC_SIMD)
    const std::uint32_t inv = 255U - (src >> 24U);
    const __m128i zero = _mm_setzero_si128();
    const __m128i vinv = _mm_set1_epi16(static_cast<short>(inv));
    const __m128i round = _mm_set1_epi16(0x80);
    const __m128i vsrc = _mm_set1_epi32(static_cast<int>(src));
    for (; i + 4 <= n; i += 4) {
        const __m128i d = _mm_loadu_si128(reinterpret_cast<const __m128i*>(p + i));
        __m128i lo = _mm_add_epi16(_mm_mullo_epi16(_mm_unpacklo_epi8(d, zero), vinv), round);
        __m128i hi = _mm_add_epi16(_mm_mullo_epi16(_mm_unpackhi_epi8(d, zero), vinv), round);
        lo = _mm_srli_epi16(_mm_add_epi16(lo, _mm_srli_epi16(lo, 8)), 8);
        hi = _mm_srli_epi16(_mm_add_epi16(hi, _mm_srli_epi16(hi, 8)), 8);
        _mm_storeu_si128(reinterpret_cast<__m128i*>(p + i), _mm_adds_epu8(_mm_packus_epi16(lo, hi), vsrc));
    }
#elif defined(__GNUC__) || defined(__clang__)
    // SILVETON_FAST_DRAW_V1: the tablet (ARM) - exactly over() (mulDiv255x2 + addSaturated), done on four pixels at once with
    // the compiler's vector types (NEON on the tablet). Every lane does the same integer steps as the single-pixel code.
    typedef std::uint32_t U32x4 __attribute__((vector_size(16)));
    const std::uint32_t inv = 255U - (src >> 24U);
    const U32x4 vinv = {inv, inv, inv, inv};
    const U32x4 mask = {0x00FF00FFU, 0x00FF00FFU, 0x00FF00FFU, 0x00FF00FFU};
    const U32x4 half = {0x00800080U, 0x00800080U, 0x00800080U, 0x00800080U};
    const U32x4 k7 = {0x7F7F7F7FU, 0x7F7F7F7FU, 0x7F7F7F7FU, 0x7F7F7F7FU};
    const U32x4 k8 = {0x80808080U, 0x80808080U, 0x80808080U, 0x80808080U};
    const U32x4 vs = {src, src, src, src};
    for (; i + 4 <= n; i += 4) {
        U32x4 d;
        std::memcpy(&d, p + i, sizeof(d));
        U32x4 lo = (d & mask) * vinv + half;
        lo = ((lo + ((lo >> 8) & mask)) >> 8) & mask;
        U32x4 hi = ((d >> 8) & mask) * vinv + half;
        hi = ((hi + ((hi >> 8) & mask)) >> 8) & mask;
        const U32x4 a = lo | (hi << 8);
        const U32x4 low = (a & k7) + (vs & k7);
        const U32x4 sum = ((a ^ vs) & k8) ^ low;
        const U32x4 carry = ((a & vs) | ((a | vs) & ~sum)) & k8;
        const U32x4 r = sum | ((carry >> 7) * 255U);
        std::memcpy(p + i, &r, sizeof(r));
    }
#endif
    for (; i < n; ++i) p[i] = over(p[i], src);
}

float signedArea(const std::vector<float>& xy) {
    double a = 0.0;
    const std::size_t n = xy.size() / 2U;
    for (std::size_t i = 0U; i < n; ++i) {
        const std::size_t j = (i + 1U) % n;
        a += static_cast<double>(xy[2U * i]) * static_cast<double>(xy[2U * j + 1U]) - static_cast<double>(xy[2U * j]) * static_cast<double>(xy[2U * i + 1U]);
    }
    return static_cast<float>(a * 0.5);
}

void reversePoly(std::vector<float>& xy) {
    const std::size_t n = xy.size() / 2U;
    for (std::size_t i = 0U; i < n / 2U; ++i) {
        std::swap(xy[2U * i], xy[2U * (n - 1U - i)]);
        std::swap(xy[2U * i + 1U], xy[2U * (n - 1U - i) + 1U]);
    }
}

// ---------------------------------------------------------------- coverage accumulation (exact area, nonzero-ish)
// a: accumulation buffer (w+2 columns, h rows). The edge is already in buffer coordinates.
// Only the rows [rowLo, rowHi) are stored (row y of the shape is row y - rowLo of the buffer), but the walk down the edge is the
// same for every band, so the numbers in the stored rows do not depend on which rows were asked for.
void accumulateLine(float* a, int stride, int h, int rowLo, int rowHi, float x0, float y0, float x1, float y1) {
    if (y0 == y1) return;
    // SILVETON_GFX_SAFE_POLY_V1: a value that is not a number cannot be turned into a row or column
    if (!std::isfinite(x0) || !std::isfinite(y0) || !std::isfinite(x1) || !std::isfinite(y1)) return;
    const int lastCol = stride - 2;   // the row has stride = w + 2 floats: columns 0..w+1 may be written (x1i + 1 at most)
    float dir = 1.0F;
    if (y0 > y1) { std::swap(x0, x1); std::swap(y0, y1); dir = -1.0F; }
    if (y1 <= 0.0F || y0 >= static_cast<float>(h)) return;
    const float dxdy = (x1 - x0) / (y1 - y0);
    if (!std::isfinite(dxdy)) return;   // SILVETON_GFX_SAFE_POLY_V1
    float x = x0;
    if (y0 < 0.0F) x -= y0 * dxdy;
    if (!std::isfinite(x)) return;
    const int yStart = std::max(0, static_cast<int>(std::floor(y0)));
    const int yEnd = std::min(h, static_cast<int>(std::ceil(y1)));
    for (int y = yStart; y < yEnd; ++y) {
        const float dy = std::min(static_cast<float>(y + 1), y1) - std::max(static_cast<float>(y), y0);
        const float xnext = x + dxdy * dy;
        if (y >= rowHi) break;
        if (y < rowLo) { x = xnext; continue; }
        float* row = a + static_cast<std::ptrdiff_t>(y - rowLo) * stride;
        const float d = dy * dir;
        const float xa = std::min(x, xnext);
        const float xb = std::max(x, xnext);
        const float x0floor = std::floor(xa);
        const int x0i = std::clamp(static_cast<int>(x0floor), 0, lastCol);
        const float x1ceil = std::ceil(xb);
        const int x1i = std::clamp(static_cast<int>(x1ceil), 0, lastCol);
        if (x1i <= x0i + 1) {
            const float xmf = 0.5F * (x + xnext) - x0floor;
            row[x0i] += d - d * xmf;
            row[x0i + 1] += d * xmf;
        } else {
            const float s = 1.0F / (xb - xa);
            const float x0f = xa - x0floor;
            const float a0 = 0.5F * s * (1.0F - x0f) * (1.0F - x0f);
            const float x1f = xb - x1ceil + 1.0F;
            const float am = 0.5F * s * x1f * x1f;
            row[x0i] += d * a0;
            if (x1i == x0i + 2) {
                row[x0i + 1] += d * (1.0F - a0 - am);
            } else {
                const float a1 = s * (1.5F - x0f);
                row[x0i + 1] += d * (a1 - a0);
                for (int xi = x0i + 2; xi < x1i - 1; ++xi) row[xi] += d * s;
                const float a2 = a1 + static_cast<float>(x1i - x0i - 3) * s;
                row[x1i - 1] += d * (1.0F - a2 - am);
            }
            row[x1i] += d * am;
        }
        x = xnext;
    }
}

// Clips the edge sideways to the buffer (outside parts become vertical lines on the border) and accumulates it.
void accumulateEdge(float* a, int stride, int w, int h, int rowLo, int rowHi, float x0, float y0, float x1, float y1) {
    if (y0 == y1) return;
    const auto fw = static_cast<float>(w);
    // work with y0 < y1 and remember the direction
    float dir = 1.0F;
    if (y0 > y1) { std::swap(x0, x1); std::swap(y0, y1); dir = -1.0F; }
    auto put = [&](float xa, float ya, float xb, float yb) {
        xa = std::clamp(xa, 0.0F, fw);
        xb = std::clamp(xb, 0.0F, fw);
        if (dir > 0.0F) accumulateLine(a, stride, h, rowLo, rowHi, xa, ya, xb, yb);
        else accumulateLine(a, stride, h, rowLo, rowHi, xb, yb, xa, ya);
    };
    if ((x0 >= 0.0F && x0 <= fw && x1 >= 0.0F && x1 <= fw) || (x0 <= 0.0F && x1 <= 0.0F) || (x0 >= fw && x1 >= fw)) {
        put(x0, y0, x1, y1);
        return;
    }
    const float dxdy = (x1 - x0) / (y1 - y0);
    // SILVETON_GFX_SAFE_POLY_V1: a slope that overflowed (a corner far outside, a near-horizontal edge) would make the cut
    // points NaN and the row index garbage; such an edge has no visible height here, it is left out.
    if (!std::isfinite(dxdy)) return;
    float cuts[2];
    int n = 0;
    for (const float border : {0.0F, fw}) {
        if ((x0 < border) != (x1 < border)) cuts[n++] = y0 + (border - x0) / dxdy;
    }
    if (n == 2 && cuts[0] > cuts[1]) std::swap(cuts[0], cuts[1]);
    float ya = y0;
    for (int i = 0; i <= n; ++i) {
        const float yb = i < n ? std::clamp(cuts[i], y0, y1) : y1;
        if (yb > ya) put(x0 + dxdy * (ya - y0), ya, x0 + dxdy * (yb - y0), yb);
        ya = yb;
    }
}

} // namespace

// ====================================================================== shaders
float Shader::parameterAt(float x, float y) const noexcept {
    switch (kind) {
        case Kind::Linear: {
            const float dx = x1 - x0;
            const float dy = y1 - y0;
            const float len2 = dx * dx + dy * dy;
            if (len2 <= 0.0F) return 0.0F;
            return ((x - x0) * dx + (y - y0) * dy) / len2;
        }
        case Kind::Radial: {
            if (radius <= 0.0F) return 0.0F;
            return std::hypot(x - cx, y - cy) / radius;
        }
        case Kind::Sweep: {
            float a = std::atan2(y - cy, x - cx) / (2.0F * kPi);
            if (a < 0.0F) a += 1.0F;
            return a;
        }
    }
    return 0.0F;
}

namespace {
// interpolates the colour stops without premultiplying (like Android's default), result as floats 0..255
void interpolateStops(const Shader& s, float t, float out[4]) {
    const std::size_t n = s.colors.size();
    if (n == 0U) { out[0] = out[1] = out[2] = out[3] = 0.0F; return; }
    auto comp = [&](std::size_t i, float* o) {
        const ColorInt c = s.colors[i];
        o[0] = static_cast<float>(Color::alpha(c));
        o[1] = static_cast<float>(Color::red(c));
        o[2] = static_cast<float>(Color::green(c));
        o[3] = static_cast<float>(Color::blue(c));
    };
    auto pos = [&](std::size_t i) -> float {
        if (s.positions.size() == n) return s.positions[i];
        return n <= 1U ? 0.0F : static_cast<float>(i) / static_cast<float>(n - 1U);
    };
    if (n == 1U || t <= pos(0U)) { comp(0U, out); return; }
    for (std::size_t i = 1U; i < n; ++i) {
        const float p1 = pos(i);
        if (t < p1) {
            const float p0 = pos(i - 1U);
            const float k = p1 > p0 ? (t - p0) / (p1 - p0) : 1.0F;
            float c0[4], c1[4];
            comp(i - 1U, c0);
            comp(i, c1);
            for (int j = 0; j < 4; ++j) out[j] = c0[j] + (c1[j] - c0[j]) * k;
            return;
        }
    }
    comp(n - 1U, out);
}
} // namespace

ColorInt Shader::colorForParameter(float t) const noexcept {
    if (tile == TileMode::Repeat) t -= std::floor(t);
    else t = std::clamp(t, 0.0F, 1.0F);
    float c[4];
    interpolateStops(*this, t, c);
    return Color::argb(static_cast<int>(c[0] + 0.5F), static_cast<int>(c[1] + 0.5F), static_cast<int>(c[2] + 0.5F), static_cast<int>(c[3] + 0.5F));
}

ColorInt Shader::colorAt(float x, float y) const noexcept {
    float t = parameterAt(x, y);
    if (kind == Kind::Sweep) t = std::clamp(t, 0.0F, 1.0F);
    else if (tile == TileMode::Repeat) t -= std::floor(t);
    else t = std::clamp(t, 0.0F, 1.0F);
    float c[4];
    interpolateStops(*this, t, c);
    const float a = c[0] / 255.0F;
    const int ia = static_cast<int>(c[0] + 0.5F);
    const int ir = static_cast<int>(c[1] * a + 0.5F);
    const int ig = static_cast<int>(c[2] * a + 0.5F);
    const int ib = static_cast<int>(c[3] * a + 0.5F);
    return (static_cast<std::uint32_t>(std::clamp(ia, 0, 255)) << 24U) | (static_cast<std::uint32_t>(std::clamp(ir, 0, 255)) << 16U) |
           (static_cast<std::uint32_t>(std::clamp(ig, 0, 255)) << 8U) | static_cast<std::uint32_t>(std::clamp(ib, 0, 255));
}

ShaderPtr linearGradient(float x0, float y0, float x1, float y1, ColorInt c0, ColorInt c1, TileMode tile) {
    return linearGradient(x0, y0, x1, y1, std::vector<ColorInt>{c0, c1}, {}, tile);
}

ShaderPtr linearGradient(float x0, float y0, float x1, float y1, const std::vector<ColorInt>& colors, const std::vector<float>& positions, TileMode tile) {
    auto s = std::make_shared<Shader>();
    s->kind = Shader::Kind::Linear;
    s->x0 = x0; s->y0 = y0; s->x1 = x1; s->y1 = y1;
    s->colors = colors;
    s->positions = positions;
    s->tile = tile;
    return s;
}

ShaderPtr radialGradient(float cx, float cy, float radius, ColorInt c0, ColorInt c1, TileMode tile) {
    return radialGradient(cx, cy, radius, std::vector<ColorInt>{c0, c1}, {}, tile);
}

ShaderPtr radialGradient(float cx, float cy, float radius, const std::vector<ColorInt>& colors, const std::vector<float>& positions, TileMode tile) {
    auto s = std::make_shared<Shader>();
    s->kind = Shader::Kind::Radial;
    s->cx = cx; s->cy = cy; s->radius = radius;
    s->colors = colors;
    s->positions = positions;
    s->tile = tile;
    return s;
}

ShaderPtr sweepGradient(float cx, float cy, const std::vector<ColorInt>& colors, const std::vector<float>& positions) {
    auto s = std::make_shared<Shader>();
    s->kind = Shader::Kind::Sweep;
    s->cx = cx; s->cy = cy;
    s->colors = colors;
    s->positions = positions;
    return s;
}

// ====================================================================== paint / path
float Paint::measureText(const std::string& utf8) const {
    const auto glyphs = detail::shapeText(utf8, typeface, textSize);
    float w = 0.0F;
    for (const auto& g : glyphs) w += g.advancePx + letterSpacing * textSize;
    return w;
}

float Paint::measureText(const std::string& utf8, int from, int count) const {
    const auto glyphs = detail::shapeText(utf8, typeface, textSize);
    float w = 0.0F;
    const int end = std::min(static_cast<int>(glyphs.size()), from + count);
    for (int i = std::max(0, from); i < end; ++i) w += glyphs[static_cast<std::size_t>(i)].advancePx + letterSpacing * textSize;
    return w;
}

void Path::moveTo(float x, float y) {
    contours_.emplace_back();
    contours_.back().xy = {x, y};
}

void Path::lineTo(float x, float y) {
    if (contours_.empty()) { moveTo(x, y); return; }
    contours_.back().xy.push_back(x);
    contours_.back().xy.push_back(y);
}

void Path::close() {
    if (!contours_.empty()) contours_.back().closed = true;
}

// ====================================================================== canvas
Canvas::Canvas(int width, int height, bool recordOnly) : width_(std::max(1, width)), height_(std::max(1, height)) {
    if (!recordOnly) pixels_.assign(static_cast<std::size_t>(width_) * static_cast<std::size_t>(height_), 0U);
    resetState();
    window_ = IRect(0, 0, width_, height_);
}

void Canvas::resetState() {
    stack_.clear();
    state_ = State{};
    state_.clipL = 0;
    state_.clipT = 0;
    state_.clipR = width_;
    state_.clipB = height_;
}

Image Canvas::takeImage() {
    Image img;
    img.width = width_;
    img.height = height_;
    img.pixels = std::move(pixels_);
    pixels_.clear();
    return img;
}

void Canvas::clear(ColorInt color) {
    RasterOp op;
    op.kind = RasterOp::Kind::Clear;
    op.solid = premultiply(color);
    op.clipR = width_;
    op.clipB = height_;
    op.areaR = width_;
    op.areaB = height_;
    submit(std::move(op));
}

void Canvas::save() { stack_.push_back(state_); }

void Canvas::restore() {
    if (stack_.empty()) return;
    state_ = stack_.back();
    stack_.pop_back();
}

void Canvas::translate(float dx, float dy) {
    Matrix& m = state_.m;
    m.e += m.a * dx + m.c * dy;
    m.f += m.b * dx + m.d * dy;
}

void Canvas::scale(float sx, float sy) {
    Matrix& m = state_.m;
    m.a *= sx; m.b *= sx;
    m.c *= sy; m.d *= sy;
}

void Canvas::rotate(float degrees, float px, float py) {
    translate(px, py);
    const float rad = degrees * kPi / 180.0F;
    const float cs = std::cos(rad);
    const float sn = std::sin(rad);
    Matrix& m = state_.m;
    const float a = m.a * cs + m.c * sn;
    const float b = m.b * cs + m.d * sn;
    const float c = -m.a * sn + m.c * cs;
    const float d = -m.b * sn + m.d * cs;
    m.a = a; m.b = b; m.c = c; m.d = d;
    translate(-px, -py);
}

void Canvas::clipRect(const RectF& r) {
    float x0, y0, x1, y1;
    mapPoint(r.left, r.top, x0, y0);
    mapPoint(r.right, r.bottom, x1, y1);
    state_.clipL = std::max(state_.clipL, static_cast<int>(std::lround(std::min(x0, x1))));
    state_.clipT = std::max(state_.clipT, static_cast<int>(std::lround(std::min(y0, y1))));
    state_.clipR = std::min(state_.clipR, static_cast<int>(std::lround(std::max(x0, x1))));
    state_.clipB = std::min(state_.clipB, static_cast<int>(std::lround(std::max(y0, y1))));
}

void Canvas::mapPoint(float x, float y, float& ox, float& oy) const noexcept {
    const Matrix& m = state_.m;
    ox = m.a * x + m.c * y + m.e;
    oy = m.b * x + m.d * y + m.f;
}

bool Canvas::isAxisAligned() const noexcept {
    const Matrix& m = state_.m;
    return std::fabs(m.b) < 1e-6F && std::fabs(m.c) < 1e-6F && m.a > 0.0F && m.d > 0.0F;
}

float Canvas::uniformScale() const noexcept {
    const Matrix& m = state_.m;
    return std::sqrt(std::fabs(m.a * m.d - m.b * m.c));
}

// ---------------------------------------------------------------- source setup and pixel writing
namespace {
struct Source {
    bool useShader{false};
    std::uint32_t solid{0U};     // premultiplied
    int alpha255{255};           // paint alpha, applied to shader colours
};
} // namespace

// The source of the operation that is being drawn.
static thread_local Source gSource;
static thread_local const Shader* gShader = nullptr;

namespace {
// Gradient lookup table: a gradient is turned into a row of ready colours once per operation, so that a pixel costs
// a multiplication and a table read instead of a search through the colour stops. Whether the table is used depends only
// on the operation (its size), never on which part of it is drawn - so drawing a part gives the same pixels as drawing it all.
struct LutState {
    bool usable{false};     // false: evaluate every pixel directly (sweep gradients, small areas)
    bool opaque{false};     // every colour of the table is fully opaque
    std::vector<std::uint32_t> table;
    int last{0};
    bool radial{false};
    bool repeat{false};
    float ta{0.0F}, tb{0.0F}, tc{0.0F};              // linear: t = ta * X + (tb * Y + tc) (X, Y: pixel centre in device pixels)
    float ia{1.0F}, ib{0.0F}, ic{0.0F}, id{1.0F}, ie{0.0F}, jf{0.0F};   // inverse matrix (radial)
    float cx{0.0F}, cy{0.0F}, invRadius{1.0F};
    // SILVETON_FAST_DRAW_V1: a linear gradient that changes only from left to right (tb == 0) gives every row the same
    // colours: they are worked out once per operation (the same expression as fillSpan uses) for the columns [rowX0, ...).
    bool rowReady{false};
    int rowX0{0};
    std::vector<std::uint32_t> row;
};

constexpr long long kLutMinArea = 600;   // below this many pixels a gradient is evaluated pixel by pixel
} // namespace
static thread_local LutState gLut;

void Canvas::prepareLut() {
    gLut.usable = false;
    const Shader& s = *gShader;
    if (s.kind == Shader::Kind::Sweep || s.colors.empty()) return;
    const int n = 256;
    gLut.last = n - 1;
    gLut.table.resize(static_cast<std::size_t>(n));
    gLut.repeat = s.tile == TileMode::Repeat;
    gLut.opaque = true;
    for (int i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(n - 1);
        float c[4];
        interpolateStops(s, t, c);
        const float a = c[0] / 255.0F;
        const int ia = static_cast<int>(c[0] + 0.5F);
        const int ir = static_cast<int>(c[1] * a + 0.5F);
        const int ig = static_cast<int>(c[2] * a + 0.5F);
        const int ib = static_cast<int>(c[3] * a + 0.5F);
        std::uint32_t px = (static_cast<std::uint32_t>(std::clamp(ia, 0, 255)) << 24U) | (static_cast<std::uint32_t>(std::clamp(ir, 0, 255)) << 16U) |
                           (static_cast<std::uint32_t>(std::clamp(ig, 0, 255)) << 8U) | static_cast<std::uint32_t>(std::clamp(ib, 0, 255));
        if (gSource.alpha255 < 255) px = scalePremul(px, gSource.alpha255);
        gLut.table[static_cast<std::size_t>(i)] = px;
        if ((px >> 24U) != 255U) gLut.opaque = false;
    }
    const Matrix& m = inverse_;
    if (s.kind == Shader::Kind::Linear) {
        const float dx = s.x1 - s.x0;
        const float dy = s.y1 - s.y0;
        const float len2 = dx * dx + dy * dy;
        gLut.radial = false;
        if (len2 <= 0.0F) { gLut.ta = gLut.tb = 0.0F; gLut.tc = 0.0F; }
        else {
            // local = inverse * device; t = ((lx - x0) * dx + (ly - y0) * dy) / len2
            gLut.ta = (m.a * dx + m.b * dy) / len2;
            gLut.tb = (m.c * dx + m.d * dy) / len2;
            gLut.tc = ((m.e - s.x0) * dx + (m.f - s.y0) * dy) / len2;
        }
    } else {
        gLut.radial = true;
        gLut.ia = m.a; gLut.ib = m.b; gLut.ic = m.c; gLut.id = m.d; gLut.ie = m.e; gLut.jf = m.f;
        gLut.cx = s.cx; gLut.cy = s.cy;
        gLut.invRadius = s.radius > 0.0F ? 1.0F / s.radius : 0.0F;
    }
    gLut.usable = true;
}

namespace {
inline float fractionOf(float t) noexcept {   // t - floor(t)
    if (std::fabs(t) < 1e8F) {
        int fi = static_cast<int>(t);
        if (t < static_cast<float>(fi)) --fi;
        return t - static_cast<float>(fi);
    }
    return t - std::floor(t);                 // (also NaN -> NaN)
}

inline std::uint32_t lutLookup(const LutState& l, float t) noexcept {
    if (l.repeat) t = fractionOf(t);
    else t = t < 0.0F ? 0.0F : (t > 1.0F ? 1.0F : t);
    const auto top = static_cast<float>(l.last);
    float f = t * top + 0.5F;
    f = f > 0.0F ? f : 0.0F;          // (also turns NaN into 0)
    f = f < top ? f : top;
    return l.table[static_cast<std::size_t>(f)];
}

inline std::uint32_t lutAt(const LutState& l, float px, float py) noexcept {   // px, py: pixel centre in device pixels
    float t;
    if (!l.radial) {
        t = l.ta * px + (l.tb * py + l.tc);
    } else {
        const float lx = l.ia * px + l.ic * py + l.ie - l.cx;
        const float ly = l.ib * px + l.id * py + l.jf - l.cy;
        t = std::sqrt(lx * lx + ly * ly) * l.invRadius;
    }
    return lutLookup(l, t);
}
} // namespace

ColorInt Canvas::shaderPixel(const Shader& s, int x, int y) const noexcept {
    const float dx = static_cast<float>(x) + 0.5F;
    const float dy = static_cast<float>(y) + 0.5F;
    const float lx = inverse_.a * dx + inverse_.c * dy + inverse_.e;
    const float ly = inverse_.b * dx + inverse_.d * dy + inverse_.f;
    return s.colorAt(lx, ly);
}

std::uint32_t Canvas::sourceAt(int x, int y) {
    if (!gSource.useShader) return gSource.solid;
    if (gLut.usable) return lutAt(gLut, static_cast<float>(x) + 0.5F, static_cast<float>(y) + 0.5F);
    std::uint32_t src = shaderPixel(*gShader, x, y);
    if (gSource.alpha255 < 255) src = scalePremul(src, gSource.alpha255);
    return src;
}

void Canvas::blendPixel(int x, int y, float coverage) {
    const int cov = static_cast<int>(coverage * 255.0F + 0.5F);
    if (cov <= 0) return;
    std::uint32_t src = sourceAt(x, y);
    if (cov < 255) src = scalePremul(src, cov);
    std::uint32_t& dst = pixels_[static_cast<std::size_t>(y) * static_cast<std::size_t>(width_) + static_cast<std::size_t>(x)];
    dst = over(dst, src);
}

// Pixels [x0, x1) of one row, all with the same coverage.
void Canvas::fillSpan(int y, int x0, int x1, int cov255) {
    if (x1 <= x0 || cov255 <= 0) return;
    std::uint32_t* row = pixels_.data() + static_cast<std::size_t>(y) * static_cast<std::size_t>(width_);
    if (!gSource.useShader) {
        std::uint32_t src = gSource.solid;
        if (cov255 < 255) src = scalePremul(src, cov255);
        if ((src >> 24U) == 255U) {
            std::fill(row + x0, row + x1, src);
        } else if ((src >> 24U) != 0U) {
            overSolidRun(row + x0, x1 - x0, src);
        }
        return;
    }
    if (gLut.usable) {
        const float py = static_cast<float>(y) + 0.5F;
        const LutState& l = gLut;
        if (!l.radial) {
            const float base = l.tb * py + l.tc;
            const bool plain = l.opaque && cov255 >= 255;
            if (l.ta == 0.0F) {
                // SILVETON_FAST_DRAW_V1: top-to-bottom gradient - the whole run has one colour (ta * X adds exactly 0)
                std::uint32_t src = lutLookup(l, l.ta * (static_cast<float>(x0) + 0.5F) + base);
                if (plain) { std::fill(row + x0, row + x1, src); return; }
                if (cov255 < 255) src = scalePremul(src, cov255);
                if ((src >> 24U) == 255U) std::fill(row + x0, row + x1, src);
                else if ((src >> 24U) != 0U) overSolidRun(row + x0, x1 - x0, src);
                return;
            }
            if (l.rowReady && x0 >= l.rowX0 && x1 - l.rowX0 <= static_cast<int>(l.row.size())) {
                // SILVETON_FAST_DRAW_V1: left-to-right gradient - the colours of the columns are ready
                const std::uint32_t* ready = l.row.data() + (x0 - l.rowX0);
                if (plain) { std::memcpy(row + x0, ready, static_cast<std::size_t>(x1 - x0) * sizeof(std::uint32_t)); return; }
                for (int x = x0; x < x1; ++x) {
                    std::uint32_t src = ready[x - x0];
                    if (cov255 < 255) src = scalePremul(src, cov255);
                    row[x] = over(row[x], src);
                }
                return;
            }
            for (int x = x0; x < x1; ++x) {
                std::uint32_t src = lutLookup(l, l.ta * (static_cast<float>(x) + 0.5F) + base);
                if (plain) { row[x] = src; continue; }
                if (cov255 < 255) src = scalePremul(src, cov255);
                row[x] = over(row[x], src);
            }
            return;
        }
        for (int x = x0; x < x1; ++x) {
            std::uint32_t src = lutAt(l, static_cast<float>(x) + 0.5F, py);
            if (cov255 < 255) src = scalePremul(src, cov255);
            row[x] = over(row[x], src);
        }
        return;
    }
    for (int x = x0; x < x1; ++x) {
        std::uint32_t src = sourceAt(x, y);
        if (cov255 < 255) src = scalePremul(src, cov255);
        row[x] = over(row[x], src);
    }
}

// ---------------------------------------------------------------- operations -> pixels
// Every operation is drawn inside window_ only. The numbers for a pixel (coverage, colour) are worked out in the same way
// and in the same order whatever the window is, so a part drawn alone is identical to the same part of a complete picture.
void Canvas::rasterize(const RasterOp& op) {
    if (op.kind == RasterOp::Kind::Clear) {
        const int x0 = std::max(0, window_.left);
        const int x1 = std::min(width_, window_.right);
        for (int y = std::max(0, window_.top); y < std::min(height_, window_.bottom); ++y) {
            std::uint32_t* row = pixels_.data() + static_cast<std::size_t>(y) * static_cast<std::size_t>(width_);
            if (x1 > x0) std::fill(row + x0, row + x1, op.solid);
        }
        return;
    }
    gSource.useShader = op.useShader;
    gSource.alpha255 = op.alpha255;
    gSource.solid = op.solid;
    gShader = op.useShader ? op.shader.get() : nullptr;
    inverse_ = op.inverse;
    gLut.usable = false;
    gLut.rowReady = false;
    if (op.useShader) {
        const long long area = static_cast<long long>(op.areaR - op.areaL) * static_cast<long long>(op.areaB - op.areaT);
        if (area > kLutMinArea) prepareLut();
        // SILVETON_FAST_DRAW_V1: left-to-right gradient over several rows - the colours of its columns once
        const int xa = std::max(op.areaL, window_.left);
        const int xb = std::min(op.areaR, window_.right);
        if (gLut.usable && !gLut.radial && gLut.tb == 0.0F && gLut.ta != 0.0F && xb > xa &&
            std::min(op.areaB, window_.bottom) - std::max(op.areaT, window_.top) >= 4) {
            const LutState& l = gLut;
            const float base = l.tb * 0.5F + l.tc;   // (tb == 0: the same number for every row)
            gLut.row.resize(static_cast<std::size_t>(xb - xa));
            for (int x = xa; x < xb; ++x) gLut.row[static_cast<std::size_t>(x - xa)] = lutLookup(l, l.ta * (static_cast<float>(x) + 0.5F) + base);
            gLut.rowX0 = xa;
            gLut.rowReady = true;
        }
    }
    switch (op.kind) {
        case RasterOp::Kind::Rect: rasterRect(op); break;
        case RasterOp::Kind::Polys: rasterPolys(op); break;
        case RasterOp::Kind::Image: rasterImage(op); break;
        case RasterOp::Kind::Clear: break;
    }
}

void Canvas::rasterRect(const RasterOp& op) {
    const float l = std::max(op.rx0, static_cast<float>(op.clipL));
    const float t = std::max(op.ry0, static_cast<float>(op.clipT));
    const float r = std::min(op.rx1, static_cast<float>(op.clipR));
    const float b = std::min(op.ry1, static_cast<float>(op.clipB));
    if (!(l < r && t < b)) return;
    const int x0 = static_cast<int>(std::floor(l));
    const int x1 = static_cast<int>(std::ceil(r));
    const int y0 = static_cast<int>(std::floor(t));
    const int y1 = static_cast<int>(std::ceil(b));
    // columns that are covered completely: [ix0, ix1)
    const int ix0 = std::min(x1, static_cast<int>(std::ceil(l)));
    const int ix1 = std::max(ix0, std::min(x1, static_cast<int>(std::floor(r))));
    const int wx0 = std::max(x0, window_.left);
    const int wx1 = std::min(x1, window_.right);
    for (int y = std::max(y0, window_.top); y < std::min(y1, window_.bottom); ++y) {
        const float covY = std::min(static_cast<float>(y + 1), b) - std::max(static_cast<float>(y), t);
        // left edge pixels, the middle run, right edge pixels
        for (int x = wx0; x < std::min(ix0, wx1); ++x) {
            const float covX = std::min(static_cast<float>(x + 1), r) - std::max(static_cast<float>(x), l);
            blendPixel(x, y, covX * covY);
        }
        fillSpan(y, std::max(ix0, wx0), std::min(ix1, wx1), static_cast<int>(covY * 255.0F + 0.5F));
        for (int x = std::max(ix1, wx0); x < wx1; ++x) {
            if (x < ix0) continue;
            const float covX = std::min(static_cast<float>(x + 1), r) - std::max(static_cast<float>(x), l);
            blendPixel(x, y, covX * covY);
        }
    }
}

void Canvas::rasterPolys(const RasterOp& op) {
    const int x0 = op.areaL;
    const int y0 = op.areaT;
    const int w = op.areaR - op.areaL;
    const int h = op.areaB - op.areaT;
    // the rows and columns of the area that are inside the window
    const int rowLo = std::max(y0, window_.top) - y0;
    const int rowHi = std::min(op.areaB, window_.bottom) - y0;
    const int colLo = std::max(x0, window_.left) - x0;
    const int colHi = std::min(op.areaR, window_.right) - x0;
    if (rowLo >= rowHi || colLo >= colHi) return;
    const int stride = w + 2;
    const std::size_t needed = static_cast<std::size_t>(stride) * static_cast<std::size_t>(rowHi - rowLo);
    if (accumulation_.size() < needed) accumulation_.assign(needed, 0.0F);   // (stays all zero between operations: every row is cleared after it was read)
    float* a = accumulation_.data();
    for (const Poly& p : op.polys) {
        const std::size_t n = p.xy.size() / 2U;
        if (n < 3U) continue;
        for (std::size_t i = 0U; i < n; ++i) {
            const std::size_t j = (i + 1U) % n;
            accumulateEdge(a, stride, w, h, rowLo, rowHi, p.xy[2U * i] - static_cast<float>(x0), p.xy[2U * i + 1U] - static_cast<float>(y0),
                           p.xy[2U * j] - static_cast<float>(x0), p.xy[2U * j + 1U] - static_cast<float>(y0));
        }
    }
    for (int row = rowLo; row < rowHi; ++row) {
        float* r = a + static_cast<std::ptrdiff_t>(row - rowLo) * stride;
        float acc = 0.0F;
        int x = 0;
        for (; x < colLo; ++x) acc += r[x];   // (the same running sum as when the whole row is drawn)
        while (x < colHi) {
            acc += r[x];
            const float cov = std::min(1.0F, std::fabs(acc));
            if (cov > 0.99805F) {
                // fully covered; the pixels after it with no edge in them are covered the same way
                int xe = x + 1;
                while (xe < colHi && r[xe] == 0.0F) ++xe;
                fillSpan(y0 + row, x0 + x, x0 + xe, 255);
                x = xe;
                continue;
            }
            if (cov > 0.002F) blendPixel(x0 + x, y0 + row, cov);
            ++x;
        }
        std::memset(r, 0, static_cast<std::size_t>(stride) * sizeof(float));
    }
}

void Canvas::rasterImage(const RasterOp& op) {
    const Image& image = *op.image;
    const float dx0 = op.rx0, dy0 = op.ry0, dx1 = op.rx1, dy1 = op.ry1;
    const int alpha = op.alpha255;
    const int xa = std::max(op.areaL, window_.left);
    const int xb = std::min(op.areaR, window_.right);
    for (int y = std::max(op.areaT, window_.top); y < std::min(op.areaB, window_.bottom); ++y) {
        const float v = ((static_cast<float>(y) + 0.5F - dy0) / (dy1 - dy0)) * static_cast<float>(image.height) - 0.5F;
        const int iy = static_cast<int>(std::floor(v));
        const float fy = v - static_cast<float>(iy);
        for (int x = xa; x < xb; ++x) {
            const float u = ((static_cast<float>(x) + 0.5F - dx0) / (dx1 - dx0)) * static_cast<float>(image.width) - 0.5F;
            const int ix = static_cast<int>(std::floor(u));
            const float fx = u - static_cast<float>(ix);
            auto px = [&](int sx, int sy) -> std::uint32_t {
                sx = std::clamp(sx, 0, image.width - 1);
                sy = std::clamp(sy, 0, image.height - 1);
                return image.pixels[static_cast<std::size_t>(sy) * static_cast<std::size_t>(image.width) + static_cast<std::size_t>(sx)];
            };
            const std::uint32_t c00 = px(ix, iy), c10 = px(ix + 1, iy), c01 = px(ix, iy + 1), c11 = px(ix + 1, iy + 1);
            std::uint32_t outc = 0U;
            for (int shift = 0; shift <= 24; shift += 8) {
                const float c0 = static_cast<float>((c00 >> shift) & 255U) * (1.0F - fx) + static_cast<float>((c10 >> shift) & 255U) * fx;
                const float c1 = static_cast<float>((c01 >> shift) & 255U) * (1.0F - fx) + static_cast<float>((c11 >> shift) & 255U) * fx;
                const int v8 = static_cast<int>(c0 * (1.0F - fy) + c1 * fy + 0.5F);
                outc |= static_cast<std::uint32_t>(std::clamp(v8, 0, 255)) << shift;
            }
            outc = scalePremul(outc, alpha);
            std::uint32_t& d = pixels_[static_cast<std::size_t>(y) * static_cast<std::size_t>(width_) + static_cast<std::size_t>(x)];
            d = over(d, outc);
        }
    }
}

// ---------------------------------------------------------------- for the video card (SILVETON_GPU_DRAW_V1)
namespace detail {
// The coverage rasterPolys works out for every pixel of the area, as bytes: the same accumulation, the same limits
// (fully covered above 0.99805, nothing below 0.002) and the same rounding as blendPixel.
void polysCoverageMask(const RasterOp& op, std::vector<std::uint8_t>& out) {
    const int w = op.areaR - op.areaL;
    const int h = op.areaB - op.areaT;
    out.clear();
    if (w <= 0 || h <= 0) return;
    out.assign(static_cast<std::size_t>(w) * static_cast<std::size_t>(h), 0U);
    const int stride = w + 2;
    std::vector<float> a(static_cast<std::size_t>(stride) * static_cast<std::size_t>(h), 0.0F);
    for (const Poly& p : op.polys) {
        const std::size_t n = p.xy.size() / 2U;
        if (n < 3U) continue;
        for (std::size_t i = 0U; i < n; ++i) {
            const std::size_t j = (i + 1U) % n;
            accumulateEdge(a.data(), stride, w, h, 0, h, p.xy[2U * i] - static_cast<float>(op.areaL), p.xy[2U * i + 1U] - static_cast<float>(op.areaT),
                           p.xy[2U * j] - static_cast<float>(op.areaL), p.xy[2U * j + 1U] - static_cast<float>(op.areaT));
        }
    }
    for (int row = 0; row < h; ++row) {
        const float* r = a.data() + static_cast<std::size_t>(row) * static_cast<std::size_t>(stride);
        std::uint8_t* o = out.data() + static_cast<std::size_t>(row) * static_cast<std::size_t>(w);
        float acc = 0.0F;
        for (int x = 0; x < w; ++x) {
            acc += r[x];
            const float cov = std::min(1.0F, std::fabs(acc));
            if (cov > 0.99805F) o[x] = 255U;
            else if (cov > 0.002F) o[x] = static_cast<std::uint8_t>(std::clamp(static_cast<int>(cov * 255.0F + 0.5F), 0, 255));
        }
    }
}

void gradientTable(const Shader& s, int alpha255, std::uint32_t out[256]) {
    for (int i = 0; i < 256; ++i) {
        if (s.colors.empty()) { out[i] = 0U; continue; }
        const float t = static_cast<float>(i) / 255.0F;
        float c[4];
        interpolateStops(s, t, c);
        const float a = c[0] / 255.0F;
        const int ia = static_cast<int>(c[0] + 0.5F);
        const int ir = static_cast<int>(c[1] * a + 0.5F);
        const int ig = static_cast<int>(c[2] * a + 0.5F);
        const int ib = static_cast<int>(c[3] * a + 0.5F);
        std::uint32_t px = (static_cast<std::uint32_t>(std::clamp(ia, 0, 255)) << 24U) | (static_cast<std::uint32_t>(std::clamp(ir, 0, 255)) << 16U) |
                           (static_cast<std::uint32_t>(std::clamp(ig, 0, 255)) << 8U) | static_cast<std::uint32_t>(std::clamp(ib, 0, 255));
        if (alpha255 < 255) px = scalePremul(px, alpha255);
        out[i] = px;
    }
}
} // namespace detail

// ---------------------------------------------------------------- geometry builders (local space -> device Poly)
void Canvas::addCircle(std::vector<Poly>& out, float cx, float cy, float rx, float ry, bool reverse) const {
    const float rDev = std::max(rx, ry) * uniformScale();
    const float tol = 0.06F;
    int n = rDev <= tol ? 8 : static_cast<int>(std::ceil(kPi / std::acos(std::max(0.0F, 1.0F - tol / rDev))));
    n = std::clamp(n, 8, 720);
    std::vector<float> local;
    local.reserve(static_cast<std::size_t>(n) * 2U);
    for (int i = 0; i < n; ++i) {
        const float th = 2.0F * kPi * static_cast<float>(i) / static_cast<float>(n);
        local.push_back(cx + rx * std::cos(th));
        local.push_back(cy + ry * std::sin(th));
    }
    if (reverse) reversePoly(local);
    Poly p;
    p.xy.resize(local.size());
    for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
    out.push_back(std::move(p));
}

void Canvas::addRoundRect(std::vector<Poly>& out, const RectF& r, float rx, float ry, bool reverse) const {
    rx = std::clamp(rx, 0.0F, r.width() * 0.5F);
    ry = std::clamp(ry, 0.0F, r.height() * 0.5F);
    std::vector<float> local;
    if (rx <= 0.0F || ry <= 0.0F) {
        local = {r.left, r.top, r.right, r.top, r.right, r.bottom, r.left, r.bottom};
    } else {
        const float rDev = std::max(rx, ry) * uniformScale();
        int n = rDev <= 0.1F ? 4 : static_cast<int>(std::ceil((kPi * 0.5F) / std::acos(std::max(0.0F, 1.0F - 0.06F / rDev))));
        n = std::clamp(n, 3, 180);
        // corners in the order top-left, top-right, bottom-right, bottom-left; each swept over a quarter turn
        const float cxs[4] = {r.left + rx, r.right - rx, r.right - rx, r.left + rx};
        const float cys[4] = {r.top + ry, r.top + ry, r.bottom - ry, r.bottom - ry};
        const float start[4] = {kPi, 1.5F * kPi, 0.0F, 0.5F * kPi};
        for (int c = 0; c < 4; ++c) {
            for (int i = 0; i <= n; ++i) {
                const float th = start[c] + 0.5F * kPi * static_cast<float>(i) / static_cast<float>(n);
                local.push_back(cxs[c] + rx * std::cos(th));
                local.push_back(cys[c] + ry * std::sin(th));
            }
        }
    }
    if (reverse) reversePoly(local);
    Poly p;
    p.xy.resize(local.size());
    for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
    out.push_back(std::move(p));
}

void Canvas::addArcBand(std::vector<Poly>& out, float cx, float cy, float rx, float ry, float startRad, float sweepRad, float halfWidth, Cap cap) const {
    const float radius = 0.5F * (rx + ry);
    float a0 = startRad;
    float a1 = startRad + sweepRad;
    if (cap == Cap::Square && radius > 0.0F) {
        const float ext = halfWidth / radius * (sweepRad >= 0.0F ? 1.0F : -1.0F);
        a0 -= ext;
        a1 += ext;
    }
    const float rOut = radius + halfWidth;
    const float rIn = std::max(0.0F, radius - halfWidth);
    const float rDev = rOut * uniformScale();
    const float dTheta = rDev <= 0.1F ? 0.5F : 2.0F * std::acos(std::max(0.0F, 1.0F - 0.06F / rDev));
    int n = static_cast<int>(std::ceil(std::fabs(a1 - a0) / std::max(0.01F, dTheta)));
    n = std::clamp(n, 2, 1440);
    std::vector<float> local;
    local.reserve(static_cast<std::size_t>(n + 1) * 4U);
    for (int i = 0; i <= n; ++i) {
        const float th = a0 + (a1 - a0) * static_cast<float>(i) / static_cast<float>(n);
        local.push_back(cx + rOut * std::cos(th));
        local.push_back(cy + rOut * std::sin(th));
    }
    for (int i = n; i >= 0; --i) {
        const float th = a0 + (a1 - a0) * static_cast<float>(i) / static_cast<float>(n);
        local.push_back(cx + rIn * std::cos(th));
        local.push_back(cy + rIn * std::sin(th));
    }
    if (signedArea(local) < 0.0F) reversePoly(local);
    Poly p;
    p.xy.resize(local.size());
    for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
    out.push_back(std::move(p));
    if (cap == Cap::Round && halfWidth > 0.0F) {
        for (const float th : {startRad, startRad + sweepRad}) {
            addCircle(out, cx + radius * std::cos(th), cy + radius * std::sin(th), halfWidth, halfWidth, false);
        }
    }
}

void Canvas::strokeLinePolys(const float* xy, int count, bool closed, float width, Cap cap, std::vector<Poly>& out) const {
    const float hw = width * 0.5F;
    if (count < 2 || hw <= 0.0F) return;
    // remove repeated points
    std::vector<float> p;
    for (int i = 0; i < count; ++i) {
        if (!p.empty() && std::fabs(p[p.size() - 2U] - xy[2 * i]) < 1e-6F && std::fabs(p[p.size() - 1U] - xy[2 * i + 1]) < 1e-6F) continue;
        p.push_back(xy[2 * i]);
        p.push_back(xy[2 * i + 1]);
    }
    int n = static_cast<int>(p.size() / 2U);
    if (closed && n > 2 && std::fabs(p[0] - p[p.size() - 2U]) < 1e-6F && std::fabs(p[1] - p[p.size() - 1U]) < 1e-6F) { p.pop_back(); p.pop_back(); --n; }
    if (n < 2) {
        if (n == 1 && cap == Cap::Round) addCircle(out, p[0], p[1], hw, hw, false);
        return;
    }
    const int segs = closed ? n : n - 1;
    auto emit = [&](std::vector<float> local) {
        if (signedArea(local) < 0.0F) reversePoly(local);
        Poly q;
        q.xy.resize(local.size());
        for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], q.xy[i], q.xy[i + 1U]);
        out.push_back(std::move(q));
    };
    std::vector<float> dirs(static_cast<std::size_t>(segs) * 2U);
    for (int s = 0; s < segs; ++s) {
        const int a = s, b = (s + 1) % n;
        float dx = p[static_cast<std::size_t>(2 * b)] - p[static_cast<std::size_t>(2 * a)];
        float dy = p[static_cast<std::size_t>(2 * b + 1)] - p[static_cast<std::size_t>(2 * a + 1)];
        const float len = std::hypot(dx, dy);
        dx /= len; dy /= len;
        dirs[static_cast<std::size_t>(2 * s)] = dx;
        dirs[static_cast<std::size_t>(2 * s + 1)] = dy;
        float ax = p[static_cast<std::size_t>(2 * a)], ay = p[static_cast<std::size_t>(2 * a + 1)];
        float bx = p[static_cast<std::size_t>(2 * b)], by = p[static_cast<std::size_t>(2 * b + 1)];
        if (cap == Cap::Square && !closed) {
            if (s == 0) { ax -= dx * hw; ay -= dy * hw; }
            if (s == segs - 1) { bx += dx * hw; by += dy * hw; }
        }
        const float nx = -dy * hw, ny = dx * hw;
        emit({ax + nx, ay + ny, bx + nx, by + ny, bx - nx, by - ny, ax - nx, ay - ny});
    }
    // joins (miter up to a limit of 4, otherwise bevel)
    const int firstJoin = closed ? 0 : 1;
    const int lastJoin = closed ? n - 1 : n - 2;
    for (int v = firstJoin; v <= lastJoin; ++v) {
        const int sPrev = (v - 1 + segs) % segs;
        const int sNext = v % segs;
        const float d0x = dirs[static_cast<std::size_t>(2 * sPrev)], d0y = dirs[static_cast<std::size_t>(2 * sPrev + 1)];
        const float d1x = dirs[static_cast<std::size_t>(2 * sNext)], d1y = dirs[static_cast<std::size_t>(2 * sNext + 1)];
        const float cross = d0x * d1y - d0y * d1x;
        if (std::fabs(cross) < 1e-5F && d0x * d1x + d0y * d1y > 0.0F) continue;   // straight on
        const float sgn = cross > 0.0F ? 1.0F : -1.0F;
        const float n0x = -d0y, n0y = d0x, n1x = -d1y, n1y = d1x;
        const float px = p[static_cast<std::size_t>(2 * v)], py = p[static_cast<std::size_t>(2 * v + 1)];
        std::vector<float> wedge{px, py, px - sgn * n0x * hw, py - sgn * n0y * hw};
        const float denom = 1.0F + (n0x * n1x + n0y * n1y);
        if (denom > 1e-4F) {
            const float mx = (n0x + n1x) / denom, my = (n0y + n1y) / denom;
            if (std::hypot(mx, my) <= 4.0F) {
                wedge.push_back(px - sgn * mx * hw);
                wedge.push_back(py - sgn * my * hw);
            }
        }
        wedge.push_back(px - sgn * n1x * hw);
        wedge.push_back(py - sgn * n1y * hw);
        emit(wedge);
    }
    if (!closed && cap == Cap::Round) {
        addCircle(out, p[0], p[1], hw, hw, false);
        addCircle(out, p[static_cast<std::size_t>(2 * (n - 1))], p[static_cast<std::size_t>(2 * (n - 1) + 1)], hw, hw, false);
    }
}

// ---------------------------------------------------------------- draw calls -> operations
namespace {
// A quick 64-bit mixing hash of the numbers that decide a pixel (not for secrecy: only to see what changed between two pictures).
struct Hasher {
    std::uint64_t h{0x243F6A8885A308D3ULL};
    void add(std::uint32_t v) noexcept {
        h = (h ^ v) * 0x9E3779B185EBCA87ULL;
        h ^= h >> 29U;
    }
    void add64(std::uint64_t v) noexcept {
        add(static_cast<std::uint32_t>(v));
        add(static_cast<std::uint32_t>(v >> 32U));
    }
    void addFloat(float f) noexcept {
        std::uint32_t u;
        std::memcpy(&u, &f, sizeof u);
        add(u);
    }
    void addInt(int v) noexcept { add(static_cast<std::uint32_t>(v)); }
};

std::uint64_t hashShaderContent(const Shader& s) {
    Hasher h;
    h.addInt(static_cast<int>(s.kind));
    h.addFloat(s.x0); h.addFloat(s.y0); h.addFloat(s.x1); h.addFloat(s.y1);
    h.addFloat(s.cx); h.addFloat(s.cy); h.addFloat(s.radius);
    h.addInt(static_cast<int>(s.tile));
    h.add64(s.colors.size());
    for (const ColorInt c : s.colors) h.add(c);
    h.add64(s.positions.size());
    for (const float f : s.positions) h.addFloat(f);
    return h.h;
}

std::uint64_t hashImageContent(const Image& image) {
    Hasher h;
    h.addInt(image.width);
    h.addInt(image.height);
    const std::size_t n = image.pixels.size();
    std::size_t i = 0U;
    for (; i + 2U <= n; i += 2U) h.add64(static_cast<std::uint64_t>(image.pixels[i]) | (static_cast<std::uint64_t>(image.pixels[i + 1U]) << 32U));
    for (; i < n; ++i) h.add(image.pixels[i]);
    return h.h;
}
} // namespace

bool Canvas::prepareSource(const Paint& paint) {
    const bool useShader = paint.shader != nullptr && !paint.shader->colors.empty();
    src_.useShader = useShader;
    src_.alpha255 = Color::alpha(paint.color);
    src_.solid = premultiply(paint.color);
    src_.shader = useShader ? paint.shader : nullptr;
    if (useShader) {
        const Matrix& m = state_.m;
        const float det = m.a * m.d - m.b * m.c;
        if (std::fabs(det) < 1e-9F) return false;
        const float id = 1.0F / det;
        Matrix& inv = src_.inverse;
        inv.a = m.d * id; inv.b = -m.b * id; inv.c = -m.c * id; inv.d = m.a * id;
        inv.e = -(inv.a * m.e + inv.c * m.f);
        inv.f = -(inv.b * m.e + inv.d * m.f);
    }
    return true;
}

void Canvas::takeSource(RasterOp& op) const {
    op.clipL = state_.clipL; op.clipT = state_.clipT; op.clipR = state_.clipR; op.clipB = state_.clipB;
    op.useShader = src_.useShader;
    op.alpha255 = src_.alpha255;
    op.solid = src_.solid;
    if (src_.useShader) {
        op.shader = src_.shader;
        op.inverse = src_.inverse;
    }
}

namespace {
std::atomic<unsigned long> gBadPolygons{0UL};
}
unsigned long badPolygonCount() noexcept { return gBadPolygons.load(std::memory_order_relaxed); }

void Canvas::emitPolys(std::vector<Poly>& polys) {
    // SILVETON_GFX_SAFE_POLY_V1: a coordinate that is not a number (NaN) or is infinite must never reach the rasterizer -
    // std::min / std::max skip a NaN, so the old bounds check let such a point through, and the row index made from it was
    // garbage (a crash in accumulateEdge while a screen was drawn). Such a polygon is left out; the rest is drawn.
    for (Poly& p : polys) {
        bool good = true;
        for (const float v : p.xy) if (!std::isfinite(v) || std::fabs(v) > 1.0e7F) { good = false; break; }
        if (!good) { p.xy.clear(); gBadPolygons.fetch_add(1UL, std::memory_order_relaxed); }
    }
    float minX = std::numeric_limits<float>::max(), minY = minX, maxX = -minX, maxY = -minX;
    for (const Poly& p : polys) {
        for (std::size_t i = 0U; i + 1U < p.xy.size(); i += 2U) {
            minX = std::min(minX, p.xy[i]); maxX = std::max(maxX, p.xy[i]);
            minY = std::min(minY, p.xy[i + 1U]); maxY = std::max(maxY, p.xy[i + 1U]);
        }
    }
    if (!(minX <= maxX) || !std::isfinite(minX) || !std::isfinite(maxX) || !std::isfinite(minY) || !std::isfinite(maxY)) return;
    const int x0 = std::max(state_.clipL, static_cast<int>(std::floor(std::max(minX, -1e7F))));
    const int y0 = std::max(state_.clipT, static_cast<int>(std::floor(std::max(minY, -1e7F))));
    const int x1 = std::min(state_.clipR, static_cast<int>(std::ceil(std::min(maxX, 1e7F))));
    const int y1 = std::min(state_.clipB, static_cast<int>(std::ceil(std::min(maxY, 1e7F))));
    if (x1 <= x0 || y1 <= y0) return;
    RasterOp op;
    op.kind = RasterOp::Kind::Polys;
    takeSource(op);
    op.areaL = x0; op.areaT = y0; op.areaR = x1; op.areaB = y1;
    op.polys = std::move(polys);
    submit(std::move(op));
}

void Canvas::emitRect(const RectF& d) {
    const float l = std::max(d.left, static_cast<float>(state_.clipL));
    const float t = std::max(d.top, static_cast<float>(state_.clipT));
    const float r = std::min(d.right, static_cast<float>(state_.clipR));
    const float b = std::min(d.bottom, static_cast<float>(state_.clipB));
    if (!(l < r && t < b)) return;
    RasterOp op;
    op.kind = RasterOp::Kind::Rect;
    takeSource(op);
    op.rx0 = d.left; op.ry0 = d.top; op.rx1 = d.right; op.ry1 = d.bottom;
    op.areaL = static_cast<int>(std::floor(l));
    op.areaR = static_cast<int>(std::ceil(r));
    op.areaT = static_cast<int>(std::floor(t));
    op.areaB = static_cast<int>(std::ceil(b));
    submit(std::move(op));
}

void Canvas::submit(RasterOp&& op) {
    if (recording_ != nullptr) {
        Hasher h;
        h.addInt(static_cast<int>(op.kind));
        h.addInt(op.clipL); h.addInt(op.clipT); h.addInt(op.clipR); h.addInt(op.clipB);
        h.addInt(op.areaL); h.addInt(op.areaT); h.addInt(op.areaR); h.addInt(op.areaB);
        h.add(op.solid);
        if (op.kind != RasterOp::Kind::Clear) {
            h.addInt(op.alpha255);
            h.addInt(op.useShader ? 1 : 0);
            if (op.useShader) {
                if (op.shader.get() != hashedShader_) {
                    hashedShader_ = op.shader.get();
                    hashedShaderValue_ = hashShaderContent(*op.shader);
                }
                h.add64(hashedShaderValue_);
                h.addFloat(op.inverse.a); h.addFloat(op.inverse.b); h.addFloat(op.inverse.c);
                h.addFloat(op.inverse.d); h.addFloat(op.inverse.e); h.addFloat(op.inverse.f);
            }
            if (op.kind == RasterOp::Kind::Rect || op.kind == RasterOp::Kind::Image) {
                h.addFloat(op.rx0); h.addFloat(op.ry0); h.addFloat(op.rx1); h.addFloat(op.ry1);
            }
            if (op.kind == RasterOp::Kind::Image) {
                op.imageHash = hashImageContent(*op.image);
                h.add64(op.imageHash);
            }
            if (!op.polys.empty()) {
                Hasher g;
                g.addInt(op.areaL); g.addInt(op.areaT); g.addInt(op.areaR); g.addInt(op.areaB);
                for (const Poly& p : op.polys) {
                    g.add64(p.xy.size());
                    for (const float f : p.xy) g.addFloat(f);
                }
                op.geomHash = g.h;
                h.add64(op.geomHash);
            }
        }
        op.hash = h.h;
        recording_->push_back(std::move(op));
        return;
    }
    window_ = IRect(0, 0, width_, height_);
    rasterize(op);
}

void Canvas::beginRecording(detail::DisplayList* list) {
    recording_ = list;
    hashedShader_ = nullptr;
    hashedShaderValue_ = 0U;
}

void Canvas::endRecording() {
    recording_ = nullptr;
    hashedShader_ = nullptr;
}

void Canvas::replay(const detail::DisplayList& list, const IRect& window) {
    if (pixels_.empty()) return;
    const IRect win = window.intersected(IRect(0, 0, width_, height_));
    if (win.isEmpty()) return;
    window_ = win;
    for (int y = win.top; y < win.bottom; ++y) {
        std::uint32_t* row = pixels_.data() + static_cast<std::size_t>(y) * static_cast<std::size_t>(width_);
        std::fill(row + win.left, row + win.right, 0U);
    }
    for (const RasterOp& op : list) {
        if (op.areaR <= win.left || op.areaL >= win.right || op.areaB <= win.top || op.areaT >= win.bottom) continue;
        rasterize(op);
    }
    window_ = IRect(0, 0, width_, height_);
}

void Canvas::replayRange(const detail::DisplayList& list, std::size_t first, std::size_t last, const IRect& window) {
    if (pixels_.empty()) return;
    const IRect win = window.intersected(IRect(0, 0, width_, height_));
    if (win.isEmpty()) return;
    window_ = win;
    last = std::min(last, list.size());
    for (std::size_t i = first; i < last; ++i) {
        const RasterOp& op = list[i];
        if (op.areaR <= win.left || op.areaL >= win.right || op.areaB <= win.top || op.areaT >= win.bottom) continue;
        rasterize(op);
    }
    window_ = IRect(0, 0, width_, height_);
}

void Canvas::copyPixels(const Canvas& from, const IRect& window) {
    if (pixels_.empty() || from.width_ != width_ || from.height_ != height_) return;
    const IRect win = window.intersected(IRect(0, 0, width_, height_));
    if (win.isEmpty()) return;
    const auto n = static_cast<std::size_t>(win.right - win.left) * sizeof(std::uint32_t);
    for (int y = win.top; y < win.bottom; ++y) {
        const std::size_t at = static_cast<std::size_t>(y) * static_cast<std::size_t>(width_) + static_cast<std::size_t>(win.left);
        std::memcpy(pixels_.data() + at, from.pixels_.data() + at, n);
    }
}

void Canvas::drawRect(const RectF& r, const Paint& paint) {
    if (!prepareSource(paint)) return;
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill && isAxisAligned()) {
        float x0, y0, x1, y1;
        mapPoint(r.left, r.top, x0, y0);
        mapPoint(r.right, r.bottom, x1, y1);
        emitRect(RectF(x0, y0, x1, y1));
    } else if (fill) {
        std::vector<Poly> polys;
        addRoundRect(polys, r, 0.0F, 0.0F, false);
        emitPolys(polys);
    }
    if (stroke) {
        const float hw = paint.strokeWidth * 0.5F;
        std::vector<Poly> polys;
        addRoundRect(polys, RectF(r.left - hw, r.top - hw, r.right + hw, r.bottom + hw), 0.0F, 0.0F, false);
        const RectF inner(r.left + hw, r.top + hw, r.right - hw, r.bottom - hw);
        if (inner.width() > 0.0F && inner.height() > 0.0F) addRoundRect(polys, inner, 0.0F, 0.0F, true);
        emitPolys(polys);
    }
}

void Canvas::drawRoundRect(const RectF& r, float rx, float ry, const Paint& paint) {
    if (!prepareSource(paint)) return;
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        std::vector<Poly> polys;
        addRoundRect(polys, r, rx, ry, false);
        emitPolys(polys);
    }
    if (stroke) {
        const float hw = paint.strokeWidth * 0.5F;
        std::vector<Poly> polys;
        addRoundRect(polys, RectF(r.left - hw, r.top - hw, r.right + hw, r.bottom + hw), rx + hw, ry + hw, false);
        const RectF inner(r.left + hw, r.top + hw, r.right - hw, r.bottom - hw);
        if (inner.width() > 0.0F && inner.height() > 0.0F) addRoundRect(polys, inner, std::max(0.0F, rx - hw), std::max(0.0F, ry - hw), true);
        emitPolys(polys);
    }
}

void Canvas::drawCircle(float cx, float cy, float radius, const Paint& paint) {
    if (radius <= 0.0F) return;
    if (!prepareSource(paint)) return;
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        std::vector<Poly> polys;
        addCircle(polys, cx, cy, radius, radius, false);
        emitPolys(polys);
    }
    if (stroke) {
        const float hw = paint.strokeWidth * 0.5F;
        std::vector<Poly> polys;
        addCircle(polys, cx, cy, radius + hw, radius + hw, false);
        if (radius - hw > 0.0F) addCircle(polys, cx, cy, radius - hw, radius - hw, true);
        emitPolys(polys);
    }
}

void Canvas::drawLine(float x0, float y0, float x1, float y1, const Paint& paint) {
    if (!prepareSource(paint)) return;
    // Android draws lines with the stroke width, whatever the style (width 0 = hairline, drawn as 1 px)
    const float w = paint.strokeWidth > 0.0F ? paint.strokeWidth : 1.0F / std::max(0.0001F, uniformScale());
    const float xy[4] = {x0, y0, x1, y1};
    std::vector<Poly> polys;
    strokeLinePolys(xy, 2, false, w, paint.strokeCap, polys);
    emitPolys(polys);
}

void Canvas::drawArc(const RectF& oval, float startDegrees, float sweepDegrees, bool useCenter, const Paint& paint) {
    if (!prepareSource(paint)) return;
    const float cx = oval.centerX(), cy = oval.centerY();
    const float rx = oval.width() * 0.5F, ry = oval.height() * 0.5F;
    const float a0 = startDegrees * kPi / 180.0F;
    float sweep = sweepDegrees * kPi / 180.0F;
    if (std::fabs(sweep) > 2.0F * kPi) sweep = sweep > 0.0F ? 2.0F * kPi : -2.0F * kPi;
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        const float rDev = std::max(rx, ry) * uniformScale();
        const float dTheta = rDev <= 0.1F ? 0.5F : 2.0F * std::acos(std::max(0.0F, 1.0F - 0.06F / rDev));
        const int n = std::clamp(static_cast<int>(std::ceil(std::fabs(sweep) / std::max(0.01F, dTheta))), 2, 1440);
        std::vector<float> local;
        if (useCenter) { local.push_back(cx); local.push_back(cy); }
        for (int i = 0; i <= n; ++i) {
            const float th = a0 + sweep * static_cast<float>(i) / static_cast<float>(n);
            local.push_back(cx + rx * std::cos(th));
            local.push_back(cy + ry * std::sin(th));
        }
        if (signedArea(local) < 0.0F) reversePoly(local);
        Poly p;
        p.xy.resize(local.size());
        for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
        std::vector<Poly> polys;
        polys.push_back(std::move(p));
        emitPolys(polys);
    }
    if (stroke) {
        std::vector<Poly> polys;
        addArcBand(polys, cx, cy, rx, ry, a0, sweep, paint.strokeWidth * 0.5F, paint.strokeCap);
        emitPolys(polys);
    }
}

void Canvas::drawPath(const Path& path, const Paint& paint) {
    if (!prepareSource(paint)) return;
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        std::vector<Poly> polys;
        for (const auto& c : path.contours()) {
            if (c.xy.size() < 6U) continue;
            std::vector<float> local = c.xy;
            if (signedArea(local) < 0.0F) reversePoly(local);
            Poly p;
            p.xy.resize(local.size());
            for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
            polys.push_back(std::move(p));
        }
        emitPolys(polys);
    }
    if (stroke) {
        std::vector<Poly> polys;
        for (const auto& c : path.contours()) {
            strokeLinePolys(c.xy.data(), static_cast<int>(c.xy.size() / 2U), c.closed, paint.strokeWidth, paint.strokeCap, polys);
        }
        emitPolys(polys);
    }
}

void Canvas::drawText(const std::string& utf8, float x, float y, const Paint& paint) {
    if (utf8.empty() || paint.textSize <= 0.0F) return;
    if (!prepareSource(paint)) return;
    const auto glyphs = detail::shapeText(utf8, paint.typeface, paint.textSize);
    const float spacing = paint.letterSpacing * paint.textSize;
    float width = 0.0F;
    for (const auto& g : glyphs) width += g.advancePx + spacing;
    float pen = x;
    if (paint.textAlign == Align::Center) pen = x - width * 0.5F;
    else if (paint.textAlign == Align::Right) pen = x - width;
    std::vector<Poly> polys;
    for (const auto& g : glyphs) {
        if (g.outline != nullptr) {
            for (const auto& contour : g.outline->contours) {
                if (contour.size() < 6U) continue;
                Poly p;
                p.xy.resize(contour.size());
                for (std::size_t i = 0U; i < contour.size(); i += 2U) {
                    mapPoint(pen + contour[i] * g.scale, y - contour[i + 1U] * g.scale, p.xy[i], p.xy[i + 1U]);
                }
                polys.push_back(std::move(p));
            }
        }
        pen += g.advancePx + spacing;
    }
    emitPolys(polys);
}

void Canvas::drawImage(const Image& image, const RectF& dst, const Paint& paint) {
    if (image.width <= 0 || image.height <= 0 || dst.isEmpty() || !isAxisAligned()) return;
    float dx0, dy0, dx1, dy1;
    mapPoint(dst.left, dst.top, dx0, dy0);
    mapPoint(dst.right, dst.bottom, dx1, dy1);
    const int x0 = std::max(state_.clipL, static_cast<int>(std::floor(dx0)));
    const int y0 = std::max(state_.clipT, static_cast<int>(std::floor(dy0)));
    const int x1 = std::min(state_.clipR, static_cast<int>(std::ceil(dx1)));
    const int y1 = std::min(state_.clipB, static_cast<int>(std::ceil(dy1)));
    if (x1 <= x0 || y1 <= y0) return;
    RasterOp op;
    op.kind = RasterOp::Kind::Image;
    op.clipL = state_.clipL; op.clipT = state_.clipT; op.clipR = state_.clipR; op.clipB = state_.clipB;
    op.alpha255 = Color::alpha(paint.color);
    op.rx0 = dx0; op.ry0 = dy0; op.rx1 = dx1; op.ry1 = dy1;
    op.areaL = x0; op.areaT = y0; op.areaR = x1; op.areaB = y1;
    op.image = &image;
    submit(std::move(op));
}

// ====================================================================== light drawing
namespace {
using detail::DisplayList;
using detail::RasterOp;

IRect opArea(const RasterOp& op) { return IRect(op.areaL, op.areaT, op.areaR, op.areaB); }

// The areas where two pictures (lists of operations) can differ.
// A pixel is the result of the operations that touch it, in order. Equal operations at matching places give equal pixels,
// so only the operations that differ (in the old or in the new list) can change anything: their areas are collected.
// Matching: the equal operations at the start and at the end of both lists; in the middle, if both lists are equally long,
// the operations at the same place; otherwise everything in the middle counts as changed.
void collectChanged(const DisplayList& prev, const DisplayList& cur, std::vector<IRect>& out, const IRect& whole) {
    const std::size_t n = prev.size();
    const std::size_t m = cur.size();
    std::size_t head = 0U;
    const std::size_t common = std::min(n, m);
    while (head < common && prev[head].hash == cur[head].hash) ++head;
    std::size_t tail = 0U;
    while (tail < common - head && prev[n - 1U - tail].hash == cur[m - 1U - tail].hash) ++tail;
    const std::size_t prevEnd = n - tail;
    const std::size_t curEnd = m - tail;
    auto add = [&](const IRect& r) {
        const IRect c = r.intersected(whole);
        if (c.isEmpty()) return;
        if (out.size() >= 256U) {   // far too many pieces: one rectangle around everything
            IRect u = c;
            for (const IRect& o : out) u = u.united(o);
            out.assign(1U, u);
            return;
        }
        out.push_back(c);
    };
    if (prevEnd - head == curEnd - head) {
        for (std::size_t i = head; i < prevEnd; ++i) {
            if (prev[i].hash != cur[i].hash) {
                add(opArea(prev[i]));
                add(opArea(cur[i]));
            }
        }
    } else {
        for (std::size_t i = head; i < prevEnd; ++i) add(opArea(prev[i]));
        for (std::size_t i = head; i < curEnd; ++i) add(opArea(cur[i]));
    }
}

// Joins neighbouring rectangles when drawing them as one costs hardly more; one big rectangle when most of the picture changed.
void mergeRects(std::vector<IRect>& r, const IRect& whole) {
    if (r.empty()) return;
    bool merged = true;
    while (merged && r.size() > 1U) {
        merged = false;
        for (std::size_t i = 0U; i < r.size() && !merged; ++i) {
            for (std::size_t j = i + 1U; j < r.size() && !merged; ++j) {
                const IRect u = r[i].united(r[j]);
                const long long sum = r[i].area() + r[j].area();
                if (u.area() <= sum + sum / 2 + 4096) {
                    r[i] = u;
                    r.erase(r.begin() + static_cast<std::ptrdiff_t>(j));
                    merged = true;
                }
            }
        }
    }
    long long total = 0;
    for (const IRect& x : r) total += x.area();
    if (total * 100 > whole.area() * 55) r.assign(1U, whole);
}
} // namespace

struct FrameRenderer::Impl {
    Canvas target;
    Canvas recorder;
    detail::DisplayList cur;
    detail::DisplayList prev;
    bool valid{false};
    std::vector<IRect> damage;
    long long repainted{0};
    // SILVETON_FAST_DRAW_V1 - the kept base picture: while something is changed again and again in the same place (a point of
    // the EQ dragged, a knob turned, the analyzer), everything drawn BEFORE it in the list stays the same. That part is drawn
    // once into `base`; afterwards a changed area is copied from it and only the operations from `baseCount` on are drawn on top.
    std::unique_ptr<Canvas> base;
    std::size_t baseCount{0U};
    std::vector<std::uint64_t> baseHashes;   // the operations the base was drawn from (it is used only while they are unchanged)
    IRect baseArea;                          // the part of the picture the base holds (where the changes were when it was made)
    bool baseValid{false};
    bool recordedValid{false};               // GPU path: `prev` is the list that was recorded last (and shown)
    std::size_t lastHead{static_cast<std::size_t>(-1)};
    int sameHead{0};
    Impl(int w, int h) : target(w, h), recorder(w, h, true) {}
};

namespace {
constexpr std::size_t kBaseMinOps = 8U;      // a base is worth keeping only above this many operations
constexpr std::size_t kBaseGrowOps = 24U;    // a valid base is drawn again (deeper) only when that adds this many operations
constexpr long long kBaseMinPixelsPer1000 = 25;   // ... and only when the changes cover at least 2.5 % of the picture
} // namespace

FrameRenderer::FrameRenderer(int width, int height) : impl_(std::make_unique<Impl>(width, height)) {}
FrameRenderer::~FrameRenderer() = default;

int FrameRenderer::width() const noexcept { return impl_->target.width(); }
int FrameRenderer::height() const noexcept { return impl_->target.height(); }
const Canvas& FrameRenderer::picture() const noexcept { return impl_->target; }
const std::vector<IRect>& FrameRenderer::changed() const noexcept { return impl_->damage; }
const detail::DisplayList& FrameRenderer::lastList() const noexcept { return impl_->prev; }
std::size_t FrameRenderer::lastOperationCount() const noexcept { return impl_->prev.size(); }
long long FrameRenderer::lastRepaintedPixels() const noexcept { return impl_->repainted; }
void FrameRenderer::invalidate() { impl_->valid = false; impl_->recordedValid = false; }

IRect FrameRenderer::changedBounds() const noexcept {
    IRect u;
    for (const IRect& r : impl_->damage) u = u.united(r);
    return u;
}

bool FrameRenderer::record(const std::function<void(Canvas&)>& draw) {
    Impl& s = *impl_;
    s.cur.clear();
    s.recorder.resetState();
    s.recorder.beginRecording(&s.cur);
    draw(s.recorder);
    s.recorder.endRecording();
    bool same = s.recordedValid && s.prev.size() == s.cur.size();
    for (std::size_t i = 0U; same && i < s.cur.size(); ++i) {
        if (s.prev[i].hash != s.cur[i].hash) same = false;
    }
    std::swap(s.prev, s.cur);
    s.recordedValid = true;
    s.valid = false;       // the pixels of the software picture are not kept up to date on this path
    s.baseValid = false;
    s.damage.clear();
    return !same;
}

const std::vector<IRect>& FrameRenderer::update(const std::function<void(Canvas&)>& draw) {
    Impl& s = *impl_;
    s.recordedValid = false;
    const IRect whole(0, 0, s.target.width(), s.target.height());
    s.cur.clear();
    s.recorder.resetState();
    s.recorder.beginRecording(&s.cur);
    draw(s.recorder);
    s.recorder.endRecording();

    s.damage.clear();
    if (!s.valid) {
        s.damage.push_back(whole);
    } else {
        collectChanged(s.prev, s.cur, s.damage, whole);
        mergeRects(s.damage, whole);
    }
    // SILVETON_FAST_DRAW_V1: how many operations at the start are the same as in the previous picture
    std::size_t head = 0U;
    if (s.valid) {
        const std::size_t c = std::min(s.prev.size(), s.cur.size());
        while (head < c && s.prev[head].hash == s.cur[head].hash) ++head;
    }
    // the kept base can be used while the operations it was drawn from are still the first ones of this picture
    bool useBase = s.baseValid && s.base != nullptr && s.baseCount <= s.cur.size();
    for (std::size_t i = 0U; useBase && i < s.baseCount; ++i) {
        if (s.cur[i].hash != s.baseHashes[i]) useBase = false;
    }

    s.repainted = 0;
    for (const IRect& r : s.damage) {
        const bool inBase = r.left >= s.baseArea.left && r.top >= s.baseArea.top && r.right <= s.baseArea.right && r.bottom <= s.baseArea.bottom;
        if (useBase && inBase) {
            // the same pixels as replay(): there the area is cleared and operations 0 .. baseCount-1 are drawn - exactly what the base holds
            s.target.copyPixels(*s.base, r);
            s.target.replayRange(s.cur, s.baseCount, s.cur.size(), r);
        } else {
            s.target.replay(s.cur, r);
        }
        s.repainted += r.area();
    }

    // a new base when the changes keep starting at the same operation (two pictures in a row) and cover a real part of the picture
    if (s.valid && !s.damage.empty()) {
        if (head == s.lastHead) ++s.sameHead;
        else { s.lastHead = head; s.sameHead = 0; }
        const bool big = s.repainted * 1000 >= whole.area() * kBaseMinPixelsPer1000;
        // the base covers the place where the changes are now (a little larger); changes elsewhere are drawn the normal way
        IRect area;
        for (const IRect& r : s.damage) area = area.isEmpty() ? r : area.united(r);
        area = IRect(area.left - 16, area.top - 16, area.right + 16, area.bottom + 16).intersected(whole);
        const bool outside = area.left < s.baseArea.left || area.top < s.baseArea.top || area.right > s.baseArea.right || area.bottom > s.baseArea.bottom;
        const bool deeper = !useBase || outside || head >= s.baseCount + kBaseGrowOps;
        if (s.sameHead >= 1 && big && head >= kBaseMinOps && deeper) {
            if (s.base == nullptr) s.base = std::make_unique<Canvas>(whole.width(), whole.height());
            // when the operations are the same as before, the old area is kept and the new one added to it
            if (useBase && head == s.baseCount) area = area.united(s.baseArea);
            std::uint32_t* px = s.base->pixels();
            for (int y = area.top; y < area.bottom; ++y) {
                std::uint32_t* row = px + static_cast<std::size_t>(y) * static_cast<std::size_t>(whole.width());
                std::fill(row + area.left, row + area.right, 0U);
            }
            s.base->replayRange(s.cur, 0U, head, area);
            s.baseArea = area;
            s.baseHashes.resize(head);
            for (std::size_t i = 0U; i < head; ++i) s.baseHashes[i] = s.cur[i].hash;
            s.baseCount = head;
            s.baseValid = true;
        }
    }
    // (the list of this picture is what the next one is compared with; its `image` pointers are not used again)
    std::swap(s.prev, s.cur);
    s.valid = true;
    return s.damage;
}

} // namespace silveton::ui
