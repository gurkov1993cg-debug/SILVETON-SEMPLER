// SILVETON_PRO_UI_V1 - ENGLISH for the screens. The screens are written in Bulgarian (the default after installing);
// with ENGLISH chosen in SETTINGS every text that is drawn goes through translateToEnglish(): a whole text that is in the
// table is replaced at once, otherwise every Bulgarian word / phrase of the table found in it (as a whole word) is replaced.
#include <algorithm>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace silveton::ui {

namespace {
#include "Lang_En_Table.inc"

// is there a letter (Latin, digit or Cyrillic) that ends just before `pos` / starts at `pos`?
bool letterBefore(const std::string& s, std::size_t pos) {
    if (pos == 0U) return false;
    const auto p = static_cast<unsigned char>(s[pos - 1U]);
    if ((p >= 'A' && p <= 'Z') || (p >= 'a' && p <= 'z') || (p >= '0' && p <= '9')) return true;
    if (p >= 0x80U && p <= 0xBFU && pos >= 2U) {
        const auto q = static_cast<unsigned char>(s[pos - 2U]);
        return q == 0xD0U || q == 0xD1U;
    }
    return false;
}
bool letterAt(const std::string& s, std::size_t pos) {
    if (pos >= s.size()) return false;
    const auto p = static_cast<unsigned char>(s[pos]);
    return (p >= 'A' && p <= 'Z') || (p >= 'a' && p <= 'z') || (p >= '0' && p <= '9') || p == 0xD0U || p == 0xD1U;
}

struct Table {
    std::unordered_map<std::string, std::string> exact;
    std::vector<std::pair<std::string, std::string>> parts;   // the longest first
    Table() {
        for (const auto& e : kEnglish) {
            exact.emplace(e.first, e.second);
            parts.emplace_back(e.first, e.second);
        }
        std::stable_sort(parts.begin(), parts.end(), [](const auto& a, const auto& b) { return a.first.size() > b.first.size(); });
    }
};
const Table& table() {
    static const Table t;
    return t;
}
} // namespace

std::string translateToEnglish(const std::string& s) {
    const Table& t = table();
    const auto it = t.exact.find(s);
    if (it != t.exact.end()) return it->second;
    std::string out = s;
    for (const auto& part : t.parts) {
        const std::string& key = part.first;
        if (key.empty()) continue;
        std::size_t pos = 0U;
        while ((pos = out.find(key, pos)) != std::string::npos) {
            const std::size_t end = pos + key.size();
            if (!letterBefore(out, pos) && !letterAt(out, end)) {
                out.replace(pos, key.size(), part.second);
                pos += part.second.size();
            } else {
                pos += key.size();
            }
        }
    }
    return out;
}

} // namespace silveton::ui
