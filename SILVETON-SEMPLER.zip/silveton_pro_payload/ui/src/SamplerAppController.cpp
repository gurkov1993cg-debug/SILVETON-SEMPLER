#include "silveton/sampler/SoloPresets.h"
#include <iomanip>
// SILVETON_MAC_CONTROLLER_V1 - see SamplerAppController.h
#include "silveton/ui/SamplerAppController.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <sstream>

#include "silveton/ui/Gfx.h"
#include "silveton/sampler/EngineDefs.h"
#include "silveton/sampler/ModelDefs.h"
#include "silveton/sampler/SamplerTypes.h"

namespace silveton::ui {
namespace {

std::string orBlank(const std::string& s, const std::string& fallback) { return isBlank(s) ? fallback : s; }

// Keeps the root set-up problem visible next to the sound error (the last non-blank line of its message).
std::string withRootNote(const std::string& message, const PlatformRuntime::Result& root) {
    if (root.ok || isBlank(root.message)) return message;
    std::string last = root.message;
    std::size_t end = root.message.size();
    while (end > 0U) {
        std::size_t begin = root.message.rfind('\n', end - 1U);
        begin = begin == std::string::npos ? 0U : begin + 1U;
        const std::string line = root.message.substr(begin, end - begin);
        if (!isBlank(line)) { last = line; break; }
        if (begin == 0U) break;
        end = begin - 1U;
    }
    return message + " | ROOT: " + last;
}

std::string joinInts(const std::set<int>& values) {
    std::string out;
    for (const int v : values) {
        if (!out.empty()) out += ",";
        out += std::to_string(v);
    }
    return out;
}

std::vector<int> parseInts(const std::string& text) {
    std::vector<int> out;
    for (const auto& part : splitChar(text, ',')) {
        if (const auto v = toIntOrNull(part)) out.push_back(*v);
    }
    return out;
}

float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
int atI(const std::vector<int>& v, std::size_t i, int def) { return i < v.size() ? v[i] : def; }

} // namespace

const std::vector<std::string>& SamplerAppController::TERCA_CELLS() {
    static const std::vector<std::string> cells = {"MAJ ↑", "MAJ ↓", "MIN ↑", "MIN ↓", "PHR ↑", "HIJAZ ↑"};
    return cells;
}

const std::vector<std::string>& SamplerAppController::NOTE_NAMES() {
    static const std::vector<std::string> names = {"C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B"};
    return names;
}

SamplerAppController::SamplerAppController(ControllerEnv env)
    : env_(std::move(env)), prefs_(files::join(env_.dataDir, "settings.txt")) {
    portaBalanceValue_ = std::clamp(prefs_.getInt("porta_balance", 11), 3, 40);
    voiceCeilingValue_ = std::clamp(prefs_.getInt("voice_ceiling", 48), 8, 128);
    portaNearValue_ = std::clamp(prefs_.getInt("porta_near", 90), 0, 400);
    tercaUppers_ = prefs_.getInt("terca_uppers", 0) & 0x7FFF;   // SILVETON_TQ_PLACES_V1: 15 bits = 7 Uppers + 8 SYNTH places
    scaleUppers_ = prefs_.getInt("scale_uppers", 0) & 0x7FFF;
    tercaRoot_ = prefs_.getInt("terca_root", -1);
    tercaCell_ = prefs_.getInt("terca_cell", -1);
    scaleMask_ = prefs_.getInt("scale_mask", 0) & 0xFFF;
    {   // SILVETON_SCALE_TUNING_V1: the 12 cents (an old file without them = the half-flat notes of the mask)
        const std::string saved = prefs_.getString("scale_cents", "");
        std::vector<float> v;
        for (const auto& part : splitChar(saved, ',')) { try { v.push_back(std::stof(part)); } catch (...) { v.clear(); break; } }
        if (v.size() == 12U) scaleCentsNow_ = v;
        else for (int pc = 0; pc < 12; ++pc) scaleCentsNow_[static_cast<std::size_t>(pc)] = (scaleMask_ & (1 << pc)) != 0 ? -50.0F : 0.0F;
        for (float& x : scaleCentsNow_) x = std::isfinite(x) ? std::clamp(x, -100.0F, 100.0F) : 0.0F;
        scaleName_ = prefs_.getString("scale_name", "");
        scaleTonicValue_ = std::clamp(prefs_.getInt("scale_tonic", 0), 0, 11);
        loadUserScales(prefs_.getString("scale_user", ""));
    }
    tercaMaster_ = prefs_.getBool("terca_master", true);
    scaleMaster_ = prefs_.getBool("scale_master", true);
    bankPath_ = prefs_.getString("bank_path", "");
}

SamplerAppController::~SamplerAppController() { close(); }

// ---------------------------------------------------------------- settings
void SamplerAppController::setPortaBalance(int value, bool save) {
    portaBalanceValue_ = std::clamp(value, 3, 40);
    engine.nativeSetPortaBalance(portaBalanceValue_);
    if (save) prefs_.putInt("porta_balance", portaBalanceValue_);
}

void SamplerAppController::setVoiceCeiling(int voices, bool save) {
    voiceCeilingValue_ = std::clamp(voices, 8, 128);
    engine.nativeSetVoiceCeiling(voiceCeilingValue_);
    if (save) prefs_.putInt("voice_ceiling", voiceCeilingValue_);
}

void SamplerAppController::setPortaNear(int value, bool save) {
    portaNearValue_ = std::clamp(value, 0, 400);
    engine.nativeSetPortaNear(portaNearValue_);
    if (save) prefs_.putInt("porta_near", portaNearValue_);
}

bool SamplerAppController::themeDark() const { return prefs_.getBool("theme_dark", true); }
void SamplerAppController::setThemeDark(bool dark) { prefs_.putBool("theme_dark", dark); }
// SILVETON_COLOR_KEYS_V1: a program that saved only the old dark / light choice opens as GRAPHITE / OLD
int SamplerAppController::classicColor() const { return std::clamp(prefs_.getInt("classic_color", themeDark() ? 0 : 4), 0, 4); }
void SamplerAppController::setClassicColor(int color) {
    const int k = std::clamp(color, 0, 4);
    prefs_.putInt("classic_color", k);
    prefs_.putBool("theme_dark", k != 4);
}
int SamplerAppController::uiLanguage() const { return prefs_.getInt("ui_language", 0) == 1 ? 1 : 0; }
void SamplerAppController::setUiLanguage(int lang) { prefs_.putInt("ui_language", lang == 1 ? 1 : 0); }
// SILVETON_ONLY_OLD_V1: the program opens with the OLD look (4) - a new key, so a choice saved by an earlier build does not bring the new screens back.
int SamplerAppController::uiTheme() const { return std::clamp(prefs_.getInt("ui_theme_v2", 4), 0, 4); }
void SamplerAppController::setUiTheme(int theme) { prefs_.putInt("ui_theme_v2", std::clamp(theme, 0, 4)); }

std::set<int> SamplerAppController::listFavourites() const {
    const auto v = parseInts(prefs_.getString("list_favs", ""));
    return std::set<int>(v.begin(), v.end());
}
void SamplerAppController::saveListFavourites(const std::set<int>& favs) { prefs_.putString("list_favs", joinInts(favs)); }

std::set<int> SamplerAppController::soundFavourites() const {
    const auto v = parseInts(prefs_.getString("sound_favs", ""));
    return std::set<int>(v.begin(), v.end());
}
void SamplerAppController::saveSoundFavourites(const std::set<int>& favs) { prefs_.putString("sound_favs", joinInts(favs)); }

std::vector<int> SamplerAppController::recentSounds() const { return parseInts(prefs_.getString("sound_recent", "")); }

void SamplerAppController::rememberRecentSound(int slot) {
    std::vector<int> list{slot};
    for (const int s : recentSounds()) if (s != slot) list.push_back(s);
    if (list.size() > 40U) list.resize(40U);
    std::string text;
    for (const int s : list) { if (!text.empty()) text += ","; text += std::to_string(s); }
    prefs_.putString("sound_recent", text);
}

// ---------------------------------------------------------------- key scan / TERCA / Q
void SamplerAppController::startKeyScan(int upper, int sound, int edge) {
    keyScanUpper_ = upper;
    keyScanSound_ = std::clamp(sound, 0, 4);
    keyScanEdge_ = edge == 0 ? 0 : 1;
    engine.nativeStartScan(3);
}
void SamplerAppController::cancelKeyScan() { keyScanUpper_ = -1; engine.nativeStartScan(0); }

bool SamplerAppController::tercaOn(int upper) const { return tercaMaster_ && ((tercaUppers_ >> upper) & 1) != 0; }
bool SamplerAppController::quarterOn(int upper) const { return scaleMaster_ && ((scaleUppers_ >> upper) & 1) != 0; }
bool SamplerAppController::tercaChosen(int upper) const { return ((tercaUppers_ >> upper) & 1) != 0; }
bool SamplerAppController::quarterChosen(int upper) const { return ((scaleUppers_ >> upper) & 1) != 0; }

void SamplerAppController::toggleTerca(int upper) {
    const bool chosen = ((tercaUppers_ >> upper) & 1) != 0;
    if (chosen && !tercaMaster_) {
        tercaMaster_ = true;
    } else {
        tercaUppers_ = tercaUppers_ ^ (1 << upper);
        if (!chosen) tercaMaster_ = true;
    }
    saveTercaScale();
    applyTerca();
}

void SamplerAppController::toggleQuarter(int upper) {
    if (upper < 0 || upper >= 15) return;
    syncScaleFromEngine();
    const bool chosen = ((scaleUppers_ >> upper) & 1) != 0;
    if (chosen && !scaleMaster_) {
        scaleMaster_ = true;
    } else {
        scaleUppers_ = scaleUppers_ ^ (1 << upper);
        if (!chosen) scaleMaster_ = true;
    }
    saveTercaScale();
    applyScale();
}

void SamplerAppController::toggleTercaMaster() { tercaMaster_ = !tercaMaster_; saveTercaScale(); applyTerca(); }
void SamplerAppController::toggleScaleMaster() { syncScaleFromEngine(); setScaleEnabled(!scaleMaster_); }
void SamplerAppController::setScaleEnabled(bool enabled) {
    syncScaleFromEngine();
    scaleMaster_ = enabled;
    applyScale();
    saveTercaScale();
}
void SamplerAppController::setScaleTarget(int upper, bool chosen) {
    if (upper < 0 || upper >= 15) return;
    syncScaleFromEngine();
    const int bit = 1 << upper;
    scaleUppers_ = chosen ? (scaleUppers_ | bit) : (scaleUppers_ & ~bit);
    applyScale();
    saveTercaScale();
}
bool SamplerAppController::syncScaleFromEngine() {
    const auto values = engine.nativeScaleTuning();
    if (values.size() != 16U || values[0] < 0.5F) return false;
    const bool enabled = values[1] >= 0.5F;
    const int targets = static_cast<int>(values[2]) & 0x7FFF;
    const int tonic = std::clamp(static_cast<int>(values[3]), 0, 11);
    const std::string name = engine.nativeScaleName();
    bool changed = scaleMaster_ != enabled || scaleUppers_ != targets || scaleTonicValue_ != tonic || scaleName_ != name;
    for (std::size_t i = 0U; i < 12U; ++i) changed = changed || scaleCentsNow_[i] != values[i + 4U];
    if (!changed) return true;
    scaleMaster_ = enabled; scaleUppers_ = targets; scaleTonicValue_ = tonic; scaleName_ = name;
    scaleCentsNow_.assign(values.begin() + 4, values.end());
    scaleMask_ = 0;
    for (int pc = 0; pc < 12; ++pc) if (std::fabs(scaleCentsNow_[static_cast<std::size_t>(pc)]) > 0.004F) scaleMask_ |= 1 << pc;
    return true;
}
void SamplerAppController::applyScaleUppers() { engine.nativeSetScaleUppers(scaleMaster_ ? scaleUppers_ : 0); }

int SamplerAppController::pollScan() {
    syncScaleFromEngine();
    const std::vector<int> v = engine.nativeScanInfo();
    if (v.size() < 6U) return 0;
    if (lastTercaSerial_ < 0) lastTercaSerial_ = v[3];
    if (lastScaleSerial_ < 0) lastScaleSerial_ = v[5];
    if (v[3] != lastTercaSerial_) {
        lastTercaSerial_ = v[3];
        if (v[1] >= 0 && v[1] <= 11 && v[2] >= 0 && v[2] <= 5) {
            tercaRoot_ = v[1];
            tercaCell_ = v[2];
            saveTercaScale();
            applyTerca();
        }
    }
    if (v[5] != lastScaleSerial_) {
        lastScaleSerial_ = v[5];
        if (v[4] != 0) {
            scaleMask_ = v[4] & 0xFFF;
            // SILVETON_SCAN_ADDS_V1: the played notes get 50 cents LOWER on top of the scale that is set now (the other notes stay as they are)
            for (int pc = 0; pc < 12; ++pc) {
                if ((scaleMask_ & (1 << pc)) == 0) continue;
                float& x = scaleCentsNow_[static_cast<std::size_t>(pc)];
                x = std::clamp(x - 50.0F, -100.0F, 100.0F);
            }
            scaleName_.clear();   // the scale is changed by the scan, so it has no ready-made name any more
            saveTercaScale();
            applyScale();
        }
    }
    if (v.size() >= 8U) {
        if (lastKeySerial_ < 0) lastKeySerial_ = v[7];
        if (v[7] != lastKeySerial_) {
            lastKeySerial_ = v[7];
            const int upper = keyScanUpper_;
            const int sound = keyScanSound_;
            const int edge = keyScanEdge_;
            keyScanUpper_ = -1;
            const int key = v[6];
            std::optional<UpperState> s;
            if (upper >= 0 && upper <= 6) s = upperState(upper);
            if (s && key >= 0 && key <= 127 && sound == 0) {
                // ОСНОВЕН: the pressed key becomes the lowest (edge 0) or the highest (edge 1) key; the other end moves only if it would cross
                UpperState n = *s;
                if (edge == 0) {
                    n.keyLow = key;
                    n.keyHigh = s->keyHigh < key ? 127 : s->keyHigh;
                } else {
                    n.keyLow = s->keyLow > key ? 0 : s->keyLow;
                    n.keyHigh = key;
                }
                updateUpperMain(upper, n);
            } else if (s && key >= 0 && key <= 127 && sound >= 1 && sound <= 4) {
                // a layer: the same rule on its own key range (ids 6 and 7)
                const std::vector<float> p = layerParams(upper, sound - 1);
                if (p.size() > 7U) {
                    const int low = static_cast<int>(p[6]);
                    const int high = static_cast<int>(p[7]);
                    if (edge == 0) {
                        setLayerParam(upper, sound - 1, 6, static_cast<float>(key));
                        setLayerParam(upper, sound - 1, 7, static_cast<float>(high < key ? 127 : high));
                    } else {
                        setLayerParam(upper, sound - 1, 6, static_cast<float>(low > key ? 0 : low));
                        setLayerParam(upper, sound - 1, 7, static_cast<float>(key));
                    }
                }
            }
        }
    }
    if (v[0] != 3 && keyScanUpper_ >= 0) keyScanUpper_ = -1;
    return v[0];
}

void SamplerAppController::startTercaScan() { engine.nativeStartScan(1); }
void SamplerAppController::startScaleScan() { engine.nativeStartScan(2); }
void SamplerAppController::cancelScan() { engine.nativeStartScan(0); }

void SamplerAppController::saveTercaScale() {
    prefs_.putAll({{"terca_uppers", std::to_string(tercaUppers_)}, {"scale_uppers", std::to_string(scaleUppers_)},
                   {"terca_root", std::to_string(tercaRoot_)}, {"terca_cell", std::to_string(tercaCell_)},
                   {"scale_mask", std::to_string(scaleMask_)},
                   {"scale_cents", [this] { std::string o; for (std::size_t i = 0U; i < scaleCentsNow_.size(); ++i) { if (i != 0U) o += ","; o += std::to_string(scaleCentsNow_[i]); } return o; }()},
                   {"scale_name", scaleName_}, {"scale_tonic", std::to_string(scaleTonicValue_)}, {"scale_user", userScalesText()},
                   {"terca_master", tercaMaster_ ? "true" : "false"}, {"scale_master", scaleMaster_ ? "true" : "false"}});
}

void SamplerAppController::applyTerca() {
    const bool valid = tercaRoot_ >= 0 && tercaRoot_ <= 11 && tercaCell_ >= 0 && tercaCell_ <= 5;
    engine.nativeSetTerca(valid && tercaMaster_ ? tercaUppers_ : 0, std::max(tercaRoot_, 0), std::max(tercaCell_, 0));
}

std::vector<float> SamplerAppController::scaleCents() const { return scaleCentsNow_; }   // SILVETON_SCALE_TUNING_V1

// ---------------------------------------------------------------- SILVETON_SCALE_TUNING_V1: the SCALE (musical tuning)
// Offsets in cents against the equal 12 notes, per real note (C = 0 ... B = 11), with the tonic C. Every number is computed
// from the ratio that defines the tuning, rounded to the hundredth; the quarter-tone ones are -50 on the named degrees.
const std::vector<SamplerAppController::ScalePreset>& SamplerAppController::scalePresets() {
    static const std::vector<ScalePreset> list = {
        {"EQUAL", {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
        {"JUST INTONATION", {0.00F, 11.73F, 3.91F, 15.64F, -13.69F, -1.96F, -9.78F, 1.96F, 13.69F, -15.64F, 17.60F, -11.73F}},
        {"PYTHAGOREAN", {0.00F, -9.78F, 3.91F, -5.87F, 7.82F, -1.96F, -11.73F, 1.96F, -7.82F, 5.87F, -3.91F, 9.78F}},
        {"MEANTONE", {0.00F, -23.95F, -6.84F, 10.26F, -13.69F, 3.42F, -20.53F, -3.42F, -27.37F, -10.26F, 6.84F, -17.11F}},
        {"WERCKMEISTER III", {0.00F, -9.78F, -7.82F, -5.87F, -9.78F, -1.96F, -11.73F, -3.91F, -7.82F, -11.73F, -3.91F, -7.82F}},
        {"RAST", {0, 0, 0, 0, -50.0F, 0, 0, 0, 0, 0, 0, -50.0F}},
        {"BAYATI", {0, 0, -50.0F, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    };
    return list;
}

std::vector<float> SamplerAppController::scaleTurned(const std::array<float, 12>& cents, int tonic) {
    std::vector<float> out(12U, 0.0F);
    const int t = ((tonic % 12) + 12) % 12;
    for (int pc = 0; pc < 12; ++pc) out[static_cast<std::size_t>((pc + t) % 12)] = cents[static_cast<std::size_t>(pc)];
    return out;
}

void SamplerAppController::setScale(const std::vector<float>& cents, const std::string& name, int tonic) {
    syncScaleFromEngine();
    for (std::size_t i = 0U; i < 12U; ++i) scaleCentsNow_[i] = i < cents.size() && std::isfinite(cents[i]) ? std::clamp(cents[i], -100.0F, 100.0F) : 0.0F;
    scaleName_ = name;
    if (tonic >= 0) scaleTonicValue_ = std::clamp(tonic, 0, 11);
    saveTercaScale();
    applyScale();
}

void SamplerAppController::setScaleNote(int note, float cents) {
    if (note < 0 || note > 11 || !std::isfinite(cents)) return;
    syncScaleFromEngine();
    scaleCentsNow_[static_cast<std::size_t>(note)] = std::clamp(cents, -100.0F, 100.0F);
    scaleName_ = "MANUAL";
    saveTercaScale();
    applyScale();
}

static std::string cleanScaleName(std::string name) {
    for (char& ch : name) if (ch == '=' || ch == '|' || ch == ';' || ch == '\n' || ch == '\r') ch = ' ';
    return trimmed(name.substr(0U, 128U));
}

bool SamplerAppController::saveUserScale(const std::string& name) {
    syncScaleFromEngine();
    const std::string n = cleanScaleName(name);
    if (n.empty()) return false;
    for (auto& u : userScales_) if (u.name == n) { u.cents = scaleCentsNow_; u.tonic = scaleTonicValue_; scaleName_ = n; applyScale(); saveTercaScale(); return true; }
    userScales_.push_back({n, scaleCentsNow_, scaleTonicValue_});
    scaleName_ = n;
    applyScale();
    saveTercaScale();
    return true;
}

bool SamplerAppController::useUserScale(int i) {
    if (i < 0 || i >= userScaleCount()) return false;
    const UserScale u = userScales_[static_cast<std::size_t>(i)];
    setScale(u.cents, u.name, u.tonic);
    return true;
}

bool SamplerAppController::deleteUserScale(int i) {
    if (i < 0 || i >= userScaleCount()) return false;
    userScales_.erase(userScales_.begin() + i);
    saveTercaScale();
    return true;
}

// "name|c0,c1,...,c11" separated by ";"
std::string SamplerAppController::userScalesText() const {
    std::string o;
    for (const auto& u : userScales_) {
        if (!o.empty()) o += ";";
        o += u.name + "|";
        for (std::size_t i = 0U; i < u.cents.size(); ++i) { if (i != 0U) o += ","; o += std::to_string(u.cents[i]); }
        o += "|" + std::to_string(u.tonic);
    }
    return o;
}

void SamplerAppController::loadUserScales(const std::string& text) {
    userScales_.clear();
    for (const auto& item : splitChar(text, ';')) {
        const std::size_t bar = item.find('|');
        if (bar == std::string::npos || bar == 0U) continue;
        UserScale u;
        u.name = item.substr(0U, bar);
        const auto end = item.find('|', bar + 1U);
        if (end != std::string::npos) u.tonic = std::clamp(toIntOrNull(item.substr(end + 1U)).value_or(0), 0, 11);
        for (const auto& part : splitChar(item.substr(bar + 1U, end == std::string::npos ? end : end - bar - 1U), ',')) {
            try { const float v = std::stof(part); if (!std::isfinite(v)) { u.cents.clear(); break; } u.cents.push_back(std::clamp(v, -100.0F, 100.0F)); }
            catch (...) { u.cents.clear(); break; }
        }
        if (u.cents.size() == 12U) userScales_.push_back(std::move(u));
    }
}

void SamplerAppController::applyScale(bool markEdited) {
    engine.nativeSetScaleTuning(scaleMaster_, scaleUppers_, scaleTonicValue_, scaleCentsNow_, scaleName_, markEdited);
}

// ---------------------------------------------------------------- full MIDI / advanced GLOBAL
std::optional<SamplerAppController::GlobalAdvanced> SamplerAppController::globalAdvanced() {
    const std::vector<float> v = engine.nativeGlobalState();
    if (v.size() < 39U) return std::nullopt;
    GlobalAdvanced a;
    a.scaleRoot = static_cast<int>(v[14]);
    a.scaleCents.assign(v.begin() + 15, v.begin() + 27);
    a.midiInMask = static_cast<int>(v[27]);
    a.filterNotes = v[28] >= 0.5F;
    a.filterCc = v[29] >= 0.5F;
    a.filterBend = v[30] >= 0.5F;
    a.filterAftertouch = v[31] >= 0.5F;
    a.breathMin = v[32]; a.breathMax = v[33]; a.breathCurve = v[34];
    a.expressionMin = v[35]; a.expressionMax = v[36]; a.expressionCurve = v[37];
    a.damperReversed = v[38] >= 0.5F;
    return a;
}

bool SamplerAppController::updateGlobalAdvanced(const GlobalAdvanced& a) {
    return nativeResult(engine.nativeUpdateGlobalAdvanced(a.scaleRoot, a.scaleCents, a.midiInMask, a.filterNotes, a.filterCc,
        a.filterBend, a.filterAftertouch, a.breathMin, a.breathMax, a.breathCurve,
        a.expressionMin, a.expressionMax, a.expressionCurve, a.damperReversed));
}

bool SamplerAppController::stepGlobalTranspose(int step) {
    auto g = globalUiState();
    if (!g) return false;
    g->transpose = step == 0 ? 0 : std::clamp(g->transpose + step, -12, 12);
    return updateGlobalUi(*g);
}

// ---------------------------------------------------------------- life cycle
bool SamplerAppController::start() {
    if (closed_.load()) return false;
    engine.nativeSetPortaBalance(portaBalanceValue_);
    engine.nativeSetPortaNear(portaNearValue_);
    engine.nativeSetVoiceCeiling(voiceCeilingValue_);   // SILVETON_VOICE_CEILING_V1
    applyTerca();
    applyScaleUppers();
    if (started_.load()) return true;
    // the tablet's SamplerRuntime.start(): (root set-up,) open the sound output (this also starts MIDI), then run it
    bool audioOk = false;
    bool rootOk = true;
    PlatformRuntime::Result audioPermissions;
    if (env_.platform) {
        const PlatformRuntime::Result root = env_.platform->enter();
        if (!root.ok) {
            status(root.message);
            rootOk = false;
        } else {
            audioPermissions = env_.platform->refreshAudioPermissions();
            if (!audioPermissions.ok) status(audioPermissions.message);
            const PlatformRuntime::Result midiPermissions = env_.platform->refreshMidiPermissions();
            if (!midiPermissions.ok) status(midiPermissions.message);
        }
    }
    if (rootOk) {
        runtimeRunning_ = true;
        if (!engine.nativeAudioOpen()) {
            status(withRootNote(orBlank(engine.nativeLastTextError(), "Audio open failed (" + std::to_string(engine.nativeLastAudioError()) + ")"), audioPermissions));
        } else if (!engine.nativeAudioStart()) {
            status(orBlank(engine.nativeLastTextError(), "Audio start failed (" + std::to_string(engine.nativeLastAudioError()) + ")"));
        } else {
            if (env_.platform) env_.platform->audioStarted();
            status("");
            audioOk = true;
        }
    }
    // The bank must be found even when audio needs another try.
    startBankLoad();
    if (!audioOk) return false;
    started_.store(true);
    return true;
}

void SamplerAppController::startBankLoad() {
    bool expected = false;
    if (!bankLoading_.compare_exchange_strong(expected, true)) return;
    std::lock_guard<std::mutex> lock(bankThreadMutex_);
    if (bankThread_.joinable()) bankThread_.join();
    bankThread_ = std::thread([this] {
        loadDefaultBankOnce();
        bankLoading_.store(false);
    });
}

int SamplerAppController::bankSoundCount() {
    int n = 0;
    for (const auto& name : engine.nativeSoundCatalogNames()) if (!startsWith(name, "~ ")) ++n;
    return n;
}

bool SamplerAppController::applyBankFile(const std::string& path) {
    if (!engine.nativeLoadSvBank(path)) {
        status(orBlank(engine.nativeLastTextError(), "SILVETON_BANK.sv load failed: " + path));
        return false;
    }
    {
        std::lock_guard<std::mutex> lock(bankPathMutex_);
        bankPath_ = path;
    }
    addExtraBankFiles();   // SILVETON_SEND_V1 (the Manager's copy): the sent sounds before the LIST
    restoreUserStateIfMissing();
    const std::string userState = userStateFile();
    if (setPresent(userState) && !engine.nativeLoadUserPerformanceState(userState)) {
        // SILVETON_STATE_RECOVER_V1: a damaged blends file is kept aside (.CORRUPT) and the safety copies are tried one after the other
        const std::string why = orBlank(engine.nativeLastTextError(), "BLENDS/LIST user state load failed");
        if (!recoverUserState(userState)) { status(why); return false; }
    }
    if (setPresent(userState) && !setPresent(privateStateFile())) backupUserState();   // first copy for LIST/BLENDS made before this version
    if (bankSoundCount() <= 0) {
        status("SILVETON_BANK.sv loaded but contains no visible SOUND positions");
        return false;
    }
    defaultBankAttempted_ = true;
    applyScale();
    applyTerca();
    // SILVETON_EMPTY_START_V1 (Цветомир, 02.11.2026): the sampler starts EMPTY - no blend is open and no engine place sounds until the
    // player chooses a blend in the LIST or turns a place on.
    engine.nativeClearPerformance();
    status("");
    ++bankSerial_;
    return true;
}

void SamplerAppController::loadDefaultBankOnce() {
    if (defaultBankAttempted_) return;
    // The native sampler survives a restart of the screens; keep its bank and BLENDS.
    // SILVETON_BANK_LOAD_FIX_V1: the built-in waves ("~ SAW" ...) are always in the catalog,
    // so only real bank SOUNDs count as "a bank is loaded".
    if (bankSoundCount() > 0) {
        defaultBankAttempted_ = true;
        status("");
        return;
    }
    std::string selected;
    {
        std::lock_guard<std::mutex> lock(bankPathMutex_);
        if (!bankPath_.empty() && files::isFile(bankPath_) && files::readable(bankPath_)) selected = bankPath_;
    }
    PlatformRuntime::Result storageAccess;
    if (selected.empty() && env_.platform) storageAccess = env_.platform->refreshBankStorageAccess();   // all-files access, granted by root
    // (on the tablet the file system may need a moment after the access was granted: three tries)
    for (int attempt = 0; attempt < (env_.platform ? 3 : 1) && selected.empty(); ++attempt) {
        for (const auto& c : env_.bankCandidates) {
            if (files::isFile(c) && files::readable(c)) { selected = c; break; }
        }
        if (selected.empty() && attempt < 2 && env_.platform) std::this_thread::sleep_for(std::chrono::milliseconds(120));
    }
    if (selected.empty()) {
        const std::string platformText = env_.platform ? env_.platform->bankNotFoundMessage(storageAccess) : std::string();
        status(!platformText.empty() ? platformText
                                     : "SILVETON_BANK.sv was not found. Put it in the “SILVETON” folder in Documents or choose it from the File menu.");
        return;
    }
    applyBankFile(files::absolute(selected));
}

bool SamplerAppController::useBankFile(const std::string& path) {
    if (!files::isFile(path) || !files::readable(path)) {
        status("SILVETON_BANK.sv cannot be read: " + path);
        return false;
    }
    prefs_.putString("bank_path", path);
    defaultBankAttempted_ = false;
    return applyBankFile(files::absolute(path));
}

void SamplerAppController::setMidiPreviewIsolation(bool blocked) {
    if (!closed_.load()) engine.nativeSetMidiPreviewIsolation(blocked);
}

void SamplerAppController::pauseAudio() {
    if (!closed_.load() && started_.load()) engine.nativeAudioStop();
}

bool SamplerAppController::resumeAudio() {
    if (closed_.load()) return false;
    if (!started_.load()) return start();
    if (!defaultBankAttempted_) startBankLoad();
    // the tablet's SamplerRuntime.resumeAudio()
    PlatformRuntime::Result audioPermissions;
    if (env_.platform) {
        const PlatformRuntime::Result root = env_.platform->enter();
        if (!root.ok) {
            status(root.message);
            return false;
        }
        audioPermissions = env_.platform->refreshAudioPermissions();
        if (!audioPermissions.ok) status(audioPermissions.message);
        const PlatformRuntime::Result midiPermissions = env_.platform->refreshMidiPermissions();
        if (!midiPermissions.ok) status(midiPermissions.message);
    }
    if (engine.nativeAudioNeedsRecovery() && !engine.nativeAudioRecover()) {
        status(orBlank(engine.nativeLastTextError(), "Audio recovery failed (" + std::to_string(engine.nativeLastAudioError()) + ")"));
        return false;
    }
    if (!engine.nativeAudioOpen()) {
        status(withRootNote(orBlank(engine.nativeLastTextError(), "Audio reopen failed (" + std::to_string(engine.nativeLastAudioError()) + ")"), audioPermissions));
        return false;
    }
    const bool ok = engine.nativeAudioStart();
    if (!ok) {
        status(orBlank(engine.nativeLastTextError(), "Audio start failed (" + std::to_string(engine.nativeLastAudioError()) + ")"));
    } else {
        if (env_.platform) env_.platform->audioStarted();
        status("");
    }
    return ok;
}

void SamplerAppController::housekeeping() {
    if (closed_.load()) return;
    const std::int64_t now = nowMs();
    if (lastRecoveryPollMs_ != 0 && now - lastRecoveryPollMs_ < 250) return;
    lastRecoveryPollMs_ = now;
    if (runtimeRunning_) {
        // Headphone lock of the tablet has no meaning here; the call stays harmless.
        engine.nativeEnforceOutputRoute();
        if (engine.nativeAudioNeedsRecovery()) {
            bool rootReady = true;
            if (env_.platform) {
                const PlatformRuntime::Result root = env_.platform->enter();
                if (!root.ok) {
                    status(root.message);
                    rootReady = false;
                } else {
                    const PlatformRuntime::Result permissions = env_.platform->refreshAudioPermissions();
                    if (!permissions.ok) {
                        status(permissions.message);
                        rootReady = false;
                    }
                }
            }
            if (rootReady) {
                const int error = engine.nativeLastAudioError();
                if (!engine.nativeAudioRecover()) {
                    status("Audio recovery failed: " + std::to_string(error) + " " + engine.nativeLastTextError());
                } else if (!engine.nativeAudioStart()) {
                    status(orBlank(engine.nativeLastTextError(), "Audio restart failed (" + std::to_string(engine.nativeLastAudioError()) + ")"));
                } else {
                    if (env_.platform) env_.platform->audioStarted();
                    status("");
                }
            }
        }
    }
    // the tablet's SamplerMidiController status poll
    const int count = std::max(engine.nativeMidiDeviceCount(), 0);
    if (count != lastMidiConnectionCount_) {
        lastMidiConnectionCount_ = count;
        if (env_.midiConnectionChanged) env_.midiConnectionChanged(count);
    }
    const int error = engine.nativeMidiLastError();
    if (error != lastMidiError_) {
        const int previous = lastMidiError_;
        lastMidiError_ = error;
        if (error != 0) {
            if (env_.platform && (error == -13 || error == -1) && now - lastMidiPermissionMs_ >= 1000) {   // the device nodes lost their permissions: root gives them back
                lastMidiPermissionMs_ = now;
                env_.platform->refreshMidiPermissions();
            }
            status("MIDI access failed (code " + std::to_string(-error) + ")");
        }
        else if (previous != 0) status("");
    }
}

SamplerAppController::MidiStatus SamplerAppController::midiStatus() {
    const std::vector<int> msg = engine.nativeMidiLastMessage();
    MidiStatus s;
    s.deviceCount = std::max(engine.nativeMidiDeviceCount(), 0);
    s.lastError = engine.nativeMidiLastError();
    s.activitySerial = engine.nativeMidiActivitySerial();
    s.status = atI(msg, 0, 0);
    s.data1 = atI(msg, 1, 0);
    s.data2 = atI(msg, 2, 0);
    return s;
}

bool SamplerAppController::audioRunning() { return !closed_.load() && engine.nativeAudioStarted(); }
int SamplerAppController::audioLastError() { return engine.nativeLastAudioError(); }
bool SamplerAppController::testInstrumentEnabled() { return !closed_.load() && engine.nativeTestInstrumentEnabled(); }
bool SamplerAppController::testEpNoteOn(int note, int velocity) {
    return !closed_.load() && engine.nativeTestNoteOn(std::clamp(note, 0, 127), std::clamp(velocity, 1, 127));
}
void SamplerAppController::testEpNoteOff(int note) { if (!closed_.load()) engine.nativeTestNoteOff(std::clamp(note, 0, 127)); }
bool SamplerAppController::panic() { return !closed_.load() && engine.nativePanic(); }

void SamplerAppController::close() {
    bool expected = false;
    if (!closed_.compare_exchange_strong(expected, true)) return;
    started_.store(false);
    {
        std::lock_guard<std::mutex> lock(bankThreadMutex_);
        if (bankThread_.joinable()) bankThread_.join();
    }
    if (lastMidiConnectionCount_ != 0 && env_.midiConnectionChanged) env_.midiConnectionChanged(0);
    runtimeRunning_ = false;
    engine.nativePanic();
    engine.nativeAudioStop();
    engine.nativeAudioClose();
    if (env_.platform) env_.platform->leave();
}

// ---------------------------------------------------------------- lists
std::vector<SamplerAppController::ListItem> SamplerAppController::listItems(int bank, int page, int slot) {
    const std::vector<int> numbers = engine.nativeListEntryNumbers(bank, page, slot);
    const std::vector<std::string> names = engine.nativeListEntryNames(bank, page, slot);
    const std::vector<int> addresses = engine.nativeListEntryCombiAddresses(bank, page, slot);
    const std::size_t count = std::min({numbers.size(), names.size(), addresses.size() / 3U});
    std::vector<ListItem> out;
    out.reserve(count);
    for (std::size_t i = 0U; i < count; ++i) {
        const std::size_t base = i * 3U;
        out.push_back(ListItem{numbers[i], names[i], addresses[base], addresses[base + 1U], addresses[base + 2U]});
    }
    return out;
}

int SamplerAppController::activeListEntry(int bank, int page, int slot) { return engine.nativeActiveListEntry(bank, page, slot); }

bool SamplerAppController::activateListEntry(int bank, int page, int slot, int index) {
    const bool ok = nativeResult(engine.nativeActivateListEntry(bank, page, slot, index));
    if (ok) syncScaleFromEngine();
    return ok;
}

bool SamplerAppController::blendEdited() { return engine.nativeBlendEdited(); }
std::string SamplerAppController::lastRecallMissing() { return engine.nativeLastRecallMissing(); }
int SamplerAppController::midiCcValue(int cc) { return engine.nativeMidiCcValue(cc); }

// SILVETON_SET_FILE_V1: the LIST and BLENDS are ONE file next to the bank -
// <folder of SILVETON_BANK.sv>/SILVETON_BLENDS.SVSET (the previous version stays as .BAK next to it).
// A silent safety copy goes to the program's own folder; at start a missing file is restored from the safety copy.
std::string SamplerAppController::bankFile() {
    {
        std::lock_guard<std::mutex> lock(bankPathMutex_);
        if (!bankPath_.empty() && files::isFile(bankPath_)) return bankPath_;
    }
    for (const auto& c : env_.bankCandidates) {
        if (files::isFile(c) && files::readable(c)) return c;
    }
    return {};
}

std::string SamplerAppController::bankDir() {
    const std::string f = bankFile();
    if (!f.empty()) {
        const std::string parent = files::parentOf(f);
        if (!parent.empty()) return parent;
    }
    return env_.dataDir;
}

// SILVETON_USER_WAVES_V1
std::string SamplerAppController::userStateFile() { return files::join(bankDir(), "SILVETON_BLENDS.SVSET"); }
std::string SamplerAppController::privateStateFile() const { return files::join(env_.dataDir, "SILVETON_USER_STATE.SVSET"); }

// SILVETON_SET_DIR_FIX_V1: a SET (.SVSET) is a FOLDER (manifest.svs + audio/), not one file.
bool SamplerAppController::setPresent(const std::string& f) const {
    return (files::isDirectory(f) && files::isFile(files::join(f, "manifest.svs"))) || (files::isFile(f) && files::fileSize(f) > 0);
}

// SILVETON_SET_COPY_SAFE_V1: the new copy is made complete under a temporary name first; the old one is taken away only after that,
// so a copy that fails half way never costs the old set.
bool SamplerAppController::copySet(const std::string& src, const std::string& dst) const {
    const std::string tmp = dst + ".new";
    if (files::exists(tmp)) files::removeRecursively(tmp);
    const bool made = files::isDirectory(src) ? files::copyRecursively(src, tmp) : (files::copyFile(src, tmp) && files::isFile(tmp));
    if (!made) { if (files::exists(tmp)) files::removeRecursively(tmp); return false; }
    if (files::exists(dst) && (files::isDirectory(dst) || files::isDirectory(tmp))) files::removeRecursively(dst);   // a folder cannot be replaced by a rename
    if (std::rename(tmp.c_str(), dst.c_str()) != 0) { files::removeRecursively(tmp); return false; }
    return true;
}

std::optional<std::string> SamplerAppController::loadSoloModelFile(int upper, const std::string& path, int sound) {
    if (!engine.nativeLoadSoloSound(upper, sound, path))
        return orBlank(engine.nativeLastTextError(), "SOLO model could not be loaded.");
    if (!saveUserState())
        return std::string("Моделът е зареден, но автоматичният запис не успя. Запази SET ръчно.");
    return std::nullopt;
}

bool SamplerAppController::saveUserState() {
    syncScaleFromEngine();
    const std::string dst = userStateFile();
    if (setPresent(dst)) copySet(dst, files::join(files::parentOf(dst), "SILVETON_BLENDS.SVSET.BAK"));   // one WRITE can always be undone
    engine.nativeSetSetExtraText(tqText()); // every save, including LIST edits and automatic safety copies
    const bool ok = nativeResult(engine.nativeSaveUserPerformanceState(dst));
    if (ok) backupUserState();
    if (ok && userStateSaved_) userStateSaved_();   // SILVETON_PROJECT_SYNC_V1
    return ok;
}

void SamplerAppController::setUserStateSavedHandler(std::function<void()> handler) { userStateSaved_ = std::move(handler); }

void SamplerAppController::backupUserState() {
    const std::string src = userStateFile();
    if (!setPresent(src)) return;
    files::makeDirectories(env_.dataDir);
    copySet(src, privateStateFile());   // silent safety copy (survives a lost / moved bank folder)
}

std::string SamplerAppController::takeNotice() {
    std::lock_guard<std::mutex> lock(noticeMutex_);
    std::string out;
    out.swap(notice_);
    return out;
}

// SILVETON_STATE_RECOVER_V1: the file with the LIST and the blends cannot be read. Nothing is thrown away: the damaged file stays next to it as
// SILVETON_BLENDS.SVSET.CORRUPT, then the safety copy (the program's own folder) and the .BAK are tried; the first one that loads takes its place.
// The first copy that is good is NOT overwritten by the damaged one, because the damaged file is moved aside before anything is written.
bool SamplerAppController::recoverUserState(const std::string& userState) {
    const std::string corrupt = userState + ".CORRUPT";
    std::vector<std::string> candidates = {privateStateFile(), files::join(files::parentOf(userState), "SILVETON_BLENDS.SVSET.BAK")};
    for (const auto& older : env_.olderStateCopies) candidates.push_back(older);
    bool keptAside = false;
    for (const auto& cand : candidates) {
        if (!setPresent(cand) || cand == userState) continue;
        if (!keptAside) { keptAside = copySet(userState, corrupt); }
        if (!copySet(cand, userState)) continue;
        if (engine.nativeLoadUserPerformanceState(userState)) {
            std::lock_guard<std::mutex> lock(noticeMutex_);
            notice_ = "The file with the blends and the LIST was damaged and could not be read.\n"
                      "I restored them from the backup copy. The damaged file was kept next to them as SILVETON_BLENDS.SVSET.CORRUPT.\n"
                      "Anything you saved after that copy may be missing.";
            return true;
        }
    }
    if (keptAside) (void)copySet(corrupt, userState);   // nothing helped: the damaged file goes back as it was
    return false;
}

void SamplerAppController::restoreUserStateIfMissing() {
    const std::string dst = userStateFile();
    if (setPresent(dst)) return;
    // the safety copy, then the .BAK next to it
    std::vector<std::string> candidates = {privateStateFile(), files::join(files::parentOf(dst), "SILVETON_BLENDS.SVSET.BAK")};
    for (const auto& older : env_.olderStateCopies) candidates.push_back(older);   // the tablet's old /storage/emulated/0/SILVETON copies
    for (const auto& c : candidates) {
        if (setPresent(c)) { copySet(c, dst); return; }   // SILVETON_SET_FILE_V1
    }
}

bool SamplerAppController::renumberLiveList() {
    const auto items = listItems(0, 0, 0);
    for (std::size_t i = 0U; i < items.size(); ++i) {
        const ListItem& item = items[i];
        const int expected = static_cast<int>(i) + 1;
        if (item.number == expected) continue;
        if (!engine.nativeSetListEntry(0, 0, 0, static_cast<int>(i), expected, item.name, item.combiBank, item.combiPage, item.combiSlot)) {
            return nativeResult(false);
        }
    }
    return true;
}

bool SamplerAppController::renameLiveListEntry(int index, const std::string& name) {
    const auto items = listItems(0, 0, 0);
    if (index < 0 || index >= static_cast<int>(items.size()) || isEmptyListItem(items[static_cast<std::size_t>(index)])) {
        return fail("LIST entry is not available");
    }
    const std::string finalName = trimmed(name);
    if (finalName.empty()) return fail("LIST name cannot be empty");
    auto changed = items;
    changed[static_cast<std::size_t>(index)].name = finalName;
    return commitLiveList(changed, engine.nativeActiveListEntry(0, 0, 0), listFavourites());
}

// SILVETON_LIST_POSITIONS_V1: fixed LIST positions 1..200 like Korg Performances.
// An empty position is an entry with COMBI address 0/0/0; empty positions at the end are removed,
// so the stored LIST only grows as far as the last BLEND.
bool SamplerAppController::isEmptyListItem(const ListItem* item) const {
    return item == nullptr || (item->combiBank == 0 && item->combiPage == 0 && item->combiSlot == 0);
}

bool SamplerAppController::ensureListLength(int count) {
    auto items = listItems(0, 0, 0);
    if (static_cast<int>(items.size()) >= count) return true;
    if (items.empty()) {
        if (!nativeResult(engine.nativeWriteList(0, 0, 0, "LIVE", {1}, {"-"}, {0, 0, 0}))) return false;
        items = listItems(0, 0, 0);
    }
    for (int i = static_cast<int>(items.size()); i < count; ++i) {
        if (!nativeResult(engine.nativeInsertListEntry(0, 0, 0, i, i + 1, "-", 0, 0, 0))) return false;
    }
    return true;
}

bool SamplerAppController::trimListTail() {
    auto items = listItems(0, 0, 0);
    while (!items.empty() && isEmptyListItem(items.back())) {
        if (!nativeResult(engine.nativeRemoveListEntry(0, 0, 0, static_cast<int>(items.size()) - 1))) return false;
        items = listItems(0, 0, 0);
    }
    return true;
}

bool SamplerAppController::deleteLiveListEntry(int index) {
    return deleteLiveListEntries({index});
}

bool SamplerAppController::deleteLiveListEntries(const std::vector<int>& indices) {
    auto items = listItems(0, 0, 0);
    auto favourites = listFavourites();
    int active = engine.nativeActiveListEntry(0, 0, 0);
    const std::set<int> unique(indices.begin(), indices.end());
    if (unique.empty()) return fail("Choose at least one blend");
    for (const int index : unique) {
        if (index < 0 || index >= static_cast<int>(items.size()) || isEmptyListItem(items[static_cast<std::size_t>(index)]))
            return fail("LIST position is empty");
    }
    for (const int index : unique) {
        items[static_cast<std::size_t>(index)] = ListItem{};
        favourites.erase(index);
        if (active == index) active = -1;
    }
    while (!items.empty() && isEmptyListItem(items.back())) items.pop_back();
    return commitLiveList(items, active, favourites);
}

bool SamplerAppController::copyListEntryTo(int from, int to) {
    lastFailure_.clear();
    const auto all = listItems(0, 0, 0);
    const ListItem* src = (from >= 0 && from < static_cast<int>(all.size())) ? &all[static_cast<std::size_t>(from)] : nullptr;
    if (isEmptyListItem(src)) return fail("LIST position is empty");
    if (to < 0 || to >= 200 || to == from) return fail("LIST target position is invalid");
    if (!ensureListLength(to + 1)) return false;
    if (!nativeResult(engine.nativeSetListEntry(0, 0, 0, to, to + 1, src->name, src->combiBank, src->combiPage, src->combiSlot))) return false;
    if (engine.nativeActiveListEntry(0, 0, 0) == to) engine.nativeSetActiveListEntry(0, 0, 0, -1);
    return persistLiveListEdits();
}

bool SamplerAppController::moveListEntryTo(int from, int to) {
    lastFailure_.clear();
    const auto all = listItems(0, 0, 0);
    const ListItem* srcPtr = (from >= 0 && from < static_cast<int>(all.size())) ? &all[static_cast<std::size_t>(from)] : nullptr;
    if (isEmptyListItem(srcPtr)) return fail("LIST position is empty");
    if (to < 0 || to >= 200 || to == from) return fail("LIST target position is invalid");
    const ListItem src = *srcPtr;
    const int active = engine.nativeActiveListEntry(0, 0, 0);
    if (!ensureListLength(to + 1)) return false;
    if (!nativeResult(engine.nativeSetListEntry(0, 0, 0, to, to + 1, src.name, src.combiBank, src.combiPage, src.combiSlot))) return false;
    if (!nativeResult(engine.nativeSetListEntry(0, 0, 0, from, from + 1, "-", 0, 0, 0))) return false;
    if (active == from) engine.nativeSetActiveListEntry(0, 0, 0, to);
    else if (active == to) engine.nativeSetActiveListEntry(0, 0, 0, -1);
    if (!trimListTail()) return false;
    return persistLiveListEdits();
}

bool SamplerAppController::moveLiveListEntry(int fromIndex, int toIndex) {
    const auto items = listItems(0, 0, 0);
    const int n = static_cast<int>(items.size());
    if (fromIndex < 0 || fromIndex >= n || toIndex < 0 || toIndex >= n) return fail("LIST move position is invalid");
    if (fromIndex == toIndex) return true;
    if (!nativeResult(engine.nativeMoveListEntry(0, 0, 0, fromIndex, toIndex))) return false;
    if (!renumberLiveList()) return false;
    return persistLiveListEdits();
}

bool SamplerAppController::copyLiveListEntry(const ListItem& item, int insertIndex) {
    const auto current = listItems(0, 0, 0);
    if (current.size() >= 200U) return fail("LIST is full");
    const int at = std::clamp(insertIndex, 0, static_cast<int>(current.size()));
    if (!nativeResult(engine.nativeInsertListEntry(0, 0, 0, at, at + 1, item.name, item.combiBank, item.combiPage, item.combiSlot))) return false;
    if (!renumberLiveList()) return false;
    return persistLiveListEdits();
}

// One logical LIST edit, one persistence operation. A failed save restores the
// in-memory order, active position and favourites without recalling any audio.
bool SamplerAppController::commitLiveList(const std::vector<ListItem>& items, int active, const std::set<int>& favourites) {
    if (items.size() > 200U) return fail("LIST is full: 200 positions");
    const auto before = listItems(0, 0, 0);
    const int beforeActive = engine.nativeActiveListEntry(0, 0, 0);
    const auto beforeFavourites = listFavourites();
    const auto write = [this](const std::vector<ListItem>& rows) {
        std::vector<int> numbers, addresses;
        std::vector<std::string> names;
        numbers.reserve(rows.size()); names.reserve(rows.size()); addresses.reserve(rows.size() * 3U);
        for (std::size_t i = 0U; i < rows.size(); ++i) {
            const auto& row = rows[i];
            numbers.push_back(static_cast<int>(i) + 1);
            names.push_back(isEmptyListItem(row) ? std::string("-") : row.name);
            addresses.insert(addresses.end(), {row.combiBank, row.combiPage, row.combiSlot});
        }
        return engine.nativeWriteList(0, 0, 0, "LIVE", numbers, names, addresses);
    };
    if (!nativeResult(write(items))) return false;
    engine.nativeSetActiveListEntry(0, 0, 0, active);
    saveListFavourites(favourites);
    if (persistLiveListEdits()) return true;
    const std::string error = lastFailure_;
    const bool restored = write(before);
    engine.nativeSetActiveListEntry(0, 0, 0, beforeActive);
    saveListFavourites(beforeFavourites);
    return fail(error + (restored ? std::string() : " (LIST rollback failed)"));
}

bool SamplerAppController::captureListClipboard(const std::vector<int>& positions, bool cut, ListClipboard& clipboard) {
    lastFailure_.clear();
    const auto current = listItems(0, 0, 0);
    const auto favourites = listFavourites();
    const std::set<int> selected(positions.begin(), positions.end());
    if (selected.empty()) return fail("Choose at least one blend");
    ListClipboard next;
    next.cut = cut;
    next.bankFile = currentBankFile();
    for (const int index : selected) {
        if (index < 0 || index >= static_cast<int>(current.size()) || isEmptyListItem(current[static_cast<std::size_t>(index)]))
            return fail("A selected LIST position is empty");
        const auto& item = current[static_cast<std::size_t>(index)];
        auto combi = engine.nativeStoredCombi(item.combiBank, item.combiPage, item.combiSlot);
        if (!combi) return fail("A selected blend is no longer available");
        next.items.push_back(item);
        next.combis.push_back(std::move(combi));
        next.sources.push_back(index);
        next.favourites.push_back(favourites.count(index) != 0U);
    }
    clipboard = std::move(next);
    return true;
}

bool SamplerAppController::pasteListClipboard(const ListClipboard& clipboard, int destination, int& first) {
    first = -1;
    lastFailure_.clear();
    const std::size_t count = clipboard.items.size();
    if (count == 0U || count > 200U || clipboard.sources.size() != count || clipboard.combis.size() != count || clipboard.favourites.size() != count)
        return fail("The clipboard is empty or incomplete");
    if (destination < 0 || destination > 200 - static_cast<int>(count)) return fail("The block does not fit at this LIST position");
    if (clipboard.bankFile != currentBankFile()) return fail("The sound bank changed. Copy the blends again");
    const auto current = listItems(0, 0, 0);
    const auto favourites = listFavourites();
    const int active = engine.nativeActiveListEntry(0, 0, 0);
    const std::set<int> selected(clipboard.sources.begin(), clipboard.sources.end());
    if (clipboard.cut && selected.size() != count) return fail("The move clipboard contains duplicate positions");
    if (clipboard.cut) {
        for (std::size_t k = 0U; k < count; ++k) {
            const int src = clipboard.sources[k];
            if (src < 0 || src >= static_cast<int>(current.size())) return fail("A cut position changed. Select the blends again");
            const auto& a = current[static_cast<std::size_t>(src)];
            const auto& b = clipboard.items[k];
            if (a.name != b.name || a.combiBank != b.combiBank || a.combiPage != b.combiPage || a.combiSlot != b.combiSlot)
                return fail("A cut position changed. Select the blends again");
        }
    }
    struct Node { ListItem item; int origin{-1}; bool favourite{false}; };
    std::vector<Node> order;
    order.reserve(200U);
    for (int i = 0; i < 200; ++i) {
        if (clipboard.cut && selected.count(i) != 0U) continue;
        const ListItem item = i < static_cast<int>(current.size()) ? current[static_cast<std::size_t>(i)] : ListItem{};
        order.push_back({item, i, favourites.count(i) != 0U});
    }
    while (order.size() < 200U) order.push_back({ListItem{}, -1, false});
    // Inserting shifts occupied entries, consuming free positions at/after the
    // chosen destination. No existing blend is overwritten or silently lost.
    std::size_t freeCount = 0U;
    for (std::size_t i = static_cast<std::size_t>(destination); i < order.size(); ++i)
        if (isEmptyListItem(order[i].item)) ++freeCount;
    if (freeCount < count) return fail("Not enough free positions after this destination. Choose an earlier position");
    for (std::size_t i = static_cast<std::size_t>(destination), removed = 0U; removed < count;) {
        if (isEmptyListItem(order[i].item)) { order.erase(order.begin() + static_cast<std::ptrdiff_t>(i)); ++removed; }
        else ++i;
    }
    std::vector<int> slots;
    if (!clipboard.cut) {
        for (int s = 1; s <= 500 && slots.size() < count; ++s) if (!engine.nativeCombiSlotOccupied(0, 0, s)) slots.push_back(s);
        if (slots.size() < count) return fail("No free COMBI position for all copied blends");
        for (const auto& combi : clipboard.combis) if (!combi) return fail("The copied blend is unavailable");
    }
    std::vector<Node> block;
    block.reserve(count);
    for (std::size_t k = 0U; k < count; ++k) {
        ListItem item = clipboard.items[k];
        if (!clipboard.cut) { item.combiBank = 0; item.combiPage = 0; item.combiSlot = slots[k]; }
        block.push_back({item, clipboard.cut ? clipboard.sources[k] : -1, clipboard.favourites[k]});
    }
    order.insert(order.begin() + destination, block.begin(), block.end());
    while (!order.empty() && isEmptyListItem(order.back().item)) order.pop_back();
    std::vector<ListItem> result;
    std::set<int> resultFavourites;
    int resultActive = -1;
    for (std::size_t k = 0U; k < order.size(); ++k) {
        auto item = order[k].item;
        item.number = static_cast<int>(k) + 1;
        result.push_back(std::move(item));
        if (order[k].favourite && !isEmptyListItem(order[k].item)) resultFavourites.insert(static_cast<int>(k));
        if (active >= 0 && order[k].origin == active) resultActive = static_cast<int>(k);
    }
    std::vector<int> created;
    const auto rollbackCombis = [this, &created]() { for (const int slot : created) engine.nativeClearCombi(0, 0, slot); };
    for (std::size_t k = 0U; k < slots.size(); ++k) {
        if (!nativeResult(engine.nativeStoreCombiSnapshot(0, 0, slots[k], *clipboard.combis[k]))) { rollbackCombis(); return false; }
        created.push_back(slots[k]);
    }
    if (!commitLiveList(result, resultActive, resultFavourites)) { rollbackCombis(); return false; }
    first = destination;
    return true;
}

bool SamplerAppController::writeCombiSlot(int slot, const std::string& name) {
    lastFailure_.clear();
    if (slot < 1 || slot > 500) return fail("COMBI position must be 1..500");
    const std::string finalName = orBlank(trimmed(name), combiName());
    if (!nativeResult(engine.nativeWriteCombi(0, 0, slot, finalName))) return false;
    if (!nativeResult(engine.nativeActivateCombi(0, 0, slot))) return false;
    return saveUserState();
}

int SamplerAppController::firstFreeCombiSlot() {
    for (int slot = 1; slot <= 500; ++slot) {
        if (!engine.nativeCombiSlotOccupied(0, 0, slot)) return slot;
    }
    return 500;
}

int SamplerAppController::writeCombiToList(int position, const std::string& name) {
    lastFailure_.clear();
    if (position < 0 || position >= 200) { fail("LIST position is invalid"); return -1; }
    const int target = position;
    if (!ensureListLength(target + 1)) { trimListTail(); return -1; }
    const auto items = listItems(0, 0, 0);
    const std::string finalName = orBlank(trimmed(name), combiName());
    const ListItem* old = nullptr;
    if (target < static_cast<int>(items.size()) && !isEmptyListItem(items[static_cast<std::size_t>(target)])) old = &items[static_cast<std::size_t>(target)];
    auto usedElsewhere = [&](int slot) {
        for (std::size_t k = 0U; k < items.size(); ++k) {
            if (static_cast<int>(k) != target && items[k].combiBank == 0 && items[k].combiPage == 0 && items[k].combiSlot == slot) return true;
        }
        return false;
    };
    int slot = -1;
    if (old != nullptr && old->combiBank == 0 && old->combiPage == 0 && old->combiSlot >= 1 && old->combiSlot <= 500 && !usedElsewhere(old->combiSlot)) {
        slot = old->combiSlot;
    } else {
        for (int s = 1; s <= 500; ++s) {
            if (!engine.nativeCombiSlotOccupied(0, 0, s)) { slot = s; break; }
        }
    }
    if (slot < 1 || slot > 500) { fail("No free COMBI position (1..500)"); trimListTail(); return -1; }
    if (!nativeResult(engine.nativeWriteCombi(0, 0, slot, finalName))) { trimListTail(); return -1; }
    if (!nativeResult(engine.nativeSetListEntry(0, 0, 0, target, target + 1, finalName, 0, 0, slot))) { trimListTail(); return -1; }
    if (!nativeResult(engine.nativeActivateListEntry(0, 0, 0, target))) return -1;
    if (!persistLiveListEdits()) return -1;
    return target;
}

bool SamplerAppController::activateCombiAddress(int bank, int page, int slot) {
    const bool ok = nativeResult(engine.nativeActivateCombi(bank, page, slot));
    if (ok) syncScaleFromEngine();
    return ok;
}

bool SamplerAppController::addCombiToList(int combiSlot, const std::string& name) {
    if (combiSlot < 1 || combiSlot > 500) return fail("COMBI position must be 1..500");
    const auto current = listItems(0, 0, 0);
    if (current.size() >= 200U) return fail("LIST is full");
    const std::string finalName = orBlank(trimmed(name), combiName());
    int maxNumber = 0;
    for (const auto& it : current) maxNumber = std::max(maxNumber, it.number);
    const int nextNumber = maxNumber + 1;
    bool changed;
    if (current.empty()) {
        changed = nativeResult(engine.nativeWriteList(0, 0, 0, "LIVE", {nextNumber}, {finalName}, {0, 0, combiSlot}));
    } else {
        changed = nativeResult(engine.nativeInsertListEntry(0, 0, 0, static_cast<int>(current.size()), nextNumber, finalName, 0, 0, combiSlot));
    }
    if (!changed) return false;
    return saveUserState();
}

std::vector<std::pair<int, std::string>> SamplerAppController::sampleCatalog() {
    const auto ids = engine.nativeSampleIds();
    const auto names = engine.nativeSampleNames();
    const std::size_t count = std::min(ids.size(), names.size());
    std::vector<std::pair<int, std::string>> out;
    for (std::size_t i = 0U; i < count; ++i) out.emplace_back(ids[i], names[i]);
    return out;
}

std::optional<std::string> SamplerAppController::sampleAsWave(int id, std::vector<float>& points) {
    if (!engine.nativeSampleWave(id, points)) return std::string("The sample is silent or missing.");
    return std::nullopt;
}

std::vector<std::pair<int, std::string>> SamplerAppController::multisampleCatalog() {
    const auto ids = engine.nativeMultisampleIds();
    const auto names = engine.nativeMultisampleNames();
    const std::size_t count = std::min(ids.size(), names.size());
    std::vector<std::pair<int, std::string>> out;
    for (std::size_t i = 0U; i < count; ++i) out.emplace_back(ids[i], names[i]);
    return out;
}

std::vector<std::pair<int, std::string>> SamplerAppController::combiCatalog() {
    const auto slots = engine.nativeCombiCatalogSlots();
    const auto names = engine.nativeCombiCatalogNames();
    const std::size_t count = std::min(slots.size(), names.size());
    std::vector<std::pair<int, std::string>> out;
    for (std::size_t i = 0U; i < count; ++i) out.emplace_back(slots[i], names[i]);
    return out;
}

std::vector<SamplerAppController::SoundItem> SamplerAppController::soundCatalog() {
    const auto addresses = engine.nativeSoundCatalogAddresses();
    const auto names = engine.nativeSoundCatalogNames();
    const std::size_t count = std::min(names.size(), addresses.size() / 3U);
    std::vector<SoundItem> out;
    out.reserve(count);
    for (std::size_t i = 0U; i < count; ++i) {
        const std::size_t base = i * 3U;
        out.push_back(SoundItem{addresses[base], addresses[base + 1U], addresses[base + 2U], names[i]});
    }
    return out;
}

// ---------------------------------------------------------------- bank info (INFO in SETTINGS)
std::optional<SamplerAppController::BankInfo> SamplerAppController::bankInfo() {
    const std::string f = bankFile();
    if (f.empty()) return std::nullopt;
    std::vector<std::string> lines;
    for (const auto& l : splitChar(engine.nativeBankInfo(files::absolute(f)), '\n')) if (!isBlank(l)) lines.push_back(l);
    if (lines.empty()) return std::nullopt;
    const auto head = splitChar(lines[0], '\t');
    if (head.size() < 5U || head[0] != "TOTAL") return std::nullopt;
    BankInfo info;
    for (std::size_t i = 1U; i < lines.size(); ++i) {
        const auto c = splitChar(lines[i], '\t');
        if (c.size() < 4U) continue;
        const auto slot = toIntOrNull(c[0]);
        if (!slot) continue;
        info.list.push_back(BankSound{*slot, c[1], toIntOrNull(c[2]).value_or(0), toLongOrNull(c[3]).value_or(0)});
    }
    std::stable_sort(info.list.begin(), info.list.end(), [](const BankSound& a, const BankSound& b) { return a.slot < b.slot; });
    info.path = files::absolute(f);
    info.sounds = toIntOrNull(head[1]).value_or(0);
    info.samples = toIntOrNull(head[2]).value_or(0);
    info.audioBytes = toLongOrNull(head[3]).value_or(0);
    info.fileBytes = toLongOrNull(head[4]).value_or(0);
    return info;
}

std::optional<std::string> SamplerAppController::deleteBankSounds(const std::vector<int>& slots) {
    const std::string f = bankFile();
    if (f.empty()) return std::string("SILVETON_BANK.sv was not found");
    const std::string err = engine.nativeRemoveBankSounds(files::absolute(f), slots);
    if (!err.empty()) return err;
    if (!engine.nativeLoadSvBank(files::absolute(f))) return orBlank(engine.nativeLastTextError(), "The bank did not load again");
    addExtraBankFiles();   // SILVETON_SEND_V1
    if (!syncScaleFromEngine()) applyScale(false);
    applyTerca();
    saveUserState();
    return std::nullopt;
}

// SOLO session. Keep the previous directory name so existing sessions are found.
std::string SamplerAppController::soloFolder() { return files::join(bankDir(), "SILVETON_SUSE"); }
void SamplerAppController::soloSaveSession() { saveUserState(); }
void SamplerAppController::soloRestoreSession() {
    namespace sv=silveton::sampler;
    std::string content;if(!files::readText(files::join(soloFolder(),"SESSION.SOLO"),content)||content.size()>250000)return;
    std::istringstream in(content);std::string tag;int version=0;in>>tag>>version;
    if(tag!="SILVETON_SOLO_SESSION"||(version!=1&&version!=2))return;
    struct Saved {int u;UpperState st;std::array<float,4> play;std::vector<float> row;};
    std::vector<Saved> saved;
    std::string line;std::getline(in,line);int rows=0;
    while(std::getline(in,line)){
        if(line.find_first_not_of(" \t\r")==std::string::npos)continue;
        if(++rows>8)return;
        std::istringstream row(line);Saved v;auto& st=v.st;
        if(!(row>>v.u>>st.enabled>>st.solo>>st.mute>>st.levelDb>>st.pan>>st.keyLow>>st.keyHigh>>st.octave>>st.transpose>>st.fineCents>>st.pitchBendRange>>st.portamentoSec))return;
        for(auto& x:v.play)if(!(row>>x)||!std::isfinite(x))return;
        sv::EngineParams ep;ep.type=sv::EngineType::Solo;std::size_t count=0;float x=0;
        while(row>>x){if(!std::isfinite(x)||count>=960)return;if(count<ep.p.size())ep.p[count]=x;++count;}
        if(!row.eof()||(count!=sv::kEngineParamCount&&(version!=1||count!=960)))return;
        if(v.u<7||v.u>14||!std::isfinite(st.levelDb)||!std::isfinite(st.pan)||!std::isfinite(st.fineCents)||!std::isfinite(st.portamentoSec))return;
        sv::engineSanitizeLoaded(ep);if(ep.type!=sv::EngineType::Solo)continue;
        v.row.resize(sv::kEngineParamCount+1U);v.row[0]=static_cast<float>(sv::EngineType::Solo);
        std::copy(ep.p.begin(),ep.p.end(),v.row.begin()+1);
        saved.push_back(std::move(v));
    }
    for(const auto& v:saved){
        const auto now=upperEngineParams(v.u);if(!now.empty()&&now[0]!=0)continue;
        if(!engine.nativeSetUpperEngineBlock(v.u,0,v.row))continue;
        const auto& st=v.st;
        engine.nativeUpdateUpperMain(v.u,st.enabled,st.solo,st.mute,st.levelDb,st.pan,st.keyLow,st.keyHigh,2);
        engine.nativeUpdateUpperTune(v.u,st.octave,st.transpose,st.fineCents,st.pitchBendRange,st.portamentoSec);
        for(int i=0;i<4;++i)engine.nativeSetUpperParam(v.u,42+i,v.play[static_cast<std::size_t>(i)]);
    }
}

// ---------------------------------------------------------------- sets (SAVE AS / LOAD)
// SILVETON_SET_NEXT_TO_BANK_V1 (Цветомир, 04.11.2026): a set is a file of its own NEXT TO the bank (not in a subfolder, not inside the bank).
// The two files the sampler keeps for itself in that folder are never shown as sets and a set cannot take their names.
std::string SamplerAppController::setsDir() { return bankDir(); }
static bool reservedSetName(const std::string& base) { return base == "SILVETON_BLENDS" || base == "SILVETON_USER_STATE"; }
std::string SamplerAppController::setsFolders() const { return const_cast<SamplerAppController*>(this)->setsDir(); }

std::string SamplerAppController::setFileName(const std::string& name) const {
    // trim, every letter that is not A-Z a-z 0-9 space _ - or Cyrillic becomes "_", at most 40 letters, trim again, empty = "SET"
    const std::string t = trimmed(name);
    std::string out;
    int count = 0;
    std::size_t i = 0U;
    while (i < t.size() && count < 40) {
        const auto c = static_cast<unsigned char>(t[i]);
        std::size_t len = 1U;
        std::uint32_t cp = c;
        if (c >= 0xF0U) { len = 4U; } else if (c >= 0xE0U) { len = 3U; } else if (c >= 0xC0U) { len = 2U; }
        if (len == 2U && i + 1U < t.size()) cp = ((c & 0x1FU) << 6U) | (static_cast<unsigned char>(t[i + 1U]) & 0x3FU);
        const bool ok = len == 1U ? ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '-')
                                  : (len == 2U && cp >= 0x0400U && cp <= 0x04FFU);
        if (ok) out += t.substr(i, len); else out += "_";
        i += len;
        ++count;
    }
    out = trimmed(out);
    return out.empty() ? std::string("SET") : out;
}

std::vector<std::string> SamplerAppController::savedSets() {
    std::vector<std::pair<long long, std::string>> all;
    const std::string dir = setsDir();
    for (const auto& n : files::listNames(dir)) {
        if (!endsWith(n, ".SVSET")) continue;
        const std::string full = files::join(dir, n);
        if (!setPresent(full)) continue;
        if (reservedSetName(n.substr(0U, n.size() - 6U))) continue;
        all.emplace_back(files::lastModifiedMs(full), n.substr(0U, n.size() - 6U));
    }
    std::stable_sort(all.begin(), all.end(), [](const auto& a, const auto& b) { return a.first > b.first; });
    std::vector<std::string> out;
    for (const auto& kv : all) if (std::find(out.begin(), out.end(), kv.second) == out.end()) out.push_back(kv.second);
    return out;
}

std::string SamplerAppController::setFile(const std::string& name) {
    if (reservedSetName(setFileName(name))) return std::string();
    const std::string f = files::join(setsDir(), setFileName(name) + ".SVSET");
    return setPresent(f) ? f : std::string();
}

bool SamplerAppController::setExists(const std::string& name) { return !setFile(name).empty(); }

std::string SamplerAppController::tqText() const {
    return "terca_uppers=" + std::to_string(tercaUppers_) + "\nscale_uppers=" + std::to_string(scaleUppers_) +
        "\nterca_root=" + std::to_string(tercaRoot_) + "\nterca_cell=" + std::to_string(tercaCell_) +
        "\nscale_mask=" + std::to_string(scaleMask_) + "\nterca_master=" + (tercaMaster_ ? "true" : "false") +
        "\nscale_master=" + (scaleMaster_ ? "true" : "false") +
        "\nscale_cents=" + [this] { std::string o; for (std::size_t i = 0U; i < scaleCentsNow_.size(); ++i) { if (i != 0U) o += ","; o += std::to_string(scaleCentsNow_[i]); } return o; }() +
        "\nscale_name=" + scaleName_ + "\nscale_tonic=" + std::to_string(scaleTonicValue_) + "\nscale_user=" + userScalesText() +
        "\nporta_balance=" + std::to_string(portaBalanceValue_) +
        "\nporta_near=" + std::to_string(portaNearValue_) +
        "\nvoice_ceiling=" + std::to_string(voiceCeilingValue_) + "\n";
}

void SamplerAppController::applyTqFile(const std::string& tq) {
    std::string text;
    if (files::isFile(tq) && files::readText(tq, text)) applyTqText(text);
}

void SamplerAppController::applyTqText(const std::string& text) {
    {
        std::map<std::string, std::string> m;
        for (const auto& l : splitChar(text, '\n')) {
            const std::size_t eq = l.find('=');
            if (eq == std::string::npos) continue;
            m[l.substr(0U, eq)] = l.substr(eq + 1U);
        }
        auto num = [&](const char* key) -> std::optional<int> {
            const auto it = m.find(key);
            return it == m.end() ? std::nullopt : toIntOrNull(it->second);
        };
        if (const auto v = num("terca_uppers")) tercaUppers_ = *v & 0x7FFF;
        if (const auto v = num("scale_uppers")) scaleUppers_ = *v & 0x7FFF;
        if (const auto v = num("terca_root")) tercaRoot_ = *v;
        if (const auto v = num("terca_cell")) tercaCell_ = *v;
        if (const auto v = num("scale_mask")) scaleMask_ = *v & 0xFFF;
        // Older SETs have no such keys: retain their existing device settings.
        if (const auto v = num("porta_balance")) setPortaBalance(*v);
        if (const auto v = num("porta_near")) setPortaNear(*v);
        if (const auto v = num("voice_ceiling")) setVoiceCeiling(*v);
        if (m.count("terca_master") != 0U) tercaMaster_ = m["terca_master"] == "true";
        if (m.count("scale_master") != 0U) scaleMaster_ = m["scale_master"] == "true";
        if (m.count("scale_cents") != 0U) {   // SILVETON_SCALE_TUNING_V1
            std::vector<float> v;
            for (const auto& part : splitChar(m["scale_cents"], ',')) { try { v.push_back(std::stof(part)); } catch (...) { v.clear(); break; } }
            if (v.size() == 12U) { for (std::size_t i = 0U; i < 12U; ++i) scaleCentsNow_[i] = std::clamp(v[i], -100.0F, 100.0F); }
        } else {
            for (int pc = 0; pc < 12; ++pc) scaleCentsNow_[static_cast<std::size_t>(pc)] = (scaleMask_ & (1 << pc)) != 0 ? -50.0F : 0.0F;
        }
        if (m.count("scale_name") != 0U) scaleName_ = m["scale_name"];
        if (const auto v = num("scale_tonic")) scaleTonicValue_ = std::clamp(*v, 0, 11);
        if (m.count("scale_user") != 0U) loadUserScales(m["scale_user"]);
        saveTercaScale();
    }
}

std::optional<std::string> SamplerAppController::saveSetAs(const std::string& name) {
    const std::string base = setFileName(name);
    if (reservedSetName(base)) return std::string("This name is used by the sampler. Choose another name");
    if (!saveUserState()) return orBlank(engine.nativeLastTextError(), "Saving failed");
    const std::string dir = setsDir();
    std::string lastError;
    bool saved = false;
    if (!files::isDirectory(dir) && !files::makeDirectories(dir)) {
        lastError = "No access to " + dir;
    } else if (!copySet(userStateFile(), files::join(dir, base + ".SVSET"))) {   // SILVETON_SET_DIR_FIX_V1
        lastError = "No access to " + dir;
    } else {
        saved = true;
    }
    if (saved) return std::nullopt;
    return lastError.empty() ? std::string("Saving failed") : lastError;
}

std::optional<std::string> SamplerAppController::loadSavedSet(const std::string& name) {
    const std::string file = setFile(name);
    if (file.empty()) return std::string("The file is missing");
    if (!nativeResult(engine.nativeReplaceUserPerformanceState(file))) return orBlank(engine.nativeLastTextError(), "Loading failed");
    const std::string embedded = engine.nativeLastLoadedSetExtraText();   // SILVETON_SET_ONE_FILE_V1
    if (!embedded.empty()) applyTqText(embedded);
    else applyTqFile(files::join(files::parentOf(file), setFileName(name) + ".TQ"));   // a set saved before: the side file
    if (!syncScaleFromEngine()) applyScale(false);
    applyTerca();
    if (!saveUserState()) return orBlank(engine.nativeLastTextError(), "SET loaded, but saving the current state failed");
    return std::nullopt;
}

// ---------------------------------------------------------------- SILVETON_SEND_V1 / SILVETON_PROJECT_V1 (the Manager's copy only)
std::optional<std::string> SamplerAppController::addSoundsFromBank(const std::string& path) {
    if (!nativeResult(engine.nativeAddBankSounds(path))) return orBlank(engine.nativeLastTextError(), "The sounds did not get into the sampler");
    ++bankSerial_;   // the screens read the sounds again
    return std::nullopt;
}

std::string SamplerAppController::currentBankFile() {
    const std::string f = bankFile();
    return f.empty() ? f : files::absolute(f);
}

std::optional<std::string> SamplerAppController::saveProjectState(const std::string& dir) {
    if (!files::isDirectory(dir) && !files::makeDirectories(dir)) return "No access to " + dir;
    engine.nativeSetSetExtraText(tqText());
    if (!nativeResult(engine.nativeSaveUserPerformanceState(files::join(dir, "SAMPLER.SVSET")))) return orBlank(engine.nativeLastTextError(), "The blends were not saved");
    if (!files::writeText(files::join(dir, "SAMPLER.TQ"), tqText())) return std::string("Saving failed");
    if (!nativeResult(engine.nativeSaveOpenCombi(files::join(dir, "OPEN-COMBI.SVSET")))) return orBlank(engine.nativeLastTextError(), "The open COMBI was not saved");
    return std::nullopt;
}

std::optional<std::string> SamplerAppController::loadProjectState(const std::string& dir) {
    const std::string state = files::join(dir, "SAMPLER.SVSET");
    if (setPresent(state) && !nativeResult(engine.nativeReplaceUserPerformanceState(state))) return orBlank(engine.nativeLastTextError(), "The blends were not loaded");
    applyTqFile(files::join(dir, "SAMPLER.TQ"));
    const std::string open = files::join(dir, "OPEN-COMBI.SVSET");
    if (setPresent(open)) (void)nativeResult(engine.nativeLoadOpenCombi(open));
    if (!syncScaleFromEngine()) applyScale(false);
    applyTerca();
    saveUserState();   // the LIST of the project is the LIST next to the bank from now on
    ++bankSerial_;
    return std::nullopt;
}

void SamplerAppController::setExtraBankFiles(const std::vector<std::string>& files) {
    std::lock_guard<std::mutex> lock(extraMutex_);
    extraBankFiles_ = files;
}

void SamplerAppController::addExtraBankFiles() {
    std::vector<std::string> list;
    std::vector<int> removed;
    {
        std::lock_guard<std::mutex> lock(extraMutex_);
        list = extraBankFiles_;
        removed = removedSounds_;
    }
    for (const auto& f : list) {
        if (!files::isFile(f)) { status("The sent sounds are missing: " + f); continue; }
        if (!nativeResult(engine.nativeAddBankSounds(f))) status(orBlank(engine.nativeLastTextError(), "The sent sounds did not get in: " + f));
    }
    if (!removed.empty()) (void)engine.nativeRemoveSoundPlaces(removed);   // SILVETON_LIST_DELETE_SOUNDS_V1
}

// ---------------------------------------------------------------- SILVETON_LIST_DELETE_SOUNDS_V1
void SamplerAppController::setRemovedSounds(const std::vector<int>& places) {
    std::lock_guard<std::mutex> lock(extraMutex_);
    removedSounds_ = places;
}

void SamplerAppController::setSoundsRemovedHandler(std::function<void(const std::vector<int>&)> handler) { soundsRemoved_ = std::move(handler); }

std::vector<std::pair<int, std::string>> SamplerAppController::soundsOnlyInListEntry(int index) {
    const auto items = listItems(0, 0, 0);
    if (index < 0 || index >= static_cast<int>(items.size()) || isEmptyListItem(items[static_cast<std::size_t>(index)])) return {};
    const ListItem& item = items[static_cast<std::size_t>(index)];
    for (std::size_t k = 0U; k < items.size(); ++k) {   // another LIST position has the same blend: it stays, so do its sounds
        if (static_cast<int>(k) == index) continue;
        if (items[k].combiBank == item.combiBank && items[k].combiPage == item.combiPage && items[k].combiSlot == item.combiSlot) return {};
    }
    std::vector<std::string> sets;
    for (const auto& name : savedSets()) {
        const std::string f = setFile(name);
        if (!f.empty()) sets.push_back(f);
    }
    const bool countOpen = engine.nativeActiveListEntry(0, 0, 0) != index;   // the open COMBI is this blend: it does not keep them
    std::vector<std::array<int, 3>> listed;   // SILVETON_LIST_DELETE_GHOST_V1: only the blends that are on the LIST keep a sound alive
    for (std::size_t k = 0U; k < items.size(); ++k) {
        if (static_cast<int>(k) == index || isEmptyListItem(items[k])) continue;
        listed.push_back({items[k].combiBank, items[k].combiPage, items[k].combiSlot});
    }
    const std::vector<int> places = engine.nativeSoundsOnlyInCombi(item.combiBank, item.combiPage, item.combiSlot, countOpen, sets, listed);
    std::vector<std::pair<int, std::string>> out;
    const auto catalog = soundCatalog();
    for (const int place : places) {
        for (const auto& s : catalog) {
            if (s.bank == 0 && s.page == 0 && s.slot == place) { out.emplace_back(place, s.name); break; }
        }
    }
    return out;
}

std::optional<std::string> SamplerAppController::deleteListEntryWithSounds(int index, const std::vector<int>& places) {
    const auto items = listItems(0, 0, 0);
    if (index < 0 || index >= static_cast<int>(items.size()) || isEmptyListItem(items[static_cast<std::size_t>(index)])) return std::string("LIST position is empty");
    const ListItem item = items[static_cast<std::size_t>(index)];
    if (!deleteLiveListEntry(index)) return orBlank(engine.nativeLastTextError(), "The LIST was not saved");
    bool shared = false;
    for (std::size_t k = 0U; k < items.size(); ++k) {
        if (static_cast<int>(k) != index && items[k].combiBank == item.combiBank && items[k].combiPage == item.combiPage && items[k].combiSlot == item.combiSlot) shared = true;
    }
    if (!shared) (void)engine.nativeClearCombi(item.combiBank, item.combiPage, item.combiSlot);   // the blend goes too (its sounds are gone)
    return deleteSounds(places);
}

// SILVETON_MULTI_DELETE_V1
std::optional<std::string> SamplerAppController::deleteSounds(const std::vector<int>& places) {
    std::vector<int> valid;
    for (const int p : places) if (p >= 1 && p <= 500 && std::find(valid.begin(), valid.end(), p) == valid.end()) valid.push_back(p);
    if (!valid.empty()) {
        (void)engine.nativeRemoveSoundPlaces(valid);
        std::lock_guard<std::mutex> lock(extraMutex_);
        for (const int p : valid) if (std::find(removedSounds_.begin(), removedSounds_.end(), p) == removedSounds_.end()) removedSounds_.push_back(p);
    }
    const bool saved = saveUserState();
    ++bankSerial_;   // the screens read the sounds again
    if (soundsRemoved_ && !valid.empty()) soundsRemoved_(valid);
    if (!saved) return orBlank(engine.nativeLastTextError(), "Saving failed");
    return std::nullopt;
}

std::optional<std::string> SamplerAppController::pasteSoundsToList(const std::vector<std::pair<int, std::string>>& sounds, int start, int& first, int& count) {
    first = -1;
    count = 0;
    constexpr int kListSize = 200;
    std::optional<std::string> problem;
    int row = std::clamp(start, 0, kListSize - 1);
    for (const auto& sound : sounds) {
        const auto items = listItems(0, 0, 0);
        while (row < kListSize && row < static_cast<int>(items.size()) && !isEmptyListItem(items[static_cast<std::size_t>(row)])) ++row;
        if (row >= kListSize) { problem = std::string("THE LIST IS FULL"); break; }
        int slot = -1;
        for (int s = 1; s <= 500; ++s) {
            if (!engine.nativeCombiSlotOccupied(0, 0, s)) { slot = s; break; }
        }
        if (slot < 0) { problem = std::string("No room for a new blend (1…500)"); break; }
        if (!engine.nativeWriteSoundCombi(slot, sound.first, sound.second)) { problem = orBlank(engine.nativeLastTextError(), "The sound “" + sound.second + "” is not in the sampler"); break; }
        if (!ensureListLength(row + 1) || !engine.nativeSetListEntry(0, 0, 0, row, row + 1, sound.second, 0, 0, slot)) {
            (void)engine.nativeClearCombi(0, 0, slot);
            problem = orBlank(engine.nativeLastTextError(), "The LIST was not saved");
            break;
        }
        if (first < 0) first = row;
        ++count;
        ++row;
    }
    trimListTail();
    if (count > 0) {
        if (!persistLiveListEdits() && !problem) problem = orBlank(engine.nativeLastTextError(), "Saving failed");
        (void)engine.nativeActivateListEntry(0, 0, 0, first);   // the first new BLEND is open, as after a click on it
        ++bankSerial_;   // the screens read the LIST and the Uppers again
    }
    return problem;
}

void SamplerAppController::waitForBankLoad() {
    while (bankLoading_.load()) std::this_thread::sleep_for(std::chrono::milliseconds(20));
}

// ---------------------------------------------------------------- SILVETON_PARAMS_V1
bool SamplerAppController::setUpperParam(int upper, int id, float value) { return nativeResult(engine.nativeSetUpperParam(upper, id, value)); }
std::vector<float> SamplerAppController::upperParams(int upper) { return engine.nativeUpperParams(upper); }
bool SamplerAppController::setLayerParam(int upper, int layer, int id, float value) { return nativeResult(engine.nativeSetLayerParam(upper, layer, id, value)); }
bool SamplerAppController::setLayerSound(int upper, int layer, int slot) { return nativeResult(engine.nativeSetLayerSound(upper, layer, slot)); }
std::vector<float> SamplerAppController::layerParams(int upper, int layer) { return engine.nativeLayerParams(upper, layer); }
std::string SamplerAppController::layerName(int upper, int layer) { return engine.nativeLayerName(upper, layer); }
std::vector<int> SamplerAppController::soundVelocityZones(int upper, int sound) { return engine.nativeSoundVelocityZones(upper, sound); }   // SILVETON_OFS_V1
int SamplerAppController::upperSoundSlot(int upper) { return engine.nativeUpperSoundSlot(upper); }
bool SamplerAppController::setFxParam(int unit, int id, float value) { return nativeResult(engine.nativeSetFxParam(unit, id, value)); }
std::vector<float> SamplerAppController::fxParams(int unit) { return engine.nativeFxParams(unit); }
std::vector<float> SamplerAppController::analyzerFrame(int upper, bool afterEq) { return engine.nativeAnalyzerFrame(upper, afterEq); }
bool SamplerAppController::setSoundSynthParam(int upper, int sound, int id, float value) { return nativeResult(engine.nativeSetSoundSynthParam(upper, sound, id, value)); }
bool SamplerAppController::setUpperEngineParam(int upper, int id, float value) { return nativeResult(engine.nativeSetUpperEngineParam(upper, id, value)); }   // SILVETON_ENGINES_V1




bool SamplerAppController::resetSoloControls(int upper) {
    namespace sv=silveton::sampler;
    const auto old=upperEngineParams(upper);
    if(old.size()!=sv::kEngineParamCount+1U||static_cast<int>(old[0])!=static_cast<int>(sv::EngineType::Solo))return false;
    std::vector<float> row(sv::kEngineParamCount+1U);row[0]=static_cast<float>(sv::EngineType::Solo);
    if(engine.nativeSoloModelName(upper).empty()){
        sv::solo::defaults(row.data()+1);
        row[sv::solo::MorphX+1]=old[sv::solo::MorphX+1];
        row[sv::solo::MorphY+1]=old[sv::solo::MorphY+1];
    }else sv::solo::learnedDefaults(row.data()+1,old[sv::solo::ReleaseMs+1]);
    row[sv::E_BEND_UP+1]=old[sv::E_BEND_UP+1];row[sv::E_BEND_DOWN+1]=old[sv::E_BEND_DOWN+1];
    // A parameter update preserves the attached model and the part's octave/range.
    return nativeResult(engine.nativeSetUpperEngineBlock(upper,0,row));
}

bool SamplerAppController::activateSolo(int upper,int character) {
    namespace sv=silveton::sampler;
    if(upper<0||upper>=sv::kPartCount||character<0||character>2)return false;
    const auto st=upperState(upper);if(!st)return false;
    const auto old=upperEngineParams(upper);
    const bool same=old.size()==sv::kEngineParamCount+1U&&static_cast<int>(old[0])==static_cast<int>(sv::EngineType::Solo);
    std::array<float,sv::kEngineParamCount> p{};sv::solo::defaults(p.data());
    if(character==1){p[sv::solo::MorphX]=1;p[sv::solo::MorphY]=.7F;}
    if(character==2){p[sv::solo::MorphX]=.5F;p[sv::solo::MorphY]=.35F;}
    if(same)for(int id:std::array<int,5>{{sv::E_BEND_UP,sv::E_BEND_DOWN,sv::solo::Priority,sv::solo::BreathMode,sv::solo::Retrigger}})
        p[static_cast<std::size_t>(id)]=old[static_cast<std::size_t>(id)+1U];
    if(!engine.nativeUpdateUpperMain(upper,true,st->solo,false,st->levelDb,st->pan,st->keyLow,st->keyHigh,2))return false;
    if(!same){
        if(!engine.nativeUpdateUpperTune(upper,0,0,0,2,.025F))return false;
        for(const auto& kv:std::vector<std::pair<int,float>>{{42,1},{43,1},{44,0},{45,12}})
            if(!engine.nativeSetUpperParam(upper,kv.first,kv.second))return false;
        for(const auto& kv:std::vector<std::pair<int,float>>{{0,1},{1,0},{2,1},{3,25}})
            if(!engine.nativeSetUpperToneParam(upper,kv.first,kv.second))return false;
    }
    // Publish the desired source/parameters once, without a temporary legacy preset.
    std::vector<float> row(sv::kEngineParamCount+1U);row[0]=static_cast<float>(sv::EngineType::Solo);
    std::copy(p.begin(),p.end(),row.begin()+1);
    if(!engine.nativeSetUpperEngineBlock(upper,0,row))return false;
    if(!engine.nativeLoadSoloModel(upper,""))return false;
    ++bankSerial_;status("");return true;
}



bool SamplerAppController::setUpperEngineBlock(int upper, int firstId, const std::vector<float>& values) { return nativeResult(engine.nativeSetUpperEngineBlock(upper, firstId, values)); }  
std::vector<float> SamplerAppController::upperEngineParams(int upper) { return engine.nativeUpperEngineParams(upper); }
std::vector<float> SamplerAppController::soundSynthParams(int upper, int sound) { return engine.nativeSoundSynthParams(upper, sound); }
bool SamplerAppController::setSoundWaveParam(int upper, int sound, int id, float value) { return nativeResult(engine.nativeSetSoundWaveParam(upper, sound, id, value)); }
std::vector<float> SamplerAppController::soundWaveParams(int upper, int sound) { return engine.nativeSoundWaveParams(upper, sound); }

// ---------------------------------------------------------------- status
std::vector<std::pair<float, float>> SamplerAppController::upperMeters() {
    const auto meters = engine.nativeMeters();
    std::vector<std::pair<float, float>> out;
    for (std::size_t i = 0U; i < 7U; ++i) {
        const std::size_t base = 5U + i * 2U;
        out.emplace_back(at(meters, base, 0.0F), at(meters, base + 1U, 0.0F));
    }
    return out;
}

SamplerAppController::AudioStatus SamplerAppController::audioStatus() {
    const auto info = engine.nativeAudioInfo();
    const auto meters = engine.nativeMeters();
    AudioStatus s;
    s.sampleRate = atI(info, 0, 0);
    s.framesPerBurst = atI(info, 1, 0);
    s.bufferSizeFrames = atI(info, 2, 0);
    s.xrunCount = atI(info, 3, 0);
    s.sharingMode = atI(info, 4, -1);
    s.performanceMode = atI(info, 5, -1);
    s.deviceId = atI(info, 6, -1);
    s.estimatedLatencyMs = engine.nativeLatencyMs();
    s.peakLeft = at(meters, 0U, 0.0F);
    s.peakRight = at(meters, 1U, 0.0F);
    s.limiterGainReductionDb = at(meters, 2U, 0.0F);
    s.activeVoices = static_cast<int>(at(meters, 3U, 0.0F));
    s.droppedRealtimeEvents = static_cast<int>(at(meters, 4U, 0.0F));
    s.cpuLoadPercent = at(meters, 5U + 7U * 2U, 0.0F);
    s.coresWorking = std::clamp(static_cast<int>(at(meters, 6U + 7U * 2U, 1.0F)), 1, 8);
    return s;
}

std::string SamplerAppController::combiName() { return orBlank(engine.nativeCombiName(), "COMBI"); }
std::string SamplerAppController::bankLoadError() { return engine.nativeLastTextError(); }

// ---------------------------------------------------------------- Uppers
std::optional<SamplerAppController::UpperState> SamplerAppController::upperState(int upper) {
    const std::vector<float> v = engine.nativeUpperState(upper);
    if (v.size() < 33U) return std::nullopt;
    UpperState s;
    s.enabled = v[0] >= 0.5F; s.solo = v[1] >= 0.5F; s.mute = v[2] >= 0.5F;
    s.levelDb = v[3]; s.pan = v[4]; s.keyLow = static_cast<int>(v[5]); s.keyHigh = static_cast<int>(v[6]);
    s.velocityLow = static_cast<int>(v[7]); s.velocityHigh = static_cast<int>(v[8]); s.voiceMode = static_cast<int>(v[9]);
    s.octave = static_cast<int>(v[10]); s.transpose = static_cast<int>(v[11]); s.fineCents = v[12];
    s.pitchBendRange = static_cast<int>(v[13]); s.portamentoSec = v[14];
    s.breath = v[15] >= 0.5F; s.expression = v[16] >= 0.5F; s.aftertouch = v[17] >= 0.5F; s.damper = v[18] >= 0.5F;
    s.midiChannel = static_cast<int>(v[19]); s.attackScale = v[20]; s.decayScale = v[21]; s.sustainScale = v[22]; s.releaseScale = v[23];
    s.cutoffOctaves = v[24]; s.resonanceOffset = v[25]; s.lfoRateScale = v[26]; s.lfoDepthScale = v[27];
    s.eqLowDb = v[28]; s.eqMidDb = v[29]; s.eqHighDb = v[30]; s.fxSend1 = v[31]; s.fxSend2 = v[32];
    s.soundName = orBlank(engine.nativeUpperSoundName(upper), "EMPTY");
    s.toneAttackMs = at(v, 33U, 5.0F); s.toneDecayMs = at(v, 34U, 80.0F); s.toneSustain = at(v, 35U, 1.0F);
    s.toneReleaseMs = at(v, 36U, 120.0F); s.toneCutoffHz = at(v, 37U, 20000.0F); s.toneResonance = at(v, 38U, 0.0F);
    int bits = 0;
    for (std::size_t k = 0U; k < 6U; ++k) if (at(v, 39U + k, 0.0F) >= 0.5F) bits |= 1 << k;
    s.toneSet = bits;
    return s;
}

bool SamplerAppController::setUpperTone(int upper, int param, float value) { return nativeResult(engine.nativeSetUpperToneParam(upper, param, value)); }
bool SamplerAppController::assignUpperSound(int upper, const SoundItem& item) { return nativeResult(engine.nativeAssignUpperSound(item.bank, item.page, item.slot, upper)); }
bool SamplerAppController::clearUpperSound(int upper) { return nativeResult(engine.nativeClearUpperSound(upper)); }
bool SamplerAppController::clearPerformance() {   // SILVETON_EMPTY_START_V1
    const bool ok = nativeResult(engine.nativeClearPerformance());
    engine.nativePanic();   // the notes that still sound stop too
    return ok;
}

bool SamplerAppController::updateUpperMain(int upper, const UpperState& s) {
    return nativeResult(engine.nativeUpdateUpperMain(upper, s.enabled, s.solo, s.mute, s.levelDb, s.pan, s.keyLow, s.keyHigh, s.voiceMode));
}
bool SamplerAppController::updateUpperTune(int upper, const UpperState& s) {
    return nativeResult(engine.nativeUpdateUpperTune(upper, s.octave, s.transpose, s.fineCents, s.pitchBendRange, s.portamentoSec));
}
bool SamplerAppController::updateUpperRange(int upper, const UpperState& s) {
    return nativeResult(engine.nativeUpdateUpperRange(upper, s.velocityLow, s.velocityHigh));
}
bool SamplerAppController::updateUpperControl(int upper, const UpperState& s) {
    return nativeResult(engine.nativeUpdateUpperControl(upper, s.breath, s.expression, s.aftertouch, s.damper, s.midiChannel));
}
bool SamplerAppController::updateUpperTone(int upper, const UpperState& s) {
    return nativeResult(engine.nativeUpdateUpperTone(upper, s.attackScale, s.decayScale, s.sustainScale, s.releaseScale,
        s.cutoffOctaves, s.resonanceOffset, s.lfoRateScale, s.lfoDepthScale, s.eqLowDb, s.eqMidDb, s.eqHighDb));
}
bool SamplerAppController::updateUpperFx(int upper, const UpperState& s) {
    return nativeResult(engine.nativeUpdateUpperFxSends(upper, s.fxSend1, s.fxSend2));
}

std::string SamplerAppController::blendInfo(const ListItem& item) {   // SILVETON_BLEND_INFO_V1
    return engine.nativeBlendInfo(item.combiBank, item.combiPage, item.combiSlot);
}

std::optional<SamplerAppController::CombiFxState> SamplerAppController::combiFxState() {
    const std::vector<float> v = engine.nativeCombiFxState();
    if (v.size() < 15U) return std::nullopt;
    auto fx = [&](std::size_t base) {
        FxState f;
        f.type = static_cast<int>(v[base]); f.wet = v[base + 1U]; f.timeMs = v[base + 2U]; f.feedback = v[base + 3U];
        f.rateHz = v[base + 4U]; f.depth = v[base + 5U]; f.tone = v[base + 6U];
        return f;
    };
    CombiFxState s;
    s.fx1 = fx(0U);
    s.fx2 = fx(7U);
    s.routing = v.size() > 28U ? static_cast<int>(v[28]) : 0;   // SILVETON_FX_V3: 4 slots x 7 values, then the routing
    return s;
}

bool SamplerAppController::updateCombiFx(int slot, const FxState& fx) {
    if (slot < 1 || slot > 2) return fail("Invalid COMBI FX slot");
    return nativeResult(engine.nativeUpdateCombiFx(slot - 1, fx.type, fx.wet, fx.timeMs, fx.feedback, fx.rateHz, fx.depth, fx.tone));
}

bool SamplerAppController::updateCombiFxRouting(int routing) { return nativeResult(engine.nativeUpdateCombiFxRouting(routing)); }

std::optional<SamplerAppController::GlobalUiState> SamplerAppController::globalUiState() {
    const std::vector<float> v = engine.nativeGlobalState();
    if (v.size() < 14U) return std::nullopt;
    GlobalUiState g;
    g.masterTuneHz = v[0]; g.transpose = static_cast<int>(v[1]); g.masterGainDb = v[2];
    g.eqLowDb = v[3]; g.eqMidDb = v[4]; g.eqHighDb = v[5];
    g.limiterEnabled = v[6] >= 0.5F; g.limiterCeilingDb = v[7]; g.velocityCurve = static_cast<int>(v[8]);
    g.breathCc = static_cast<int>(v[9]); g.expressionCc = static_cast<int>(v[10]); g.damperCc = static_cast<int>(v[11]);
    g.pitchBendEnabled = v[12] >= 0.5F; g.aftertouchEnabled = v[13] >= 0.5F;
    return g;
}

std::optional<float> SamplerAppController::nudgeMasterGain(float stepDb) {
    auto g = globalUiState();
    if (!g) return std::nullopt;
    const float next = std::clamp(g->masterGainDb + stepDb, -60.0F, 18.0F);
    g->masterGainDb = next;
    if (!updateGlobalUi(*g)) return std::nullopt;
    return next;
}

bool SamplerAppController::updateGlobalUi(const GlobalUiState& s) {
    return nativeResult(engine.nativeUpdateGlobal(s.masterTuneHz, s.transpose, s.masterGainDb, s.eqLowDb, s.eqMidDb, s.eqHighDb,
        s.limiterEnabled, s.limiterCeilingDb, s.velocityCurve, s.breathCc, s.expressionCc, s.damperCc,
        s.pitchBendEnabled, s.aftertouchEnabled));
}

bool SamplerAppController::nativeResult(bool ok) {
    if (ok) { status(""); return true; }
    lastFailure_ = orBlank(engine.nativeLastTextError(), "Native sampler operation failed");
    status(lastFailure_);
    return false;
}

bool SamplerAppController::fail(const std::string& message) {
    lastFailure_ = message;
    status(message);
    return false;
}

} // namespace silveton::ui
