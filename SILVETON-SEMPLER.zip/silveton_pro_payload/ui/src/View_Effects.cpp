// SILVETON_MAC_VIEW_V1 - the EFFECTS page (tablet SilvetonSamplerView.kt lines 2582-2721)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
// Kotlin's kotlin.math.ln on a Float computes in double and rounds back to float.
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float roundf_(float v) { return std::nearbyint(v); }   // kotlin.math.round(Float)

float reverbSeconds(float feedback) {
    const float f = std::clamp(feedback, 0.0F, 0.95F);
    return 0.6F * static_cast<float>(std::pow(20.0, static_cast<double>(f / 0.95F)));
}
float reverbFeedbackFor(float seconds) {
    return std::clamp(0.95F * (lnf(std::clamp(seconds, 0.6F, 12.0F) / 0.6F) / lnf(20.0F)), 0.0F, 0.95F);
}

// One knob of an effect: id into the FX params, label, min, max, step, how it is shown.
struct FxKnob {
    int id;
    std::string label;
    float minV;
    float maxV;
    float step;
    float def;
    std::function<std::string(float)> show;
    int decimals;
};

std::vector<FxKnob> fxKnobsFor(int type) {
    const auto pct = [](float v) { return fmtFixed(static_cast<double>(v * 100.0F), 2) + " %"; };
    const auto ms = [](float v) {
        if (v < 1000.0F) return std::to_string(static_cast<int>(roundf_(v))) + " ms";
        return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
    };
    const auto hz = [](float v) { return fmtFixed(static_cast<double>(v), 2) + " Hz"; };
    const auto whole = [](float v) { return std::to_string(static_cast<int>(v)); };
    const auto db2 = [](float v) { return fmtFixed(static_cast<double>(v), 2) + " dB"; };
    const FxKnob wet{1, "WET", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0};
    const std::vector<FxKnob> reverb = {
        wet, {7, "PRE-DELAY", 0.0F, 200.0F, 1.0F, 10.0F, ms, 0},
        {3, "DECAY", 0.0F, 0.95F, 0.005F, 0.6F, [](float v) { return fmtFixed(static_cast<double>(reverbSeconds(v)), 2) + " s"; }, 1},
        {6, "TONE", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {8, "DAMPING", 0.0F, 1.0F, 0.01F, 0.4F, pct, 0},
        {9, "SIZE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}, {10, "MOD", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0}};
    const std::vector<FxKnob> delay = {wet, {2, "TIME", 1.0F, 2500.0F, 1.0F, 320.0F, ms, 0}, {3, "FEEDBACK", 0.0F, 0.95F, 0.005F, 0.25F, pct, 0},
                                       {6, "TONE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}};
    const auto plus = [&delay](const FxKnob& extra, const FxKnob* second = nullptr) {
        std::vector<FxKnob> v = delay;
        v.push_back(extra);
        if (second != nullptr) v.push_back(*second);
        return v;
    };
    switch (type) {
        case 1: return delay;
        case 8: { const FxKnob a{10, "WOW/FLUTTER", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0}; const FxKnob b{5, "SATURATION", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0}; return plus(a, &b); }
        case 9: return delay;
        case 10: return plus({5, "SPREAD", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0});
        case 11: return plus({5, "DUCKING", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0});
        case 2: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.8F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0}, {6, "TONE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0},
                        {14, "VOICES", 2.0F, 4.0F, 1.0F, 3.0F, whole, 0}};
        case 12: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.3F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}, {3, "FEEDBACK", -0.95F, 0.95F, 0.01F, 0.4F, pct, 0}};
        case 17: return {wet, {4, "SPEED", 0.1F, 2.0F, 0.01F, 0.6F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.7F, pct, 0}};
        case 13: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.4F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {3, "FEEDBACK", 0.0F, 0.9F, 0.01F, 0.3F, pct, 0},
                         {14, "STAGES", 4.0F, 8.0F, 2.0F, 6.0F, whole, 0}};
        case 14: return {wet, {4, "SLOW Hz", 0.1F, 2.0F, 0.01F, 0.8F, hz, 2}, {14, "FAST Hz", 2.0F, 10.0F, 0.1F, 6.5F, hz, 1}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0},
                         {15, "SPEED", 0.0F, 1.0F, 1.0F, 0.0F, [](float v) { return std::string(v >= 0.5F ? "FAST" : "SLOW"); }, 0}};
        case 15: return {{14, "THRESHOLD", -60.0F, 0.0F, 0.5F, -20.0F, db2, 1},
                         {15, "RATIO", 1.0F, 20.0F, 0.1F, 4.0F, [](float v) { return fmtFixed(static_cast<double>(v), 1) + " : 1"; }, 1},
                         {2, "ATTACK", 0.1F, 300.0F, 0.1F, 10.0F, ms, 1}, {16, "RELEASE", 10.0F, 3000.0F, 1.0F, 120.0F, ms, 0},
                         {6, "MAKE-UP", 0.0F, 24.0F, 0.1F, 0.0F, db2, 1}};
        case 16: return {wet, {5, "DRIVE", 0.0F, 1.0F, 0.01F, 0.4F, pct, 0}, {6, "TONE", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {14, "OUTPUT", -24.0F, 12.0F, 0.5F, 0.0F, db2, 1}};
        case 3: case 4: case 5: case 6: case 7: return reverb;
        default: return {};
    }
}
} // namespace

// SILVETON_PRO_UI_V1 - the FX page of COMBI: the effects are common to all Uppers. Left: what every Upper sends to FX1..FX4 and its
// INSERT; right: the effect chosen above (FX1..FX4 or the INSERT of an Upper), its type and its knobs.
void SilvetonSamplerView::drawFxPage(Canvas& c) {
    // the sends of all Uppers
    const RectF lp(10.0F, 80.0F, 430.0F, 736.0F);
    proPanel(c, lp, "ИЗПРАЩАНЕ · ВСИЧКИ UPPER-И", "%");
    const float nameL = 20.0F, cellL = 154.0F, cellW = 48.0F, insL = 362.0F, insR = 422.0F;
    text(c, "UPPER", nameL, 114.0F, 9.5F, Color::rgb(118, 128, 140), Opt().bold().spacing(0.12F));
    for (int n = 0; n < 4; ++n)
        text(c, "FX" + std::to_string(n + 1), cellL + static_cast<float>(n) * (cellW + 3.0F) + cellW * 0.5F, 114.0F, 9.5F, Color::rgb(118, 128, 140), Opt().center().bold());
    text(c, "INSERT", (insL + insR) * 0.5F, 114.0F, 9.5F, Color::rgb(118, 128, 140), Opt().center().bold());
    for (int u = 0; u < 7; ++u) {
        auto& slot = upperStates[static_cast<std::size_t>(u)];
        if (!slot) slot = sampler.upperState(u);
        if (!slot) continue;
        const UpperState s = *slot;
        const bool used = s.enabled && s.soundName != "EMPTY" && !isBlank(s.soundName);
        const float top = 122.0F + static_cast<float>(u) * 52.0F;
        const RectF row(16.0F, top, 424.0F, top + 46.0F);
        fill(c, row, 6.0F, u == selectedUpper_ ? Color::rgb(30, 40, 54) : Color::rgb(27, 31, 36));
        text(c, "U" + std::to_string(u + 1), nameL + 4.0F, top + 20.0F, 12.0F, u == selectedUpper_ ? Color::rgb(111, 183, 255) : C_INK, Opt().bold());
        text(c, used ? s.soundName : std::string("EMPTY"), nameL + 4.0F, top + 37.0F, 11.0F, used ? Color::rgb(200, 205, 212) : Color::rgb(100, 108, 118), Opt().maxW(cellL - nameL - 10.0F));
        hit(RectF(row.left, row.top, cellL - 4.0F, row.bottom), [this, u](float, float) { selectedUpper_ = u; invalidate(); });
        const std::vector<float> p = uParams(u);
        for (int n = 1; n <= 4; ++n) {
            const float value = n == 1 ? s.fxSend1 : (n == 2 ? s.fxSend2 : (n == 3 ? getOr(p, 46, 0.0F) : getOr(p, 47, 0.0F)));
            const RectF cr(cellL + static_cast<float>(n - 1) * (cellW + 3.0F), top + 6.0F, cellL + static_cast<float>(n - 1) * (cellW + 3.0F) + cellW, top + 40.0F);
            fill(c, cr, 4.0F, Color::rgb(5, 6, 8));
            fill(c, RectF(cr.left + 1.0F, cr.top + 1.0F, cr.right - 1.0F, cr.bottom - 1.0F), 3.0F, isDown(cr) ? Color::rgb(30, 36, 44) : Color::rgb(15, 18, 21));
            const int pct = static_cast<int>(std::lround(value * 100.0F));
            text(c, std::to_string(pct), cr.centerX(), cr.centerY() + 4.0F, 12.0F, pct > 0 ? Color::rgb(241, 243, 245) : Color::rgb(70, 78, 88), Opt().center().monoBold());
            if (pct > 0) fill(c, RectF(cr.left + 3.0F, cr.bottom - 4.0F, cr.left + 3.0F + (cr.width() - 6.0F) * std::clamp(value, 0.0F, 1.0F), cr.bottom - 2.0F), 1.0F, C_ACCENT);
            const std::function<void(float)> apply = [this, s, u, n](float nv) {
                nv = std::clamp(nv, 0.0F, 1.0F);
                if (n <= 2) {
                    const auto& sl = upperStates[static_cast<std::size_t>(u)];
                    UpperState x = sl ? *sl : s;
                    if (n == 1) x.fxSend1 = nv; else x.fxSend2 = nv;
                    const int keep = selectedUpper_;
                    selectedUpper_ = u;   // commitUpperFx works on the selected Upper
                    commitUpperFx(x);
                    selectedUpper_ = keep;
                } else {
                    setUParam(u, n == 3 ? 46 : 47, nv);
                }
            };
            knobHit(cr, value, 0.0F, 1.0F, 0.01F, 200.0F, apply,
                    [this, u, n, value, apply] {
                        showNumber("U" + std::to_string(u + 1) + " → FX" + std::to_string(n) + " SEND %", value * 100.0F, 0.0F, 100.0F, 0,
                                   [apply](float pct2) { apply(pct2 / 100.0F); });
                    },
                    [apply] { apply(0.0F); });
        }
        const int insType = static_cast<int>(at(fxP(4 + u), 0U, 0.0F));
        const RectF ir(insL, top + 6.0F, insR, top + 40.0F);
        proKey(c, ir, insType != 0 ? effectName(insType) : std::string("OFF"), fxUnitFocus == 4 + u, 9.0F, insType != 0 ? C_ACCENT : Color::rgb(80, 88, 98));
        hit(ir, [this, u](float, float) { fxUnitFocus = 4 + u; selectedUpper_ = u; invalidate(); });
    }
    // ROUTING of FX1 and FX2
    std::optional<CombiFxState> fx = fxState;
    if (!fx) { fx = sampler.combiFxState(); if (fx) fxState = fx; }
    const int routing = fx ? fx->routing : 0;
    text(c, "ROUTING", 20.0F, 512.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.18F));
    const RectF rp(20.0F, 520.0F, 220.0F, 560.0F), rs(226.0F, 520.0F, 420.0F, 560.0F);
    proKey(c, rp, "FX1 + FX2\nПАРАЛЕЛНО", routing == 0, 10.5F);
    proKey(c, rs, "FX1 → FX2\nПОСЛЕДОВАТЕЛНО", routing != 0, 10.5F);
    hit(rp, [this](float, float) { if (sampler.updateCombiFxRouting(0)) refreshFx(); });
    hit(rs, [this](float, float) { if (sampler.updateCombiFxRouting(1)) refreshFx(); });
    text(c, "Плъзни число нагоре / надолу, докосни го за точна стойност, две докосвания = 0.", 20.0F, 600.0F, 11.0F, C_HINT, Opt().maxW(400.0F));
    text(c, "INSERT е ефект само на своя UPPER; FX1..FX4 са общи за всички.", 20.0F, 620.0F, 11.0F, C_HINT, Opt().maxW(400.0F));

    // the units: FX1..FX4 and the INSERT of every Upper
    const float ux0 = 438.0F, ux1 = 1330.0F;
    const float unit = (ux1 - ux0 - 10.0F * 4.0F) / (4.0F * 1.6F + 7.0F);
    float x = ux0;
    for (int k = 0; k < 11; ++k) {
        const float w = k < 4 ? unit * 1.6F : unit;
        const RectF kr(x, 80.0F, x + w, 128.0F);
        const int t = static_cast<int>(at(fxP(k), 0U, 0.0F));
        const std::string name = k < 4 ? "FX " + std::to_string(k + 1) : "INS U" + std::to_string(k - 3);
        const bool sel = fxUnitFocus == k;
        proKey(c, kr, "", sel, 11.0F);
        text(c, name, kr.left + 8.0F, kr.top + 17.0F, 9.5F, sel ? Color::rgb(220, 234, 255) : (k < 4 ? Color::rgb(139, 149, 161) : C_PRO_AMBER), Opt().bold().spacing(0.12F).maxW(w - 12.0F));
        text(c, t != 0 ? effectName(t) : std::string("OFF"), kr.left + 8.0F, kr.bottom - 11.0F, k < 4 ? 14.0F : 10.5F, sel ? Color::WHITE : C_INK, Opt().bold().maxW(w - 12.0F));
        hit(kr, [this, k](float, float) { fxUnitFocus = k; invalidate(); });
        x += w + 4.0F;
    }
    drawFxParams(c, RectF(ux0, 136.0F, ux1, 736.0F), std::clamp(fxUnitFocus, 0, 10));
}

void SilvetonSamplerView::drawFxParams(Canvas& c, const RectF& r, int unit) {
    const std::vector<float> p = fxP(unit);
    const int type = static_cast<int>(at(p, 0U, 0.0F));
    const std::string title = unit < 4 ? "FX" + std::to_string(unit + 1) : "INSERT U" + std::to_string(unit - 3);
    // the type
    const RectF tb(r.left, r.top, r.right, r.top + 132.0F);
    proPanel(c, tb, title + " · ТИП");
    static const char* const typeNames[] = {"OFF", "DIGITAL DLY", "CHORUS", "PLATE", "HALL", "ROOM", "CHAMBER", "SPRING", "TAPE DLY", "PING-PONG",
                                            "MULTI-TAP", "DUCK DLY", "FLANGER", "PHASER", "ROTARY", "COMP", "DRIVE", "ENSEMBLE"};
    static const int order[] = {0, 4, 3, 5, 6, 7, 1, 8, 9, 10, 11, 2, 17, 12, 13, 14, 15, 16};
    const float kw = (tb.width() - 20.0F - 5.0F * 4.0F) / 6.0F;
    for (int k = 0; k < 18; ++k) {
        const int t = order[k];
        const float row = static_cast<float>(k / 6);
        const float col = static_cast<float>(k % 6);
        const RectF b(tb.left + 10.0F + col * (kw + 4.0F), tb.top + 28.0F + row * 33.0F, tb.left + 10.0F + col * (kw + 4.0F) + kw, tb.top + 58.0F + row * 33.0F);
        proKey(c, b, typeNames[t], type == t, 11.0F);
        hit(b, [this, unit, t](float, float) { setFxP(unit, 0, static_cast<float>(t)); });
    }
    // the knobs
    const RectF sec(r.left, tb.bottom + 8.0F, r.right, r.bottom);
    proPanel(c, sec, "ПАРАМЕТРИ · " + effectName(type));
    const std::vector<FxKnob> knobs = fxKnobsFor(type);
    if (knobs.empty()) {
        text(c, title + " е изключен. Избери ефект отгоре.", sec.centerX(), sec.top + 160.0F, 16.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
        return;
    }
    const bool delayType = type == 1 || type == 8 || type == 9 || type == 10 || type == 11;
    const int n = static_cast<int>(knobs.size());
    const float cy = delayType ? sec.top + 150.0F : sec.top + sec.height() * 0.45F;
    for (int k = 0; k < n; ++k) {
        const FxKnob kn = knobs[static_cast<std::size_t>(k)];
        const float cx = sec.left + sec.width() * (static_cast<float>(k) + 0.5F) / static_cast<float>(n);
        const float v = at(p, static_cast<std::size_t>(kn.id), kn.def);
        const std::function<void(float)> apply = [this, unit, kn](float nv) {
            setFxP(unit, kn.id, kn.step >= 1.0F ? roundf_(nv / kn.step) * kn.step : nv);
        };
        const bool reverbType = type >= 3 && type <= 7;
        knobControl(c, cx, cy, 32.0F, v, kn.minV, kn.maxV, kn.step, 300.0F, kn.minV < 0.0F && kn.maxV > 0.0F, kn.show(v), kn.label,
                    std::min(170.0F, sec.width() / static_cast<float>(n) - 10.0F),
                    [apply](float nv) { apply(nv); },
                    [this, kn, v, title, apply, reverbType]() {
                        if (kn.id == 3 && reverbType) {
                            showNumber(title + " DECAY s", reverbSeconds(v), 0.6F, 12.0F, 1, [apply](float it) { apply(reverbFeedbackFor(it)); }, true,
                                       [apply, v]() { apply(v); });
                        } else if (kn.maxV <= 1.0F && kn.minV >= -1.0F && kn.step < 1.0F) {
                            showNumber(title + " " + kn.label + " %", v * 100.0F, kn.minV * 100.0F, kn.maxV * 100.0F, 0,
                                       [apply, kn](float it) { apply(std::clamp(it / 100.0F, kn.minV, kn.maxV)); }, true, [apply, v]() { apply(v); });
                        } else {
                            showNumber(title + " " + kn.label, v, kn.minV, kn.maxV, kn.decimals, [apply](float it) { apply(it); });
                        }
                    },
                    [apply, kn]() { apply(kn.def); });
    }
    // delays: tempo sync keys
    if (delayType) {
        const bool sync = at(p, 11U, 0.0F) >= 0.5F;
        const float y = sec.bottom - 120.0F;
        text(c, "TEMPO", sec.left + 16.0F, y - 10.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.18F));
        const RectF sr(sec.left + 16.0F, y, sec.left + 176.0F, y + 44.0F);
        proKey(c, sr, "TEMPO SYNC", sync, 12.0F);
        hit(sr, [this, unit, sync](float, float) { setFxP(unit, 11, sync ? 0.0F : 1.0F); });
        const float bpm = at(p, 12U, 120.0F);
        const RectF br(sec.left + 188.0F, y, sec.left + 348.0F, y + 44.0F);
        proField(c, br, std::to_string(static_cast<int>(bpm)) + " BPM", 14.0F);
        hit(br, [this, unit, bpm](float, float) {
            showNumber("TEMPO (BPM)", bpm, 30.0F, 300.0F, 0, [this, unit](float it) { setFxP(unit, 12, roundf_(it)); });
        });
        const RectF tapR(sec.left + 360.0F, y, sec.left + 470.0F, y + 44.0F);
        proKey(c, tapR, "TAP", false, 13.0F);
        hit(tapR, [this, unit](float, float) { tapTempo(unit); });
        static const std::pair<float, const char*> divs[] = {{0.25F, "1/4"}, {0.1875F, "1/8."}, {0.125F, "1/8"}, {0.0833333F, "1/8T"}, {0.0625F, "1/16"}, {0.5F, "1/2"}};
        const float cur = at(p, 13U, 0.25F);
        for (int k = 0; k < 6; ++k) {
            const float d = divs[k].first;
            const RectF dr(sec.left + 490.0F + static_cast<float>(k) * 66.0F, y, sec.left + 550.0F + static_cast<float>(k) * 66.0F, y + 44.0F);
            proKey(c, dr, divs[k].second, sync && std::fabs(cur - d) < 0.002F, 12.0F);
            hit(dr, [this, unit, d](float, float) { setFxP(unit, 13, d); });
        }
    }
}

void SilvetonSamplerView::tapTempo(int unit) {
    const std::int64_t now = nowMs();
    if (!tapTimes.empty() && now - tapTimes.back() > 2000) tapTimes.clear();
    tapTimes.push_back(now);
    if (tapTimes.size() >= 2) {
        const float avg = static_cast<float>(tapTimes.back() - tapTimes.front()) / static_cast<float>(tapTimes.size() - 1);
        setFxP(unit, 12, std::clamp(roundf_(60000.0F / avg), 30.0F, 300.0F));
        setFxP(unit, 11, 1.0F);
    }
    if (tapTimes.size() > 8) tapTimes.erase(tapTimes.begin());
}

} // namespace silveton::ui
