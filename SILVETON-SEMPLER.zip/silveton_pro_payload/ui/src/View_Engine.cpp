// SILVETON_ENGINES_V1 - the ENGINE page of an Upper (КОМБИ > ENGINE): one of the nine engines on the whole Upper.
// Top row: the engines (OFF · HD-1 · POLYSIX · MS-20 · AL-1 · MOD-7 · STR-1 · CX-3 · SGX · EP) and the three pages of the
// chosen one (ЗВУК = the engine's own knobs, ФИЛТЪР = the two filters and the filter envelope, МОД = LFO / unison / analog).
// Every knob: drag = turn, tap = exact number, right button / double tap = its starting value. The labels, ranges and
// starting values come from core/include/silveton/sampler/EngineDefs.h, so the screen and the sound can never disagree.
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return cur;
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, 6))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u, int id, float v) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, 6))];
    const bool ok = sampler.setUpperEngineParam(u, id, v);
    // the engine itself changed = its starting values were loaded: read everything again.
    // SILVETON_ENGINE_UPPER_ON_V1: choosing an engine on an empty Upper switches the Upper on in the engine - read the Upper
    // again too, or the next LEVEL / PAN / range move would send the old OFF back and the engine's sound would stop
    if (!ok || id == 0) { slot.reset(); refreshUpper(u); }
    // SILVETON_ENGINES_V3: the STR-1 INSTRUMENT loads its typical values - read them all again
    else if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && id == sv::ST_BODY_TYPE + 1) slot.reset();
    else {
        auto a = eParams(u);
        if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = v;
        slot = a;
    }
    invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v));
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = d.label;
    const std::string hint = d.hint;
    if (logKind(d)) {
        knobControl(c, cx, cy, rad, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
                    [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
                    [this, u, id, d, v, hint, pct] {
                        showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                                   [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
                    },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && d.id == sv::ST_STYLE)
        d.names = sv::str1StyleNames(rndI(engineP(u, sv::ST_BODY_TYPE + 1)));
    const int id = d.id + 1;
    const float v = engineP(u, id);
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    stripToggle(c, r, engineValueText(d, v), on, C_AMBER, 11.0F);
    text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — " + d.hint;
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, darkTheme ? Color::rgb(16, 18, 16) : Color::rgb(40, 43, 48));
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, C_ACCENT);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 11.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 7.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    const RectF h(trackX - 14.0F, y - 9.0F, trackX + 14.0F, y + 9.0F);
    shadow(c, h, 4.0F, 2.0F, 70);
    fillV(c, h, 4.0F, Color::rgb(236, 238, 241), Color::rgb(201, 204, 209));
    text(c, std::to_string(v), trackX, y + 4.0F, 10.0F, Color::rgb(48, 52, 58), Opt().center().bold());
    text(c, d.label, trackX, r.bottom + 16.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold());
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- the page
void SilvetonSamplerView::drawEngine(Canvas& c, const RectF& sec, int u) {
    using sv::engineName;
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    secTitle(c, sec, "ENGINE · UPPER " + std::to_string(u + 1) + " · " + sv::engineLine(type));

    // row A: the ten engines, then the pages of the chosen one (three, or four for the engines with a second page of their own)
    const float keyY0 = sec.top + 26.0F, keyY1 = keyY0 + 36.0F;
    const float enginesW = 700.0F;
    const float kw = (enginesW - 9.0F * 4.0F) / 10.0F;
    for (int k = 0; k < sv::kEngineTypeCount; ++k) {
        const float x0 = sec.left + static_cast<float>(k) * (kw + 4.0F);
        const RectF kr(x0, keyY0, x0 + kw, keyY1);
        stripToggle(c, kr, engineName(static_cast<EngineType>(k)), typeIx == k, C_ACCENT, 11.0F);
        hit(kr, [this, u, k](float, float) { setEngineP(u, 0, static_cast<float>(k)); enginePage_ = 0; });
    }
    // SILVETON_ENGINES_V2: ENGINE ON / OFF - OFF plays the plain recording and keeps every setting (to hear the difference)
    if (type != EngineType::Off) {
        const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
        const float x0 = sec.left + enginesW + 8.0F;
        const RectF br(x0, keyY0, x0 + 72.0F, keyY1);
        stripToggle(c, br, bypassed ? "OFF" : "ON", !bypassed, C_LCD_OK, 13.0F);
        hit(br, [this, u, bypassed](float, float) { setEngineP(u, sv::E_BYPASS + 1, bypassed ? 0.0F : 1.0F); });
    }
    const int pageCount = std::max(1, sv::enginePageCount(type));
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the ДЪХ page
    if (enginePage_ >= pageCount) enginePage_ = 0;
    if (type != EngineType::Off) {
        const float pw = 94.0F;
        for (int k = 0; k < pageCount; ++k) {
            const float x1 = sec.right - static_cast<float>(pageCount - k) * (pw + 4.0F) + 4.0F;
            const RectF pr(x1, keyY0, x1 + pw, keyY1);
            stripToggle(c, pr, sv::enginePageName(type, k, variant), enginePage_ == k, C_AMBER, 11.0F);
            hit(pr, [this, k](float, float) { enginePage_ = k; invalidate(); });
        }
    }
    if (type == EngineType::Off) {
        text(c, "Избери двигател отгоре. Той работи върху записите на целия Upper (ОСНОВЕН + L1..L4), нота по нота.", sec.left + 8.0F, sec.top + 110.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
        text(c, "OFF = чист запис, както досега. Настройките се пазят в блендата / сета, както всичко друго.", sec.left + 8.0F, sec.top + 134.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
        return;
    }

    // the knobs and keys of the page: one or two rows
    const EngineParamPage page = sv::enginePage(type, std::clamp(enginePage_, 0, pageCount - 1), variant);
    if (page.count <= 0 || page.items == nullptr) return;
    const int n = page.count;
    const bool cx3Sound = type == EngineType::CX3 && enginePage_ == 0;
    const int cols = n <= 6 ? n : (cx3Sound ? 12 : std::min(12, (n + 1) / 2));
    const int firstRow = n <= 6 ? n : (cx3Sound ? 12 : (n + 1) / 2);
    const float unit = sec.width() / static_cast<float>(std::max(cols, 1));
    const float hw = std::min(unit - 4.0F, 150.0F);
    const float rad = 16.0F;
    const float r1 = n <= 6 ? sec.top + 150.0F : sec.top + 102.0F;
    const float r2 = r1 + (darkTheme ? 96.0F : 86.0F);   // the dark theme prints the names above the knobs
    for (int i = 0; i < n; ++i) {
        const EngineParamDef& d = page.items[i];
        const bool second = i >= firstRow;
        const int col = second ? i - firstRow : i;
        const float cx = sec.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = second ? r2 : r1;
        switch (d.kind) {
            case EngineKind::Drawbar: engineDrawbar(c, RectF(cx - hw / 2.0F, cy - 36.0F, cx + hw / 2.0F, cy + 30.0F), u, d); break;
            case EngineKind::Choice:
            case EngineKind::Switch: engineKey(c, RectF(cx - hw / 2.0F + 2.0F, cy - 22.0F, cx + hw / 2.0F - 2.0F, cy + 22.0F), u, d); break;
            default: engineKnob(c, cx, cy, rad, hw, u, d); break;
        }
    }
}

} // namespace silveton::ui
