// SOLO parameter controls.
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>

namespace silveton::ui {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

// SILVETON_USER_WAVES_V1: a place USER n shows the name of the user's wave in it ("U2 STRINGS"), or "USER n НЯМА" when empty


std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return cur;
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, 6))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u,int id,float v) {
 sampler.setUpperEngineParam(u,id,v);engineParamsCache[static_cast<std::size_t>(std::clamp(u,0,6))].reset();refreshUpper(u);invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v) - rndI(d.lo));   // SILVETON_OCTAVE_V1: a choice may start below 0 (ОКТАВА -2..+2) or at 1 (SUB OCT)
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = d.label;
    const std::string hint = d.hint;
    if (logKind(d)) {
        knobControl(c, cx, cy, rad, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
                    [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
                    [this, u, id, d, v, hint, pct] {
                        showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                                   [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
                    },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    const int id = d.id + 1;
    const float v = engineP(u, id);
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    // SILVETON_PRO_UI_V1: the name above; a choice is a dark field with ▾, a switch a key that lights
    text(c, d.label, r.centerX(), r.top - 5.0F, 10.0F, C_KNOB_LABEL, Opt().center().bold().spacing(0.1F).maxW(r.width() + 8.0F));
    if (d.kind == EngineKind::Switch) proKey(c, r, engineValueText(d, v), on, 12.0F);
    else proField(c, r, engineValueText(d, v), 13.0F, true);
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — избери и свири · допир извън прозореца = затваряне";
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open while choosing and playing
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, darkTheme ? Color::rgb(16, 18, 16) : Color::rgb(40, 43, 48));
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, C_ACCENT);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 11.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 7.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    const RectF h(trackX - 14.0F, y - 9.0F, trackX + 14.0F, y + 9.0F);
    shadow(c, h, 4.0F, 2.0F, 70);
    fillV(c, h, 4.0F, Color::rgb(236, 238, 241), Color::rgb(201, 204, 209));
    text(c, std::to_string(v), trackX, y + 4.0F, 10.0F, Color::rgb(48, 52, 58), Opt().center().bold());
    text(c, d.label, trackX, r.bottom + 16.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold());
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- SILVETON_PRO_UI_V1: the ENGINE page on the whole screen
namespace {
struct Group { const char* title; std::vector<int> ids; };

// the boxes of every page: a title and the parameters in it (a parameter of the page not named here goes to a last box)
std::vector<Group> engineGroups(EngineType t,int,int) {
 return t==EngineType::Solo?std::vector<Group>{{"CHARACTER",{0,1,2,3,4,5,6,7}},{"PLAYING",{8,9,10,11,12,13,14,15,16,17}}}:std::vector<Group>{};
}

ColorInt engineColor(int){return Color::rgb(74,163,255);}

const char* engineShort(int type){return type==13?"SOLO":"OFF";}

// one period of a basic wave, -1..1 (the name of the wave decides; anything else is a richer table wave)

} // namespace

void SilvetonSamplerView::drawEngineVis(Canvas& c,const RectF& r,int,int typeIx) {
 text(c,typeIx==13?"SILVETON SOLO":"SAMPLE",r.centerX(),r.centerY(),18,Color::WHITE,Opt().center().bold());
}

// one box of parameters: the choices on top, the drawbars / knobs under them, spread evenly over the box
void SilvetonSamplerView::engineBox(Canvas& c, const RectF& r, int u, const std::string& title, const std::vector<const EngineParamDef*>& items) {
    proPanel(c, r, title);
    std::vector<const EngineParamDef*> choices, bars, knobs;
    for (const EngineParamDef* d : items) {
        if (d->kind == EngineKind::Choice || d->kind == EngineKind::Switch) choices.push_back(d);
        else if (d->kind == EngineKind::Drawbar) bars.push_back(d);
        else knobs.push_back(d);
    }
    const RectF in(r.left + 10.0F, r.top + 28.0F, r.right - 10.0F, r.bottom - 8.0F);
    float y = in.top;
    if (!choices.empty()) {
        const int n = static_cast<int>(choices.size());
        const float cw = std::min(176.0F, (in.width() - static_cast<float>(n - 1) * 12.0F) / static_cast<float>(n));
        const float gap = (in.width() - cw * static_cast<float>(n)) / static_cast<float>(n + 1);
        for (int k = 0; k < n; ++k) {
            const float l = in.left + gap + static_cast<float>(k) * (cw + gap);
            engineKey(c, RectF(l, y + 16.0F, l + cw, y + 48.0F), u, *choices[static_cast<std::size_t>(k)]);
        }
        y += 58.0F;
    }
    if (!bars.empty()) {
        const int n = static_cast<int>(bars.size());
        const float cw = in.width() / static_cast<float>(n);
        const float bh = std::min(200.0F, in.bottom - y - 30.0F);
        for (int k = 0; k < n; ++k) {
            const float cx = in.left + cw * (static_cast<float>(k) + 0.5F);
            engineDrawbar(c, RectF(cx - 16.0F, y + 6.0F, cx + 16.0F, y + 6.0F + bh), u, *bars[static_cast<std::size_t>(k)]);
        }
        y += bh + 30.0F;
    }
    if (knobs.empty()) return;
    const int n = static_cast<int>(knobs.size());
    const float h = in.bottom - y;
    const int maxCols = std::max(1, static_cast<int>(in.width() / 92.0F));
    int cols = std::min(n, maxCols);
    int rows = (n + cols - 1) / cols;
    while (rows > 1 && h / static_cast<float>(rows) < 96.0F && cols < n) { ++cols; rows = (n + cols - 1) / cols; }
    const float cellW = in.width() / static_cast<float>(cols);
    const float cellH = h / static_cast<float>(rows);
    const float rad = std::clamp(std::min(cellW * 0.22F, (cellH - 64.0F) * 0.5F), 13.0F, 30.0F);   // SILVETON_UI_KRONOS_V1: the page is wide - bigger knobs
    for (int k = 0; k < n; ++k) {
        const int row = k / cols;
        const int col = k % cols;
        const int inRow = row == rows - 1 ? n - row * cols : cols;
        const float rowLeft = in.left + (in.width() - cellW * static_cast<float>(inRow)) * 0.5F;
        const float cx = rowLeft + cellW * (static_cast<float>(col) + 0.5F);
        const float cy = y + cellH * (static_cast<float>(row) + 0.5F) - (8.5F - 0.21F * rad);
        engineKnob(c, cx, cy, rad, std::min(cellW - 6.0F, 140.0F), u, *knobs[static_cast<std::size_t>(k)]);
    }
}

// PITCH BEND like the TRANSPOSE: ◀ the value ▶ (OFF / UPPER / 1..24 semitones); a tap on the value = the number
void SilvetonSamplerView::engineBend(Canvas& c, const RectF& r, int u, int id, const std::string& lab) {
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id);
    text(c, lab, r.left, r.centerY() + 4.0F, 11.0F, C_KNOB_LABEL, Opt().bold().spacing(0.1F));
    const RectF left(r.left + 70.0F, r.top, r.left + 120.0F, r.bottom);
    const RectF right(r.right - 50.0F, r.top, r.right, r.bottom);
    const RectF val(left.right + 6.0F, r.top, right.left - 6.0F, r.bottom);
    if (d == nullptr) {
        proField(c, val, "—", 15.0F);
        return;
    }
    const int hid = id + 1;
    const float v = engineP(u, hid);
    proKey(c, left, "◀", false, 15.0F);
    proKey(c, right, "▶", false, 15.0F);
    fill(c, val, 5.0F, Color::rgb(5, 6, 8));
    fill(c, RectF(val.left + 1.0F, val.top + 1.0F, val.right - 1.0F, val.bottom - 1.0F), 4.0F, Color::rgb(15, 18, 21));
    text(c, engineValueText(*d, v), val.centerX(), val.centerY() + 6.0F, 17.0F, Color::rgb(241, 243, 245), Opt().center().monoBold());
    const float lo = d->lo, hi = d->hi, def = d->def;
    hit(left, [this, u, hid, v, lo](float, float) { setEngineP(u, hid, std::max(lo, std::round(v) - 1.0F)); }, [this, u, hid, def] { setEngineP(u, hid, def); });
    hit(right, [this, u, hid, v, hi](float, float) { setEngineP(u, hid, std::min(hi, std::round(v) + 1.0F)); }, [this, u, hid, def] { setEngineP(u, hid, def); });
    const std::string hint = d->hint;
    hit(val, [this, u, hid, v, lo, hi, hint](float, float) { showNumber(hint, v, lo, hi, 0, [this, u, hid](float x) { setEngineP(u, hid, std::round(x)); }); },
        [this, u, hid, def] { setEngineP(u, hid, def); });
}

// SILVETON_UI_KRONOS_V1: the ENGINE screen built as pages, one thing on each page (like the pages of a workstation):
//   ДВИГАТЕЛ (choose the engine, the sound source, ON / OFF) · the pages of the engine (ЗВУК, ФИЛТЪР, МОД ...) · ИЗХОД (level, pan, bend) · OFS.
// The Upper keys stay at the right of the page row. Nothing else is on the screen - no numbered boxes, no side column.
void SilvetonSamplerView::drawEnginePage(Canvas& c, int u) {
    using sv::engineName;
    constexpr int kPgSelect = 100, kPgOutput = 101;
    u = std::clamp(u, 0, 6);
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
    const bool on = type != EngineType::Off && !bypassed;
    const int pageCount = type == EngineType::Off ? 0 : std::max(1, sv::enginePageCount(type));   // SILVETON_OFS_V1: pageCount = the OFS page
    const int variant=0;
    int pg = enginePage_;
    if (pg != kPgSelect && pg != kPgOutput && (type == EngineType::Off || pg < 0 || pg > pageCount)) pg = type == EngineType::Off ? kPgSelect : 0;
    enginePage_ = pg;
    const RectF area(10.0F, 128.0F, 1330.0F, 736.0F);

    // the row of pages and the Upper keys
    {
        std::vector<std::pair<int, std::string>> tabs;
        tabs.emplace_back(kPgSelect, "ДВИГАТЕЛ");
        for (int k = 0; k < pageCount; ++k) tabs.emplace_back(k, sv::enginePageName(type, k, variant));
        tabs.emplace_back(kPgOutput, "ИЗХОД");
        if (type != EngineType::Off) tabs.emplace_back(pageCount, "OFS");
        float x = 10.0F;
        for (const auto& t : tabs) {
            const RectF pr(x, 82.0F, x + 118.0F, 122.0F);
            proKey(c, pr, t.second, pg == t.first, 13.0F);
            const int id = t.first;
            hit(pr, [this, id](float, float) { enginePage_ = id; invalidate(); });
            x += 122.0F;
        }
        const float uw = 40.0F, ux0 = 1330.0F - 7.0F * uw - 6.0F * 4.0F;
        for (int k = 0; k < 7; ++k) {
            const RectF kr(ux0 + static_cast<float>(k) * (uw + 4.0F), 82.0F, ux0 + static_cast<float>(k) * (uw + 4.0F) + uw, 122.0F);
            const int tk = std::clamp(rndI(engineP(k, 0)), 0, sv::kEngineTypeCount - 1);
            proKey(c, kr, "U" + std::to_string(k + 1), k == u, 12.0F);
            if (tk != 0) fill(c, RectF(kr.right - 9.0F, kr.top + 4.0F, kr.right - 4.0F, kr.top + 9.0F), 2.5F, engineColor(tk));
            hit(kr, [this, k](float, float) { selectedUpper_ = k; invalidate(); });
        }
    }

    // page ДВИГАТЕЛ: the engines (big keys), the source of the sound, ON / OFF, and what the chosen engine is
    if (pg == kPgSelect) {
        // SILVETON_MODEL_REMOVED_V1: the old engines and SILVETON MODEL are gone from this page - only "no engine" is left (SILVETON SYNTH is put into a place of ДВИГАТЕЛИ)
        {
            const RectF kr(22.0F, 452.0F, 796.0F, 506.0F);
            const bool sel = typeIx == 0;
            proKey(c, kr, "НЯМА ДВИГАТЕЛ · ЧИСТ ЗАПИС", sel, 13.0F);
            hit(kr, [this, u, typeIx](float, float) {
                if (typeIx != 0) setEngineP(u, 0, 0.0F);
                invalidate();
            });
        }
        {   // what the chosen engine is
            const RectF b(22.0F, 520.0F, 796.0F, 728.0F);
            proPanel(c, b, "");
            text(c, type == EngineType::Off ? std::string("НЯМА ДВИГАТЕЛ") : std::string(engineName(type)), b.left + 16.0F, b.top + 44.0F, 28.0F, engineColor(typeIx), Opt().bold().spacing(0.08F));
            if (type != EngineType::Off) {
                text(c, engineShort(typeIx), b.left + 16.0F, b.top + 70.0F, 12.0F, Color::rgb(139, 149, 161), Opt().spacing(0.1F));
                text(c, sv::engineLine(type), b.left + 16.0F, b.top + 104.0F, 13.0F, Color::rgb(176, 188, 202), Opt().maxW(b.width() - 32.0F));
            } else {
                text(c, "Тук няма двигател: Upper-ът свири чист запис. SILVETON SYNTH се слага на място в ДВИГАТЕЛИ.", b.left + 16.0F, b.top + 82.0F, 13.0F, C_HINT, Opt().maxW(b.width() - 32.0F));
            }
        }
        {   // the source of the sound
            const RectF b(830.0F, 140.0F, 1330.0F, 396.0F);
            proPanel(c, b, "ЗВУК ОТ");
            const bool hasSource = type != EngineType::Off && sv::engineParamDef(type, sv::E_SOURCE) != nullptr;
            if (!hasSource) {
                text(c, type == EngineType::Off ? "САМО СЕМПЪЛ" : "SOLO · ИЗЧИСЛЕН ЗВУК", b.centerX(), b.centerY() + 6.0F, 13.0F, Color::rgb(130, 140, 152),
                     Opt().center().bold().maxW(b.width() - 24.0F));
            } else {
                const int src = std::clamp(rndI(engineP(u, sv::E_SOURCE + 1)), 0, 2);
                static const char* const names[3] = {"ДВИГАТЕЛ\n+ СЕМПЪЛ", "САМО\nДВИГАТЕЛ", "САМО\nСЕМПЪЛ"};
                for (int k = 0; k < 3; ++k) {
                    const RectF kr(844.0F, 168.0F + static_cast<float>(k) * 74.0F, 1316.0F, 168.0F + static_cast<float>(k) * 74.0F + 64.0F);
                    std::string a = uiLang_ != 0 ? tr(names[k]) : std::string(names[k]);
                    for (char& ch : a) if (ch == '\n') ch = ' ';
                    proKey(c, kr, a, src == k, 15.0F);
                    hit(kr, [this, u, k](float, float) { setEngineP(u, sv::E_SOURCE + 1, static_cast<float>(k)); });
                }
            }
        }
        {   // ON / OFF (OFF = the plain recording; every setting stays)
            const RectF b(830.0F, 410.0F, 1330.0F, 518.0F);
            proPanel(c, b, "ДВИГАТЕЛ", "UPPER " + std::to_string(u + 1));
            if (type == EngineType::Off) {
                text(c, "избери двигател", b.centerX(), b.centerY() + 12.0F, 13.0F, Color::rgb(130, 140, 152), Opt().center());
            } else {
                const RectF kOn(844.0F, 438.0F, 1068.0F, 504.0F), kOff(1092.0F, 438.0F, 1316.0F, 504.0F);
                proKey(c, kOn, "ВКЛЮЧЕН", on, 15.0F, C_PLAY);
                proKey(c, kOff, "ИЗКЛЮЧЕН", !on, 15.0F);
                hit(kOn, [this, u](float, float) { setEngineP(u, sv::E_BYPASS + 1, 0.0F); });
                hit(kOff, [this, u](float, float) { setEngineP(u, sv::E_BYPASS + 1, 1.0F); });
            }
        }
        {   // the picture of the engine
            const RectF b(830.0F, 532.0F, 1330.0F, 728.0F);
            proPanel(c, b, "");
            if (type != EngineType::Off) drawEngineVis(c, RectF(842.0F, 544.0F, 1318.0F, 720.0F), u, typeIx);
        }
        return;
    }

    // page ИЗХОД: level, pan and the pitch bend of the Upper
    if (pg == kPgOutput) {
        proPanel(c, RectF(area.left, area.top + 100.0F, area.right, area.top + 430.0F), "ИЗХОД", "UPPER " + std::to_string(u + 1));
        auto& slot = upperStates[static_cast<std::size_t>(u)];
        if (!slot) slot = sampler.upperState(u);
        if (slot) {
            const UpperState s = *slot;
            const std::function<void(float)> setLevel = [this, u, s](float t) {
                const auto& sl = upperStates[static_cast<std::size_t>(u)];
                UpperState cur = sl ? *sl : s;
                cur.levelDb = quantizeControl(faderDb(t), -60.0F, 12.0F, 0.1F);
                commitMain(u, cur);
            };
            knobControl(c, 210.0F, 358.0F, 40.0F, faderT(s.levelDb), 0.0F, 1.0F, 0.002F, 250.0F, false, dbText(s.levelDb), "LEVEL", 170.0F, setLevel,
                        [this, u, s] {
                            showNumber("UPPER " + std::to_string(u + 1) + " LEVEL dB", s.levelDb, -60.0F, 12.0F, 1, [this, u, s](float nv) {
                                const auto& sl = upperStates[static_cast<std::size_t>(u)];
                                UpperState cur = sl ? *sl : s;
                                cur.levelDb = nv;
                                commitMain(u, cur);
                            });
                        },
                        [this, u, s] { const auto& sl = upperStates[static_cast<std::size_t>(u)]; UpperState cur = sl ? *sl : s; cur.levelDb = 0.0F; commitMain(u, cur); });
            const std::function<void(float)> setPan = [this, u, s](float nv) {
                const auto& sl = upperStates[static_cast<std::size_t>(u)];
                UpperState cur = sl ? *sl : s;
                cur.pan = nv;
                commitMain(u, cur);
            };
            knobControl(c, 480.0F, 358.0F, 40.0F, s.pan, -1.0F, 1.0F, 0.01F, 160.0F, true, panText(s.pan), "PAN", 170.0F, setPan,
                        [this, u, s, setPan] { showNumber("UPPER " + std::to_string(u + 1) + " PAN", s.pan, -1.0F, 1.0F, 2, [setPan](float nv) { setPan(nv); }); },
                        [setPan] { setPan(0.0F); });
        }
        text(c, "PITCH BEND", 840.0F, 290.0F, 12.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
        engineBend(c, RectF(720.0F, 312.0F, 1300.0F, 362.0F), u, sv::E_BEND_UP, "НАГОРЕ");
        engineBend(c, RectF(720.0F, 382.0F, 1300.0F, 432.0F), u, sv::E_BEND_DOWN, "НАДОЛУ");
        return;
    }

    if (pg == pageCount) { drawOfsPage(c, area, u); return; }   // SILVETON_OFS_V1
    const EngineParamPage page = sv::enginePage(type, std::clamp(pg, 0, pageCount - 1), variant);
    if (page.count <= 0 || page.items == nullptr) return;
    // the boxes of this page; the source key and the bends live on their own pages
    std::vector<Group> groups = engineGroups(type, pg, variant);
    std::vector<std::pair<std::string, std::vector<const EngineParamDef*>>> boxes;
    std::vector<bool> used(static_cast<std::size_t>(page.count), false);
    for (int i = 0; i < page.count; ++i) {
        const int id = page.items[i].id;
        if (id == sv::E_SOURCE || id == sv::E_BEND_UP || id == sv::E_BEND_DOWN) used[static_cast<std::size_t>(i)] = true;
    }
    for (const Group& g : groups) {
        std::vector<const EngineParamDef*> items;
        for (const int id : g.ids) {
            for (int i = 0; i < page.count; ++i) {
                if (page.items[i].id == id && !used[static_cast<std::size_t>(i)]) { items.push_back(&page.items[i]); used[static_cast<std::size_t>(i)] = true; }
            }
        }
        if (!items.empty()) boxes.emplace_back(g.title, items);
    }
    {
        std::vector<const EngineParamDef*> rest;
        for (int i = 0; i < page.count; ++i) if (!used[static_cast<std::size_t>(i)]) rest.push_back(&page.items[i]);
        if (!rest.empty()) boxes.emplace_back(boxes.empty() ? std::string(sv::enginePageName(type, pg, variant)) : std::string("ОЩЕ"), rest);
    }
    const int nb = static_cast<int>(boxes.size());
    const float gap = 8.0F;
    const float halfW = (area.width() - gap) * 0.5F;
    for (int k = 0; k < nb; ++k) {
        RectF br;
        if (nb == 1) br = area;
        else if (nb == 2) br = RectF(area.left + static_cast<float>(k) * (halfW + gap), area.top, area.left + static_cast<float>(k) * (halfW + gap) + halfW, area.bottom);
        else {
            const int rows = (nb + 1) / 2;
            const float rh = (area.height() - gap * static_cast<float>(rows - 1)) / static_cast<float>(rows);
            const int row = k / 2, col = k % 2;
            const bool lastAlone = nb % 2 == 1 && k == nb - 1;
            const float top = area.top + static_cast<float>(row) * (rh + gap);
            br = lastAlone ? RectF(area.left, top, area.right, top + rh)
                           : RectF(area.left + static_cast<float>(col) * (halfW + gap), top, area.left + static_cast<float>(col) * (halfW + gap) + halfW, top + rh);
        }
        engineBox(c, br, u, boxes[static_cast<std::size_t>(k)].first, boxes[static_cast<std::size_t>(k)].second);
    }
}

} // namespace silveton::ui
