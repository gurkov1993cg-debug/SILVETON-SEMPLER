// SILVETON_ENGINES_V1 - the ENGINE page of an Upper (КОМБИ > ENGINE): one of the nine engines on the whole Upper.
// Top row: the engines (OFF · HD-1 · POLYSIX · MS-20 · AL-1 · MOD-7 · STR-1 · CX-3 · SGX · EP) and the three pages of the
// chosen one (ЗВУК = the engine's own knobs, ФИЛТЪР = the two filters and the filter envelope, МОД = LFO / unison / analog).
// Every knob: drag = turn, tap = exact number, right button / double tap = its starting value. The labels, ranges and
// starting values come from core/include/silveton/sampler/EngineDefs.h, so the screen and the sound can never disagree.
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>

namespace silveton::ui {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

// SILVETON_USER_WAVES_V1: a place USER n shows the name of the user's wave in it ("U2 STRINGS"), or "USER n НЯМА" when empty
std::string userWaveLabel(const std::string& s) {
    if (s.rfind("USER ", 0) != 0) return s;
    const int n = std::atoi(s.c_str() + 5);
    if (n < 1 || n > sv::kUserWaveCount) return s;
    const std::string nm = sv::userWaveName(n - 1);
    return nm.empty() ? s + " НЯМА" : "U" + std::to_string(n) + " " + nm;
}

std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return userWaveLabel(cur);
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, 6))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u, int id, float v) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, 6))];
    const bool ok = sampler.setUpperEngineParam(u, id, v);
    // the engine itself changed = its starting values were loaded: read everything again.
    // SILVETON_ENGINE_UPPER_ON_V1: choosing an engine on an empty Upper switches the Upper on in the engine - read the Upper
    // again too, or the next LEVEL / PAN / range move would send the old OFF back and the engine's sound would stop
    if (!ok || id == 0) { slot.reset(); refreshUpper(u); }
    // SILVETON_ENGINES_V3: the STR-1 INSTRUMENT loads its typical values - read them all again
    else if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && id == sv::ST_BODY_TYPE + 1) slot.reset();
    else {
        auto a = eParams(u);
        if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = v;
        slot = a;
    }
    invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v) - rndI(d.lo));   // SILVETON_OCTAVE_V1: a choice may start below 0 (ОКТАВА -2..+2) or at 1 (SUB OCT)
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = d.label;
    const std::string hint = d.hint;
    if (logKind(d)) {
        knobControl(c, cx, cy, rad, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
                    [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
                    [this, u, id, d, v, hint, pct] {
                        showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                                   [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
                    },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && d.id == sv::ST_STYLE)
        d.names = sv::str1StyleNames(rndI(engineP(u, sv::ST_BODY_TYPE + 1)));
    const int id = d.id + 1;
    const float v = engineP(u, id);
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    // SILVETON_PRO_UI_V1: the name above; a choice is a dark field with ▾, a switch a key that lights
    text(c, d.label, r.centerX(), r.top - 5.0F, 10.0F, C_KNOB_LABEL, Opt().center().bold().spacing(0.1F).maxW(r.width() + 8.0F));
    if (d.kind == EngineKind::Switch) proKey(c, r, engineValueText(d, v), on, 12.0F);
    else proField(c, r, engineValueText(d, v), 13.0F, true);
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — избери и свири · допир извън прозореца = затваряне";
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open while choosing and playing
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, darkTheme ? Color::rgb(16, 18, 16) : Color::rgb(40, 43, 48));
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, C_ACCENT);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 11.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 7.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    const RectF h(trackX - 14.0F, y - 9.0F, trackX + 14.0F, y + 9.0F);
    shadow(c, h, 4.0F, 2.0F, 70);
    fillV(c, h, 4.0F, Color::rgb(236, 238, 241), Color::rgb(201, 204, 209));
    text(c, std::to_string(v), trackX, y + 4.0F, 10.0F, Color::rgb(48, 52, 58), Opt().center().bold());
    text(c, d.label, trackX, r.bottom + 16.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold());
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- SILVETON_PRO_UI_V1: the ENGINE page on the whole screen
namespace {
struct Group { const char* title; std::vector<int> ids; };

// the boxes of every page: a title and the parameters in it (a parameter of the page not named here goes to a last box)
std::vector<Group> engineGroups(EngineType t, int page, int variant) {
    using namespace sv;
    if (page == 1) return {{"ФИЛТЪР 1", {E_FILT_TYPE, E_CUTOFF, E_RESO, E_KEYTRACK, E_DRIVE, E_VEL_CUT}},
                           {"ОБВИВКА НА ФИЛТЪРА", {E_FEG_AMT, E_FEG_A, E_FEG_D, E_FEG_S, E_FEG_R}},
                           {"ФИЛТЪР 2", {E_F2_TYPE, E_F2_CUT, E_F2_RES, E_F2_PAR}}};
    if (page == 2) return {{"LFO", {E_LFO_WAVE, E_LFO_RATE, E_LFO_PITCH, E_LFO_CUT, E_LFO_AMP}},
                           {"UNISON · ANALOG", {CX_WHEEL_ROT, E_UNISON, E_UNI_DET, E_UNI_SPREAD, E_ANALOG}}};
    if (page == 3) {
        switch (t) {
            case EngineType::MS20: return {{"КАБЕЛ 1", {MS_P1_SRC, MS_P1_DST, MS_P1_AMT}}, {"КАБЕЛ 2", {MS_P2_SRC, MS_P2_DST, MS_P2_AMT}},
                                           {"КАБЕЛ 3", {MS_P3_SRC, MS_P3_DST, MS_P3_AMT}}, {"S&H · ESP · МОДЕЛ", {MS_MODEL, MS_ROUTE, MS_SH_RATE, MS_ESP_SENS, MS_FB_SAT}}};
            case EngineType::AL1: return {{"OSC 1", {AL_OSC1_WAVE, AL_OSC1_LEVEL, AL_PW, AL_PWM}}, {"OSC 2", {AL_OSC2_WAVE, AL_OSC2_LEVEL, AL_OSC2_SEMI, AL_OSC2_FINE}},
                                          {"МОДУЛАЦИЯ", {AL_OSC_SYNC, AL_OSC_FM, AL_OSC_RING}}, {"ЗАПИС", {AL_REC_LEVEL}}};
            case EngineType::Mod7: return {{"АЛГОРИТЪМ · ИЗХОД", {M7_ALGO, M7_OVERSAMPLE, M7_OP_LEVEL, M7_PCM_LEVEL, M7_FINE}},
                                           {"ОПЕРАТОРИ 4 · 5 · 6", {M7_OP4_RATIO, M7_OP4_LEVEL, M7_OP5_RATIO, M7_OP5_LEVEL, M7_OP6_RATIO, M7_OP6_LEVEL}},
                                           {"ОБВИВКА НА МОДУЛАТОРИТЕ", {M7_ENV_A, M7_ENV_D, M7_ENV_S, M7_ENV_R, M7_ENV_AMT, M7_PEG, M7_PEG_TIME}},
                                           {"ВЪЛНИ НА ОПЕРАТОРИТЕ", {M7_OP2_WAVE, M7_OP3_WAVE, M7_OP4_WAVE, M7_OP5_WAVE, M7_OP6_WAVE}}};
            case EngineType::CX3: return {{"КОЛЕЛА", {CX_TUNING, CX_FOLDBACK, CX_TAPER}},
                                          {"LESLIE", {CX_DRUM_SLOW, CX_DRUM_FAST, CX_HORN_ACCEL, CX_DRUM_ACCEL, CX_MIC_DIST}}};
            case EngineType::Str1:
                if (variant >= ST_SAX_ALTO) return {{"ДЪХ", {ST_BOW_SPEED, ST_BOW_PRESS, ST_VEL_BOW, ST_BOW_NOISE, ST_GROWL}},
                                                    {"ОБВИВКА", {ST_BOW_ATTACK, ST_BOW_RELEASE}}, {"ВИБРАТО", {ST_VIBRATO, ST_VIB_RATE, ST_VIB_DELAY}}};
                return {{"ЛЪК", {ST_BOW_PRESS, ST_BOW_SPEED, ST_BOW_POS, ST_VEL_BOW, ST_BOW_NOISE}}, {"ОБВИВКА", {ST_BOW_ATTACK, ST_BOW_RELEASE, ST_TREM_RATE}},
                        {"ЛЯВА РЪКА", {ST_VIBRATO, ST_VIB_RATE, ST_VIB_DELAY}}};
            default: return {};
        }
    }
    switch (t) {
        case EngineType::HD1: return {{"ЗАПИС", {HD_INTERP, HD_BOOST}}, {"ВИСОЧИНА", {HD_PEG_CENTS, HD_PEG_TIME, HD_PEG_VEL}}};
        case EngineType::Polysix: return {{"ОСЦИЛАТОР", {P6_OSC, P6_OSC_LEVEL, P6_REC_LEVEL, P6_PWM_WIDTH, P6_PWM_DEPTH, P6_PWM_RATE}},
                                          {"SUB · НАСИЩАНЕ", {P6_SUB_OCT, P6_SUB_WAVE, P6_SUB_LEVEL, P6_FILT_SAT}},
                                          {"ЕФЕКТ", {P6_FX_TYPE, P6_FX_SPEED, P6_FX_DEPTH, P6_FX_MIX}}};
        case EngineType::MS20: return {{"VCO", {MS_VCO1_WAVE, MS_VCO2_WAVE, MS_VCO1_LEVEL, MS_VCO2_LEVEL, MS_VCO2_PITCH, MS_PW, MS_REC_LEVEL}},
                                       {"HPF", {MS_HPF_CUT, MS_HPF_PEAK, MS_MG_HPF}},
                                       {"EG1", {MS_EG1_DELAY, MS_EG1_ATTACK, MS_EG1_RELEASE, MS_EG1_PITCH, MS_EG1_HPF}},
                                       {"WHEEL", {MS_WHEEL_TO, MS_WHEEL_AMT}}};
        case EngineType::AL1: return {{"PCM FM", {AL_FM_AMT, AL_FM_RATIO, AL_FM_EG}}, {"PCM RING · SYNC", {AL_SYNC, AL_RING_LEVEL, AL_RING_RATIO, AL_SYNC_RATIO}},
                                      {"SUB · ШУМ · SHAPE", {AL_SUB_OCT, AL_SUB_LEVEL, AL_NOISE_LEVEL, AL_NOISE_COLOR, AL_SHAPE}}};
        case EngineType::Mod7: return {{"ОПЕРАТОРИ 2 · 3", {M7_OP3_TARGET, M7_OP2_RATIO, M7_OP2_LEVEL, M7_OP3_RATIO, M7_OP3_LEVEL}},
                                       {"FM", {M7_FEEDBACK, M7_FM_EG, M7_FM_VEL, M7_RING}}, {"SHAPER", {M7_WS_TYPE, M7_WS_DRIVE, M7_WS_MIX, M7_BRIGHT}}};
        case EngineType::Str1: return {{"ИНСТРУМЕНТ", {ST_BODY_TYPE, ST_STYLE, ST_BODY, ST_STRING, ST_TUNE}},
                                       {"ВЪЗБУЖДАНЕ", {ST_EXCITE, ST_EXC_LEN, ST_PLUCK, ST_PLUCK_COLOR, ST_PICK, ST_PICKUP}},
                                       {"СТРУНА", {ST_DECAY, ST_DAMP, ST_DISP, ST_FEEDBACK, ST_NONLIN, ST_KEY_DECAY}}};
        case EngineType::CX3: return {{"DRAWBARS", {CX_DB16, CX_DB513, CX_DB8, CX_DB4, CX_DB223, CX_DB2, CX_DB135, CX_DB113, CX_DB1}},
                                      {"ПЕРКУСИЯ", {CX_PERC, CX_PERC_DECAY, CX_PERC_LEVEL, CX_CLICK, CX_LEAK}},
                                      {"LESLIE", {CX_ROTARY, CX_SLOW, CX_FAST, CX_HORN, CX_AMP_DRIVE}}, {"ОРГАН", {CX_VIBCHO, CX_SAMPLE}}};
        case EngineType::SGX: return {{"РЕЗОНАНС", {SG_STRING_RES, SG_DAMPER_RES, SG_RES_RELEASE, SG_SYMP_LIMIT}}, {"КОРПУС", {SG_BODY_TYPE, SG_BODY, SG_LID, SG_WIDTH}},
                                      {"ПЕДАЛ", {SG_HALF_PEDAL, SG_DAMPER_TIME, SG_UNA_CORDA}}, {"ШУМОВЕ", {SG_HAMMER, SG_KEYOFF, SG_KEYOFF_TONE, SG_VEL_BRIGHT}}};
        case EngineType::EP: return {{"ЕЗИЧЕ", {EP_TYPE, EP_MODEL, EP_REC_LEVEL, EP_TINE_DECAY, EP_INHARM, EP_HAMMER}},
                                     {"ПИКЪП", {EP_PICKUP_DRIVE, EP_PICKUP_SYM, EP_BELL, EP_BARK, EP_KEYOFF}},
                                     {"УСИЛВАТЕЛ", {EP_CAB, EP_PRE_DRIVE, EP_BASS, EP_TREBLE, EP_CAB_DRIVE}},
                                     {"ТРЕМОЛО", {EP_TREM, EP_TREM_SPEED, EP_TREM_DEPTH, EP_TREM_STEREO}}};
        default: return {};
    }
}

ColorInt engineColor(int type) {
    static const ColorInt cols[10] = {Color::rgb(150, 158, 168), Color::rgb(74, 163, 255), Color::rgb(255, 138, 61), Color::rgb(232, 232, 232), Color::rgb(176, 124, 255),
                                      Color::rgb(63, 193, 201), Color::rgb(240, 163, 90), Color::rgb(232, 96, 80), Color::rgb(216, 195, 138), Color::rgb(107, 212, 122)};
    return cols[std::clamp(type, 0, 9)];
}

const char* engineShort(int type) {
    static const char* const names[10] = {"", "ЗАПИС + ФИЛТРИ", "АНАЛОГОВ ПОЛИ", "АНАЛОГ С КАБЕЛИ", "АНАЛОГОВ СИНТ", "FM · 6 ОПЕРАТОРА",
                                          "СТРУНИ И ДУХОВИ", "ОРГАН", "АКУСТ. ПИАНО", "ЕЛ. ПИАНО"};
    return names[std::clamp(type, 0, 9)];
}

// one period of a basic wave, -1..1 (the name of the wave decides; anything else is a richer table wave)
float waveAt(const std::string& name, float ph, float pw) {
    ph -= std::floor(ph);
    const std::string n = name;
    if (n == "OFF" || n.empty()) return 0.0F;
    if (n.find("SAW") != std::string::npos || n.find("RAMP") != std::string::npos) return 1.0F - 2.0F * ph;
    if (n.find("SQU") != std::string::npos || n.find("PUL") != std::string::npos || n.find("PWM") != std::string::npos) return ph < pw ? 0.85F : -0.85F;
    if (n.find("TRI") != std::string::npos) return ph < 0.5F ? 4.0F * ph - 1.0F : 3.0F - 4.0F * ph;
    if (n.find("SIN") != std::string::npos) return std::sin(6.2831853F * ph);
    // a table wave: a few partials (stable, so the picture does not shimmer)
    unsigned h = 2166136261U;
    for (const char ch : name) h = (h ^ static_cast<unsigned char>(ch)) * 16777619U;
    float v = 0.0F;
    for (int k = 1; k <= 6; ++k) {
        const float a = static_cast<float>((h >> (k * 4)) & 15U) / 15.0F / static_cast<float>(k);
        v += a * std::sin(6.2831853F * ph * static_cast<float>(k) + static_cast<float>(k) * 0.7F);
    }
    return std::clamp(v * 0.75F, -1.0F, 1.0F);
}
} // namespace

void SilvetonSamplerView::drawEngineVis(Canvas& c, const RectF& r, int u, int typeIx) {
    const auto type = static_cast<EngineType>(typeIx);
    const ColorInt acc = engineColor(typeIx);
    fill(c, r, 6.0F, Color::rgb(2, 3, 4));
    fill(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 5.0F, Color::rgb(7, 10, 12));
    for (int k = 1; k < 8; ++k) {
        const float x = r.left + r.width() * static_cast<float>(k) / 8.0F;
        line(c, x, r.top + 2.0F, x, r.bottom - 2.0F, Color::rgb(18, 26, 32), 1.0F);
    }
    for (int k = 1; k < 4; ++k) {
        const float y = r.top + r.height() * static_cast<float>(k) / 4.0F;
        line(c, r.left + 2.0F, y, r.right - 2.0F, y, Color::rgb(18, 26, 32), 1.0F);
    }
    const auto par = [&](int id) { return engineP(u, id + 1); };
    const auto choice = [&](int id) -> std::string {
        const EngineParamDef* d = sv::engineParamDef(type, id);
        return d != nullptr ? choiceName(*d, rndI(par(id)) - rndI(d->lo)) : std::string();
    };
    const auto curve = [&](const std::function<float(float)>& f, float top, float bottom, ColorInt col, float width) {
        Path p;
        const int n = 160;
        for (int i = 0; i <= n; ++i) {
            const float t = static_cast<float>(i) / static_cast<float>(n);
            const float v = std::clamp(f(t), -1.0F, 1.0F);
            const float x = r.left + 6.0F + t * (r.width() - 12.0F);
            const float y = (top + bottom) * 0.5F - v * (bottom - top) * 0.42F;
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        Paint pp;
        pp.antiAlias = true;
        pp.style = Style::Stroke;
        pp.strokeWidth = width;
        pp.color = colorWithAlpha(col, 60);
        pp.strokeWidth = width + 4.0F;
        c.drawPath(p, pp);
        pp.color = col;
        pp.strokeWidth = width;
        c.drawPath(p, pp);
    };
    const auto label = [&](const std::string& s, float y, ColorInt col, bool right = false) {
        text(c, s, right ? r.right - 10.0F : r.left + 10.0F, y, 11.0F, col, (right ? Opt().right() : Opt()).mono().maxW(r.width() - 20.0F));
    };
    switch (type) {
        case EngineType::Off:
            text(c, "БЕЗ ДВИГАТЕЛ", r.centerX(), r.centerY() - 4.0F, 18.0F, Color::rgb(150, 158, 168), Opt().center().bold().spacing(0.1F));
            text(c, "чист запис, както досега", r.centerX(), r.centerY() + 20.0F, 12.0F, Color::rgb(108, 118, 130), Opt().center());
            break;
        case EngineType::HD1: {
            const float fc = std::clamp(par(sv::E_CUTOFF), 20.0F, 20000.0F);
            const float q = 0.707F + std::clamp(par(sv::E_RESO), 0.0F, 1.0F) * 7.0F;
            const int ft = rndI(par(sv::E_FILT_TYPE));
            const auto resp = [fc, q, ft](float t) {
                const float f = 20.0F * std::pow(1000.0F, t);
                const float w = f / fc;
                const float g2 = 1.0F / std::sqrt((1.0F - w * w) * (1.0F - w * w) + (w / q) * (w / q));
                float g = g2;
                if (ft == 1 || ft == 2) g = g2 * g2 * (ft == 2 ? 0.8F : 1.0F);
                else if (ft == 4) g = g2 * w * w;
                else if (ft == 5) g = g2 * w / q;
                else if (ft == 0) g = 1.0F;
                const float db = 20.0F * std::log10(std::max(g, 1e-6F));
                return std::clamp((db + 24.0F) / 36.0F * 2.0F - 1.0F, -1.0F, 1.0F);
            };
            curve(resp, r.top + 18.0F, r.bottom - 8.0F, acc, 2.5F);
            label(choice(sv::E_FILT_TYPE) + " · " + engineValueText(*sv::engineParamDef(type, sv::E_CUTOFF), fc), r.top + 18.0F, acc);
            label("20 Hz", r.bottom - 8.0F, Color::rgb(108, 118, 130));
            label("20 kHz", r.bottom - 8.0F, Color::rgb(108, 118, 130), true);
            break;
        }
        case EngineType::Polysix: {
            const std::string w = choice(sv::P6_OSC);
            const float pw = std::clamp(par(sv::P6_PWM_WIDTH), 0.05F, 0.95F);
            curve([w, pw](float t) { return waveAt(w, t * 4.0F, pw); }, r.top + 20.0F, r.bottom - 10.0F, acc, 2.5F);
            label("OSC · " + w, r.top + 18.0F, acc);
            label("SUB " + choice(sv::P6_SUB_OCT), r.bottom - 8.0F, Color::rgb(150, 158, 168), true);
            break;
        }
        case EngineType::MS20: {
            const std::string w1 = choice(sv::MS_VCO1_WAVE), w2 = choice(sv::MS_VCO2_WAVE);
            const float pw = std::clamp(par(sv::MS_PW), 0.05F, 0.95F);
            const float mid = r.centerY();
            curve([w1, pw](float t) { return waveAt(w1, t * 4.0F, pw); }, r.top + 18.0F, mid, acc, 2.2F);
            curve([w2, pw](float t) { return waveAt(w2, t * 4.0F * 1.5F, pw); }, mid + 4.0F, r.bottom - 8.0F, C_PRO_AMBER, 2.0F);
            label("VCO 1 · " + w1, r.top + 18.0F, acc);
            label("VCO 2 · " + w2, mid + 16.0F, C_PRO_AMBER);
            break;
        }
        case EngineType::AL1: {
            const std::string w1 = choice(sv::AL_OSC1_WAVE), w2 = choice(sv::AL_OSC2_WAVE);
            const float pw = std::clamp(par(sv::AL_PW), 0.05F, 0.95F);
            const float semi = par(sv::AL_OSC2_SEMI);
            const float ratio = std::pow(2.0F, semi / 12.0F);
            const float mid = r.centerY();
            curve([w1, pw](float t) { return waveAt(w1, t * 4.0F, pw); }, r.top + 18.0F, mid, acc, 2.2F);
            curve([w2, pw, ratio](float t) { return waveAt(w2, t * 4.0F * ratio, pw); }, mid + 4.0F, r.bottom - 8.0F, C_PRO_AMBER, 2.0F);
            label("OSC 1 · " + w1, r.top + 18.0F, acc);
            label("OSC 2 · " + w2, mid + 16.0F, C_PRO_AMBER);
            break;
        }
        case EngineType::Mod7: {
            const float bw = r.width() * 0.2F, bh = r.height() * 0.22F;
            const float y1 = r.top + r.height() * 0.22F, y2 = r.top + r.height() * 0.58F;
            for (int k = 0; k < 3; ++k) {
                const float cx = r.left + r.width() * (0.2F + 0.3F * static_cast<float>(k));
                line(c, cx, y1 + bh, cx, y2, Color::rgb(108, 118, 130), 2.0F);
                const RectF m(cx - bw * 0.5F, y1, cx + bw * 0.5F, y1 + bh);
                const RectF ca(cx - bw * 0.5F, y2, cx + bw * 0.5F, y2 + bh);
                fill(c, m, 6.0F, Color::rgb(20, 36, 58));
                fill(c, ca, 6.0F, Color::rgb(58, 42, 16));
                text(c, "OP " + std::to_string(2 + 2 * k), m.centerX(), m.centerY() + 5.0F, 13.0F, Color::rgb(111, 183, 255), Opt().center().bold());
                text(c, "OP " + std::to_string(1 + 2 * k), ca.centerX(), ca.centerY() + 5.0F, 13.0F, C_PRO_AMBER, Opt().center().bold());
            }
            label("ALGORITHM · " + choice(sv::M7_ALGO), r.bottom - 8.0F, acc);
            break;
        }
        case EngineType::Str1: {
            const std::string ins = choice(sv::ST_BODY_TYPE);
            text(c, ins, r.centerX(), r.top + 44.0F, 24.0F, acc, Opt().center().bold().spacing(0.08F).maxW(r.width() - 20.0F));
            text(c, choice(sv::ST_STYLE), r.centerX(), r.top + 64.0F, 12.0F, Color::rgb(150, 158, 168), Opt().center().mono());
            curve([](float t) { return std::exp(-t * 3.0F) * std::sin(t * 70.0F) * 0.9F; }, r.top + 74.0F, r.bottom - 8.0F, acc, 2.0F);
            break;
        }
        case EngineType::CX3: {
            static const ColorInt cols[9] = {Color::rgb(139, 90, 43), Color::rgb(139, 90, 43), Color::rgb(232, 230, 222), Color::rgb(232, 230, 222), Color::rgb(30, 30, 32),
                                             Color::rgb(232, 230, 222), Color::rgb(30, 30, 32), Color::rgb(30, 30, 32), Color::rgb(232, 230, 222)};
            static const char* const feet[9] = {"16'", "5⅓'", "8'", "4'", "2⅔'", "2'", "1⅗'", "1⅓'", "1'"};
            const float cw = (r.width() - 20.0F) / 9.0F;
            for (int k = 0; k < 9; ++k) {
                const int v = std::clamp(rndI(par(sv::CX_DB16 + k)), 0, 8);
                const float cx = r.left + 10.0F + cw * (static_cast<float>(k) + 0.5F);
                const float top = r.top + 12.0F, bot = r.bottom - 26.0F;
                fill(c, RectF(cx - 7.0F, top, cx + 7.0F, bot), 3.0F, Color::rgb(0, 0, 0));
                const float y = top + (bot - top) * static_cast<float>(v) / 8.0F;
                if (v > 0) fill(c, RectF(cx - 5.0F, top, cx + 5.0F, y), 2.0F, colorWithAlpha(cols[k], 200));
                fill(c, RectF(cx - 10.0F, y - 9.0F, cx + 10.0F, y + 9.0F), 3.0F, cols[k]);
                text(c, std::to_string(v), cx, y + 4.0F, 10.0F, (k == 4 || k == 6 || k == 7 || k < 2) ? Color::WHITE : Color::rgb(30, 30, 32), Opt().center().bold());
                text(c, feet[k], cx, r.bottom - 8.0F, 9.5F, Color::rgb(150, 158, 168), Opt().center().mono());
            }
            break;
        }
        case EngineType::SGX: {
            const RectF kb(r.left + 10.0F, r.top + 16.0F, r.right - 10.0F, r.top + r.height() * 0.62F);
            drawMiniKeyboard(c, kb, 48, 72);
            label("BODY · " + choice(sv::SG_BODY_TYPE), r.bottom - 10.0F, acc);
            label(par(sv::SG_HALF_PEDAL) >= 0.5F ? "HALF PEDAL ON" : "HALF PEDAL OFF", r.bottom - 10.0F, Color::rgb(150, 158, 168), true);
            break;
        }
        case EngineType::EP: {
            const float dec = std::clamp(par(sv::EP_TINE_DECAY), 0.2F, 12.0F);
            curve([dec](float t) { return std::exp(-t * 6.0F / dec) * std::sin(t * 60.0F) * 0.95F; }, r.top + 20.0F, r.bottom - 10.0F, acc, 2.2F);
            label("TYPE · " + choice(sv::EP_TYPE), r.top + 18.0F, acc);
            break;
        }
        case EngineType::Suse: break;   // SILVETON_SUSE_V1: SILVETON SYNTH has screens of its own (classic view)
    }
}

// one box of parameters: the choices on top, the drawbars / knobs under them, spread evenly over the box
void SilvetonSamplerView::engineBox(Canvas& c, const RectF& r, int u, const std::string& title, const std::vector<const EngineParamDef*>& items) {
    proPanel(c, r, title);
    std::vector<const EngineParamDef*> choices, bars, knobs;
    for (const EngineParamDef* d : items) {
        if (d->kind == EngineKind::Choice || d->kind == EngineKind::Switch) choices.push_back(d);
        else if (d->kind == EngineKind::Drawbar) bars.push_back(d);
        else knobs.push_back(d);
    }
    const RectF in(r.left + 10.0F, r.top + 28.0F, r.right - 10.0F, r.bottom - 8.0F);
    float y = in.top;
    if (!choices.empty()) {
        const int n = static_cast<int>(choices.size());
        const float cw = std::min(176.0F, (in.width() - static_cast<float>(n - 1) * 12.0F) / static_cast<float>(n));
        const float gap = (in.width() - cw * static_cast<float>(n)) / static_cast<float>(n + 1);
        for (int k = 0; k < n; ++k) {
            const float l = in.left + gap + static_cast<float>(k) * (cw + gap);
            engineKey(c, RectF(l, y + 16.0F, l + cw, y + 48.0F), u, *choices[static_cast<std::size_t>(k)]);
        }
        y += 58.0F;
    }
    if (!bars.empty()) {
        const int n = static_cast<int>(bars.size());
        const float cw = in.width() / static_cast<float>(n);
        const float bh = std::min(200.0F, in.bottom - y - 30.0F);
        for (int k = 0; k < n; ++k) {
            const float cx = in.left + cw * (static_cast<float>(k) + 0.5F);
            engineDrawbar(c, RectF(cx - 16.0F, y + 6.0F, cx + 16.0F, y + 6.0F + bh), u, *bars[static_cast<std::size_t>(k)]);
        }
        y += bh + 30.0F;
    }
    if (knobs.empty()) return;
    const int n = static_cast<int>(knobs.size());
    const float h = in.bottom - y;
    const int maxCols = std::max(1, static_cast<int>(in.width() / 92.0F));
    int cols = std::min(n, maxCols);
    int rows = (n + cols - 1) / cols;
    while (rows > 1 && h / static_cast<float>(rows) < 96.0F && cols < n) { ++cols; rows = (n + cols - 1) / cols; }
    const float cellW = in.width() / static_cast<float>(cols);
    const float cellH = h / static_cast<float>(rows);
    const float rad = std::clamp(std::min(cellW * 0.22F, (cellH - 64.0F) * 0.5F), 13.0F, 30.0F);   // SILVETON_UI_KRONOS_V1: the page is wide - bigger knobs
    for (int k = 0; k < n; ++k) {
        const int row = k / cols;
        const int col = k % cols;
        const int inRow = row == rows - 1 ? n - row * cols : cols;
        const float rowLeft = in.left + (in.width() - cellW * static_cast<float>(inRow)) * 0.5F;
        const float cx = rowLeft + cellW * (static_cast<float>(col) + 0.5F);
        const float cy = y + cellH * (static_cast<float>(row) + 0.5F) - (8.5F - 0.21F * rad);
        engineKnob(c, cx, cy, rad, std::min(cellW - 6.0F, 140.0F), u, *knobs[static_cast<std::size_t>(k)]);
    }
}

// PITCH BEND like the TRANSPOSE: ◀ the value ▶ (OFF / UPPER / 1..24 semitones); a tap on the value = the number
void SilvetonSamplerView::engineBend(Canvas& c, const RectF& r, int u, int id, const std::string& lab) {
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id);
    text(c, lab, r.left, r.centerY() + 4.0F, 11.0F, C_KNOB_LABEL, Opt().bold().spacing(0.1F));
    const RectF left(r.left + 70.0F, r.top, r.left + 120.0F, r.bottom);
    const RectF right(r.right - 50.0F, r.top, r.right, r.bottom);
    const RectF val(left.right + 6.0F, r.top, right.left - 6.0F, r.bottom);
    if (d == nullptr) {
        proField(c, val, "—", 15.0F);
        return;
    }
    const int hid = id + 1;
    const float v = engineP(u, hid);
    proKey(c, left, "◀", false, 15.0F);
    proKey(c, right, "▶", false, 15.0F);
    fill(c, val, 5.0F, Color::rgb(5, 6, 8));
    fill(c, RectF(val.left + 1.0F, val.top + 1.0F, val.right - 1.0F, val.bottom - 1.0F), 4.0F, Color::rgb(15, 18, 21));
    text(c, engineValueText(*d, v), val.centerX(), val.centerY() + 6.0F, 17.0F, Color::rgb(241, 243, 245), Opt().center().monoBold());
    const float lo = d->lo, hi = d->hi, def = d->def;
    hit(left, [this, u, hid, v, lo](float, float) { setEngineP(u, hid, std::max(lo, std::round(v) - 1.0F)); }, [this, u, hid, def] { setEngineP(u, hid, def); });
    hit(right, [this, u, hid, v, hi](float, float) { setEngineP(u, hid, std::min(hi, std::round(v) + 1.0F)); }, [this, u, hid, def] { setEngineP(u, hid, def); });
    const std::string hint = d->hint;
    hit(val, [this, u, hid, v, lo, hi, hint](float, float) { showNumber(hint, v, lo, hi, 0, [this, u, hid](float x) { setEngineP(u, hid, std::round(x)); }); },
        [this, u, hid, def] { setEngineP(u, hid, def); });
}

// SILVETON_UI_KRONOS_V1: the ENGINE screen built as pages, one thing on each page (like the pages of a workstation):
//   ДВИГАТЕЛ (choose the engine, the sound source, ON / OFF) · the pages of the engine (ЗВУК, ФИЛТЪР, МОД ...) · ИЗХОД (level, pan, bend) · OFS.
// The Upper keys stay at the right of the page row. Nothing else is on the screen - no numbered boxes, no side column.
void SilvetonSamplerView::drawEnginePage(Canvas& c, int u) {
    using sv::engineName;
    constexpr int kPgSelect = 100, kPgOutput = 101;
    u = std::clamp(u, 0, 6);
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
    const bool on = type != EngineType::Off && !bypassed;
    const int pageCount = type == EngineType::Off ? 0 : std::max(1, sv::enginePageCount(type));   // SILVETON_OFS_V1: pageCount = the OFS page
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the ДЪХ page
    int pg = enginePage_;
    if (pg != kPgSelect && pg != kPgOutput && (type == EngineType::Off || pg < 0 || pg > pageCount)) pg = type == EngineType::Off ? kPgSelect : 0;
    enginePage_ = pg;
    const RectF area(10.0F, 128.0F, 1330.0F, 736.0F);

    // the row of pages and the Upper keys
    {
        std::vector<std::pair<int, std::string>> tabs;
        tabs.emplace_back(kPgSelect, "ДВИГАТЕЛ");
        for (int k = 0; k < pageCount; ++k) tabs.emplace_back(k, sv::enginePageName(type, k, variant));
        tabs.emplace_back(kPgOutput, "ИЗХОД");
        if (type != EngineType::Off) tabs.emplace_back(pageCount, "OFS");
        float x = 10.0F;
        for (const auto& t : tabs) {
            const RectF pr(x, 82.0F, x + 118.0F, 122.0F);
            proKey(c, pr, t.second, pg == t.first, 13.0F);
            const int id = t.first;
            hit(pr, [this, id](float, float) { enginePage_ = id; invalidate(); });
            x += 122.0F;
        }
        const float uw = 40.0F, ux0 = 1330.0F - 7.0F * uw - 6.0F * 4.0F;
        for (int k = 0; k < 7; ++k) {
            const RectF kr(ux0 + static_cast<float>(k) * (uw + 4.0F), 82.0F, ux0 + static_cast<float>(k) * (uw + 4.0F) + uw, 122.0F);
            const int tk = std::clamp(rndI(engineP(k, 0)), 0, sv::kEngineTypeCount - 1);
            proKey(c, kr, "U" + std::to_string(k + 1), k == u, 12.0F);
            if (tk != 0) fill(c, RectF(kr.right - 9.0F, kr.top + 4.0F, kr.right - 4.0F, kr.top + 9.0F), 2.5F, engineColor(tk));
            hit(kr, [this, k](float, float) { selectedUpper_ = k; invalidate(); });
        }
    }

    // page ДВИГАТЕЛ: the engines (big keys), the source of the sound, ON / OFF, and what the chosen engine is
    if (pg == kPgSelect) {
        // SILVETON_ONLY_V1: the old engines are not used any more - the page has only SILVETON SYNTH (the key below: no engine)
        {
            const int t = static_cast<int>(EngineType::Suse);
            const RectF kr(22.0F, 140.0F, 796.0F, 244.0F);
            const bool sel = typeIx == t;
            proKey(c, kr, "", sel, 12.0F);
            text(c, engineName(EngineType::Suse), kr.centerX(), kr.centerY() + 9.0F, 24.0F, sel ? Color::WHITE : Color::rgb(228, 231, 235), Opt().center().bold().maxW(kr.width() - 12.0F));
            hit(kr, [this, u, t, typeIx](float, float) {
                if (t != typeIx) setEngineP(u, 0, static_cast<float>(t));
                invalidate();
            });
        }
        {
            const RectF kr(22.0F, 452.0F, 796.0F, 506.0F);
            const bool sel = typeIx == 0;
            proKey(c, kr, "НЯМА ДВИГАТЕЛ · ЧИСТ ЗАПИС", sel, 13.0F);
            hit(kr, [this, u, typeIx](float, float) {
                if (typeIx != 0) setEngineP(u, 0, 0.0F);
                invalidate();
            });
        }
        {   // what the chosen engine is
            const RectF b(22.0F, 520.0F, 796.0F, 728.0F);
            proPanel(c, b, "");
            text(c, type == EngineType::Off ? std::string("НЯМА ДВИГАТЕЛ") : std::string(engineName(type)), b.left + 16.0F, b.top + 44.0F, 28.0F, engineColor(typeIx), Opt().bold().spacing(0.08F));
            if (type != EngineType::Off) {
                text(c, engineShort(typeIx), b.left + 16.0F, b.top + 70.0F, 12.0F, Color::rgb(139, 149, 161), Opt().spacing(0.1F));
                text(c, sv::engineLine(type), b.left + 16.0F, b.top + 104.0F, 13.0F, Color::rgb(176, 188, 202), Opt().maxW(b.width() - 32.0F));
            } else {
                text(c, "Избери двигател. Той работи върху записите на целия Upper (ОСНОВЕН + L1..L4), нота по нота.", b.left + 16.0F, b.top + 82.0F, 13.0F, C_HINT, Opt().maxW(b.width() - 32.0F));
                text(c, "НЯМА = чист запис, както досега. Настройките се пазят в блендата / сета.", b.left + 16.0F, b.top + 106.0F, 13.0F, C_HINT, Opt().maxW(b.width() - 32.0F));
            }
        }
        {   // the source of the sound
            const RectF b(830.0F, 140.0F, 1330.0F, 396.0F);
            proPanel(c, b, "ЗВУК ОТ");
            const bool hasSource = type != EngineType::Off && sv::engineParamDef(type, sv::E_SOURCE) != nullptr;
            if (!hasSource) {
                text(c, type == EngineType::Off ? "САМО СЕМПЪЛ" : "САМО СЕМПЪЛ · двигателят обработва записа", b.centerX(), b.centerY() + 6.0F, 13.0F, Color::rgb(130, 140, 152),
                     Opt().center().bold().maxW(b.width() - 24.0F));
            } else {
                const int src = std::clamp(rndI(engineP(u, sv::E_SOURCE + 1)), 0, 2);
                static const char* const names[3] = {"ДВИГАТЕЛ\n+ СЕМПЪЛ", "САМО\nДВИГАТЕЛ", "САМО\nСЕМПЪЛ"};
                for (int k = 0; k < 3; ++k) {
                    const RectF kr(844.0F, 168.0F + static_cast<float>(k) * 74.0F, 1316.0F, 168.0F + static_cast<float>(k) * 74.0F + 64.0F);
                    std::string a = uiLang_ != 0 ? tr(names[k]) : std::string(names[k]);
                    for (char& ch : a) if (ch == '\n') ch = ' ';
                    proKey(c, kr, a, src == k, 15.0F);
                    hit(kr, [this, u, k](float, float) { setEngineP(u, sv::E_SOURCE + 1, static_cast<float>(k)); });
                }
            }
        }
        {   // ON / OFF (OFF = the plain recording; every setting stays)
            const RectF b(830.0F, 410.0F, 1330.0F, 518.0F);
            proPanel(c, b, "ДВИГАТЕЛ", "UPPER " + std::to_string(u + 1));
            if (type == EngineType::Off) {
                text(c, "избери двигател", b.centerX(), b.centerY() + 12.0F, 13.0F, Color::rgb(130, 140, 152), Opt().center());
            } else {
                const RectF kOn(844.0F, 438.0F, 1068.0F, 504.0F), kOff(1092.0F, 438.0F, 1316.0F, 504.0F);
                proKey(c, kOn, "ВКЛЮЧЕН", on, 15.0F, C_PLAY);
                proKey(c, kOff, "ИЗКЛЮЧЕН", !on, 15.0F);
                hit(kOn, [this, u](float, float) { setEngineP(u, sv::E_BYPASS + 1, 0.0F); });
                hit(kOff, [this, u](float, float) { setEngineP(u, sv::E_BYPASS + 1, 1.0F); });
            }
        }
        {   // the picture of the engine
            const RectF b(830.0F, 532.0F, 1330.0F, 728.0F);
            proPanel(c, b, "");
            if (type != EngineType::Off) drawEngineVis(c, RectF(842.0F, 544.0F, 1318.0F, 720.0F), u, typeIx);
        }
        return;
    }

    // page ИЗХОД: level, pan and the pitch bend of the Upper
    if (pg == kPgOutput) {
        proPanel(c, RectF(area.left, area.top + 100.0F, area.right, area.top + 430.0F), "ИЗХОД", "UPPER " + std::to_string(u + 1));
        auto& slot = upperStates[static_cast<std::size_t>(u)];
        if (!slot) slot = sampler.upperState(u);
        if (slot) {
            const UpperState s = *slot;
            const std::function<void(float)> setLevel = [this, u, s](float t) {
                const auto& sl = upperStates[static_cast<std::size_t>(u)];
                UpperState cur = sl ? *sl : s;
                cur.levelDb = quantizeControl(faderDb(t), -60.0F, 12.0F, 0.1F);
                commitMain(u, cur);
            };
            knobControl(c, 210.0F, 358.0F, 40.0F, faderT(s.levelDb), 0.0F, 1.0F, 0.002F, 250.0F, false, dbText(s.levelDb), "LEVEL", 170.0F, setLevel,
                        [this, u, s] {
                            showNumber("UPPER " + std::to_string(u + 1) + " LEVEL dB", s.levelDb, -60.0F, 12.0F, 1, [this, u, s](float nv) {
                                const auto& sl = upperStates[static_cast<std::size_t>(u)];
                                UpperState cur = sl ? *sl : s;
                                cur.levelDb = nv;
                                commitMain(u, cur);
                            });
                        },
                        [this, u, s] { const auto& sl = upperStates[static_cast<std::size_t>(u)]; UpperState cur = sl ? *sl : s; cur.levelDb = 0.0F; commitMain(u, cur); });
            const std::function<void(float)> setPan = [this, u, s](float nv) {
                const auto& sl = upperStates[static_cast<std::size_t>(u)];
                UpperState cur = sl ? *sl : s;
                cur.pan = nv;
                commitMain(u, cur);
            };
            knobControl(c, 480.0F, 358.0F, 40.0F, s.pan, -1.0F, 1.0F, 0.01F, 160.0F, true, panText(s.pan), "PAN", 170.0F, setPan,
                        [this, u, s, setPan] { showNumber("UPPER " + std::to_string(u + 1) + " PAN", s.pan, -1.0F, 1.0F, 2, [setPan](float nv) { setPan(nv); }); },
                        [setPan] { setPan(0.0F); });
        }
        text(c, "PITCH BEND", 840.0F, 290.0F, 12.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
        engineBend(c, RectF(720.0F, 312.0F, 1300.0F, 362.0F), u, sv::E_BEND_UP, "НАГОРЕ");
        engineBend(c, RectF(720.0F, 382.0F, 1300.0F, 432.0F), u, sv::E_BEND_DOWN, "НАДОЛУ");
        return;
    }

    if (pg == pageCount) { drawOfsPage(c, area, u); return; }   // SILVETON_OFS_V1
    const EngineParamPage page = sv::enginePage(type, std::clamp(pg, 0, pageCount - 1), variant);
    if (page.count <= 0 || page.items == nullptr) return;
    // the boxes of this page; the source key and the bends live on their own pages
    std::vector<Group> groups = engineGroups(type, pg, variant);
    std::vector<std::pair<std::string, std::vector<const EngineParamDef*>>> boxes;
    std::vector<bool> used(static_cast<std::size_t>(page.count), false);
    for (int i = 0; i < page.count; ++i) {
        const int id = page.items[i].id;
        if (id == sv::E_SOURCE || id == sv::E_BEND_UP || id == sv::E_BEND_DOWN) used[static_cast<std::size_t>(i)] = true;
    }
    for (const Group& g : groups) {
        std::vector<const EngineParamDef*> items;
        for (const int id : g.ids) {
            for (int i = 0; i < page.count; ++i) {
                if (page.items[i].id == id && !used[static_cast<std::size_t>(i)]) { items.push_back(&page.items[i]); used[static_cast<std::size_t>(i)] = true; }
            }
        }
        if (!items.empty()) boxes.emplace_back(g.title, items);
    }
    {
        std::vector<const EngineParamDef*> rest;
        for (int i = 0; i < page.count; ++i) if (!used[static_cast<std::size_t>(i)]) rest.push_back(&page.items[i]);
        if (!rest.empty()) boxes.emplace_back(boxes.empty() ? std::string(sv::enginePageName(type, pg, variant)) : std::string("ОЩЕ"), rest);
    }
    const int nb = static_cast<int>(boxes.size());
    const float gap = 8.0F;
    const float halfW = (area.width() - gap) * 0.5F;
    for (int k = 0; k < nb; ++k) {
        RectF br;
        if (nb == 1) br = area;
        else if (nb == 2) br = RectF(area.left + static_cast<float>(k) * (halfW + gap), area.top, area.left + static_cast<float>(k) * (halfW + gap) + halfW, area.bottom);
        else {
            const int rows = (nb + 1) / 2;
            const float rh = (area.height() - gap * static_cast<float>(rows - 1)) / static_cast<float>(rows);
            const int row = k / 2, col = k % 2;
            const bool lastAlone = nb % 2 == 1 && k == nb - 1;
            const float top = area.top + static_cast<float>(row) * (rh + gap);
            br = lastAlone ? RectF(area.left, top, area.right, top + rh)
                           : RectF(area.left + static_cast<float>(col) * (halfW + gap), top, area.left + static_cast<float>(col) * (halfW + gap) + halfW, top + rh);
        }
        engineBox(c, br, u, boxes[static_cast<std::size_t>(k)].first, boxes[static_cast<std::size_t>(k)].second);
    }
}

} // namespace silveton::ui
