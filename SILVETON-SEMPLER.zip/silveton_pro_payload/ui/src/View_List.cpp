// SILVETON_MAC_VIEW_V1 - the LIST page (tablet SilvetonSamplerView.kt lines 2053-2333)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
std::string pad3(long long v) { return fmtZeroPad(v, 3); }
bool containsIgnoreCase(const std::string& text, const std::string& part) {
    return utf8Upper(text).find(utf8Upper(part)) != std::string::npos;
}
} // namespace

// SILVETON_LIST_GRID_V1: the LIST like the BLENDS picker - pages of 20 (4 x 5).
// Tap a BLEND = play it. Tap an empty place = choose it for STORE.
// STORE writes the COMBI that sounds now to the chosen place (asks before writing over a BLEND). EDIT opens the chosen BLEND in COMBI.
// SILVETON_LIST_V2: 30 BLENDS a page (5 x 6), 7 page keys, favourites and search,
// one row of big keys for thick fingers (TRANSPOSE - [0] + : both at once = 0).
std::vector<int> SilvetonSamplerView::listVisible() {
    std::vector<int> out;
    for (int i = 0; i < LIST_SIZE; ++i) {
        if (!listSearch.empty()) {
            const auto item = realListItem(i);
            if (item && containsIgnoreCase(item->name, listSearch)) out.push_back(i);
        } else if (listFavOnly) {
            if (listFavs.count(i) != 0 && realListItem(i)) out.push_back(i);
        } else {
            out.push_back(i);
        }
    }
    return out;
}

void SilvetonSamplerView::drawList(Canvas& c) {
    if (!listCacheLoaded) refreshListCache();
    const int active = realListItem(cachedActiveListEntry) ? cachedActiveListEntry : -1;
    const std::vector<int> visible = listVisible();
    const int visibleCount = static_cast<int>(visible.size());
    const int pages = std::max(1, (visibleCount + LIST_PER_PAGE - 1) / LIST_PER_PAGE);
    const auto indexOf = [&visible](int v) {
        const auto it = std::find(visible.begin(), visible.end(), v);
        return it == visible.end() ? -1 : static_cast<int>(it - visible.begin());
    };
    if (active != listFollowedActive) {
        listFollowedActive = active;
        if (active >= 0) {
            const int vi = indexOf(active);
            if (vi >= 0) listPage = vi / LIST_PER_PAGE;
            listSelected = active;
        }
    }
    listPage = std::clamp(listPage, 0, pages - 1);
    if (listSelected < 0 || listSelected >= LIST_SIZE) listSelected = active >= 0 ? active : -1;

    // SILVETON_MULTI_DELETE_V1: the page keys leave room on the right for МАРКИРАЙ / ИЗТРИЙ
    const float keyW = (1018.0F - static_cast<float>(pages - 1) * 6.0F) / static_cast<float>(pages);
    for (int i = 0; i < pages; ++i) {
        const float fi = static_cast<float>(i);
        const RectF pr(112.0F + fi * (keyW + 6.0F), 108.0F, 112.0F + fi * (keyW + 6.0F) + keyW, 148.0F);
        bool hasData = false;
        for (int k = i * LIST_PER_PAGE; k < std::min(visibleCount, (i + 1) * LIST_PER_PAGE); ++k) {
            if (realListItem(visible[static_cast<std::size_t>(k)])) { hasData = true; break; }
        }
        const int activeIndex = indexOf(active);
        const bool activeHere = active >= 0 && activeIndex / LIST_PER_PAGE == i && activeIndex >= 0;
        pageKey(c, pr, std::to_string(i + 1), i == listPage, hasData, activeHere);
        hit(pr, [this, i](float, float) { listPage = i; });
    }
    // SILVETON_MULTI_DELETE_V1: МАРКИРАЙ = a tap marks blends (as many as you like), ИЗТРИЙ takes them out with the sounds only they use
    if (!listMarkMode_) {
        const RectF markR(1140.0F, 108.0F, 1326.0F, 148.0F);
        stripToggle(c, markR, "МАРКИРАЙ", false, C_MUTE, 12.0F);
        hit(markR, [this](float, float) { listMarkMode_ = true; listMarked_.clear(); invalidate(); });
    } else {
        const std::size_t n = listMarked_.size();
        const RectF delR(1140.0F, 108.0F, 1250.0F, 148.0F);
        const RectF offR(1258.0F, 108.0F, 1326.0F, 148.0F);
        stripToggle(c, delR, n == 0U ? std::string("ИЗТРИЙ") : "ИЗТРИЙ " + std::to_string(n), n > 0U, C_MUTE, 12.0F);
        lightKey(c, offR, "ОТКАЗ", true, 11.0F);
        hit(delR, [this](float, float) { deleteMarkedListEntries(); });
        hit(offR, [this](float, float) { listMarkMode_ = false; listMarked_.clear(); invalidate(); });
    }

    const float gridTop = 156.0F;
    const float gridBottom = 640.0F;
    const float gap = 7.0F;
    const int cols = 5;
    const int rows = 6;
    const float colW = (1214.0F - static_cast<float>(cols - 1) * gap) / static_cast<float>(cols);
    const float rowH = (gridBottom - gridTop - static_cast<float>(rows - 1) * gap) / static_cast<float>(rows);
    for (int j = 0; j < LIST_PER_PAGE; ++j) {
        const int vi = listPage * LIST_PER_PAGE + j;
        if (vi >= visibleCount) break;
        const int idx = visible[static_cast<std::size_t>(vi)];
        const float col = static_cast<float>(j % cols);
        const float row = static_cast<float>(j / cols);
        const RectF rr(112.0F + col * (colW + gap), gridTop + row * (rowH + gap),
                       112.0F + col * (colW + gap) + colW, gridTop + row * (rowH + gap) + rowH);
        const std::optional<ListItem> item = realListItem(idx);
        listGridCell(c, rr, idx, item, idx == active, idx == listSelected);
        listCells_.emplace_back(idx, rr);   // SILVETON_WORKFLOW_V1
        if (listMarkMode_ && item) {   // SILVETON_MULTI_DELETE_V1: a tap marks / unmarks, nothing is played
            const bool marked = listMarked_.count(idx) != 0U;
            if (marked) {
                fill(c, rr, 10.0F, Color::argb(150, 255, 107, 94));
                fill(c, RectF(rr.right - 30.0F, rr.bottom - 30.0F, rr.right - 12.0F, rr.bottom - 12.0F), 9.0F, Color::WHITE);   // the mark: a white dot
            }
            hit(rr, [this, idx](float, float) { if (listMarked_.count(idx) != 0U) listMarked_.erase(idx); else listMarked_.insert(idx); invalidate(); });
            continue;
        }
        if (item) {
            const ListItem it = *item;
            hit(rr, [this, idx, it](float, float) {
                listSelected = idx;
                if (sampler.activateListEntry(0, 0, 0, idx)) {
                    cachedActiveListEntry = idx;
                    listFollowedActive = idx;
                    loadedFromList = idx;
                    if (it.combiBank == 0 && it.combiPage == 0) editingCombiSlot = it.combiSlot;
                    cachedCombiName = sampler.combiName();
                    refreshAllUppers();
                    refreshFx();
                }
            });
            listLongHit(rr, [this, idx, it](float, float) { showListContextMenu(idx, it); });
        } else {
            hit(rr, [this, idx](float, float) {
                listSelected = idx;
                flash("ЛИСТ " + pad3(idx + 1) + " ИЗБРАН - STORE ЗАПИСВА ТУК");
            });
            if (pasteAction_) listLongHit(rr, [this, idx](float, float) { showPasteMenu(idx); });   // SILVETON_PASTE_V1
        }
    }
    if (visible.empty()) {
        text(c, !listSearch.empty() ? "НЯМА БЛЕНДА С „" + listSearch + "“" : std::string("НЯМА ЛЮБИМИ - ЗАДРЪЖ БЛЕНДА → ★"),
             719.0F, 400.0F, 20.0F, C_INK_SOFT, Opt().center().bold());
    }
    text(c, listMarkMode_ ? "МАРКИРАЙ: докосни блендите, които да се изтрият, после ИЗТРИЙ  ·  ОТКАЗ = без триене" : "◀  плъзни за страница  ▶",
         719.0F, 652.0F, 11.0F, listMarkMode_ ? C_MUTE : C_LABEL_GREY, Opt().center());

    // ---- one row of big keys
    const float top = 664.0F;
    const float bottom = 786.0F;
    const std::optional<ListItem> chosenItem = realListItem(listSelected);
    float x = 112.0F;
    const RectF storeR(x, top, x + 186.0F, bottom);
    x = storeR.right + 8.0F;
    accentKey(c, storeR, listSelected >= 0 ? "STORE ► " + pad3(listSelected + 1) : std::string("STORE"), true);
    hit(storeR, [this](float, float) { storeToList(); });
    const RectF editR(x, top, x + 118.0F, bottom);
    x = editR.right + 8.0F;
    lightKey(c, editR, "EDIT", chosenItem.has_value(), 17.0F);
    if (chosenItem) {
        const ListItem it = *chosenItem;
        const int sel = listSelected;
        hit(editR, [this, it, sel](float, float) { editListCombi(it, sel); });
    }
    const RectF tR(x, top, x + 96.0F, bottom);
    x = tR.right + 6.0F;
    const RectF qR(x, top, x + 96.0F, bottom);
    x = qR.right + 22.0F;
    stripToggle(c, tR, sampler.hasTercaUppers() ? std::string("T  ") + (sampler.tercaMasterOn() ? "ON" : "OFF") : std::string("T  —"),
                sampler.tercaMasterOn(), C_AMBER, 18.0F);
    stripToggle(c, qR, sampler.hasScaleUppers() ? std::string("Q  ") + (sampler.scaleMasterOn() ? "ON" : "OFF") : std::string("Q  —"),
                sampler.scaleMasterOn(), C_AMBER, 18.0F);
    hit(tR, [this](float, float) {
        if (!sampler.hasTercaUppers()) flash("НЯМА UPPER С T - ИЗБЕРИ T В COMBI"); else sampler.toggleTercaMaster();
        invalidate();
    });
    hit(qR, [this](float, float) {
        if (!sampler.hasScaleUppers()) flash("НЯМА UPPER С Q - ИЗБЕРИ Q В COMBI"); else sampler.toggleScaleMaster();
        invalidate();
    });
    // TRANSPOSE: big - [value] +, both at once = 0
    std::optional<GlobalUiState> g = globalState;
    if (!g) { g = sampler.globalUiState(); if (g) globalState = g; }
    const RectF tm(x, top, x + 118.0F, bottom);
    x = tm.right + 4.0F;
    const RectF tv(x, top, x + 104.0F, bottom);
    x = tv.right + 4.0F;
    const RectF tp(x, top, x + 118.0F, bottom);
    x = tp.right + 16.0F;
    stripToggle(c, tm, "−", false, C_AMBER, 44.0F);
    stripToggle(c, tp, "+", false, C_AMBER, 44.0F);
    lcd(c, tv, 8.0F);
    text(c, "TRANSPOSE", tv.centerX(), tv.top + 20.0F, 11.0F, C_LCD_DIM, Opt().center().mono().maxW(tv.width() - 8.0F));
    text(c, signed_(g ? g->transpose : 0), tv.centerX(), tv.bottom - 24.0F, 36.0F, C_LCD, Opt().center().mono());
    text(c, "− и + заедно = 0", tv.centerX(), tv.bottom - 7.0F, 11.0F, C_LCD_DIM, Opt().center().maxW(tv.width() - 8.0F));
    hit(tv, [](float, float) {}, [this]() { sampler.stepGlobalTranspose(0); refreshGlobal(); });
    hit(tm, [this](float, float) { sampler.stepGlobalTranspose(-1); refreshGlobal(); });
    hit(tp, [this](float, float) { sampler.stepGlobalTranspose(1); refreshGlobal(); });
    pairHits.push_back(PairHit{tm, tp, [this]() { sampler.stepGlobalTranspose(0); refreshGlobal(); }});
    const RectF ts(x, top, x + 150.0F, bottom);
    x = ts.right + 6.0F;
    scanKey(c, ts, 1, "T SCAN\n" + tercaText(sampler.tercaState()));
    const RectF qs(x, top, std::min(x + 150.0F, 1326.0F), bottom);
    const int notes = sampler.quarterNotes();
    std::string names;
    for (int i = 0; i < 12; ++i) {
        if ((notes & (1 << i)) == 0) continue;
        if (!names.empty()) names += " ";
        names += Ctrl::NOTE_NAMES()[static_cast<std::size_t>(i)];
    }
    scanKey(c, qs, 2, "Q SCAN\n" + (names.empty() ? std::string("—") : names));
}

// SILVETON_MULTI_DELETE_V1: the marked blends leave the LIST, each with the sounds only it uses (asked once). From the last position
// down, so the positions of the others do not move while it runs; a sound shared by two marked blends goes with the second one.
void SilvetonSamplerView::deleteMarkedListEntries() {
    if (listMarked_.empty()) { flash("ДОКОСНИ БЛЕНДИТЕ, КОИТО ДА СЕ ИЗТРИЯТ"); return; }
    std::vector<int> order(listMarked_.rbegin(), listMarked_.rend());
    std::string names;
    std::size_t shown = 0U;
    for (auto it = listMarked_.begin(); it != listMarked_.end(); ++it) {
        const auto item = realListItem(*it);
        if (!item) continue;
        if (shown < 10U) names += (shown == 0U ? "" : ", ") + pad3(*it + 1) + " " + item->name;
        ++shown;
    }
    if (shown > 10U) names += " … (" + std::to_string(shown) + ")";
    showConfirm("ИЗТРИЙ " + std::to_string(order.size()) + (order.size() == 1U ? " БЛЕНДА" : " БЛЕНДИ"),
                "Излизат от ЛИСТА заедно със звуците, които само те ползват. Общ с друга бленда звук остава.\n" + names,
                "ИЗТРИЙ", [this, order]() {
                    std::optional<std::string> err;
                    for (const int index : order) {
                        if (!realListItem(index)) continue;
                        const auto leaving = sampler.soundsOnlyInListEntry(index);
                        std::vector<int> places;
                        for (const auto& l : leaving) places.push_back(l.first);
                        const auto one = sampler.deleteListEntryWithSounds(index, places);
                        if (one && !err) err = one;
                        if (loadedFromList == index) loadedFromList = -1;
                        refreshListCache();
                    }
                    listMarked_.clear();
                    listMarkMode_ = false;
                    refreshListCache();
                    refreshAllUppers();
                    if (err) flash("ГРЕШКА: " + *err);
                    invalidate();
                }, "CANCEL");
}

void SilvetonSamplerView::listGridCell(Canvas& c, const RectF& r, int idx, const std::optional<ListItem>& item, bool active, bool chosen) {
    if (chosen) fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), 13.0F, C_ACCENT);
    else shadow(c, r, 10.0F, 2.0F, 60);
    const ColorInt face = active ? C_ACCENT : (item ? Color::rgb(44, 50, 58) : Color::rgb(30, 34, 39));
    fill(c, r, 10.0F, face);
    if (!active) line(c, r.left + 10.0F, r.top + 1.0F, r.right - 10.0F, r.top + 1.0F, Color::rgb(78, 88, 100), 1.0F);
    if (isDown(r)) fill(c, r, 10.0F, Color::argb(60, 0, 0, 0));
    const ColorInt numColor = active ? Color::WHITE : (item ? Color::rgb(196, 202, 210) : Color::rgb(110, 118, 128));
    text(c, pad3(idx + 1), r.left + 14.0F, r.top + 24.0F, 15.0F, numColor, Opt().monoBold());
    if (listFavs.count(idx) != 0) {
        text(c, "★", r.right - 12.0F, r.top + 24.0F, 15.0F, active ? Color::WHITE : Color::rgb(255, 200, 90), Opt().right());
    }
    if (item) {
        text(c, item->name, r.left + 14.0F, r.bottom - 16.0F, 18.0F, Color::WHITE,
             Opt().bold().maxW(r.width() - 28.0F));
    } else {
        text(c, "—", r.left + 14.0F, r.bottom - 22.0F, 20.0F, Color::rgb(96, 104, 114));
    }
}

/** STORE: the COMBI that sounds now goes to the chosen LIST place. */
// SILVETON_PASTE_V1 (the Manager's copy)
void SilvetonSamplerView::setPasteOffer(const std::string& label, std::function<void(int)> paste) {
    pasteLabel_ = label;
    pasteAction_ = std::move(paste);
    invalidate();
}

void SilvetonSamplerView::showPasteMenu(int index) {
    listSelected = index;
    showItems("ЛИСТ " + pad3(index + 1), {"ПОСТАВИ: " + pasteLabel_}, [this, index](int which) {
        if (which == 0 && pasteAction_) pasteAction_(index);
    }, "CANCEL");
}

void SilvetonSamplerView::listPasted(int first, int count) {
    if (first < 0 || count <= 0) return;
    page_ = Page::LIST;
    listSelected = first;
    listPage = std::clamp(first / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    refreshListCache();
    flash(count == 1 ? "ПОСТАВЕН: ЛИСТ " + pad3(first + 1) : "ПОСТАВЕНИ " + std::to_string(count) + " ЗВУКА ОТ ЛИСТ " + pad3(first + 1));
    invalidate();
}

void SilvetonSamplerView::storeToList() {
    const std::vector<ListItem> list = sampler.listItems(0, 0, 0);
    const auto nameAt = [this, &list](int pos) -> std::optional<std::string> {
        if (pos < 0 || pos >= static_cast<int>(list.size())) return std::nullopt;
        const ListItem& it = list[static_cast<std::size_t>(pos)];
        if (sampler.isEmptyListItem(it)) return std::nullopt;
        return it.name;
    };
    int pos = -1;
    if (listSelected >= 0 && listSelected < LIST_SIZE) {
        pos = listSelected;
    } else {
        for (int i = 0; i < LIST_SIZE; ++i) if (!nameAt(i)) { pos = i; break; }
    }
    if (pos < 0) { flash("ЛИСТЪТ Е ПЪЛЕН"); return; }
    const std::optional<std::string> old = nameAt(pos);
    const auto askName = [this, pos, old]() {
        showTextPage("STORE  →  ЛИСТ " + pad3(pos + 1), old ? *old : sampler.combiName(), [this, pos](const std::string& newName) {
            const std::string t = trimmed(newName);
            doWriteList(pos, t.empty() ? sampler.combiName() : t);
            listSelected = pos;
        });
    };
    if (!old) { askName(); return; }
    showConfirm("ЛИСТ " + pad3(pos + 1), "Тук вече има „" + *old + "“.\nДа запиша ли отгоре?", "ДА, ЗАПИШИ", askName, "НЕ");
}

// SILVETON_SET_SAVE_AS_V1
void SilvetonSamplerView::saveSetAs() {
    showTextPage("SAVE AS  (ЦЕЛИЯТ СЕТ)", "SILVETON SET", [this](const std::string& name) {
        const auto doSave = [this, name]() {
            const std::optional<std::string> err = sampler.saveSetAs(name);
            flash(!err ? "СЕТЪТ Е ЗАПИСАН: " + trimmed(name) : "ГРЕШКА: " + *err);
        };
        if (sampler.setExists(name)) {
            showConfirm("SAVE AS", "Сет „" + trimmed(name) + "“ вече има.\nДа запиша ли отгоре?", "ДА, ЗАПИШИ", doSave, "НЕ");
        } else {
            doSave();
        }
    });
}

void SilvetonSamplerView::loadSet() {
    const std::vector<std::string> sets = sampler.savedSets();
    if (sets.empty()) {
        showMessage("LOAD", "Няма записани сетове.\nЗапиши с SAVE AS. Папка: " + sampler.setsFolders());
        return;
    }
    std::vector<std::pair<std::string, std::string>> items;
    for (std::size_t i = 0; i < sets.size(); ++i) items.emplace_back(fmtZeroPad(static_cast<long long>(i) + 1, 2), sets[i]);
    showGridPicker("LOAD  -  ЗАПИСАНИ СЕТОВЕ", items, -1, std::nullopt, [this, sets](int index) {
        const std::string name = sets[static_cast<std::size_t>(index)];
        showConfirm("LOAD  „" + name + "“",
                    "Целият ЛИСТ, блендите и настройките се сменят с тези от сета.\nСегашните (ако не са записани със SAVE AS) се губят.",
                    "LOAD", [this, name]() {
                        const std::optional<std::string> err = sampler.loadSavedSet(name);
                        if (!err) {
                            loadedFromList = -1;
                            listSelected = -1;
                            refreshListCache();
                            refreshAllUppers();
                            refreshFx();
                            refreshGlobal();
                            flash("ЗАРЕДЕН СЕТ: " + name);
                        } else {
                            flash("ГРЕШКА: " + *err);
                        }
                    }, "CANCEL");
    });
}

// SILVETON_LIST_POSITIONS_V1: a LIST position with a BLEND (nullopt = empty position).
std::optional<SilvetonSamplerView::ListItem> SilvetonSamplerView::realListItem(int index) {
    if (index < 0 || index >= static_cast<int>(cachedListItems.size())) return std::nullopt;
    const ListItem& it = cachedListItems[static_cast<std::size_t>(index)];
    if (sampler.isEmptyListItem(it)) return std::nullopt;
    return it;
}

void SilvetonSamplerView::listCard(Canvas& c, const RectF& r, const std::optional<ListItem>& item, int idx, bool selected) {
    if (selected) fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), 15.0F, C_ACCENT);
    else if (item) shadow(c, r, 12.0F, 2.0F, 50);
    fill(c, r, 12.0F, !item ? C_EMPTY_CARD : (selected ? C_STRIP_SEL : C_STRIP));
    if (isDown(r)) fill(c, r, 12.0F, Color::argb(28, 0, 0, 0));
    led(c, r.left + 22.0F, r.centerY(), selected, 5.0F, true);
    const RectF box(r.left + 40.0F, r.centerY() - 22.0F, r.left + 124.0F, r.centerY() + 22.0F);
    lcd(c, box, 8.0F);
    text(c, pad3(idx + 1), box.centerX(), box.centerY() + 8.0F, 22.0F, item ? C_LCD : C_LCD_DIM, Opt().center().mono());
    if (item) {
        text(c, item->name, r.left + 142.0F, r.centerY() + 3.0F, 24.0F, C_INK, Opt().bold().maxW(r.width() - 160.0F));
        text(c, blendAddress(*item), r.left + 142.0F, r.centerY() + 27.0F, 12.0F, C_LABEL_GREY, Opt().mono().spacing(0.1F));
    } else {
        text(c, "—", r.left + 142.0F, r.centerY() + 9.0F, 24.0F, C_EMPTY_TEXT);
    }
}

std::string SilvetonSamplerView::blendAddress(const ListItem& item) {
    if (item.combiBank == 0 && item.combiPage == 0) return "BLEND " + pad3(item.combiSlot);
    return "COMBI B" + std::to_string(item.combiBank + 1) + " P" + std::to_string(item.combiPage + 1) + " S" + std::to_string(item.combiSlot);
}

void SilvetonSamplerView::editListCombi(const ListItem& item, int index) {
    if (sampler.activateCombiAddress(item.combiBank, item.combiPage, item.combiSlot)) {
        editingCombiSlot = item.combiSlot;
        loadedFromList = index;
        page_ = Page::COMBI;
        cachedCombiName = sampler.combiName();
        refreshAllUppers();
        refreshFx();
        invalidate();
    }
}

void SilvetonSamplerView::showListContextMenu(int index, const ListItem& item) {
    const std::string favLabel = listFavs.count(index) != 0 ? "☆ МАХНИ ОТ ЛЮБИМИ" : "★ ЛЮБИМА";
    std::vector<std::string> actions = {"EDIT COMBI", favLabel, "RENAME", "COPY", "MOVE", "DELETE"};
    const bool paste = static_cast<bool>(pasteAction_);   // SILVETON_PASTE_V1: first item while the Manager has copied sounds
    if (paste) actions.insert(actions.begin(), "ПОСТАВИ: " + pasteLabel_);
    showItems(pad3(index + 1) + "   " + item.name, actions, [this, index, paste](int which) {
        if (paste) {
            if (which == 0) { if (pasteAction_) pasteAction_(index); return; }
            --which;
        }
        listRowAction(index, which);
    }, "CANCEL");
}

// SILVETON_WORKFLOW_V1: the actions of the LIST menu, for the screens' own menu and for the Mac's menu
int SilvetonSamplerView::listRowAt(float rawX, float rawY) const {
    if (page_ != Page::LIST || writeOpen || dialogIsOpen() || picker) return -1;
    const float x = (rawX - uiOffsetX) / uiScale;
    const float y = (rawY - uiOffsetY) / uiScale;
    for (const auto& cell : listCells_) if (cell.second.contains(x, y)) return cell.first;
    return -1;
}

bool SilvetonSamplerView::listRowInfo(int index, std::string& name, bool& favourite) {
    favourite = listFavs.count(index) != 0;
    const std::optional<ListItem> item = realListItem(index);
    if (!item) { name.clear(); return false; }
    name = item->name;
    return true;
}

void SilvetonSamplerView::listRowAction(int index, int which) {
    const std::optional<ListItem> found = realListItem(index);
    if (!found) return;
    const ListItem item = *found;
    listSelected = index;
    switch (which) {
        case 0: editListCombi(item, index); break;
        case 1:
            if (listFavs.erase(index) == 0) listFavs.insert(index);
            sampler.saveListFavourites(listFavs);
            break;
        case 2:
            showTextPage("RENAME BLEND", item.name, [this, index](const std::string& newName) {
                if (sampler.renameLiveListEntry(index, newName)) { refreshListCache(); invalidate(); }
            });
            break;
        case 3: openPositionPicker(WriteMode::COPY, index); break;
        case 4: openPositionPicker(WriteMode::MOVE, index); break;
        case 5: {
            // SILVETON_LIST_DELETE_SOUNDS_V1 (the Manager's copy): the sounds only this blend has leave the sampler with it
            const auto leaving = sampler.soundsOnlyInListEntry(index);
            if (leaving.empty()) {
                showConfirm("DELETE  ЛИСТ " + pad3(index + 1),
                            "„" + item.name + "“ излиза от ЛИСТА и мястото остава празно. Другите позиции не мърдат, самата бленда не се трие.",
                            "DELETE", [this, index]() {
                                if (sampler.deleteLiveListEntry(index)) {
                                    if (loadedFromList == index) loadedFromList = -1;
                                    refreshListCache();
                                    invalidate();
                                }
                            }, "CANCEL");
                break;
            }
            std::string names;
            std::vector<int> places;
            for (std::size_t k = 0U; k < leaving.size(); ++k) {
                places.push_back(leaving[k].first);
                if (k < 12U) names += (k == 0U ? "" : ", ") + leaving[k].second;
            }
            if (leaving.size() > 12U) names += " … (" + std::to_string(leaving.size()) + ")";
            showConfirm("DELETE  ЛИСТ " + pad3(index + 1),
                        "„" + item.name + "“ излиза от ЛИСТА заедно с блендата.\nТези звуци не са в друга бленда и излизат от семплера:\n" + names,
                        "DELETE", [this, index, places]() {
                            const auto err = sampler.deleteListEntryWithSounds(index, places);
                            if (loadedFromList == index) loadedFromList = -1;
                            refreshListCache();
                            refreshAllUppers();
                            if (err) flash("ГРЕШКА: " + *err);
                            invalidate();
                        }, "CANCEL");
            break;
        }
        default: break;
    }
    invalidate();
}

} // namespace silveton::ui
