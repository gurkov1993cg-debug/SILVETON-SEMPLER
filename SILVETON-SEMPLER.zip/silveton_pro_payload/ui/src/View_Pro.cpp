// SILVETON_PRO_UI_V1 - the professional frame of the screens: transforms for the older pages, the Upper strips' places,
// the page keys under the COMBI page, the panels / keys / fields of the new look, and the language of the screens.
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

std::string translateToEnglish(const std::string& s);   // Lang_En.cpp

// ---------------------------------------------------------------- transforms
void SilvetonSamplerView::beginXf(Canvas& c, const Xf& x) {
    c.save();
    c.translate(x.tx, x.ty);
    c.scale(x.s, x.s);
    xf_ = x;
}

void SilvetonSamplerView::endXf(Canvas& c) {
    c.restore();
    xf_ = Xf{};
}

SilvetonSamplerView::Xf SilvetonSamplerView::fitXf(const RectF& from, const RectF& to) {
    Xf x;
    x.s = std::min(to.width() / std::max(1.0F, from.width()), to.height() / std::max(1.0F, from.height()));
    x.tx = to.left + (to.width() - from.width() * x.s) * 0.5F - from.left * x.s;
    x.ty = to.top - from.top * x.s;
    return x;
}

RectF SilvetonSamplerView::stripRect(int i) const {
    const float w = (1320.0F - 6.0F * 6.0F) / 7.0F;
    const float left = 10.0F + static_cast<float>(std::clamp(i, 0, 6)) * (w + 6.0F);
    return RectF(left, 80.0F, left + w, tab == UpperTab::MIXER ? 736.0F : 392.0F);
}

// ---------------------------------------------------------------- the pieces of the new look
void SilvetonSamplerView::proPanel(Canvas& c, const RectF& r, const std::string& title, const std::string& sub) {
    shadow(c, r, 9.0F, 2.0F, 90);
    fill(c, r, 9.0F, Color::rgb(15, 17, 20));
    fillV(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 8.0F, Color::rgb(45, 50, 56), Color::rgb(37, 42, 48));
    line(c, r.left + 9.0F, r.top + 1.5F, r.right - 9.0F, r.top + 1.5F, Color::argb(26, 255, 255, 255), 1.0F);
    if (!title.empty()) text(c, title, r.left + 11.0F, r.top + 18.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.18F).maxW(r.width() * 0.62F));
    if (!sub.empty()) text(c, sub, r.right - 11.0F, r.top + 18.0F, 10.0F, Color::rgb(118, 128, 140), Opt().right().spacing(0.06F).maxW(r.width() * 0.42F));
}

void SilvetonSamplerView::proKey(Canvas& c, const RectF& r, const std::string& label, bool on, float size, ColorInt onColor) {
    const bool down = isDown(r);
    fill(c, r, 6.0F, Color::rgb(13, 15, 18));
    const RectF f(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F);
    if (on) fillV(c, f, 5.0F, down ? onColor : lighten(onColor, 24), down ? lighten(onColor, -18) : onColor);
    else fillV(c, f, 5.0F, down ? Color::rgb(46, 51, 58) : Color::rgb(62, 68, 76), down ? Color::rgb(38, 42, 48) : Color::rgb(47, 52, 59));
    if (!down) line(c, f.left + 5.0F, f.top + 1.0F, f.right - 5.0F, f.top + 1.0F, Color::argb(on ? 80 : 24, 255, 255, 255), 1.0F);
    const ColorInt tc = on ? litText(onColor) : Color::rgb(180, 188, 198);
    std::vector<std::string> lines;
    {
        std::string cur;
        const std::string shown = uiLang_ != 0 ? tr(label) : label;   // a label of two lines is translated as a whole
        for (const char ch : shown) {
            if (ch == '\n') { lines.push_back(cur); cur.clear(); } else cur.push_back(ch);
        }
        lines.push_back(cur);
    }
    const float lh = size + 3.0F;
    const float y0 = r.centerY() + size * 0.36F - lh * static_cast<float>(lines.size() - 1U) * 0.5F;
    for (std::size_t k = 0U; k < lines.size(); ++k)
        text(c, lines[k], r.centerX(), y0 + lh * static_cast<float>(k), size, tc, Opt().center().bold().spacing(0.06F).maxW(r.width() - 8.0F));
}

void SilvetonSamplerView::proField(Canvas& c, const RectF& r, const std::string& value, float size, bool arrow) {
    fill(c, r, 5.0F, Color::rgb(5, 6, 8));
    fill(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 4.0F, Color::rgb(15, 18, 21));
    line(c, r.left + 4.0F, r.top + 2.0F, r.right - 4.0F, r.top + 2.0F, Color::argb(140, 0, 0, 0), 1.5F);
    if (isDown(r)) fill(c, r, 5.0F, Color::argb(40, 255, 255, 255));
    text(c, value, r.left + 10.0F, r.centerY() + size * 0.36F, size, Color::rgb(241, 243, 245),
         Opt().bold().maxW(r.width() - (arrow ? 34.0F : 16.0F)));
    if (arrow) text(c, "▾", r.right - 12.0F, r.centerY() + 5.0F, 13.0F, Color::rgb(111, 183, 255), Opt().center());
}

// ---------------------------------------------------------------- the page keys under the COMBI page
void SilvetonSamplerView::drawBottomTabs(Canvas& c) {
    const RectF bar(10.0F, 744.0F, 1330.0F, 792.0F);
    fill(c, bar, 8.0F, Color::rgb(7, 8, 10));
    fill(c, RectF(bar.left + 1.0F, bar.top + 1.0F, bar.right - 1.0F, bar.bottom - 1.0F), 7.0F, Color::rgb(16, 18, 21));
    struct T { UpperTab t; const char* name; };
    static const T tabs[] = {{UpperTab::MIXER, "МИКСЕР"}, {UpperTab::TUNE, "TUNE"},    {UpperTab::RANGE, "RANGE"}, {UpperTab::VELOCITY, "VEL"},
                             {UpperTab::TONE, "TONE"},    {UpperTab::WAVE, "WAVE"},    {UpperTab::PORTA, "VOICE"}, {UpperTab::EQ, "EQ"},
                             {UpperTab::CONTROL, "CTRL"}, {UpperTab::FX, "FX"},        {UpperTab::ENGINE, "ENGINE"}};
    const float groupW = 112.0F + 66.0F + 90.0F + 90.0F + 3.0F * 4.0F;
    const float x0 = bar.left + 4.0F;
    const float x1 = bar.right - 4.0F - groupW - 10.0F;
    const float tw = (x1 - x0 - 10.0F * 4.0F) / 11.0F;
    for (int k = 0; k < 11; ++k) {
        const T t = tabs[k];
        const float l = x0 + static_cast<float>(k) * (tw + 4.0F);
        const RectF r(l, bar.top + 4.0F, l + tw, bar.bottom - 4.0F);
        proKey(c, r, t.name, tab == t.t, 12.0F);
        hit(r, [this, t](float, float) {
            tab = t.t;
            dropUpper = -1;
            if (t.t == UpperTab::FX) refreshFx();
            invalidate();
        });
    }
    // SILVETON_MARK_LINK_V1: МАРКИРАЙ / ЛИНК, COPY / PASTE of the whole Upper
    float x = bar.right - 4.0F - groupW;
    const long markedCount = std::count(marked.begin(), marked.end(), true);
    const RectF mkR(x, bar.top + 4.0F, x + 112.0F, bar.bottom - 4.0F);
    proKey(c, mkR, markedCount > 0 ? "МАРКИРАЙ · " + std::to_string(markedCount) : std::string("МАРКИРАЙ"), markMode, 11.0F, C_MARK);
    hit(mkR,
        [this](float, float) {
            markMode = !markMode;
            if (markMode) {
                if (tab == UpperTab::ENGINE || tab == UpperTab::FX || tab == UpperTab::EQ) tab = UpperTab::MIXER;   // the strips must be seen
                flash("ДОКОСВАЙ ЛЕНТИТЕ НА УПЕРИТЕ, КОИТО ИСКАШ ДА МАРКИРАШ");
            }
            invalidate();
        },
        [this] {
            marked.fill(false);
            flash("МАРКИРОВКАТА Е ИЗЧИСТЕНА");
            invalidate();
        });
    x = mkR.right + 4.0F;
    const RectF lkR(x, bar.top + 4.0F, x + 66.0F, bar.bottom - 4.0F);
    proKey(c, lkR, "ЛИНК", linkOn, 11.0F, C_MARK);
    hit(lkR, [this](float, float) {
        linkOn = !linkOn;
        flash(linkOn ? "ЛИНК ВКЛ: МАРКИРАНИТЕ УПЕРИ СЛЕДВАТ" : "ЛИНК ИЗКЛ");
        invalidate();
    });
    x = lkR.right + 4.0F;
    const RectF copyR(x, bar.top + 4.0F, x + 90.0F, bar.bottom - 4.0F);
    proKey(c, copyR, "COPY U" + std::to_string(selectedUpper_ + 1), false, 11.0F);
    hit(copyR, [this](float, float) { copyUpper(selectedUpper_); });
    x = copyR.right + 4.0F;
    const RectF pasteR(x, bar.top + 4.0F, x + 90.0F, bar.bottom - 4.0F);
    proKey(c, pasteR, copiedClip ? "PASTE U" + std::to_string(copiedClip->from + 1) : std::string("PASTE"), false, 11.0F);
    if (!copiedClip) fill(c, pasteR, 6.0F, Color::argb(110, 16, 18, 21));
    hit(pasteR, [this](float, float) { pasteUpper(selectedUpper_); });
}

// the line over an older page of the selected Upper: which sound is edited (ОСНОВЕН / L1..L4) and the page's name
void SilvetonSamplerView::drawEditorHeader(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int ss = std::clamp(stripSound[static_cast<std::size_t>(u)], 0, 4);
    if (editSound != ss) editSound = ss;
    const bool soundPage = tab == UpperTab::TUNE || tab == UpperTab::RANGE || tab == UpperTab::VELOCITY || tab == UpperTab::TONE || tab == UpperTab::WAVE;
    const RectF rr(10.0F, 400.0F, 250.0F, 436.0F);
    const std::string who = ss == 0 ? "UPPER " + std::to_string(u + 1) + " · ОСНОВЕН ▾" : "UPPER " + std::to_string(u + 1) + " · L" + std::to_string(ss) + " ▾";
    proKey(c, rr, who, soundPage, 12.0F);
    hit(rr, [this, u](float, float) { dropUpper = dropUpper == u ? -1 : u; invalidate(); });
    std::string sound;
    if (ss == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        sound = st && st->soundName != "EMPTY" && !isBlank(st->soundName) ? st->soundName : std::string("EMPTY");
    } else {
        sound = layerSlot(u, ss - 1) > 0 ? sampler.layerName(u, ss - 1) : std::string("EMPTY");
        if (isBlank(sound)) sound = "L" + std::to_string(ss);
    }
    const std::string page = tab == UpperTab::CONTROL ? std::string("CTRL") : tabName(tab);
    text(c, page, 266.0F, 425.0F, 16.0F, C_SECTION_TITLE, Opt().bold().spacing(0.16F));
    const float pw = textWidth(page, 16.0F, Face::Bold, 0.16F);
    text(c, (soundPage ? sound : "UPPER " + std::to_string(u + 1)), 282.0F + pw, 425.0F, 15.0F, C_INK, Opt().bold().maxW(1330.0F - 300.0F - pw));
    line(c, 10.0F, 439.0F, 1330.0F, 439.0F, Color::argb(60, 0, 0, 0), 1.0F);
}

// ---------------------------------------------------------------- the language of the screens
const std::string& SilvetonSamplerView::tr(const std::string& s) {
    bool cyr = false;
    for (const char ch : s) {
        const auto b = static_cast<unsigned char>(ch);
        if (b == 0xD0U || b == 0xD1U) { cyr = true; break; }
    }
    if (!cyr) return s;
    const auto it = trCache_.find(s);
    if (it != trCache_.end()) return it->second;
    if (trCache_.size() > 4000U) trCache_.clear();
    return trCache_.emplace(s, translateToEnglish(s)).first->second;
}

void SilvetonSamplerView::setLanguage(int lang) {
    uiLang_ = lang == 1 ? 1 : 0;
    trCache_.clear();
    sampler.setUiLanguage(uiLang_);
    invalidate();
}

} // namespace silveton::ui
