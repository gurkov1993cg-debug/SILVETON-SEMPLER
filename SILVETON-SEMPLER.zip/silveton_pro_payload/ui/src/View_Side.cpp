// SILVETON_PRO_UI_V1 - the top bar of every page: the logo, ЛИСТ / КОМБИ / НАСТРОЙКИ, the display with the name, the state
// of the sound (latency, XRUN, MIDI, CPU, voices), MASTER, PORTA and PANIC. (Before: the side navigation and the header.)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
int roundToInt(float v) { return static_cast<int>(std::nearbyint(v)); }   // Kotlin round(x).toInt()
} // namespace

void SilvetonSamplerView::drawTopBar(Canvas& c) {
    // the bar itself
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    paint.shader = linearGradient(0.0F, 0.0F, 0.0F, 72.0F, Color::rgb(47, 52, 59), Color::rgb(34, 38, 44), TileMode::Clamp);
    c.drawRect(RectF(0.0F, 0.0F, DESIGN_W, 72.0F), paint);
    paint.shader = nullptr;
    line(c, 0.0F, 72.5F, DESIGN_W, 72.5F, Color::rgb(10, 11, 13), 1.0F);
    fill(c, RectF(0.0F, 73.0F, DESIGN_W, 78.0F), 0.0F, Color::argb(60, 0, 0, 0));

    const Ctrl::AudioStatus a = frameAudioStatus;
    const Ctrl::MidiStatus m = frameMidiStatus;
    const std::int64_t now = nowMs();
    const bool midiRx = now < midiFlashUntilMs;
    const bool keyFlash = midiRx && (m.status & 0xF0) == 0x90 && m.data2 > 0;
    const bool midiConnected = std::max(midiConnections, m.deviceCount) > 0;
    std::string midiValue;
    if (keyFlash) midiValue = midiNoteName(m.data1);
    else if (midiRx) midiValue = "RX";
    else if (midiConnected) midiValue = "ON";
    else if (m.lastError != 0) midiValue = "E" + std::to_string(-m.lastError);
    else midiValue = "OFF";

    const bool running = sampler.audioRunning();
    const int lastAudioError = sampler.audioLastError();
    // SILVETON_HALF_RATE_V1: the proven profile, or any other the chip gave us (two portions)
    const bool classicAudio = a.sampleRate == 96000 && a.framesPerBurst == 96 && a.bufferSizeFrames == 192;
    const bool audioOk = running && (classicAudio ||
        (a.sampleRate >= 44100 && a.framesPerBurst >= 16 && a.framesPerBurst <= 512 && a.bufferSizeFrames == a.framesPerBurst * 2));
    bool audioSignal = a.activeVoices > 0;
    for (const auto& pr : frameUpperMeters) if (pr.first > 0.0001F || pr.second > 0.0001F) audioSignal = true;
    std::string audioValue;
    if (audioOk && classicAudio) audioValue = "96k 96x2";
    else if (audioOk) audioValue = std::to_string(a.sampleRate / 1000) + "k " + std::to_string(a.framesPerBurst) + "x" + std::to_string(a.bufferSizeFrames / std::max(1, a.framesPerBurst));
    else if (running) audioValue = std::to_string(a.sampleRate / 1000) + "k " + std::to_string(a.framesPerBurst);
    else if (lastAudioError != 0) audioValue = "OFF E" + std::to_string(-lastAudioError);
    else audioValue = "OFF";

    // the logo
    text(c, "SILVETON", 14.0F, 34.0F, 17.0F, C_LOGO, Opt().bold().spacing(0.22F));
    text(c, "SAMPLER · LIVE", 15.0F, 52.0F, 9.5F, Color::rgb(126, 135, 146), Opt().spacing(0.2F));

    // ЛИСТ / КОМБИ / НАСТРОЙКИ
    const RectF modes(132.0F, 8.0F, 448.0F, 64.0F);
    fill(c, modes, 8.0F, Color::rgb(9, 10, 12));
    fill(c, RectF(modes.left + 1.0F, modes.top + 1.0F, modes.right - 1.0F, modes.bottom - 1.0F), 7.0F, Color::rgb(18, 20, 24));
    const std::pair<Page, const char*> labels[] = {{Page::LIST, "ЛИСТ"}, {Page::COMBI, "КОМБИ"}, {Page::SETTINGS, "НАСТРОЙКИ"}};
    for (int i = 0; i < 3; ++i) {
        const Page p = labels[i].first;
        const float mw = (modes.width() - 8.0F - 2.0F * 4.0F) / 3.0F;
        const RectF b(modes.left + 4.0F + static_cast<float>(i) * (mw + 4.0F), modes.top + 4.0F, modes.left + 4.0F + static_cast<float>(i) * (mw + 4.0F) + mw, modes.bottom - 4.0F);
        const bool on = page_ == p || (p == Page::COMBI && page_ == Page::EFFECTS);
        proKey(c, b, labels[i].second, on, 12.0F);
        hit(b, [this, p](float, float) {
            page_ = p;
            dropUpper = -1;
            if (p == Page::LIST) refreshListCache();
            if (p == Page::COMBI) cachedCombiName = sampler.combiName();
            if (p == Page::SETTINGS) refreshGlobal();
        });
    }

    const bool isList = page_ == Page::LIST;
    // the display: where you are and what is loaded
    const RectF big(456.0F, 8.0F, isList ? 704.0F : 770.0F, 64.0F);
    fill(c, big, 8.0F, Color::rgb(2, 3, 4));
    fillV(c, RectF(big.left + 1.0F, big.top + 1.0F, big.right - 1.0F, big.bottom - 1.0F), 7.0F, Color::rgb(14, 17, 20), Color::rgb(8, 10, 12));
    const std::string slotText = editingCombiSlot ? fmtZeroPad(*editingCombiSlot, 3) : "---";
    const std::optional<ListItem> activeItem = realListItem(cachedActiveListEntry);
    std::string line1;
    switch (page_) {
        case Page::COMBI:
            line1 = "КОМБИ " + slotText + (loadedFromList >= 0 ? " · ЛИСТ " + fmtZeroPad(loadedFromList + 1, 3) : std::string());
            break;
        case Page::LIST:
            if (!listSearch.empty()) {
                line1 = "ЛИСТ · ТЪРСЕНЕ: " + utf8Upper(listSearch);
            } else if (listFavOnly) {
                line1 = "ЛИСТ · ЛЮБИМИ · " + std::to_string(listFavs.size());
            } else {
                int used = 0;
                for (const auto& it : cachedListItems) if (!sampler.isEmptyListItem(it)) ++used;
                line1 = "ЛИСТ · СТРАНИЦА " + std::to_string(listPage + 1) + " · " + std::to_string(used) + " / " + std::to_string(LIST_SIZE);
            }
            break;
        case Page::EFFECTS: line1 = "ЕФЕКТИ · КОМБИ " + slotText; break;
        case Page::SETTINGS: line1 = "НАСТРОЙКИ · ГЛОБАЛНИ"; break;
    }
    const std::string line2 = (page_ == Page::LIST && activeItem) ? fmtZeroPad(cachedActiveListEntry + 1, 3) + " " + activeItem->name : cachedCombiName;
    const bool flashOn = flashText.has_value() && now < flashUntilMs;
    text(c, flashOn ? *flashText : line1, big.left + 12.0F, big.top + 18.0F, 10.5F, flashOn ? C_LCD_OK : Color::rgb(111, 183, 255),
         Opt().mono().spacing(0.12F).maxW(big.width() - 24.0F));
    text(c, line2, big.left + 12.0F, big.bottom - 12.0F, 24.0F, Color::rgb(244, 246, 248), Opt().bold().maxW(big.width() - 24.0F));

    // a small dark box of the status
    const auto box = [&](const RectF& r) {
        fill(c, r, 7.0F, Color::rgb(2, 3, 4));
        fill(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 6.0F, Color::rgb(16, 18, 21));
        if (isDown(r)) fill(c, r, 7.0F, Color::argb(40, 255, 255, 255));
    };
    const auto bar = [&](const RectF& r, float t, ColorInt col) {
        fill(c, r, 2.0F, Color::rgb(36, 41, 47));
        if (t > 0.002F) fill(c, RectF(r.left, r.top, r.left + r.width() * std::clamp(t, 0.0F, 1.0F), r.bottom), 2.0F, col);
    };
    const float cpu = a.cpuLoadPercent;
    const ColorInt cpuCol = cpu > 95.0F ? C_LCD_BAD : (cpu > 80.0F ? C_YELLOW : C_LCD_OK);
    float x = big.right + 8.0F;
    if (isList) {
        // SILVETON_LIST_V2: SAVE AS / LOAD / SEARCH / star live up here on the LIST page.
        const RectF saveR(x, 8.0F, x + 92.0F, 34.0F); proKey(c, saveR, "SAVE AS", false, 10.5F); hit(saveR, [this](float, float) { saveSetAs(); });
        const RectF loadR(x, 38.0F, x + 92.0F, 64.0F); proKey(c, loadR, "LOAD", false, 10.5F); hit(loadR, [this](float, float) { loadSet(); });
        x += 100.0F;
        const RectF findR(x, 8.0F, x + 84.0F, 34.0F);
        proKey(c, findR, "ТЪРСИ", !listSearch.empty(), 10.5F, C_MARK);
        hit(findR, [this](float, float) {
            if (!listSearch.empty()) { listSearch.clear(); listPage = 0; invalidate(); }
            else showTextPage("ТЪРСИ БЛЕНДА ПО ИМЕ", "", [this](const std::string& q) { listSearch = trimmed(q); listFavOnly = false; listPage = 0; invalidate(); });
        });
        const RectF favR(x, 38.0F, x + 84.0F, 64.0F);
        proKey(c, favR, "★", listFavOnly, 15.0F, C_MARK);
        hit(favR, [this](float, float) { listFavOnly = !listFavOnly; listSearch.clear(); listPage = 0; invalidate(); });
        x += 92.0F;
    }
    // SOUND: the state of the audio, the latency, XRUN and MIDI
    const RectF zv(x, 8.0F, x + 128.0F, 64.0F);
    box(zv);
    led(c, zv.left + 12.0F, zv.top + 13.0F, audioOk || running, 4.0F);
    text(c, audioOk ? std::string("ЗВУК OK") : "ЗВУК " + audioValue, zv.left + 22.0F, zv.top + 17.0F, 9.5F, audioOk ? C_LCD_OK : C_LCD_BAD,
         Opt().mono().spacing(0.1F).maxW(zv.width() - 30.0F));
    text(c, a.estimatedLatencyMs >= 0.0 ? fmtFixed(a.estimatedLatencyMs, 2) + " ms" : "—", zv.left + 10.0F, zv.top + 37.0F, 17.0F, C_LCD, Opt().monoBold());
    text(c, "XRUN " + std::to_string(a.xrunCount), zv.left + 10.0F, zv.bottom - 7.0F, 9.5F, a.xrunCount > 0 ? C_LCD_BAD : C_LCD_DIM, Opt().mono());
    text(c, "MIDI " + midiValue, zv.right - 8.0F, zv.bottom - 7.0F, 9.5F, midiRx ? C_LCD : (midiConnected ? C_LCD_OK : C_LCD_DIM), Opt().mono().right().maxW(64.0F));
    hit(zv, [this](float, float) { page_ = Page::SETTINGS; settingsTab = 0; });
    x = zv.right + 8.0F;
    // CPU, the cores that share the sound, the voices
    const RectF cb(x, 8.0F, x + 104.0F, 64.0F);
    box(cb);
    text(c, "CPU · ЯДРА " + std::to_string(a.coresWorking), cb.left + 10.0F, cb.top + 17.0F, 9.5F, C_LCD_DIM, Opt().mono().maxW(cb.width() - 16.0F));
    text(c, std::to_string(roundToInt(cpu)) + " %", cb.left + 10.0F, cb.top + 37.0F, 17.0F, cpuCol, Opt().monoBold());
    bar(RectF(cb.left + 10.0F, cb.bottom - 14.0F, cb.right - 10.0F, cb.bottom - 10.0F), static_cast<float>(a.activeVoices) / 128.0F,
        a.activeVoices > 110 ? C_LCD_BAD : C_LCD_OK);
    text(c, std::to_string(a.activeVoices) + " ГЛ.", cb.right - 10.0F, cb.top + 37.0F, 9.5F, audioSignal ? C_LCD : C_LCD_DIM, Opt().mono().right());
    hit(cb, [this](float, float) { page_ = Page::SETTINGS; settingsTab = 0; });
    x = cb.right + 8.0F;
    // MASTER
    std::optional<GlobalUiState> g = globalState;
    if (!g) { g = sampler.globalUiState(); if (g) globalState = g; }
    const float master = g ? g->masterGainDb : -6.0F;
    const RectF ms(x, 8.0F, x + 104.0F, 64.0F);
    box(ms);
    text(c, "MASTER", ms.left + 10.0F, ms.top + 17.0F, 9.5F, C_LCD_DIM, Opt().mono().spacing(0.15F));
    text(c, fmtFixed(static_cast<double>(master), 1) + " dB", ms.left + 10.0F, ms.top + 37.0F, 17.0F, master > 0.0F ? C_LCD_BAD : C_LCD, Opt().monoBold());
    {
        float pkMax = 0.0F;
        for (const auto& pr : frameUpperMeters) pkMax = std::max(pkMax, std::max(pr.first, pr.second));
        const float mt = std::clamp((20.0F * std::log10(std::max(pkMax, 1e-5F)) + 60.0F) / 60.0F, 0.0F, 1.0F);
        bar(RectF(ms.left + 10.0F, ms.bottom - 14.0F, ms.right - 10.0F, ms.bottom - 10.0F), mt, mt > 0.9F ? C_LCD_BAD : C_LCD_OK);
    }
    hit(ms, [this, g](float, float) {
            if (g) {
                const GlobalUiState gg = *g;
                showNumber("MASTER dB", gg.masterGainDb, -60.0F, 18.0F, 1, [this, gg](float v) { GlobalUiState n = gg; n.masterGainDb = v; commitGlobal(n); });
            }
        },
        [this, g]() { if (g) { GlobalUiState n = *g; n.masterGainDb = -6.0F; commitGlobal(n); } });
    x = ms.right + 8.0F;
    if (!isList) {
        // PORTA of the selected Upper
        const std::vector<float> up = uParams(selectedUpper_);
        const int portaMode = std::clamp(roundToInt(at(up, 42U, 0.0F)), 0, 3);
        const bool kronos = portaMode >= 1;   // KRONOS, INSTRUMENT and BASS all use TIME 0..127
        static const char* const kPortaNames[4] = {"SILVETON", "KRONOS", "INSTRUMENT", "BASS"};   // SILVETON_BASS_PORTA_V1: the real name of the mode
        const auto& selState = upperStates[static_cast<std::size_t>(selectedUpper_)];
        const float porta = selState ? selState->portamentoSec : 0.0F;
        const RectF po(x, 8.0F, 1242.0F, 64.0F);
        box(po);
        text(c, "PORTA U" + std::to_string(selectedUpper_ + 1) + " · " + kPortaNames[portaMode], po.left + 10.0F, po.top + 17.0F, 9.5F, C_LCD_DIM,
             Opt().mono().maxW(po.width() - 16.0F));
        std::string tv;
        if (kronos) { const int t = static_cast<int>(at(up, 45U, 0.0F)); tv = t <= 0 ? "OFF" : "TIME " + std::to_string(t); }
        else if (porta <= 0.0F) tv = "OFF";
        else tv = std::to_string(roundToInt(porta * 1000.0F)) + " ms";
        text(c, tv, po.left + 10.0F, po.top + 37.0F, 16.0F, C_LCD, Opt().monoBold().maxW(po.width() - 16.0F));
        std::string sub;
        if (kronos) sub = std::string(at(up, 43U, 0.0F) >= 0.5F ? "FINGERED" : "ВИНАГИ") + " · " + (at(up, 44U, 0.0F) >= 0.5F ? "RATE" : "TIME");
        else sub = "СЪСЕДНИ " + std::to_string(sampler.portaNear()) + " · BAL " + std::to_string(sampler.portaBalance());
        text(c, sub, po.left + 10.0F, po.bottom - 7.0F, 9.5F, C_LCD_VALUE, Opt().mono().maxW(po.width() - 16.0F));
        hit(po, [this](float, float) { page_ = Page::COMBI; tab = UpperTab::PORTA; });
    }

    const RectF panic(1250.0F, 8.0F, 1330.0F, 64.0F);
    const bool down = isDown(panic);
    fill(c, panic, 8.0F, Color::rgb(70, 18, 14));
    fillV(c, RectF(panic.left + 1.0F, panic.top + 1.0F, panic.right - 1.0F, panic.bottom - 1.0F), 7.0F, down ? C_PANIC : Color::rgb(204, 70, 60),
          down ? Color::rgb(140, 28, 22) : Color::rgb(156, 42, 36));
    if (!down) line(c, panic.left + 8.0F, panic.top + 2.0F, panic.right - 8.0F, panic.top + 2.0F, Color::argb(80, 255, 255, 255), 1.0F);
    text(c, "PANIC", panic.centerX(), panic.centerY() + 5.0F, 14.0F, Color::WHITE, Opt().center().bold().spacing(0.18F));
    hit(panic, [this](float, float) { sampler.panic(); });
}

} // namespace silveton::ui
