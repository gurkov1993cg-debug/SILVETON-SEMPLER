// SILVETON_KEYRANGE_V1 / SILVETON_VELOCITY_V1 - the RANGE page (KEYS only) and the VEL page of one sound of an Upper
// (0 = ОСНОВЕН, 1..4 = L1..L4). Both pages show all five sounds of the Upper as bars, so overlaps are seen at a glance; a tap on a row
// chooses that sound, a drag on a bar moves its end. Everything is live: every change goes straight into the engine.
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/sampler/VelocityShape.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
int rnd(float v) { return static_cast<int>(std::nearbyint(v)); }
float rndf(float v) { return std::nearbyint(v); }

// The ids of the velocity values of a sound in upperParams (ОСНОВЕН) and layerParams (L1..L4); see SamplerHost.cpp.
struct VelIds { int fadeIn, fadeOut, response, curve, custom0, compress, attack, xfade; };
VelIds velIds(int sound) {
    return sound == 0 ? VelIds{50, 51, 52, 55, 56, 65, 66, 67} : VelIds{32, 33, 34, 35, 36, 45, 46, 47};
}
constexpr int kCustomDefault[9] = {0, 16, 32, 48, 64, 79, 95, 111, 127};

// where the bar of a row is, for the key rows and for the velocity rows
struct RowGeom {
    float labelW{50.0F};
    float chipW{0.0F};
    float barL{0.0F};
    float barR{0.0F};
    int minV{0};
    int slots{128};   // how many values the bar holds
    float x(int v) const { return barL + (barR - barL) * static_cast<float>(v - minV) / static_cast<float>(slots); }
    int valueAt(float px) const { return static_cast<int>(std::floor((px - barL) / (barR - barL) * static_cast<float>(slots) + 0.5F)) + minV; }
};
RowGeom rowGeom(const RectF& a, bool velocity) {
    RowGeom g;
    g.chipW = velocity ? 44.0F : 0.0F;
    g.minV = velocity ? 1 : 0;
    g.slots = velocity ? 127 : 128;
    g.barL = a.left + g.labelW + (velocity ? g.chipW + 6.0F : 0.0F);
    g.barR = a.right - (velocity ? g.chipW + 6.0F : 80.0F);
    return g;
}
constexpr float kRowH = 32.0F;
constexpr float kRowGap = 4.0F;
} // namespace

// ---------------------------------------------------------------- values of a sound
float SilvetonSamplerView::velP(int u, int sound, int id, float def) {
    return sound == 0 ? getOr(uParams(u), id, def) : getOr(lParams(u, sound - 1), id, def);
}

void SilvetonSamplerView::setVelP(int u, int sound, int id, float v) {
    if (sound == 0) setUParam(u, id, v); else setLParam(u, sound - 1, id, v);
}

void SilvetonSamplerView::selectSound(int u, int k) {
    stripSound[static_cast<std::size_t>(u)] = k;
    selectedUpper_ = u;
    editSound = k;
    dropUpper = -1;
    invalidate();
}

SilvetonSamplerView::SoundRanges SilvetonSamplerView::soundRanges(int u, int sound) {
    SoundRanges r;
    if (sound == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        if (st) {
            r.keyLow = st->keyLow; r.keyHigh = st->keyHigh; r.velLow = st->velocityLow; r.velHigh = st->velocityHigh; r.transpose = st->transpose;
            r.has = !(st->soundName == "EMPTY" || isBlank(st->soundName));
            if (r.has) r.name = st->soundName;
        }
    } else {
        const std::vector<float> p = lParams(u, sound - 1);
        r.keyLow = static_cast<int>(getOr(p, 6, 0.0F)); r.keyHigh = static_cast<int>(getOr(p, 7, 127.0F));
        r.velLow = static_cast<int>(getOr(p, 8, 1.0F)); r.velHigh = static_cast<int>(getOr(p, 9, 127.0F));
        r.transpose = static_cast<int>(getOr(p, 3, 0.0F));
        r.has = layerSlot(u, sound - 1) > 0;
        if (r.has) r.name = lName(u, sound - 1);
    }
    r.keyLow = std::clamp(r.keyLow, 0, 127);
    r.keyHigh = std::clamp(r.keyHigh, r.keyLow, 127);
    r.velLow = std::clamp(r.velLow, 1, 127);
    r.velHigh = std::clamp(r.velHigh, r.velLow, 127);
    return r;
}

void SilvetonSamplerView::setSoundKeyRange(int u, int sound, int lo, int hi) {
    lo = std::clamp(lo, 0, 127);
    hi = std::clamp(hi, lo, 127);
    if (sound == 0) {
        if (!upperStates[static_cast<std::size_t>(u)]) return;
        UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
        n.keyLow = lo;
        n.keyHigh = hi;
        commitMain(u, n);
    } else {
        setLParam(u, sound - 1, 6, static_cast<float>(lo));
        setLParam(u, sound - 1, 7, static_cast<float>(hi));
    }
}

void SilvetonSamplerView::setSoundVelRange(int u, int sound, int lo, int hi) {
    lo = std::clamp(lo, 1, 127);
    hi = std::clamp(hi, lo, 127);
    if (sound == 0) {
        if (!upperStates[static_cast<std::size_t>(u)]) return;
        UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
        n.velocityLow = lo;
        n.velocityHigh = hi;
        commitRange(n);
    } else {
        setLParam(u, sound - 1, 8, static_cast<float>(lo));
        setLParam(u, sound - 1, 9, static_cast<float>(hi));
    }
}

// A compact value box: label on the left, value on the right. Drag up / right raises, a long press asks for the number, a double tap resets.
void SilvetonSamplerView::paramChip(Canvas& c, const RectF& r, const std::string& label, const std::string& value, bool on, float v, float minV,
                                    float maxV, float step, std::function<void(float)> onChange, std::function<void()> exact,
                                    std::function<void()> reset) {
    lcd(c, r, 7.0F);
    text(c, label, r.left + 10.0F, r.centerY() + 4.0F, 11.0F, C_LCD_DIM, Opt().bold().spacing(0.08F).maxW(r.width() * 0.52F));
    text(c, value, r.right - 10.0F, r.centerY() + 6.0F, 15.0F, on ? C_LCD : C_LCD_DIM, Opt().right().mono().maxW(r.width() * 0.46F));
    knobHit(r, v, minV, maxV, step, 240.0F, std::move(onChange), std::move(exact), std::move(reset));
}

// ---------------------------------------------------------------- the five sounds as bars
// velocity = false: the KEY ranges (0..127); velocity = true: the VELOCITY ranges (1..127) with their fades drawn as ramps.
void SilvetonSamplerView::drawSoundRows(Canvas& c, const RectF& a, int u, int sound, bool velocity) {
    const RowGeom g = rowGeom(a, velocity);
    for (int k = 0; k <= 4; ++k) {
        const SoundRanges rg = soundRanges(u, k);
        const int lo = velocity ? rg.velLow : rg.keyLow;
        const int hi = velocity ? rg.velHigh : rg.keyHigh;
        const bool sel = k == sound;
        const float y = a.top + static_cast<float>(k) * (kRowH + kRowGap);
        const RectF rr(a.left, y, a.right, y + kRowH);
        if (sel) fill(c, rr, 8.0F, colorWithAlpha(C_ACCENT, 70));
        const RectF labelR(rr.left, rr.top, rr.left + g.labelW, rr.bottom);
        text(c, k == 0 ? "ОСН" : "L" + std::to_string(k), rr.left + 8.0F, rr.centerY() + 4.0F, 12.0F, sel ? C_VALUE : (rg.has ? C_KNOB_LABEL : C_HINT), Opt().bold());
        hit(labelR, [this, u, k](float, float) { selectSound(u, k); });

        const RectF track(g.barL, rr.top + 5.0F, g.barR, rr.bottom - 5.0F);
        fill(c, track, 5.0F, C_METER_BG);
        const float xl = g.x(lo);
        const float xr = g.x(hi + 1);
        const ColorInt col = !rg.has ? colorWithAlpha(C_HINT, 110) : (sel ? C_ACCENT : colorWithAlpha(C_ACCENT, 130));
        if (velocity) {
            // the sound comes in over FADE IN steps from its lowest value and goes out over FADE OUT steps up to its highest
            const VelIds id = velIds(k);
            const int fi = std::clamp(rnd(velP(u, k, id.fadeIn, 0.0F)), 0, 127);
            const int fo = std::clamp(rnd(velP(u, k, id.fadeOut, 0.0F)), 0, 127);
            float xi = g.x(std::min(lo + fi, hi + 1));
            float xo = g.x(std::max(hi + 1 - fo, lo));
            if (xi > xo) xi = xo = (xi + xo) * 0.5F;
            Path path;
            path.moveTo(xl, track.bottom);
            path.lineTo(xi, track.top);
            path.lineTo(xo, track.top);
            path.lineTo(xr, track.bottom);
            path.close();
            paint.shader = nullptr;
            paint.style = Style::Fill;
            paint.color = col;
            c.drawPath(path, paint);
        } else {
            fill(c, RectF(xl, track.top, std::max(xr, xl + 2.0F), track.bottom), 3.0F, col);
        }
        const ColorInt handle = sel ? C_VALUE : C_KNOB_LABEL;
        fill(c, RectF(xl - 2.0F, track.top - 2.0F, xl + 2.0F, track.bottom + 2.0F), 2.0F, handle);
        fill(c, RectF(xr - 2.0F, track.top - 2.0F, xr + 2.0F, track.bottom + 2.0F), 2.0F, handle);

        if (velocity) {
            // the numbers at both ends: a tap asks for the exact value
            const RectF loR(rr.left + g.labelW, rr.top + 3.0F, rr.left + g.labelW + g.chipW, rr.bottom - 3.0F);
            const RectF hiR(rr.right - g.chipW, rr.top + 3.0F, rr.right, rr.bottom - 3.0F);
            lcd(c, loR, 5.0F);
            lcd(c, hiR, 5.0F);
            text(c, std::to_string(lo), loR.centerX(), loR.centerY() + 5.0F, 13.0F, rg.has ? C_LCD : C_LCD_DIM, Opt().center().mono());
            text(c, std::to_string(hi), hiR.centerX(), hiR.centerY() + 5.0F, 13.0F, rg.has ? C_LCD : C_LCD_DIM, Opt().center().mono());
            const std::string who = k == 0 ? "ОСНОВЕН" : "L" + std::to_string(k);
            hit(loR,
                [this, u, k, lo, hi, who](float, float) {
                    selectSound(u, k);
                    showNumber(who + " VELOCITY МИН", static_cast<float>(lo), 1.0F, 127.0F, 0,
                               [this, u, k, hi](float x) { setSoundVelRange(u, k, std::min(rnd(x), hi), hi); });
                },
                [this, u, k, hi] { setSoundVelRange(u, k, 1, hi); });
            hit(hiR,
                [this, u, k, lo, hi, who](float, float) {
                    selectSound(u, k);
                    showNumber(who + " VELOCITY МАКС", static_cast<float>(hi), 1.0F, 127.0F, 0,
                               [this, u, k, lo](float x) { setSoundVelRange(u, k, lo, std::max(rnd(x), lo)); });
                },
                [this, u, k, lo] { setSoundVelRange(u, k, lo, 127); });
        } else {
            text(c, noteName(lo) + "–" + noteName(hi), rr.right - 4.0F, rr.centerY() + 4.0F, 11.0F, rg.has ? C_VALUE : C_HINT, Opt().right().mono().maxW(78.0F));
        }

        // a drag on the bar moves the nearer end; a tap chooses the sound; a long press asks for the number; a double tap = the whole range
        const RectF dragR(track.left - 8.0F, rr.top, track.right + 8.0F, rr.bottom);
        hit(dragR,
            [this, u, k, lo, hi, velocity, xl, xr](float px, float) {
                selectSound(u, k);
                const bool low = std::fabs(px - xl) <= std::fabs(px - xr);
                const std::string who = k == 0 ? "ОСНОВЕН" : "L" + std::to_string(k);
                if (velocity) {
                    if (low) showNumber(who + " VELOCITY МИН", static_cast<float>(lo), 1.0F, 127.0F, 0, [this, u, k, hi](float x) { setSoundVelRange(u, k, std::min(rnd(x), hi), hi); });
                    else showNumber(who + " VELOCITY МАКС", static_cast<float>(hi), 1.0F, 127.0F, 0, [this, u, k, lo](float x) { setSoundVelRange(u, k, lo, std::max(rnd(x), lo)); });
                } else {
                    if (low) showNumber(who + " КЛАВИШ ОТ (0 = C-1 · 60 = C4)", static_cast<float>(lo), 0.0F, 127.0F, 0, [this, u, k, hi](float x) { setSoundKeyRange(u, k, std::min(rnd(x), hi), hi); });
                    else showNumber(who + " КЛАВИШ ДО (0 = C-1 · 60 = C4)", static_cast<float>(hi), 0.0F, 127.0F, 0, [this, u, k, lo](float x) { setSoundKeyRange(u, k, lo, std::max(rnd(x), lo)); });
                }
            },
            [this, u, k, velocity] { if (velocity) setSoundVelRange(u, k, 1, 127); else setSoundKeyRange(u, k, 0, 127); },
            [this, u, k, lo, hi, velocity, xl, xr, g, which = -1](float px, float, bool) mutable {
                if (!dragMoved) { selectSound(u, k); return; }   // a plain tap only chooses the sound
                if (which < 0) {
                    const float d1 = std::fabs(downX - xl);
                    const float d2 = std::fabs(downX - xr);
                    which = d1 < d2 ? 0 : (d2 < d1 ? 1 : (px >= downX ? 1 : 0));
                    selectSound(u, k);
                }
                if (which == 0) {
                    const int v = std::clamp(g.valueAt(px), g.minV, hi);
                    if (velocity) setSoundVelRange(u, k, v, hi); else setSoundKeyRange(u, k, v, hi);
                } else {
                    const int v = std::clamp(g.valueAt(px) - 1, lo, 127);
                    if (velocity) setSoundVelRange(u, k, lo, v); else setSoundKeyRange(u, k, lo, v);
                }
            });
    }
}

// ---------------------------------------------------------------- RANGE: keys only
void SilvetonSamplerView::drawKeyRangePage(Canvas& c, const RectF& sec, int u, int sound) {
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const SoundRanges rg = soundRanges(u, sound);
    const RectF left(sec.left, sec.top, sec.left + 742.0F, sec.bottom);
    const RectF right(left.right + 8.0F, sec.top, sec.right, sec.bottom);

    // the keys of the chosen sound: bar with two ends, the numbers, the keyboard
    rangeHalf(c, left, "KEY RANGE · " + soundLabel(sound), "ОТ", "ДО", rg.keyLow, rg.keyHigh, 0, 127, [](int v) { return noteName(v); },
              "Влачи краищата · Докосни нотите = точна стойност · Двоен допир = цялата",
              [this, u, sound](int a, int b) { setSoundKeyRange(u, sound, a, b); },
              [this, u, sound, rg] {
                  showNumber("КЛАВИШ ОТ (0 = C-1 · 60 = C4)", static_cast<float>(rg.keyLow), 0.0F, 127.0F, 0,
                             [this, u, sound, rg](float x) { setSoundKeyRange(u, sound, std::min(rnd(x), rg.keyHigh), rg.keyHigh); });
              },
              [this, u, sound, rg] {
                  showNumber("КЛАВИШ ДО (0 = C-1 · 60 = C4)", static_cast<float>(rg.keyHigh), 0.0F, 127.0F, 0,
                             [this, u, sound, rg](float x) { setSoundKeyRange(u, sound, rg.keyLow, std::max(rnd(x), rg.keyLow)); });
              },
              [this, u, sound] { sampler.cancelKeyScan(); setSoundKeyRange(u, sound, 0, 127); }, true, -1);

    // the keys can also be set by playing: a tap, then the key on the MIDI keyboard
    for (int edge = 0; edge < 2; ++edge) {
        const RectF kr(left.right - (edge == 0 ? 324.0F : 160.0F), left.top + 10.0F, left.right - (edge == 0 ? 170.0F : 14.0F), left.top + 44.0F);
        const bool scanning = sampler.keyScanUpper() == u && sampler.keyScanSound() == sound && sampler.keyScanEdge() == edge;
        const bool blink = scanning && (nowMs() / 300) % 2 == 0;
        stripToggle(c, kr, scanning ? "НАТИСНИ КЛАВИШ…" : (edge == 0 ? "ЗАДАЙ ОТ · MIDI" : "ЗАДАЙ ДО · MIDI"), scanning, blink ? C_ACCENT : C_AMBER, 11.0F);
        if (scanning) postInvalidateDelayed(150);
        hit(kr, [this, u, sound, edge, scanning](float, float) {
            if (scanning) sampler.cancelKeyScan(); else sampler.startKeyScan(u, sound, edge);
            invalidate();
        });
    }

    // the transposition of the sound (the same value as on the TUNE page)
    {
        const RectF cr(left.left + 244.0F, left.top + 10.0F, left.left + 394.0F, left.top + 44.0F);
        const int t = rg.transpose;
        paramChip(c, cr, "ТРАНСП.", signed_(t) + " st", t != 0, static_cast<float>(t), -12.0F, 12.0F, 1.0F,
                  [this, u, sound](float nv) {
                      const int v = std::clamp(rnd(nv), -12, 12);
                      if (sound == 0) {
                          if (!upperStates[static_cast<std::size_t>(u)]) return;
                          UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
                          n.transpose = v;
                          commitTune(n);
                      } else {
                          setLParam(u, sound - 1, 3, static_cast<float>(v));
                      }
                  },
                  [this, u, sound, t] {
                      showNumber("ТРАНСПОНИРАНЕ (полутонове)", static_cast<float>(t), -12.0F, 12.0F, 0, [this, u, sound](float x) {
                          const int v = std::clamp(rnd(x), -12, 12);
                          if (sound == 0) {
                              if (!upperStates[static_cast<std::size_t>(u)]) return;
                              UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
                              n.transpose = v;
                              commitTune(n);
                          } else {
                              setLParam(u, sound - 1, 3, static_cast<float>(v));
                          }
                      });
                  },
                  [this, u, sound] {
                      if (sound == 0) {
                          if (!upperStates[static_cast<std::size_t>(u)]) return;
                          UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
                          n.transpose = 0;
                          commitTune(n);
                      } else {
                          setLParam(u, sound - 1, 3, 0.0F);
                      }
                  });
    }

    // all five sounds of the Upper: where they overlap
    section(c, right, "ПРЕКЛАПЯНЕ · КЛАВИШИ");
    const RectF rows(right.left + 12.0F, right.top + 44.0F, right.right - 12.0F, right.bottom - 8.0F);
    drawSoundRows(c, rows, u, sound, false);
    {
        const RowGeom g = rowGeom(rows, false);
        const float y0 = rows.top + 5.0F * (kRowH + kRowGap) + 2.0F;
        const RectF strip(g.barL, y0, g.barR, y0 + 8.0F);
        fill(c, strip, 3.0F, C_METER_BG);
        int counts[128] = {};
        for (int k = 0; k <= 4; ++k) {
            const SoundRanges r2 = soundRanges(u, k);
            if (!r2.has || (k > 0 && !layerOn(u, k - 1))) continue;
            for (int v = r2.keyLow; v <= r2.keyHigh; ++v) ++counts[v];
        }
        int v = 0;
        while (v < 128) {
            int w = v;
            while (w < 128 && counts[w] == counts[v]) ++w;
            if (counts[v] > 0) fill(c, RectF(g.x(v), strip.top, g.x(w), strip.bottom), 0.0F, counts[v] >= 2 ? C_AMBER : colorWithAlpha(C_ACCENT, 160));
            v = w;
        }
        text(c, "ПРЕКЛ.", rows.left + 8.0F, y0 + 8.0F, 10.0F, C_HINT, Opt().bold());
        text(c, "заедно", rows.right - 4.0F, y0 + 8.0F, 10.0F, C_AMBER, Opt().right().bold().maxW(g.barR < rows.right ? rows.right - g.barR - 4.0F : 50.0F));
    }
}

// ---------------------------------------------------------------- VEL: the strength of the key press
void SilvetonSamplerView::drawVelocityPage(Canvas& c, const RectF& sec, int u, int sound) {
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    using silveton::sampler::VelocityShape;
    const VelIds id = velIds(sound);
    const std::string who = sound == 0 ? "ОСНОВЕН" : "L" + std::to_string(sound);
    const RectF b1(sec.left, sec.top, sec.left + 470.0F, sec.bottom);
    const RectF b2(b1.right + 8.0F, sec.top, b1.right + 8.0F + 282.0F, sec.bottom);
    const RectF b3(b2.right + 8.0F, sec.top, sec.right, sec.bottom);

    // ---- 1: the five sounds on the scale 1..127
    section(c, b1, "СИЛА НА УДАРА 1–127 · UPPER " + std::to_string(u + 1));
    const RectF rows(b1.left + 12.0F, b1.top + 44.0F, b1.right - 12.0F, b1.bottom - 8.0F);
    drawSoundRows(c, rows, u, sound, true);
    {
        const RowGeom g = rowGeom(rows, true);
        const float y = rows.top + 5.0F * (kRowH + kRowGap) + 10.0F;
        for (const int v : {1, 32, 64, 96, 127}) text(c, std::to_string(v), g.x(v == 1 ? 1 : v), y, 10.0F, C_HINT, Opt().center().mono());
    }

    // ---- 2: the curve of this sound
    section(c, b2, "КРИВА · " + who);
    VelocityShape sh;
    sh.curve = static_cast<std::uint8_t>(std::clamp(rnd(velP(u, sound, id.curve, 0.0F)), 0, 6));
    for (int i = 0; i < 9; ++i) sh.custom[static_cast<std::size_t>(i)] = static_cast<std::uint8_t>(std::clamp(rnd(velP(u, sound, id.custom0 + i, static_cast<float>(kCustomDefault[i]))), 0, 127));
    sh.compress = velP(u, sound, id.compress, 0.0F);
    const float resp = velP(u, sound, id.response, 1.0F);
    const RectF g(b2.left + 16.0F, b2.top + 42.0F, b2.right - 16.0F, b2.top + 158.0F);
    lcd(c, g, 6.0F);
    const RectF gi(g.left + 12.0F, g.top + 10.0F, g.right - 12.0F, g.bottom - 10.0F);
    for (const float q : {0.25F, 0.5F, 0.75F}) {
        line(c, gi.left + gi.width() * q, gi.top, gi.left + gi.width() * q, gi.bottom, Color::argb(36, 255, 255, 255), 1.0F);
        line(c, gi.left, gi.bottom - gi.height() * q, gi.right, gi.bottom - gi.height() * q, Color::argb(36, 255, 255, 255), 1.0F);
    }
    line(c, gi.left, gi.bottom, gi.right, gi.top, Color::argb(60, 255, 255, 255), 1.0F);   // as played
    {
        Path path;
        const int n = 64;
        for (int i = 0; i <= n; ++i) {
            const float x = static_cast<float>(i) / static_cast<float>(n);
            float y = silveton::sampler::velocityShaped(sh, x);
            if (std::fabs(resp - 1.0F) > 0.0001F) y = std::pow(std::clamp(y, 0.0F, 1.0F), std::clamp(resp, 0.25F, 4.0F));
            const float px = gi.left + gi.width() * x;
            const float py = gi.bottom - gi.height() * std::clamp(y, 0.0F, 1.0F);
            if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        paint.shader = nullptr;
        paint.style = Style::Stroke;
        paint.strokeWidth = 7.0F;
        paint.color = Color::argb(60, 140, 220, 170);
        c.drawPath(path, paint);
        paint.strokeWidth = 2.5F;
        paint.color = Color::rgb(232, 238, 240);
        c.drawPath(path, paint);
        paint.style = Style::Fill;
    }
    if (sh.curve == 6U) {
        for (int i = 0; i < 9; ++i) {
            const float px = gi.left + gi.width() * static_cast<float>(i) / 8.0F;
            const float py = gi.bottom - gi.height() * static_cast<float>(sh.custom[static_cast<std::size_t>(i)]) / 127.0F;
            paint.color = Color::argb(170, 0, 0, 0);
            c.drawCircle(px, py + 1.5F, 6.5F, paint);
            paint.color = C_AMBER;
            c.drawCircle(px, py, 6.0F, paint);
        }
    }
    text(c, "1", g.left + 5.0F, g.bottom - 4.0F, 9.0F, C_LCD_DIM, Opt().mono());
    text(c, "127", g.right - 5.0F, g.bottom - 4.0F, 9.0F, C_LCD_DIM, Opt().right().mono());
    text(c, sh.curve == 6U ? "ВЛАЧИ ТОЧКИТЕ" : "ВЛАЧИ = СВОЯ КРИВА", g.left + 8.0F, g.top + 12.0F, 9.0F, C_LCD_DIM, Opt().bold().maxW(g.width() - 16.0F));
    // a drag on the graph draws the curve through its nine points (a ready curve becomes the start of the own one)
    hit(g, [](float, float) {}, [this, u, sound, id] {
            setVelP(u, sound, id.curve, 0.0F);
            for (int i = 0; i < 9; ++i) setVelP(u, sound, id.custom0 + i, static_cast<float>(kCustomDefault[i]));
        },
        [this, u, sound, id, sh, gi, which = -1](float, float py, bool) mutable {
            if (!dragMoved) return;
            if (which < 0) {
                which = std::clamp(static_cast<int>(std::floor((downX - gi.left) / gi.width() * 8.0F + 0.5F)), 0, 8);
                if (sh.curve != 6U) {
                    for (int i = 0; i < 9; ++i) {
                        const float y = silveton::sampler::velocityCurveValue(sh.curve, sh.custom, static_cast<float>(i) / 8.0F);
                        setVelP(u, sound, id.custom0 + i, rndf(y * 127.0F));
                    }
                    setVelP(u, sound, id.curve, 6.0F);
                }
            }
            setVelP(u, sound, id.custom0 + which, rndf(std::clamp((gi.bottom - py) / gi.height(), 0.0F, 1.0F) * 127.0F));
        });
    // the ready curves
    struct CurveKey { const char* name; int type; };
    const CurveKey keys[7] = {{"SOFT", 1}, {"LINEAR", 0}, {"HARD", 2}, {"EXP", 3}, {"LOG", 4}, {"S-CURVE", 5}, {"СВОЯ", 6}};
    for (int k = 0; k < 7; ++k) {
        const int row = k < 4 ? 0 : 1;
        const int col = k < 4 ? k : k - 4;
        const int per = row == 0 ? 4 : 3;
        const float w = (b2.width() - 32.0F - static_cast<float>(per - 1) * 6.0F) / static_cast<float>(per);
        const float x0 = b2.left + 16.0F + static_cast<float>(col) * (w + 6.0F);
        const float y0 = g.bottom + 10.0F + static_cast<float>(row) * 34.0F;
        const RectF kr(x0, y0, x0 + w, y0 + 28.0F);
        const int type = keys[k].type;
        stripToggle(c, kr, keys[k].name, static_cast<int>(sh.curve) == type, C_ACCENT, 10.0F);
        hit(kr, [this, u, sound, id, sh, type](float, float) {
            if (type == 6 && sh.curve != 6U) {   // the own curve starts like the curve that was on
                for (int i = 0; i < 9; ++i) {
                    const float y = silveton::sampler::velocityCurveValue(sh.curve, sh.custom, static_cast<float>(i) / 8.0F);
                    setVelP(u, sound, id.custom0 + i, rndf(y * 127.0F));
                }
            }
            setVelP(u, sound, id.curve, static_cast<float>(type));
        });
    }

    // ---- 3: fades, shape, what the strength does
    section(c, b3, "ДИНАМИКА · " + who);
    const float colW = (b3.width() - 32.0F - 10.0F) / 2.0F;
    const auto cell = [&](int row, int col) {
        const float x0 = b3.left + 16.0F + static_cast<float>(col) * (colW + 10.0F);
        const float y0 = b3.top + 44.0F + static_cast<float>(row) * 36.0F;
        return RectF(x0, y0, x0 + colW, y0 + 30.0F);
    };
    const auto fadeChip = [&](int row, int col, const char* label, int pid) {
        const float v = velP(u, sound, pid, 0.0F);
        paramChip(c, cell(row, col), label, v <= 0.0F ? "ИЗКЛ" : std::to_string(rnd(v)), v > 0.0F, v, 0.0F, 127.0F, 1.0F,
                  [this, u, sound, pid](float nv) { setVelP(u, sound, pid, rndf(nv)); },
                  [this, u, sound, pid, v, label] {
                      showNumber(std::string(label) + " (0 = ИЗКЛ)", v, 0.0F, 127.0F, 0, [this, u, sound, pid](float x) { setVelP(u, sound, pid, rndf(x)); });
                  },
                  [this, u, sound, pid] { setVelP(u, sound, pid, 0.0F); });
    };
    fadeChip(0, 0, "FADE IN", id.fadeIn);
    fadeChip(0, 1, "FADE OUT", id.fadeOut);
    paramChip(c, cell(1, 0), "ФОРМА", fmtFixed(static_cast<double>(resp), 2) + " ×", std::fabs(resp - 1.0F) > 0.001F, resp, 0.25F, 4.0F, 0.05F,
              [this, u, sound, id](float nv) { setVelP(u, sound, id.response, nv); },
              [this, u, sound, id, resp] { showNumber("ФОРМА НА ДИНАМИКАТА (1.0 = ОРИГИНАЛ)", resp, 0.25F, 4.0F, 2, [this, u, sound, id](float x) { setVelP(u, sound, id.response, x); }); },
              [this, u, sound, id] { setVelP(u, sound, id.response, 1.0F); });
    {
        const float v = sh.compress;
        const std::string txt = std::fabs(v) < 0.005F ? "ИЗКЛ" : std::string(v > 0.0F ? "КОМПР. " : "РАЗШ. ") + std::to_string(rnd(std::fabs(v) * 100.0F)) + " %";
        paramChip(c, cell(1, 1), "КОМПР./РАЗШ.", txt, std::fabs(v) >= 0.005F, v, -1.0F, 1.0F, 0.05F,
                  [this, u, sound, id](float nv) { setVelP(u, sound, id.compress, nv); },
                  [this, u, sound, id, v] {
                      showNumber("КОМПРЕСИЯ (+) / РАЗШИРЕНИЕ (−) %", v * 100.0F, -100.0F, 100.0F, 0, [this, u, sound, id](float x) { setVelP(u, sound, id.compress, x / 100.0F); });
                  },
                  [this, u, sound, id] { setVelP(u, sound, id.compress, 0.0F); });
    }
    {
        const float v = toneX(u, sound, 4);
        paramChip(c, cell(2, 0), "→ СИЛА", fmtFixed(static_cast<double>(v * 100.0F), 0) + " %", v < 0.999F, v, 0.0F, 1.0F, 0.01F,
                  [this, u, sound](float nv) { setToneX(u, sound, 4, nv); },
                  [this, u, sound, v] { showNumber("СИЛА НА УДАРА → СИЛА НА ЗВУКА %", v * 100.0F, 0.0F, 100.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 4, x / 100.0F); }); },
                  [this, u, sound] { setToneX(u, sound, 4, 1.0F); });
        const float f = toneX(u, sound, 5);
        paramChip(c, cell(2, 1), "→ ФИЛТЪР", fmtFixed(static_cast<double>(f), 2) + " oct", f > 0.001F, f, 0.0F, 8.0F, 0.05F,
                  [this, u, sound](float nv) { setToneX(u, sound, 5, nv); },
                  [this, u, sound, f] { showNumber("СИЛА НА УДАРА → ФИЛТЪР (октави)", f, 0.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 5, x); }); },
                  [this, u, sound] { setToneX(u, sound, 5, 0.0F); });
    }
    {
        const float v = sh.toAttack;
        paramChip(c, cell(3, 0), "→ АТАКА", v <= 0.0F ? "ИЗКЛ" : "+" + std::to_string(rnd(v * silveton::sampler::kVelocityAttackMaxMs)) + " ms", v > 0.0F, v, 0.0F, 1.0F, 0.01F,
                  [this, u, sound, id](float nv) { setVelP(u, sound, id.attack, nv); },
                  [this, u, sound, id, v] {
                      showNumber("СИЛА НА УДАРА → АТАКА (най-тихият удар получава толкова ms)", v * silveton::sampler::kVelocityAttackMaxMs, 0.0F, silveton::sampler::kVelocityAttackMaxMs, 0,
                                 [this, u, sound, id](float x) { setVelP(u, sound, id.attack, x / silveton::sampler::kVelocityAttackMaxMs); });
                  },
                  [this, u, sound, id] { setVelP(u, sound, id.attack, 0.0F); });
    }
    {
        const bool xf = velP(u, sound, id.xfade, 0.0F) >= 0.5F;
        const RectF kr = cell(3, 1);
        stripToggle(c, kr, "КРОСФЕЙД", xf, C_AMBER, 11.0F);
        hit(kr, [this, u, sound, id, xf](float, float) {
            setVelP(u, sound, id.xfade, xf ? 0.0F : 1.0F);
            flash(xf ? "КРОСФЕЙД ИЗКЛ" : "КРОСФЕЙД ВКЛ: слоевете с него не се сумират над 1");
        });
    }
    {
        const bool independent = getOr(uParams(u), 54, 1.0F) >= 0.5F;
        const RectF kr = cell(4, 0);
        stripToggle(c, kr, "САМОСТ. L1–L4", independent, C_AMBER, 11.0F);
        hit(kr, [this, u, independent](float, float) {
            setUParam(u, 54, independent ? 0.0F : 1.0F);
            flash(independent ? "ОБЩ ОБХВАТ: ОСНОВЕН затваря целия Upper" : "САМОСТОЯТЕЛНИ: всеки слой има свой обхват");
        });
        const RectF rr = cell(4, 1);
        stripToggle(c, rr, "НУЛИРАЙ", false, C_AMBER, 11.0F);
        hit(rr, [this](float, float) { flash("ДВОЕН ДОПИР = НУЛИРА КРИВАТА, FADE, КОМПРЕСИЯТА, АТАКАТА И КРОСФЕЙДА (ОБХВАТЪТ ОСТАВА)"); },
            [this, u, sound, id] {
                setVelP(u, sound, id.fadeIn, 0.0F);
                setVelP(u, sound, id.fadeOut, 0.0F);
                setVelP(u, sound, id.response, 1.0F);
                setVelP(u, sound, id.curve, 0.0F);
                for (int i = 0; i < 9; ++i) setVelP(u, sound, id.custom0 + i, static_cast<float>(kCustomDefault[i]));
                setVelP(u, sound, id.compress, 0.0F);
                setVelP(u, sound, id.attack, 0.0F);
                setVelP(u, sound, id.xfade, 0.0F);
                flash("ДИНАМИКАТА Е НУЛИРАНА");
            });
    }
    text(c, "Влачи числата ↑ → · Задръж = въвеждане · Двоен допир = нула", b3.left + 16.0F, b3.bottom - 10.0F, 10.0F, C_HINT, Opt().maxW(b3.width() - 32.0F));
}

} // namespace silveton::ui
