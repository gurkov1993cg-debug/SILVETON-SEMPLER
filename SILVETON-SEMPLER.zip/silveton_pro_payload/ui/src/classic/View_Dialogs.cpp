// SILVETON_MAC_VIEW_V1 - dialogs: the tablet's Android dialogs as modal overlays (tablet SilvetonSamplerView.kt lines 2932-3261)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
// SILVETON_NEW_LOOK_V1: the dialogs use the common new-look widgets (nlPanel, nlBtn, nlLcd ...); these are the few extra colours.
constexpr ColorInt D_BACK = Color::argb(199, 0, 0, 0);               // the dimmed screen behind a dialog (rgba 0,0,0,.78)
constexpr ColorInt D_SUB = Color::rgb(163, 172, 183);                // the grey line under a title
constexpr ColorInt D_MESSAGE = Color::rgb(207, 214, 222);            // the text of a message
constexpr ColorInt D_LIST_TEXT = Color::rgb(255, 208, 138);          // the yellow rows of a message list (MISSING SOUNDS)
constexpr ColorInt D_BAD_TEXT = Color::rgb(255, 138, 138);           // a key that deletes (its text is red)

RectF intersect(const RectF& a, const RectF& b) {
    return RectF(std::max(a.left, b.left), std::max(a.top, b.top), std::min(a.right, b.right), std::min(a.bottom, b.bottom));
}

float clampF(float v, float lo, float hi) { return std::min(std::max(v, lo), hi); }

// a label that deletes something: its key is red
bool isDeleteLabel(const std::string& label) {
    return label.find("DELETE") != std::string::npos || label.find("DELETE") != std::string::npos || label.find("REMOVE") != std::string::npos;
}
} // namespace

// ---------------------------------------------------------------- public entry points
void SilvetonSamplerView::keyDown(Key key) {
    if (dialogIsOpen()) { dialogKey(key); return; }
    if (key != Key::Escape) return;
    if (writeOpen) writeOpen = false;
    else if (scaleOpen_) closeScalePage();
    else if (saveOpen_) saveOpen_ = false;
    else if (listPasteMode_) listCancelPasteSelection();
    else if (listStoreMode_) listStoreMode_ = false;
    else if (listMarkMode_) listEndMarking();
    invalidate();
}

void SilvetonSamplerView::typeText(const std::string& utf8) {
    if (dialogIsOpen()) dialogType(utf8);
}

void SilvetonSamplerView::wheel(float rawX, float rawY, float dy) {
    const float x = (rawX - uiOffsetX) / uiScale;
    const float y = (rawY - uiOffsetY) / uiScale;
    if (dialogIsOpen()) dialogWheel(x, y, dy);
}

// ---------------------------------------------------------------- stack
void SilvetonSamplerView::closeDialog(const std::shared_ptr<Dialog>& d) {
    const auto it = std::find(dialogStack.begin(), dialogStack.end(), d);
    if (it != dialogStack.end()) dialogStack.erase(it);
    invalidate();
}

void SilvetonSamplerView::dialogFire(const std::shared_ptr<Dialog>& d, const std::function<void()>& action) {
    const std::shared_ptr<Dialog> keep = d;
    closeDialog(keep);
    if (action) action();
    invalidate();
}

void SilvetonSamplerView::dialogCancel(const std::shared_ptr<Dialog>& d) {
    if (d->kind == Dialog::Kind::Wait || !d->cancelable) return;
    const std::shared_ptr<Dialog> keep = d;
    closeDialog(keep);
    if (keep->onCancel) keep->onCancel();
    invalidate();
}

// ---------------------------------------------------------------- small helpers
std::vector<std::string> SilvetonSamplerView::wrapLines(const std::string& s, float size, Face face, float maxW) {
    std::vector<std::string> out;
    for (const std::string& para : splitChar(s, '\n')) {
        if (para.empty()) { out.emplace_back(); continue; }
        std::string cur;
        auto pushLong = [&](std::string w) {
            while (textWidth(w, size, face) > maxW) {
                const int n = utf8Length(w);
                int k = n;
                while (k > 1 && textWidth(utf8Prefix(w, k), size, face) > maxW) --k;
                if (k >= n) break;
                out.push_back(utf8Prefix(w, k));
                w = utf8Substring(w, k, n);
            }
            cur = w;
        };
        for (const std::string& word : splitChar(para, ' ')) {
            if (cur.empty()) {
                if (textWidth(word, size, face) > maxW) pushLong(word); else cur = word;
            } else {
                const std::string trial = cur + " " + word;
                if (textWidth(trial, size, face) <= maxW) {
                    cur = trial;
                } else {
                    out.push_back(cur);
                    cur.clear();
                    if (textWidth(word, size, face) > maxW) pushLong(word); else cur = word;
                }
            }
        }
        out.push_back(cur);
    }
    return out;
}

// SILVETON_NEW_LOOK_V1: a dialog card = a raised panel with the amber frame and a soft amber glow (the "mk" panel of the pictures)
void SilvetonSamplerView::dialogCard(Canvas& c, const RectF& r) {
    for (int k = 3; k >= 1; --k) {   // the glow: a few translucent rings (no blur)
        const float kk = static_cast<float>(k) * 4.0F;
        fill(c, RectF(r.left - kk, r.top - kk, r.right + kk, r.bottom + kk), 12.0F + kk, colorWithAlpha(NL_AMBER, 9));
    }
    nlPanel(c, r);
    strokeRR(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 11.0F, NL_AMBER, 2.0F);
}

// SILVETON_NEW_LOOK_V1: a key of a dialog list / grid (chosen = blue). `pressed` is for keys that do not go through hit().
void SilvetonSamplerView::dialogKeyCap(Canvas& c, const RectF& r, const std::string& label, bool selected, float size, bool pressed, bool leftAligned) {
    const NlBtn state = selected ? NlBtn::Sel : NlBtn::Plain;
    if (leftAligned) {
        nlBtn(c, r, std::string(), state, size, false);
        text(c, label, r.left + 16.0F, r.centerY() + size * 0.36F, size, selected ? Color::WHITE : Color::rgb(233, 237, 242), Opt().bold().maxW(r.width() - 32.0F));
    } else {
        nlBtn(c, r, label, state, size, false);
    }
    if (pressed) fill(c, r, std::min(8.0F, r.height() * 0.3F), Color::argb(70, 0, 0, 0));
}

// SILVETON_NEW_LOOK_V1: the title (and one grey line under it) of a card; `top` = card.top + 20
void SilvetonSamplerView::dialogHeadText(Canvas& c, const RectF& card, float top, float titleSize, const std::string& title, const std::string& subtitle) {
    text(c, title, card.left + 30.0F, top + titleSize * 0.95F, titleSize, Color::WHITE, Opt().bold().maxW(card.width() - 60.0F));
    if (!subtitle.empty()) text(c, subtitle, card.left + 30.0F, top + 52.0F, 13.0F, D_SUB, Opt().maxW(card.width() - 60.0F));
}

// The keys at the bottom: one = right, two = left and right (a small card: two halves), three or more = equal keys over the whole width.
// The main one (the last) is amber, a key that deletes is red (as in dialogs_misc.png); `top` = the top of the row.
void SilvetonSamplerView::dialogButtonRow(Canvas& c, const std::shared_ptr<Dialog>& d, const RectF& card, float top) {
    const int n = static_cast<int>(d->buttons.size());
    if (n <= 0) return;
    const float pad = card.width() < 700.0F ? 26.0F : 30.0F;
    const float inL = card.left + pad;
    const float inR = card.right - pad;
    const float h = n >= 3 ? 60.0F : 64.0F;
    const bool editor = d->kind == Dialog::Kind::Text || d->kind == Dialog::Kind::Number;
    for (int i = 0; i < n; ++i) {
        const DialogButton& b = d->buttons[static_cast<std::size_t>(i)];
        RectF r;
        if (n == 1) {
            r = RectF(inR - 260.0F, top, inR, top + h);
        } else if (n == 2) {
            const float w = card.width() < 700.0F ? (inR - inL - 28.0F) * 0.5F : 280.0F;
            r = i == 0 ? RectF(inL, top, inL + w, top + h) : RectF(inR - w, top, inR, top + h);
        } else {
            const float gap = 10.0F;
            const float w = (inR - inL - gap * static_cast<float>(n - 1)) / static_cast<float>(n);
            r = RectF(inL + static_cast<float>(i) * (w + gap), top, inL + static_cast<float>(i) * (w + gap) + w, top + h);
        }
        const bool primary = i == n - 1 && (n > 1 || d->kind == Dialog::Kind::Message);
        const NlBtn state = primary ? (isDeleteLabel(b.label) ? NlBtn::Red : NlBtn::On) : NlBtn::Plain;
        nlBtn(c, r, b.label, state, n >= 3 ? 14.0F : 15.0F, primary && editor);
        const std::function<void()> act = b.action;
        hit(r, [this, d, act](float, float) { dialogFire(d, act); });
    }
}

// ---------------------------------------------------------------- draw
void SilvetonSamplerView::drawDialogs(Canvas& c) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    fill(c, RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), 0.0F, D_BACK);
    // a click outside the card = cancel (as on the tablet), except the pages where typed work could be lost
    const bool outsideCancels = d->cancelable && d->kind != Dialog::Kind::Wait && d->kind != Dialog::Kind::Text && d->kind != Dialog::Kind::Number;
    hit(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), [this, d, outsideCancels](float, float) { if (outsideCancels) dialogCancel(d); });
    switch (d->kind) {
        case Dialog::Kind::Message:
        case Dialog::Kind::Wait: drawDialogMessage(c, d); break;
        case Dialog::Kind::Items:
        case Dialog::Kind::Multi: drawDialogList(c, d); break;
        case Dialog::Kind::Grid: drawDialogGrid(c, d); break;
        case Dialog::Kind::Text:
        case Dialog::Kind::Number: drawDialogEditor(c, d); break;
    }
}

// SILVETON_NEW_LOOK_V1: a cell of the pictures. kind 0 normal, 1 current (blue), 2 empty (a dark well), 3 marked (amber frame).
void SilvetonSamplerView::dlgCell(Canvas& c, const RectF& r, int kind) {
    const float rad = 8.0F;
    if (kind == 2) {
        fill(c, r, rad, Color::rgb(24, 26, 30));
        line(c, r.left + rad, r.top + 1.0F, r.right - rad, r.top + 1.0F, Color::argb(150, 0, 0, 0), 2.0F);
        strokeRR(c, r, rad, Color::rgb(8, 9, 11), 1.0F);
        return;
    }
    shadow(c, r, rad, 2.0F, 110);
    if (kind == 3) {   // marked: an amber glow and frame
        for (int k = 2; k >= 1; --k) {
            const float kk = static_cast<float>(k) * 3.0F;
            fill(c, RectF(r.left - kk, r.top - kk, r.right + kk, r.bottom + kk), rad + kk, colorWithAlpha(NL_AMBER, 28));
        }
    }
    fill(c, r, rad, Color::rgb(8, 9, 11));
    const RectF face(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F);
    if (kind == 1) fillV(c, face, rad - 1.0F, Color::rgb(82, 180, 255), Color::rgb(23, 96, 194));
    else if (kind == 3) fillV(c, face, rad - 1.0F, Color::rgb(58, 50, 36), Color::rgb(43, 38, 25));
    else fillV(c, face, rad - 1.0F, Color::rgb(44, 48, 55), Color::rgb(35, 38, 43));
    line(c, face.left + rad, face.top + 1.0F, face.right - rad, face.top + 1.0F, Color::argb(kind == 1 ? 90 : 30, 255, 255, 255), 1.0F);
    if (kind == 3) strokeRR(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), rad - 1.0F, NL_AMBER, 3.0F);
    if (isDown(r)) fill(c, r, rad, Color::argb(40, 0, 0, 0));
}

// MESSAGE, CONFIRM and WAIT (dialogs_misc.png): a card 600 wide, a title, the text, the keys; a waiting card has a moving bar
void SilvetonSamplerView::drawDialogMessage(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const bool wait = d->kind == Dialog::Kind::Wait;
    struct Row { std::string s; bool listRow; };
    // The first paragraph is plain; when two or more rows follow it they are a list (yellow mono: the missing sounds)
    auto build = [&](float w) {
        std::vector<Row> out;
        const std::vector<std::string> paras = splitChar(d->message, '\n');
        const bool asList = !wait && paras.size() >= 3U;
        for (std::size_t i = 0U; i < paras.size(); ++i) {
            const bool listRow = asList && i > 0U;
            for (const std::string& ln : wrapLines(paras[i], listRow ? 13.0F : (wait ? 13.0F : 14.0F), listRow ? Face::Mono : Face::Regular, w - 52.0F)) out.push_back({ln, listRow});
        }
        return out;
    };
    float w = 600.0F;
    std::vector<Row> rows = build(w);
    if (rows.size() > 9U) { w = 900.0F; rows = build(w); }
    if (rows.size() > 16U) rows.resize(16U);
    const float pad = w < 700.0F ? 26.0F : 30.0F;
    const bool hasText = !d->message.empty();
    const float pitch = wait ? 22.0F : 24.0F;
    const float firstBase = wait ? 106.0F : 73.0F;
    const float lastBase = firstBase + (rows.empty() ? 0.0F : static_cast<float>(rows.size() - 1U) * pitch);
    const float btnH = d->buttons.size() >= 3U ? 60.0F : 64.0F;
    // the keys sit at 160 under a short text (dialogs_misc.png), lower under a long one, right under the title when there is no text
    const float btnTop = !hasText ? 78.0F : std::max(160.0F, lastBase + 24.0F);
    float h = wait || d->buttons.empty() ? lastBase + 44.0F : btnTop + btnH + 26.0F;
    if (!wait) h = std::max(h, hasText ? 250.0F : 200.0F);
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    text(c, d->title, card.left + pad, card.top + 39.0F, 22.0F, Color::WHITE, Opt().bold().maxW(w - 2.0F * pad));
    for (std::size_t i = 0U; i < rows.size(); ++i) {
        const float y = card.top + firstBase + static_cast<float>(i) * pitch;
        if (rows[i].listRow) text(c, rows[i].s, card.left + pad, y, 13.0F, D_LIST_TEXT, Opt().mono().maxW(w - 2.0F * pad));
        else text(c, rows[i].s, card.left + pad, y, wait ? 13.0F : 14.0F, wait ? D_SUB : D_MESSAGE, Opt().maxW(w - 2.0F * pad));
    }
    if (wait) {
        // a bar that moves, so that you see the program is working
        const RectF bar(card.left + pad, card.top + 66.0F, card.right - pad, card.top + 78.0F);
        fillV(c, bar, 6.0F, Color::rgb(5, 7, 10), Color::rgb(13, 18, 24));
        strokeRR(c, bar, 6.0F, Color::rgb(2, 3, 4), 1.0F);
        const float t = static_cast<float>((nowMs() % 1400)) / 1400.0F;
        const float bw = bar.width() * 0.25F;
        const float x0 = bar.left + (bar.width() - bw) * (0.5F - 0.5F * std::cos(t * 6.2831853F));
        fillV(c, RectF(x0, bar.top, x0 + bw, bar.bottom), 5.0F, Color::rgb(82, 180, 255), Color::rgb(23, 102, 201));
    } else {
        dialogButtonRow(c, d, card, card.top + btnTop);
    }
}

// SILVETON_LIST_MENU_V2: the menu of a LIST position (picture list_menu.png): the name on top, the items as big keys TWO in a row, the cancel key
// last over the whole width. An odd last item (the DELETE key) takes the whole row. (itemCols > 1 asks for this big-key menu.)
void SilvetonSamplerView::drawDialogItemGrid(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const int n = static_cast<int>(d->items.size());
    const int rows = (n + 1) / 2;
    const float w = 760.0F;
    const float kh = 68.0F;
    float pitch = 82.0F;
    const float headH = 70.0F;
    const float tail = 9.0F + 61.0F + 32.0F;   // the gap, the CANCEL key, the bottom margin
    if (headH + static_cast<float>(rows) * pitch + tail > 770.0F) pitch = std::max(kh + 2.0F, (770.0F - headH - tail) / static_cast<float>(std::max(1, rows)));
    const float h = headH + static_cast<float>(rows) * pitch + tail;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    text(c, d->title, card.left + 30.0F, card.top + 40.0F, 22.0F, Color::WHITE, Opt().monoBold().maxW(w - 60.0F));
    const float top = card.top + headH;
    const float left = card.left + 30.0F, right = card.right - 30.0F;
    const float colW = (right - left - 14.0F) / 2.0F;
    for (int i = 0; i < n; ++i) {
        const int row = i / 2;
        const bool wide = (i == n - 1) && (n % 2 == 1);
        const float x0 = (i % 2 == 0 || wide) ? left : left + colW + 14.0F;
        const float x1 = wide ? right : x0 + colW;
        const float y0 = top + static_cast<float>(row) * pitch;
        const RectF r(x0, y0, x1, y0 + kh);
        const std::string& label = d->items[static_cast<std::size_t>(i)];
        if (isDeleteLabel(label)) {   // the key that deletes: its text is red
            nlBtn(c, r, std::string(), NlBtn::Plain, 15.0F, false);
            text(c, label, r.centerX(), r.centerY() + 15.0F * 0.36F, 15.0F, D_BAD_TEXT, Opt().center().bold().spacing(0.07F).maxW(r.width() - 16.0F));
        } else {
            nlBtn(c, r, label, NlBtn::Off, 15.0F, false);
        }
        const std::function<void(int)> pick = d->onItem;
        hit(r, [this, d, pick, i](float, float) { dialogFire(d, [pick, i] { if (pick) pick(i); }); });
    }
    // the buttons (CANCEL): one key over the whole width as in the picture
    const float btnTop = top + static_cast<float>(rows) * pitch + 9.0F;
    const float bh = 61.0F;
    if (d->buttons.size() == 1U) {
        const RectF r(left, btnTop, right, btnTop + bh);
        nlBtn(c, r, d->buttons[0].label, NlBtn::Plain, 15.0F, false);
        const std::function<void()> act = d->buttons[0].action;
        hit(r, [this, d, act](float, float) { dialogFire(d, act); });
    } else {
        dialogButtonRow(c, d, card, btnTop);
    }
}

void SilvetonSamplerView::drawDialogList(Canvas& c, const std::shared_ptr<Dialog>& d) {
    if (d->kind == Dialog::Kind::Items && d->itemCols > 1) { drawDialogItemGrid(c, d); return; }   // SILVETON_LIST_MENU_V2
    const bool multi = d->kind == Dialog::Kind::Multi;
    const float w = multi ? 780.0F : 560.0F;
    const float rowH = multi ? 46.0F : 56.0F;
    const int n = static_cast<int>(d->items.size());
    const int visible = std::min(n, multi ? 9 : 8);
    const int maxScroll = std::max(0, n - visible);
    d->scroll = std::clamp(d->scroll, 0, maxScroll);
    const float listH = static_cast<float>(visible) * rowH;
    const float btnH = d->buttons.size() >= 3U ? 60.0F : 64.0F;
    const float h = 66.0F + listH + 16.0F + btnH + 26.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    text(c, d->title, card.left + 30.0F, card.top + 41.0F, multi ? 19.0F : 22.0F, Color::WHITE, Opt().bold().maxW(w - 60.0F));
    const float listTop = card.top + 66.0F;
    const bool scrolls = n > visible;
    const RectF list(card.left + 24.0F, listTop, card.right - 24.0F - (scrolls ? 56.0F : 0.0F), listTop + listH);
    for (int i = 0; i < visible; ++i) {
        const int idx = d->scroll + i;
        const RectF row(list.left, list.top + static_cast<float>(i) * rowH, list.right, list.top + static_cast<float>(i + 1) * rowH - 6.0F);
        const std::string& label = d->items[static_cast<std::size_t>(idx)];
        if (multi) {
            const bool on = idx < static_cast<int>(d->checked.size()) && d->checked[static_cast<std::size_t>(idx)];
            dlgCell(c, row, 0);
            const RectF box(row.left + 14.0F, row.centerY() - 13.0F, row.left + 40.0F, row.centerY() + 13.0F);
            if (on) {
                fillV(c, box, 5.0F, Color::rgb(82, 180, 255), Color::rgb(23, 96, 194));
                line(c, box.left + 6.0F, box.centerY() + 1.0F, box.left + 11.5F, box.bottom - 7.0F, Color::WHITE, 3.0F);
                line(c, box.left + 11.5F, box.bottom - 7.0F, box.right - 5.0F, box.top + 7.0F, Color::WHITE, 3.0F);
            } else {
                fillV(c, box, 5.0F, Color::rgb(5, 7, 10), Color::rgb(13, 18, 24));
            }
            strokeRR(c, box, 5.0F, on ? Color::rgb(8, 9, 11) : Color::rgb(72, 80, 90), 1.5F);
            text(c, label, row.left + 54.0F, row.centerY() + 5.5F, 15.0F, Color::WHITE, Opt().bold().maxW(row.width() - 68.0F));
            hit(row, [this, d, idx](float, float) {
                if (idx < static_cast<int>(d->checked.size())) d->checked[static_cast<std::size_t>(idx)] = !d->checked[static_cast<std::size_t>(idx)];
                invalidate();
            });
        } else {
            dlgCell(c, row, 0);
            text(c, label, row.left + 16.0F, row.centerY() + 6.0F, 17.0F, Color::WHITE, Opt().bold().maxW(row.width() - 32.0F));
            const std::function<void(int)> pick = d->onItem;
            hit(row, [this, d, pick, idx](float, float) { dialogFire(d, [pick, idx] { if (pick) pick(idx); }); });
        }
    }
    if (scrolls) {
        const RectF up(list.right + 10.0F, list.top, list.right + 56.0F, list.top + 44.0F);
        const RectF down(list.right + 10.0F, list.bottom - 50.0F, list.right + 56.0F, list.bottom - 6.0F);
        dialogKeyCap(c, up, "▲", false, 14.0F, isDown(up));
        dialogKeyCap(c, down, "▼", false, 14.0F, isDown(down));
        hit(up, [this, d](float, float) { d->scroll = std::max(0, d->scroll - 1); invalidate(); });
        hit(down, [this, d, maxScroll](float, float) { d->scroll = std::min(maxScroll, d->scroll + 1); invalidate(); });
        const RectF track(up.centerX() - 3.0F, up.bottom + 8.0F, up.centerX() + 3.0F, down.top - 8.0F);
        fillV(c, track, 3.0F, Color::rgb(5, 7, 10), Color::rgb(13, 18, 24));
        const float th = std::max(24.0F, track.height() * static_cast<float>(visible) / static_cast<float>(n));
        const float ty = track.top + (track.height() - th) * (maxScroll > 0 ? static_cast<float>(d->scroll) / static_cast<float>(maxScroll) : 0.0F);
        fillV(c, RectF(track.left, ty, track.right, ty + th), 3.0F, Color::rgb(82, 180, 255), Color::rgb(23, 96, 194));
    }
    dialogButtonRow(c, d, card, card.bottom - 26.0F - btnH);
}

void SilvetonSamplerView::drawDialogGrid(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const int perPage = 20;
    const int count = static_cast<int>(d->gridItems.size());
    const int pages = std::max(1, (count + perPage - 1) / perPage);
    d->gridPage = std::clamp(d->gridPage, 0, pages - 1);
    const float w = DESIGN_W * 0.92F;
    const float pad = 20.0F;
    const float cellH = 64.0F;
    const float h = 16.0F + 52.0F + 10.0F + 52.0F + 10.0F + 5.0F * (cellH + 8.0F) + 16.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    const float innerL = card.left + pad;
    const float innerR = card.right - pad;
    // head: title and the keys on the right
    const float headTop = card.top + 16.0F;
    float right = innerR;
    {
        const char* closeLabel = d->keepOpen ? "DONE" : "CANCEL";   // a window that stays open while choosing is closed with DONE
        const float cw = std::max(120.0F, textWidth(closeLabel, 16.0F, Face::Bold) + 40.0F);
        const RectF r(right - cw, headTop, right, headTop + 52.0F);
        dialogKeyCap(c, r, closeLabel, false, 15.0F, isDown(r));
        hit(r, [this, d](float, float) { dialogFire(d, nullptr); });
        right -= cw + 8.0F;
    }
    if (!d->gridAction.empty()) {   // SILVETON_MODEL_RENAME_V1
        const float cw = std::max(120.0F, textWidth(d->gridAction, 16.0F, Face::Bold) + 40.0F);
        const RectF r(right - cw, headTop, right, headTop + 52.0F);
        dialogKeyCap(c, r, d->gridAction, false, 15.0F, isDown(r));
        const std::function<void(int)> act = d->onAction;
        hit(r, [this, d, act](float, float) { if (act) act(d->gridCurrent); invalidate(); });
        right -= cw + 8.0F;
    }
    if (!d->gridAction2.empty()) {   // SILVETON_MODELS_FROM_FILE_V1
        const float cw = std::max(120.0F, textWidth(d->gridAction2, 16.0F, Face::Bold) + 40.0F);
        const RectF r(right - cw, headTop, right, headTop + 52.0F);
        dialogKeyCap(c, r, d->gridAction2, false, 15.0F, isDown(r));
        const std::function<void(int)> act2 = d->onAction2;
        hit(r, [this, d, act2](float, float) { if (act2) act2(d->gridCurrent); invalidate(); });
        right -= cw + 8.0F;
    }
    if (d->hasExtra) {
        const float cw = std::max(120.0F, textWidth(d->gridExtra, 16.0F, Face::Bold) + 40.0F);
        const RectF r(right - cw, headTop, right, headTop + 52.0F);
        dialogKeyCap(c, r, d->gridExtra, false, 15.0F, isDown(r));
        const std::function<void(int)> pick = d->onPick;
        hit(r, [this, d, pick](float, float) { dialogFire(d, [pick] { if (pick) pick(-1); }); });
        right -= cw + 8.0F;
    }
    text(c, d->title, innerL + 6.0F, headTop + 34.0F, 22.0F, Color::WHITE, Opt().bold().maxW(right - innerL - 18.0F));

    // page keys (a strip that can be wider than the card: arrows and the wheel move it)
    const float pageTop = headTop + 52.0F + 10.0F;
    std::vector<float> keyW(static_cast<std::size_t>(pages));
    float total = 0.0F;
    for (int pg = 0; pg < pages; ++pg) {
        keyW[static_cast<std::size_t>(pg)] = std::max(56.0F, textWidth(std::to_string(pg + 1), 15.0F, Face::Bold) + 28.0F);
        total += keyW[static_cast<std::size_t>(pg)] + 8.0F;
    }
    const bool overflow = total > innerR - innerL;
    const float viewL = overflow ? innerL + 48.0F : innerL;
    const float viewR = overflow ? innerR - 48.0F : innerR;
    const float maxScroll = std::max(0.0F, total - (viewR - viewL));
    if (d->followPage) {
        float x0 = 0.0F;
        for (int pg = 0; pg < d->gridPage; ++pg) x0 += keyW[static_cast<std::size_t>(pg)] + 8.0F;
        const float x1 = x0 + keyW[static_cast<std::size_t>(d->gridPage)] + 8.0F;
        if (x0 < d->pageScroll) d->pageScroll = x0;
        if (x1 > d->pageScroll + (viewR - viewL)) d->pageScroll = x1 - (viewR - viewL);
        d->followPage = false;
    }
    d->pageScroll = clampF(d->pageScroll, 0.0F, maxScroll);
    const RectF view(viewL, pageTop, viewR, pageTop + 52.0F);
    if (overflow) {
        const RectF left(innerL, pageTop, innerL + 40.0F, pageTop + 52.0F);
        const RectF rightK(innerR - 40.0F, pageTop, innerR, pageTop + 52.0F);
        dialogKeyCap(c, left, "‹", false, 22.0F, isDown(left));
        dialogKeyCap(c, rightK, "›", false, 22.0F, isDown(rightK));
        hit(left, [this, d](float, float) { d->pageScroll = std::max(0.0F, d->pageScroll - 260.0F); invalidate(); });
        hit(rightK, [this, d, maxScroll](float, float) { d->pageScroll = std::min(maxScroll, d->pageScroll + 260.0F); invalidate(); });
    }
    c.save();
    c.clipRect(RectF(view.left - 1.0F, view.top - 6.0F, view.right + 1.0F, view.bottom + 8.0F));
    float x = viewL - d->pageScroll;
    for (int pg = 0; pg < pages; ++pg) {
        const float kw = keyW[static_cast<std::size_t>(pg)];
        const RectF r(x + 4.0F, pageTop, x + 4.0F + kw, pageTop + 52.0F);
        x += kw + 8.0F;
        if (r.right < view.left || r.left > view.right) continue;
        dialogKeyCap(c, r, std::to_string(pg + 1), pg == d->gridPage, 15.0F, isDown(r));
        const RectF hitR = intersect(r, view);
        if (!hitR.isEmpty()) hit(hitR, [this, d, pg](float, float) { d->gridPage = pg; invalidate(); });
    }
    c.restore();

    // the 4 x 5 grid: the number small on top, the name under it (the chosen one is blue)
    const float gridTop = pageTop + 52.0F + 10.0F;
    const float cellW = (innerR - innerL) / 4.0F;
    for (int row = 0; row < 5; ++row) {
        for (int col = 0; col < 4; ++col) {
            const int idx = d->gridPage * perPage + row * 4 + col;
            if (idx >= count) continue;
            const RectF r(innerL + static_cast<float>(col) * cellW + 4.0F, gridTop + static_cast<float>(row) * (cellH + 8.0F) + 4.0F,
                          innerL + static_cast<float>(col + 1) * cellW - 4.0F, gridTop + static_cast<float>(row) * (cellH + 8.0F) + 4.0F + cellH);
            const bool sel = idx == d->gridCurrent;
            const auto& item = d->gridItems[static_cast<std::size_t>(idx)];
            nlBtn(c, r, std::string(), sel ? NlBtn::Sel : NlBtn::Plain, 15.0F, false);
            text(c, item.first, r.left + 14.0F, r.top + 22.0F, 12.0F, sel ? Color::rgb(207, 230, 255) : Color::rgb(127, 139, 152), Opt().monoBold().maxW(r.width() - 28.0F));
            text(c, item.second, r.left + 14.0F, r.bottom - 15.0F, 16.0F, Color::WHITE, Opt().bold().maxW(r.width() - 28.0F));
            const std::function<void(int)> pick = d->onPick;
            hit(r, [this, d, pick, idx](float, float) {
                if (d->keepOpen) { d->gridCurrent = idx; if (pick) pick(idx); invalidate(); return; }   // stays open: choose and play
                dialogFire(d, [pick, idx] { if (pick) pick(idx); });
            });
        }
    }
}

// NUMBER and TEXT pages (dialog_number.png, dialog_text.png): a card with the title, the display, the keys and CANCEL / APPLY
void SilvetonSamplerView::drawDialogEditor(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const bool number = d->kind == Dialog::Kind::Number;
    const float w = number ? 960.0F : 1160.0F;
    const float kbH = softKeyboardHeight(*d);   // 0 when the real keyboard is used
    const float lcdTop = number ? 92.0F : 102.0F;
    const float lcdH = number ? 96.0F : 64.0F;
    const float stepTop = lcdTop + lcdH + 16.0F;   // number: the - / + keys
    const float kbTop = number ? 306.0F : 186.0F;
    const float btnTop = kbH > 0.0F ? 620.0F : (number ? stepTop + 84.0F : lcdTop + lcdH) + 40.0F;
    const float h = btnTop + 64.0F + 36.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    dialogHeadText(c, card, card.top + 20.0F, 24.0F, d->title, d->subtitle);
    if (!number) nlLabel(c, "NAME", card.left + 30.0F, card.top + 94.0F, false, NL_TXT2, 11.0F);
    const RectF field(card.left + 30.0F, card.top + lcdTop, card.right - 30.0F, card.top + lcdTop + lcdH);
    nlLcd(c, field);
    const float size = number ? 48.0F : 26.0F;
    const Face face = number ? Face::MonoBold : Face::Bold;
    const float innerW = field.width() - 36.0F;
    const float textW = textWidth(d->value, size, face);
    const int len = utf8Length(d->value);
    d->cursor = std::clamp(d->cursor, 0, len);
    const float cursorOff = textWidth(utf8Prefix(d->value, d->cursor), size, face);
    float startX = number ? field.centerX() - textW * 0.5F : field.left + 16.0F;
    if (textW > innerW) startX = field.left + 18.0F - std::max(0.0F, cursorOff - innerW + 8.0F);
    const float baseline = field.centerY() + size * 0.36F;
    c.save();
    c.clipRect(RectF(field.left + 4.0F, field.top + 2.0F, field.right - 4.0F, field.bottom - 2.0F));
    if (d->selectAll && len > 0) fill(c, RectF(startX - 2.0F, field.centerY() - size * 0.62F, startX + textW + 2.0F, field.centerY() + size * 0.62F), 4.0F, Color::argb(110, 70, 160, 235));
    text(c, d->value, startX, baseline, size, NL_VALUE, Opt().face(face));
    if (!d->selectAll && (nowMs() / 500) % 2 == 0) {
        const float cx = startX + cursorOff;
        fill(c, RectF(cx - 1.0F, field.centerY() - size * 0.62F, cx + 1.0F, field.centerY() + size * 0.62F), 0.0F, NL_BLUE);   // the blue caret
    }
    c.restore();
    // click in the field = put the cursor there
    hit(field, [this, d, startX, size, face, len](float x, float) {
        d->selectAll = false;
        int best = 0;
        float bestDist = 1e9F;
        for (int k = 0; k <= len; ++k) {
            const float px = startX + textWidth(utf8Prefix(d->value, k), size, face);
            const float dist = std::fabs(px - x);
            if (dist < bestDist) { bestDist = dist; best = k; }
        }
        d->cursor = best;
        invalidate();
    });
    if (number) {
        const float keysTop = card.top + stepTop;
        const float half = (field.width() - 28.0F) * 0.5F;
        for (int k = 0; k < 2; ++k) {
            const RectF r(field.left + (k == 0 ? 0.0F : half + 28.0F), keysTop, field.left + (k == 0 ? half : half * 2.0F + 28.0F), keysTop + 84.0F);
            d->stepRect[k] = r;
            const bool pressed = d->repeatDir == (k == 0 ? -1 : 1);
            nlBtn(c, r, k == 0 ? "−" : "+", NlBtn::Plain, 40.0F, false);
            if (pressed) fill(c, r, 8.0F, Color::argb(70, 0, 0, 0));
            hit(r, [](float, float) {});   // the press itself is handled by dialogPointerHook (hold = repeat)
        }
    }
    if (kbH > 0.0F) {
        drawSoftKeyboard(c, d, RectF(field.left, card.top + kbTop, field.right, card.top + kbTop + kbH));
    } else {
        d->kbKeys.clear();
    }
    dialogButtonRow(c, d, card, card.top + btnTop);
}

// ---------------------------------------------------------------- on-screen keyboard
namespace {
// SILVETON_NEW_LOOK_V1: the keys of the pictures: a text page has keys 62 high with a gap of 8, a number page 52 high with a gap of 6
constexpr float KB_GAP_TEXT = 8.0F;
constexpr float KB_GAP_NUM = 6.0F;
constexpr float KB_ROW_TEXT = 62.0F;
constexpr float KB_ROW_NUM = 52.0F;

// the capital of a lower case letter (ASCII and the Cyrillic of the Bulgarian alphabet)
std::string capitalOf(const std::string& ch) {
    if (ch.size() == 1U && ch[0] >= 'a' && ch[0] <= 'z') return std::string(1U, static_cast<char>(ch[0] - 'a' + 'A'));
    if (ch.size() == 2U) {
        const auto b0 = static_cast<unsigned char>(ch[0]);
        const auto b1 = static_cast<unsigned char>(ch[1]);
        if (b0 == 0xD0U && b1 >= 0xB0U && b1 <= 0xBFU) return std::string{static_cast<char>(0xD0), static_cast<char>(b1 - 0x20U)};   // а-п
        if (b0 == 0xD1U && b1 >= 0x80U && b1 <= 0x8FU) return std::string{static_cast<char>(0xD0), static_cast<char>(b1 + 0x20U)};   // р-я
    }
    return ch;
}

} // namespace

float SilvetonSamplerView::softKeyboardHeight(const Dialog& d) const {
    if (!softKeyboard_) return 0.0F;
    // SILVETON_FULL_KEYBOARD_V1: the same whole keyboard for a number as for a text (5 rows)
    if (d.kind == Dialog::Kind::Text || d.kind == Dialog::Kind::Number) {
        const bool num = d.kind == Dialog::Kind::Number;
        return 5.0F * (num ? KB_ROW_NUM : KB_ROW_TEXT) + 4.0F * (num ? KB_GAP_NUM : KB_GAP_TEXT);
    }
    return 0.0F;
}

bool SilvetonSamplerView::kbShifted(const Dialog& d) const {
    if (d.kbCaps) return true;
    if (d.kbShiftOff) return false;
    if (d.kbShift) return true;
    // the tablet's TYPE_TEXT_FLAG_CAP_SENTENCES: a capital at the start and after ". "
    if (d.selectAll || d.cursor <= 0) return true;
    const std::string before = utf8Prefix(d.value, d.cursor);
    return before.size() >= 2U && before[before.size() - 1U] == ' ' && (before[before.size() - 2U] == '.' || before[before.size() - 2U] == '!' || before[before.size() - 2U] == '?');
}

void SilvetonSamplerView::drawSoftKeyboard(Canvas& c, const std::shared_ptr<Dialog>& d, const RectF& area) {
    d->kbKeys.clear();
    struct Cell { std::string label; KbKey::Act act; float weight; };
    std::vector<std::vector<Cell>> rows;
    const bool num = d->kind == Dialog::Kind::Number;
    const float gap = num ? KB_GAP_NUM : KB_GAP_TEXT;
    const float rowH = num ? KB_ROW_NUM : KB_ROW_TEXT;
    // The Latin rows are 10 keys wide (as in the pictures); the Bulgarian rows have 11 letters, so a row is 11 units wide there.
    const float units = (!num && d->kbLang == 1) ? 11.0F : 10.0F;
    auto ch = [](const std::string& g) { return Cell{g, KbKey::Act::Char, 1.0F}; };
    auto rowOf = [&](const std::vector<std::string>& glyphs) {
        std::vector<Cell> r;
        for (const std::string& g : glyphs) r.push_back(ch(g));
        return r;
    };
    const bool shifted = kbShifted(*d);
    if (num) {
        // SILVETON_FULL_KEYBOARD_V1: the whole keyboard also for a number - the digits on top as always, the letters (they type
        // nothing into a number, they are grey) keep the keys where the fingers know them, the minus / point / delete / clear at the bottom.
        rows.push_back(rowOf({"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}));
        rows.push_back(rowOf({"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"}));
        rows.push_back(rowOf({"A", "S", "D", "F", "G", "H", "J", "K", "L"}));
        std::vector<Cell> r3;
        for (const char* g : {"Z", "X", "C", "V", "B", "N", "M"}) r3.push_back(ch(g));
        r3.push_back(Cell{"DELETE", KbKey::Act::Backspace, 2.0F});
        rows.push_back(r3);
        std::vector<Cell> r4;
        if (d->numMin < 0.0F) r4.push_back(Cell{"±", KbKey::Act::Sign, 1.0F});   // only when the minimum is below 0
        r4.push_back(ch("-"));
        r4.push_back(Cell{"SPACE", KbKey::Act::Space, 4.0F});
        r4.push_back(Cell{".", KbKey::Act::Char, 1.0F});
        r4.push_back(Cell{"CLEAR", KbKey::Act::Clear, 3.0F});
        rows.push_back(r4);
    } else {
        rows.push_back(rowOf({"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}));
        if (d->kbLang == 0) {
            rows.push_back(rowOf({"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"}));
            rows.push_back(rowOf({"a", "s", "d", "f", "g", "h", "j", "k", "l"}));
            std::vector<Cell> r3{Cell{"SHIFT", KbKey::Act::Shift, 1.0F}};
            for (const char* g : {"z", "x", "c", "v", "b", "n", "m"}) r3.push_back(ch(g));
            r3.push_back(Cell{"DELETE", KbKey::Act::Backspace, 1.0F});
            rows.push_back(r3);
        } else {   // БДС: у е и ш щ к с д з ц / ь я а о ж г т н в м ч / ю й ъ ф х п р л б
            rows.push_back(rowOf({"у", "е", "и", "ш", "щ", "к", "с", "д", "з", "ц"}));
            rows.push_back(rowOf({"ь", "я", "а", "о", "ж", "г", "т", "н", "в", "м", "ч"}));
            std::vector<Cell> r3{Cell{"SHIFT", KbKey::Act::Shift, 1.0F}};
            for (const char* g : {"ю", "й", "ъ", "ф", "х", "п", "р", "л", "б"}) r3.push_back(ch(g));
            r3.push_back(Cell{"DELETE", KbKey::Act::Backspace, 1.0F});
            rows.push_back(r3);
        }
        std::vector<Cell> r4;
        const bool latin = d->kbLang == 0;
        r4.push_back(Cell{latin ? "EN" : "BG", KbKey::Act::Language, latin ? 1.0F : 1.5F});
        r4.push_back(ch("-"));
        r4.push_back(ch(","));
        r4.push_back(Cell{"SPACE", KbKey::Act::Space, latin ? 3.5F : 4.5F});
        r4.push_back(ch("."));
        r4.push_back(Cell{"CLEAR", KbKey::Act::Clear, latin ? 2.5F : 2.0F});
        rows.push_back(r4);
    }
    // widths: a row is centred; a key of weight w is w units wide (+ the gaps it swallows)
    const float unit = (area.width() - (units - 1.0F) * gap) / units;
    for (std::size_t row = 0U; row < rows.size(); ++row) {
        float used = 0.0F;
        for (const Cell& cell : rows[row]) used += cell.weight;
        float x = area.left + std::max(0.0F, (units - used) * 0.5F) * (unit + gap);
        const float top = area.top + static_cast<float>(row) * (rowH + gap);
        for (const Cell& cell : rows[row]) {
            const float w = cell.weight * unit + (cell.weight - 1.0F) * gap;
            KbKey k;
            k.rect = RectF(x, top, x + w, top + rowH);
            k.act = cell.act;
            k.label = cell.label;
            k.output = cell.label;
            if (cell.act == KbKey::Act::Char && shifted) {
                k.label = capitalOf(cell.label);
                k.output = k.label;
            }
            d->kbKeys.push_back(k);
            x += w + gap;
        }
    }
    for (std::size_t i = 0U; i < d->kbKeys.size(); ++i) {
        const KbKey& k = d->kbKeys[i];
        const bool lit = k.act == KbKey::Act::Shift && (d->kbCaps || shifted);
        const bool inert = num && k.act == KbKey::Act::Char && !k.label.empty() &&
                           ((k.label[0] >= 'A' && k.label[0] <= 'Z') || (k.label[0] >= 'a' && k.label[0] <= 'z'));   // a letter types nothing into a number
        NlBtn state = NlBtn::Plain;
        std::string label = k.label;
        float size = num ? 15.0F : 18.0F;
        switch (k.act) {
            case KbKey::Act::Char: state = inert ? NlBtn::Off : NlBtn::Plain; break;
            case KbKey::Act::Space: state = NlBtn::Off; size = 13.0F; break;
            case KbKey::Act::Backspace: state = NlBtn::Off; size = num ? 13.0F : 14.0F; break;
            case KbKey::Act::Shift: state = lit ? NlBtn::On : NlBtn::Off; if (d->kbCaps) label = "CAPS"; size = 14.0F; break;   // CAPS = caps lock
            case KbKey::Act::Language: state = NlBtn::On; size = 14.0F; break;
            case KbKey::Act::Clear: state = NlBtn::Plain; size = 13.0F; break;
            case KbKey::Act::Sign: state = NlBtn::Off; size = 15.0F; break;
        }
        nlBtn(c, k.rect, label, state, size, false);
        if (static_cast<int>(i) == d->kbPressed) fill(c, k.rect, std::min(8.0F, k.rect.height() * 0.3F), Color::argb(70, 0, 0, 0));
    }
}

int SilvetonSamplerView::kbKeyAt(const Dialog& d, float x, float y) const {
    const float gap = d.kind == Dialog::Kind::Number ? KB_GAP_NUM : KB_GAP_TEXT;
    for (std::size_t i = 0U; i < d.kbKeys.size(); ++i) {
        // the gaps between the keys belong to the nearest key: a finger does not fall through
        const RectF& r = d.kbKeys[i].rect;
        const RectF grown(r.left - gap * 0.5F, r.top - gap * 0.5F, r.right + gap * 0.5F, r.bottom + gap * 0.5F);
        if (grown.contains(x, y)) return static_cast<int>(i);
    }
    return -1;
}

void SilvetonSamplerView::kbPress(const std::shared_ptr<Dialog>& d, int index) {
    if (index < 0 || index >= static_cast<int>(d->kbKeys.size())) return;
    const KbKey key = d->kbKeys[static_cast<std::size_t>(index)];
    switch (key.act) {
        case KbKey::Act::Char:
            dialogType(key.output);
            d->kbShift = false;
            d->kbShiftOff = false;
            break;
        case KbKey::Act::Space:
            dialogType(" ");
            d->kbShift = false;
            d->kbShiftOff = false;
            break;
        case KbKey::Act::Backspace:
            dialogKey(Key::Backspace);
            break;
        case KbKey::Act::Shift: {
            const std::int64_t now = nowMs();
            if (d->kbCaps) {
                d->kbCaps = false; d->kbShift = false; d->kbShiftOff = true;
            } else if (now - d->kbShiftTapMs < 400) {
                d->kbCaps = true; d->kbShift = false; d->kbShiftOff = false;
            } else if (kbShifted(*d)) {
                d->kbShift = false; d->kbShiftOff = true;
            } else {
                d->kbShift = true; d->kbShiftOff = false;
            }
            d->kbShiftTapMs = now;
            break;
        }
        case KbKey::Act::Language:
            d->kbLang = d->kbLang == 0 ? 1 : 0;
            break;
        case KbKey::Act::Clear:
            d->value.clear();
            d->cursor = 0;
            d->selectAll = false;
            break;
        case KbKey::Act::Sign: {
            if (!d->value.empty() && d->value[0] == '-') {
                d->value.erase(0, 1);
                d->cursor = std::max(0, d->cursor - 1);
            } else {
                d->value.insert(0, "-");
                d->cursor += 1;
            }
            d->selectAll = false;
            break;
        }
    }
    invalidate();
}

// ---------------------------------------------------------------- number page logic
std::string SilvetonSamplerView::numberFormat(const Dialog& d, float value) {
    if (d.numDec <= 0) return toStr(static_cast<long long>(std::nearbyint(value)));
    return trimmed(fmtFixed(static_cast<double>(value), d.numDec));
}

float SilvetonSamplerView::numberTyped(const Dialog& d) const {
    const std::string t = replaceAll(d.value, ",", ".");
    const std::optional<float> v = toFloatOrNull(t);
    return std::clamp(v ? *v : d.numCurrent, d.numMin, d.numMax);
}

void SilvetonSamplerView::numberSetText(Dialog& d, float value) {
    d.value = numberFormat(d, std::clamp(value, d.numMin, d.numMax));
    d.cursor = utf8Length(d.value);
    d.selectAll = false;
}

void SilvetonSamplerView::numberPreview(Dialog& d, float value) {
    if (!d.numLive) return;
    const float v = std::clamp(value, d.numMin, d.numMax);
    if (d.previewed && v == d.lastPreview) return;
    d.lastPreview = v;
    d.previewed = true;
    if (d.numDone) d.numDone(v);
    invalidate();
}

void SilvetonSamplerView::numberStepOnce(Dialog& d, int dir, float mult) {
    const float v = std::clamp(numberTyped(d) + static_cast<float>(dir) * d.numStep * mult, d.numMin, d.numMax);
    numberSetText(d, v);
    numberPreview(d, v);
}

// The - / + keys: first step at once, after 420 ms it repeats every 70 ms, faster the longer you hold (see tickDialogs).
bool SilvetonSamplerView::dialogPointerHook(PointerAction action, float x, float y) {
    if (dialogStack.empty()) return false;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    // the on-screen keyboard: a key works at once when the finger touches it (hold the delete key = repeat)
    if (!d->kbKeys.empty() && (d->kind == Dialog::Kind::Text || d->kind == Dialog::Kind::Number)) {
        switch (action) {
            case PointerAction::Down: {
                const int hitKey = kbKeyAt(*d, x, y);
                if (hitKey >= 0) {
                    d->kbPressed = hitKey;
                    kbPress(d, hitKey);
                    if (d->kbKeys[static_cast<std::size_t>(hitKey)].act == KbKey::Act::Backspace) {
                        d->kbBackHeld = true;
                        d->kbBackCount = 0;
                        d->kbNextBackMs = nowMs() + 420;
                    }
                    invalidate();
                    return true;
                }
                break;
            }
            case PointerAction::Move:
                if (d->kbPressed >= 0) return true;
                break;
            case PointerAction::Up:
            case PointerAction::Cancel:
                if (d->kbPressed >= 0) {
                    d->kbPressed = -1;
                    d->kbBackHeld = false;
                    invalidate();
                    return true;
                }
                break;
        }
    }
    if (d->kind != Dialog::Kind::Number) return false;
    switch (action) {
        case PointerAction::Down:
            for (int k = 0; k < 2; ++k) {
                if (d->stepRect[k].contains(x, y)) {
                    d->repeatDir = k == 0 ? -1 : 1;
                    d->repeatCount = 0;
                    d->nextRepeatMs = nowMs() + 420;
                    numberStepOnce(*d, d->repeatDir, 1.0F);
                    invalidate();
                    return true;
                }
            }
            return false;
        case PointerAction::Move:
            return d->repeatDir != 0;
        case PointerAction::Up:
        case PointerAction::Cancel:
            if (d->repeatDir != 0) {
                d->repeatDir = 0;
                invalidate();
                return true;
            }
            return false;
    }
    return false;
}

void SilvetonSamplerView::tickDialogs(std::int64_t now) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    if (d->kind == Dialog::Kind::Number && d->repeatDir != 0 && now >= d->nextRepeatMs) {
        d->repeatCount++;
        const float mult = d->repeatCount > 40 ? 100.0F : (d->repeatCount > 15 ? 10.0F : 1.0F);
        numberStepOnce(*d, d->repeatDir, mult);
        d->nextRepeatMs = now + 70;
        invalidate();
    }
    if (d->kbBackHeld && d->kbPressed >= 0 && now >= d->kbNextBackMs) {
        d->kbBackCount++;
        dialogKey(Key::Backspace);
        d->kbNextBackMs = now + (d->kbBackCount > 12 ? 40 : 70);
        invalidate();
    }
    if (d->kind == Dialog::Kind::Wait && d->workDone.load(std::memory_order_acquire)) {
        const std::function<void()> done = d->completion;
        closeDialog(d);
        if (done) done();
        invalidate();
    }
}

// ---------------------------------------------------------------- keyboard and wheel
void SilvetonSamplerView::dialogKey(Key key) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    if (d->kind == Dialog::Kind::Wait) return;
    if (key == Key::Escape) {
        dialogCancel(d);
        return;
    }
    const bool editor = d->kind == Dialog::Kind::Text || d->kind == Dialog::Kind::Number;
    if (key == Key::Enter) {
        if ((editor || d->kind == Dialog::Kind::Message) && !d->buttons.empty()) {
            const std::function<void()> act = d->buttons.back().action;
            dialogFire(d, act);
        }
        return;
    }
    if (editor) {
        const int len = utf8Length(d->value);
        switch (key) {
            case Key::Backspace:
                if (d->selectAll) { d->value.clear(); d->cursor = 0; d->selectAll = false; }
                else if (d->cursor > 0) { d->value = utf8Substring(d->value, 0, d->cursor - 1) + utf8Substring(d->value, d->cursor, len); --d->cursor; }
                break;
            case Key::Delete:
                if (d->selectAll) { d->value.clear(); d->cursor = 0; d->selectAll = false; }
                else if (d->cursor < len) d->value = utf8Substring(d->value, 0, d->cursor) + utf8Substring(d->value, d->cursor + 1, len);
                break;
            case Key::Left: d->cursor = d->selectAll ? 0 : std::max(0, d->cursor - 1); d->selectAll = false; break;
            case Key::Right: d->cursor = d->selectAll ? len : std::min(len, d->cursor + 1); d->selectAll = false; break;
            case Key::Up:
            case Key::Down:
                if (d->kind == Dialog::Kind::Number) numberStepOnce(*d, key == Key::Up ? 1 : -1, 1.0F);
                break;
            default: break;
        }
        invalidate();
        return;
    }
    if (d->kind == Dialog::Kind::Items || d->kind == Dialog::Kind::Multi) {
        if (key == Key::Up) d->scroll = std::max(0, d->scroll - 1);
        if (key == Key::Down) d->scroll += 1;   // clamped when drawn
        invalidate();
        return;
    }
    if (d->kind == Dialog::Kind::Grid) {
        if (key == Key::Left || key == Key::Up) { d->gridPage = std::max(0, d->gridPage - 1); d->followPage = true; }
        if (key == Key::Right || key == Key::Down) { d->gridPage += 1; d->followPage = true; }   // clamped when drawn
        invalidate();
    }
}

void SilvetonSamplerView::dialogType(const std::string& utf8) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    if (d->kind != Dialog::Kind::Text && d->kind != Dialog::Kind::Number) return;
    // keep only printable letters; the number page only takes digits, one point, a minus at the front
    std::string clean;
    for (std::size_t i = 0U; i < utf8.size();) {
        const auto b = static_cast<unsigned char>(utf8[i]);
        if (b < 0x20U || b == 0x7FU) { ++i; continue; }                                  // control characters
        if (b == 0xEFU && i + 2U < utf8.size()) {                                          // U+F700..U+F8FF: Mac function keys
            const auto b2 = static_cast<unsigned char>(utf8[i + 1U]);
            if (b2 >= 0x9CU && b2 <= 0xA3U) { i += 3U; continue; }
        }
        clean += utf8[i];
        ++i;
    }
    if (clean.empty()) return;
    if (d->kind == Dialog::Kind::Number) {
        std::string filtered;
        for (const char ch : clean) {
            if ((ch >= '0' && ch <= '9')) filtered += ch;
            else if (ch == '.' || ch == ',') filtered += '.';
            else if (ch == '-' && d->numMin < 0.0F) filtered += '-';
        }
        clean = filtered;
        if (clean.empty()) return;
    }
    if (d->selectAll) { d->value.clear(); d->cursor = 0; d->selectAll = false; }
    if (d->kind == Dialog::Kind::Number) {
        // a second point or a minus in the middle is not a number: drop it
        std::string ok;
        for (const char ch : clean) {
            std::string trial = utf8Prefix(d->value, d->cursor) + ok + ch;
            const bool minusOk = ch != '-' || trial.size() == 1U;
            const bool pointOk = ch != '.' || (d->value.find('.') == std::string::npos && ok.find('.') == std::string::npos);
            if (minusOk && pointOk) ok += ch;
        }
        clean = ok;
        if (clean.empty()) return;
    }
    const int len = utf8Length(d->value);
    d->value = utf8Prefix(d->value, d->cursor) + clean + utf8Substring(d->value, d->cursor, len);
    d->cursor += utf8Length(clean);
    invalidate();
}

void SilvetonSamplerView::dialogWheel(float x, float y, float dy) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    d->wheelAcc += dy;
    int steps = 0;
    while (d->wheelAcc >= 24.0F) { ++steps; d->wheelAcc -= 24.0F; }
    while (d->wheelAcc <= -24.0F) { --steps; d->wheelAcc += 24.0F; }
    if (steps == 0) return;
    if (d->kind == Dialog::Kind::Items || d->kind == Dialog::Kind::Multi) {
        d->scroll = std::max(0, d->scroll + steps);   // clamped when drawn
    } else if (d->kind == Dialog::Kind::Grid) {
        const float pageRowTop = DESIGN_H * 0.5F;   // the page strip is the upper part of the card: scroll the strip there
        (void)pageRowTop;
        if (y < 150.0F) d->pageScroll = std::max(0.0F, d->pageScroll + static_cast<float>(steps) * 120.0F);
        else { d->gridPage = std::max(0, d->gridPage + (steps > 0 ? 1 : -1)); d->followPage = true; }
    }
    (void)x;
    invalidate();
}

// ---------------------------------------------------------------- the Android calls
void SilvetonSamplerView::showMessage(const std::string& title, const std::string& message, const std::string& okLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Message;
    d->title = title;
    d->message = message;
    d->buttons.push_back({okLabel, nullptr});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showConfirm(const std::string& title, const std::string& message, const std::string& positiveLabel,
                                      std::function<void()> onPositive, const std::string& negativeLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Message;
    d->title = title;
    d->message = message;
    d->buttons.push_back({negativeLabel, nullptr});
    d->buttons.push_back({positiveLabel, std::move(onPositive)});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showItems(const std::string& title, const std::vector<std::string>& items, std::function<void(int)> onItem,
                                    const std::string& negativeLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Items;
    d->title = title;
    d->items = items;
    d->onItem = std::move(onItem);
    d->buttons.push_back({negativeLabel, nullptr});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showMultiChoice(const std::string& title, const std::vector<std::string>& labels,
                                          std::function<void(const std::vector<bool>&)> onPositive, const std::string& positiveLabel,
                                          const std::string& negativeLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Multi;
    d->title = title;
    d->items = labels;
    d->checked.assign(labels.size(), false);
    const std::weak_ptr<Dialog> weak = d;
    d->buttons.push_back({negativeLabel, nullptr});
    d->buttons.push_back({positiveLabel, [weak, onPositive] {
        if (const auto dd = weak.lock()) { if (onPositive) onPositive(dd->checked); }
    }});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showWait(const std::string& title, const std::string& message, std::function<std::function<void()>()> work) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Wait;
    d->title = title;
    d->message = message;
    d->cancelable = false;
    Dialog* raw = d.get();
    d->worker = std::thread([raw, work = std::move(work)] {
        std::function<void()> completion;
        try {
            if (work) completion = work();
        } catch (...) {
        }
        raw->completion = std::move(completion);
        raw->workDone.store(true, std::memory_order_release);
    });
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showGridPicker(const std::string& title, const std::vector<std::pair<std::string, std::string>>& items, int current,
                                         const std::optional<std::string>& extra, std::function<void(int)> pick) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Grid;
    d->title = title;
    d->gridItems = items;
    d->gridCurrent = current;
    d->hasExtra = extra.has_value();
    if (extra) d->gridExtra = *extra;
    d->onPick = std::move(pick);
    d->gridPage = current >= 0 ? current / 20 : 0;
    d->followPage = true;
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showEditorPage(const std::shared_ptr<Dialog>& d, const std::string& title, const std::string& subtitle,
                                         const std::string& applyLabel, std::function<void()> onApply) {
    d->title = title;
    d->subtitle = subtitle;
    d->buttons.clear();
    d->buttons.push_back({"CANCEL", d->onCancel});   // SILVETON_NEW_LOOK_V1: the words of the pictures
    d->buttons.push_back({applyLabel, std::move(onApply)});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showTextPage(const std::string& title, const std::string& current, std::function<void(const std::string&)> done) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Text;
    d->value = current;
    d->cursor = utf8Length(current);
    d->selectAll = true;   // the name is selected, so typing replaces it
    const std::weak_ptr<Dialog> weak = d;
    showEditorPage(d, title, "Edit the name and confirm.", "APPLY", [this, weak, done = std::move(done)] {
        const auto dd = weak.lock();
        if (!dd) return;
        const std::string value = trimmed(dd->value);
        if (!value.empty() && done) done(value);
        invalidate();
    });
}

void SilvetonSamplerView::showNumber(const std::string& title, float current, float minV, float maxV, int decimals, std::function<void(float)> done,
                                     bool live, std::function<void()> restore) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Number;
    d->numMin = minV;
    d->numMax = maxV;
    d->numCurrent = current;
    d->lastPreview = current;
    d->numLive = live;
    d->numDone = done;
    d->numRestore = restore;
    // SILVETON_FINE_KNOBS_V1: every value can be set to the hundredth; only small whole-number ranges stay whole.
    d->numDec = (decimals > 0 || maxV - minV >= 50.0F) ? 2 : decimals;
    const int scale = d->numDec <= 0 ? 1 : (d->numDec == 1 ? 10 : 100);
    d->numStep = 1.0F / static_cast<float>(scale);
    numberSetText(*d, std::clamp(current, minV, maxV));
    const std::string range = numberFormat(*d, minV) + " … " + numberFormat(*d, maxV);
    const std::string subtitle = live ? "− / + : one step · hold = faster · you hear it at once  (" + range + ")" : range;
    const std::weak_ptr<Dialog> weak = d;
    d->onCancel = [this, weak, done, restore] {
        const auto dd = weak.lock();
        if (!dd) return;
        dd->repeatDir = 0;
        if (dd->previewed) {
            if (restore) restore();
            else if (done) done(std::clamp(dd->numCurrent, dd->numMin, dd->numMax));
            invalidate();
        }
    };
    showEditorPage(d, title, subtitle, "APPLY", [this, weak, done] {
        const auto dd = weak.lock();
        if (!dd) return;
        dd->repeatDir = 0;
        const float value = numberTyped(*dd);
        if (done) done(value);
        invalidate();
    });
}

// ---------------------------------------------------------------- pickers of the COMBI page (tablet lines 2932-2987)
void SilvetonSamplerView::showBlendPicker() {
    const std::vector<std::pair<int, std::string>> blends = sampler.combiCatalog();
    if (blends.empty()) {
        showMessage("BLENDS", "There are no COMBI / BLEND positions in the loaded bank.");
        return;
    }
    std::vector<std::pair<std::string, std::string>> items;
    items.reserve(blends.size());
    for (const auto& b : blends) items.emplace_back(fmtZeroPad(b.first, 3), isBlank(b.second) ? "COMBI " + std::to_string(b.first) : b.second);
    // Open on the blend that is loaded now, not on position 1.
    int current = -1;
    if (editingCombiSlot) {
        for (std::size_t i = 0U; i < blends.size(); ++i) if (blends[i].first == *editingCombiSlot) { current = static_cast<int>(i); break; }
    }
    showGridPicker("BLENDS  1–500", items, current, std::nullopt, [this, blends](int index) {
        if (index < 0 || index >= static_cast<int>(blends.size())) return;
        const auto& item = blends[static_cast<std::size_t>(index)];
        if (sampler.activateCombiAddress(0, 0, item.first)) {
            editingCombiSlot = item.first;
            loadedFromList = -1;
            page_ = Page::COMBI;
            cachedCombiName = sampler.combiName();
            refreshAllUppers();
            refreshFx();
            invalidate();
        }
    });
}

// SILVETON_SUSE_SAMPLE_V1 (Цветомир, 02.11.2026): the blend is loaded from the ДВИГАТЕЛИ page itself. The list is the LIST (the
// positions with a blend); the chosen blend opens as a tap on the LIST does, then SILVETON SYNTH goes on its first Upper with a sound
// (its recordings keep sounding as they are) and that Upper is the one edited on the page.


void SilvetonSamplerView::showSoundPicker(int upper) {
    const std::vector<SoundItem> sounds = sampler.soundCatalog();
    if (sounds.empty()) {
        std::string detail = sampler.bankLoadError();
        if (isBlank(detail)) detail = "SILVETON_BANK.sv is not loaded or has no SOUND positions.";
        showMessage("BANK HAS NO SOUNDS", detail);
        return;
    }
    // Open on this Upper's own sound (e.g. position 53), not on position 1.
    const std::optional<SoundItem>& picked = lastPickedSound[static_cast<std::size_t>(upper)];
    std::optional<std::string> currentName;
    if (upperStates[static_cast<std::size_t>(upper)]) currentName = upperStates[static_cast<std::size_t>(upper)]->soundName;
    else if (const auto s = sampler.upperState(upper)) currentName = s->soundName;
    int current = -1;
    if (picked && currentName && picked->name == *currentName) {
        for (std::size_t i = 0U; i < sounds.size(); ++i) {
            if (sounds[i].bank == picked->bank && sounds[i].page == picked->page && sounds[i].slot == picked->slot) { current = static_cast<int>(i); break; }
        }
    }
    if (current < 0 && currentName && *currentName != "EMPTY") {
        for (std::size_t i = 0U; i < sounds.size(); ++i) if (sounds[i].name == *currentName) { current = static_cast<int>(i); break; }
    }
    std::vector<std::pair<std::string, std::string>> items;
    items.reserve(sounds.size());
    for (const auto& s : sounds) items.emplace_back(fmtZeroPad(s.slot, 3), s.name);
    showGridPicker("UPPER " + std::to_string(upper + 1) + " — SOUND", items, current, std::string("EMPTY"), [this, upper, sounds](int index) {
        if (index < 0) {
            sampler.clearUpperSound(upper);
            lastPickedSound[static_cast<std::size_t>(upper)].reset();
        } else {
            sampler.assignUpperSound(upper, sounds[static_cast<std::size_t>(index)]);
            lastPickedSound[static_cast<std::size_t>(upper)] = sounds[static_cast<std::size_t>(index)];
        }
        mirrorSound(upper, -1);
        refreshUpper(upper);
        invalidate();
    });
    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // the list of sounds stays open while choosing and playing, DONE closes
}

} // namespace silveton::ui::classic
