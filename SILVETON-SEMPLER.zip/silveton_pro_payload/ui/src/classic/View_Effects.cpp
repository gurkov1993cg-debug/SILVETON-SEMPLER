// SILVETON_MAC_VIEW_V1 - the EFFECTS page (tablet SilvetonSamplerView.kt lines 2582-2721)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
// Kotlin's kotlin.math.ln on a Float computes in double and rounds back to float.
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float roundf_(float v) { return std::nearbyint(v); }   // kotlin.math.round(Float)

float reverbSeconds(float feedback) {
    const float f = std::clamp(feedback, 0.0F, 0.95F);
    return 0.6F * static_cast<float>(std::pow(20.0, static_cast<double>(f / 0.95F)));
}
float reverbFeedbackFor(float seconds) {
    return std::clamp(0.95F * (lnf(std::clamp(seconds, 0.6F, 12.0F) / 0.6F) / lnf(20.0F)), 0.0F, 0.95F);
}

// One knob of an effect: id into the FX params, label, min, max, step, how it is shown.
struct FxKnob {
    int id;
    std::string label;
    float minV;
    float maxV;
    float step;
    float def;
    std::function<std::string(float)> show;
    int decimals;
};

std::vector<FxKnob> fxKnobsFor(int type) {
    const auto pct = [](float v) { return fmtFixed(static_cast<double>(v * 100.0F), 2) + " %"; };
    const auto ms = [](float v) {
        if (v < 1000.0F) return std::to_string(static_cast<int>(roundf_(v))) + " ms";
        return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
    };
    const auto hz = [](float v) { return fmtFixed(static_cast<double>(v), 2) + " Hz"; };
    const auto whole = [](float v) { return std::to_string(static_cast<int>(v)); };
    const auto db2 = [](float v) { return fmtFixed(static_cast<double>(v), 2) + " dB"; };
    const FxKnob wet{1, "WET", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0};
    const std::vector<FxKnob> reverb = {
        wet, {7, "PRE-DELAY", 0.0F, 200.0F, 1.0F, 10.0F, ms, 0},
        {3, "DECAY", 0.0F, 0.95F, 0.005F, 0.6F, [](float v) { return fmtFixed(static_cast<double>(reverbSeconds(v)), 2) + " s"; }, 1},
        {6, "TONE", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {8, "DAMPING", 0.0F, 1.0F, 0.01F, 0.4F, pct, 0},
        {9, "SIZE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}, {10, "MOD", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0}};
    const std::vector<FxKnob> delay = {wet, {2, "TIME", 1.0F, 2500.0F, 1.0F, 320.0F, ms, 0}, {3, "FEEDBACK", 0.0F, 0.95F, 0.005F, 0.25F, pct, 0},
                                       {6, "TONE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}};
    const auto plus = [&delay](const FxKnob& extra, const FxKnob* second = nullptr) {
        std::vector<FxKnob> v = delay;
        v.push_back(extra);
        if (second != nullptr) v.push_back(*second);
        return v;
    };
    switch (type) {
        case 1: return delay;
        case 8: { const FxKnob a{10, "WOW/FLUTTER", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0}; const FxKnob b{5, "SATURATION", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0}; return plus(a, &b); }
        case 9: return delay;
        case 10: return plus({5, "SPREAD", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0});
        case 11: return plus({5, "DUCKING", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0});
        case 2: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.8F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0}, {6, "TONE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0},
                        {14, "VOICES", 2.0F, 4.0F, 1.0F, 3.0F, whole, 0}};
        case 12: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.3F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}, {3, "FEEDBACK", -0.95F, 0.95F, 0.01F, 0.4F, pct, 0}};
        case 17: return {wet, {4, "SPEED", 0.1F, 2.0F, 0.01F, 0.6F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.7F, pct, 0}};
        case 13: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.4F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {3, "FEEDBACK", 0.0F, 0.9F, 0.01F, 0.3F, pct, 0},
                         {14, "STAGES", 4.0F, 8.0F, 2.0F, 6.0F, whole, 0}};
        case 14: return {wet, {4, "SLOW Hz", 0.1F, 2.0F, 0.01F, 0.8F, hz, 2}, {14, "FAST Hz", 2.0F, 10.0F, 0.1F, 6.5F, hz, 1}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0},
                         {15, "SPEED", 0.0F, 1.0F, 1.0F, 0.0F, [](float v) { return std::string(v >= 0.5F ? "FAST" : "SLOW"); }, 0}};
        case 15: return {{14, "THRESHOLD", -60.0F, 0.0F, 0.5F, -20.0F, db2, 1},
                         {15, "RATIO", 1.0F, 20.0F, 0.1F, 4.0F, [](float v) { return fmtFixed(static_cast<double>(v), 1) + " : 1"; }, 1},
                         {2, "ATTACK", 0.1F, 300.0F, 0.1F, 10.0F, ms, 1}, {16, "RELEASE", 10.0F, 3000.0F, 1.0F, 120.0F, ms, 0},
                         {6, "MAKE-UP", 0.0F, 24.0F, 0.1F, 0.0F, db2, 1}};
        case 16: return {wet, {5, "DRIVE", 0.0F, 1.0F, 0.01F, 0.4F, pct, 0}, {6, "TONE", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {14, "OUTPUT", -24.0F, 12.0F, 0.5F, 0.0F, db2, 1}};
        case 3: case 4: case 5: case 6: case 7: return reverb;
        default: return {};
    }
}

const char* const kFxTypeNames[] = {"OFF", "DIGITAL DLY", "CHORUS", "PLATE", "HALL", "ROOM", "CHAMBER", "SPRING", "TAPE DLY", "PING-PONG",
                                    "MULTI-TAP", "DUCK DLY", "FLANGER", "PHASER", "ROTARY", "COMP", "DRIVE", "ENSEMBLE"};
const int kFxTypeOrder[] = {0, 4, 3, 5, 6, 7, 1, 8, 9, 10, 11, 2, 17, 12, 13, 14, 15, 16};

// SILVETON_NEW_LOOK_V1: the short names on the INS tiles (54 units wide), same order as the type numbers
const char* const kFxShortNames[] = {"OFF", "DLY", "CHOR", "PLATE", "HALL", "ROOM", "CHAMB", "SPRING", "TAPE", "PING", "MTAP", "DUCK", "FLANG", "PHASE", "ROTARY", "COMP", "DRIVE", "ENS"};
// the delays have the TEMPO row (sync, BPM, TAP, note length)
bool fxHasTempo(int type) { return type == 1 || type == 8 || type == 9 || type == 10 || type == 11; }

// the name of a unit: 0..3 = FX1..FX4, 4..10 = INSERT of Upper 1..7, 11..18 = INSERT of SILVETON SYNTH place 1..8
std::string fxUnitTitle(int unit) {
    if (unit < 4) return "FX" + std::to_string(unit + 1);
    if (unit < 11) return "INSERT U" + std::to_string(unit - 3);
    return "INSERT M" + std::to_string(unit - 10);
}
} // namespace

// SILVETON_NEW_LOOK_V1 - the EFFECTS page (picture fx_reverb / fx_delay). Left: SENDS matrix of the 7 UPPERS x FX1..FX4 with the INSERT key of every UPPER
// and the ROUTING keys. Right: the 11 unit tiles (FX 1..4, INS U1..U7), the TYPE keys of the chosen unit and its PARAMETERS.
void SilvetonSamplerView::drawEffects(Canvas& c) {
    // SILVETON_FX_V3: FX1..FX4 (common sends) and the INSERT of every Upper.
    const int unit = std::clamp(fxUnitFocus, 0, 10);
    std::array<int, 11> types{};   // the effect type of every unit: 0..3 = FX1..FX4, 4..10 = INSERT of Upper 1..7
    for (int k = 0; k < 11; ++k) types[static_cast<std::size_t>(k)] = std::clamp(static_cast<int>(at(fxP(k), 0U, 0.0F)), 0, 17);
    drawFxSends(c, types, unit);
    // the 11 unit tiles, top right
    for (int k = 0; k < 11; ++k) {
        const bool fxTile = k < 4;
        const float x0 = fxTile ? 530.0F + static_cast<float>(k) * 96.0F : 914.0F + static_cast<float>(k - 4) * 58.0F;
        const RectF r(x0, 98.0F, x0 + (fxTile ? 92.0F : 54.0F), 150.0F);
        const int t = types[static_cast<std::size_t>(k)];
        fxKey2(c, r, fxTile ? "FX " + std::to_string(k + 1) : "INS U" + std::to_string(k - 3), fxTile ? effectName(t) : std::string(kFxShortNames[t]),
               static_cast<int>(unit == k ? NlBtn::Sel : NlBtn::Plain), fxTile ? 12.0F : 9.5F, 10.5F, true, 0.0F);
        hit(r, [this, k](float, float) { fxUnitFocus = k; });
    }
    drawFxBoardV3(c, RectF(530.0F, 158.0F, 1320.0F, 650.0F), unit);
}

// The left panel: the sends of the 7 UPPERS to FX1..FX4 (percent), the INSERT key of every UPPER, ROUTING FX1 -> FX2 and the three hint lines.
// A touch on the name = choose that UPPER; on a number: drag = level, tap = type it, double tap = 0; on INSERT = open the insert effect of that UPPER.
void SilvetonSamplerView::drawFxSends(Canvas& c, const std::array<int, 11>& types, int unit) {
    nlPanel(c, RectF(20.0F, 98.0F, 520.0F, 650.0F), "SENDS · ALL UPPERS · %");
    nlLabel(c, "UPPER", 34.0F, 142.0F, false);
    static const char* const heads[4] = {"FX1", "FX2", "FX3", "FX4"};
    for (int n = 0; n < 4; ++n) nlLabel(c, heads[n], 206.0F + static_cast<float>(n) * 62.0F, 142.0F, true);
    nlLabel(c, "INSERT", 440.0F, 142.0F, false);
    const ColorInt zeroColor = Color::rgb(91, 99, 108), trackColor = Color::rgb(26, 29, 33);
    for (int u = 0; u < 7; ++u) {
        const float y = 152.0F + static_cast<float>(u) * 48.0F;
        const std::optional<UpperState>& stOpt = upperStates[static_cast<std::size_t>(u)];
        const bool chosen = selectedUpper_ == u;
        upperSelectAreas_.push_back({RectF(30.0F, y, 514.0F, y + 42.0F), u});   // a touch anywhere in the row chooses that UPPER (where the page allows it)
        // the name key
        const RectF nameR(30.0F, y, 170.0F, y + 42.0F);
        nlBtn(c, nameR, std::string(), chosen ? NlBtn::Sel : NlBtn::Plain, 12.0F, false);
        text(c, "U" + std::to_string(u + 1), 40.0F, y + 15.0F, 12.0F, chosen ? Color::WHITE : NL_TXT2, Opt().bold());
        text(c, stOpt ? stOpt->soundName : std::string("—"), 40.0F, y + 32.0F, 11.5F, chosen ? Color::WHITE : Color::rgb(207, 214, 222), Opt().maxW(122.0F));
        hit(nameR, [this, u](float, float) { selectedUpper_ = u; });
        // the four sends
        const std::vector<float> up = uParams(u);
        for (int n = 1; n <= 4; ++n) {
            const RectF cell(178.0F + static_cast<float>(n - 1) * 62.0F, y, 234.0F + static_cast<float>(n - 1) * 62.0F, y + 42.0F);
            float value = 0.0F;
            if (stOpt) value = n == 1 ? stOpt->fxSend1 : (n == 2 ? stOpt->fxSend2 : at(up, n == 3 ? 46U : 47U, 0.0F));
            value = std::clamp(value, 0.0F, 1.0F);
            const int pct = static_cast<int>(roundf_(value * 100.0F));
            nlLcd(c, cell);
            text(c, std::to_string(pct), cell.centerX(), y + 19.5F, 14.0F, pct != 0 ? NL_VALUE : zeroColor, Opt().center().monoBold());
            fill(c, RectF(cell.left + 6.0F, y + 33.0F, cell.left + 50.0F, y + 37.0F), 2.0F, trackColor);
            if (value > 0.0F) fill(c, RectF(cell.left + 6.0F, y + 33.0F, cell.left + 6.0F + std::max(3.0F, 44.0F * value), y + 37.0F), 1.5F, NL_BLUE);
            if (!stOpt) continue;
            const std::function<void(float)> apply = [this, u, n](float nv) {
                if (n == 1 || n == 2) {
                    const std::optional<UpperState>& cur = upperStates[static_cast<std::size_t>(u)];
                    if (!cur) return;
                    UpperState changed = *cur;
                    if (n == 1) changed.fxSend1 = nv; else changed.fxSend2 = nv;
                    commitUpperFx(changed, u);
                } else setUParam(u, n == 3 ? 46 : 47, nv);
            };
            knobHit(cell, value, 0.0F, 1.0F, 0.01F, 250.0F, apply,
                    [this, u, n, value, apply]() {
                        showNumber("U" + std::to_string(u + 1) + " · FX" + std::to_string(n) + " SEND %", value * 100.0F, 0.0F, 100.0F, 0, [apply](float pc) { apply(std::clamp(pc / 100.0F, 0.0F, 1.0F)); });
                    },
                    [apply]() { apply(0.0F); });
        }
        // the INSERT key: shows the type, opens the insert effect of this UPPER
        const RectF insR(430.0F, y, 514.0F, y + 42.0F);
        const int insType = types[static_cast<std::size_t>(4 + u)];
        nlBtn(c, insR, kFxTypeNames[insType], unit == 4 + u ? NlBtn::Sel : (insType == 0 ? NlBtn::Off : NlBtn::Plain), 11.0F, true);
        hit(insR, [this, u](float, float) { fxUnitFocus = 4 + u; selectedUpper_ = u; });
    }
    // ROUTING FX1 -> FX2: two keys
    std::optional<CombiFxState> fx = fxState;
    if (!fx) { fx = sampler.combiFxState(); if (fx) fxState = fx; }
    const int routing = fx ? fx->routing : 0;
    nlLabel(c, "ROUTING FX1 → FX2", 34.0F, 504.0F, false);
    const RectF parallel(30.0F, 512.0F, 254.0F, 560.0F), serial(262.0F, 512.0F, 510.0F, 560.0F);
    fxKey2(c, parallel, "FX1 + FX2", "PARALLEL", static_cast<int>(routing == 0 ? NlBtn::On : NlBtn::Off), 12.0F, 10.5F, true, 0.05F);
    fxKey2(c, serial, "FX1 → FX2", "SERIAL", static_cast<int>(routing != 0 ? NlBtn::On : NlBtn::Off), 12.0F, 10.5F, true, 0.05F);
    hit(parallel, [this](float, float) { if (sampler.updateCombiFxRouting(0)) refreshFx(); });
    hit(serial, [this](float, float) { if (sampler.updateCombiFxRouting(1)) refreshFx(); });
    // the hints
    const ColorInt hintColor = Color::rgb(138, 147, 157);
    text(c, "drag a number = level · tap the number = type it · double-tap = 0", 34.0F, 584.0F, 11.0F, hintColor, Opt().maxW(470.0F));
    text(c, "INSERT works only for its own UPPER · FX1–FX4 are shared by all UPPERs", 34.0F, 604.0F, 11.0F, hintColor, Opt().maxW(470.0F));
    text(c, "tap a row = choose that UPPER · tap INSERT = open its insert effect", 34.0F, 624.0F, 11.0F, hintColor, Opt().maxW(470.0F));
}

// The right side of the page for one unit: the TYPE keys (3 rows of 6) in the box `r` (top 178 units) and below it the PARAMETERS panel.
void SilvetonSamplerView::drawFxBoardV3(Canvas& c, const RectF& r, int unit) {
    const std::vector<float> p = fxP(unit);
    const int type = std::clamp(static_cast<int>(at(p, 0U, 0.0F)), 0, 17);
    const std::string title = fxUnitTitle(unit);
    const bool isSend = unit < 4;
    nlPanel(c, RectF(r.left, r.top, r.right, r.top + 178.0F), (isSend ? "FX " + std::to_string(unit + 1) : "INSERT · U" + std::to_string(unit - 3)) + " · TYPE");
    for (int k = 0; k < 18; ++k) {
        const int t = kFxTypeOrder[k];
        const RectF b(r.left + 10.0F + static_cast<float>(k % 6) * 126.0F, r.top + 30.0F + static_cast<float>(k / 6) * 46.0F,
                      r.left + 130.0F + static_cast<float>(k % 6) * 126.0F, r.top + 70.0F + static_cast<float>(k / 6) * 46.0F);
        nlBtn(c, b, kFxTypeNames[t], type == t ? NlBtn::On : NlBtn::Off, 11.5F, true);
        hit(b, [this, unit, t](float, float) { setFxP(unit, 0, static_cast<float>(t)); });
    }
    const RectF sec(r.left, r.top + 188.0F, r.right, r.bottom);
    if (!drawFxParamsBlock(c, sec, unit, type, p, title)) return;
    if (fxHasTempo(type)) return;   // a delay shows its TEMPO row instead of the hints
    const ColorInt hintColor = Color::rgb(138, 147, 157);
    text(c, "drag a knob · double-tap = default · hold or tap the value = type a number", sec.left + 14.0F, sec.bottom - 49.0F, 12.0F, hintColor, Opt().maxW(sec.width() - 28.0F));
    if (isSend) {
        if (type != 15) text(c, "FX " + std::to_string(unit + 1) + " is a shared send: WET = return level", sec.left + 14.0F, sec.bottom - 27.0F, 12.0F, hintColor, Opt().maxW(sec.width() - 28.0F));
    } else {
        text(c, "INSERT U" + std::to_string(unit - 3) + " works only for its own UPPER", sec.left + 14.0F, sec.bottom - 27.0F, 12.0F, hintColor, Opt().maxW(sec.width() - 28.0F));
    }
}

// A two-line key (top line bold, small line below) in the new look. `state` is an NlBtn value (Plain / Off / Sel / On).
void SilvetonSamplerView::fxKey2(Canvas& c, const RectF& r, const std::string& top, const std::string& sub, int state, float size1, float size2, bool lamp, float spacing1) {
    const NlBtn st = static_cast<NlBtn>(state);
    nlBtn(c, r, std::string(), st, size1, lamp);
    ColorInt txt = Color::rgb(179, 187, 196);
    if (st == NlBtn::Sel) txt = Color::WHITE;
    else if (st == NlBtn::On) txt = Color::rgb(28, 19, 4);
    else if (st == NlBtn::Off) txt = Color::rgb(121, 130, 140);
    const ColorInt subColor = Color::argb(204, Color::red(txt), Color::green(txt), Color::blue(txt));
    const float lh1 = size1 * 1.15F, lh2 = size2 * 1.15F;
    const float start = (r.height() - lh1 - lh2) / 2.0F;
    text(c, top, r.centerX(), r.top + start + lh1 / 2.0F + size1 * 0.36F, size1, txt, Opt().center().bold().spacing(spacing1).maxW(r.width() - 10.0F));
    text(c, sub, r.centerX(), r.top + start + lh1 + lh2 / 2.0F + size2 * 0.36F, size2, subColor, Opt().center().spacing(0.06F).maxW(r.width() - 10.0F));
}

// A key that is "lit" when on: dark key, amber lamp and amber letters (TEMPO SYNC).
void SilvetonSamplerView::fxLitKey(Canvas& c, const RectF& r, const std::string& label, bool on, float size) {
    nlBtn(c, r, std::string(), on ? NlBtn::Plain : NlBtn::Off, size, true);
    if (on) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
    }
    text(c, label, r.centerX(), r.centerY() + size * 0.36F + 2.0F, size, on ? Color::rgb(255, 177, 58) : Color::rgb(121, 130, 140),
         Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
}

// One knob of the new look: name above, knob with the blue ring, black value box below. The touch is the same as knobControl: drag = value,
// double tap = reset, tap on the knob or on the value = type the number.
void SilvetonSamplerView::fxKnobNl(Canvas& c, float cx, float cy, float radius, float value, float minV, float maxV, float step, float travel, bool bipolar,
                                   const std::string& valueText, const std::string& label, float hitW, std::function<void(float)> onChange,
                                   std::function<void()> exact, std::function<void()> reset) {
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    if (!label.empty()) nlLabel(c, label, cx, cy - (radius * 1.30F + 3.0F) - 5.0F, true, NL_TXT2, 11.0F);
    nlKnob(c, cx, cy, radius, t, bipolar, false, true);
    const float vw = hitW >= 140.0F ? 90.0F : 88.0F;
    nlValue(c, RectF(cx - vw / 2.0F, cy + radius + 9.0F, cx + vw / 2.0F, cy + radius + 31.0F), valueText, 12.0F);
    knobHit(RectF(cx - hitW / 2.0F, cy - radius - 16.0F, cx + hitW / 2.0F, cy + radius + 10.0F), value, minV, maxV, step, travel, std::move(onChange), exact, reset);
    hit(RectF(cx - hitW / 2.0F, cy + radius + 10.0F, cx + hitW / 2.0F, cy + radius + 42.0F), [exact](float, float) { exact(); }, std::move(reset));
}

// The PARAMETERS panel of an effect (the knobs, and the TEMPO row of a delay) inside the box `sec`: the same for the EFFECTS page and for the effects of
// a SILVETON SYNTH place. Returns false when the unit is OFF (nothing but the hint was drawn).
bool SilvetonSamplerView::drawFxParamsBlock(Canvas& c, const RectF& sec, int unit, int type, const std::vector<float>& p, const std::string& title) {
    nlPanel(c, sec, "PARAMETERS · " + effectName(type));
    const std::vector<FxKnob> knobs = fxKnobsFor(type);
    if (knobs.empty()) {
        text(c, title + " is switched off · choose a type above", sec.centerX(), sec.centerY() + 6.0F, 16.0F, NL_TXT2, Opt().center().maxW(sec.width() - 40.0F));
        return false;
    }
    const bool tempo = fxHasTempo(type);
    const int n = static_cast<int>(knobs.size());
    const float gap = std::min(150.0F, (sec.width() - 142.0F) / static_cast<float>(std::max(1, n - 1)));
    const float x0 = sec.left + (n >= 7 ? 60.0F : 70.0F);
    const float cy = sec.top + (tempo ? 94.0F : 124.0F);
    for (int k = 0; k < n; ++k) {
        const FxKnob kn = knobs[static_cast<std::size_t>(k)];
        const float cx = x0 + static_cast<float>(k) * gap;
        const float v = at(p, static_cast<std::size_t>(kn.id), kn.def);
        const std::function<void(float)> apply = [this, unit, kn](float nv) {
            setFxP(unit, kn.id, kn.step >= 1.0F ? roundf_(nv / kn.step) * kn.step : nv);
        };
        const bool reverbType = type >= 3 && type <= 7;
        fxKnobNl(c, cx, cy, 25.0F, v, kn.minV, kn.maxV, kn.step, 300.0F, kn.minV < 0.0F && kn.maxV > 0.0F, kn.show(v), kn.label, gap - 6.0F,
                 [apply](float nv) { apply(nv); },
                 [this, kn, v, title, apply, reverbType]() {
                     if (kn.id == 3 && reverbType) {
                         showNumber(title + " DECAY s", reverbSeconds(v), 0.6F, 12.0F, 1, [apply](float it) { apply(reverbFeedbackFor(it)); }, true,
                                    [apply, v]() { apply(v); });
                     } else if (kn.maxV <= 1.0F && kn.minV >= -1.0F && kn.step < 1.0F) {
                         showNumber(title + " " + kn.label + " %", v * 100.0F, kn.minV * 100.0F, kn.maxV * 100.0F, 0,
                                    [apply, kn](float it) { apply(std::clamp(it / 100.0F, kn.minV, kn.maxV)); }, true, [apply, v]() { apply(v); });
                     } else {
                         showNumber(title + " " + kn.label, v, kn.minV, kn.maxV, kn.decimals, [apply](float it) { apply(it); });
                     }
                 },
                 [apply, kn]() { apply(kn.def); });
    }
    // delays: the TEMPO row (sync, BPM, TAP, note length)
    if (tempo) {
        const bool sync = at(p, 11U, 0.0F) >= 0.5F;
        nlLabel(c, "TEMPO", sec.left + 14.0F, sec.top + 176.0F, false);
        const float y = sec.top + 186.0F;
        const RectF sr(sec.left + 14.0F, y, sec.left + 164.0F, y + 46.0F);
        fxLitKey(c, sr, "TEMPO SYNC", sync, 12.0F);
        hit(sr, [this, unit, sync](float, float) { setFxP(unit, 11, sync ? 0.0F : 1.0F); });
        const float bpm = at(p, 12U, 120.0F);
        const RectF br(sec.left + 174.0F, y, sec.left + 290.0F, y + 46.0F);
        nlLcd(c, br);
        text(c, std::to_string(static_cast<int>(bpm)) + " BPM", br.centerX(), y + 29.0F, 18.0F, sync ? NL_VALUE : Color::rgb(91, 99, 108), Opt().center().monoBold().maxW(br.width() - 8.0F));
        hit(br, [this, unit, bpm](float, float) {
            showNumber("TEMPO (BPM)", bpm, 30.0F, 300.0F, 0, [this, unit](float it) { setFxP(unit, 12, roundf_(it)); });
        });
        const RectF tapR(sec.left + 300.0F, y, sec.left + 386.0F, y + 46.0F);
        nlBtn(c, tapR, "TAP", NlBtn::Plain, 13.0F, false);
        hit(tapR, [this, unit](float, float) { tapTempo(unit); });
        const ColorInt hintColor = Color::rgb(138, 147, 157);
        text(c, "with TEMPO SYNC on, the time follows the tempo", sec.left + 410.0F, y + 10.0F, 11.0F, hintColor, Opt().maxW(sec.width() - 424.0F));
        text(c, "TAP: two or more taps set the BPM", sec.left + 410.0F, y + 30.0F, 11.0F, hintColor, Opt().maxW(sec.width() - 424.0F));
        static const std::pair<float, const char*> divs[] = {{0.25F, "1/4"}, {0.1875F, "1/8."}, {0.125F, "1/8"}, {0.0833333F, "1/8T"}, {0.0625F, "1/16"}, {0.5F, "1/2"}};
        const float cur = at(p, 13U, 0.25F);
        for (int k = 0; k < 6; ++k) {
            const float d = divs[k].first;
            const RectF dr(sec.left + 14.0F + static_cast<float>(k) * 98.0F, sec.top + 244.0F, sec.left + 106.0F + static_cast<float>(k) * 98.0F, sec.top + 288.0F);
            nlBtn(c, dr, divs[k].second, sync && std::fabs(cur - d) < 0.002F ? NlBtn::On : NlBtn::Off, 13.0F, true);
            hit(dr, [this, unit, d](float, float) { setFxP(unit, 13, d); });
        }
    }
    return true;
}

// SILVETON_PLACE_FX_V1: the EFFECTS tab of a SILVETON SYNTH place (ENGINE page): the four sends FX1..FX4 of the place, its own INSERT
// (the same 18 effects) and the knobs of that effect. `u` = part 7..14 (a place); unit 4 + u = its INSERT.
void SilvetonSamplerView::drawPlaceFx(Canvas& c, int u) {
    const float L = 388.0F, R = 1326.0F;
    const int unit = 4 + u;
    const std::optional<UpperState>& stOpt = upperStates[static_cast<std::size_t>(u)];
    // ---- SENDS
    const RectF pSend(L, 222.0F, L + 310.0F, 392.0F);
    board(c, pSend, false);
    text(c, "SENDS TO FX1–FX4", pSend.left + 16.0F, pSend.top + 20.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
    if (stOpt) {
        const UpperState st = *stOpt;
        const std::vector<float> up = uParams(u);
        const float colW = pSend.width() / 4.0F;
        for (int n = 1; n <= 4; ++n) {
            const float value = n == 1 ? st.fxSend1 : (n == 2 ? st.fxSend2 : (n == 3 ? at(up, 46U, 0.0F) : at(up, 47U, 0.0F)));
            const std::function<void(float)> apply = [this, st, u, n](float nv) {
                if (n == 1 || n == 2) {
                    const auto& cur = upperStates[static_cast<std::size_t>(u)];
                    UpperState x = cur ? *cur : st;
                    if (n == 1) x.fxSend1 = nv; else x.fxSend2 = nv;
                    commitUpperFx(x, u);
                } else setUParam(u, n == 3 ? 46 : 47, nv);
            };
            knobControl(c, pSend.left + colW * (static_cast<float>(n) - 0.5F), pSend.top + 82.0F, 26.0F, value, 0.0F, 1.0F, 0.01F, 250.0F, false,
                        std::to_string(static_cast<int>(roundf_(value * 100.0F))) + " %", "FX" + std::to_string(n), colW - 6.0F,
                        apply,
                        [this, n, value, apply] {
                            showNumber("FX" + std::to_string(n) + " SEND %", value * 100.0F, 0.0F, 100.0F, 0, [apply](float pct) { apply(std::clamp(pct / 100.0F, 0.0F, 1.0F)); });
                        },
                        [apply] { apply(0.0F); });
        }
        text(c, "FX1–FX4 are the four shared effects (EFFECTS page)", pSend.left + 16.0F, pSend.bottom - 14.0F, 10.5F, C_HINT, Opt().maxW(pSend.width() - 24.0F));
    }
    // ---- INSERT: the type
    const std::vector<float> p = fxP(unit);
    const int type = static_cast<int>(at(p, 0U, 0.0F));
    const RectF pIns(L + 318.0F, 222.0F, R, 392.0F);
    board(c, pIns, false);
    text(c, "INSERT  ·  TYPE  ·  only for this place", pIns.left + 16.0F, pIns.top + 20.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
    const float kw = (pIns.width() - 24.0F - 5.0F * 6.0F) / 6.0F;
    for (int k = 0; k < 18; ++k) {
        const int t = kFxTypeOrder[k];
        const float cx0 = pIns.left + 12.0F + static_cast<float>(k % 6) * (kw + 6.0F);
        const float cy0 = pIns.top + 32.0F + static_cast<float>(k / 6) * 44.0F;
        const RectF b(cx0, cy0, cx0 + kw, cy0 + 38.0F);
        segKey(c, b, kFxTypeNames[t], type == t, 10.0F);
        hit(b, [this, unit, t](float, float) { setFxP(unit, 0, static_cast<float>(t)); });
    }
    // ---- the knobs of the chosen effect
    const RectF board3(L, 400.0F, R, 786.0F);
    board(c, board3, false);
    drawFxParamsBlock(c, RectF(board3.left + 16.0F, board3.top + 16.0F, board3.right - 16.0F, board3.bottom - 16.0F), unit, type, p, fxUnitTitle(unit));
}

void SilvetonSamplerView::tapTempo(int unit) {
    const std::int64_t now = nowMs();
    if (!tapTimes.empty() && now - tapTimes.back() > 2000) tapTimes.clear();
    tapTimes.push_back(now);
    if (tapTimes.size() >= 2) {
        const float avg = static_cast<float>(tapTimes.back() - tapTimes.front()) / static_cast<float>(tapTimes.size() - 1);
        setFxP(unit, 12, std::clamp(roundf_(60000.0F / avg), 30.0F, 300.0F));
        setFxP(unit, 11, 1.0F);
    }
    if (tapTimes.size() > 8) tapTimes.erase(tapTimes.begin());
}

} // namespace silveton::ui::classic
