// SILVETON_ENGINES_V1 - the ENGINE page of an Upper (КОМБИ > ENGINE): one of the nine engines on the whole Upper.
// Top row: the engines (OFF · HD-1 · POLYSIX · MS-20 · AL-1 · MOD-7 · STR-1 · CX-3 · SGX · EP) and the three pages of the
// chosen one (ЗВУК = the engine's own knobs, ФИЛТЪР = the two filters and the filter envelope, МОД = LFO / unison / analog).
// Every knob: drag = turn, tap = exact number, right button / double tap = its starting value. The labels, ranges and
// starting values come from core/include/silveton/sampler/EngineDefs.h, so the screen and the sound can never disagree.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SoloDefs.h"   // SILVETON_SOLO_V1

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>

namespace silveton::ui::classic {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

// SILVETON_USER_WAVES_V1: a place USER n shows the name of the user's wave in it ("U2 STRINGS"), or "USER n НЯМА" when empty
std::string userWaveLabel(const std::string& s) {
    if (s.rfind("USER ", 0) != 0) return s;
    const int n = std::atoi(s.c_str() + 5);
    if (n < 1 || n > sv::kUserWaveCount) return s;
    const std::string nm = sv::userWaveName(n - 1);
    return nm.empty() ? s + " НЯМА" : "U" + std::to_string(n) + " " + nm;
}

std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return userWaveLabel(cur);
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- SILVETON_ENGINES_PAGE_V1: the page of the nine ENGINES (left menu)
// A row of the Uppers (tap = choose it), under it the ENGINE of the chosen Upper with all its pages and its oscillators.
void SilvetonSamplerView::drawEnginesPage(Canvas& c) {
    // SILVETON_ENGINE_SLOTS_V2: the engines have a page of their own. LEFT: the 8 places like a small mixer (name, ВКЛ lamp, СИЛА slider).
    // RIGHT: the chosen place - its engine, ВКЛ / СИЛА / POLY-MONO-LEGATO / PORTAMENTO, then the oscillators and knobs of the engine.
    const int slot = std::clamp(engSlot_, 0, 7);
    if (engUpper_ >= 7) engUpper_ = -1;
    const bool onUpper = engUpper_ >= 0;   // SILVETON_SUSE_SAMPLE_V1: an Upper of the blend is edited here (SILVETON SYNTH on its recordings)
    const int u = onUpper ? engUpper_ : 7 + slot;
    const ColorInt cardOff = Color::rgb(47, 51, 59), cardOn = Color::rgb(70, 76, 89);

    // ---- left: the eight places
    const RectF rack(112.0F, 112.0F, 372.0F, 786.0F);
    board(c, rack, true);
    for (int i = 0; i < 8; ++i) {
        const int pu = 7 + i;
        const float top = 124.0F + static_cast<float>(i) * 81.0F;
        const RectF r(124.0F, top, 360.0F, top + 75.0F);
        const bool sel = !onUpper && i == slot;
        const int t = std::clamp(rndI(engineP(pu, 0)), 0, sv::kEngineTypeCount - 1);
        const std::optional<UpperState> st = upperStates[static_cast<std::size_t>(pu)];
        const bool live = t != 0 && st && st->enabled;
        fill(c, r, 10.0F, sel ? cardOn : cardOff);
        if (sel) fill(c, RectF(r.left, r.top + 9.0F, r.left + 4.0F, r.bottom - 9.0F), 2.0F, C_ACCENT);
        text(c, std::to_string(i + 1), r.left + 24.0F, r.top + 38.0F, 26.0F, sel ? C_VALUE : C_KNOB_LABEL, Opt().center().bold());
        // SILVETON_SUSE_V1: only the new engine is shown - a place is "празно" or SILVETON SYNTH (an old engine of an old set is not named)
        text(c, t == 0 ? std::string("празно") : (static_cast<EngineType>(t) == EngineType::Solo ? std::string("SILVETON SOLO") : std::string("стар")), r.left + 48.0F, r.top + 30.0F,
             t != 0 && static_cast<EngineType>(t) == EngineType::Solo ? 15.0F : 18.0F, t == 0 ? C_HINT : C_VALUE, Opt().bold().maxW(t != 0 && static_cast<EngineType>(t) == EngineType::Solo ? 134.0F : 110.0F));
        hit(r, [this, i](float, float) { engSlot_ = i; engUpper_ = -1; selectedUpper_ = 7 + i; enginePage_ = 0; invalidate(); });
        if (t != 0 && st) {
            // the lamp = ВКЛ / ИЗКЛ of the place
            const RectF lamp(r.right - 50.0F, r.top + 4.0F, r.right - 4.0F, r.top + 42.0F);
            fill(c, RectF(r.right - 30.0F, r.top + 15.0F, r.right - 14.0F, r.top + 31.0F), 8.0F, live ? C_ACCENT : Color::rgb(30, 33, 38));
            if (live) fill(c, RectF(r.right - 33.0F, r.top + 12.0F, r.right - 11.0F, r.top + 34.0F), 11.0F, Color::argb(60, 80, 220, 120));
            text(c, fmtFixed(static_cast<double>(st->levelDb), 1) + " dB", r.right - 14.0F, r.top + 47.0F, 11.0F, C_KNOB_LABEL, Opt().right().mono().maxW(80.0F));
            hit(lamp, [this, pu](float, float) {
                const auto& cur = upperStates[static_cast<std::size_t>(pu)];
                if (!cur) return;
                UpperState n = *cur; n.enabled = !n.enabled; if (n.enabled) n.mute = false;
                commitMain(pu, n); invalidate();
            });
            // the slider = СИЛА of the place (tap or drag; 0 dB is the small mark)
            const float x0 = r.left + 48.0F, x1 = r.right - 14.0F;
            const float ty = r.top + 56.0F;
            fill(c, RectF(x0, ty - 3.0F, x1, ty + 3.0F), 3.0F, Color::rgb(28, 31, 36));
            const float tv = std::clamp((st->levelDb + 60.0F) / 72.0F, 0.0F, 1.0F);
            fill(c, RectF(x0, ty - 3.0F, x0 + (x1 - x0) * tv, ty + 3.0F), 3.0F, live ? C_ACCENT : Color::rgb(110, 116, 126));
            fill(c, RectF(x0 + (x1 - x0) * (60.0F / 72.0F) - 1.0F, ty - 8.0F, x0 + (x1 - x0) * (60.0F / 72.0F) + 1.0F, ty - 4.0F), 0.0F, Color::argb(110, 255, 255, 255));
            fill(c, RectF(x0 + (x1 - x0) * tv - 8.0F, ty - 8.0F, x0 + (x1 - x0) * tv + 8.0F, ty + 8.0F), 8.0F, Color::rgb(226, 229, 234));
            const auto setLevel = [this, pu, x0, x1](float x, float) {
                const auto& cur = upperStates[static_cast<std::size_t>(pu)];
                if (!cur) return;
                const float v = std::clamp(-60.0F + (x - x0) / std::max(1.0F, x1 - x0) * 72.0F, -60.0F, 12.0F);
                UpperState n = *cur; n.levelDb = std::nearbyint(v * 2.0F) * 0.5F;
                if (std::fabs(n.levelDb) < 0.75F) n.levelDb = 0.0F;   // it sticks to 0 dB
                commitMain(pu, n);
            };
            hit(RectF(x0 - 10.0F, ty - 16.0F, x1 + 10.0F, ty + 16.0F), setLevel,
                [this, pu] { const auto& cur = upperStates[static_cast<std::size_t>(pu)]; if (!cur) return; UpperState n = *cur; n.levelDb = 0.0F; commitMain(pu, n); },
                [setLevel](float x, float y, bool) { setLevel(x, y); });
        }
    }

    // ---- right, top: the chosen place and its engine keys
    const float L = 388.0F, R = 1326.0F;
    const int tSel = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto typeSel = static_cast<EngineType>(tSel);
    const RectF head(L, 112.0F, R, 238.0F);
    board(c, head, false);
    text(c, onUpper ? "UPPER " + std::to_string(u + 1) + " · БЛЕНДА" : "МЯСТО " + std::to_string(slot + 1), L + 22.0F, 138.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
    // SILVETON_SOLO_V1: ONE engine - there is no choice. A place holds SILVETON SOLO, or it is empty and has one key to create it.
    const bool isSolo = typeSel == EngineType::Solo;
    if (isSolo) {
        soloHead(c, head, u);
    } else {
        text(c, tSel == 0 ? std::string("ПРАЗНО") : std::string("СТАР ДВИГАТЕЛ"), L + 22.0F, 172.0F, 32.0F, C_HINT, Opt().bold().maxW(360.0F));
        text(c, "Соло синтезатор: два осцилатора, CZ огъване, суб, синхрон, унисон, филтър, обвивки, вибрато, портаменто CZ / DX / JS1 / JS2.", L + 392.0F, 166.0F, 14.0F, C_KNOB_LABEL, Opt().maxW(R - L - 420.0F));
        const RectF kr(L + 22.0F, 188.0F, L + 22.0F + 330.0F, 228.0F);
        stripToggle(c, kr, tSel == 0 ? "СЛОЖИ SILVETON SOLO" : "ЗАМЕНИ СЪС SILVETON SOLO", false, C_ACCENT, 14.0F);
        hit(kr, [this, u](float, float) {
            setEngineP(u, 0, static_cast<float>(static_cast<int>(EngineType::Solo)));
            enginePage_ = 0; invalidate();
        });
    }

    // ---- right, middle: ВКЛ / СИЛА, POLY / MONO / LEGATO, PORTAMENTO
    const RectF strip(L, 246.0F, R, 394.0F);
    board(c, strip, false);
    if (upperStates[static_cast<std::size_t>(u)]) {
        const UpperState st = *upperStates[static_cast<std::size_t>(u)];
        const std::vector<float> p = uParams(u);
        const auto card = [&](float x0, float x1, const char* name) {
            fill(c, RectF(x0, strip.top + 10.0F, x1, strip.bottom - 10.0F), 10.0F, Color::argb(26, 255, 255, 255));
            text(c, name, x0 + 14.0F, strip.top + 31.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
        };
        card(L + 10.0F, L + 258.0F, "ГЛАС");
        card(L + 266.0F, R - 10.0F, "СВИРЕНЕ");
        const float ky0 = strip.top + 50.0F, ky1 = ky0 + 44.0F;
        const RectF onR(L + 26.0F, ky0, L + 112.0F, ky1);
        stripToggle(c, onR, st.enabled ? "ВКЛ" : "ИЗКЛ", st.enabled, C_AMBER, 14.0F);
        hit(onR, [this, st](float, float) { UpperState cur = currentUpper(st); cur.enabled = !cur.enabled; if (cur.enabled) cur.mute = false; commitMain(selectedUpper_, cur); invalidate(); });
        {
            auto setLevel = [this, st](float v) { UpperState n = currentUpper(st); n.levelDb = v; commitMain(selectedUpper_, n); };
            knobControl(c, L + 186.0F, strip.top + 68.0F, 18.0F, st.levelDb, -60.0F, 12.0F, 0.5F, 300.0F, false, fmtFixed(static_cast<double>(st.levelDb), 1) + " dB", "СИЛА", 110.0F, setLevel,
                        [this, st, setLevel] { showNumber("СИЛА НА ДВИГАТЕЛЯ dB", st.levelDb, -60.0F, 12.0F, 1, setLevel); },
                        [setLevel] { setLevel(0.0F); });
        }
        for (int k = 0; k < 3; ++k) {
            const RectF mr(L + 280.0F + static_cast<float>(k) * 102.0F, ky0, L + 374.0F + static_cast<float>(k) * 102.0F, ky1);
            stripToggle(c, mr, k == 0 ? "POLY" : (k == 1 ? "MONO" : "LEGATO"), st.voiceMode == k, C_AMBER, 13.0F);
            hit(mr, [this, st, k](float, float) { UpperState cur = currentUpper(st); cur.voiceMode = k; commitMain(selectedUpper_, cur); invalidate(); });
        }
        text(c, st.voiceMode == 0 ? "много ноти наведнъж" : (st.voiceMode == 1 ? "една нота, всяка се почва отначало" : "една нота, плавно между тях"),
             L + 280.0F, strip.bottom - 22.0F, 11.0F, C_HINT, Opt().maxW(300.0F));
    }

    // ---- right, bottom: the pages and knobs of the engine
    board(c, RectF(L, 402.0F, R, 786.0F), false);
    if (isSolo) drawEngine(c, RectF(L + 16.0F, 412.0F, R - 16.0F, 776.0F), u);
    else text(c, "Натисни горе ключа, за да сложиш SILVETON SOLO на това място.", L + 40.0F, 480.0F, 16.0F, C_HINT, Opt().maxW(R - L - 80.0F));
}

// ---------------------------------------------------------------- SILVETON_SOLO_V1: the head of a SILVETON SOLO place
void SilvetonSamplerView::soloHead(Canvas& c, const RectF& head, int u) {
    const float L = head.left, R = head.right;
    text(c, "SILVETON SOLO", L + 110.0F, 138.0F, 15.0F, C_VALUE, Opt().bold().maxW(160.0F));
    text(c, sv::engineLine(EngineType::Solo), L + 22.0F, 160.0F, 12.0F, C_VALUE, Opt().maxW(R - L - 22.0F - 232.0F));
    text(c, "Ръчка: въртене = стойност · допир = точно число · десен бутон = началната. Страниците са долу.", L + 22.0F, 177.0F, 12.0F, C_KNOB_LABEL, Opt().maxW(R - L - 22.0F - 232.0F));
    // the real meters (the whole sampler)
    const Ctrl::AudioStatus a = frameAudioStatus;
    text(c, "ПРОЦЕСОР (всичко)", R - 210.0F, 128.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    text(c, std::to_string(rndI(a.cpuLoadPercent)) + " %", R - 22.0F, 128.0F, 13.0F, a.cpuLoadPercent > 80.0F ? C_AMBER : C_VALUE, Opt().right().mono().bold());
    fill(c, RectF(R - 210.0F, 134.0F, R - 22.0F, 139.0F), 2.5F, Color::rgb(28, 31, 36));
    fill(c, RectF(R - 210.0F, 134.0F, R - 210.0F + 188.0F * std::clamp(a.cpuLoadPercent / 100.0F, 0.0F, 1.0F), 139.0F), 2.5F, a.cpuLoadPercent > 80.0F ? C_AMBER : C_ACCENT);
    text(c, "ГЛАСОВЕ (всичко)", R - 210.0F, 156.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    text(c, std::to_string(a.activeVoices), R - 22.0F, 156.0F, 13.0F, C_VALUE, Opt().right().mono().bold());
    // the eight sounds, and the starting sound
    const RectF rz(L + 22.0F, 192.0F, L + 22.0F + 220.0F, 228.0F), rr(R - 210.0F, 192.0F, R - 22.0F, 228.0F), rm(L + 22.0F + 232.0F, 192.0F, R - 222.0F, 228.0F);
    stripToggle(c, rz, "ЗВУЦИ  ▼", false, C_ACCENT, 13.0F);
    stripToggle(c, rr, "НАЧАЛЕН ЗВУК", false, C_AMBER, 12.0F);
    text(c, "ЗВУЦИ = осем готови звука (довърши ги на ухо). НАЧАЛЕН ЗВУК = всичко отначало.", rm.left, rm.centerY() + 4.0F, 10.5F, C_HINT, Opt().maxW(rm.width()));
    hit(rz, [this, u](float, float) {
        std::vector<std::pair<std::string, std::string>> items;
        for (int i = 0; i < sv::solo::kPresets; ++i) items.emplace_back(std::to_string(i + 1), sv::solo::presetName(i));
        showGridPicker("ЗВУЦИ НА SILVETON SOLO  ·  избери и свири, ГОТОВО затваря", items, -1, std::nullopt, [this, u](int k) {
            if (k < 0 || k >= sv::solo::kPresets) return;
            std::vector<float> row(eParams(u));
            if (row.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) return;
            sv::solo::preset(k, row.data() + 1);
            std::vector<float> values(row.begin() + 1, row.begin() + 1 + sv::kEngineParamCountLegacy);
            sampler.setUpperEngineBlock(u, 1, values);
            engineParamsCache[static_cast<std::size_t>(u)].reset();
            flash(std::string("ЗВУК: ") + sv::solo::presetName(k));
            invalidate();
        });
        if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open: try the sounds one after another, ГОТОВО closes
    });
    hit(rr, [this, u](float, float) {
        showConfirm("НАЧАЛЕН ЗВУК", "Всички ръчки на това място се връщат на началното. Сегашният звук се губи, ако не е записан в бленда.", "ДА, ВЪРНИ", [this, u]() {
            std::vector<float> row(eParams(u));
            if (row.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) return;
            sv::solo::setDefaults(row.data() + 1);
            std::vector<float> values(row.begin() + 1, row.begin() + 1 + sv::kEngineParamCountLegacy);
            sampler.setUpperEngineBlock(u, 1, values);
            engineParamsCache[static_cast<std::size_t>(u)].reset();
            invalidate();
        });
    });
}

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u, int id, float v) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id, v);
    // the engine itself changed = its starting values were loaded: read everything again.
    // SILVETON_ENGINE_UPPER_ON_V1: choosing an engine on an empty Upper switches the Upper on in the engine - read the Upper
    // again too, or the next LEVEL / PAN / range move would send the old OFF back and the engine's sound would stop
    if (!ok || id == 0) { slot.reset(); refreshUpper(u); }
    // SILVETON_ENGINES_V3: the STR-1 INSTRUMENT loads its typical values - read them all again
    else if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && id == sv::ST_BODY_TYPE + 1) slot.reset();
    else {
        auto a = eParams(u);
        // SILVETON_MUSICAL_V1: the value as the engine keeps it (a RATIO jumps to its musical step)
        const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
        if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = id >= 1 ? sv::engineClamp(type, id - 1, v) : v;
        slot = a;
        // SILVETON_ENGINE_WAVE_V1: a ВЪЛНА chosen on a set saved before (its level is 0 there) gets the starting level
        int wid = 0, lid = 0, oid = 0;
        if (v >= 0.5F && sv::engineWaveIds(type, wid, lid, oid) && id == wid + 1 && engineP(u, lid + 1) <= 0.0F) {
            const EngineParamDef* d = sv::engineParamDef(type, lid);
            if (d != nullptr) setEnginePOne(u, lid + 1, d->def);
        }
    }
    invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v) - rndI(d.lo));   // SILVETON_OCTAVE_V1: a choice may start below 0 (ОКТАВА -2..+2) or at 1 (SUB OCT)
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = d.label;
    const std::string hint = d.hint;
    if (logKind(d)) {
        knobControl(c, cx, cy, rad, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
                    [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
                    [this, u, id, d, v, hint, pct] {
                        showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                                   [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
                    },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && d.id == sv::ST_STYLE)
        d.names = sv::str1StyleNames(rndI(engineP(u, sv::ST_BODY_TYPE + 1)));
    const int id = d.id + 1;
    const float v = engineP(u, id);
    // SILVETON_OCTAVE_V2: ОКТАВА is  [ - ]  +1 OCT  [ + ]  - one tap = one octave, a tap on the middle = back to 0
    if (d.kind == EngineKind::Choice && rndI(d.lo) == -2 && rndI(d.hi) == 2) {
        const int cur = std::clamp(rndI(v), -2, 2);
        stripToggle(c, r, cur == 0 ? "0 OCT" : (cur > 0 ? "+" + std::to_string(cur) + " OCT" : std::to_string(cur) + " OCT"), cur != 0, C_AMBER, 11.0F);
        const float w = std::min(r.width() * 0.3F, 46.0F);
        const RectF lr(r.left, r.top, r.left + w, r.bottom), rr(r.right - w, r.top, r.right, r.bottom), mr(r.left + w, r.top, r.right - w, r.bottom);
        text(c, "-", lr.centerX(), lr.centerY() + 7.0F, 22.0F, C_KNOB_LABEL, Opt().center().bold());
        text(c, "+", rr.centerX(), rr.centerY() + 7.0F, 22.0F, C_KNOB_LABEL, Opt().center().bold());
        text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
        hit(lr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::max(cur - 1, -2))); });
        hit(rr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::min(cur + 1, 2))); });
        hit(mr, [](float, float) {}, [this, u, id] { setEngineP(u, id, 0.0F); });
        return;
    }
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    stripToggle(c, r, engineValueText(d, v), on, C_AMBER, 11.0F);
    text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — избери и свири · допир извън прозореца = затваряне";
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open while choosing and playing
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, darkTheme ? Color::rgb(16, 18, 16) : Color::rgb(40, 43, 48));
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, C_ACCENT);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 11.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 7.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    const RectF h(trackX - 14.0F, y - 9.0F, trackX + 14.0F, y + 9.0F);
    shadow(c, h, 4.0F, 2.0F, 70);
    fillV(c, h, 4.0F, Color::rgb(236, 238, 241), Color::rgb(201, 204, 209));
    text(c, std::to_string(v), trackX, y + 4.0F, 10.0F, Color::rgb(48, 52, 58), Opt().center().bold());
    text(c, d.label, trackX, r.bottom + 16.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold());
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- the page
void SilvetonSamplerView::drawEngine(Canvas& c, const RectF& sec, int u) {
    using sv::engineName;
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const bool slotMode = u >= 7;   // SILVETON_ENGINE_SLOTS_V2: an engine slot has its own page - the engine keys are in its header, here only the pages and knobs
    if (!slotMode) secTitle(c, sec, "ENGINE · UPPER " + std::to_string(u + 1) + " · " + sv::engineLine(type));

    // row A: the ten engines, then the pages of the chosen one (three, or four for the engines with a second page of their own)
    const float keyY0 = slotMode ? sec.top + 2.0F : sec.top + 26.0F, keyY1 = keyY0 + (slotMode ? 44.0F : 36.0F);
    const float enginesW = 700.0F;
    // SILVETON_ONLY_V1: the old engines are not used any more - the row has only OFF and SILVETON SYNTH
    const EngineType shownKeys[2] = {EngineType::Off, EngineType::Solo};   // SILVETON_SOLO_V1
    const float kw = (enginesW - 4.0F) / 2.0F;
    for (int k = 0; k < (slotMode ? 0 : 2); ++k) {
        const EngineType kt = shownKeys[k];
        const float x0 = sec.left + static_cast<float>(k) * (kw + 4.0F);
        const RectF kr(x0, keyY0, x0 + kw, keyY1);
        stripToggle(c, kr, engineName(kt), typeIx == static_cast<int>(kt), C_ACCENT, 11.0F);
        hit(kr, [this, u, kt](float, float) {
            setEngineP(u, 0, static_cast<float>(static_cast<int>(kt)));
            enginePage_ = sv::engineOscPage(kt);   // SILVETON_ENGINES_PAGE_V2: opens on the oscillators
        });
    }
    // SILVETON_ENGINES_V2: ENGINE ON / OFF - OFF plays the plain recording and keeps every setting (to hear the difference)
    if (type != EngineType::Off && u < 7) {   // (an engine slot has its own ВКЛ / ИЗКЛ above - no second switch)
        const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
        const float x0 = sec.left + enginesW + 8.0F;
        const RectF br(x0, keyY0, x0 + 72.0F, keyY1);
        stripToggle(c, br, bypassed ? "OFF" : "ON", !bypassed, C_LCD_OK, 13.0F);
        hit(br, [this, u, bypassed](float, float) { setEngineP(u, sv::E_BYPASS + 1, bypassed ? 0.0F : 1.0F); });
    }
    const int pageCount = std::max(1, sv::enginePageCount(type));
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the ДЪХ page
    if (enginePage_ >= pageCount) enginePage_ = 0;
    if (type != EngineType::Off) {
        const float pw = pageCount >= 5 ? 74.0F : 94.0F;   // SILVETON_ENGINES_PAGE_V2: five pages fit beside the ON key
        // SILVETON_ENGINES_PAGE_V3: the ОСЦ page is the FIRST key of every engine (the others keep their order after it)
        std::array<int, 8> order{};
        int cnt = 0;
        order[static_cast<std::size_t>(cnt++)] = std::clamp(sv::engineOscPage(type), 0, pageCount - 1);
        for (int k = 0; k < pageCount && cnt < 8; ++k) if (k != order[0]) order[static_cast<std::size_t>(cnt++)] = k;
        for (int slotIx = 0; slotIx < pageCount; ++slotIx) {
            const int k = order[static_cast<std::size_t>(slotIx)];
            const float spw = slotMode ? 126.0F : pw;
            const float x1 = slotMode ? sec.left + 4.0F + static_cast<float>(slotIx) * (spw + 10.0F)
                                      : sec.right - static_cast<float>(pageCount - slotIx) * (pw + 4.0F) + 4.0F;
            const RectF pr(x1, keyY0, x1 + spw, keyY1);
            stripToggle(c, pr, sv::enginePageName(type, k, variant), enginePage_ == k, C_AMBER, slotMode ? 13.0F : 11.0F);
            hit(pr, [this, k](float, float) { enginePage_ = k; invalidate(); });
        }
    }
    if (type == EngineType::Off) {
        if (slotMode) {   // SILVETON_ENGINE_SLOTS_V2
            text(c, "Това място е празно.", sec.centerX(), sec.top + 150.0F, 24.0F, C_VALUE, Opt().center().bold());
            text(c, "Натисни СЛОЖИ SILVETON SOLO горе - той звучи сам, без Upper и без семпъл.", sec.centerX(), sec.top + 188.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
            text(c, "Можеш да пуснеш до 8 места наведнъж и да смесиш силата им отляво.", sec.centerX(), sec.top + 214.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
        } else {
            text(c, "SILVETON SOLO на този Upper: синтезаторът свири вместо записите му, на неговите клавиши. OFF = чист запис.", sec.left + 8.0F, sec.top + 110.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
            text(c, "Настройките се пазят в блендата / сета, както всичко друго.", sec.left + 8.0F, sec.top + 134.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
        }
        return;
    }

    // the knobs and keys of the page: one or two rows
    const EngineParamPage page = sv::enginePage(type, std::clamp(enginePage_, 0, pageCount - 1), variant);
    if (page.count <= 0 || page.items == nullptr) return;
    const int n = page.count;
    const bool cx3Sound = type == EngineType::CX3 && enginePage_ == 0;
    // SILVETON_SOLO_V2: SILVETON SOLO says itself how many knobs go in the first row (the rows follow the logic of the page)
    const int soloFirst = type == EngineType::Solo && n > 6 ? std::clamp(sv::solo::firstRow(enginePage_), 1, n) : -1;
    const int cols = soloFirst > 0 ? std::max(soloFirst, n - soloFirst) : (n <= 6 ? n : (cx3Sound ? std::max(12, n - 12) : (n + 1) / 2));   // SILVETON_ENGINE_WAVE_V1: up to 13 / 14 in a row
    const int firstRow = soloFirst > 0 ? soloFirst : (n <= 6 ? n : (cx3Sound ? 12 : (n + 1) / 2));
    const float unit = sec.width() / static_cast<float>(std::max(cols, 1));
    const float hw = std::min(unit - 4.0F, 150.0F);
    const float rad = 16.0F;
    const bool roomy = sec.height() > 360.0F;   // SILVETON_ENGINES_PAGE_V1: the page of its own has room - the rows do not touch
    const float r1 = n <= 6 ? sec.top + (roomy ? 190.0F : 150.0F) : sec.top + (roomy ? 140.0F : 102.0F);
    const float r2 = r1 + (roomy ? 150.0F : (darkTheme ? 96.0F : 86.0F));   // the dark theme prints the names above the knobs
    // SILVETON_SOLO_V1 / V2: a knob that does nothing with the waves chosen now (PULSE WIDTH on a saw, RATIO without VPM / COMB / RING,
    // SHAPE on plain waves) is dimmed, with the waves it works with written on it
    std::vector<float> soloRow;
    if (type == EngineType::Solo) { soloRow = eParams(u); if (soloRow.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) soloRow.clear(); }
    for (int i = 0; i < n; ++i) {
        const EngineParamDef& d = page.items[i];
        const bool second = i >= firstRow;
        const int col = second ? i - firstRow : i;
        const float cx = sec.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = second ? r2 : r1;
        switch (d.kind) {
            case EngineKind::Drawbar: engineDrawbar(c, RectF(cx - hw / 2.0F, cy - 36.0F, cx + hw / 2.0F, cy + 30.0F), u, d); break;
            case EngineKind::Choice:
            case EngineKind::Switch: engineKey(c, RectF(cx - hw / 2.0F + 2.0F, cy - 22.0F, cx + hw / 2.0F - 2.0F, cy + 22.0F), u, d); break;
            default: engineKnob(c, cx, cy, rad, hw, u, d); break;
        }
        const char* note = soloRow.empty() ? nullptr : sv::solo::dimNote(soloRow.data() + 1, d.id);
        if (note != nullptr) {
            fill(c, RectF(cx - hw / 2.0F, cy - rad - 28.0F, cx + hw / 2.0F, cy + rad + 58.0F), 8.0F, Color::argb(135, 0, 0, 0));
            text(c, note, cx, cy + 5.0F, 10.0F, C_AMBER, Opt().center().bold().maxW(hw - 4.0F));
        }
    }
}

} // namespace silveton::ui::classic
