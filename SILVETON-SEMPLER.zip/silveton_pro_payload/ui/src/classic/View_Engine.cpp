#include "silveton/ui/classic/SilvetonSamplerView.h"
#include <algorithm>
namespace silveton::ui::classic {
// Old page/tab IDs resolve to the same UPPER editor; no second rack or controls.
void SilvetonSamplerView::drawEnginesPage(Canvas& c) { drawSoundEdit(c); }
void SilvetonSamplerView::drawEngine(Canvas& c,const RectF& area,int upper) {
    nlBtn(c,area,"SOURCE / WAVE",NlBtn::On,14,true);
    hit(area,[this,upper](float,float){showSoloPart(std::clamp(upper,0,6),selectedSoloSound());});
}
}
