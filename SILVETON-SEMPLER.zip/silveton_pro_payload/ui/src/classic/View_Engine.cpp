// SILVETON_ENGINES_V1 - the ENGINE page of an Upper (КОМБИ > ENGINE): one of the nine engines on the whole Upper.
// Top row: the engines (OFF · HD-1 · POLYSIX · MS-20 · AL-1 · MOD-7 · STR-1 · CX-3 · SGX · EP) and the three pages of the
// chosen one (ЗВУК = the engine's own knobs, ФИЛТЪР = the two filters and the filter envelope, МОД = LFO / unison / analog).
// Every knob: drag = turn, tap = exact number, right button / double tap = its starting value. The labels, ranges and
// starting values come from core/include/silveton/sampler/EngineDefs.h, so the screen and the sound can never disagree.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/ModelDefs.h"   // SILVETON_MODEL_V1

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>

namespace silveton::ui::classic {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

// SILVETON_USER_WAVES_V1: a place USER n shows the name of the user's wave in it ("U2 STRINGS"), or "USER n НЯМА" when empty
std::string userWaveLabel(const std::string& s) {
    if (s.rfind("USER ", 0) != 0) return s;
    const int n = std::atoi(s.c_str() + 5);
    if (n < 1 || n > sv::kUserWaveCount) return s;
    const std::string nm = sv::userWaveName(n - 1);
    return nm.empty() ? s + " НЯМА" : "U" + std::to_string(n) + " " + nm;
}

std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return userWaveLabel(cur);
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- SILVETON_ENGINES_PAGE_V1: the page of the nine ENGINES (left menu)
// A row of the Uppers (tap = choose it), under it the ENGINE of the chosen Upper with all its pages and its oscillators.
void SilvetonSamplerView::drawEnginesPage(Canvas& c) {
    // SILVETON_ENGINE_SLOTS_V2: the engines have a page of their own. LEFT: the 8 places like a small mixer (name, ВКЛ lamp, СИЛА slider).
    // RIGHT: the chosen place - its engine, ВКЛ / СИЛА / POLY-MONO-LEGATO / PORTAMENTO, then the oscillators and knobs of the engine.
    const int slot = std::clamp(engSlot_, 0, 7);
    if (engUpper_ >= 7) engUpper_ = -1;
    const bool onUpper = engUpper_ >= 0;   // SILVETON_SUSE_SAMPLE_V1: an Upper of the blend is edited here (SILVETON SYNTH on its recordings)
    const int u = onUpper ? engUpper_ : 7 + slot;
    const ColorInt cardOff = Color::rgb(47, 51, 59), cardOn = Color::rgb(70, 76, 89);

    // ---- left: the eight places
    const RectF rack(112.0F, 112.0F, 372.0F, 786.0F);
    board(c, rack, true);
    for (int i = 0; i < 8; ++i) {
        const int pu = 7 + i;
        const float top = 124.0F + static_cast<float>(i) * 81.0F;
        const RectF r(124.0F, top, 360.0F, top + 75.0F);
        const bool sel = !onUpper && i == slot;
        const int t = std::clamp(rndI(engineP(pu, 0)), 0, sv::kEngineTypeCount - 1);
        const std::optional<UpperState> st = upperStates[static_cast<std::size_t>(pu)];
        const bool live = t != 0 && st && st->enabled;
        fill(c, r, 10.0F, sel ? cardOn : cardOff);
        if (sel) fill(c, RectF(r.left, r.top + 9.0F, r.left + 4.0F, r.bottom - 9.0F), 2.0F, C_ACCENT);
        text(c, std::to_string(i + 1), r.left + 24.0F, r.top + 38.0F, 26.0F, sel ? C_VALUE : C_KNOB_LABEL, Opt().center().bold());
        // SILVETON_SUSE_V1: only the new engine is shown - a place is "празно" or SILVETON SYNTH (an old engine of an old set is not named)
        // SILVETON_MODEL_V1: a place shows the sound of the bank it holds (the model changes that sound); no sound = "без звук"
        const bool isModelPlace = t != 0 && static_cast<EngineType>(t) == EngineType::Model;
        const std::string placeName = t == 0 ? std::string("празно") : (isModelPlace ? ((st && !st->soundName.empty() && st->soundName != "EMPTY") ? st->soundName : std::string("MODEL · без звук")) : std::string("стар"));
        text(c, placeName, r.left + 48.0F, r.top + 30.0F, isModelPlace ? 14.0F : 18.0F, t == 0 ? C_HINT : C_VALUE, Opt().bold().maxW(isModelPlace ? 134.0F : 110.0F));
        hit(r, [this, i](float, float) { engSlot_ = i; engUpper_ = -1; selectedUpper_ = 7 + i; enginePage_ = 0; invalidate(); });
        if (t != 0 && st) {
            // the lamp = ВКЛ / ИЗКЛ of the place
            const RectF lamp(r.right - 50.0F, r.top + 4.0F, r.right - 4.0F, r.top + 42.0F);
            fill(c, RectF(r.right - 30.0F, r.top + 15.0F, r.right - 14.0F, r.top + 31.0F), 8.0F, live ? C_ACCENT : Color::rgb(30, 33, 38));
            if (live) fill(c, RectF(r.right - 33.0F, r.top + 12.0F, r.right - 11.0F, r.top + 34.0F), 11.0F, Color::argb(60, 80, 220, 120));
            text(c, fmtFixed(static_cast<double>(st->levelDb), 1) + " dB", r.right - 14.0F, r.top + 47.0F, 11.0F, C_KNOB_LABEL, Opt().right().mono().maxW(80.0F));
            hit(lamp, [this, pu](float, float) {
                const auto& cur = upperStates[static_cast<std::size_t>(pu)];
                if (!cur) return;
                UpperState n = *cur; n.enabled = !n.enabled; if (n.enabled) n.mute = false;
                commitMain(pu, n); invalidate();
            });
            // the slider = СИЛА of the place (tap or drag; 0 dB is the small mark)
            const float x0 = r.left + 48.0F, x1 = r.right - 14.0F;
            const float ty = r.top + 56.0F;
            fill(c, RectF(x0, ty - 3.0F, x1, ty + 3.0F), 3.0F, Color::rgb(28, 31, 36));
            const float tv = std::clamp((st->levelDb + 60.0F) / 72.0F, 0.0F, 1.0F);
            fill(c, RectF(x0, ty - 3.0F, x0 + (x1 - x0) * tv, ty + 3.0F), 3.0F, live ? C_ACCENT : Color::rgb(110, 116, 126));
            fill(c, RectF(x0 + (x1 - x0) * (60.0F / 72.0F) - 1.0F, ty - 8.0F, x0 + (x1 - x0) * (60.0F / 72.0F) + 1.0F, ty - 4.0F), 0.0F, Color::argb(110, 255, 255, 255));
            fill(c, RectF(x0 + (x1 - x0) * tv - 8.0F, ty - 8.0F, x0 + (x1 - x0) * tv + 8.0F, ty + 8.0F), 8.0F, Color::rgb(226, 229, 234));
            const auto setLevel = [this, pu, x0, x1](float x, float) {
                const auto& cur = upperStates[static_cast<std::size_t>(pu)];
                if (!cur) return;
                const float v = std::clamp(-60.0F + (x - x0) / std::max(1.0F, x1 - x0) * 72.0F, -60.0F, 12.0F);
                UpperState n = *cur; n.levelDb = std::nearbyint(v * 2.0F) * 0.5F;
                if (std::fabs(n.levelDb) < 0.75F) n.levelDb = 0.0F;   // it sticks to 0 dB
                commitMain(pu, n);
            };
            hit(RectF(x0 - 10.0F, ty - 16.0F, x1 + 10.0F, ty + 16.0F), setLevel,
                [this, pu] { const auto& cur = upperStates[static_cast<std::size_t>(pu)]; if (!cur) return; UpperState n = *cur; n.levelDb = 0.0F; commitMain(pu, n); },
                [setLevel](float x, float y, bool) { setLevel(x, y); });
        }
    }

    // ---- right, top: the chosen place and its engine keys
    const float L = 388.0F, R = 1326.0F;
    const int tSel = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto typeSel = static_cast<EngineType>(tSel);
    const RectF head(L, 112.0F, R, 238.0F);
    board(c, head, false);
    text(c, onUpper ? "UPPER " + std::to_string(u + 1) + " · БЛЕНДА" : "МЯСТО " + std::to_string(slot + 1), L + 22.0F, 138.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
    // SILVETON_MODEL_V1: ONE engine - there is no choice. A place holds SILVETON MODEL, or it is empty and has one key to create it.
    const bool isModel = typeSel == EngineType::Model;
    if (isModel) {
        modelHead(c, head, u);
    } else {
        text(c, tSel == 0 ? std::string("ПРАЗНО") : std::string("СТАР ДВИГАТЕЛ"), L + 22.0F, 172.0F, 32.0F, C_HINT, Opt().bold().maxW(360.0F));
        text(c, "Без свой звук: слагаш звук от банката, избираш научен МОДЕЛ и врътките изменят звука към него (тембър, атака, дъх, унисон). TUNE мести само тембъра.", L + 392.0F, 166.0F, 14.0F, C_KNOB_LABEL, Opt().maxW(R - L - 420.0F));
        const RectF kr(L + 22.0F, 188.0F, L + 22.0F + 330.0F, 228.0F);
        stripToggle(c, kr, tSel == 0 ? "СЛОЖИ SILVETON MODEL" : "ЗАМЕНИ СЪС SILVETON MODEL", false, C_ACCENT, 14.0F);
        hit(kr, [this, u](float, float) {
            setEngineP(u, 0, static_cast<float>(static_cast<int>(EngineType::Model)));
            enginePage_ = 0; invalidate();
        });
    }

    // ---- right, middle: ВКЛ / СИЛА, POLY / MONO / LEGATO, PORTAMENTO
    const RectF strip(L, 246.0F, R, 394.0F);
    board(c, strip, false);
    if (upperStates[static_cast<std::size_t>(u)]) {
        const UpperState st = *upperStates[static_cast<std::size_t>(u)];
        const std::vector<float> p = uParams(u);
        const auto card = [&](float x0, float x1, const char* name) {
            fill(c, RectF(x0, strip.top + 10.0F, x1, strip.bottom - 10.0F), 10.0F, Color::argb(26, 255, 255, 255));
            text(c, name, x0 + 14.0F, strip.top + 31.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
        };
        card(L + 10.0F, L + 258.0F, "ГЛАС");
        card(L + 266.0F, R - 10.0F, "СВИРЕНЕ");
        const float ky0 = strip.top + 50.0F, ky1 = ky0 + 44.0F;
        const RectF onR(L + 26.0F, ky0, L + 112.0F, ky1);
        stripToggle(c, onR, st.enabled ? "ВКЛ" : "ИЗКЛ", st.enabled, C_AMBER, 14.0F);
        hit(onR, [this, st](float, float) { UpperState cur = currentUpper(st); cur.enabled = !cur.enabled; if (cur.enabled) cur.mute = false; commitMain(selectedUpper_, cur); invalidate(); });
        {
            auto setLevel = [this, st](float v) { UpperState n = currentUpper(st); n.levelDb = v; commitMain(selectedUpper_, n); };
            knobControl(c, L + 186.0F, strip.top + 68.0F, 18.0F, st.levelDb, -60.0F, 12.0F, 0.5F, 300.0F, false, fmtFixed(static_cast<double>(st.levelDb), 1) + " dB", "СИЛА", 110.0F, setLevel,
                        [this, st, setLevel] { showNumber("СИЛА НА ДВИГАТЕЛЯ dB", st.levelDb, -60.0F, 12.0F, 1, setLevel); },
                        [setLevel] { setLevel(0.0F); });
        }
        for (int k = 0; k < 3; ++k) {
            const RectF mr(L + 280.0F + static_cast<float>(k) * 102.0F, ky0, L + 374.0F + static_cast<float>(k) * 102.0F, ky1);
            stripToggle(c, mr, k == 0 ? "POLY" : (k == 1 ? "MONO" : "LEGATO"), st.voiceMode == k, C_AMBER, 13.0F);
            hit(mr, [this, st, k](float, float) { UpperState cur = currentUpper(st); cur.voiceMode = k; commitMain(selectedUpper_, cur); invalidate(); });
        }
        text(c, st.voiceMode == 0 ? "много ноти наведнъж" : (st.voiceMode == 1 ? "една нота, всяка се почва отначало" : "една нота, плавно между тях"),
             L + 280.0F, strip.bottom - 22.0F, 11.0F, C_HINT, Opt().maxW(300.0F));
    }

    // ---- right, bottom: the pages and knobs of the engine
    board(c, RectF(L, 402.0F, R, 786.0F), false);
    if (isModel) drawEngine(c, RectF(L + 16.0F, 412.0F, R - 16.0F, 776.0F), u);
    else text(c, "Натисни горе ключа, за да сложиш SILVETON MODEL на това място.", L + 40.0F, 480.0F, 16.0F, C_HINT, Opt().maxW(R - L - 80.0F));
}

// ---------------------------------------------------------------- SILVETON_MODEL_V1: the head of a SILVETON MODEL place
void SilvetonSamplerView::modelHead(Canvas& c, const RectF& head, int u) {
    const float L = head.left, R = head.right;
    text(c, "SILVETON MODEL", L + 110.0F, 138.0F, 15.0F, C_VALUE, Opt().bold().maxW(180.0F));
    text(c, sv::engineLine(EngineType::Model), L + 22.0F, 160.0F, 12.0F, C_VALUE, Opt().maxW(R - L - 22.0F - 232.0F));
    text(c, "Ръчка: въртене = стойност · допир = точно число · десен бутон = началната. Страниците са долу.", L + 22.0F, 177.0F, 12.0F, C_KNOB_LABEL, Opt().maxW(R - L - 22.0F - 232.0F));
    // the real meters (the whole sampler)
    const Ctrl::AudioStatus a = frameAudioStatus;
    text(c, "ПРОЦЕСОР (всичко)", R - 210.0F, 128.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    text(c, std::to_string(rndI(a.cpuLoadPercent)) + " %", R - 22.0F, 128.0F, 13.0F, a.cpuLoadPercent > 80.0F ? C_AMBER : C_VALUE, Opt().right().mono().bold());
    fill(c, RectF(R - 210.0F, 134.0F, R - 22.0F, 139.0F), 2.5F, Color::rgb(28, 31, 36));
    fill(c, RectF(R - 210.0F, 134.0F, R - 210.0F + 188.0F * std::clamp(a.cpuLoadPercent / 100.0F, 0.0F, 1.0F), 139.0F), 2.5F, a.cpuLoadPercent > 80.0F ? C_AMBER : C_ACCENT);
    text(c, "ГЛАСОВЕ (всичко)", R - 210.0F, 156.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    text(c, std::to_string(a.activeVoices), R - 22.0F, 156.0F, 13.0F, C_VALUE, Opt().right().mono().bold());
    // ЗВУК (of the bank) · МОДЕЛ (of the learned file) · НАЧАЛНИ ВРЪТКИ
    const std::optional<UpperState>& st = upperStates[static_cast<std::size_t>(u)];
    const bool hasSound = st && !st->soundName.empty() && st->soundName != "EMPTY";
    const RectF rz(L + 22.0F, 192.0F, L + 22.0F + 330.0F, 228.0F), rm(L + 22.0F + 342.0F, 192.0F, R - 222.0F, 228.0F), rr(R - 210.0F, 192.0F, R - 22.0F, 228.0F);
    stripToggle(c, rz, hasSound ? "ЗВУК: " + st->soundName : std::string("ЗВУК  ▼  избери от банката"), hasSound, C_ACCENT, 12.0F);
    const std::vector<std::string> models = sampler.learnedModelNames();
    const int mSel = std::clamp(rndI(engineP(u, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels);
    std::string mText;
    if (models.empty()) mText = "МОДЕЛ: няма вградени модели";
    else if (mSel <= 0) mText = "МОДЕЛ  ▼  избери (" + std::to_string(models.size()) + " научени)";
    else mText = "МОДЕЛ " + std::to_string(mSel) + ": " + (mSel <= static_cast<int>(models.size()) ? models[static_cast<std::size_t>(mSel - 1)] : std::string("няма го във файла"));
    stripToggle(c, rm, mText, mSel > 0 && !models.empty(), C_AMBER, 12.0F);
    stripToggle(c, rr, "НАЧАЛНИ ВРЪТКИ", false, C_AMBER, 12.0F);
    hit(rz, [this, u](float, float) { showSoundPicker(u); });
    hit(rm, [this, u, models](float, float) {
        if (models.empty()) { showMessage("НЯМА МОДЕЛИ", "Моделите са вградени в семплера; нови се добавят със SILVETON_OSC.sv (от SILVETON TEACHER, ЗАПИШИ) до SILVETON_BANK.sv.\n" + sampler.learnedModelsNote()); return; }
        std::vector<std::pair<std::string, std::string>> items;
        for (std::size_t i = 0; i < models.size(); ++i) items.emplace_back(std::to_string(i + 1), models[i]);
        const int cur = std::clamp(rndI(engineP(u, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels) - 1;
        showGridPicker("МОДЕЛ  ·  наученото се налага върху звука на мястото, ГОТОВО затваря", items, cur, std::string("NONE"), [this, u](int k) {
            setEngineP(u, sv::model::MO_MODEL + 1, static_cast<float>(k + 1));   // -1 (NONE) -> 0
            invalidate();
        });
        if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open: try the models one after another, ГОТОВО closes
    });
    hit(rr, [this, u](float, float) {
        showConfirm("НАЧАЛНИ ВРЪТКИ", "Всички ръчки на двигателя на това място се връщат на началното (звукът и моделът остават).", "ДА, ВЪРНИ", [this, u]() {
            std::vector<float> row(eParams(u));
            if (row.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) return;
            const float keepModel = row[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U];
            sv::model::setDefaults(row.data() + 1);
            row[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U] = keepModel;
            std::vector<float> values(row.begin() + 1, row.begin() + 1 + sv::kEngineParamCountLegacy);
            sampler.setUpperEngineBlock(u, 1, values);
            engineParamsCache[static_cast<std::size_t>(u)].reset();
            invalidate();
        });
    });
}

// SILVETON_MODEL_V1: the pages of the place itself - its envelope, its octave / transpose / fine tune, how it plays (the same
// POLY / MONO / LEGATO, SILVETON / KRONOS / BASS portamento and pitch bend as an Upper of the blend)
void SilvetonSamplerView::drawModelExtraPage(Canvas& c, const RectF& sec, int u, int page) {
    const std::optional<UpperState>& slot = upperStates[static_cast<std::size_t>(u)];
    if (!slot) return;
    const UpperState st = *slot;
    if (page == 0) {   // ENV
        const float cy = sec.top + 190.0F;
        const float cx0 = sec.left + sec.width() / 8.0F, dx = sec.width() / 4.0F;
        const auto ms = [](float v) { return v >= 1000.0F ? fmtFixed(static_cast<double>(v) / 1000.0, 2) + " s" : fmtFixed(static_cast<double>(v), 0) + " ms"; };
        const auto knobMs = [&](float cx, const char* name, const char* exactName, float value, float hi, TonePar par, float def) {
            knobControl(c, cx, cy, 30.0F, value, 0.0F, hi, 1.0F, 400.0F, false, ms(value), name, 190.0F,
                        [this, par](float v) { setTone(par, v); },
                        [this, exactName, value, hi, par] { showNumber(exactName, value, 0.0F, hi, 0, [this, par](float v) { setTone(par, v); }); },
                        [this, par, def] { setTone(par, def); });
        };
        knobMs(cx0, "ATTACK", "ATTACK ms", st.toneAttackMs, 5000.0F, TonePar::ATTACK, 5.0F);
        knobMs(cx0 + dx, "DECAY", "DECAY ms", st.toneDecayMs, 10000.0F, TonePar::DECAY, 80.0F);
        knobControl(c, cx0 + 2.0F * dx, cy, 30.0F, st.toneSustain * 100.0F, 0.0F, 100.0F, 1.0F, 300.0F, false, fmtFixed(static_cast<double>(st.toneSustain) * 100.0, 0) + " %", "SUSTAIN", 190.0F,
                    [this](float v) { setTone(TonePar::SUSTAIN, v / 100.0F); },
                    [this, st] { showNumber("SUSTAIN %", st.toneSustain * 100.0F, 0.0F, 100.0F, 0, [this](float v) { setTone(TonePar::SUSTAIN, v / 100.0F); }); },
                    [this] { setTone(TonePar::SUSTAIN, 1.0F); });
        knobMs(cx0 + 3.0F * dx, "RELEASE", "RELEASE ms", st.toneReleaseMs, 10000.0F, TonePar::RELEASE, 200.0F);
        text(c, "Обвивката на силата на това място: атака, затихване, държане, отпускане. Моделът слага своята атака отгоре (SHAPE на страница MODEL).", sec.left + 8.0F, sec.bottom - 14.0F, 12.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
    } else if (page == 1) {   // TUNE: OCTAVE / TRANSPOSE / FINE of the place (the special TUNE of the model is on the MODEL page)
        drawTune(c, RectF(sec.left, 532.0F, sec.right, 740.0F), st);
    } else {   // PLAY: the portamento of the place (SILVETON / KRONOS / BASS, the same settings as an Upper of the blend) and its pitch bend
        const int u2 = u; (void)u2;
        const std::vector<float> p = uParams(u);
        const int mode = std::clamp(rndI(getOr(p, 42, 0.0F)), 0, 3);
        const float X = sec.left + 8.0F, ky0 = sec.top + 86.0F, ky1 = ky0 + 44.0F;
        text(c, "ПОРТАМЕНТО НА МЯСТОТО  ·  POLY / MONO / LEGATO са горе в СВИРЕНЕ", X, sec.top + 72.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
        const char* names[3] = {"SILVETON", "KRONOS", "BASS"};
        const int modeOf[3] = {0, 1, 3};
        for (int k = 0; k < 3; ++k) {
            const RectF mr(X + static_cast<float>(k) * 168.0F, ky0, X + 156.0F + static_cast<float>(k) * 168.0F, ky1);
            stripToggle(c, mr, names[k], mode == modeOf[k], C_AMBER, 13.0F);
            const int m = modeOf[k];
            hit(mr, [this, u, m](float, float) { setUParam(u, 42, static_cast<float>(m)); });
        }
        const float cy = sec.top + 232.0F;
        if (mode == 0 || mode == 2) {
            const float porta = portamentoUiValue(st.portamentoSec);
            auto setPorta = [this, st](float v) { UpperState n = currentUpper(st); n.portamentoSec = portamentoSecondsFromUi(v); commitTune(n); };
            knobControl(c, X + 90.0F, cy, 30.0F, porta, 0.0F, 100.0F, 1.0F, 300.0F, false,
                        porta <= 0.0F ? std::string("OFF") : fmtFixed(static_cast<double>(porta), 2) + " ms", "PORTAMENTO TIME", 170.0F, setPorta,
                        [this, porta, setPorta] { showNumber("PORTAMENTO TIME ms (0 = OFF)", porta, 0.0F, 100.0F, 0, setPorta); },
                        [this, st] { UpperState n = currentUpper(st); n.portamentoSec = 0.0F; commitTune(n); });
            const float bal = static_cast<float>(sampler.portaBalance());
            knobControl(c, X + 290.0F, cy, 30.0F, bal, 3.0F, 40.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bal)), "BALANCE", 170.0F,
                        [this](float nv) { sampler.setPortaBalance(rndI(nv)); },
                        [this, bal] { showNumber("PORTA BALANCE (мекота)", bal, 3.0F, 40.0F, 0, [this](float x) { sampler.setPortaBalance(rndI(x)); }); },
                        [this] { sampler.setPortaBalance(11); });
            const float nearV = static_cast<float>(sampler.portaNear());
            knobControl(c, X + 490.0F, cy, 30.0F, nearV, 0.0F, 400.0F, 1.0F, 300.0F, false, fmtFixed(static_cast<double>(nearV), 2) + " ms", "TIME СЪСЕДНИ", 170.0F,
                        [this](float nv) { sampler.setPortaNear(rndI(nv)); },
                        [this, nearV] { showNumber("TIME СЪСЕДНИ ТОНОВЕ ms", nearV, 0.0F, 400.0F, 0, [this](float x) { sampler.setPortaNear(rndI(x)); }); },
                        [this] { sampler.setPortaNear(90); });
            text(c, "Меко влизане · чисто достигане точно в TIME · BALANCE и СЪСЕДНИ са общи за всички", X, sec.bottom - 14.0F, 11.0F, C_HINT, Opt().maxW(620.0F));
        } else {
            const float t = getOr(p, 45, 40.0F);
            knobControl(c, X + 90.0F, cy, 30.0F, t, 0.0F, 127.0F, 1.0F, 300.0F, false, t <= 0.0F ? std::string("OFF") : std::to_string(static_cast<int>(t)), mode == 1 ? "TIME 0–127" : "BASS TIME 0–127", 170.0F,
                        [this, u](float nv) { setUParam(u, 45, static_cast<float>(rndI(nv))); },
                        [this, u, t] { showNumber("PORTA TIME (0 = OFF)", t, 0.0F, 127.0F, 0, [this, u](float x) { setUParam(u, 45, static_cast<float>(rndI(x))); }); },
                        [this, u] { setUParam(u, 45, 0.0F); });
            const bool fing = getOr(p, 43, 0.0F) >= 0.5F;
            const RectF fr(X + 210.0F, cy - 24.0F, X + 370.0F, cy + 24.0F);
            stripToggle(c, fr, "FINGERED", fing, C_AMBER, 13.0F);
            hit(fr, [this, u, fing](float, float) { setUParam(u, 43, fing ? 0.0F : 1.0F); });
            text(c, "само докато държиш клавиш", X + 290.0F, cy + 48.0F, 11.0F, C_KNOB_LABEL, Opt().center());
            const bool rate = getOr(p, 44, 0.0F) >= 0.5F;
            const RectF rA(X + 390.0F, cy - 24.0F, X + 480.0F, cy + 24.0F), rB(X + 486.0F, cy - 24.0F, X + 576.0F, cy + 24.0F);
            stripToggle(c, rA, "TIME", !rate, C_AMBER, 13.0F);
            stripToggle(c, rB, "RATE", rate, C_AMBER, 13.0F);
            hit(rA, [this, u](float, float) { setUParam(u, 44, 0.0F); });
            hit(rB, [this, u](float, float) { setUParam(u, 44, 1.0F); });
            text(c, rate ? "RATE: времето е за една октава" : "TIME: едно и също време за всеки интервал", X + 483.0F, cy + 48.0F, 11.0F, C_KNOB_LABEL, Opt().center());
            text(c, mode == 1 ? "Меко, стегнато преливане · TIME / RATE" : "Слайдът продължава със записа, с който е почнала нотата", X, sec.bottom - 14.0F, 11.0F, C_HINT, Opt().maxW(620.0F));
        }
        // PITCH BEND RANGE of the place
        line(c, sec.right - 230.0F, ky0, sec.right - 230.0F, cy + 60.0F, Color::argb(60, 255, 255, 255), 1.0F);
        const float bend = getOr(p, 48, 2.0F);
        knobControl(c, sec.right - 130.0F, cy, 30.0F, bend, 0.0F, 24.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bend)) + " st", "PITCH BEND", 150.0F,
                    [this, u](float nv) { setUParam(u, 48, static_cast<float>(rndI(nv))); },
                    [this, u, bend] { showNumber("PITCH BEND RANGE (полутонове)", bend, 0.0F, 24.0F, 0, [this, u](float x) { setUParam(u, 48, static_cast<float>(rndI(x))); }); },
                    [this, u] { setUParam(u, 48, 2.0F); });
    }
}

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u, int id, float v) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id, v);
    // the engine itself changed = its starting values were loaded: read everything again.
    // SILVETON_ENGINE_UPPER_ON_V1: choosing an engine on an empty Upper switches the Upper on in the engine - read the Upper
    // again too, or the next LEVEL / PAN / range move would send the old OFF back and the engine's sound would stop
    if (!ok || id == 0) { slot.reset(); refreshUpper(u); }
    // SILVETON_ENGINES_V3: the STR-1 INSTRUMENT loads its typical values - read them all again
    else if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && id == sv::ST_BODY_TYPE + 1) slot.reset();
    else {
        auto a = eParams(u);
        // SILVETON_MUSICAL_V1: the value as the engine keeps it (a RATIO jumps to its musical step)
        const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
        if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = id >= 1 ? sv::engineClamp(type, id - 1, v) : v;
        slot = a;
        // SILVETON_ENGINE_WAVE_V1: a ВЪЛНА chosen on a set saved before (its level is 0 there) gets the starting level
        int wid = 0, lid = 0, oid = 0;
        if (v >= 0.5F && sv::engineWaveIds(type, wid, lid, oid) && id == wid + 1 && engineP(u, lid + 1) <= 0.0F) {
            const EngineParamDef* d = sv::engineParamDef(type, lid);
            if (d != nullptr) setEnginePOne(u, lid + 1, d->def);
        }
    }
    invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v) - rndI(d.lo));   // SILVETON_OCTAVE_V1: a choice may start below 0 (ОКТАВА -2..+2) or at 1 (SUB OCT)
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = d.label;
    const std::string hint = d.hint;
    if (logKind(d)) {
        knobControl(c, cx, cy, rad, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
                    [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
                    [this, u, id, d, v, hint, pct] {
                        showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                                   [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
                    },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && d.id == sv::ST_STYLE)
        d.names = sv::str1StyleNames(rndI(engineP(u, sv::ST_BODY_TYPE + 1)));
    const int id = d.id + 1;
    const float v = engineP(u, id);
    // SILVETON_OCTAVE_V2: ОКТАВА is  [ - ]  +1 OCT  [ + ]  - one tap = one octave, a tap on the middle = back to 0
    if (d.kind == EngineKind::Choice && rndI(d.lo) == -2 && rndI(d.hi) == 2) {
        const int cur = std::clamp(rndI(v), -2, 2);
        stripToggle(c, r, cur == 0 ? "0 OCT" : (cur > 0 ? "+" + std::to_string(cur) + " OCT" : std::to_string(cur) + " OCT"), cur != 0, C_AMBER, 11.0F);
        const float w = std::min(r.width() * 0.3F, 46.0F);
        const RectF lr(r.left, r.top, r.left + w, r.bottom), rr(r.right - w, r.top, r.right, r.bottom), mr(r.left + w, r.top, r.right - w, r.bottom);
        text(c, "-", lr.centerX(), lr.centerY() + 7.0F, 22.0F, C_KNOB_LABEL, Opt().center().bold());
        text(c, "+", rr.centerX(), rr.centerY() + 7.0F, 22.0F, C_KNOB_LABEL, Opt().center().bold());
        text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
        hit(lr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::max(cur - 1, -2))); });
        hit(rr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::min(cur + 1, 2))); });
        hit(mr, [](float, float) {}, [this, u, id] { setEngineP(u, id, 0.0F); });
        return;
    }
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    stripToggle(c, r, engineValueText(d, v), on, C_AMBER, 11.0F);
    text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — избери и свири · допир извън прозореца = затваряне";
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open while choosing and playing
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, darkTheme ? Color::rgb(16, 18, 16) : Color::rgb(40, 43, 48));
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, C_ACCENT);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 11.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 7.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    const RectF h(trackX - 14.0F, y - 9.0F, trackX + 14.0F, y + 9.0F);
    shadow(c, h, 4.0F, 2.0F, 70);
    fillV(c, h, 4.0F, Color::rgb(236, 238, 241), Color::rgb(201, 204, 209));
    text(c, std::to_string(v), trackX, y + 4.0F, 10.0F, Color::rgb(48, 52, 58), Opt().center().bold());
    text(c, d.label, trackX, r.bottom + 16.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold());
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- the page
void SilvetonSamplerView::drawEngine(Canvas& c, const RectF& sec, int u) {
    using sv::engineName;
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const bool slotMode = u >= 7;   // SILVETON_ENGINE_SLOTS_V2: an engine slot has its own page - the engine keys are in its header, here only the pages and knobs
    if (!slotMode) secTitle(c, sec, "ENGINE · UPPER " + std::to_string(u + 1) + " · " + sv::engineLine(type));

    // row A: the ten engines, then the pages of the chosen one (three, or four for the engines with a second page of their own)
    const float keyY0 = slotMode ? sec.top + 2.0F : sec.top + 26.0F, keyY1 = keyY0 + (slotMode ? 44.0F : 36.0F);
    const float enginesW = 700.0F;
    // SILVETON_ONLY_V1: the old engines are not used any more - the row has only OFF and SILVETON SYNTH
    const EngineType shownKeys[2] = {EngineType::Off, EngineType::Model};   // SILVETON_MODEL_V1
    const float kw = (enginesW - 4.0F) / 2.0F;
    for (int k = 0; k < (slotMode ? 0 : 2); ++k) {
        const EngineType kt = shownKeys[k];
        const float x0 = sec.left + static_cast<float>(k) * (kw + 4.0F);
        const RectF kr(x0, keyY0, x0 + kw, keyY1);
        stripToggle(c, kr, engineName(kt), typeIx == static_cast<int>(kt), C_ACCENT, 11.0F);
        hit(kr, [this, u, kt](float, float) {
            setEngineP(u, 0, static_cast<float>(static_cast<int>(kt)));
            enginePage_ = sv::engineOscPage(kt);   // SILVETON_ENGINES_PAGE_V2: opens on the oscillators
        });
    }
    // SILVETON_ENGINES_V2: ENGINE ON / OFF - OFF plays the plain recording and keeps every setting (to hear the difference)
    if (type != EngineType::Off && u < 7) {   // (an engine slot has its own ВКЛ / ИЗКЛ above - no second switch)
        const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
        const float x0 = sec.left + enginesW + 8.0F;
        const RectF br(x0, keyY0, x0 + 72.0F, keyY1);
        stripToggle(c, br, bypassed ? "OFF" : "ON", !bypassed, C_LCD_OK, 13.0F);
        hit(br, [this, u, bypassed](float, float) { setEngineP(u, sv::E_BYPASS + 1, bypassed ? 0.0F : 1.0F); });
    }
    const int pageCount = std::max(1, sv::enginePageCount(type));
    // SILVETON_MODEL_V1: a SILVETON MODEL place has three pages of its own after the engine's: ENV, TUNE (octave / transpose / fine), PLAY
    const int extraPages = type == EngineType::Model && slotMode ? 3 : 0;
    static const char* const kExtraNames[3] = {"ENV", "TUNE", "PLAY"};
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the ДЪХ page
    if (enginePage_ >= pageCount + extraPages) enginePage_ = 0;
    if (type != EngineType::Off) {
        const float pw = pageCount >= 5 ? 74.0F : 94.0F;   // SILVETON_ENGINES_PAGE_V2: five pages fit beside the ON key
        // SILVETON_ENGINES_PAGE_V3: the ОСЦ page is the FIRST key of every engine (the others keep their order after it)
        std::array<int, 8> order{};
        int cnt = 0;
        order[static_cast<std::size_t>(cnt++)] = std::clamp(sv::engineOscPage(type), 0, pageCount - 1);
        for (int k = 0; k < pageCount + extraPages && cnt < 8; ++k) if (k != order[0]) order[static_cast<std::size_t>(cnt++)] = k;
        for (int slotIx = 0; slotIx < pageCount + extraPages; ++slotIx) {
            const int k = order[static_cast<std::size_t>(slotIx)];
            const float spw = slotMode ? 126.0F : pw;
            const float x1 = slotMode ? sec.left + 4.0F + static_cast<float>(slotIx) * (spw + 10.0F)
                                      : sec.right - static_cast<float>(pageCount - slotIx) * (pw + 4.0F) + 4.0F;
            const RectF pr(x1, keyY0, x1 + spw, keyY1);
            stripToggle(c, pr, k >= pageCount ? kExtraNames[k - pageCount] : sv::enginePageName(type, k, variant), enginePage_ == k, C_AMBER, slotMode ? 13.0F : 11.0F);
            hit(pr, [this, k](float, float) { enginePage_ = k; invalidate(); });
        }
    }
    if (extraPages > 0 && enginePage_ >= pageCount) { drawModelExtraPage(c, sec, u, enginePage_ - pageCount); return; }
    if (type == EngineType::Off) {
        if (slotMode) {   // SILVETON_ENGINE_SLOTS_V2
            text(c, "Това място е празно.", sec.centerX(), sec.top + 150.0F, 24.0F, C_VALUE, Opt().center().bold());
            text(c, "Натисни СЛОЖИ SILVETON MODEL горе, после ЗВУК - звук от банката, и МОДЕЛ - наученото от семплите.", sec.centerX(), sec.top + 188.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
            text(c, "Можеш да пуснеш до 8 места наведнъж и да смесиш силата им отляво.", sec.centerX(), sec.top + 214.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
        } else {
            text(c, "SILVETON MODEL на този Upper: записите му се променят към избрания модел. OFF = чист запис.", sec.left + 8.0F, sec.top + 110.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
            text(c, "Настройките се пазят в блендата / сета, както всичко друго.", sec.left + 8.0F, sec.top + 134.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
        }
        return;
    }

    // the knobs and keys of the page: one or two rows
    const EngineParamPage page = sv::enginePage(type, std::clamp(enginePage_, 0, pageCount - 1), variant);
    if (page.count <= 0 || page.items == nullptr) return;
    const int n = page.count;
    const bool cx3Sound = type == EngineType::CX3 && enginePage_ == 0;
    // SILVETON_MODEL_V1: SILVETON MODEL says itself how many knobs go in the first row (the rows follow the logic of the page)
    const int modelFirst = type == EngineType::Model && n > 6 ? std::clamp(sv::model::firstRow(enginePage_), 1, n) : -1;
    const int cols = modelFirst > 0 ? std::max(modelFirst, n - modelFirst) : (n <= 6 ? n : (cx3Sound ? std::max(12, n - 12) : (n + 1) / 2));   // SILVETON_ENGINE_WAVE_V1: up to 13 / 14 in a row
    const int firstRow = modelFirst > 0 ? modelFirst : (n <= 6 ? n : (cx3Sound ? 12 : (n + 1) / 2));
    const float unit = sec.width() / static_cast<float>(std::max(cols, 1));
    const float hw = std::min(unit - 4.0F, 150.0F);
    const float rad = 16.0F;
    const bool roomy = sec.height() > 360.0F;   // SILVETON_ENGINES_PAGE_V1: the page of its own has room - the rows do not touch
    const float r1 = n <= 6 ? sec.top + (roomy ? 190.0F : 150.0F) : sec.top + (roomy ? 140.0F : 102.0F);
    const float r2 = r1 + (roomy ? 150.0F : (darkTheme ? 96.0F : 86.0F));   // the dark theme prints the names above the knobs
    // SILVETON_MODEL_V1: without a chosen model the learned knobs do nothing - they are dimmed, with a note on them
    std::vector<float> modelRow;
    if (type == EngineType::Model) { modelRow = eParams(u); if (modelRow.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) modelRow.clear(); }
    const bool noModel = !modelRow.empty() && sv::model::modelIndex(modelRow.data() + 1) == 0;
    for (int i = 0; i < n; ++i) {
        const EngineParamDef& d = page.items[i];
        const bool second = i >= firstRow;
        const int col = second ? i - firstRow : i;
        const float cx = sec.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = second ? r2 : r1;
        switch (d.kind) {
            case EngineKind::Drawbar: engineDrawbar(c, RectF(cx - hw / 2.0F, cy - 36.0F, cx + hw / 2.0F, cy + 30.0F), u, d); break;
            case EngineKind::Choice:
            case EngineKind::Switch: engineKey(c, RectF(cx - hw / 2.0F + 2.0F, cy - 22.0F, cx + hw / 2.0F - 2.0F, cy + 22.0F), u, d); break;
            default: engineKnob(c, cx, cy, rad, hw, u, d); break;
        }
        const char* note = nullptr;
        if (noModel && d.id >= sv::model::MO_AMOUNT && d.id <= sv::model::MO_FORMANT && d.id != sv::model::MO_TUNE && d.id != sv::model::MO_BRIGHT) note = "избери МОДЕЛ";
        if (note != nullptr) {
            fill(c, RectF(cx - hw / 2.0F, cy - rad - 28.0F, cx + hw / 2.0F, cy + rad + 58.0F), 8.0F, Color::argb(135, 0, 0, 0));
            text(c, note, cx, cy + 5.0F, 10.0F, C_AMBER, Opt().center().bold().maxW(hw - 4.0F));
        }
    }
}

} // namespace silveton::ui::classic
