// SILVETON_NEW_LOOK_V1: the ENGINE page of the new look (pictures engine_rack, engine_fx, engine_legacy) is drawn by drawEnginesPage (the rack of places +
// drawModelOneScreen / drawPlaceFxNew) and drawEngineLegacy (an Upper with an old-style engine); the helpers neRack, neHead, neKnob ... are declared in
// view/Members_NEngine.inc. The old drawEngine below is only used by the old COMBI page.
// SILVETON_ENGINES_V1 - the ENGINE page of an Upper (КОМБИ > ENGINE): one of the nine engines on the whole Upper.
// Top row: the engines (OFF · HD-1 · POLYSIX · MS-20 · AL-1 · MOD-7 · STR-1 · CX-3 · SGX · EP) and the three pages of the
// chosen one (ЗВУК = the engine's own knobs, ФИЛТЪР = the two filters and the filter envelope, МОД = LFO / unison / analog).
// Every knob: drag = turn, tap = exact number, right button / double tap = its starting value. The labels, ranges and
// starting values come from core/include/silveton/sampler/EngineDefs.h, so the screen and the sound can never disagree.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/ModelDefs.h"   // SILVETON_MODEL_V1

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>

namespace silveton::ui::classic {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

// SILVETON_USER_WAVES_V1: a place USER n shows the name of the user's wave in it ("U2 STRINGS"), or "USER n НЯМА" when empty
std::string userWaveLabel(const std::string& s) {
    if (s.rfind("USER ", 0) != 0) return s;
    const int n = std::atoi(s.c_str() + 5);
    if (n < 1 || n > sv::kUserWaveCount) return s;
    const std::string nm = sv::userWaveName(n - 1);
    return nm.empty() ? s + " NONE" : "U" + std::to_string(n) + " " + nm;
}

std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return userWaveLabel(cur);
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- SILVETON_ENGINES_PAGE_V1 / SILVETON_NEW_LOOK_V1: the ENGINE page
// LEFT: ENGINE PLACES - the 8 places like a small mixer (name, ON lamp, LEVEL slider). RIGHT: the chosen place - the title line with the tabs
// SOUND | EFFECTS and SAVE LIST, then the four panels of SILVETON SYNTH (picture engine_rack) or the effects of that place (picture engine_fx).
// Frame: the top bar and the bottom menu are drawn by the common code; this page uses y 98..650, x 20..1320.
namespace {
constexpr ColorInt kNote = Color::rgb(138, 147, 157);    // SILVETON_NEW_LOOK_V1: the grey of the small notes in the pictures
constexpr ColorInt kName = Color::rgb(207, 214, 222);    // the name of a filled place
constexpr ColorInt kWell = Color::rgb(11, 14, 18);       // the black groove of a slider
}

void SilvetonSamplerView::drawEnginesPage(Canvas& c) {
    // SILVETON_ENGINE_SLOTS_V2: the engines have a page of their own. LEFT: the 8 places. RIGHT: the chosen place.
    const int slot = std::clamp(engSlot_, 0, 7);
    if (engUpper_ >= 7) engUpper_ = -1;
    const bool onUpper = engUpper_ >= 0;   // SILVETON_SUSE_SAMPLE_V1: an Upper of the blend is edited here (SILVETON SYNTH on its recordings)
    const int u = onUpper ? engUpper_ : 7 + slot;

    // SILVETON_NEW_LOOK_V1 (picture engine_legacy): an Upper with an old-style engine (or none) has its own full page (UPPER chips + tabs)
    if (onUpper) {
        const int tUp = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
        // an Upper WITHOUT an engine does not go to the old page: it gets the ADD SILVETON SYNTH key right here (MIXER > ENGINE of an Upper)
        if (tUp != 0 && tUp != static_cast<int>(EngineType::Synth) && tUp != static_cast<int>(EngineType::Suse)) { drawEngineLegacy(c, u); return; }
    }

    neRack(c, slot, onUpper);

    // ---- right: the chosen place. SILVETON_MODEL_ONE_SCREEN_V1 (Цветомир, 03.11.2026): ONE screen - the head (MODEL), the knobs of the sound,
    // the FILTER, TONE · ENVELOPE and PLAYING. Nothing twice, no page for three knobs.
    const int tSel = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto typeSel = static_cast<EngineType>(tSel);
    if (typeSel == EngineType::Synth) { drawModelOneScreen(c, u); return; }
    // an empty place (or one of an old set): one key makes it a SILVETON SYNTH place
    const std::string where = onUpper ? "UPPER " + std::to_string(u + 1) + " · BLEND" : "PLACE " + std::to_string(slot + 1);
    neHead(c, where + " · " + (tSel == 0 ? std::string("EMPTY") : std::string("OLD ENGINE")), false);
    nlPanel(c, RectF(324.0F, 146.0F, 1320.0F, 650.0F), "SILVETON SYNTH");
    text(c, tSel == 0 ? (onUpper ? "THIS UPPER HAS NO ENGINE" : "THIS PLACE IS EMPTY") : "OLD ENGINE", 822.0F, 292.0F, 30.0F, NL_MUT, Opt().center().bold().spacing(0.1F).maxW(900.0F));
    const RectF ks(822.0F - 170.0F, 322.0F, 822.0F + 170.0F, 366.0F);
    nlBtn(c, ks, "ADD SILVETON SYNTH", NlBtn::Sel, 14.0F, true);   // SILVETON_SYNTH_V1
    hit(ks, [this, u](float, float) { setEngineP(u, 0, static_cast<float>(static_cast<int>(EngineType::Synth))); enginePage_ = 0; invalidate(); });
    text(c, "SILVETON SYNTH: the sound is calculated from what it learned, no recording.", 822.0F, 408.0F, 14.0F, kNote, Opt().center().maxW(900.0F));
    text(c, "Up to 8 places can play together - mix their level on the left. Then choose a MODEL.", 822.0F, 434.0F, 14.0F, kNote, Opt().center().maxW(900.0F));
}

// the rack of the eight places: name, ON lamp, LEVEL slider (tap = choose, lamp = ON / OFF, slider = LEVEL -60..+12 dB, it sticks to 0 dB)
void SilvetonSamplerView::neRack(Canvas& c, int slot, bool onUpper) {
    nlPanel(c, RectF(20.0F, 98.0F, 312.0F, 650.0F), "ENGINE PLACES");
    for (int i = 0; i < 8; ++i) {
        const int pu = 7 + i;
        const float y = 128.0F + static_cast<float>(i) * 64.0F;
        const RectF r(28.0F, y, 304.0F, y + 58.0F);
        const bool sel = !onUpper && i == slot;
        const int t = std::clamp(rndI(engineP(pu, 0)), 0, sv::kEngineTypeCount - 1);
        const std::optional<UpperState> st = upperStates[static_cast<std::size_t>(pu)];
        const bool live = t != 0 && st && st->enabled;
        const bool filled = t != 0 && st;
        // SILVETON_SYNTH_V1: a place is "empty" or SILVETON SYNTH with its model (an old engine of an old set is not named)
        const bool isSynthPlace = t != 0 && static_cast<EngineType>(t) == EngineType::Synth;
        const int mNo = isSynthPlace ? std::clamp(rndI(engineP(pu, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels) : 0;
        const std::string placeName = t == 0 ? std::string("empty")
            : (isSynthPlace ? (mNo > 0 ? "SYNTH · MODEL " + std::to_string(mNo) : std::string("SYNTH · no model")) : std::string("old engine"));
        nlBtn(c, r, "", sel ? NlBtn::Sel : NlBtn::Plain, 12.0F, false);
        text(c, "PLACE " + std::to_string(i + 1), 40.0F, y + 17.5F, 12.0F, sel ? Color::WHITE : NL_TXT2, Opt().bold().spacing(0.1F));
        text(c, placeName, 40.0F, y + 36.0F, 12.5F, sel ? Color::WHITE : (t == 0 ? NL_MUT : kName), Opt().maxW(190.0F));
        hit(r, [this, i](float, float) { engSlot_ = i; engUpper_ = -1; selectedUpper_ = 7 + i; enginePage_ = 0; invalidate(); });
        // the lamp = ON / OFF of the place
        if (live) fill(c, RectF(272.0F, y + 4.0F, 294.0F, y + 26.0F), 11.0F, Color::argb(60, 255, 163, 26));
        fill(c, RectF(276.0F, y + 8.0F, 290.0F, y + 22.0F), 7.0F, live ? NL_AMBER : Color::rgb(43, 48, 54));
        // the slider = LEVEL of the place (0 dB is the small mark)
        const float x0 = 40.0F, x1 = 272.0F, ty = y + 49.0F;
        const float tv = st ? std::clamp((st->levelDb + 60.0F) / 72.0F, 0.0F, 1.0F) : 60.0F / 72.0F;
        const float hx = x0 + (x1 - x0) * tv;
        if (filled) {
            text(c, (st->levelDb >= 0.0F ? "+" : "") + fmtFixed(static_cast<double>(st->levelDb), 1) + " dB", 270.0F, y + 17.0F, 11.5F, sel ? Color::rgb(207, 230, 255) : kNote, Opt().right().mono().maxW(80.0F));
        }
        fill(c, RectF(x0, ty - 3.0F, x1, ty + 3.0F), 3.0F, kWell);
        fill(c, RectF(x0, ty - 3.0F, hx, ty + 3.0F), 3.0F, filled ? NL_BLUE : Color::rgb(58, 64, 72));
        fill(c, RectF(x0 + (x1 - x0) * (60.0F / 72.0F) - 1.0F, ty - 9.0F, x0 + (x1 - x0) * (60.0F / 72.0F) + 1.0F, ty - 6.0F), 0.0F, Color::argb(110, 255, 255, 255));
        shadow(c, RectF(hx - 6.0F, ty - 7.0F, hx + 6.0F, ty + 7.0F), 3.0F, 2.0F, 90);
        fillV(c, RectF(hx - 6.0F, ty - 7.0F, hx + 6.0F, ty + 7.0F), 3.0F, Color::rgb(227, 230, 234), Color::rgb(154, 161, 169));
        if (!filled) continue;
        hit(RectF(258.0F, y + 2.0F, 304.0F, y + 34.0F), [this, pu](float, float) {
            const auto& cur = upperStates[static_cast<std::size_t>(pu)];
            if (!cur) return;
            UpperState n = *cur; n.enabled = !n.enabled; if (n.enabled) n.mute = false;
            commitMain(pu, n); invalidate();
        });
        const auto setLevel = [this, pu, x0, x1](float x, float) {
            const auto& cur = upperStates[static_cast<std::size_t>(pu)];
            if (!cur) return;
            const float v = std::clamp(-60.0F + (x - x0) / std::max(1.0F, x1 - x0) * 72.0F, -60.0F, 12.0F);
            UpperState n = *cur; n.levelDb = std::nearbyint(v * 2.0F) * 0.5F;
            if (std::fabs(n.levelDb) < 0.75F) n.levelDb = 0.0F;   // it sticks to 0 dB
            commitMain(pu, n);
        };
        hit(RectF(x0 - 10.0F, ty - 15.0F, x1 + 10.0F, ty + 9.0F), setLevel,
            [this, pu] { const auto& cur = upperStates[static_cast<std::size_t>(pu)]; if (!cur) return; UpperState n = *cur; n.levelDb = 0.0F; commitMain(pu, n); },
            [setLevel](float x, float y2, bool) { setLevel(x, y2); });
    }
}

// the title line (LCD): the place and its engine; then the tabs SOUND | EFFECTS (SILVETON_PLACE_FX_V1) and SAVE LIST
// (= STORE of the top bar: choose a LIST position, the blend with the SILVETON SYNTH places is written there)
void SilvetonSamplerView::neHead(Canvas& c, const std::string& title, bool tabs) {
    nlLcd(c, RectF(324.0F, 98.0F, 824.0F, 138.0F));
    // a tap on the title line goes between the PLACES (SILVETON SYNTH) and the old-style engines of the Uppers (page engine_legacy)
    hit(RectF(324.0F, 98.0F, 824.0F, 138.0F), [this](float, float) {
        if (engUpper_ >= 0) engUpper_ = -1;
        else { engUpper_ = std::clamp(savedUpper_, 0, 6); selectedUpper_ = engUpper_; }
        enginePage_ = 100;
        invalidate();
    });
    text(c, title, 338.0F, 124.0F, 15.0F, Color::WHITE, Opt().bold().spacing(0.06F).maxW(300.0F));
    // SILVETON_NO_DOUBLE_CPU_V1 (Цветомир, 04.11.2026): CPU and VOICES are only in the display of the top bar - not twice
    if (tabs) {
        const RectF tSound(832.0F, 98.0F, 982.0F, 138.0F), tFx(988.0F, 98.0F, 1138.0F, 138.0F);
        nlBtn(c, tSound, "SOUND", placeTab_ == 0 ? NlBtn::Sel : NlBtn::Off, 13.0F, true);
        nlBtn(c, tFx, "EFFECTS", placeTab_ == 1 ? NlBtn::Sel : NlBtn::Off, 13.0F, true);
        hit(tSound, [this](float, float) { placeTab_ = 0; invalidate(); });
        hit(tFx, [this](float, float) { placeTab_ = 1; invalidate(); });
    }
    const RectF tSave(1170.0F, 98.0F, 1320.0F, 138.0F);
    nlBtn(c, tSave, "SAVE LIST", NlBtn::On, 13.0F, true);
    hit(tSave, [this](float, float) { openStore(); });
}

// a knob like in the engine pictures. Touch: drag = turn, tap (knob or value) = exact number, double tap = the starting value.
void SilvetonSamplerView::neKnob(Canvas& c, float cx, float cy, float d, float value, float minV, float maxV, float step, float travel, bool bipolar,
                                 const std::string& valueText, const std::string& label, float vw,
                                 std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset) {
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    nlKnob(c, cx, cy, d * 0.35F, t, bipolar, false, true);
    if (!label.empty()) text(c, label, cx, cy - d / 2.0F - 4.5F, 11.0F, NL_TXT2, Opt().center().bold().spacing(0.13F).maxW(vw + 14.0F));
    const float fs = d >= 80.0F ? 13.0F : 12.0F;
    const RectF vr(cx - vw / 2.0F, cy + d / 2.0F - 2.0F, cx + vw / 2.0F, cy + d / 2.0F + fs + 8.0F);
    nlValue(c, vr, valueText, fs);
    const float hw = std::max(vw, d) + 4.0F;
    knobHit(RectF(cx - hw / 2.0F, cy - d / 2.0F - 16.0F, cx + hw / 2.0F, vr.top), value, minV, maxV, step, travel, std::move(onChange), exact, reset);
    hit(RectF(cx - hw / 2.0F, vr.top, cx + hw / 2.0F, vr.bottom + 4.0F), [exact](float, float) { exact(); }, reset);
}

// a thin horizontal slider: black groove, blue part from01..to01, silver cap at cap01 (the picture TUNE slider; the touch is added by the caller)
void SilvetonSamplerView::neSlider(Canvas& c, float x, float y, float w, float from01, float to01, float cap01) {
    const RectF g(x, y + 12.0F, x + w, y + 22.0F);
    fill(c, g, 5.0F, kWell);
    strokeRR(c, g, 5.0F, Color::rgb(3, 4, 5), 1.0F);
    if (to01 - from01 > 0.001F) fillV(c, RectF(x + w * from01, g.top, x + w * to01, g.bottom), 5.0F, Color::rgb(82, 180, 255), Color::rgb(23, 102, 201));
    nlFaderCap(c, x + w * cap01, y + 17.0F, 28.0F, 34.0F);
}

// ---------------------------------------------------------------- SILVETON_MODEL_ONE_SCREEN_V2 (Цветомир, 03.11.2026, спецификация):
// ALL settings of a SILVETON SYNTH place on ONE screen, like a professional synthesizer. No pages, nothing twice, nothing hidden.
//   TITLE LINE: PLACE n · SILVETON SYNTH, CPU / VOICES, the tabs SOUND | EFFECTS, SAVE LIST
//   PANEL A:   MODEL · CHARACTER OF THE SOUND - MODEL ▼ (the learned models), RESET KNOBS, BRIGHT HARMONICS SHAPE SCOOP UNISON LIFE VIBRATO
//   PANEL B:   FILTER - type, CUTOFF, RESONANCE, KEY TRACK, DRIVE, VEL→CUTOFF, ENV AMOUNT, F.ADSR, LFO→CUTOFF
//   PANEL C:   TONE · ENVELOPE - OCTAVE, TRANSPOSE; TUNE (the slider -12 .. +12 st = the sampler's own TUNE, the TRANSPOSE that keeps
//              the notes on their keys is added by the sampler itself; no FINE knob); ATTACK DECAY SUSTAIN RELEASE
//   PANEL D:   PLAYING - POLY / MONO / LEGATO; portamento SILVETON / KRONOS / BASS, ON / OFF, FINGERED, TIME / RATE; PORTA TIME; PITCH BEND
// Every control drives its real parameter (the same host calls as before: setEngineP -> the engine row, commitTune / commitMain /
// setTone / setUParam -> the part), everything is saved with the blend / the SET as before.
void SilvetonSamplerView::drawModelOneScreen(Canvas& c, int u) {
    const std::string where = u >= 7 ? "PLACE " + std::to_string(u - 6) : "UPPER " + std::to_string(u + 1);
    const std::optional<UpperState>& stOpt = upperStates[static_cast<std::size_t>(u)];
    const std::vector<float> p = uParams(u);

    // ================= TITLE LINE: SOUND | EFFECTS (SILVETON_PLACE_FX_V1) and SAVE LIST
    neHead(c, where + " · SILVETON SYNTH", true);
    if (placeTab_ == 1) { drawPlaceFxNew(c, u); return; }   // the effects of this place

    // ================= PANEL A: MODEL · CHARACTER OF THE SOUND
    const RectF pA(324.0F, 146.0F, 820.0F, 390.0F), pB(824.0F, 146.0F, 1320.0F, 390.0F);
    const RectF pC(324.0F, 398.0F, 820.0F, 648.0F), pD(824.0F, 398.0F, 1320.0F, 648.0F);
    nlPanel(c, pA, "MODEL · CHARACTER OF THE SOUND");
    const std::vector<std::string> models = sampler.learnedModelNames();
    const int mSel = std::clamp(rndI(engineP(u, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels);
    if (mSel <= 0) text(c, "choose a MODEL above", pA.right - 14.0F, pA.top + 20.0F, 11.0F, NL_AMBER, Opt().right().bold().maxW(200.0F));
    {
        const RectF rm(338.0F, 176.0F, 658.0F, 216.0F), rr(668.0F, 176.0F, 806.0F, 216.0F);
        std::string mText;
        if (models.empty()) mText = "MODEL: none";
        else if (mSel <= 0) mText = "MODEL ▼  choose (" + std::to_string(models.size()) + ")";
        else mText = "MODEL ▼  " + std::to_string(mSel) + " · " + (mSel <= static_cast<int>(models.size()) ? models[static_cast<std::size_t>(mSel - 1)] : std::string("missing"));
        nlBtn(c, rm, mText, NlBtn::Plain, 13.0F, true);
        hit(rm, [this, u, models](float, float) {
            if (models.empty()) { showMessage("NO MODELS", "The models are built into the sampler.\n" + sampler.learnedModelsNote()); return; }
            std::vector<std::pair<std::string, std::string>> items;
            for (std::size_t i = 0; i < models.size(); ++i) items.emplace_back(std::to_string(i + 1), models[i]);
            const int cur = std::clamp(rndI(engineP(u, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels) - 1;
            showGridPicker("MODEL  ·  try the models one after another, DONE closes", items, cur, std::string("NONE"), [this, u](int k) {
                setEngineP(u, sv::model::MO_MODEL + 1, static_cast<float>(k + 1));   // -1 (NONE) -> 0
                invalidate();
            });
            if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open: try the models one after another, ГОТОВО closes
            if (!dialogStack.empty()) {   // SILVETON_MODEL_RENAME_V1: RENAME works on the model that is chosen (blue) in the list
                const std::shared_ptr<Dialog> grid = dialogStack.back();
                const std::weak_ptr<Dialog> weak = grid;
                grid->gridAction = "RENAME";
                grid->onAction = [this, weak](int k) {
                    if (k < 0) { flash("choose a model first, then RENAME"); return; }
                    showTextPage("NAME OF MODEL " + std::to_string(k + 1), sampler.learnedModelEditName(k), [this, weak, k](const std::string& v) {
                        sampler.renameLearnedModel(k, v);
                        if (const auto g = weak.lock()) {
                            const std::vector<std::string> now = sampler.learnedModelNames();
                            if (k < static_cast<int>(now.size()) && k < static_cast<int>(g->gridItems.size())) g->gridItems[static_cast<std::size_t>(k)].second = now[static_cast<std::size_t>(k)];
                        }
                        invalidate();
                    });
                };
            }
        });
        nlBtn(c, rr, "RESET KNOBS", NlBtn::Plain, 12.0F, false);
        hit(rr, [this, u](float, float) {
            showConfirm("INITIAL KNOBS", "All the engine knobs of this place go back to the initial values (the model stays).", "YES, RESET", [this, u]() {
                std::vector<float> row(eParams(u));
                if (row.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) return;
                const float keepModel = row[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U];
                sv::synth::setDefaults(row.data() + 1);
                row[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U] = keepModel;
                std::vector<float> values(row.begin() + 1, row.begin() + 1 + sv::kEngineParamCountLegacy);
                sampler.setUpperEngineBlock(u, 1, values);
                engineParamsCache[static_cast<std::size_t>(u)].reset();
                invalidate();
            });
        });
    }
    {   // the character of the sound (the learned parts, 100 % = as the model learned it): one row of knobs
        const EngineParamPage pg = sv::synth::page(0);
        std::vector<const EngineParamDef*> items;
        for (int i = 0; i < pg.count; ++i) {
            const int id = pg.items[i].id;
            if (id == sv::model::MO_MODEL || id == sv::model::MO_AMOUNT || id == sv::model::MO_TUNE) continue;
            items.push_back(&pg.items[i]);
        }
        const float n = static_cast<float>(items.size());
        const float pitch = n <= 7.0F ? 68.0F : 476.0F / n;
        for (std::size_t i = 0; i < items.size(); ++i) {
            const float cx = 570.0F + (static_cast<float>(i) - (n - 1.0F) / 2.0F) * pitch;
            neEngineKnob(c, cx, 300.0F, 50.0F, 62.0F, u, *items[i]);
        }
    }
    text(c, "the model is chosen from a list · the knobs change how it sounds", 338.0F, 369.5F, 11.5F, kNote, Opt().maxW(470.0F));

    // ================= PANEL B: FILTER
    nlPanel(c, pB, "FILTER");
    {
        const EngineParamPage pg = sv::synth::page(1);
        const auto find = [&pg](int id) -> const EngineParamDef* {
            for (int i = 0; i < pg.count; ++i) if (pg.items[i].id == id) return &pg.items[i];
            return nullptr;
        };
        if (const EngineParamDef* ft = find(sv::E_FILT_TYPE)) {   // the type: tap = the next one, double tap = the starting one
            const RectF kr(838.0F, 176.0F, 978.0F, 212.0F);
            const float v = engineP(u, ft->id + 1);
            const int cur = rndI(v) - rndI(ft->lo), n = choiceCount(*ft);
            const int id = ft->id + 1;
            const EngineParamDef d = *ft;
            nlBtn(c, kr, engineValueText(d, v), cur != 0 ? NlBtn::On : NlBtn::Off, 12.0F, true);
            hit(kr, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
            text(c, "tap = next type", 990.0F, 197.0F, 11.5F, kNote);
        }
        static const int kRow1[5] = {sv::E_CUTOFF, sv::E_RESO, sv::E_KEYTRACK, sv::E_DRIVE, sv::E_VEL_CUT};
        static const int kRow2[6] = {sv::E_FEG_AMT, sv::E_FEG_A, sv::E_FEG_D, sv::E_FEG_S, sv::E_FEG_R, sv::E_LFO_CUT};
        const auto shortName = [](const EngineParamDef& d) -> const char* {
            if (d.id == sv::E_FEG_AMT) return "ENV AMT";
            if (d.id == sv::E_LFO_CUT) return "LFO→CUT";
            return nullptr;
        };
        for (int k = 0; k < 5; ++k)
            if (const EngineParamDef* d = find(kRow1[k])) neEngineKnob(c, 868.0F + 84.0F * static_cast<float>(k), 258.0F, 44.0F, 74.0F, u, *d, shortName(*d));
        for (int k = 0; k < 6; ++k)
            if (const EngineParamDef* d = find(kRow2[k])) neEngineKnob(c, 870.0F + 78.0F * static_cast<float>(k), 346.0F, 44.0F, 70.0F, u, *d, shortName(*d));
    }

    // ================= PANEL C: TONE · ENVELOPE
    nlPanel(c, pC, "TONE · ENVELOPE");
    if (stOpt) {
        const UpperState st = *stOpt;
        // the same stepper as the Upper's TUNE page (title, number, − / +, both together = 0)
        const auto stepAt = [&](float x, const char* title, const std::string& value, std::function<void()> onMinus, std::function<void()> onPlus, std::function<void()> onReset) {
            nlLabel(c, title, x, 438.5F, false, NL_TXT2, 11.0F);
            const RectF minus(x, 442.0F, x + 44.0F, 480.0F), box(x + 50.0F, 442.0F, x + 112.0F, 480.0F), plus(x + 118.0F, 442.0F, x + 162.0F, 480.0F);
            nlBtn(c, minus, "−", NlBtn::Plain, 18.0F, false);
            nlValue(c, box, value, 15.0F);
            nlBtn(c, plus, "+", NlBtn::Plain, 18.0F, false);
            hit(box, [](float, float) {}, onReset);   // double tap on the number = 0
            hit(minus, [this, onMinus](float, float) { onMinus(); invalidate(); });
            hit(plus, [this, onPlus](float, float) { onPlus(); invalidate(); });
            pairHits.push_back(PairHit{minus, plus, [this, onReset] { onReset(); invalidate(); }});
        };
        stepAt(338.0F, "OCTAVE", signed_(st.octave),
               [this, st] { UpperState cur = currentUpper(st); cur.octave = std::max(cur.octave - 1, -4); commitTune(cur); },
               [this, st] { UpperState cur = currentUpper(st); cur.octave = std::min(cur.octave + 1, 4); commitTune(cur); },
               [this, st] { UpperState cur = currentUpper(st); cur.octave = 0; commitTune(cur); });
        stepAt(520.0F, "TRANSPOSE", signed_(st.transpose),
               [this, st] { UpperState cur = currentUpper(st); cur.transpose = std::max(cur.transpose - 1, -12); commitTune(cur); },
               [this, st] { UpperState cur = currentUpper(st); cur.transpose = std::min(cur.transpose + 1, 12); commitTune(cur); },
               [this, st] { UpperState cur = currentUpper(st); cur.transpose = 0; commitTune(cur); });
        // SILVETON_SYNTH_TUNE_V1 (Цветомир, 03.11.2026 18:26): the FINE knob is gone. The slider below is the TUNE of the sampler itself
        // (-12 .. +12 semitones = -1200 .. +1200 ct, 0 in the middle): TUNE -500 ct = the slider at -5. The sampler adds the TRANSPOSE that
        // puts the notes back on their keys by itself (SamplerEngine.cpp synthTuneKeys) - the TRANSPOSE above is never touched. The timbre
        // moves (the zone of the key that sounds), the pitch never does.
        {
            const int tune = std::clamp(static_cast<int>(std::lround(st.fineCents / 100.0F)), -12, 12);
            const float sx0 = 338.0F, sx1 = 668.0F;
            nlLabel(c, "TUNE · the timbre moves, the pitch stays", 338.0F, 500.5F, false, NL_TXT2, 11.0F);
            const float frac = (static_cast<float>(tune) + 12.0F) / 24.0F;
            neSlider(c, sx0, 506.0F, sx1 - sx0, std::min(0.5F, frac), std::max(0.5F, frac), frac);
            const RectF valR(690.0F, 506.0F, 802.0F, 540.0F);
            nlValue(c, valR, (tune > 0 ? "+" : "") + std::to_string(tune) + " st", 13.0F);
            const auto setTune = [this, st](int v) { UpperState n = currentUpper(st); n.fineCents = static_cast<float>(std::clamp(v, -12, 12)) * 100.0F; commitTune(n); };
            const auto setAt = [setTune, sx0, sx1](float x, float) {
                setTune(static_cast<int>(std::lround((x - sx0) / std::max(1.0F, sx1 - sx0) * 24.0F - 12.0F)));
            };
            hit(RectF(sx0 - 20.0F, 498.0F, sx1 + 20.0F, 548.0F), setAt, [setTune] { setTune(0); }, [setAt](float x, float y, bool) { setAt(x, y); });
            hit(valR, [this, tune, setTune](float, float) { showNumber("TUNE (semitones, 1 = 100 ct; the pitch stays)", static_cast<float>(tune), -12.0F, 12.0F, 0, [setTune](float x) { setTune(rndI(x)); }); });
        }
        // ATTACK DECAY SUSTAIN RELEASE: the same knobs as the Upper's TONE page in SOUND EDIT (the fine logarithmic knobs; double tap = the recording's own envelope)
        {
            const char* names[4] = {"ATTACK", "DECAY", "SUSTAIN", "RELEASE"};
            for (int k = 0; k < 4; ++k) {
                const TonePar par = static_cast<TonePar>(k);
                const float v = toneValue(st, par);
                const ToneRange range = toneRange(par);
                const bool pct = k == 2;
                const std::string nm = names[k];
                neKnob(c, 380.0F + 118.0F * static_cast<float>(k), 600.0F, 40.0F, toneToNorm(par, v), 0.0F, 1.0F, 0.002F, 260.0F, false, toneText(par, v), nm, 84.0F,
                       [this, par](float nv) { setTone(par, toneFromNorm(par, nv)); },
                       [this, par, nm, pct, v, range] {
                           showNumber(nm, pct ? v * 100.0F : v, range.lo, range.hi, range.decimals, [this, par, pct](float nv) { setTone(par, pct ? nv / 100.0F : nv); }, true, [this, par, v] { setTone(par, v); });
                       },
                       [this, par] { setTone(par, -1.0F); });
            }
        }
    }

    // ================= PANEL D: PLAYING
    nlPanel(c, pD, "PLAYING");
    if (stOpt) {
        const UpperState st = *stOpt;
        for (int k = 0; k < 3; ++k) {
            const RectF mr(838.0F + 108.0F * static_cast<float>(k), 428.0F, 940.0F + 108.0F * static_cast<float>(k), 466.0F);
            nlBtn(c, mr, k == 0 ? "POLY" : (k == 1 ? "MONO" : "LEGATO"), st.voiceMode == k ? NlBtn::On : NlBtn::Off, 12.0F, true);
            hit(mr, [this, st, k](float, float) { UpperState cur = currentUpper(st); cur.voiceMode = k; commitMain(selectedUpper_, cur); invalidate(); });
        }
        nlLabel(c, "PORTAMENTO", 838.0F, 484.5F, false, NL_TXT2, 11.0F);
        const int mode = std::clamp(rndI(getOr(p, 42, 0.0F)), 0, 3);   // 0 SILVETON, 1 KRONOS, 3 BASS
        const char* names[3] = {"SILVETON", "KRONOS", "BASS"};
        const int modeOf[3] = {0, 1, 3};
        for (int k = 0; k < 3; ++k) {
            const RectF mr(838.0F + 108.0F * static_cast<float>(k), 492.0F, 940.0F + 108.0F * static_cast<float>(k), 528.0F);
            nlBtn(c, mr, names[k], mode == modeOf[k] ? NlBtn::On : NlBtn::Off, 11.5F, true);
            const int m = modeOf[k];
            hit(mr, [this, u, m](float, float) { setUParam(u, 42, static_cast<float>(m)); });
        }
        const bool silveton = mode == 0 || mode == 2;
        const float kronosTime = getOr(p, 45, 40.0F);
        const bool portaOn = silveton ? st.portamentoSec > 0.0F : kronosTime > 0.0F;
        // ON / OFF: OFF = TIME 0 (as the engine knows it), ON = the time it had before (or a usual one)
        {
            const RectF r(1166.0F, 428.0F, 1308.0F, 466.0F);
            nlBtn(c, r, portaOn ? "PORTA ON" : "PORTA OFF", portaOn ? NlBtn::On : NlBtn::Off, 12.0F, true);
            float& last = lastPorta_[static_cast<std::size_t>(std::clamp(u, 0, 15))];
            if (portaOn) last = silveton ? portamentoUiValue(st.portamentoSec) : kronosTime;
            const float restore = last > 0.0F ? last : (silveton ? 20.0F : 40.0F);
            hit(r, [this, u, st, silveton, portaOn, restore](float, float) {
                if (silveton) { UpperState n = currentUpper(st); n.portamentoSec = portaOn ? 0.0F : portamentoSecondsFromUi(restore); commitTune(n); }
                else setUParam(u, 45, portaOn ? 0.0F : restore);
            });
        }
        {   // FINGERED, TIME / RATE: the KRONOS / BASS way (dimmed under SILVETON, which has none of them)
            const bool fing = getOr(p, 43, 0.0F) >= 0.5F, rate = getOr(p, 44, 0.0F) >= 0.5F;
            const RectF fr(1166.0F, 492.0F, 1308.0F, 528.0F);
            const RectF rA(838.0F, 540.0F, 940.0F, 576.0F), rB(946.0F, 540.0F, 1048.0F, 576.0F);
            nlBtn(c, fr, "FINGERED", fing && !silveton ? NlBtn::On : NlBtn::Off, 12.0F, true);
            if (!silveton) {   // SILVETON_PORTA_ALL_V1: under SILVETON TIME / RATE do not exist - the place is used for its three knobs
                nlBtn(c, rA, "TIME", !rate && !silveton ? NlBtn::On : NlBtn::Off, 12.0F, true);
                nlBtn(c, rB, "RATE", rate && !silveton ? NlBtn::On : NlBtn::Off, 12.0F, true);
            }
            if (!silveton) {
                hit(fr, [this, u, fing](float, float) { setUParam(u, 43, fing ? 0.0F : 1.0F); });
                hit(rA, [this, u](float, float) { setUParam(u, 44, 0.0F); });
                hit(rB, [this, u](float, float) { setUParam(u, 44, 1.0F); });
            } else {
                fill(c, fr, 8.0F, Color::argb(110, 0, 0, 0));
            }
        }
        // the knobs: PORTA TIME, PITCH BEND
        if (silveton) {
            const float porta = portamentoUiValue(st.portamentoSec);
            auto setPorta = [this, st](float v) { UpperState n = currentUpper(st); n.portamentoSec = portamentoSecondsFromUi(v); commitTune(n); };
            neKnob(c, 880.0F, 604.0F, 40.0F, porta, 0.0F, 100.0F, 1.0F, 300.0F, false, porta <= 0.0F ? std::string("OFF") : fmtFixed(static_cast<double>(porta), 2) + " ms", "PORTA TIME", 84.0F, setPorta,
                   [this, porta, setPorta] { showNumber("PORTAMENTO TIME ms (0 = OFF)", porta, 0.0F, 100.0F, 0, setPorta); },
                   [this, st] { UpperState n = currentUpper(st); n.portamentoSec = 0.0F; commitTune(n); });
            // SILVETON_PORTA_ALL_V1: the other two settings of the SILVETON portamento (the same two numbers as in SOUND EDIT: for the whole sampler)
            const float bal = static_cast<float>(sampler.portaBalance());
            neKnob(c, 1000.0F, 604.0F, 40.0F, bal, 3.0F, 40.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bal)), "BALANCE", 84.0F,
                   [this](float nv) { sampler.setPortaBalance(rndI(nv)); },
                   [this, bal] { showNumber("PORTA BALANCE (softness)", bal, 3.0F, 40.0F, 0, [this](float x) { sampler.setPortaBalance(rndI(x)); }); },
                   [this] { sampler.setPortaBalance(11); });
            const float nearV = static_cast<float>(sampler.portaNear());
            neKnob(c, 1120.0F, 604.0F, 40.0F, nearV, 0.0F, 400.0F, 1.0F, 300.0F, false, fmtFixed(static_cast<double>(nearV), 2) + " ms", "NEAR-NOTE", 84.0F,
                   [this](float nv) { sampler.setPortaNear(rndI(nv)); },
                   [this, nearV] { showNumber("NEAR-NOTE TIME ms", nearV, 0.0F, 400.0F, 0, [this](float x) { sampler.setPortaNear(rndI(x)); }); },
                   [this] { sampler.setPortaNear(90); });
        } else {
            neKnob(c, 1110.0F, 604.0F, 40.0F, kronosTime, 0.0F, 127.0F, 1.0F, 300.0F, false, kronosTime <= 0.0F ? std::string("OFF") : std::to_string(static_cast<int>(kronosTime)), mode == 1 ? "PORTA TIME 0–127" : "BASS TIME 0–127", 84.0F,
                   [this, u](float nv) { setUParam(u, 45, static_cast<float>(rndI(nv))); },
                   [this, u, kronosTime] { showNumber("PORTA TIME (0 = OFF)", kronosTime, 0.0F, 127.0F, 0, [this, u](float x) { setUParam(u, 45, static_cast<float>(rndI(x))); }); },
                   [this, u] { setUParam(u, 45, 0.0F); });
        }
        {
            const float bend = getOr(p, 48, 2.0F);
            neKnob(c, 1240.0F, 604.0F, 40.0F, bend, 0.0F, 24.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bend)) + " st", "PITCH BEND", 84.0F,
                   [this, u](float nv) { setUParam(u, 48, static_cast<float>(rndI(nv))); },
                   [this, u, bend] { showNumber("PITCH BEND RANGE (semitones)", bend, 0.0F, 24.0F, 0, [this, u](float x) { setUParam(u, 48, static_cast<float>(rndI(x))); }); },
                   [this, u] { setUParam(u, 48, 2.0F); });
        }
        if (silveton) {
            text(c, "SILVETON: soft entry, the note arrives exactly at TIME", 838.0F, 550.0F, 11.0F, kNote, Opt().maxW(470.0F));
            text(c, "BALANCE: the softness · NEAR-NOTE: time for close notes", 838.0F, 566.0F, 11.0F, kNote, Opt().maxW(470.0F));
        } else {
            text(c, "TIME: same time for any interval", 838.0F, 598.5F, 11.0F, kNote, Opt().maxW(260.0F));
            text(c, "RATE: time for one octave", 838.0F, 616.5F, 11.0F, kNote, Opt().maxW(260.0F));
            text(c, mode == 1 ? "KRONOS: tight glide" : "BASS: the slide goes on with the recording", 838.0F, 634.5F, 11.0F, kNote, Opt().maxW(260.0F));
        }
    }
}

// ---------------------------------------------------------------- SILVETON_NEW_LOOK_V1: the page of an old-style engine of an Upper (picture engine_legacy)
// The row of the 7 Uppers (tap = that Upper), under it the tabs ENGINE and the pages of the engine of the chosen Upper, the title line.
// FILTER is drawn like the picture (FILTER 1 · FILTER ENVELOPE · FILTER 2); every other page keeps its keys and knobs in one panel.
namespace {
std::string legacyPageName(const std::string& bg) {
    if (bg == "ЗВУК") return "SOUND";   // the names of the pages come from the engine tables in Bulgarian
    if (bg == "ФИЛТЪР") return "FILTER";
    if (bg == "МОД") return "MOD";
    if (bg == "ОСЦ") return "OSC";
    if (bg == "ОПЕРАТОРИ") return "OPERATORS";
    if (bg == "КОЛЕЛА") return "WHEELS";
    if (bg == "ЛЪК") return "BOW";
    if (bg == "ДЪХ") return "BREATH";
    return bg;
}
}

// a choice key without a name under it (tap = next, double tap = the starting value; many names: a window with all of them)
void SilvetonSamplerView::neEngineKey(Canvas& c, const RectF& r, int u, const ::silveton::sampler::EngineParamDef& dIn, float size) {
    EngineParamDef d = dIn;
    const int id = d.id + 1;
    const float v = engineP(u, id);
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    nlBtn(c, r, engineValueText(d, v), on ? NlBtn::On : NlBtn::Off, size, true);
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
        return;
    }
    const int n = choiceCount(d);
    const int cur = rndI(v) - rndI(d.lo);
    hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
        [this, u, id, d] { setEngineP(u, id, d.def); });
}

void SilvetonSamplerView::drawEngineLegacy(Canvas& c, int u) {
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the BREATH page
    const bool hasEngine = type != EngineType::Off;
    const int pageCount = hasEngine ? std::max(1, sv::enginePageCount(type)) : 0;
    // ---- the row of the 7 Uppers
    for (int i = 0; i < 7; ++i) {
        const RectF r(20.0F + 187.0F * static_cast<float>(i), 98.0F, 198.0F + 187.0F * static_cast<float>(i), 150.0F);
        const bool sel = i == u;
        const std::optional<UpperState> st = upperStates[static_cast<std::size_t>(i)];
        nlBtn(c, r, "", sel ? NlBtn::Sel : NlBtn::Plain, 13.0F, true);
        text(c, i == 6 ? std::string("LOWER") : "UPPER " + std::to_string(i + 1), r.centerX(), r.top + 22.0F, 13.0F, sel ? Color::WHITE : NL_TXT2, Opt().center().bold().spacing(0.12F));
        text(c, st ? st->soundName : std::string(), r.centerX(), r.top + 38.5F, 11.5F, sel ? Color::WHITE : kName, Opt().center().maxW(r.width() - 14.0F));
        hit(r, [this, i](float, float) { engUpper_ = i; selectedUpper_ = i; invalidate(); });
    }
    // ---- the tabs: ENGINE, then the pages of the engine (the engine's own order)
    if (enginePage_ != 100 && (enginePage_ < 0 || enginePage_ >= pageCount)) enginePage_ = hasEngine ? 0 : 100;
    if (!hasEngine) enginePage_ = 100;
    int tabNo = 0;
    const auto addTab = [&](int id, const std::string& name) {
        const RectF r(20.0F + 146.0F * static_cast<float>(tabNo), 160.0F, 158.0F + 146.0F * static_cast<float>(tabNo), 200.0F);
        ++tabNo;
        nlBtn(c, r, name, enginePage_ == id ? NlBtn::Sel : NlBtn::Off, 13.0F, true);
        hit(r, [this, id](float, float) { enginePage_ = id; invalidate(); });
    };
    addTab(100, "ENGINE");
    for (int k = 0; k < pageCount; ++k) addTab(k, legacyPageName(sv::enginePageName(type, k, variant)));
    // ---- the title line (a tap = back to the PLACES)
    const RectF title(1052.0F, 160.0F, 1320.0F, 200.0F);
    nlLcd(c, title);
    text(c, (u == 6 ? std::string("LOWER") : "UPPER " + std::to_string(u + 1)) + " · " + (hasEngine ? std::string(sv::engineName(type)) : std::string("NO ENGINE")), title.left + 14.0F, 186.0F, 15.0F, Color::WHITE, Opt().bold().spacing(0.04F).maxW(170.0F));
    text(c, "tap = PLACES", title.right - 10.0F, 185.0F, 10.0F, kNote, Opt().right().maxW(80.0F));
    hit(title, [this](float, float) { engUpper_ = -1; enginePage_ = 0; invalidate(); });

    // ---- the page
    const RectF area(20.0F, 212.0F, 1320.0F, 650.0F);
    if (enginePage_ == 100) {   // ENGINE: what runs on this Upper, ON / OFF (E_BYPASS keeps every setting), the way back to the places
        nlPanel(c, area, "ENGINE");
        text(c, hasEngine ? std::string(sv::engineName(type)) : std::string("NO ENGINE · PLAIN SAMPLE"), 40.0F, 290.0F, 28.0F, hasEngine ? NL_VALUE : NL_MUT, Opt().bold().spacing(0.06F).maxW(900.0F));
        if (hasEngine) {
            text(c, sv::engineLine(type), 40.0F, 322.0F, 14.0F, NL_TXT2, Opt().maxW(1200.0F));
            const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
            const RectF rOn(40.0F, 360.0F, 270.0F, 412.0F), rOff(282.0F, 360.0F, 512.0F, 412.0F);
            nlBtn(c, rOn, "ENGINE ON", bypassed ? NlBtn::Off : NlBtn::On, 14.0F, true);
            nlBtn(c, rOff, "ENGINE OFF", bypassed ? NlBtn::On : NlBtn::Off, 14.0F, true);
            hit(rOn, [this, u](float, float) { setEngineP(u, sv::E_BYPASS + 1, 0.0F); });
            hit(rOff, [this, u](float, float) { setEngineP(u, sv::E_BYPASS + 1, 1.0F); });
            text(c, "ENGINE OFF plays the plain recording and keeps every setting (to hear the difference).", 40.0F, 438.0F, 12.0F, kNote, Opt().maxW(1200.0F));
        } else {
            text(c, "This Upper plays the plain recording. SILVETON SYNTH is put on a place of ENGINE PLACES.", 40.0F, 322.0F, 14.0F, NL_TXT2, Opt().maxW(1200.0F));
        }
        const RectF rBack(40.0F, 580.0F, 270.0F, 626.0F);
        nlBtn(c, rBack, "ENGINE PLACES", NlBtn::Plain, 13.0F, true);
        hit(rBack, [this](float, float) { engUpper_ = -1; enginePage_ = 0; invalidate(); });
        return;
    }
    const EngineParamPage pg = sv::enginePage(type, enginePage_, variant);
    if (pg.count <= 0 || pg.items == nullptr) { nlPanel(c, area, ""); return; }
    if (enginePage_ == 1) {   // FILTER: FILTER 1 · FILTER ENVELOPE · FILTER 2 (the picture)
        const auto find = [&pg](int id) -> const EngineParamDef* {
            for (int i = 0; i < pg.count; ++i) if (pg.items[i].id == id) return &pg.items[i];
            return nullptr;
        };
        nlPanel(c, RectF(20.0F, 212.0F, 660.0F, 422.0F), "FILTER 1");
        nlPanel(c, RectF(680.0F, 212.0F, 1320.0F, 422.0F), "FILTER ENVELOPE");
        nlPanel(c, RectF(20.0F, 436.0F, 1320.0F, 624.0F), "FILTER 2");
        if (const EngineParamDef* ft = find(sv::E_FILT_TYPE)) {
            neEngineKey(c, RectF(34.0F, 241.0F, 192.0F, 277.0F), u, *ft, 13.0F);
            text(c, "tap = next · OFF · LP24 · 35 · LP12 · HP12 · BP12", 206.0F, 263.0F, 11.5F, kNote, Opt().maxW(440.0F));
        }
        static const int kF1[5] = {sv::E_CUTOFF, sv::E_RESO, sv::E_KEYTRACK, sv::E_DRIVE, sv::E_VEL_CUT};
        static const int kEnv[5] = {sv::E_FEG_AMT, sv::E_FEG_A, sv::E_FEG_D, sv::E_FEG_S, sv::E_FEG_R};
        for (int k = 0; k < 5; ++k) {
            if (const EngineParamDef* d = find(kF1[k])) neEngineKnob(c, 99.0F + 122.0F * static_cast<float>(k), 340.0F, 72.0F, 84.0F, u, *d);
            if (const EngineParamDef* d = find(kEnv[k])) neEngineKnob(c, 760.0F + 122.0F * static_cast<float>(k), 331.0F, 72.0F, 84.0F, u, *d);
        }
        if (const EngineParamDef* f2 = find(sv::E_F2_TYPE)) {
            nlLabel(c, "TYPE", 34.0F, 474.0F, false, NL_TXT2, 11.0F);
            neEngineKey(c, RectF(34.0F, 481.0F, 163.0F, 519.0F), u, *f2, 13.0F);
            text(c, "OFF LP HP BP BR", 34.0F, 538.0F, 11.5F, kNote, Opt().maxW(150.0F));
        }
        if (const EngineParamDef* rt = find(sv::E_F2_PAR)) {
            nlLabel(c, "ROUTING", 190.0F, 474.0F, false, NL_TXT2, 11.0F);
            neEngineKey(c, RectF(190.0F, 481.0F, 339.0F, 519.0F), u, *rt, 13.0F);
            text(c, "SERIES / PARALLEL", 190.0F, 538.0F, 11.5F, kNote, Opt().maxW(170.0F));
        }
        if (const EngineParamDef* d = find(sv::E_F2_CUT)) neEngineKnob(c, 450.0F, 540.0F, 72.0F, 84.0F, u, *d);
        if (const EngineParamDef* d = find(sv::E_F2_RES)) neEngineKnob(c, 580.0F, 540.0F, 72.0F, 84.0F, u, *d);
        return;
    }
    // every other page: one panel with its keys, drawbars and knobs
    nlPanel(c, area, legacyPageName(sv::enginePageName(type, enginePage_, variant)));
    std::vector<const EngineParamDef*> keys, bars, knobs;
    for (int i = 0; i < pg.count; ++i) {
        const EngineParamDef& d = pg.items[i];
        if (d.kind == EngineKind::Choice || d.kind == EngineKind::Switch) keys.push_back(&d);
        else if (d.kind == EngineKind::Drawbar) bars.push_back(&d);
        else knobs.push_back(&d);
    }
    float y = area.top + 36.0F;
    if (!keys.empty()) {
        const int perRow = 8;
        const int rows = (static_cast<int>(keys.size()) + perRow - 1) / perRow;
        const float kw = std::min(150.0F, (area.width() - 40.0F - 12.0F * static_cast<float>(perRow - 1)) / static_cast<float>(perRow));
        for (std::size_t i = 0; i < keys.size(); ++i) {
            const int row = static_cast<int>(i) / perRow, col = static_cast<int>(i) % perRow;
            const float x0 = area.left + 20.0F + static_cast<float>(col) * (kw + 12.0F), y0 = y + static_cast<float>(row) * 70.0F;
            engineKey(c, RectF(x0, y0, x0 + kw, y0 + 38.0F), u, *keys[i]);
        }
        y += static_cast<float>(rows) * 70.0F;
    }
    if (!bars.empty()) {
        const float unit = (area.width() - 40.0F) / static_cast<float>(bars.size());
        for (std::size_t i = 0; i < bars.size(); ++i) {
            const float cx = area.left + 20.0F + unit * (static_cast<float>(i) + 0.5F);
            engineDrawbar(c, RectF(cx - 23.0F, y + 6.0F, cx + 23.0F, y + 126.0F), u, *bars[i]);
        }
        y += 160.0F;
    }
    if (!knobs.empty()) {
        const int cols = std::min(static_cast<int>(knobs.size()), 10);
        const float unit = (area.width() - 40.0F) / static_cast<float>(cols);
        for (std::size_t i = 0; i < knobs.size(); ++i) {
            const int row = static_cast<int>(i) / cols, col = static_cast<int>(i) % cols;
            neEngineKnob(c, area.left + 20.0F + unit * (static_cast<float>(col) + 0.5F), y + 54.0F + static_cast<float>(row) * 128.0F, 62.0F, std::min(84.0F, unit - 6.0F), u, *knobs[i]);
        }
    }
}

// the knob of an engine value: the same touch logic as engineKnob (log kinds on a 0..1 position, whole steps, % typed 0..100), the look of the pictures
void SilvetonSamplerView::neEngineKnob(Canvas& c, float cx, float cy, float dia, float vw, int u, const EngineParamDef& d, const char* labelOverride) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = labelOverride != nullptr ? std::string(labelOverride) : std::string(d.label);
    const std::string hint = d.hint;
    if (logKind(d)) {
        neKnob(c, cx, cy, dia, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, vw,
               [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
               [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
               [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        neKnob(c, cx, cy, dia, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, vw,
               [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
               [this, u, id, d, v, hint, pct] {
                   showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                              [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
               },
               [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// ---------------------------------------------------------------- SILVETON_PLACE_FX_V1 / SILVETON_NEW_LOOK_V1: the EFFECTS tab of a place (picture engine_fx)
// SENDS = the four shared units FX1..FX4 of this place, INSERT = its own effect (the same 18 types as on EFFECTS), PARAMETERS = the knobs of that effect.
// `u` = part 7..14 (a place); unit 4 + u = its INSERT.
namespace {
const char* const kNeFxNames[] = {"OFF", "DIGITAL DLY", "CHORUS", "PLATE", "HALL", "ROOM", "CHAMBER", "SPRING", "TAPE DLY", "PING-PONG",
                                  "MULTI-TAP", "DUCK DLY", "FLANGER", "PHASER", "ROTARY", "COMP", "DRIVE", "ENSEMBLE"};
const int kNeFxOrder[] = {0, 4, 3, 5, 6, 7, 1, 8, 9, 10, 11, 2, 17, 12, 13, 14, 15, 16};
}

void SilvetonSamplerView::drawPlaceFxNew(Canvas& c, int u) {
    const int unit = 4 + u;
    const std::string where = u >= 7 ? "PLACE " + std::to_string(u - 6) : "UPPER " + std::to_string(u + 1);
    const std::optional<UpperState>& stOpt = upperStates[static_cast<std::size_t>(u)];
    // ---- SENDS
    nlPanel(c, RectF(324.0F, 146.0F, 624.0F, 334.0F), "SENDS · " + where);
    if (stOpt) {
        const UpperState st = *stOpt;
        const std::vector<float> up = uParams(u);
        for (int n = 1; n <= 4; ++n) {
            const float value = n == 1 ? st.fxSend1 : (n == 2 ? st.fxSend2 : (n == 3 ? getOr(up, 46, 0.0F) : getOr(up, 47, 0.0F)));
            const std::function<void(float)> apply = [this, st, u, n](float nv) {
                if (n == 1 || n == 2) {
                    const auto& cur = upperStates[static_cast<std::size_t>(u)];
                    UpperState x = cur ? *cur : st;
                    if (n == 1) x.fxSend1 = nv; else x.fxSend2 = nv;
                    commitUpperFx(x, u);
                } else setUParam(u, n == 3 ? 46 : 47, nv);
            };
            neKnob(c, 358.0F + 70.0F * static_cast<float>(n - 1), 266.0F, 50.0F, value, 0.0F, 1.0F, 0.01F, 250.0F, false,
                   std::to_string(rndI(value * 100.0F)) + " %", "FX " + std::to_string(n), 64.0F, apply,
                   [this, n, value, apply] {
                       showNumber("FX" + std::to_string(n) + " SEND %", value * 100.0F, 0.0F, 100.0F, 0, [apply](float pct) { apply(std::clamp(pct / 100.0F, 0.0F, 1.0F)); });
                   },
                   [apply] { apply(0.0F); });
        }
    }
    // ---- INSERT: the type
    const std::vector<float> p = fxP(unit);
    const int type = p.empty() ? 0 : rndI(p[0]);
    nlPanel(c, RectF(632.0F, 146.0F, 1320.0F, 334.0F), "INSERT · " + where + " · TYPE");
    for (int k = 0; k < 18; ++k) {
        const int t = kNeFxOrder[k];
        const float x0 = 644.0F + static_cast<float>(k % 6) * 112.0F, y0 = 176.0F + static_cast<float>(k / 6) * 50.0F;
        const RectF b(x0, y0, x0 + 106.0F, y0 + 44.0F);
        nlBtn(c, b, kNeFxNames[t], type == t ? NlBtn::On : NlBtn::Off, 11.0F, true);
        hit(b, [this, unit, t](float, float) { setFxP(unit, 0, static_cast<float>(t)); });
    }
    // ---- PARAMETERS: the knobs of the chosen effect (the same block as on EFFECTS; the delays add their TEMPO row)
    drawFxParamsBlock(c, RectF(324.0F, 344.0F, 1320.0F, 650.0F), unit, type, p, "INSERT " + where);
    const bool tempoRow = type == 1 || type == 8 || type == 9 || type == 10 || type == 11;
    if (!tempoRow && type != 0) {
        text(c, "the same effect types and knobs as on EFFECTS · drag a knob · double-tap = default · hold or tap the value = type a number", 340.0F, 603.0F, 12.0F, kNote, Opt().maxW(960.0F));
        text(c, "FX 1–FX 4 are the same four shared units as on EFFECTS · the INSERT works only for this place", 340.0F, 625.0F, 12.0F, kNote, Opt().maxW(960.0F));
    }
}

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u, int id, float v) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id, v);
    // the engine itself changed = its starting values were loaded: read everything again.
    // SILVETON_ENGINE_UPPER_ON_V1: choosing an engine on an empty Upper switches the Upper on in the engine - read the Upper
    // again too, or the next LEVEL / PAN / range move would send the old OFF back and the engine's sound would stop
    if (!ok || id == 0) { slot.reset(); refreshUpper(u); }
    // SILVETON_ENGINES_V3: the STR-1 INSTRUMENT loads its typical values - read them all again
    else if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && id == sv::ST_BODY_TYPE + 1) slot.reset();
    else {
        auto a = eParams(u);
        // SILVETON_MUSICAL_V1: the value as the engine keeps it (a RATIO jumps to its musical step)
        const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
        if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = id >= 1 ? sv::engineClamp(type, id - 1, v) : v;
        slot = a;
        // SILVETON_ENGINE_WAVE_V1: a ВЪЛНА chosen on a set saved before (its level is 0 there) gets the starting level
        int wid = 0, lid = 0, oid = 0;
        if (v >= 0.5F && sv::engineWaveIds(type, wid, lid, oid) && id == wid + 1 && engineP(u, lid + 1) <= 0.0F) {
            const EngineParamDef* d = sv::engineParamDef(type, lid);
            if (d != nullptr) setEnginePOne(u, lid + 1, d->def);
        }
    }
    invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v) - rndI(d.lo));   // SILVETON_OCTAVE_V1: a choice may start below 0 (ОКТАВА -2..+2) or at 1 (SUB OCT)
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page (SILVETON_NEW_LOOK_V1: drawn like the pictures; rad = the bezel, hw = the width of its value box)
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    neEngineKnob(c, cx, cy, rad / 0.35F, std::min(hw, 84.0F), u, d);
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && d.id == sv::ST_STYLE)
        d.names = sv::str1StyleNames(rndI(engineP(u, sv::ST_BODY_TYPE + 1)));
    const int id = d.id + 1;
    const float v = engineP(u, id);
    // SILVETON_OCTAVE_V2: ОКТАВА is  [ - ]  +1 OCT  [ + ]  - one tap = one octave, a tap on the middle = back to 0
    if (d.kind == EngineKind::Choice && rndI(d.lo) == -2 && rndI(d.hi) == 2) {
        const int cur = std::clamp(rndI(v), -2, 2);
        stripToggle(c, r, cur == 0 ? "0 OCT" : (cur > 0 ? "+" + std::to_string(cur) + " OCT" : std::to_string(cur) + " OCT"), cur != 0, C_AMBER, 11.0F);
        const float w = std::min(r.width() * 0.3F, 46.0F);
        const RectF lr(r.left, r.top, r.left + w, r.bottom), rr(r.right - w, r.top, r.right, r.bottom), mr(r.left + w, r.top, r.right - w, r.bottom);
        text(c, "-", lr.centerX(), lr.centerY() + 7.0F, 22.0F, NL_TXT2, Opt().center().bold());
        text(c, "+", rr.centerX(), rr.centerY() + 7.0F, 22.0F, NL_TXT2, Opt().center().bold());
        nlLabel(c, d.label, r.centerX(), r.bottom + 17.0F, true, NL_TXT2, 11.0F);   // SILVETON_NEW_LOOK_V1
        hit(lr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::max(cur - 1, -2))); });
        hit(rr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::min(cur + 1, 2))); });
        hit(mr, [](float, float) {}, [this, u, id] { setEngineP(u, id, 0.0F); });
        return;
    }
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    stripToggle(c, r, engineValueText(d, v), on, C_AMBER, 11.0F);
    nlLabel(c, d.label, r.centerX(), r.bottom + 17.0F, true, NL_TXT2, 11.0F);   // SILVETON_NEW_LOOK_V1
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — choose and play · touch outside the window = close";
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open while choosing and playing
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, kWell);   // SILVETON_NEW_LOOK_V1
    strokeRR(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, Color::rgb(3, 4, 5), 1.0F);
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, NL_BLUE);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 13.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 8.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    nlFaderCap(c, trackX, y, 32.0F, 20.0F);
    text(c, std::to_string(v), trackX + 20.0F, y + 4.0F, 10.0F, NL_TXT2, Opt().bold());
    nlLabel(c, d.label, trackX, r.bottom + 17.0F, true, NL_TXT2, 11.0F);
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- the page
void SilvetonSamplerView::drawEngine(Canvas& c, const RectF& sec, int u) {
    using sv::engineName;
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const bool slotMode = u >= 7;   // SILVETON_ENGINE_SLOTS_V2: an engine slot has its own page - the engine keys are in its header, here only the pages and knobs
    if (!slotMode) secTitle(c, sec, "ENGINE · UPPER " + std::to_string(u + 1) + " · " + sv::engineLine(type));

    // row A: the ten engines, then the pages of the chosen one (three, or four for the engines with a second page of their own)
    const float keyY0 = slotMode ? sec.top + 2.0F : sec.top + 26.0F, keyY1 = keyY0 + (slotMode ? 44.0F : 36.0F);
    const float enginesW = 700.0F;
    // SILVETON_MODEL_REMOVED_V1: the old engines and SILVETON MODEL are gone - the row of an Upper has only OFF (SILVETON SYNTH is put into a place of ДВИГАТЕЛИ)
    const EngineType shownKeys[1] = {EngineType::Off};
    const float kw = (enginesW - 4.0F) / 2.0F;
    for (int k = 0; k < (slotMode ? 0 : 1); ++k) {
        const EngineType kt = shownKeys[k];
        const float x0 = sec.left + static_cast<float>(k) * (kw + 4.0F);
        const RectF kr(x0, keyY0, x0 + kw, keyY1);
        stripToggle(c, kr, engineName(kt), typeIx == static_cast<int>(kt), C_ACCENT, 11.0F);
        hit(kr, [this, u, kt](float, float) {
            setEngineP(u, 0, static_cast<float>(static_cast<int>(kt)));
            enginePage_ = sv::engineOscPage(kt);   // SILVETON_ENGINES_PAGE_V2: opens on the oscillators
        });
    }
    // SILVETON_ENGINES_V2: ENGINE ON / OFF - OFF plays the plain recording and keeps every setting (to hear the difference)
    if (type != EngineType::Off && u < 7) {   // (an engine slot has its own ВКЛ / ИЗКЛ above - no second switch)
        const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
        const float x0 = sec.left + enginesW + 8.0F;
        const RectF br(x0, keyY0, x0 + 72.0F, keyY1);
        stripToggle(c, br, bypassed ? "OFF" : "ON", !bypassed, C_LCD_OK, 13.0F);
        hit(br, [this, u, bypassed](float, float) { setEngineP(u, sv::E_BYPASS + 1, bypassed ? 0.0F : 1.0F); });
    }
    const int pageCount = std::max(1, sv::enginePageCount(type));
    const int extraPages = 0;   // a SILVETON SYNTH place has ONE screen (drawModelOneScreen), no pages
    static const char* const kExtraNames[1] = {""};
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the ДЪХ page
    if (enginePage_ >= pageCount + extraPages) enginePage_ = 0;
    if (type != EngineType::Off) {
        const float pw = pageCount >= 5 ? 74.0F : 94.0F;   // SILVETON_ENGINES_PAGE_V2: five pages fit beside the ON key
        // SILVETON_ENGINES_PAGE_V3: the ОСЦ page is the FIRST key of every engine (the others keep their order after it)
        std::array<int, 8> order{};
        int cnt = 0;
        order[static_cast<std::size_t>(cnt++)] = std::clamp(sv::engineOscPage(type), 0, pageCount - 1);
        for (int k = 0; k < pageCount + extraPages && cnt < 8; ++k) if (k != order[0]) order[static_cast<std::size_t>(cnt++)] = k;
        for (int slotIx = 0; slotIx < pageCount + extraPages; ++slotIx) {
            const int k = order[static_cast<std::size_t>(slotIx)];
            const float spw = slotMode ? 126.0F : pw;
            const float x1 = slotMode ? sec.left + 4.0F + static_cast<float>(slotIx) * (spw + 10.0F)
                                      : sec.right - static_cast<float>(pageCount - slotIx) * (pw + 4.0F) + 4.0F;
            const RectF pr(x1, keyY0, x1 + spw, keyY1);
            stripToggle(c, pr, k >= pageCount ? kExtraNames[k - pageCount] : sv::enginePageName(type, k, variant), enginePage_ == k, C_AMBER, slotMode ? 13.0F : 11.0F);
            hit(pr, [this, k](float, float) { enginePage_ = k; invalidate(); });
        }
    }
    if (type == EngineType::Off) {
        if (slotMode) {   // SILVETON_ENGINE_SLOTS_V2
            text(c, "This place is empty.", sec.centerX(), sec.top + 150.0F, 24.0F, C_VALUE, Opt().center().bold());
            text(c, "Press ADD SILVETON SYNTH above, then choose a MODEL - what was learned from the samples.", sec.centerX(), sec.top + 188.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
            text(c, "You can run up to 8 places at once and mix their level on the left.", sec.centerX(), sec.top + 214.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
        } else {
            text(c, "There is no engine here: the Upper plays the clean recording. SILVETON SYNTH is put on a place in ENGINE.", sec.left + 8.0F, sec.top + 110.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
        }
        return;
    }

    // the knobs and keys of the page: one or two rows
    const EngineParamPage pageAll = sv::enginePage(type, std::clamp(enginePage_, 0, pageCount - 1), variant);
    if (pageAll.count <= 0 || pageAll.items == nullptr) return;
    const EngineParamPage page = pageAll;
    const int n = page.count;
    const bool cx3Sound = type == EngineType::CX3 && enginePage_ == 0;
    const int cols = n <= 6 ? n : (cx3Sound ? std::max(12, n - 12) : (n + 1) / 2);   // SILVETON_ENGINE_WAVE_V1: up to 13 / 14 in a row
    const int firstRow = n <= 6 ? n : (cx3Sound ? 12 : (n + 1) / 2);
    const float unit = sec.width() / static_cast<float>(std::max(cols, 1));
    const float hw = std::min(unit - 4.0F, 150.0F);
    const float rad = 16.0F;
    const bool roomy = sec.height() > 360.0F;   // SILVETON_ENGINES_PAGE_V1: the page of its own has room - the rows do not touch
    const float r1 = n <= 6 ? sec.top + (roomy ? 190.0F : 150.0F) : sec.top + (roomy ? 140.0F : 102.0F);
    const float r2 = r1 + (roomy ? 150.0F : (darkTheme ? 96.0F : 86.0F));   // the dark theme prints the names above the knobs
    for (int i = 0; i < n; ++i) {
        const EngineParamDef& d = page.items[i];
        const bool second = i >= firstRow;
        const int col = second ? i - firstRow : i;
        const float cx = sec.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = second ? r2 : r1;
        switch (d.kind) {
            case EngineKind::Drawbar: engineDrawbar(c, RectF(cx - hw / 2.0F, cy - 36.0F, cx + hw / 2.0F, cy + 30.0F), u, d); break;
            case EngineKind::Choice:
            case EngineKind::Switch: engineKey(c, RectF(cx - hw / 2.0F + 2.0F, cy - 22.0F, cx + hw / 2.0F - 2.0F, cy + 22.0F), u, d); break;
            default: engineKnob(c, cx, cy, rad, hw, u, d); break;
        }
    }
}

} // namespace silveton::ui::classic
