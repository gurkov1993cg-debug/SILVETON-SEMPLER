// SILVETON_ENGINES_V1 - the ENGINE page of an Upper (КОМБИ > ENGINE): one of the nine engines on the whole Upper.
// Top row: the engines (OFF · HD-1 · POLYSIX · MS-20 · AL-1 · MOD-7 · STR-1 · CX-3 · SGX · EP) and the three pages of the
// chosen one (ЗВУК = the engine's own knobs, ФИЛТЪР = the two filters and the filter envelope, МОД = LFO / unison / analog).
// Every knob: drag = turn, tap = exact number, right button / double tap = its starting value. The labels, ranges and
// starting values come from core/include/silveton/sampler/EngineDefs.h, so the screen and the sound can never disagree.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/ModelDefs.h"   // SILVETON_MODEL_V1

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>

namespace silveton::ui::classic {

namespace sv = ::silveton::sampler;   // (inside the view class the name `sampler` is the controller member)

namespace {
using sv::EngineKind;
using sv::EngineParamDef;
using sv::EngineParamPage;
using sv::EngineType;

float lnF(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expF(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rndI(float v) { return static_cast<int>(std::nearbyint(v)); }

std::string msTextE(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), v < 10.0F ? 2 : 1) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}

// SILVETON_USER_WAVES_V1: a place USER n shows the name of the user's wave in it ("U2 STRINGS"), or "USER n НЯМА" when empty
std::string userWaveLabel(const std::string& s) {
    if (s.rfind("USER ", 0) != 0) return s;
    const int n = std::atoi(s.c_str() + 5);
    if (n < 1 || n > sv::kUserWaveCount) return s;
    const std::string nm = sv::userWaveName(n - 1);
    return nm.empty() ? s + " НЯМА" : "U" + std::to_string(n) + " " + nm;
}

std::string choiceName(const EngineParamDef& d, int index) {
    std::string names = d.names != nullptr ? d.names : "";
    int k = 0;
    std::string cur;
    for (std::size_t i = 0; i <= names.size(); ++i) {
        if (i == names.size() || names[i] == '|') {
            if (k == index) return userWaveLabel(cur);
            ++k; cur.clear();
        } else cur.push_back(names[i]);
    }
    return std::to_string(index);
}

int choiceCount(const EngineParamDef& d) {
    if (d.names == nullptr) return 2;
    int n = 1;
    for (const char* c = d.names; *c != '\0'; ++c) if (*c == '|') ++n;
    return n;
}

// knob position 0..1 of a value, and back (the logarithmic kinds)
bool logKind(const EngineParamDef& d) { return d.kind == EngineKind::Hz || d.kind == EngineKind::Sec || d.kind == EngineKind::Ms; }
float toNorm(const EngineParamDef& d, float v) {
    if (!logKind(d)) return v;
    if (d.lo <= 0.0F) return lnF(std::clamp(v, 0.0F, d.hi) + 1.0F) / lnF(d.hi + 1.0F);   // 0 = OFF at the left
    return lnF(std::clamp(v, d.lo, d.hi) / d.lo) / lnF(d.hi / d.lo);
}
float fromNorm(const EngineParamDef& d, float t) {
    t = std::clamp(t, 0.0F, 1.0F);
    if (d.lo <= 0.0F) { const float v = expF(t * lnF(d.hi + 1.0F)) - 1.0F; return v < 0.5F ? 0.0F : v; }
    return d.lo * expF(t * lnF(d.hi / d.lo));
}
} // namespace

// ---------------------------------------------------------------- SILVETON_ENGINES_PAGE_V1: the page of the nine ENGINES (left menu)
// A row of the Uppers (tap = choose it), under it the ENGINE of the chosen Upper with all its pages and its oscillators.
void SilvetonSamplerView::drawEnginesPage(Canvas& c) {
    // SILVETON_ENGINE_SLOTS_V2: the engines have a page of their own. LEFT: the 8 places like a small mixer (name, ВКЛ lamp, СИЛА slider).
    // RIGHT: the chosen place - its engine, ВКЛ / СИЛА / POLY-MONO-LEGATO / PORTAMENTO, then the oscillators and knobs of the engine.
    const int slot = std::clamp(engSlot_, 0, 7);
    if (engUpper_ >= 7) engUpper_ = -1;
    const bool onUpper = engUpper_ >= 0;   // SILVETON_SUSE_SAMPLE_V1: an Upper of the blend is edited here (SILVETON SYNTH on its recordings)
    const int u = onUpper ? engUpper_ : 7 + slot;
    const ColorInt cardOff = Color::rgb(47, 51, 59), cardOn = Color::rgb(70, 76, 89);

    // ---- left: the eight places
    const RectF rack(112.0F, 112.0F, 372.0F, 786.0F);
    board(c, rack, true);
    for (int i = 0; i < 8; ++i) {
        const int pu = 7 + i;
        const float top = 124.0F + static_cast<float>(i) * 81.0F;
        const RectF r(124.0F, top, 360.0F, top + 75.0F);
        const bool sel = !onUpper && i == slot;
        const int t = std::clamp(rndI(engineP(pu, 0)), 0, sv::kEngineTypeCount - 1);
        const std::optional<UpperState> st = upperStates[static_cast<std::size_t>(pu)];
        const bool live = t != 0 && st && st->enabled;
        fill(c, r, 10.0F, sel ? cardOn : cardOff);
        if (sel) fill(c, RectF(r.left, r.top + 9.0F, r.left + 4.0F, r.bottom - 9.0F), 2.0F, C_ACCENT);
        text(c, std::to_string(i + 1), r.left + 24.0F, r.top + 38.0F, 26.0F, sel ? C_VALUE : C_KNOB_LABEL, Opt().center().bold());
        // SILVETON_SYNTH_V1: a place is "празно" or SILVETON SYNTH with its model (an old engine of an old set is not named)
        const bool isSynthPlace = t != 0 && static_cast<EngineType>(t) == EngineType::Synth;
        const int mNo = isSynthPlace ? std::clamp(rndI(engineP(pu, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels) : 0;
        const std::string placeName = t == 0 ? std::string("празно")
            : (isSynthPlace ? (mNo > 0 ? "SYNTH · МОДЕЛ " + std::to_string(mNo) : std::string("SYNTH · без модел")) : std::string("стар"));
        text(c, placeName, r.left + 48.0F, r.top + 30.0F, isSynthPlace ? 14.0F : 18.0F, t == 0 ? C_HINT : C_VALUE, Opt().bold().maxW(isSynthPlace ? 134.0F : 110.0F));
        hit(r, [this, i](float, float) { engSlot_ = i; engUpper_ = -1; selectedUpper_ = 7 + i; enginePage_ = 0; invalidate(); });
        if (t != 0 && st) {
            // the lamp = ВКЛ / ИЗКЛ of the place
            const RectF lamp(r.right - 50.0F, r.top + 4.0F, r.right - 4.0F, r.top + 42.0F);
            fill(c, RectF(r.right - 30.0F, r.top + 15.0F, r.right - 14.0F, r.top + 31.0F), 8.0F, live ? C_ACCENT : Color::rgb(30, 33, 38));
            if (live) fill(c, RectF(r.right - 33.0F, r.top + 12.0F, r.right - 11.0F, r.top + 34.0F), 11.0F, Color::argb(60, 80, 220, 120));
            text(c, fmtFixed(static_cast<double>(st->levelDb), 1) + " dB", r.right - 14.0F, r.top + 47.0F, 11.0F, C_KNOB_LABEL, Opt().right().mono().maxW(80.0F));
            hit(lamp, [this, pu](float, float) {
                const auto& cur = upperStates[static_cast<std::size_t>(pu)];
                if (!cur) return;
                UpperState n = *cur; n.enabled = !n.enabled; if (n.enabled) n.mute = false;
                commitMain(pu, n); invalidate();
            });
            // the slider = СИЛА of the place (tap or drag; 0 dB is the small mark)
            const float x0 = r.left + 48.0F, x1 = r.right - 14.0F;
            const float ty = r.top + 56.0F;
            fill(c, RectF(x0, ty - 3.0F, x1, ty + 3.0F), 3.0F, Color::rgb(28, 31, 36));
            const float tv = std::clamp((st->levelDb + 60.0F) / 72.0F, 0.0F, 1.0F);
            fill(c, RectF(x0, ty - 3.0F, x0 + (x1 - x0) * tv, ty + 3.0F), 3.0F, live ? C_ACCENT : Color::rgb(110, 116, 126));
            fill(c, RectF(x0 + (x1 - x0) * (60.0F / 72.0F) - 1.0F, ty - 8.0F, x0 + (x1 - x0) * (60.0F / 72.0F) + 1.0F, ty - 4.0F), 0.0F, Color::argb(110, 255, 255, 255));
            fill(c, RectF(x0 + (x1 - x0) * tv - 8.0F, ty - 8.0F, x0 + (x1 - x0) * tv + 8.0F, ty + 8.0F), 8.0F, Color::rgb(226, 229, 234));
            const auto setLevel = [this, pu, x0, x1](float x, float) {
                const auto& cur = upperStates[static_cast<std::size_t>(pu)];
                if (!cur) return;
                const float v = std::clamp(-60.0F + (x - x0) / std::max(1.0F, x1 - x0) * 72.0F, -60.0F, 12.0F);
                UpperState n = *cur; n.levelDb = std::nearbyint(v * 2.0F) * 0.5F;
                if (std::fabs(n.levelDb) < 0.75F) n.levelDb = 0.0F;   // it sticks to 0 dB
                commitMain(pu, n);
            };
            hit(RectF(x0 - 10.0F, ty - 16.0F, x1 + 10.0F, ty + 16.0F), setLevel,
                [this, pu] { const auto& cur = upperStates[static_cast<std::size_t>(pu)]; if (!cur) return; UpperState n = *cur; n.levelDb = 0.0F; commitMain(pu, n); },
                [setLevel](float x, float y, bool) { setLevel(x, y); });
        }
    }

    // ---- right: the chosen place. SILVETON_MODEL_ONE_SCREEN_V1 (Цветомир, 03.11.2026): ONE screen like the OSC page of a Korg -
    // the head (МОДЕЛ, СИЛА), the knobs of the sound, the FILTER, ТОН · ОБВИВКА and СВИРЕНЕ. Nothing twice, no page for three knobs.
    const float L = 388.0F, R = 1326.0F;
    const int tSel = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto typeSel = static_cast<EngineType>(tSel);
    if (typeSel == EngineType::Synth) { drawModelOneScreen(c, u); return; }
    // an empty place (or one of an old set): one key makes it a SILVETON SYNTH place
    const RectF head(L, 112.0F, R, 238.0F);
    board(c, head, false);
    text(c, onUpper ? "UPPER " + std::to_string(u + 1) + " · БЛЕНДА" : "МЯСТО " + std::to_string(slot + 1), L + 22.0F, 138.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
    text(c, tSel == 0 ? std::string("ПРАЗНО") : std::string("СТАР ДВИГАТЕЛ"), L + 22.0F, 172.0F, 32.0F, C_HINT, Opt().bold().maxW(360.0F));
    text(c, "SYNTH: звукът се пресмята от наученото, без запис.", L + 392.0F, 166.0F, 14.0F, C_KNOB_LABEL, Opt().maxW(R - L - 420.0F));
    const RectF ks(L + 22.0F, 188.0F, L + 22.0F + 330.0F, 228.0F);
    stripToggle(c, ks, "СЛОЖИ SILVETON SYNTH", false, C_ACCENT, 14.0F);   // SILVETON_SYNTH_V1
    hit(ks, [this, u](float, float) { setEngineP(u, 0, static_cast<float>(static_cast<int>(EngineType::Synth))); enginePage_ = 0; invalidate(); });
    board(c, RectF(L, 246.0F, R, 786.0F), false);
    text(c, "Натисни горе ключа: SILVETON SYNTH (звукът му е пресметнат от наученото).", L + 40.0F, 330.0F, 16.0F, C_HINT, Opt().maxW(R - L - 80.0F));
}

// ---------------------------------------------------------------- SILVETON_MODEL_ONE_SCREEN_V2 (Цветомир, 03.11.2026, спецификация):
// ALL settings of a SILVETON SYNTH place on ONE screen, like a professional synthesizer. No pages, nothing twice, nothing hidden.
//   HEAD:      МОДЕЛ (the learned models)  ·  НАЧАЛНИ ВРЪТКИ
//   PANEL A:   МОДЕЛ - the character of the sound: BRIGHT HARMONICS SHAPE SCOOP UNISON LIFE VIBRATO
//   PANEL B:   ФИЛТЪР - type, CUTOFF, RESONANCE, KEY TRACK, DRIVE, ENV AMOUNT, F.ADSR, VEL→CUTOFF, LFO→CUTOFF
//   PANEL C:   ТОН · ОБВИВКА - ОКТАВА, ТРАНСПОНИРАНЕ; TUNE (the slider -12 .. +12 st = the sampler's own TUNE, the TRANSPOSE that keeps
//              the notes on their keys is added by the sampler itself; no ФИНА knob); ATTACK DECAY SUSTAIN RELEASE
//   PANEL D:   СВИРЕНЕ - POLY / MONO / LEGATO; portamento SILVETON / KRONOS / BASS, ON / OFF, FINGERED, TIME / RATE; PORTA TIME; PITCH BEND
// Every control drives its real parameter (the same host calls as before: setEngineP -> the engine row, commitTune / commitMain /
// setTone / setUParam -> the part), everything is saved with the blend / the SET as before.
namespace {
constexpr float kOneL = 388.0F, kOneR = 1326.0F;
}

void SilvetonSamplerView::drawModelOneScreen(Canvas& c, int u) {
    const float L = kOneL, R = kOneR;
    const int slot = u - 7;
    const std::optional<UpperState>& stOpt = upperStates[static_cast<std::size_t>(u)];
    const std::vector<float> p = uParams(u);

    // ================= HEAD
    const RectF head(L, 112.0F, R, 214.0F);
    board(c, head, false);
    text(c, "МЯСТО " + std::to_string(slot + 1), L + 22.0F, 134.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
    text(c, "SILVETON SYNTH", L + 96.0F, 134.0F, 13.0F, C_VALUE, Opt().bold());
    {
        const Ctrl::AudioStatus a = frameAudioStatus;
        text(c, "ПРОЦЕСОР " + std::to_string(rndI(a.cpuLoadPercent)) + " %  ·  ГЛАСОВЕ " + std::to_string(a.activeVoices), L + 250.0F, 134.0F, 11.0F,
             a.cpuLoadPercent > 80.0F ? C_AMBER : C_KNOB_LABEL, Opt().mono());
    }
    const float ky0 = 152.0F, ky1 = 192.0F;
    const RectF rm(L + 22.0F, ky0, L + 562.0F, ky1), rr(L + 790.0F, ky0, L + 916.0F, ky1);
    const std::vector<std::string> models = sampler.learnedModelNames();
    const int mSel = std::clamp(rndI(engineP(u, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels);
    std::string mText;
    if (models.empty()) mText = "МОДЕЛ: няма";
    else if (mSel <= 0) mText = "МОДЕЛ  ▼  избери (" + std::to_string(models.size()) + ")";
    else mText = "МОДЕЛ " + std::to_string(mSel) + ": " + (mSel <= static_cast<int>(models.size()) ? models[static_cast<std::size_t>(mSel - 1)] : std::string("няма го"));
    stripToggle(c, rm, mText, mSel > 0 && !models.empty(), C_AMBER, 12.0F);
    hit(rm, [this, u, models](float, float) {
        if (models.empty()) { showMessage("НЯМА МОДЕЛИ", "Моделите са вградени в семплера.\n" + sampler.learnedModelsNote()); return; }
        std::vector<std::pair<std::string, std::string>> items;
        for (std::size_t i = 0; i < models.size(); ++i) items.emplace_back(std::to_string(i + 1), models[i]);
        const int cur = std::clamp(rndI(engineP(u, sv::model::MO_MODEL + 1)), 0, sv::model::kMaxModels) - 1;
        showGridPicker("МОДЕЛ  ·  пробвай моделите един след друг, ГОТОВО затваря", items, cur, std::string("NONE"), [this, u](int k) {
            setEngineP(u, sv::model::MO_MODEL + 1, static_cast<float>(k + 1));   // -1 (NONE) -> 0
            invalidate();
        });
        if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open: try the models one after another, ГОТОВО closes
    });
    stripToggle(c, rr, "НАЧАЛНИ ВРЪТКИ", false, C_AMBER, 11.0F);
    hit(rr, [this, u](float, float) {
        showConfirm("НАЧАЛНИ ВРЪТКИ", "Всички ръчки на двигателя на това място се връщат на началното (моделът остава).", "ДА, ВЪРНИ", [this, u]() {
            std::vector<float> row(eParams(u));
            if (row.size() < static_cast<std::size_t>(sv::kEngineParamCountLegacy) + 1U) return;
            const float keepModel = row[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U];
            sv::synth::setDefaults(row.data() + 1);
            row[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U] = keepModel;
            std::vector<float> values(row.begin() + 1, row.begin() + 1 + sv::kEngineParamCountLegacy);
            sampler.setUpperEngineBlock(u, 1, values);
            engineParamsCache[static_cast<std::size_t>(u)].reset();
            invalidate();
        });
    });

    // ================= the four panels (two columns, two rows)
    const float gap = 8.0F, colW = (R - L - gap) / 2.0F;
    const RectF pA(L, 222.0F, L + colW, 470.0F), pB(L + colW + gap, 222.0F, R, 470.0F);
    const RectF pC(L, 478.0F, L + colW, 786.0F), pD(L + colW + gap, 478.0F, R, 786.0F);
    const auto panel = [&](const RectF& r, const std::string& title, const std::string& note) {
        board(c, r, false);
        text(c, title, r.left + 16.0F, r.top + 20.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
        if (!note.empty()) text(c, note, r.right - 16.0F, r.top + 20.0F, 11.0F, C_AMBER, Opt().right().bold().maxW(r.width() * 0.6F));
    };

    // ---- PANEL A: МОДЕЛ - the character of the sound (the learned parts, 100 % = as the model learned it)
    {
        panel(pA, "МОДЕЛ  ·  ХАРАКТЕР НА ЗВУКА", mSel <= 0 ? "избери МОДЕЛ горе" : "");
        const EngineParamPage pg = sv::synth::page(0);
        std::vector<const EngineParamDef*> items;
        for (int i = 0; i < pg.count; ++i) {
            const int id = pg.items[i].id;
            if (id == sv::model::MO_MODEL || id == sv::model::MO_AMOUNT || id == sv::model::MO_TUNE) continue;
            items.push_back(&pg.items[i]);
        }
        const int first = items.size() > 8 ? 5 : 4;   // 7 knobs (no BREATH / CHIFF): 4 + 3
        const float unit = pA.width() / static_cast<float>(first);
        for (std::size_t i = 0; i < items.size(); ++i) {
            const bool second = static_cast<int>(i) >= first;
            const int col = second ? static_cast<int>(i) - first : static_cast<int>(i);
            const float cx = pA.left + unit * (static_cast<float>(col) + 0.5F), cy = second ? pA.top + 178.0F : pA.top + 78.0F;
            engineKnob(c, cx, cy, 18.0F, unit - 6.0F, u, *items[i]);
        }
    }
    // ---- PANEL B: ФИЛТЪР
    {
        panel(pB, "ФИЛТЪР", "");
        const EngineParamPage pg = sv::synth::page(1);
        const int first = 6;
        const float unit = pB.width() / static_cast<float>(first);
        for (int i = 0; i < pg.count; ++i) {
            const EngineParamDef& d = pg.items[i];
            const bool second = i >= first;
            const int col = second ? i - first : i;
            const float cx = pB.left + unit * (static_cast<float>(col) + 0.5F), cy = second ? pB.top + 178.0F : pB.top + 78.0F;
            if (d.kind == EngineKind::Choice || d.kind == EngineKind::Switch) engineKey(c, RectF(cx - unit / 2.0F + 4.0F, cy - 22.0F, cx + unit / 2.0F - 4.0F, cy + 22.0F), u, d);
            else engineKnob(c, cx, cy, 16.0F, unit - 6.0F, u, d);
        }
    }
    // ---- PANEL C: ТОН · ОБВИВКА
    if (stOpt) {
        const UpperState st = *stOpt;
        panel(pC, "ТОН  ·  ОБВИВКА", "");
        // the same stepper as the Upper's TUNE page (title, LCD number, − / +, both together = 0), compact
        const auto stepperAt = [&](float cx, float top, const char* title, const std::string& value, std::function<void()> onMinus, std::function<void()> onPlus, std::function<void()> onReset) {
            const RectF r(cx - 84.0F, top, cx + 84.0F, top + 88.0F);
            text(c, title, r.centerX(), r.top + 10.0F, 11.0F, C_KNOB_LABEL, Opt().center().bold().spacing(0.12F).maxW(r.width()));
            const RectF box(r.left + 26.0F, r.top + 16.0F, r.right - 26.0F, r.top + 50.0F);
            lcd(c, box, 7.0F);
            text(c, value, box.centerX(), box.centerY() + 8.0F, 22.0F, C_LCD, Opt().center().mono());
            hit(box, [](float, float) {}, onReset);   // double tap on the number = 0
            const float kw = (r.width() - 10.0F) / 2.0F;
            const RectF minus(r.left, r.top + 56.0F, r.left + kw, r.bottom), plus(r.left + kw + 10.0F, r.top + 56.0F, r.right, r.bottom);
            stripToggle(c, minus, "−", false, C_AMBER, 24.0F);
            stripToggle(c, plus, "+", false, C_AMBER, 24.0F);
            hit(minus, [this, onMinus](float, float) { onMinus(); invalidate(); });
            hit(plus, [this, onPlus](float, float) { onPlus(); invalidate(); });
            pairHits.push_back(PairHit{minus, plus, [this, onReset] { onReset(); invalidate(); }});
        };
        const float row1 = pC.top + 32.0F;
        stepperAt(pC.left + 100.0F, row1, "ОКТАВА", signed_(st.octave),
                  [this, st] { UpperState cur = currentUpper(st); cur.octave = std::max(cur.octave - 1, -4); commitTune(cur); },
                  [this, st] { UpperState cur = currentUpper(st); cur.octave = std::min(cur.octave + 1, 4); commitTune(cur); },
                  [this, st] { UpperState cur = currentUpper(st); cur.octave = 0; commitTune(cur); });
        stepperAt(pC.left + 282.0F, row1, "ТРАНСПОНИРАНЕ", signed_(st.transpose),
                  [this, st] { UpperState cur = currentUpper(st); cur.transpose = std::max(cur.transpose - 1, -12); commitTune(cur); },
                  [this, st] { UpperState cur = currentUpper(st); cur.transpose = std::min(cur.transpose + 1, 12); commitTune(cur); },
                  [this, st] { UpperState cur = currentUpper(st); cur.transpose = 0; commitTune(cur); });
        // SILVETON_SYNTH_TUNE_V1 (Цветомир, 03.11.2026 18:26): the ФИНА knob is gone. The slider below is the TUNE of the sampler itself
        // (-12 .. +12 semitones = -1200 .. +1200 ct, 0 in the middle): TUNE -500 ct = the slider at -5. The sampler adds the TRANSPOSE that
        // puts the notes back on their keys by itself (SamplerEngine.cpp synthTuneKeys) - the TRANSPOSE above is never touched. The timbre
        // moves (the zone of the key that sounds), the pitch never does.
        {
            const int tune = std::clamp(static_cast<int>(std::lround(st.fineCents / 100.0F)), -12, 12);
            const float sy = pC.top + 176.0F, sx0 = pC.left + 40.0F, sx1 = pC.right - 40.0F;
            text(c, "TUNE  ·  тембърът се мести, тонът стои", pC.left + 16.0F, pC.top + 150.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F).maxW(pC.width() - 110.0F));
            const RectF valR(pC.right - 90.0F, pC.top + 134.0F, pC.right - 12.0F, pC.top + 158.0F);
            text(c, (tune > 0 ? "+" : "") + std::to_string(tune) + " st", valR.right - 4.0F, pC.top + 152.0F, 15.0F, C_VALUE, Opt().right().mono().bold());
            fill(c, RectF(sx0, sy - 4.0F, sx1, sy + 4.0F), 4.0F, Color::rgb(28, 31, 36));
            for (int k = -12; k <= 12; ++k) {
                const float x = sx0 + (static_cast<float>(k) + 12.0F) / 24.0F * (sx1 - sx0);
                const bool big = k % 6 == 0;
                fill(c, RectF(x - 1.0F, sy + (big ? 8.0F : 10.0F), x + 1.0F, sy + 16.0F), 0.0F, Color::argb(big ? 150 : 70, 255, 255, 255));
                if (big) text(c, (k > 0 ? "+" : "") + std::to_string(k), x, sy + 30.0F, 10.0F, C_KNOB_LABEL, Opt().center());
            }
            const float hx = sx0 + (static_cast<float>(tune) + 12.0F) / 24.0F * (sx1 - sx0);
            fill(c, RectF(std::min(hx, (sx0 + sx1) / 2.0F), sy - 4.0F, std::max(hx, (sx0 + sx1) / 2.0F), sy + 4.0F), 4.0F, tune != 0 ? C_AMBER : Color::rgb(28, 31, 36));
            fill(c, RectF(hx - 13.0F, sy - 15.0F, hx + 13.0F, sy + 15.0F), 15.0F, Color::rgb(226, 229, 234));
            const auto setTune = [this, st](int v) { UpperState n = currentUpper(st); n.fineCents = static_cast<float>(std::clamp(v, -12, 12)) * 100.0F; commitTune(n); };
            const auto setAt = [setTune, sx0, sx1](float x, float) {
                setTune(static_cast<int>(std::lround((x - sx0) / std::max(1.0F, sx1 - sx0) * 24.0F - 12.0F)));
            };
            hit(RectF(sx0 - 20.0F, sy - 26.0F, sx1 + 20.0F, sy + 26.0F), setAt, [setTune] { setTune(0); }, [setAt](float x, float y, bool) { setAt(x, y); });
            hit(valR, [this, tune, setTune](float, float) { showNumber("TUNE (полутонове, 1 = 100 ct; тонът не мърда)", static_cast<float>(tune), -12.0F, 12.0F, 0, [setTune](float x) { setTune(rndI(x)); }); });
        }
        // ATTACK DECAY SUSTAIN RELEASE: the same knobs as the Upper's ТЕМБЪР page in КОМБИ (the fine logarithmic knobs; right button = the recording's own envelope)
        {
            const char* names[4] = {"ATTACK", "DECAY", "SUSTAIN", "RELEASE"};
            const float unit = pC.width() / 4.0F, cy = pC.top + 238.0F;
            for (int k = 0; k < 4; ++k) {
                const TonePar par = static_cast<TonePar>(k);
                const float v = toneValue(st, par);
                const ToneRange range = toneRange(par);
                const bool pct = k == 2;
                const std::string nm = names[k];
                const float cx = pC.left + unit * (static_cast<float>(k) + 0.5F);
                knobControl(c, cx, cy, 18.0F, toneToNorm(par, v), 0.0F, 1.0F, 0.002F, 260.0F, false, toneText(par, v), nm, unit - 6.0F,
                            [this, par](float nv) { setTone(par, toneFromNorm(par, nv)); },
                            [this, par, nm, pct, v, range] {
                                showNumber(nm, pct ? v * 100.0F : v, range.lo, range.hi, range.decimals, [this, par, pct](float nv) { setTone(par, pct ? nv / 100.0F : nv); }, true, [this, par, v] { setTone(par, v); });
                            },
                            [this, par] { setTone(par, -1.0F); });
            }
        }
    }
    // ---- PANEL D: СВИРЕНЕ
    if (stOpt) {
        const UpperState st = *stOpt;
        panel(pD, "СВИРЕНЕ", "");
        const float x0 = pD.left + 16.0F, kw = 130.0F, kg = 10.0F;
        const float r1 = pD.top + 34.0F, r2 = pD.top + 104.0F, r3 = pD.top + 156.0F, kh = 38.0F;
        for (int k = 0; k < 3; ++k) {
            const RectF mr(x0 + static_cast<float>(k) * (kw + kg), r1, x0 + kw + static_cast<float>(k) * (kw + kg), r1 + kh);
            stripToggle(c, mr, k == 0 ? "POLY" : (k == 1 ? "MONO" : "LEGATO"), st.voiceMode == k, C_AMBER, 12.0F);
            hit(mr, [this, st, k](float, float) { UpperState cur = currentUpper(st); cur.voiceMode = k; commitMain(selectedUpper_, cur); invalidate(); });
        }
        text(c, "ПОРТАМЕНТО", x0, r2 - 8.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.25F));
        const int mode = std::clamp(rndI(getOr(p, 42, 0.0F)), 0, 3);   // 0 SILVETON, 1 KRONOS, 3 BASS
        const char* names[3] = {"SILVETON", "KRONOS", "BASS"};
        const int modeOf[3] = {0, 1, 3};
        for (int k = 0; k < 3; ++k) {
            const RectF mr(x0 + static_cast<float>(k) * (kw + kg), r2, x0 + kw + static_cast<float>(k) * (kw + kg), r2 + kh);
            stripToggle(c, mr, names[k], mode == modeOf[k], C_AMBER, 12.0F);
            const int m = modeOf[k];
            hit(mr, [this, u, m](float, float) { setUParam(u, 42, static_cast<float>(m)); });
        }
        const bool silveton = mode == 0 || mode == 2;
        const float kronosTime = getOr(p, 45, 40.0F);
        const bool portaOn = silveton ? st.portamentoSec > 0.0F : kronosTime > 0.0F;
        // ON / OFF: OFF = TIME 0 (as the engine knows it), ON = the time it had before (or a usual one)
        {
            const RectF r(x0, r3, x0 + kw, r3 + kh);
            stripToggle(c, r, portaOn ? "PORTA ON" : "PORTA OFF", portaOn, C_LCD_OK, 12.0F);
            float& last = lastPorta_[static_cast<std::size_t>(std::clamp(u, 0, 15))];
            if (portaOn) last = silveton ? portamentoUiValue(st.portamentoSec) : kronosTime;
            const float restore = last > 0.0F ? last : (silveton ? 20.0F : 40.0F);
            hit(r, [this, u, st, silveton, portaOn, restore](float, float) {
                if (silveton) { UpperState n = currentUpper(st); n.portamentoSec = portaOn ? 0.0F : portamentoSecondsFromUi(restore); commitTune(n); }
                else setUParam(u, 45, portaOn ? 0.0F : restore);
            });
        }
        {   // FINGERED, TIME / RATE: the KRONOS / BASS way (dimmed under SILVETON, which has none of them)
            const bool fing = getOr(p, 43, 0.0F) >= 0.5F, rate = getOr(p, 44, 0.0F) >= 0.5F;
            const RectF fr(x0 + kw + kg, r3, x0 + 2.0F * kw + kg, r3 + kh);
            const RectF rA(x0 + 2.0F * (kw + kg), r3, x0 + 2.0F * (kw + kg) + 60.0F, r3 + kh), rB(rA.right + 10.0F, r3, rA.right + 70.0F, r3 + kh);
            stripToggle(c, fr, "FINGERED", fing && !silveton, C_AMBER, 11.0F);
            stripToggle(c, rA, "TIME", !rate && !silveton, C_AMBER, 11.0F);
            stripToggle(c, rB, "RATE", rate && !silveton, C_AMBER, 11.0F);
            if (!silveton) {
                hit(fr, [this, u, fing](float, float) { setUParam(u, 43, fing ? 0.0F : 1.0F); });
                hit(rA, [this, u](float, float) { setUParam(u, 44, 0.0F); });
                hit(rB, [this, u](float, float) { setUParam(u, 44, 1.0F); });
            } else fill(c, RectF(fr.left, r3, rB.right, r3 + kh), 8.0F, Color::argb(110, 0, 0, 0));
        }
        // the knobs: PORTA TIME, PITCH BEND
        const float cy = pD.top + 242.0F;
        if (silveton) {
            const float porta = portamentoUiValue(st.portamentoSec);
            auto setPorta = [this, st](float v) { UpperState n = currentUpper(st); n.portamentoSec = portamentoSecondsFromUi(v); commitTune(n); };
            knobControl(c, x0 + 65.0F, cy, 18.0F, porta, 0.0F, 100.0F, 1.0F, 300.0F, false, porta <= 0.0F ? std::string("OFF") : fmtFixed(static_cast<double>(porta), 2) + " ms", "PORTA TIME", 130.0F, setPorta,
                        [this, porta, setPorta] { showNumber("PORTAMENTO TIME ms (0 = OFF)", porta, 0.0F, 100.0F, 0, setPorta); },
                        [this, st] { UpperState n = currentUpper(st); n.portamentoSec = 0.0F; commitTune(n); });
        } else {
            knobControl(c, x0 + 65.0F, cy, 18.0F, kronosTime, 0.0F, 127.0F, 1.0F, 300.0F, false, kronosTime <= 0.0F ? std::string("OFF") : std::to_string(static_cast<int>(kronosTime)), mode == 1 ? "PORTA TIME 0–127" : "BASS TIME 0–127", 130.0F,
                        [this, u](float nv) { setUParam(u, 45, static_cast<float>(rndI(nv))); },
                        [this, u, kronosTime] { showNumber("PORTA TIME (0 = OFF)", kronosTime, 0.0F, 127.0F, 0, [this, u](float x) { setUParam(u, 45, static_cast<float>(rndI(x))); }); },
                        [this, u] { setUParam(u, 45, 0.0F); });
        }
        {
            const float bend = getOr(p, 48, 2.0F);
            knobControl(c, x0 + 65.0F + kw + kg, cy, 18.0F, bend, 0.0F, 24.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bend)) + " st", "PITCH BEND", 130.0F,
                        [this, u](float nv) { setUParam(u, 48, static_cast<float>(rndI(nv))); },
                        [this, u, bend] { showNumber("PITCH BEND RANGE (полутонове)", bend, 0.0F, 24.0F, 0, [this, u](float x) { setUParam(u, 48, static_cast<float>(rndI(x))); }); },
                        [this, u] { setUParam(u, 48, 2.0F); });
        }
        text(c, silveton ? "SILVETON: меко влизане, точно в TIME" : (mode == 1 ? "KRONOS: стегнато преливане" : "BASS: слайдът продължава със записа"), x0 + 2.0F * (kw + kg), cy + 6.0F, 11.0F, C_HINT, Opt().maxW(pD.right - x0 - 2.0F * (kw + kg) - 12.0F));
    }
}

// ---------------------------------------------------------------- values of the Upper's ENGINE (cached like the other pages)
std::vector<float> SilvetonSamplerView::eParams(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    return *slot;
}

float SilvetonSamplerView::engineP(int u, int id) {
    const std::vector<float> a = eParams(u);
    if (id >= 0 && id < static_cast<int>(a.size())) return a[static_cast<std::size_t>(id)];
    if (id == 0) return 0.0F;
    const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
    const EngineParamDef* d = sv::engineParamDef(type, id - 1);
    return d != nullptr ? d->def : 0.0F;
}

void SilvetonSamplerView::setEngineP(int u, int id, float v) {
    setEnginePOne(u, id, v);
    for (const int t : linkTargets(u)) setEnginePOne(t, id, v);
}

void SilvetonSamplerView::setEnginePOne(int u, int id, float v) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id, v);
    // the engine itself changed = its starting values were loaded: read everything again.
    // SILVETON_ENGINE_UPPER_ON_V1: choosing an engine on an empty Upper switches the Upper on in the engine - read the Upper
    // again too, or the next LEVEL / PAN / range move would send the old OFF back and the engine's sound would stop
    if (!ok || id == 0) { slot.reset(); refreshUpper(u); }
    // SILVETON_ENGINES_V3: the STR-1 INSTRUMENT loads its typical values - read them all again
    else if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && id == sv::ST_BODY_TYPE + 1) slot.reset();
    else {
        auto a = eParams(u);
        // SILVETON_MUSICAL_V1: the value as the engine keeps it (a RATIO jumps to its musical step)
        const auto type = static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1));
        if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = id >= 1 ? sv::engineClamp(type, id - 1, v) : v;
        slot = a;
        // SILVETON_ENGINE_WAVE_V1: a ВЪЛНА chosen on a set saved before (its level is 0 there) gets the starting level
        int wid = 0, lid = 0, oid = 0;
        if (v >= 0.5F && sv::engineWaveIds(type, wid, lid, oid) && id == wid + 1 && engineP(u, lid + 1) <= 0.0F) {
            const EngineParamDef* d = sv::engineParamDef(type, lid);
            if (d != nullptr) setEnginePOne(u, lid + 1, d->def);
        }
    }
    invalidate();
}

std::string SilvetonSamplerView::engineValueText(const EngineParamDef& d, float v) {
    switch (d.kind) {
        case EngineKind::Pct: return std::to_string(rndI(v * 100.0F)) + " %";
        case EngineKind::Hz: return v >= 1000.0F ? fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz" : (v >= 100.0F ? std::to_string(rndI(v)) + " Hz" : fmtFixed(static_cast<double>(v), 2) + " Hz");
        case EngineKind::Ms: return msTextE(v);
        case EngineKind::Sec: return fmtFixed(static_cast<double>(v), 2) + " s";
        case EngineKind::Oct: return (v > 0.004F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 2) + " oct";
        case EngineKind::Cents: return (v > 0.4F && d.lo < 0.0F ? "+" : std::string()) + std::to_string(rndI(v)) + " c";
        case EngineKind::Semis: return (v > 0.04F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " st";
        case EngineKind::Db: return (v > 0.04F && d.lo < 0.0F ? "+" : std::string()) + fmtFixed(static_cast<double>(v), 1) + " dB";
        case EngineKind::Choice: return choiceName(d, rndI(v) - rndI(d.lo));   // SILVETON_OCTAVE_V1: a choice may start below 0 (ОКТАВА -2..+2) or at 1 (SUB OCT)
        case EngineKind::Switch: return v >= 0.5F ? "ON" : "OFF";
        case EngineKind::Drawbar: return std::to_string(rndI(v));
        case EngineKind::Bend: return rndI(v) < 0 ? std::string("OFF") : (rndI(v) == 0 ? std::string("UPPER") : std::to_string(rndI(v)) + " st");
        case EngineKind::Lin: return d.decimals > 0 ? fmtFixed(static_cast<double>(v), d.decimals) : std::to_string(rndI(v));
    }
    return fmtFixed(static_cast<double>(v), 2);
}

// a knob of the ENGINE page
void SilvetonSamplerView::engineKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, const EngineParamDef& d) {
    const int id = d.id + 1;   // host id
    const float v = engineP(u, id);
    const bool bipolar = d.lo < 0.0F && d.kind != EngineKind::Bend;
    const std::string shown = engineValueText(d, v);
    const std::string label = d.label;
    const std::string hint = d.hint;
    if (logKind(d)) {
        knobControl(c, cx, cy, rad, toNorm(d, v), 0.0F, 1.0F, 0.002F, 260.0F, false, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, fromNorm(d, nv)); },
                    [this, u, id, d, v, hint] { showNumber(hint, v, d.lo, d.hi, d.decimals, [this, u, id](float x) { setEngineP(u, id, x); }); },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const bool pct = d.kind == EngineKind::Pct;
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, d.step, 260.0F, bipolar, shown, label, hw,
                    [this, u, id, d](float nv) { setEngineP(u, id, d.step >= 1.0F ? std::round(nv) : nv); },
                    [this, u, id, d, v, hint, pct] {
                        showNumber(hint, pct ? v * 100.0F : v, pct ? d.lo * 100.0F : d.lo, pct ? d.hi * 100.0F : d.hi, pct ? 0 : d.decimals,
                                   [this, u, id, pct](float x) { setEngineP(u, id, pct ? x / 100.0F : x); });
                    },
                    [this, u, id, d] { setEngineP(u, id, d.def); });
    }
}

// a key of the ENGINE page: a choice (tap = next, right button = first) or an ON / OFF switch.
// SILVETON_ENGINES_V3: a choice with many names (the waves) opens a window with all of them; the STR-1 STYLE shows the names
// of the chosen INSTRUMENT.
void SilvetonSamplerView::engineKey(Canvas& c, const RectF& r, int u, const EngineParamDef& dIn) {
    EngineParamDef d = dIn;
    if (static_cast<EngineType>(std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1)) == EngineType::Str1 && d.id == sv::ST_STYLE)
        d.names = sv::str1StyleNames(rndI(engineP(u, sv::ST_BODY_TYPE + 1)));
    const int id = d.id + 1;
    const float v = engineP(u, id);
    // SILVETON_OCTAVE_V2: ОКТАВА is  [ - ]  +1 OCT  [ + ]  - one tap = one octave, a tap on the middle = back to 0
    if (d.kind == EngineKind::Choice && rndI(d.lo) == -2 && rndI(d.hi) == 2) {
        const int cur = std::clamp(rndI(v), -2, 2);
        stripToggle(c, r, cur == 0 ? "0 OCT" : (cur > 0 ? "+" + std::to_string(cur) + " OCT" : std::to_string(cur) + " OCT"), cur != 0, C_AMBER, 11.0F);
        const float w = std::min(r.width() * 0.3F, 46.0F);
        const RectF lr(r.left, r.top, r.left + w, r.bottom), rr(r.right - w, r.top, r.right, r.bottom), mr(r.left + w, r.top, r.right - w, r.bottom);
        text(c, "-", lr.centerX(), lr.centerY() + 7.0F, 22.0F, C_KNOB_LABEL, Opt().center().bold());
        text(c, "+", rr.centerX(), rr.centerY() + 7.0F, 22.0F, C_KNOB_LABEL, Opt().center().bold());
        text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
        hit(lr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::max(cur - 1, -2))); });
        hit(rr, [this, u, id, cur](float, float) { setEngineP(u, id, static_cast<float>(std::min(cur + 1, 2))); });
        hit(mr, [](float, float) {}, [this, u, id] { setEngineP(u, id, 0.0F); });
        return;
    }
    const bool on = d.kind == EngineKind::Switch ? v >= 0.5F : rndI(v) != rndI(d.lo);
    stripToggle(c, r, engineValueText(d, v), on, C_AMBER, 11.0F);
    text(c, d.label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 8.0F));
    if (d.kind == EngineKind::Switch) {
        hit(r, [this, u, id, v](float, float) { setEngineP(u, id, v >= 0.5F ? 0.0F : 1.0F); }, [this, u, id, d] { setEngineP(u, id, d.def); });
    } else {
        const int n = choiceCount(d);
        const int cur = rndI(v) - rndI(d.lo);
        if (n > 6) {   // many names: a window with all of them
            std::vector<std::pair<std::string, std::string>> items;
            items.reserve(static_cast<std::size_t>(n));
            for (int k = 0; k < n; ++k) items.emplace_back(fmtZeroPad(k + rndI(d.lo), 2), choiceName(d, k));
            const std::string title = std::string(d.label) + " — избери и свири · допир извън прозореца = затваряне";
            hit(r, [this, u, id, d, cur, items, title](float, float) {
                    showGridPicker(title, items, cur, std::nullopt, [this, u, id, d](int k) { if (k >= 0) setEngineP(u, id, d.lo + static_cast<float>(k)); });
                    if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;   // stays open while choosing and playing
                },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        } else {
            hit(r, [this, u, id, d, cur, n](float, float) { setEngineP(u, id, d.lo + static_cast<float>((cur + 1) % std::max(1, n))); },
                [this, u, id, d] { setEngineP(u, id, d.def); });
        }
    }
}

// a CX-3 drawbar: a vertical slider, 0 (in) .. 8 (out); drag or tap sets it, right button = its starting value
void SilvetonSamplerView::engineDrawbar(Canvas& c, const RectF& r, int u, const EngineParamDef& d) {
    const int id = d.id + 1;
    const int v = std::clamp(rndI(engineP(u, id)), 0, 8);
    const float trackX = r.centerX();
    fill(c, RectF(trackX - 5.0F, r.top, trackX + 5.0F, r.bottom), 5.0F, darkTheme ? Color::rgb(16, 18, 16) : Color::rgb(40, 43, 48));
    const float stepH = (r.height() - 14.0F) / 8.0F;
    // the pulled-out part lights up
    const float y = r.top + 7.0F + stepH * static_cast<float>(v);
    if (v > 0) fill(c, RectF(trackX - 3.0F, r.top + 7.0F, trackX + 3.0F, y), 3.0F, C_ACCENT);
    for (int k = 0; k <= 8; k += 2) line(c, trackX - 11.0F, r.top + 7.0F + stepH * static_cast<float>(k), trackX - 7.0F, r.top + 7.0F + stepH * static_cast<float>(k), Color::argb(110, 255, 255, 255), 1.0F);
    // the handle
    const RectF h(trackX - 14.0F, y - 9.0F, trackX + 14.0F, y + 9.0F);
    shadow(c, h, 4.0F, 2.0F, 70);
    fillV(c, h, 4.0F, Color::rgb(236, 238, 241), Color::rgb(201, 204, 209));
    text(c, std::to_string(v), trackX, y + 4.0F, 10.0F, Color::rgb(48, 52, 58), Opt().center().bold());
    text(c, d.label, trackX, r.bottom + 16.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold());
    const auto set = [this, u, id, r, stepH](float, float yy) {
        const int nv = std::clamp(rndI((yy - r.top - 7.0F) / std::max(1.0F, stepH)), 0, 8);
        setEngineP(u, id, static_cast<float>(nv));
    };
    hit(RectF(r.left, r.top - 6.0F, r.right, r.bottom + 6.0F), set, [this, u, id, d] { setEngineP(u, id, d.def); },
        [set](float x, float yy, bool) { set(x, yy); });
}

// ---------------------------------------------------------------- the page
void SilvetonSamplerView::drawEngine(Canvas& c, const RectF& sec, int u) {
    using sv::engineName;
    const int typeIx = std::clamp(rndI(engineP(u, 0)), 0, sv::kEngineTypeCount - 1);
    const auto type = static_cast<EngineType>(typeIx);
    const bool slotMode = u >= 7;   // SILVETON_ENGINE_SLOTS_V2: an engine slot has its own page - the engine keys are in its header, here only the pages and knobs
    if (!slotMode) secTitle(c, sec, "ENGINE · UPPER " + std::to_string(u + 1) + " · " + sv::engineLine(type));

    // row A: the ten engines, then the pages of the chosen one (three, or four for the engines with a second page of their own)
    const float keyY0 = slotMode ? sec.top + 2.0F : sec.top + 26.0F, keyY1 = keyY0 + (slotMode ? 44.0F : 36.0F);
    const float enginesW = 700.0F;
    // SILVETON_MODEL_REMOVED_V1: the old engines and SILVETON MODEL are gone - the row of an Upper has only OFF (SILVETON SYNTH is put into a place of ДВИГАТЕЛИ)
    const EngineType shownKeys[1] = {EngineType::Off};
    const float kw = (enginesW - 4.0F) / 2.0F;
    for (int k = 0; k < (slotMode ? 0 : 1); ++k) {
        const EngineType kt = shownKeys[k];
        const float x0 = sec.left + static_cast<float>(k) * (kw + 4.0F);
        const RectF kr(x0, keyY0, x0 + kw, keyY1);
        stripToggle(c, kr, engineName(kt), typeIx == static_cast<int>(kt), C_ACCENT, 11.0F);
        hit(kr, [this, u, kt](float, float) {
            setEngineP(u, 0, static_cast<float>(static_cast<int>(kt)));
            enginePage_ = sv::engineOscPage(kt);   // SILVETON_ENGINES_PAGE_V2: opens on the oscillators
        });
    }
    // SILVETON_ENGINES_V2: ENGINE ON / OFF - OFF plays the plain recording and keeps every setting (to hear the difference)
    if (type != EngineType::Off && u < 7) {   // (an engine slot has its own ВКЛ / ИЗКЛ above - no second switch)
        const bool bypassed = engineP(u, sv::E_BYPASS + 1) >= 0.5F;
        const float x0 = sec.left + enginesW + 8.0F;
        const RectF br(x0, keyY0, x0 + 72.0F, keyY1);
        stripToggle(c, br, bypassed ? "OFF" : "ON", !bypassed, C_LCD_OK, 13.0F);
        hit(br, [this, u, bypassed](float, float) { setEngineP(u, sv::E_BYPASS + 1, bypassed ? 0.0F : 1.0F); });
    }
    const int pageCount = std::max(1, sv::enginePageCount(type));
    const int extraPages = 0;   // a SILVETON SYNTH place has ONE screen (drawModelOneScreen), no pages
    static const char* const kExtraNames[1] = {""};
    const int variant = type == EngineType::Str1 ? rndI(engineP(u, sv::ST_BODY_TYPE + 1)) : 0;   // SILVETON_ENGINES_V3: the winds have the ДЪХ page
    if (enginePage_ >= pageCount + extraPages) enginePage_ = 0;
    if (type != EngineType::Off) {
        const float pw = pageCount >= 5 ? 74.0F : 94.0F;   // SILVETON_ENGINES_PAGE_V2: five pages fit beside the ON key
        // SILVETON_ENGINES_PAGE_V3: the ОСЦ page is the FIRST key of every engine (the others keep their order after it)
        std::array<int, 8> order{};
        int cnt = 0;
        order[static_cast<std::size_t>(cnt++)] = std::clamp(sv::engineOscPage(type), 0, pageCount - 1);
        for (int k = 0; k < pageCount + extraPages && cnt < 8; ++k) if (k != order[0]) order[static_cast<std::size_t>(cnt++)] = k;
        for (int slotIx = 0; slotIx < pageCount + extraPages; ++slotIx) {
            const int k = order[static_cast<std::size_t>(slotIx)];
            const float spw = slotMode ? 126.0F : pw;
            const float x1 = slotMode ? sec.left + 4.0F + static_cast<float>(slotIx) * (spw + 10.0F)
                                      : sec.right - static_cast<float>(pageCount - slotIx) * (pw + 4.0F) + 4.0F;
            const RectF pr(x1, keyY0, x1 + spw, keyY1);
            stripToggle(c, pr, k >= pageCount ? kExtraNames[k - pageCount] : sv::enginePageName(type, k, variant), enginePage_ == k, C_AMBER, slotMode ? 13.0F : 11.0F);
            hit(pr, [this, k](float, float) { enginePage_ = k; invalidate(); });
        }
    }
    if (type == EngineType::Off) {
        if (slotMode) {   // SILVETON_ENGINE_SLOTS_V2
            text(c, "Това място е празно.", sec.centerX(), sec.top + 150.0F, 24.0F, C_VALUE, Opt().center().bold());
            text(c, "Натисни СЛОЖИ SILVETON SYNTH горе, после избери МОДЕЛ - наученото от семплите.", sec.centerX(), sec.top + 188.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
            text(c, "Можеш да пуснеш до 8 места наведнъж и да смесиш силата им отляво.", sec.centerX(), sec.top + 214.0F, 14.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
        } else {
            text(c, "Тук няма двигател: Upper-ът свири чист запис. SILVETON SYNTH се слага на място в ДВИГАТЕЛИ.", sec.left + 8.0F, sec.top + 110.0F, 13.0F, C_HINT, Opt().maxW(sec.width() - 16.0F));
        }
        return;
    }

    // the knobs and keys of the page: one or two rows
    const EngineParamPage pageAll = sv::enginePage(type, std::clamp(enginePage_, 0, pageCount - 1), variant);
    if (pageAll.count <= 0 || pageAll.items == nullptr) return;
    const EngineParamPage page = pageAll;
    const int n = page.count;
    const bool cx3Sound = type == EngineType::CX3 && enginePage_ == 0;
    const int cols = n <= 6 ? n : (cx3Sound ? std::max(12, n - 12) : (n + 1) / 2);   // SILVETON_ENGINE_WAVE_V1: up to 13 / 14 in a row
    const int firstRow = n <= 6 ? n : (cx3Sound ? 12 : (n + 1) / 2);
    const float unit = sec.width() / static_cast<float>(std::max(cols, 1));
    const float hw = std::min(unit - 4.0F, 150.0F);
    const float rad = 16.0F;
    const bool roomy = sec.height() > 360.0F;   // SILVETON_ENGINES_PAGE_V1: the page of its own has room - the rows do not touch
    const float r1 = n <= 6 ? sec.top + (roomy ? 190.0F : 150.0F) : sec.top + (roomy ? 140.0F : 102.0F);
    const float r2 = r1 + (roomy ? 150.0F : (darkTheme ? 96.0F : 86.0F));   // the dark theme prints the names above the knobs
    for (int i = 0; i < n; ++i) {
        const EngineParamDef& d = page.items[i];
        const bool second = i >= firstRow;
        const int col = second ? i - firstRow : i;
        const float cx = sec.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = second ? r2 : r1;
        switch (d.kind) {
            case EngineKind::Drawbar: engineDrawbar(c, RectF(cx - hw / 2.0F, cy - 36.0F, cx + hw / 2.0F, cy + 30.0F), u, d); break;
            case EngineKind::Choice:
            case EngineKind::Switch: engineKey(c, RectF(cx - hw / 2.0F + 2.0F, cy - 22.0F, cx + hw / 2.0F - 2.0F, cy + 22.0F), u, d); break;
            default: engineKnob(c, cx, cy, rad, hw, u, d); break;
        }
    }
}

} // namespace silveton::ui::classic
