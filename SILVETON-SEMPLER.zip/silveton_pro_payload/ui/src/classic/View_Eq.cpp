// SILVETON_MAC_VIEW_V1 - EQ page, analyzer, sound picker and the copy / link helpers (tablet lines 1700-2051 and 3263-3400)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float rndf(float v) { return std::nearbyint(v); }
float log10f_(float v) { return static_cast<float>(std::log10(static_cast<double>(v))); }
constexpr double kPi = 3.14159265358979323846;
std::string signedFixed(double v, int decimals) {   // "%+.Nf"
    std::string s = fmtFixed(v, decimals);
    if (s.empty() || s[0] != '-') s = "+" + s;
    return s;
}
} // namespace

// ---------------------------------------------------------------- SILVETON_EQ5_V1 page (finger design)
float SilvetonSamplerView::eqFreqX(float hz, float x0, float x1) { return x0 + (x1 - x0) * (log10f_(std::clamp(hz, 20.0F, 20000.0F) / 20.0F) / 3.0F); }
float SilvetonSamplerView::eqXFreq(float x, float x0, float x1) {
    return static_cast<float>(20.0 * std::pow(1000.0, static_cast<double>(std::clamp((x - x0) / (x1 - x0), 0.0F, 1.0F))));
}
float SilvetonSamplerView::eqGainY(float db, float y0, float y1) { return (y0 + y1) * 0.5F - (y1 - y0) * 0.5F * db / 18.0F; }
float SilvetonSamplerView::eqYGain(float y, float y0, float y1) { return std::clamp(((y0 + y1) * 0.5F - y) / ((y1 - y0) * 0.5F) * 18.0F, -18.0F, 18.0F); }

// Band b: 0 = HP, 1..5 = bands, 6 = LP. Parameter ids in the Upper params. `count` = how many ids the band has.
std::array<int, 4> SilvetonSamplerView::eqBandIds(int b, int& count) {
    if (b == 0) { count = 3; return {36, 37, 38, 0}; }
    if (b == 6) { count = 3; return {39, 40, 41, 0}; }
    count = 4;
    return {16 + (b - 1) * 4, 17 + (b - 1) * 4, 18 + (b - 1) * 4, 19 + (b - 1) * 4};
}

// Magnitude (dB) of the whole EQ at hz, analog prototypes (what the matched filters follow).
float SilvetonSamplerView::eqResponseDb(const std::vector<float>& p, float hz) {
    if (getOr(p, 15, 1.0F) < 0.5F) return 0.0F;
    double db = 0.0;
    const double w = static_cast<double>(hz);
    for (int b = 1; b <= 5; ++b) {
        int cnt = 0;
        const std::array<int, 4> ids = eqBandIds(b, cnt);
        if (getOr(p, ids[0], 1.0F) < 0.5F) continue;
        const double f0 = static_cast<double>(getOr(p, ids[1], 1000.0F));
        const double g = static_cast<double>(getOr(p, ids[2], 0.0F));
        const double q = std::max(static_cast<double>(getOr(p, ids[3], 0.7F)), 0.1);
        if (std::fabs(g) < 0.01) continue;
        const double A = std::pow(10.0, g / 40.0);
        const double w2 = w * w;
        const double f2 = f0 * f0;
        double mag;
        if (b == 1) {
            const double sa = std::sqrt(A);
            const double nr = A * f2 - w2, ni = sa * f0 * w, dr = f2 - A * w2, di = sa * f0 * w;
            mag = A * std::sqrt((nr * nr + ni * ni) / (dr * dr + di * di));
        } else if (b == 5) {
            const double sa = std::sqrt(A);
            const double nr = f2 - A * w2, ni = sa * f0 * w, dr = A * f2 - w2, di = sa * f0 * w;
            mag = A * std::sqrt((nr * nr + ni * ni) / (dr * dr + di * di));
        } else {
            const double d = (f2 - w2) * (f2 - w2);
            const double k = w * f0 / q;
            mag = std::sqrt((d + A * A * k * k) / (d + k * k / (A * A)));
        }
        db += 20.0 * std::log10(mag);
    }
    if (getOr(p, 36, 0.0F) >= 0.5F) {
        const double n = getOr(p, 38, 12.0F) >= 18.0F ? 4.0 : 2.0;
        const double r = w / static_cast<double>(getOr(p, 37, 40.0F));
        db += 20.0 * std::log10(std::pow(r, n) / std::sqrt(1.0 + std::pow(r, 2.0 * n)));
    }
    if (getOr(p, 39, 0.0F) >= 0.5F) {
        const double n = getOr(p, 41, 12.0F) >= 18.0F ? 4.0 : 2.0;
        const double r = w / static_cast<double>(getOr(p, 40, 18000.0F));
        db += 20.0 * std::log10(1.0 / std::sqrt(1.0 + std::pow(r, 2.0 * n)));
    }
    return std::clamp(static_cast<float>(db), -60.0F, 30.0F);
}

void SilvetonSamplerView::drawEqPage(Canvas& c) {
    const int u = selectedUpper_;
    const std::vector<float> p = uParams(u);
    const std::optional<UpperState> s = upperStates[static_cast<std::size_t>(u)];
    board(c, RectF(112.0F, 108.0F, 1326.0F, 786.0F));
    // display
    const RectF d(124.0F, 118.0F, 1314.0F, 466.0F);
    lcd(c, d, 8.0F);
    const float x0 = d.left + 30.0F, x1 = d.right - 30.0F, y0 = d.top + 14.0F, y1 = d.bottom - 24.0F;
    const std::pair<float, const char*> grid[8] = {{50.0F, "50"}, {100.0F, "100"}, {200.0F, "200"}, {500.0F, "500"}, {1000.0F, "1k"}, {2000.0F, "2k"}, {5000.0F, "5k"}, {10000.0F, "10k"}};
    for (const auto& g : grid) {
        const float x = eqFreqX(g.first, x0, x1);
        line(c, x, y0, x, y1, Color::rgb(34, 40, 44), 1.0F);
        text(c, g.second, x, d.bottom - 8.0F, 11.0F, Color::rgb(120, 150, 160), Opt().center().mono());
    }
    for (const int dbi : {-12, -6, 0, 6, 12}) {
        const float y = eqGainY(static_cast<float>(dbi), y0, y1);
        line(c, x0, y, x1, y, dbi == 0 ? Color::rgb(90, 100, 90) : Color::rgb(34, 40, 44), 1.0F);
        text(c, dbi == 0 ? std::string("0") : signedFixed(dbi, 0), d.left + 6.0F, y + 4.0F, 11.0F, Color::rgb(120, 150, 160), Opt().mono());
    }
    // analyzer
    if (analyzerOn) drawAnalyzer(c, u, x0, x1, y0, y1);
    // the curve
    const int n = 240;
    Path path;
    Path fillPath;
    for (int i = 0; i <= n; ++i) {
        const float hz = static_cast<float>(20.0 * std::pow(1000.0, static_cast<double>(i) / static_cast<double>(n)));
        const float x = x0 + (x1 - x0) * static_cast<float>(i) / static_cast<float>(n);
        const float y = eqGainY(std::clamp(eqResponseDb(p, hz), -18.0F, 18.0F), y0, y1);
        if (i == 0) { path.moveTo(x, y); fillPath.moveTo(x, y1); fillPath.lineTo(x, y); }
        else { path.lineTo(x, y); fillPath.lineTo(x, y); }
    }
    fillPath.lineTo(x1, y1);
    fillPath.close();
    paint.shader = nullptr;
    paint.style = Style::Fill;
    paint.color = Color::argb(50, 120, 200, 150);   // SILVETON_SERIOUS_V1: the curve in the display's own cool light
    c.drawPath(fillPath, paint);
    paint.style = Style::Stroke;
    paint.strokeWidth = 14.0F;
    paint.color = Color::argb(40, 140, 220, 170);
    c.drawPath(path, paint);
    paint.strokeWidth = 7.0F;
    paint.color = Color::argb(80, 150, 230, 180);
    c.drawPath(path, paint);
    paint.strokeWidth = 2.5F;
    paint.color = Color::rgb(232, 238, 240);
    c.drawPath(path, paint);
    paint.style = Style::Fill;
    // handles (registered after the display hit so they win)
    for (int b = 0; b <= 6; ++b) {
        int cnt = 0;
        const std::array<int, 4> ids = eqBandIds(b, cnt);
        const float hz = getOr(p, ids[1], 1000.0F);
        const float gain = (b >= 1 && b <= 5) ? getOr(p, ids[2], 0.0F) : 0.0F;
        const bool on = getOr(p, ids[0], 1.0F) >= 0.5F;
        const float x = eqFreqX(hz, x0, x1);
        const float y = eqGainY(std::clamp(gain, -18.0F, 18.0F), y0, y1);
        const bool sel = b == eqBand;
        const float r = sel ? 24.0F : 19.0F;
        if (sel) { paint.color = colorWithAlpha(C_ACCENT, 90); c.drawCircle(x, y, r + 16.0F, paint); }
        const ColorInt col = !on ? Color::rgb(110, 112, 116) : (sel ? C_ACCENT : ((b == 0 || b == 6) ? C_LCD_OK : C_LCD_VALUE));
        paint.color = Color::argb(160, 0, 0, 0); c.drawCircle(x, y + 3.0F, r, paint);
        paint.color = col; c.drawCircle(x, y, r, paint);
        paint.color = Color::argb(60, 0, 0, 0); c.drawCircle(x, y + r * 0.45F, r * 0.55F, paint);
        paint.color = col; c.drawCircle(x, y + r * 0.35F, r * 0.5F, paint);
        paint.color = Color::argb(110, 255, 255, 255); c.drawCircle(x - r * 0.25F, y - r * 0.35F, r * 0.35F, paint);
        text(c, b == 0 ? "HP" : (b == 6 ? "LP" : std::to_string(b)), x, y + 6.0F, sel ? 15.0F : 12.0F, sel ? Color::WHITE : Color::rgb(28, 30, 34), Opt().center().bold());
        const RectF hr(x - 34.0F, y - 34.0F, x + 34.0F, y + 34.0F);
        const int gainId = ids[2];
        const int freqId = ids[1];
        hit(hr, [this, b](float, float) { eqBand = b; },
            [this, u, b, gainId] { if (b >= 1 && b <= 5) setUParam(u, gainId, 0.0F); },
            [this, u, b, x0, x1, y0, y1, freqId, gainId](float px, float py, bool) {
                eqBand = b;
                setUParam(u, freqId, rndf(eqXFreq(px, x0, x1)));
                if (b >= 1 && b <= 5) setUParam(u, gainId, rndf(eqYGain(py, y0, y1) * 10.0F) / 10.0F);
            });
    }
    // analyzer keys in the display
    const std::pair<std::string, bool> ak[3] = {{"ANAL.", analyzerOn}, {analyzerAfter ? "POST EQ" : "PRE EQ", analyzerAfter}, {"PEAK", analyzerPeak}};
    for (int k = 0; k < 3; ++k) {
        const RectF kr(d.right - 20.0F - static_cast<float>(3 - k) * 118.0F, d.top + 10.0F, d.right - 20.0F - static_cast<float>(2 - k) * 118.0F - 8.0F, d.top + 42.0F);
        stripToggle(c, kr, ak[k].first, ak[k].second, k == 0 ? C_LCD_OK : C_AMBER, 11.0F);
        hit(kr, [this, k](float, float) {
            if (k == 0) analyzerOn = !analyzerOn;
            else if (k == 1) analyzerAfter = !analyzerAfter;
            else { analyzerPeak = !analyzerPeak; analyzerHold.clear(); }
        });
    }
    // band keys
    const float kw = (1314.0F - 124.0F - 6.0F * 8.0F) / 7.0F;
    for (int b = 0; b <= 6; ++b) {
        const RectF kr(124.0F + static_cast<float>(b) * (kw + 8.0F), 478.0F, 124.0F + static_cast<float>(b) * (kw + 8.0F) + kw, 522.0F);
        stripToggle(c, kr, b == 0 ? "HP" : (b == 6 ? "LP" : "BAND " + std::to_string(b)), eqBand == b, C_ACCENT, 14.0F);
        hit(kr, [this, b](float, float) { eqBand = b; });
    }
    // sliders of the chosen band
    int cnt = 0;
    const std::array<int, 4> ids = eqBandIds(eqBand, cnt);
    const bool isPass = eqBand == 0 || eqBand == 6;
    const float hz = getOr(p, ids[1], 1000.0F);
    auto hzText = [](float v) { return v < 1000.0F ? fmtFixed(static_cast<double>(v), 2) + " Hz" : fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz"; };
    const float fMin = eqBand == 6 ? 1000.0F : (eqBand == 0 ? 10.0F : 20.0F);
    const float fMax = eqBand == 0 ? 2000.0F : 20000.0F;
    const int idOn = ids[0], idF = ids[1], idG = ids[2], idQ = ids[3];
    eqSlider(c, RectF(124.0F, 534.0F, 700.0F, 600.0F), "FREQ", hzText(hz), std::clamp(lnf(hz / fMin) / lnf(fMax / fMin), 0.0F, 1.0F),
             [this, u, idF, fMin, fMax](float t) { setUParam(u, idF, rndf(static_cast<float>(fMin * std::pow(static_cast<double>(fMax / fMin), static_cast<double>(t))))); },
             [this, u, idF, hz, fMax] { setUParam(u, idF, std::min(hz * 1.02F, fMax)); },
             [this, u, idF, hz, fMin] { setUParam(u, idF, std::max(hz / 1.02F, fMin)); },
             [this, u, idF, hz, fMin, fMax] {
                 showNumber("BAND " + std::to_string(eqBand) + " FREQ Hz", hz, fMin, fMax, 0, [this, u, idF](float x) { setUParam(u, idF, x); });
             });
    if (!isPass) {
        const float gain = getOr(p, idG, 0.0F);
        eqSlider(c, RectF(124.0F, 610.0F, 700.0F, 676.0F), "GAIN", signedFixed(static_cast<double>(gain), 1) + " dB", (gain + 18.0F) / 36.0F,
                 [this, u, idG](float t) { setUParam(u, idG, rndf((t * 36.0F - 18.0F) * 10.0F) / 10.0F); },
                 [this, u, idG, gain] { setUParam(u, idG, std::min(gain + 0.5F, 18.0F)); },
                 [this, u, idG, gain] { setUParam(u, idG, std::max(gain - 0.5F, -18.0F)); },
                 [this, u, idG, gain] { showNumber("BAND " + std::to_string(eqBand) + " GAIN dB", gain, -18.0F, 18.0F, 1, [this, u, idG](float x) { setUParam(u, idG, x); }); });
        const float q = getOr(p, idQ, 0.7F);
        eqSlider(c, RectF(714.0F, 534.0F, 1314.0F, 600.0F), "Q", fmtFixed(static_cast<double>(q), 2), std::clamp(lnf(q / 0.1F) / lnf(100.0F), 0.0F, 1.0F),
                 [this, u, idQ](float t) { setUParam(u, idQ, rndf(static_cast<float>(0.1F * std::pow(100.0, static_cast<double>(t))) * 100.0F) / 100.0F); },
                 [this, u, idQ, q] { setUParam(u, idQ, std::min(q * 1.05F, 10.0F)); },
                 [this, u, idQ, q] { setUParam(u, idQ, std::max(q / 1.05F, 0.1F)); },
                 [this, u, idQ, q] { showNumber("BAND " + std::to_string(eqBand) + " Q", q, 0.1F, 10.0F, 2, [this, u, idQ](float x) { setUParam(u, idQ, x); }); });
    } else {
        const float slope = getOr(p, idG, 12.0F);
        const RectF a(124.0F, 610.0F, 400.0F, 676.0F);
        const RectF b(412.0F, 610.0F, 700.0F, 676.0F);
        stripToggle(c, a, "12 dB / OCT", slope < 18.0F, C_AMBER, 14.0F);
        stripToggle(c, b, "24 dB / OCT", slope >= 18.0F, C_AMBER, 14.0F);
        hit(a, [this, u, idG](float, float) { setUParam(u, idG, 12.0F); });
        hit(b, [this, u, idG](float, float) { setUParam(u, idG, 24.0F); });
    }
    const RectF onR(714.0F, 610.0F, 900.0F, 676.0F);
    const RectF eqR(912.0F, 610.0F, 1098.0F, 676.0F);
    const RectF zR(1110.0F, 610.0F, 1314.0F, 676.0F);
    const bool bandOn = getOr(p, idOn, 1.0F) >= 0.5F;
    stripToggle(c, onR, isPass ? (eqBand == 0 ? "HP ON" : "LP ON") : "BAND ON", bandOn, C_LCD_OK, 14.0F);
    hit(onR, [this, u, idOn, bandOn](float, float) { setUParam(u, idOn, bandOn ? 0.0F : 1.0F); });
    const bool eqOn = getOr(p, 15, 1.0F) >= 0.5F;
    stripToggle(c, eqR, "EQ ON", eqOn, C_LCD_OK, 14.0F);
    hit(eqR, [this, u, eqOn](float, float) { setUParam(u, 15, eqOn ? 0.0F : 1.0F); });
    lightKey(c, zR, "RESET", true, 14.0F);
    hit(zR, [this, u](float, float) {
        for (int b = 1; b <= 5; ++b) { int cc = 0; const std::array<int, 4> bi = eqBandIds(b, cc); setUParam(u, bi[2], 0.0F); }
        setUParam(u, 36, 0.0F);
        setUParam(u, 39, 0.0F);
        flash("EQ RESET U" + std::to_string(u + 1));
    });
    // bottom: title + back
    text(c, "UPPER " + std::to_string(u + 1) + " · " + (s ? s->soundName : std::string()) + " · EQ", 124.0F, 720.0F, 16.0F, C_VALUE, Opt().monoBold().maxW(800.0F));
    text(c, "drag a point: left/right = frequency · up/down = level · double tap a point = 0 dB · double tap a sound = ★", 124.0F, 748.0F, 11.0F, C_HINT, Opt().maxW(900.0F));
    const RectF back(1110.0F, 700.0F, 1314.0F, 760.0F);
    lightKey(c, back, "◀ SAMPLE", true, 14.0F);
    hit(back, [this](float, float) { tab = UpperTab::TUNE; });
    if (analyzerOn) postInvalidateDelayed(50);
}

// ---------------------------------------------------------------- SILVETON_NEW_LOOK_V1: the EQ group of SOUND EDIT (picture eq.png, gui/screens2.py eq())
// The same bands, parameter ids, touch logic and analyzer as the old full-screen page above, drawn inside the content panel (x 250..1310, y 214..636).
// drawEqPage / eqSlider stay for the old COMBI page (drawCombiOld); they can go when drawCombiOld goes.
void SilvetonSamplerView::drawEditEq(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const std::vector<float> p = uParams(u);
    const ColorInt gridCol = Color::rgb(35, 43, 51);      // #232b33
    const ColorInt zeroCol = Color::rgb(59, 70, 82);      // #3b4652
    const ColorInt axisCol = Color::rgb(127, 139, 152);   // #7f8b98

    // the display with the frequency / level grid
    const RectF d(250.0F, 214.0F, 1310.0F, 464.0F);
    nlLcd(c, d);
    const float x0 = d.left + 40.0F, x1 = d.right - 26.0F, y0 = d.top + 14.0F, y1 = d.bottom - 24.0F;
    const std::pair<float, const char*> grid[8] = {{50.0F, "50"}, {100.0F, "100"}, {200.0F, "200"}, {500.0F, "500"}, {1000.0F, "1k"}, {2000.0F, "2k"}, {5000.0F, "5k"}, {10000.0F, "10k"}};
    for (const auto& g : grid) {
        const float x = eqFreqX(g.first, x0, x1);
        line(c, x, y0, x, y1, gridCol, 1.0F);
        text(c, g.second, x, d.bottom - 8.0F, 10.0F, axisCol, Opt().center().mono());
    }
    for (const int dbi : {-12, -6, 0, 6, 12}) {
        const float y = eqGainY(static_cast<float>(dbi), y0, y1);
        line(c, x0, y, x1, y, dbi == 0 ? zeroCol : gridCol, 1.0F);
        text(c, signedFixed(dbi, 0), x0 - 8.0F, y + 4.0F, 10.0F, axisCol, Opt().right().mono());
    }
    // analyzer (unchanged)
    if (analyzerOn) drawAnalyzer(c, u, x0, x1, y0, y1);
    // the curve: one blue line
    {
        const int n = 240;
        Path path;
        for (int i = 0; i <= n; ++i) {
            const float hz = static_cast<float>(20.0 * std::pow(1000.0, static_cast<double>(i) / static_cast<double>(n)));
            const float x = x0 + (x1 - x0) * static_cast<float>(i) / static_cast<float>(n);
            const float y = eqGainY(std::clamp(eqResponseDb(p, hz), -18.0F, 18.0F), y0, y1);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        paint.shader = nullptr;
        paint.style = Style::Stroke;
        paint.strokeWidth = 3.5F;
        paint.color = NL_BLUE;
        c.drawPath(path, paint);
        paint.style = Style::Fill;
    }
    // the seven handles: HP, bands 1..5, LP. Ring: amber = chosen, grey = on, dashed = switched off. HP / LP sit at a fixed level (they only move along the frequency).
    for (int b = 0; b <= 6; ++b) {
        int cnt = 0;
        const std::array<int, 4> ids = eqBandIds(b, cnt);
        const bool pass = b == 0 || b == 6;
        const float hz = getOr(p, ids[1], 1000.0F);
        const float gain = pass ? -10.0F : getOr(p, ids[2], 0.0F);
        const bool on = getOr(p, ids[0], 1.0F) >= 0.5F;
        const bool sel = b == eqBand;
        const float x = eqFreqX(hz, x0, x1);
        const float y = eqGainY(std::clamp(gain, -18.0F, 18.0F), y0, y1);
        const float r = pass ? (sel ? 17.0F : 14.0F) : (sel ? 18.0F : 15.0F);
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = Color::rgb(11, 16, 20);
        c.drawCircle(x, y, r, paint);
        paint.style = Style::Stroke;
        paint.strokeWidth = 3.0F;
        paint.color = sel ? NL_AMBER : (on ? NL_MUT : Color::rgb(58, 63, 70));
        if (on) {
            c.drawCircle(x, y, r, paint);
        } else {
            for (int k = 0; k < 12; ++k) c.drawArc(RectF(x - r, y - r, x + r, y + r), static_cast<float>(k) * 30.0F, 18.0F, false, paint);
        }
        paint.style = Style::Fill;
        text(c, b == 0 ? "HP" : (b == 6 ? "LP" : std::to_string(b)), x, y + (pass ? 4.0F : 5.0F), pass ? 12.0F : 14.0F, sel ? NL_AMBER : (on ? Color::rgb(207, 214, 222) : NL_MUT),
             Opt().center().bold());
        const RectF hr(x - 34.0F, y - 34.0F, x + 34.0F, y + 34.0F);
        const int gainId = ids[2];
        const int freqId = ids[1];
        hit(hr, [this, b](float, float) { eqBand = b; },
            [this, u, b, gainId] { if (b >= 1 && b <= 5) setUParam(u, gainId, 0.0F); },
            [this, u, b, x0, x1, y0, y1, freqId, gainId](float px, float py, bool) {
                eqBand = b;
                setUParam(u, freqId, rndf(eqXFreq(px, x0, x1)));
                if (b >= 1 && b <= 5) setUParam(u, gainId, rndf(eqYGain(py, y0, y1) * 10.0F) / 10.0F);
            });
    }
    // analyzer keys in the display (ANAL. = on / off, AFTER EQ / BEFORE EQ = which signal, PEAK = peak hold)
    {
        const RectF kr[3] = {RectF(1084.0F, 222.0F, 1154.0F, 254.0F), RectF(1160.0F, 222.0F, 1246.0F, 254.0F), RectF(1252.0F, 222.0F, 1304.0F, 254.0F)};
        const std::string kl[3] = {"ANAL.", analyzerAfter ? "AFTER EQ" : "BEFORE EQ", "PEAK"};
        const bool kon[3] = {analyzerOn, analyzerAfter, analyzerPeak};
        for (int k = 0; k < 3; ++k) {
            e2Lit(c, kr[k], kl[k], std::string(), kon[k], k == 0 ? 11.0F : 10.5F, false);
            hit(kr[k], [this, k](float, float) {
                if (k == 0) analyzerOn = !analyzerOn;
                else if (k == 1) analyzerAfter = !analyzerAfter;
                else { analyzerPeak = !analyzerPeak; analyzerHold.clear(); }
            });
        }
    }
    // band keys: HP, BAND 1..5, LP
    for (int b = 0; b <= 6; ++b) {
        const RectF kr(250.0F + 153.0F * static_cast<float>(b), 474.0F, 397.0F + 153.0F * static_cast<float>(b), 514.0F);
        nlBtn(c, kr, b == 0 ? "HP" : (b == 6 ? "LP" : "BAND " + std::to_string(b)), eqBand == b ? NlBtn::Sel : NlBtn::Off, 13.0F, true);
        hit(kr, [this, b](float, float) { eqBand = b; });
    }
    // the chosen band: FREQ, GAIN, Q (HP / LP: FREQ and the slope 12 / 24 dB per octave)
    int cnt = 0;
    const std::array<int, 4> ids = eqBandIds(eqBand, cnt);
    const bool isPass = eqBand == 0 || eqBand == 6;
    const float hz = getOr(p, ids[1], 1000.0F);
    auto hzText = [](float v) { return v < 1000.0F ? fmtFixed(static_cast<double>(v), 2) + " Hz" : fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz"; };
    const float fMin = eqBand == 6 ? 1000.0F : (eqBand == 0 ? 10.0F : 20.0F);
    const float fMax = eqBand == 0 ? 2000.0F : 20000.0F;
    const int idOn = ids[0], idF = ids[1], idG = ids[2], idQ = ids[3];
    e2Slider(c, 250.0F, "FREQ", hzText(hz), std::clamp(lnf(hz / fMin) / lnf(fMax / fMin), 0.0F, 1.0F),
             [this, u, idF, fMin, fMax](float t) { setUParam(u, idF, rndf(static_cast<float>(fMin * std::pow(static_cast<double>(fMax / fMin), static_cast<double>(t))))); },
             [this, u, idF, hz, fMax] { setUParam(u, idF, std::min(hz * 1.02F, fMax)); },
             [this, u, idF, hz, fMin] { setUParam(u, idF, std::max(hz / 1.02F, fMin)); },
             [this, u, idF, hz, fMin, fMax] {
                 showNumber("BAND " + std::to_string(eqBand) + " FREQ Hz", hz, fMin, fMax, 0, [this, u, idF](float x) { setUParam(u, idF, x); });
             });
    if (!isPass) {
        const float gain = getOr(p, idG, 0.0F);
        e2Slider(c, 612.0F, "GAIN", signedFixed(static_cast<double>(gain), 1) + " dB", (gain + 18.0F) / 36.0F,
                 [this, u, idG](float t) { setUParam(u, idG, rndf((t * 36.0F - 18.0F) * 10.0F) / 10.0F); },
                 [this, u, idG, gain] { setUParam(u, idG, std::min(gain + 0.5F, 18.0F)); },
                 [this, u, idG, gain] { setUParam(u, idG, std::max(gain - 0.5F, -18.0F)); },
                 [this, u, idG, gain] { showNumber("BAND " + std::to_string(eqBand) + " GAIN dB", gain, -18.0F, 18.0F, 1, [this, u, idG](float x) { setUParam(u, idG, x); }); });
        const float q = getOr(p, idQ, 0.7F);
        e2Slider(c, 974.0F, "Q", fmtFixed(static_cast<double>(q), 2), std::clamp(lnf(q / 0.1F) / lnf(100.0F), 0.0F, 1.0F),
                 [this, u, idQ](float t) { setUParam(u, idQ, rndf(static_cast<float>(0.1F * std::pow(100.0, static_cast<double>(t))) * 100.0F) / 100.0F); },
                 [this, u, idQ, q] { setUParam(u, idQ, std::min(q * 1.05F, 10.0F)); },
                 [this, u, idQ, q] { setUParam(u, idQ, std::max(q / 1.05F, 0.1F)); },
                 [this, u, idQ, q] { showNumber("BAND " + std::to_string(eqBand) + " Q", q, 0.1F, 10.0F, 2, [this, u, idQ](float x) { setUParam(u, idQ, x); }); });
    } else {
        const float slope = getOr(p, idG, 12.0F);
        e2Label(c, "SLOPE", 612.0F, 522.0F);
        const RectF a(612.0F, 548.0F, 772.0F, 588.0F);
        const RectF b(780.0F, 548.0F, 940.0F, 588.0F);
        nlBtn(c, a, "12 dB / OCT", slope < 18.0F ? NlBtn::On : NlBtn::Off, 13.0F, true);
        nlBtn(c, b, "24 dB / OCT", slope >= 18.0F ? NlBtn::On : NlBtn::Off, 13.0F, true);
        hit(a, [this, u, idG](float, float) { setUParam(u, idG, 12.0F); });
        hit(b, [this, u, idG](float, float) { setUParam(u, idG, 24.0F); });
    }
    // BAND ON (HP ON / LP ON), EQ ON, RESET
    const RectF onR(250.0F, 596.0F, 400.0F, 636.0F);
    const RectF eqR(410.0F, 596.0F, 560.0F, 636.0F);
    const RectF zR(570.0F, 596.0F, 720.0F, 636.0F);
    const bool bandOn = getOr(p, idOn, 1.0F) >= 0.5F;
    e2Lit(c, onR, isPass ? (eqBand == 0 ? "HP ON" : "LP ON") : "BAND ON", std::string(), bandOn, 12.0F, true);
    hit(onR, [this, u, idOn, bandOn](float, float) { setUParam(u, idOn, bandOn ? 0.0F : 1.0F); });
    const bool eqOn = getOr(p, 15, 1.0F) >= 0.5F;
    e2Lit(c, eqR, "EQ ON", std::string(), eqOn, 12.0F, true);
    hit(eqR, [this, u, eqOn](float, float) { setUParam(u, 15, eqOn ? 0.0F : 1.0F); });
    nlBtn(c, zR, "RESET", NlBtn::Plain, 12.0F, true);
    hit(zR, [this, u](float, float) {
        for (int b = 1; b <= 5; ++b) { int cc = 0; const std::array<int, 4> bi = eqBandIds(b, cc); setUParam(u, bi[2], 0.0F); }
        setUParam(u, 36, 0.0F);
        setUParam(u, 39, 0.0F);
        flash("EQ RESET " + (u == 6 ? std::string("LOWER") : "U" + std::to_string(u + 1)));
    });
    if (analyzerOn) postInvalidateDelayed(50);
}

void SilvetonSamplerView::eqSlider(Canvas& c, const RectF& r, const std::string& label, const std::string& value, float t,
                                   std::function<void(float)> onDrag, std::function<void()> plus, std::function<void()> minus, std::function<void()> exact) {
    fill(c, r, 10.0F, Color::rgb(41, 44, 49));
    text(c, label, r.left + 14.0F, r.top + 30.0F, 12.0F, C_KNOB_LABEL, Opt().bold());
    const RectF vr(r.left + 90.0F, r.top + 8.0F, r.left + 290.0F, r.top + 42.0F);
    lcd(c, vr, 6.0F);
    text(c, value, vr.centerX(), vr.top + 25.0F, 17.0F, C_VALUE, Opt().center().mono());
    hit(vr, [exact](float, float) { exact(); });
    const RectF mR(r.right - 150.0F, r.top + 8.0F, r.right - 82.0F, r.bottom - 8.0F);
    const RectF pR(r.right - 74.0F, r.top + 8.0F, r.right - 6.0F, r.bottom - 8.0F);
    lightKey(c, mR, "−", true, 22.0F);
    lightKey(c, pR, "+", true, 22.0F);
    hit(mR, [minus](float, float) { minus(); });
    hit(pR, [plus](float, float) { plus(); });
    const float tx0 = r.left + 14.0F;
    const float tx1 = r.right - 166.0F;
    fill(c, RectF(tx0, r.bottom - 20.0F, tx1, r.bottom - 12.0F), 4.0F, Color::rgb(16, 18, 16));
    const float px = tx0 + (tx1 - tx0) * std::clamp(t, 0.0F, 1.0F);
    fill(c, RectF(tx0, r.bottom - 20.0F, px, r.bottom - 12.0F), 4.0F, C_ACCENT);
    paint.shader = nullptr;
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    c.drawCircle(px, r.bottom - 16.0F + 2.0F, 16.0F, paint);
    paint.color = Color::rgb(236, 238, 241);
    c.drawCircle(px, r.bottom - 16.0F, 16.0F, paint);
    hit(RectF(tx0 - 10.0F, r.top + 44.0F, tx1 + 10.0F, r.bottom), [onDrag, tx0, tx1](float x, float) { onDrag(std::clamp((x - tx0) / (tx1 - tx0), 0.0F, 1.0F)); }, nullptr,
        [onDrag, tx0, tx1](float x, float, bool) { onDrag(std::clamp((x - tx0) / (tx1 - tx0), 0.0F, 1.0F)); });
}

// ---------------------------------------------------------------- SILVETON_ANALYZER_V1 (FFT 8192, 1/12 oct, 3 dB/oct tilt, peak hold)
void SilvetonSamplerView::fft(std::vector<float>& re, std::vector<float>& im) {
    const int n = static_cast<int>(re.size());
    int j = 0;
    for (int i = 1; i < n; ++i) {
        int bit = n >> 1;
        while ((j & bit) != 0) { j ^= bit; bit >>= 1; }
        j ^= bit;
        if (i < j) {
            std::swap(re[static_cast<std::size_t>(i)], re[static_cast<std::size_t>(j)]);
            std::swap(im[static_cast<std::size_t>(i)], im[static_cast<std::size_t>(j)]);
        }
    }
    for (int len = 2; len <= n; len <<= 1) {
        const double ang = -2.0 * kPi / len;
        const float wr = static_cast<float>(std::cos(ang));
        const float wi = static_cast<float>(std::sin(ang));
        for (int i = 0; i < n; i += len) {
            float cr = 1.0F;
            float ci = 0.0F;
            for (int k = 0; k < len / 2; ++k) {
                const auto a = static_cast<std::size_t>(i + k);
                const auto b = static_cast<std::size_t>(i + k + len / 2);
                const float ar = re[a], ai = im[a];
                const float br = re[b] * cr - im[b] * ci;
                const float bi = re[b] * ci + im[b] * cr;
                re[a] = ar + br; im[a] = ai + bi;
                re[b] = ar - br; im[b] = ai - bi;
                const float ncr = cr * wr - ci * wi;
                ci = cr * wi + ci * wr;
                cr = ncr;
            }
        }
    }
}

void SilvetonSamplerView::drawAnalyzer(Canvas& c, int u, float x0, float x1, float y0, float y1) {
    if (fftWin.empty()) {
        fftRe.assign(8192U, 0.0F);
        fftIm.assign(8192U, 0.0F);
        fftWin.resize(8192U);
        float sum = 0.0F;
        for (int i = 0; i < 8192; ++i) {
            const double a = 2.0 * kPi * i / 8191.0;
            fftWin[static_cast<std::size_t>(i)] = static_cast<float>(0.35875 - 0.48829 * std::cos(a) + 0.14128 * std::cos(2.0 * a) - 0.01168 * std::cos(3.0 * a));
            sum += fftWin[static_cast<std::size_t>(i)];
        }
        fftWinSum = sum;
    }
    const std::int64_t now = nowMs();
    const int sr = frameAudioStatus.sampleRate > 0 ? frameAudioStatus.sampleRate : 96000;
    if (now - analyzerLastMs >= 46) {
        analyzerLastMs = now;
        const std::vector<float> frame = sampler.analyzerFrame(u, analyzerAfter);
        if (frame.size() >= 8192U) {
            for (std::size_t i = 0U; i < 8192U; ++i) { fftRe[i] = frame[i] * fftWin[i]; fftIm[i] = 0.0F; }
            fft(fftRe, fftIm);
            if (analyzerCurve.empty()) analyzerCurve.assign(static_cast<std::size_t>(kAnalyzerBins), -90.0F);
            if (analyzerHold.empty()) analyzerHold.assign(static_cast<std::size_t>(kAnalyzerBins), -90.0F);
            if (anSr != sr || anLo.empty()) {   // the frequency of every piece is worked out once per sample rate
                anSr = sr;
                anLo.assign(static_cast<std::size_t>(kAnalyzerBins), 1);
                anHi = anLo;
                anTilt.assign(static_cast<std::size_t>(kAnalyzerBins), 0.0F);
                const double binHz = static_cast<double>(sr) / 8192.0;
                for (int k = 0; k < kAnalyzerBins; ++k) {
                    const double hz = 20.0 * std::pow(1000.0, static_cast<double>(k) / static_cast<double>(kAnalyzerBins - 1));
                    const int lo = std::clamp(static_cast<int>(hz / std::pow(2.0, 1.0 / 24.0) / binHz), 1, 4095);
                    anLo[static_cast<std::size_t>(k)] = lo;
                    anHi[static_cast<std::size_t>(k)] = std::clamp(static_cast<int>(hz * std::pow(2.0, 1.0 / 24.0) / binHz), lo, 4095);
                    anTilt[static_cast<std::size_t>(k)] = 3.0F * (lnf(static_cast<float>(hz) / 1000.0F) / lnf(2.0F));
                }
            }
            for (int k = 0; k < kAnalyzerBins; ++k) {
                const int lo = anLo[static_cast<std::size_t>(k)];
                const int hi = anHi[static_cast<std::size_t>(k)];
                double e = 0.0;
                for (int b = lo; b <= hi; ++b) {
                    const auto bi = static_cast<std::size_t>(b);
                    e += static_cast<double>(fftRe[bi] * fftRe[bi] + fftIm[bi] * fftIm[bi]);
                }
                e /= static_cast<double>(hi - lo + 1);
                const double mag = std::sqrt(e) * 2.0 / static_cast<double>(fftWinSum);
                float db = static_cast<float>(20.0 * std::log10(mag + 1e-9)) + anTilt[static_cast<std::size_t>(k)];
                db = std::clamp(db, -90.0F, 0.0F);
                float& cur = analyzerCurve[static_cast<std::size_t>(k)];
                float& hold = analyzerHold[static_cast<std::size_t>(k)];
                cur = db > cur ? db : std::max(cur - 0.9F, db);
                hold = analyzerPeak ? std::max(db, hold - 0.08F) : -90.0F;
            }
        }
    }
    if (analyzerCurve.empty() || analyzerHold.empty()) return;
    const std::vector<float>& cur = analyzerCurve;
    const std::vector<float>& hold = analyzerHold;
    // SILVETON_ANALYZER_V2: only thin lines, cut into short pieces. Every piece is its own drawing operation with its own small box, so the
    // light drawing repaints just the pieces that moved (a filled area under the curve made the whole graph move every picture).
    auto sy = [&](float db) { return std::round(y1 - (y1 - y0) * (db + 90.0F) / 90.0F); };
    constexpr int kPiece = 8;   // 8 bins a piece; a point on every second bin is enough for a smooth line
    auto drawLine = [&](const std::vector<float>& v, float width, ColorInt color) {
        paint.style = Style::Stroke;
        paint.strokeWidth = width;
        paint.color = color;
        for (int k0 = 0; k0 < kAnalyzerBins - 1; k0 += kPiece) {
            const int k1 = std::min(k0 + kPiece, kAnalyzerBins - 1);
            Path lp;
            for (int k = k0; k <= k1; k += 2) {
                const float x = std::round(x0 + (x1 - x0) * static_cast<float>(k) / static_cast<float>(kAnalyzerBins - 1));
                if (k == k0) lp.moveTo(x, sy(v[static_cast<std::size_t>(k)])); else lp.lineTo(x, sy(v[static_cast<std::size_t>(k)]));
            }
            c.drawPath(lp, paint);
        }
    };
    drawLine(cur, 2.0F, Color::argb(230, 150, 205, 245));
    if (analyzerPeak) drawLine(hold, 1.0F, Color::argb(110, 230, 240, 250));
    paint.style = Style::Fill;
    for (const int db : {-20, -40, -60, -80}) text(c, std::to_string(db), x1 + 4.0F, sy(static_cast<float>(db)) + 4.0F, 11.0F, Color::rgb(100, 140, 170), Opt().mono());
}

// Title, value window and two big keys - / +. Both keys at the same time = onReset.
void SilvetonSamplerView::stepper(Canvas& c, const RectF& r, const std::string& title, const std::string& value,
                                  std::function<void()> onMinus, std::function<void()> onPlus, std::function<void()> onReset) {
    text(c, title, r.centerX(), r.top + 14.0F, 12.0F, C_KNOB_LABEL, Opt().center().bold().spacing(0.12F).maxW(r.width()));
    const RectF box(r.left + 30.0F, r.top + 26.0F, r.right - 30.0F, r.top + 74.0F);
    lcd(c, box, 8.0F);
    text(c, value, box.centerX(), box.centerY() + 10.0F, 28.0F, C_LCD, Opt().center().mono());
    hit(box, [](float, float) {}, onReset);   // double tap on the value = 0
    const float kw = (r.width() - 12.0F) / 2.0F;
    const RectF minus(r.left, r.top + 86.0F, r.left + kw, r.bottom);
    const RectF plus(minus.right + 12.0F, r.top + 86.0F, r.right, r.bottom);
    stripToggle(c, minus, "−", false, C_AMBER, 34.0F);
    stripToggle(c, plus, "+", false, C_AMBER, 34.0F);
    hit(minus, [this, onMinus](float, float) { onMinus(); invalidate(); });
    hit(plus, [this, onPlus](float, float) { onPlus(); invalidate(); });
    pairHits.push_back(PairHit{minus, plus, [this, onReset] { onReset(); invalidate(); }});
}

void SilvetonSamplerView::copyUpper(int u) {
    if (u < 0 || u > 6) return;
    std::optional<UpperState> st = sampler.upperState(u);
    if (!st) st = upperStates[static_cast<std::size_t>(u)];
    if (!st) return;
    std::optional<SoundItem> sound;
    const int soundId = sampler.upperSoundSlot(u);
    if (soundId > 0) sound = SoundItem{0, 0, soundId, st->soundName};
    UpperClip clip;
    clip.from = u;
    clip.bankSerial = sampler.bankSerial();
    clip.state = *st;
    clip.params = sampler.upperParams(u);
    for (int l = 0; l < 4; ++l) clip.layerParams.push_back(sampler.layerParams(u, l));
    for (int slot = 0; slot < 5; ++slot) {
        clip.sources[static_cast<std::size_t>(slot)]=sampler.soundSource(u,slot);
        clip.waveParams[static_cast<std::size_t>(slot)] = sampler.soundWaveParams(u, slot);
        clip.synthParams[static_cast<std::size_t>(slot)] = sampler.soundSynthParams(u, slot);
    }
    clip.insert = sampler.fxParams(4 + u);
    clip.engine = sampler.upperEngineParams(u);   // SILVETON_ENGINES_V1
    clip.sound = sound;
    clip.terca = sampler.tercaChosen(u);
    clip.quarter = sampler.quarterChosen(u);
    copiedClip = clip;
    flash("COPIED WHOLE " + neUpperName(u) + " — SOUNDS, LAYERS, ENGINE, FX AND SETTINGS");
    invalidate();
}

void SilvetonSamplerView::pasteUpper(int target) {
    if (!copiedClip || target < 0 || target > 6) return;
    const UpperClip clip = *copiedClip;
    if (clip.bankSerial != sampler.bankSerial()) {
        showMessage("PART CLIPBOARD", "The sound bank or SET changed. Copy the part again before pasting.");
        return;
    }
    std::vector<int> targets{target};
    for (const int t : linkTargets(target)) targets.push_back(t);   // ЛИНК: the marked ones get the same
    const auto apply = [this, clip, targets, target] {
        if (clip.bankSerial != sampler.bankSerial()) { showMessage("PART CLIPBOARD", "The bank or SET changed. Copy the part again."); return; }
        for (const int t : targets) if (!pasteOne(clip, t)) {
            showMessage("PART PASTE STOPPED", failureText(sampler.lastFailure()) + "\nCheck the destination before continuing.");
            invalidate();
            return;
        }
        flash(targets.size() > 1U ? "PASTED " + neUpperName(clip.from) + " TO " + std::to_string(targets.size()) + " PARTS"
                                  : "PASTED " + neUpperName(clip.from) + " TO " + neUpperName(target));
        invalidate();
    };
    bool occupied = false;
    std::string names;
    for (const int t : targets) {
        if (!names.empty()) names += ", ";
        names += neUpperName(t);
        occupied = occupied || sampler.upperSoundSlot(t) > 0 || getOr(sampler.upperEngineParams(t), 0, 0.0F) != 0.0F;
        for (int l = 0; l < 4; ++l) occupied = occupied || soundSlotHas(t,l+1);
    }
    if (occupied) showConfirm("PASTE WHOLE PART", "Replace " + names + " with the copied " + neUpperName(clip.from) +
                              "?\nThis copies all five sounds, their settings, the engine and insert effect.", "PASTE PART", apply);
    else apply();
}

bool SilvetonSamplerView::pasteOne(const UpperClip& clip, int t) {
    if (t < 0 || t > 6 || clip.layerParams.size() != 4U) return false;
    const UpperState& src = clip.state;
    if(!sampler.putSoundSource(t,0,clip.sources[0]))return false;
    lastPickedSound[static_cast<std::size_t>(t)]=clip.sound;
    // 2 the six groups of the Upper (ON / SOLO / MUTE, level, pan, zones, voice mode, tune, controllers, MIDI channel, tone, FX sends)
    if (!sampler.updateUpperMain(t, src) || !sampler.updateUpperTune(t, src) || !sampler.updateUpperRange(t, src) ||
        !sampler.updateUpperControl(t, src) || !sampler.updateUpperTone(t, src) || !sampler.updateUpperFx(t, src)) return false;
    const float tone[6] = {src.toneAttackMs, src.toneDecayMs, src.toneSustain, src.toneReleaseMs, src.toneCutoffHz, src.toneResonance};
    for (int k = 0; k < 6; ++k) if (!sampler.setUpperTone(t, k, ((src.toneSet >> k) & 1) != 0 ? tone[k] : -1.0F)) return false;
    // 3 all extra Upper parameters (tone extras, EQ bands, HP / LP, portamento, sends 3 / 4, pitch bend)
    for (std::size_t id = 0U; id < clip.params.size(); ++id) if (!sampler.setUpperParam(t, static_cast<int>(id), clip.params[id])) return false;
    // 4 the four layers: sound first, then their own settings
    for (int l = 0; l < 4; ++l) {
        const std::vector<float>& lp = clip.layerParams[static_cast<std::size_t>(l)];
        if (!sampler.putSoundSource(t,l+1,clip.sources[static_cast<std::size_t>(l+1)])) return false;
        // every value of the layer (31 = the SOUND slot, already set above; SILVETON_VELOCITY_V1: the velocity shape is 35..47)
        for (int id = 0; id < static_cast<int>(lp.size()); ++id)
            if (id != 31 && !sampler.setLayerParam(t, l, id, lp[static_cast<std::size_t>(id)])) return false;
    }
    // WAVE and the per-sound synth/modulation matrix have their own parameter APIs.
    // They must travel with all five places, including currently empty layers.
    for (int slot = 0; slot < 5; ++slot) {
        const auto& wave = clip.waveParams[static_cast<std::size_t>(slot)];
        const auto& synth = clip.synthParams[static_cast<std::size_t>(slot)];
        for (std::size_t id = 0; id < wave.size(); ++id)
            if (!sampler.setSoundWaveParam(t, slot, static_cast<int>(id), wave[id])) return false;
        for (std::size_t id = 0; id < synth.size(); ++id)
            if (!sampler.setSoundSynthParam(t, slot, static_cast<int>(id), synth[id])) return false;
        waveParamsCache[static_cast<std::size_t>(t)][static_cast<std::size_t>(slot)].reset();
    }
    // 5 the INSERT effect of this Upper
    for (std::size_t id = 0U; id < clip.insert.size(); ++id) if (!sampler.setFxParam(4 + t, static_cast<int>(id), clip.insert[id])) return false;
    // Apply the complete engine patch in one state publication. A sequence of method
    // setters can reset later parameters and needlessly clone hundreds of states.
    if (!clip.engine.empty() && !sampler.setUpperEngineBlock(t, 0, clip.engine)) return false;
    // Choosing an engine may auto-enable an empty part; the clipboard's ON/MUTE wins.
    if (!sampler.updateUpperMain(t, src)) return false;
    engineParamsCache[static_cast<std::size_t>(t)].reset();
    // 6 T / Q
    int guard = 0;
    while (sampler.tercaChosen(t) != clip.terca && guard++ < 2) sampler.toggleTerca(t);
    guard = 0;
    while (sampler.quarterChosen(t) != clip.quarter && guard++ < 2) sampler.toggleQuarter(t);
    fxParamsCache[static_cast<std::size_t>(4 + t)].reset();
    refreshUpper(t);
    return true;
}

// ЛИНК: T / Q of the marked Uppers follow (same on / off).
void SilvetonSamplerView::toggleTercaLinked(int i) {
    sampler.toggleTerca(i);
    const bool want = sampler.tercaChosen(i);
    for (const int t : linkTargets(i)) { int g = 0; while (sampler.tercaChosen(t) != want && g++ < 2) sampler.toggleTerca(t); }
}

void SilvetonSamplerView::toggleQuarterLinked(int i) {
    sampler.toggleQuarter(i);
    const bool want = sampler.quarterChosen(i);
    for (const int t : linkTargets(i)) { int g = 0; while (sampler.quarterChosen(t) != want && g++ < 2) sampler.toggleQuarter(t); }
}

// ЛИНК: the sound just chosen (or removed) on a marked Upper goes to the other marked Uppers. layer < 0 = main sound.
void SilvetonSamplerView::mirrorSound(int u, int layer) {
    const auto source=sampler.soundSource(u,layer+1);
    for (const int t : linkTargets(u)) {
        if(!sampler.putSoundSource(t,layer+1,source)){showMessage("LINK FAILED",failureText(sampler.lastFailure()));return;}
        if(layer<0)lastPickedSound[static_cast<std::size_t>(t)].reset();
        refreshUpper(t);
    }
}

void SilvetonSamplerView::flash(const std::string& message) {
    flashText = message;
    flashUntilMs = nowMs() + 3500;
    invalidate();
}

void SilvetonSamplerView::scanKey(Canvas& c, const RectF& r, int mode, const std::string& label) {
    const bool on = scanMode == mode;
    const bool blink = on && (nowMs() / 300) % 2 == 0;
    const std::vector<std::string> lines = splitChar(on ? std::string("SCAN…\nPLAY THE NOTES") : label, '\n');
    stripToggle(c, r, "", on, blink ? C_ACCENT : C_AMBER, 13.0F);
    for (std::size_t k = 0U; k < lines.size(); ++k) {
        text(c, lines[k], r.centerX(), r.centerY() + 5.0F + (static_cast<float>(k) - static_cast<float>(lines.size() - 1U) / 2.0F) * 18.0F, 13.0F,
             on ? Color::WHITE : C_TOGGLE_TEXT, Opt().center().bold().maxW(r.width() - 6.0F));
    }
    hit(r, [this, mode](float, float) {
        if (scanMode == mode) sampler.cancelScan();
        else if (mode == 1) sampler.startTercaScan();
        else sampler.startScaleScan();
        scanMode = sampler.pollScan();
        invalidate();
    });
}

std::string SilvetonSamplerView::tercaText(const Ctrl::TercaState& t) {
    if (t.root >= 0 && t.root <= 11 && t.cell >= 0 && t.cell <= 5)
        return Ctrl::NOTE_NAMES()[static_cast<std::size_t>(t.root)] + " " + Ctrl::TERCA_CELLS()[static_cast<std::size_t>(t.cell)];
    return "—";
}

void SilvetonSamplerView::cellKey(Canvas& c, const RectF& r, const std::string& title, const std::string& value, std::function<void()> tap,
                                  const std::optional<bool>& on) {
    if (on) {
        stripToggle(c, r, title + "  " + (*on ? "ON" : "OFF"), *on, C_AMBER, 15.0F);
    } else {
        fill(c, r, 10.0F, C_STRIP);
        text(c, title, r.left + 12.0F, r.top + 18.0F, 11.0F, C_LABEL_GREY, Opt().bold().spacing(0.1F).maxW(r.width() - 20.0F));
        text(c, value, r.left + 12.0F, r.bottom - 12.0F, 19.0F, C_INK, Opt().monoBold().maxW(r.width() - 20.0F));
    }
    hit(r, [this, tap](float, float) { tap(); invalidate(); });
}

} // namespace silveton::ui::classic
