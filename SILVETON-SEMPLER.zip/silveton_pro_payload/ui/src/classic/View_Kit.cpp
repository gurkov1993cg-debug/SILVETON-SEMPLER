// SILVETON_MAC_VIEW_V1 - the drawing kit (tablet SilvetonSamplerView.kt lines 3556-4141)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
constexpr double kPi = 3.14159265358979323846;
float log10f_(float v) { return std::log10(v); }
} // namespace

void SilvetonSamplerView::fill(Canvas& c, const RectF& r, float radius, ColorInt color) {
    paint.shader = nullptr;
    paint.style = Style::Fill;
    paint.color = color;
    if (radius <= 0.0F) c.drawRect(r, paint); else c.drawRoundRect(r, radius, radius, paint);
}

void SilvetonSamplerView::fillV(Canvas& c, const RectF& r, float radius, ColorInt top, ColorInt bottom) {
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    paint.shader = linearGradient(0.0F, r.top, 0.0F, r.bottom, top, bottom, TileMode::Clamp);
    c.drawRoundRect(r, radius, radius, paint);
    paint.shader = nullptr;
}

void SilvetonSamplerView::shadow(Canvas& c, const RectF& r, float radius, float dy, int alpha) {
    fill(c, RectF(r.left - 1.0F, r.top + dy - 0.5F, r.right + 1.0F, r.bottom + dy + 1.5F), radius + 1.0F, Color::argb(alpha / 2, 0, 0, 0));
    fill(c, RectF(r.left, r.top + dy, r.right, r.bottom + dy), radius, Color::argb(alpha, 0, 0, 0));
}

void SilvetonSamplerView::line(Canvas& c, float x1, float y1, float x2, float y2, ColorInt color, float w) {
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = w;
    paint.color = color;
    c.drawLine(x1, y1, x2, y2, paint);
    paint.style = Style::Fill;
}

void SilvetonSamplerView::text(Canvas& c, const std::string& s, float x, float y, float size, ColorInt color, const Opt& o) {
    if (colorTheme() == 3 && Color::alpha(color) == 255 && !glass_.empty()) {   // SILVETON_COLOR_KEYS_V1: light writing on a dark display stays light in CLASSIC
        const float py = y - size * 0.3F;
        for (const RectF& g : glass_) {
            if (x >= g.left - 6.0F && x <= g.right + 6.0F && py >= g.top && py <= g.bottom) { color = (color & 0x00FFFFFFU) | 0xFE000000U; break; }
        }
    }
    paint.shader = nullptr;
    paint.style = Style::Fill;
    paint.color = color;
    paint.textSize = size;
    paint.typeface = o.face_;
    paint.letterSpacing = o.spacing_;
    paint.textAlign = o.center_ ? Align::Center : (o.right_ ? Align::Right : Align::Left);
    std::string shown = s;
    const float maxWidth = o.maxWidth_;
    if (maxWidth != std::numeric_limits<float>::infinity() && maxWidth > 1.0F) {
        const float measured = paint.measureText(shown);
        if (measured > maxWidth) {
            paint.textSize = std::max(size * 0.55F, size * (maxWidth / measured));   // SILVETON_FIT_V1: a long name gets smaller, dots only as a last resort
            if (paint.measureText(shown) > maxWidth) {
                const std::string ell = "…";
                const float room = std::max(0.0F, maxWidth - paint.measureText(ell));
                int count = utf8Length(shown);
                while (count > 0 && paint.measureText(shown, 0, count) > room) --count;
                shown = count <= 0 ? ell : utf8Prefix(shown, count) + ell;
            }
        }
    }
    c.drawText(shown, x, y, paint);
    paint.textAlign = Align::Left;
    paint.letterSpacing = 0.0F;
}

void SilvetonSamplerView::soundNameText(Canvas& c, const RectF& r, const std::string& name, ColorInt color) {
    const float maxW = r.width() - 14.0F;
    const float size = 15.0F;
    if (textWidth(name, size, Face::Bold) <= maxW) {
        text(c, name, r.centerX(), r.centerY() + size * 0.36F, size, color, Opt().center().bold().maxW(maxW));
        return;
    }
    // the best place to break the name in two lines: a blank, so that the longer half is as short as possible
    int best = -1;
    float bestW = std::numeric_limits<float>::max();
    const int n = utf8Length(name);
    for (int k = 0; k < n; ++k) {
        if (utf8Substring(name, k, k + 1) == " ") {
            const float w = std::max(textWidth(utf8Substring(name, 0, k), size, Face::Bold), textWidth(utf8Substring(name, k + 1, n), size, Face::Bold));
            if (w < bestW) { bestW = w; best = k; }
        }
    }
    if (best < 0) {
        text(c, name, r.centerX(), r.centerY() + size * 0.36F, size, color, Opt().center().bold().maxW(maxW));
        return;
    }
    text(c, utf8Substring(name, 0, best), r.centerX(), r.centerY() - 2.0F, size, color, Opt().center().bold().maxW(maxW));
    text(c, utf8Substring(name, best + 1, n), r.centerX(), r.centerY() + 15.0F, size, color, Opt().center().bold().maxW(maxW));
}

float SilvetonSamplerView::textWidth(const std::string& s, float size, Face face, float spacing) {
    paint.textSize = size;
    paint.typeface = face;
    paint.letterSpacing = spacing;
    const float w = paint.measureText(s);
    paint.letterSpacing = 0.0F;
    return w;
}

void SilvetonSamplerView::led(Canvas& c, float x, float y, bool on, float radius, bool light) {
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    if (on) {
        paint.shader = radialGradient(x, y, radius * 2.8F, colorWithAlpha(NL_BLUE, 120), colorWithAlpha(NL_BLUE, 0), TileMode::Clamp);   // SILVETON_NEW_LOOK_V1: blue lamp
        c.drawCircle(x, y, radius * 2.8F, paint);
        paint.shader = radialGradient(x - radius * 0.3F, y - radius * 0.3F, radius * 1.2F, Color::rgb(214, 238, 255), NL_BLUE, TileMode::Clamp);
    } else {
        const ColorInt base = light ? C_LED_OFF_LIGHT : C_LED_OFF;
        paint.shader = radialGradient(x - radius * 0.3F, y - radius * 0.3F, radius * 1.2F, lighten(base, 30), base, TileMode::Clamp);
    }
    c.drawCircle(x, y, radius, paint);
    paint.shader = nullptr;
}

void SilvetonSamplerView::navKey(Canvas& c, const RectF& r, bool on) {
    shadow(c, r, 12.0F, 2.0F, 100);
    if (darkTheme) {   // SILVETON_THEME_V1: lit = on
        if (on) { fill(c, r, 12.0F, C_KEY_ON); litGlow(c, r, 12.0F, C_LOGO); }
        else fillV(c, r, 12.0F, Color::rgb(72, 76, 86), Color::rgb(58, 62, 70));
    } else {
        fillV(c, r, 12.0F, on ? Color::rgb(66, 69, 75) : Color::rgb(50, 53, 58), on ? Color::rgb(54, 57, 63) : Color::rgb(41, 44, 49));
    }
    line(c, r.left + 10.0F, r.top + 1.0F, r.right - 10.0F, r.top + 1.0F, C_NAV_EDGE, 1.0F);
    if (isDown(r)) fill(c, r, 12.0F, Color::argb(70, 0, 0, 0));
}

// SILVETON_THEME_V1: a soft inner glow of a lit key (no blur filters: a few translucent rings)
void SilvetonSamplerView::litGlow(Canvas& c, const RectF& r, float radius, ColorInt color) {
    for (int k = 0; k < 4; ++k) {
        const float inset = 2.0F + static_cast<float>(k) * 3.0F;
        fill(c, RectF(r.left + inset, r.top + inset, r.right - inset, r.bottom - inset), std::max(2.0F, radius - inset), colorWithAlpha(color, 14 + k * 6));
    }
}

void SilvetonSamplerView::lightKey(Canvas& c, const RectF& r, const std::string& label, bool enabled, float size, float radius) {
    const bool down = enabled && isDown(r);
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1
        (void)radius;
        nlBtn(c, r, label, enabled ? NlBtn::Plain : NlBtn::Off, size, false);
        return;
    }
    if (!down) shadow(c, r, radius, 4.0F, 90);   // SILVETON_LOOK_V2: relief
    fill(c, r, radius, Color::rgb(150, 154, 162));
    const RectF face(r.left + 1.0F, r.top + (down ? 2.0F : 1.0F), r.right - 1.0F, r.bottom - (down ? 1.0F : 3.0F));
    if (!enabled) fill(c, face, radius - 1.0F, Color::rgb(214, 216, 220));
    else if (down) fill(c, face, radius - 1.0F, Color::rgb(205, 208, 214));
    else fillV(c, face, radius - 1.0F, Color::rgb(248, 249, 251), Color::rgb(214, 216, 221));
    if (enabled && !down) line(c, face.left + radius, face.top + 1.0F, face.right - radius, face.top + 1.0F, Color::WHITE, 1.5F);
    text(c, label, r.centerX(), r.centerY() + size * 0.36F, size, enabled ? C_KEY_TEXT : C_EMPTY_TEXT,
         Opt().center().bold().spacing(0.1F).maxW(r.width() - 16.0F));
}

void SilvetonSamplerView::darkKey(Canvas& c, const RectF& r, const std::string& label) {
    const bool down = isDown(r);
    fill(c, r, 6.0F, Color::BLACK);
    fill(c, RectF(r.left, r.top, r.right, r.bottom - (down ? 0.5F : 2.0F)), 6.0F, down ? Color::rgb(28, 30, 34) : C_DARK_KEY);
    text(c, label, r.centerX(), r.centerY() + 4.0F, 11.0F, C_VALUE, Opt().center().monoBold().spacing(0.06F).maxW(r.width() - 8.0F));
}

// SILVETON_LIT_V1: which colour a switched-on key lights in (the callers still name the old amber for "the usual on")
ColorInt SilvetonSamplerView::litFill(ColorInt onColor) {
    if (onColor == C_AMBER) return C_ACCENT;                 // the usual "on": green
    if (onColor == C_LCD_OK) return C_ACCENT;                // also green
    if (onColor == C_SOLO) return C_YELLOW;                  // SOLO: yellow
    if (onColor == C_LCD_DIM) return Color::rgb(112, 122, 134);   // chosen here but switched off elsewhere: dim grey
    return onColor;                                          // MUTE red, blinking SCAN, ...
}

ColorInt SilvetonSamplerView::litText(ColorInt fill) {
    const int lum = (Color::red(fill) * 54 + Color::green(fill) * 183 + Color::blue(fill) * 18) / 255;
    return lum > 165 ? Color::rgb(28, 30, 34) : Color::WHITE;
}

void SilvetonSamplerView::litKey(Canvas& c, const RectF& r, float radius, ColorInt color, bool down) {
    const ColorInt fillC = litFill(color);
    const int dr = Color::red(fillC) * 2 / 3, dg = Color::green(fillC) * 2 / 3, db = Color::blue(fillC) * 2 / 3;
    fill(c, r, radius, Color::rgb(dr, dg, db));
    const RectF face(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - (down ? 1.0F : 3.0F));
    if (down) fill(c, face, radius - 1.0F, fillC);
    else fillV(c, face, radius - 1.0F, lighten(fillC, 26), fillC);
    if (!down) line(c, face.left + radius, face.top + 1.0F, face.right - radius, face.top + 1.0F, colorWithAlpha(Color::WHITE, 110), 1.0F);
}

void SilvetonSamplerView::stripToggle(Canvas& c, const RectF& r, const std::string& label, bool on, ColorInt onColor, float size) {
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1: amber = on, red = mute / error, blue = chosen, grey = off
        NlBtn st = NlBtn::Plain;
        if (on) {
            if (onColor == C_MUTE || onColor == C_LCD_BAD || onColor == C_RED || onColor == C_PANIC) st = NlBtn::Red;
            else if (onColor == C_ACCENT || onColor == C_MARK || onColor == C_FREE || onColor == C_GREEN) st = NlBtn::Sel;
            else if (onColor == C_LCD_DIM) st = NlBtn::Off;
            else st = NlBtn::On;
        }
        nlBtn(c, r, label, st, size, false);
        return;
    }
    const bool down = isDown(r);
    if (!down) shadow(c, r, 7.0F, 3.0F, 80);
    if (on) {
        litKey(c, r, 7.0F, onColor, down);
        text(c, label, r.centerX(), r.centerY() + size * 0.36F, size, litText(litFill(onColor)), Opt().center().bold().maxW(r.width() - 14.0F));
        return;
    }
    // SILVETON_LOOK_V2: relief keys
    fill(c, r, 7.0F, Color::rgb(150, 154, 162));
    const RectF face(r.left + 1.0F, r.top + (down ? 2.0F : 1.0F), r.right - 1.0F, r.bottom - (down ? 1.0F : 3.0F));
    if (down) fill(c, face, 6.0F, Color::rgb(205, 208, 214));
    else fillV(c, face, 6.0F, Color::rgb(246, 247, 249), Color::rgb(214, 216, 221));
    if (!down) line(c, face.left + 6.0F, face.top + 1.0F, face.right - 6.0F, face.top + 1.0F, Color::WHITE, 1.5F);
    text(c, label, r.centerX(), r.centerY() + size * 0.36F, size, C_TOGGLE_TEXT, Opt().center().bold().maxW(r.width() - 14.0F));
}

void SilvetonSamplerView::segKey(Canvas& c, const RectF& r, const std::string& label, bool on, float size, bool withLed) {
    if (darkTheme) {   // SILVETON_NEW_LOOK_V2: the chosen one of a row is blue
        nlBtn(c, r, label, on ? NlBtn::Sel : NlBtn::Plain, size, false);
        return;
    }
    const bool down = isDown(r);
    if (!down) shadow(c, r, 8.0F, 2.0F, 70);
    if (on) {
        litKey(c, r, 8.0F, C_AMBER, down);
    } else {
        fillV(c, r, 8.0F, Color::rgb(74, 78, 85), Color::rgb(58, 61, 67));
        if (down) fill(c, r, 8.0F, Color::argb(60, 0, 0, 0));
    }
    if (withLed) led(c, r.right - 7.0F, r.top + 7.0F, true, 2.5F);
    text(c, label, r.centerX(), r.centerY() + size * 0.36F, size, on ? Color::WHITE : Color::rgb(205, 209, 215),
         Opt().center().bold().spacing(0.1F).maxW(r.width() - 8.0F));
}

void SilvetonSamplerView::accentKey(Canvas& c, const RectF& r, const std::string& label, bool enabled, float size) {
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1: the green action key stays green
        nlBtn(c, r, label, enabled ? NlBtn::Green : NlBtn::Off, size, false);
        return;
    }
    const bool down = enabled && isDown(r);
    if (!down) shadow(c, r, 10.0F, 3.0F, 90);
    fillV(c, r, 10.0F,
          !enabled ? Color::rgb(96, 99, 105) : (down ? C_ACCENT_DARK : lighten(C_ACCENT, 14)),
          !enabled ? Color::rgb(80, 83, 89) : (down ? Color::rgb(24, 96, 52) : C_ACCENT_DARK));
    text(c, label, r.centerX(), r.centerY() + size * 0.375F, size, enabled ? Color::WHITE : Color::rgb(150, 153, 158), Opt().center().bold().spacing(0.2F));
}

void SilvetonSamplerView::switchKey(Canvas& c, const RectF& r, const std::string& title, const std::string& sub, bool on) {
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1: amber when on, a lamp bar on top
        nlBtn(c, r, "", on ? NlBtn::On : NlBtn::Plain, 14.0F, true);
        const ColorInt tc = on ? Color::rgb(28, 19, 4) : Color::rgb(179, 187, 196);
        text(c, title, r.centerX(), r.centerY() + (sub.empty() ? 8.0F : 2.0F), sub.empty() ? 20.0F : 15.0F, tc, Opt().center().bold().spacing(0.08F).maxW(r.width() - 24.0F));
        if (!sub.empty()) text(c, sub, r.centerX(), r.centerY() + 22.0F, 11.0F, on ? Color::rgb(70, 45, 8) : NL_MUT, Opt().center().mono().maxW(r.width() - 20.0F));
        return;
    }
    const bool down = isDown(r);
    if (!down) shadow(c, r, 12.0F, 3.0F, 90);
    if (on) {
        litKey(c, r, 12.0F, C_AMBER, down);
    } else {
        fillV(c, r, 12.0F, Color::rgb(70, 74, 80), Color::rgb(56, 59, 65));
        if (down) fill(c, r, 12.0F, Color::argb(60, 0, 0, 0));
    }
    led(c, r.left + 18.0F, r.top + 18.0F, on, 5.0F);
    text(c, title, r.centerX(), r.centerY() + (sub.empty() ? 8.0F : 0.0F), sub.empty() ? 22.0F : 15.0F,
         on ? Color::WHITE : Color::rgb(205, 209, 215), Opt().center().bold().spacing(0.08F).maxW(r.width() - 40.0F));
    if (!sub.empty()) text(c, sub, r.centerX(), r.centerY() + 20.0F, 11.0F, on ? Color::rgb(222, 240, 228) : C_KNOB_LABEL, Opt().center().mono());
    if (!sub.empty() || utf8Length(title) > 3) {
        text(c, on ? "ON" : "OFF", r.right - 14.0F, r.top + 22.0F, 11.0F, on ? Color::WHITE : C_KNOB_LABEL, Opt().right().bold().spacing(0.15F));
    }
}

void SilvetonSamplerView::pageKey(Canvas& c, const RectF& r, const std::string& label, bool on, bool hasData, bool ledOn) {
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1: chosen = blue; a small lamp says that the page holds data
        nlBtn(c, r, "", on ? NlBtn::Sel : NlBtn::Plain, 14.0F, false);
        text(c, label, r.centerX(), r.top + 24.0F, 16.0F, on ? Color::WHITE : (hasData ? Color::rgb(179, 187, 196) : NL_MUT), Opt().center().monoBold());
        led(c, r.centerX(), r.bottom - 11.0F, ledOn, 3.0F, !on);
        return;
    }
    if (on) {
        shadow(c, r, 8.0F, 2.0F, 60);
        litKey(c, r, 8.0F, C_AMBER, isDown(r));
        text(c, label, r.centerX(), r.top + 24.0F, 16.0F, Color::WHITE, Opt().center().monoBold());
    } else {
        lightKey(c, r, "", true);
        text(c, label, r.centerX(), r.top + 24.0F, 16.0F, hasData ? C_KEY_TEXT : C_EMPTY_TEXT, Opt().center().monoBold());
    }
    led(c, r.centerX(), r.bottom - 11.0F, ledOn, 3.0F, !on);
}

void SilvetonSamplerView::lcd(Canvas& c, const RectF& r, float radius) {
    if (darkTheme) { nlLcd(c, r, std::min(radius, 8.0F)); return; }   // SILVETON_NEW_LOOK_V1
    if (darkTheme) {   // SILVETON_THEME_V1: the display's own warm light on the panel
        for (int k = 3; k >= 1; --k) {
            const float kk = static_cast<float>(k);
            fill(c, RectF(r.left - kk * 3.0F, r.top - kk * 3.0F, r.right + kk * 3.0F, r.bottom + kk * 3.0F), radius + kk * 3.0F, Color::argb(10, 200, 210, 220));
        }
    } else {
        fill(c, RectF(r.left, r.top + 1.0F, r.right, r.bottom + 1.0F), radius, Color::argb(150, 255, 255, 255));
    }
    fillV(c, r, radius, C_LCD_TOP, C_LCD_BOT);
    paint.color = Color::BLACK;
    paint.shader = linearGradient(0.0F, r.top, 0.0F, r.top + 9.0F, Color::argb(170, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawRoundRect(r, radius, radius, paint);
    paint.shader = nullptr;
}

void SilvetonSamplerView::board(Canvas& c, const RectF& r, bool squareTopLeft) {
    if (darkTheme) { (void)squareTopLeft; nlPanel(c, r); return; }   // SILVETON_NEW_LOOK_V1
    shadow(c, r, 14.0F, 4.0F, 80);
    fillV(c, r, 14.0F, C_BOARD_TOP, C_BOARD_BOT);
    if (squareTopLeft) {
        paint.color = Color::BLACK;
        paint.shader = linearGradient(0.0F, r.top, 0.0F, r.bottom, C_BOARD_TOP, C_BOARD_BOT, TileMode::Clamp);
        c.drawRect(RectF(r.left, r.top, r.left + 16.0F, r.top + 16.0F), paint);
        paint.shader = nullptr;
    }
    line(c, r.left + (squareTopLeft ? 1.0F : 14.0F), r.top + 1.0F, r.right - 14.0F, r.top + 1.0F, C_BOARD_EDGE, 1.0F);
}

// SILVETON_THEME_V1: the title of a sound page - left in the light theme, right in the dark one
// (there the knob names are printed above the knobs and would collide with it).
void SilvetonSamplerView::secTitle(Canvas& c, const RectF& sec, const std::string& title) {
    if (darkTheme) text(c, title, sec.left + 14.0F, sec.top + 20.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.16F).maxW(sec.width() - 28.0F));   // SILVETON_NEW_LOOK_V1
    else text(c, title, sec.left + 6.0F, sec.top + 12.0F, 11.0F, C_SECTION_TITLE, Opt().spacing(0.25F));
}

void SilvetonSamplerView::section(Canvas& c, const RectF& r, const std::string* title) {
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1: an inset panel with a blue title
        nlSub(c, r);
        if (title != nullptr) text(c, *title, r.left + 14.0F, r.top + 20.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.16F).maxW(r.width() - 28.0F));
        return;
    }
    fill(c, r, 12.0F, C_SECTION);
    line(c, r.left + 12.0F, r.top + 1.0F, r.right - 12.0F, r.top + 1.0F, Color::argb(20, 255, 255, 255), 1.0F);
    if (title != nullptr) {
        text(c, *title, r.left + 16.0F, r.top + 24.0F, 11.0F, C_SECTION_TITLE, Opt().spacing(0.25F).maxW(r.width() - 32.0F));
        fill(c, RectF(r.left + 16.0F, r.top + 30.0F, r.left + 46.0F, r.top + 32.0F), 1.0F, C_ACCENT);
    }
}

void SilvetonSamplerView::knobControl(Canvas& c, float cx, float cy, float radius, float value, float minV, float maxV, float step, float travel,
                                      bool bipolar, const std::string& valueText, const std::string& label, float hitW,
                                      std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset,
                                      std::function<void(float)> onFinal) {
    if (hitW < 0.0F) hitW = radius * 2.0F + 120.0F;   // the tablet's default argument
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    drawKnob(c, cx, cy, radius, t, bipolar, true);
    const float vy = cy + radius + 30.0F;
    if (darkTheme) {   // SILVETON_NEW_LOOK_V1: the name above the dots, the value in a black box below
        if (!label.empty()) nlLabel(c, label, cx, cy - (radius * 1.30F + 3.0F) - 12.0F, true, NL_TXT2, radius >= 40.0F ? 12.0F : 11.0F);
        nlValue(c, RectF(cx - std::min(42.0F, hitW / 2.0F - 3.0F), cy + radius + 15.0F, cx + std::min(42.0F, hitW / 2.0F - 3.0F), cy + radius + 39.0F), valueText, radius >= 40.0F ? 14.0F : 12.5F);
        knobHit(RectF(cx - hitW / 2.0F, cy - radius - 16.0F, cx + hitW / 2.0F, cy + radius + 10.0F), value, minV, maxV, step, travel, onChange, exact, reset, onFinal);
        hit(RectF(cx - hitW / 2.0F, cy + radius + 10.0F, cx + hitW / 2.0F, cy + radius + 42.0F), [exact](float, float) { exact(); }, reset);
        return;
    }
    text(c, valueText, cx, vy, radius >= 40.0F ? 19.0F : 15.0F, C_VALUE, Opt().center().mono().maxW(hitW - 6.0F));
    if (!label.empty()) {
        if (darkTheme) text(c, label, cx, cy - radius * 1.42F - 8.0F, radius >= 40.0F ? 12.0F : 11.0F, C_KNOB_LABEL, Opt().center().bold().spacing(0.12F).maxW(hitW + 20.0F));   // SILVETON_THEME_V1: printed above, like on the instrument
        else text(c, label, cx, vy + 16.0F, radius >= 40.0F ? 12.0F : 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.15F).maxW(hitW - 6.0F));
    }
    knobHit(RectF(cx - hitW / 2.0F, cy - radius - 16.0F, cx + hitW / 2.0F, cy + radius + 10.0F), value, minV, maxV, step, travel, onChange, exact, reset, onFinal);
    hit(RectF(cx - hitW / 2.0F, cy + radius + 10.0F, cx + hitW / 2.0F, vy + 22.0F), [exact](float, float) { exact(); }, reset);
}

void SilvetonSamplerView::drawKnob(Canvas& c, float cx, float cy, float r, float t, bool bipolar, bool ring) {
    const float tt = std::clamp(t, 0.0F, 1.0F);
    paint.style = Style::Fill;
    if (darkTheme) { nlKnob(c, cx, cy, r, tt, bipolar, false, ring); return; }   // SILVETON_NEW_LOOK_V1
    if (ring) {
        const float rr = r + 8.0F;
        const RectF arc(cx - rr, cy - rr, cx + rr, cy + rr);
        paint.shader = nullptr;
        paint.style = Style::Stroke;
        paint.strokeWidth = 4.0F;
        paint.strokeCap = Cap::Round;
        paint.color = Color::argb(110, 0, 0, 0);
        c.drawArc(arc, 135.0F, 270.0F, false, paint);
        paint.color = Color::rgb(214, 218, 224);   // SILVETON_SERIOUS_V1: the value arc is a neutral light line
        if (bipolar) {
            const float sweep = (tt - 0.5F) * 270.0F;
            if (std::fabs(sweep) > 0.5F) c.drawArc(arc, 270.0F, sweep, false, paint);
        } else if (tt > 0.002F) {
            c.drawArc(arc, 135.0F, 270.0F * tt, false, paint);
        }
        paint.strokeCap = Cap::Butt;
        paint.style = Style::Fill;
    }
    paint.color = Color::BLACK;
    paint.shader = radialGradient(cx, cy + r * 0.16F, r * 1.22F, Color::argb(150, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawCircle(cx, cy + r * 0.12F, r * 1.22F, paint);
    paint.shader = sweepGradient(cx, cy, std::vector<ColorInt>{C_KNOB_A, C_KNOB_B, C_KNOB_A, C_KNOB_C, C_KNOB_A}, {});
    c.drawCircle(cx, cy, r, paint);
    paint.shader = radialGradient(cx, cy - r * 0.6F, r * 0.95F, colorWithAlpha(Color::rgb(252, 253, 255), 60),
                                  colorWithAlpha(Color::rgb(252, 253, 255), 0), TileMode::Clamp);
    c.drawCircle(cx, cy, r, paint);
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = 1.2F;
    paint.color = Color::argb(150, 0, 0, 0);
    c.drawCircle(cx, cy, r, paint);
    const double ang = (135.0 + 270.0 * static_cast<double>(tt)) * kPi / 180.0;
    const float cs = static_cast<float>(std::cos(ang));
    const float sn = static_cast<float>(std::sin(ang));
    paint.color = Color::rgb(236, 238, 242);     // white pointer, like on the instruments
    paint.strokeWidth = std::max(3.0F, r * 0.09F);
    paint.strokeCap = Cap::Round;
    c.drawLine(cx + cs * r * 0.40F, cy + sn * r * 0.40F, cx + cs * r * 0.84F, cy + sn * r * 0.84F, paint);
    paint.strokeCap = Cap::Butt;
    paint.style = Style::Fill;
}

// SILVETON_THEME_V1: matte black knob, flat brushed-aluminium insert, white line on the rim,
// thin scale ticks printed on the panel (like the Rhodes Mark I). No value arc.
void SilvetonSamplerView::drawRhodesKnob(Canvas& c, float cx, float cy, float r, float tt, bool ticks) {
    paint.shader = nullptr;
    if (ticks) {
        paint.style = Style::Stroke;
        paint.strokeCap = Cap::Butt;
        const float sk = r * 1.42F;
        for (int i = 0; i <= 10; ++i) {
            const double a = (135.0 + 270.0 * i / 10.0) * kPi / 180.0;
            const float cs = static_cast<float>(std::cos(a));
            const float sn = static_cast<float>(std::sin(a));
            const float l1 = sk * 0.86F;
            const float l2 = (i % 5 == 0) ? sk : sk * 0.95F;
            paint.color = Color::rgb(196, 196, 190);
            paint.strokeWidth = (i % 5 == 0) ? 1.6F : 1.1F;
            c.drawLine(cx + cs * l1, cy + sn * l1, cx + cs * l2, cy + sn * l2, paint);
        }
        paint.style = Style::Fill;
    }
    // shadow under the body
    paint.shader = radialGradient(cx, cy + r * 0.25F, r * 1.25F, Color::argb(170, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawCircle(cx, cy + r * 0.2F, r * 1.25F, paint);
    // matte black body, a little lighter in the middle
    paint.shader = radialGradient(cx, cy, r, Color::rgb(40, 40, 42), Color::rgb(22, 22, 24), TileMode::Clamp);
    c.drawCircle(cx, cy, r, paint);
    paint.shader = nullptr;
    paint.style = Style::Stroke; paint.strokeWidth = 1.0F; paint.color = Color::rgb(58, 58, 60);
    c.drawCircle(cx, cy, r, paint);
    paint.color = Color::argb(60, 255, 255, 255); paint.strokeWidth = 1.5F;
    c.drawArc(RectF(cx - r + 1.5F, cy - r + 1.5F, cx + r - 1.5F, cy + r - 1.5F), 200.0F, 140.0F, false, paint);
    paint.style = Style::Fill;
    // flat brushed-aluminium insert
    const float cr = r * 0.56F;
    paint.shader = linearGradient(0.0F, cy - cr, 0.0F, cy + cr,
        std::vector<ColorInt>{Color::rgb(176, 178, 182), Color::rgb(150, 152, 156), Color::rgb(184, 186, 190), Color::rgb(146, 148, 152), Color::rgb(172, 174, 178),
                              Color::rgb(152, 154, 158), Color::rgb(180, 182, 186), Color::rgb(148, 150, 154), Color::rgb(170, 172, 176)},
        {}, TileMode::Clamp);
    c.drawCircle(cx, cy, cr, paint);
    paint.shader = radialGradient(cx, cy + cr * 0.6F, cr, Color::argb(0, 0, 0, 0), Color::argb(50, 0, 0, 0), TileMode::Clamp);
    c.drawCircle(cx, cy, cr, paint);
    paint.shader = nullptr;
    paint.style = Style::Stroke; paint.strokeWidth = 1.2F; paint.color = Color::rgb(90, 90, 94);
    c.drawCircle(cx, cy, cr, paint);
    paint.strokeWidth = 1.4F; paint.color = Color::rgb(8, 8, 9);
    c.drawCircle(cx, cy, cr + 2.0F, paint);
    // white pointer line on the rim
    const double ang = (135.0 + 270.0 * static_cast<double>(tt)) * kPi / 180.0;
    const float cs = static_cast<float>(std::cos(ang));
    const float sn = static_cast<float>(std::sin(ang));
    paint.color = Color::rgb(236, 234, 226); paint.strokeWidth = std::max(2.4F, r * 0.08F); paint.strokeCap = Cap::Butt;
    c.drawLine(cx + cs * (cr + 3.0F), cy + sn * (cr + 3.0F), cx + cs * r * 0.96F, cy + sn * r * 0.96F, paint);
    paint.style = Style::Fill;
}

void SilvetonSamplerView::stripMeter(Canvas& c, const RectF& r, float peak) {
    fill(c, r, 3.0F, C_METER_BG);
    const float db = peak <= 0.000001F ? -90.0F : 20.0F * log10f_(peak);
    const float t = db <= -60.0F ? 0.0F : faderT(std::min(db, 12.0F));
    if (t > 0.004F) {
        paint.color = Color::BLACK;
        paint.shader = linearGradient(0.0F, r.bottom, 0.0F, r.top, std::vector<ColorInt>{C_GREEN, C_GREEN, C_YELLOW, C_RED, C_RED},
                                      std::vector<float>{0.0F, 0.5F, 0.6F, 0.67F, 1.0F}, TileMode::Clamp);
        c.drawRoundRect(RectF(r.left, r.bottom - r.height() * t, r.right, r.bottom), 3.0F, 3.0F, paint);
        paint.shader = nullptr;
    }
}

void SilvetonSamplerView::faderCap(Canvas& c, float cx, float cy, bool big) {
    const float hw = big ? 26.0F : 20.0F;
    const float hh = big ? 15.0F : 11.0F;
    const RectF r(cx - hw, cy - hh, cx + hw, cy + hh);
    if (darkTheme) { nlFaderCap(c, cx, cy, big ? 52.0F : 44.0F, big ? 28.0F : 24.0F); return; }   // SILVETON_NEW_LOOK_V1
    if (false) {
        shadow(c, r, 3.0F, 4.0F, 150);
        fill(c, r, 3.0F, Color::rgb(60, 60, 64));
        fill(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 2.5F, Color::rgb(26, 26, 28));
        fill(c, RectF(r.left + 3.0F, r.top + 3.0F, r.right - 3.0F, cy - 1.0F), 2.0F, Color::rgb(38, 38, 41));
        fill(c, RectF(r.left + 5.0F, cy - 1.2F, r.right - 5.0F, cy + 1.2F), 1.0F, Color::rgb(236, 234, 226));
        return;
    }
    shadow(c, r, 5.0F, 3.0F, 110);
    fillV(c, r, 5.0F, Color::rgb(91, 95, 102), Color::rgb(42, 44, 49));
    line(c, r.left + 4.0F, r.top + 1.0F, r.right - 4.0F, r.top + 1.0F, Color::rgb(154, 160, 168), 1.0F);
    fill(c, RectF(r.left + 4.0F, cy - 1.0F, r.right - 4.0F, cy + 1.0F), 1.0F, Color::rgb(236, 234, 226));   // white line, like on a real fader
}

void SilvetonSamplerView::drawRangeBar(Canvas& c, const RectF& r, float low, float high, float minV, float maxV) {
    fill(c, r, 6.0F, C_METER_BG);
    const float a = std::clamp((low - minV) / (maxV - minV), 0.0F, 1.0F);
    const float b = std::clamp((high - minV) / (maxV - minV), 0.0F, 1.0F);
    fill(c, RectF(r.left + r.width() * a, r.top, r.left + r.width() * b, r.bottom), 6.0F, darkTheme ? NL_BLUE : C_ACCENT);
    for (const float x : {r.left + r.width() * a, r.left + r.width() * b}) {
        drawKnob(c, x, r.centerY(), 13.0F, 0.5F, false, false);
    }
}

void SilvetonSamplerView::drawMiniKeyboard(Canvas& c, const RectF& r, int low, int high) {
    static const int whiteSteps[] = {0, 2, 4, 5, 7, 9, 11};
    std::vector<int> whites;
    for (int n = 0; n <= 127; ++n) {
        for (const int w : whiteSteps) if (n % 12 == w) { whites.push_back(n); break; }
    }
    const float ww = r.width() / static_cast<float>(whites.size());
    for (std::size_t k = 0U; k < whites.size(); ++k) {
        const int note = whites[k];
        const RectF kr(r.left + static_cast<float>(k) * ww, r.top, r.left + static_cast<float>(k + 1U) * ww - 0.6F, r.bottom);
        fill(c, kr, 1.0F, (note >= low && note <= high) ? (darkTheme ? NL_BLUE : C_ACCENT) : Color::rgb(226, 228, 232));
    }
    for (std::size_t k = 0U; k < whites.size(); ++k) {
        const int note = whites[k];
        const int pc = note % 12;
        if ((pc == 0 || pc == 2 || pc == 5 || pc == 7 || pc == 9) && note + 1 <= 127) {
            const float bx = r.left + static_cast<float>(k + 1U) * ww;
            const RectF br(bx - ww * 0.32F, r.top, bx + ww * 0.32F, r.top + r.height() * 0.6F);
            fill(c, br, 1.0F, (note + 1 >= low && note + 1 <= high) ? (darkTheme ? NL_BLUE_DARK : C_ACCENT_DARK) : Color::rgb(32, 34, 38));
        }
    }
    for (int oct = 0; oct <= 10; ++oct) {
        int k = -1;
        for (std::size_t i = 0U; i < whites.size(); ++i) if (whites[i] == oct * 12) { k = static_cast<int>(i); break; }
        if (k >= 0 && oct % 2 == 0) text(c, "C" + std::to_string(oct - 1), r.left + static_cast<float>(k) * ww + 1.0F, r.bottom + 14.0F, 11.0F, C_KNOB_LABEL, Opt().mono());
    }
}

void SilvetonSamplerView::drawGear(Canvas& c, float cx, float cy, float radius) {
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = std::max(2.0F, radius * 0.18F);
    paint.color = C_NAV_TEXT;
    c.drawCircle(cx, cy, radius * 0.55F, paint);
    c.drawCircle(cx, cy, radius * 0.18F, paint);
    for (int i = 0; i < 8; ++i) {
        const double a = kPi * 2.0 * i / 8.0;
        const float x1 = cx + static_cast<float>(std::cos(a)) * radius * 0.72F;
        const float y1 = cy + static_cast<float>(std::sin(a)) * radius * 0.72F;
        const float x2 = cx + static_cast<float>(std::cos(a)) * radius;
        const float y2 = cy + static_cast<float>(std::sin(a)) * radius;
        c.drawLine(x1, y1, x2, y2, paint);
    }
    paint.style = Style::Fill;
}

std::string SilvetonSamplerView::midiNoteName(int note) {
    static const char* names[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const int n = std::clamp(note, 0, 127);
    return std::string(names[n % 12]) + std::to_string(n / 12 - 1);
}

ColorInt SilvetonSamplerView::colorWithAlpha(ColorInt color, int alpha) {
    return Color::argb(alpha, Color::red(color), Color::green(color), Color::blue(color));
}

ColorInt SilvetonSamplerView::lighten(ColorInt color, int amount) {
    return Color::rgb(std::min(255, Color::red(color) + amount), std::min(255, Color::green(color) + amount), std::min(255, Color::blue(color) + amount));
}

std::string SilvetonSamplerView::signed_(int v) { return v > 0 ? "+" + std::to_string(v) : std::to_string(v); }
std::string SilvetonSamplerView::dbText(float db) { return fmtFixed(static_cast<double>(db), 2) + " dB"; }

std::string SilvetonSamplerView::voiceModeName(int m) {
    switch (m) { case 1: return "MONO"; case 2: return "LEGATO"; default: return "POLY"; }
}

std::string SilvetonSamplerView::effectName(int t) {
    switch (t) {
        case 1: return "DIGITAL DELAY"; case 2: return "CHORUS"; case 3: return "PLATE REVERB"; case 4: return "HALL";
        case 5: return "ROOM"; case 6: return "CHAMBER"; case 7: return "SPRING"; case 8: return "TAPE DELAY";
        case 9: return "PING-PONG"; case 10: return "MULTI-TAP"; case 11: return "DUCKING DELAY"; case 12: return "FLANGER";
        case 13: return "PHASER"; case 14: return "ROTARY"; case 15: return "COMPRESSOR"; case 16: return "DRIVE";
        case 17: return "ENSEMBLE"; default: return "OFF";
    }
}

std::string SilvetonSamplerView::panText(float p) {
    if (p < -0.02F) return "L" + std::to_string(static_cast<int>(-p * 100.0F));
    if (p > 0.02F) return "R" + std::to_string(static_cast<int>(p * 100.0F));
    return "C";
}

std::string SilvetonSamplerView::noteName(int key) {
    static const char* names[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const int k = std::clamp(key, 0, 127);
    return std::string(names[k % 12]) + std::to_string(k / 12 - 1);
}

void SilvetonSamplerView::applyTheme(bool dark) {
    darkTheme = dark;
    if (!dark) {
        C_METAL_A = Color::rgb(217, 218, 222); C_METAL_B = Color::rgb(222, 223, 227);
        C_SIDE_A = Color::rgb(38, 40, 44); C_SIDE_B = Color::rgb(51, 54, 59);
        C_NAV_EDGE = Color::rgb(72, 76, 82); C_NAV_TEXT = Color::rgb(158, 163, 171); C_NAV_ON_TEXT = Color::WHITE;
        C_LOGO = Color::rgb(226, 228, 232);
        C_KEY_LIGHT = Color::rgb(236, 238, 241); C_KEY_LIGHT_EDGE = Color::rgb(185, 188, 194); C_KEY_TEXT = Color::rgb(48, 52, 58);
        C_STRIP = Color::rgb(236, 238, 241); C_STRIP_SEL = Color::WHITE; C_EMPTY_CARD = Color::rgb(226, 228, 232);
        C_INK = Color::rgb(35, 38, 43); C_INK_SOFT = Color::rgb(48, 52, 58); C_LABEL_GREY = Color::rgb(100, 106, 116);
        C_SCALE = Color::rgb(100, 106, 116); C_EMPTY_TEXT = Color::rgb(104, 110, 120);
        C_TOGGLE = Color::rgb(223, 226, 230); C_TOGGLE_TEXT = Color::rgb(74, 80, 90); C_DARK_KEY = Color::rgb(43, 46, 51);
        C_TRACK_LIGHT = Color::rgb(201, 204, 209); C_METER_BG = Color::rgb(27, 29, 32);
        C_BOARD_TOP = Color::rgb(52, 55, 61); C_BOARD_BOT = Color::rgb(39, 41, 46); C_BOARD_EDGE = Color::rgb(85, 89, 95);
        C_SECTION_TITLE = Color::rgb(201, 204, 209); C_KNOB_LABEL = Color::rgb(170, 176, 184); C_HINT = Color::rgb(143, 148, 156);
        C_TAB = Color::rgb(201, 204, 209); C_TAB_TEXT = Color::rgb(62, 66, 74); C_LED_OFF_LIGHT = Color::rgb(187, 187, 187);
    } else {
        C_METAL_A = Color::rgb(30, 32, 37); C_METAL_B = Color::rgb(31, 33, 38);
        C_SIDE_A = Color::rgb(14, 15, 17); C_SIDE_B = Color::rgb(19, 20, 23);   // SILVETON_NEW_LOOK_V1: no wood, the page is the dark chassis
        C_NAV_EDGE = Color::rgb(96, 100, 112); C_NAV_TEXT = Color::rgb(190, 194, 204); C_NAV_ON_TEXT = Color::WHITE;
        C_LOGO = Color::rgb(226, 228, 232);
        C_KEY_LIGHT = Color::rgb(66, 70, 80); C_KEY_LIGHT_EDGE = Color::rgb(16, 17, 20); C_KEY_TEXT = Color::rgb(190, 194, 204);
        C_STRIP = Color::rgb(42, 45, 52); C_STRIP_SEL = Color::rgb(50, 54, 62); C_EMPTY_CARD = Color::rgb(36, 38, 44);
        C_INK = Color::rgb(226, 228, 232); C_INK_SOFT = Color::rgb(200, 204, 210); C_LABEL_GREY = Color::rgb(172, 178, 190);
        C_SCALE = Color::rgb(152, 158, 170); C_EMPTY_TEXT = Color::rgb(146, 152, 164);
        C_TOGGLE = Color::rgb(66, 70, 80); C_TOGGLE_TEXT = Color::rgb(214, 218, 226); C_DARK_KEY = Color::rgb(24, 26, 30);
        C_TRACK_LIGHT = Color::rgb(14, 15, 18); C_METER_BG = Color::rgb(14, 15, 18);
        C_BOARD_TOP = Color::rgb(26, 28, 32); C_BOARD_BOT = Color::rgb(22, 24, 28); C_BOARD_EDGE = Color::rgb(52, 56, 64);
        C_SECTION_TITLE = Color::rgb(201, 204, 209); C_KNOB_LABEL = Color::rgb(222, 224, 230); C_HINT = Color::rgb(150, 156, 168);
        C_TAB = Color::rgb(66, 70, 80); C_TAB_TEXT = Color::rgb(214, 218, 226); C_LED_OFF_LIGHT = Color::rgb(85, 85, 85);
    }
}

// SILVETON_COLOR_KEYS_V1: the five keys of SETTINGS > THEME. GRAPHITE is the look as drawn; LIGHT, BLACK and CLASSIC turn the colour of the whole
// picture (the same colours the program has always had); OLD is the old light palette. All five keep the screens of the new look.
void SilvetonSamplerView::applyColor(int color, bool save) {
    const int k = std::clamp(color, 0, 4);
    colorKey_ = k;
    if (save) sampler.setClassicColor(k);
    applyTheme(k != 4);
    setColorTheme(k <= 3 ? k : 0);
    woodBitmap_.reset();
    invalidate();
}

} // namespace silveton::ui::classic
