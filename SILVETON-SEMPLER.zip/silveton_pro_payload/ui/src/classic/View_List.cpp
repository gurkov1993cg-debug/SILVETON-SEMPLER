// SILVETON_MAC_VIEW_V1 - the LIST page (tablet SilvetonSamplerView.kt lines 2053-2333)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace silveton::ui::classic {

namespace {
std::string pad3(long long v) { return fmtZeroPad(v, 3); }
bool containsIgnoreCase(const std::string& text, const std::string& part) {
    return utf8Upper(text).find(utf8Upper(part)) != std::string::npos;
}
} // namespace

// SILVETON_LIST_GRID_V1: the LIST like the BLENDS picker - pages of 20 (4 x 5).
// Tap a BLEND = play it. Tap an empty place = choose it for STORE.
// STORE writes the COMBI that sounds now to the chosen place (asks before writing over a BLEND). EDIT opens the chosen BLEND in COMBI.
// SILVETON_LIST_V2: 30 BLENDS a page (5 x 6), 7 page keys, favourites and search,
// one row of big keys for thick fingers (TRANSPOSE - [0] + : both at once = 0).
std::vector<int> SilvetonSamplerView::listVisible() {
    std::vector<int> out;
    for (int i = 0; i < LIST_SIZE; ++i) {
        if (!listSearch.empty()) {
            const auto item = realListItem(i);
            if (item && containsIgnoreCase(item->name, listSearch)) out.push_back(i);
        } else if (listFavOnly) {
            if (listFavs.count(i) != 0 && realListItem(i)) out.push_back(i);
        } else {
            out.push_back(i);
        }
    }
    return out;
}

// SILVETON_NEW_LOOK_V1: the LIST page of the new look (pictures list.png / list_mark.png). Top toolbar y 98..142, grid 5 x 6 from y 150,
// bottom toolbar y 584..650, hint line at y 662. The loaded blend is shown by the common top bar.
void SilvetonSamplerView::drawList(Canvas& c) {
    if (scaleOpen_) { drawScalePage(c); return; }   // SILVETON_SCALE_PAGE_V1: the SCALE page instead of the grid
    if (!listCacheLoaded) refreshListCache();
    const int active = realListItem(cachedActiveListEntry) ? cachedActiveListEntry : -1;
    const std::vector<int> visible = listVisible();
    const int visibleCount = static_cast<int>(visible.size());
    const int pages = std::max(1, (visibleCount + LIST_PER_PAGE - 1) / LIST_PER_PAGE);
    const auto indexOf = [&visible](int v) {
        const auto it = std::find(visible.begin(), visible.end(), v);
        return it == visible.end() ? -1 : static_cast<int>(it - visible.begin());
    };
    if (active != listFollowedActive) {
        listFollowedActive = active;
        if (active >= 0) {
            const int vi = indexOf(active);
            if (vi >= 0) listPage = vi / LIST_PER_PAGE;
            listSelected = active;
        }
    }
    listPage = std::clamp(listPage, 0, pages - 1);
    if (listSelected < 0 || listSelected >= LIST_SIZE) listSelected = active >= 0 ? active : -1;

    // Editing belongs to the held blend. The toolbar only filters and selects.
    const RectF findR(20.0F, 98.0F, 120.0F, 142.0F);
    nlBtn(c, findR, "SEARCH", listSearch.empty() ? NlBtn::Plain : NlBtn::On, 12.0F, false);
    hit(findR, [this](float, float) {
        if (!listSearch.empty()) { listSearch.clear(); listPage = 0; invalidate(); }
        else showTextPage("SEARCH BLEND BY NAME", "", [this](const std::string& q) { listSearch = trimmed(q); listFavOnly = false; listPage = 0; invalidate(); });
    });
    const RectF favR(129.0F, 98.0F, 185.0F, 142.0F);
    nlBtn(c, favR, "★", listFavOnly ? NlBtn::Sel : NlBtn::Plain, 17.0F, false);
    hit(favR, [this](float, float) { listFavOnly = !listFavOnly; listSearch.clear(); listPage = 0; invalidate(); });
    const std::size_t markedCount = listMarked_.size();
    const RectF selectR(199.0F, 98.0F, 303.0F, 142.0F);
    const bool destinationMode = listPasteMode_ || listStoreMode_;
    nlBtn(c, selectR, destinationMode ? "CANCEL" : (listMarkMode_ ? "DONE" : "SELECT"),
          listMarkMode_ || destinationMode ? NlBtn::Sel : NlBtn::Plain, 12.0F, false);
    hit(selectR, [this](float, float) {
        if (listPasteMode_ || listStoreMode_) { listPasteMode_ = false; listStoreMode_ = false; }
        else if (listMarkMode_) listEndMarking();
        else { listMarkMode_ = true; listMarked_.clear(); }
        invalidate();
    });
    text(c, "HOLD A BLEND / RIGHT CLICK: EDIT, RENAME, COPY, MOVE, DELETE", 1320, 126, 12, NL_TXT2, Opt().right().maxW(980));

    // Navigation stays separate from editing the held blend.
    const int activeIndex = indexOf(active);
    for (int i = 0; i < pages; ++i) {
        const float fi = static_cast<float>(i);
        const RectF pr(452.0F + fi * 70.0F, 150.0F, 516.0F + fi * 70.0F, 188.0F);
        bool hasData = false;
        for (int k = i * LIST_PER_PAGE; k < std::min(visibleCount, (i + 1) * LIST_PER_PAGE); ++k)
            if (realListItem(visible[static_cast<std::size_t>(k)])) { hasData = true; break; }
        nlBtn(c, pr, std::to_string(i + 1), i == listPage ? NlBtn::Sel : (hasData ? NlBtn::Plain : NlBtn::Off), 14.0F, false);
        if (active >= 0 && activeIndex >= 0 && activeIndex / LIST_PER_PAGE == i)
            fill(c, RectF(pr.centerX() - 8.0F, pr.bottom - 5.0F, pr.centerX() + 8.0F, pr.bottom - 3.0F), 1.0F, NL_AMBER);
        hit(pr, [this, i](float, float) { listPage = i; invalidate(); });
    }
    const std::string mode = listPasteMode_ ? "DESTINATION · " + pasteLabel_
        : listStoreMode_ ? "STORE · choose a position"
        : listMarkMode_ ? "SELECT · " + std::to_string(markedCount) + " blends · drag to mark"
        : "LIVE · tap a blend to play";
    text(c, mode, 20.0F, 175.0F, 13.0F, destinationMode || listMarkMode_ ? NL_AMBER : NL_TXT2, Opt().bold().maxW(420.0F));
    text(c, pasteAction_ && !listPasteMode_ ? "HOLD THE DESTINATION · PASTE" : "HOLD / RIGHT CLICK · MENU", 1320.0F, 175.0F, 11.0F, NL_TXT2, Opt().right().maxW(370.0F));

    // ---- the grid: 5 x 6 positions
    const float cellW = 253.6F;
    const float cellH = 52.0F;
    const float cellGap = 8.0F;
    for (int j = 0; j < LIST_PER_PAGE; ++j) {
        const int vi = listPage * LIST_PER_PAGE + j;
        if (vi >= visibleCount) break;
        const int idx = visible[static_cast<std::size_t>(vi)];
        const float col = static_cast<float>(j % 5);
        const float row = static_cast<float>(j / 5);
        const RectF rr(20.0F + col * (cellW + cellGap), 198.0F + row * (cellH + cellGap),
                       20.0F + col * (cellW + cellGap) + cellW, 198.0F + row * (cellH + cellGap) + cellH);
        const std::optional<ListItem> item = realListItem(idx);
        const bool isMarked = listMarkMode_ && item && listMarked_.count(idx) != 0U;
        listGridCell(c, rr, idx, item, idx == active, idx == listSelected, isMarked);
        listCells_.emplace_back(idx, rr);   // SILVETON_WORKFLOW_V1
        if (listPasteMode_) {
            hit(rr, [this, idx](float, float) { listPasteAt(idx); });
            continue;
        }
        if (listStoreMode_) {   // SILVETON_LIST_STORE_V1: a tap on ANY position (taken or free) = store the blend there
            hit(rr, [this, idx](float, float) { listStorePick(idx); });
            continue;
        }
        if (listMarkMode_ && item) {   // SILVETON_MULTI_DELETE_V1: a tap marks / unmarks, nothing is played
            // SILVETON_LIST_MENU_V2: a tap marks / unmarks; a finger dragged over the cells marks (or, started on a marked one, unmarks) all it passes;
            // a hold opens the menu for all the marked blends
            hit(rr, [](float, float) {}, nullptr, [this](float x, float y, bool final) { listPaintTouch(x, y, final); });
            { const ListItem it = *item; listLongHit(rr, [this, idx, it](float, float) { listMarked_.insert(idx); showListContextMenu(idx, it); }); }
            continue;
        }
        if (item) {
            const ListItem it = *item;
            hit(rr, [this, idx](float, float) { openListEntry(idx); });   // SILVETON_SAVEQ_V1: changes of the open blend are asked about first
            listLongHit(rr, [this, idx, it](float, float) { showListContextMenu(idx, it); });
        } else {
            hit(rr, [this, idx](float, float) {
                listSelected = idx;
                flash("LIST " + pad3(idx + 1) + " CHOSEN - STORE WRITES HERE");
            });
            if (pasteAction_) listLongHit(rr, [this, idx](float, float) { showPasteMenu(idx); });   // SILVETON_PASTE_V1
        }
    }
    if (visible.empty()) {
        text(c, !listSearch.empty() ? "NO BLEND WITH “" + listSearch + "”" : std::string("NO FAVOURITES - HOLD A BLEND → ★"),
             670.0F, 360.0F, 20.0F, NL_MUT, Opt().center().bold().maxW(1200.0F));
    }

    // ---- the line under the toolbar: the hint on the left, the page title (the old header text) on the right
    {
        int used = 0;
        for (const auto& it : cachedListItems) if (!sampler.isEmptyListItem(it)) ++used;
        std::string title;
        if (listMarkMode_) title = "LIST · PAGE " + std::to_string(listPage + 1) + " · " + std::to_string(markedCount) + " MARKED";
        else if (!listSearch.empty()) title = "LIST · SEARCH: " + utf8Upper(listSearch);
        else if (listFavOnly) title = "LIST · FAVOURITES · " + std::to_string(listFavs.size());
        else title = "LIST · PAGE " + std::to_string(listPage + 1) + " · " + std::to_string(used) + " / " + std::to_string(LIST_SIZE);
        if (listStoreMode_) title = "STORE · PAGE " + std::to_string(listPage + 1);
        const ColorInt hintColor = Color::rgb(138, 147, 157);
        text(c, listPasteMode_ ? "PASTE / MOVE: tap the destination. Occupied blends shift; nothing is overwritten. CANCEL leaves the clipboard ready."
                              : listStoreMode_ ? "STORE “" + sampler.combiName() + "”: TAP THE POSITION  ·  a taken position asks before it is overwritten  ·  STORE again = the lit one  ·  CANCEL = leave"
                              : listMarkMode_ ? "drag a finger over the cells = mark many positions at once  ·  amber = marked  ·  hold = menu for all marked  ·  CANCEL = leave"
                              : (pasteAction_ ? "HOLD DESTINATION → PASTE: " + pasteLabel_
                                              : std::string("◀ swipe for the page ▶  ·  tap = load the blend  ·  hold = menu: EDIT COMBI, FAVOURITE, RENAME, COPY, MOVE, DELETE")),
             20.0F, 673.0F, 12.0F, hintColor, Opt().spacing(0.03F).maxW(930.0F));
        text(c, title, 1320.0F, 673.0F, 12.0F, NL_TXT2, Opt().right().bold().spacing(0.06F).maxW(340.0F));
    }

    // ---- bottom toolbar: STORE, EDIT, T, Q, TRANSPOSE - [value] +, T SCAN, Q SCAN, SCALE
    const float top = 584.0F;
    const float bottom = 650.0F;
    // STORE: the same as the green key of the top bar; the number is the place it writes to (the same choice openStore() makes)
    int storeAt = -1;
    if (listSelected >= 0 && listSelected < LIST_SIZE) storeAt = listSelected;
    else if (loadedFromList >= 0 && realListItem(loadedFromList)) storeAt = loadedFromList;
    else { for (int i = 0; i < LIST_SIZE; ++i) if (!realListItem(i)) { storeAt = i; break; } }
    const RectF storeR(20.0F, top, 349.0F, bottom);
    nlBtn(c, storeR, "STORE ▶ " + (storeAt >= 0 ? pad3(storeAt + 1) : std::string("---")), listStoreMode_ ? NlBtn::Green : NlBtn::Sel, 16.0F, true);
    hit(storeR, [this](float, float) { openStore(); });
    // T / Q: the terca and quarter tone switches of all the Uppers that have them
    const RectF tR(358.0F, top, 468.0F, bottom);
    const RectF qR(477.0F, top, 587.0F, bottom);
    listLitKey(c, tR, sampler.hasTercaUppers() ? std::string("T  ") + (sampler.tercaMasterOn() ? "ON" : "OFF") : std::string("T  —"), sampler.tercaMasterOn(), 15.0F);
    listLitKey(c, qR, sampler.hasScaleUppers() ? std::string("Q  ") + (sampler.scaleMasterOn() ? "ON" : "OFF") : std::string("Q  —"), sampler.scaleMasterOn(), 15.0F);
    hit(tR, [this](float, float) {
        if (!sampler.hasTercaUppers()) flash("NO UPPER WITH T - CHOOSE T IN SAMPLE"); else sampler.toggleTercaMaster();
        invalidate();
    });
    hit(qR, [this](float, float) {
        if (!sampler.hasScaleUppers()) flash("NO UPPER WITH Q - CHOOSE Q IN SAMPLE"); else sampler.toggleScaleMaster();
        invalidate();
    });
    // TRANSPOSE: - [value] +, both at once = 0
    std::optional<GlobalUiState> g = globalState;
    if (!g) { g = sampler.globalUiState(); if (g) globalState = g; }
    const RectF tm(596.0F, top, 676.0F, bottom);
    const RectF tv(685.0F, top, 815.0F, bottom);
    const RectF tp(824.0F, top, 904.0F, bottom);
    nlBtn(c, tm, "−", NlBtn::Plain, 24.0F, true);
    nlBtn(c, tp, "+", NlBtn::Plain, 24.0F, true);
    nlLcd(c, tv);
    nlLabel(c, "TRANSPOSE", tv.centerX(), tv.top + 17.0F, true, NL_TXT2, 10.5F);
    text(c, signed_(g ? g->transpose : 0), tv.centerX(), tv.top + 50.0F, 28.0F, NL_VALUE, Opt().center().monoBold().maxW(tv.width() - 12.0F));
    hit(tv, [](float, float) {}, [this]() { sampler.stepGlobalTranspose(0); refreshGlobal(); });
    hit(tm, [this](float, float) { sampler.stepGlobalTranspose(-1); refreshGlobal(); });
    hit(tp, [this](float, float) { sampler.stepGlobalTranspose(1); refreshGlobal(); });
    pairHits.push_back(PairHit{tm, tp, [this]() { sampler.stepGlobalTranspose(0); refreshGlobal(); }});
    // T SCAN / Q SCAN: read the terca / the quarter tones from the keyboard
    const RectF ts(913.0F, top, 1053.0F, bottom);
    listScanKey(c, ts, 1, tercaText(sampler.tercaState()));
    const RectF qs(1062.0F, top, 1212.0F, bottom);
    const int notes = sampler.quarterNotes();
    std::string names;
    for (int i = 0; i < 12; ++i) {
        if ((notes & (1 << i)) == 0) continue;
        if (!names.empty()) names += " ";
        names += Ctrl::NOTE_NAMES()[static_cast<std::size_t>(i)];
    }
    // SILVETON_SCALE_TUNING_V1: a scale chosen by name (ready / by hand / yours) shows its name here, a SCAN shows the played notes
    listScanKey(c, qs, 2, !sampler.scaleName().empty() ? sampler.scaleName() : (names.empty() ? std::string("—") : names));
    // SCALE (not in the picture - the scale feature has its own extra key at the end of the row): by hand, ready ones, your own
    const RectF scR(1221.0F, top, 1320.0F, bottom);
    nlBtn(c, scR, "SCALE", NlBtn::Plain, 14.0F, true);
    hit(scR, [this](float, float) { listEndMarking(); listStoreMode_ = false; listPasteMode_ = false; openScalePage(); });   // SILVETON_SCALE_PAGE_V1

    if (listInfoOpen_) drawListInfo(c);   // the INFO of a blend is drawn over everything (it is modal)
}

// SILVETON_NEW_LOOK_V1: a T / Q switch: lit = amber lamp and amber letters on the dark key, off = dim
void SilvetonSamplerView::listLitKey(Canvas& c, const RectF& r, const std::string& label, bool lit, float size) {
    nlBtn(c, r, lit ? std::string() : label, lit ? NlBtn::Plain : NlBtn::Off, size, true);
    if (!lit) return;
    const float lw = std::min(24.0F, r.width() * 0.5F);
    fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
    text(c, label, r.centerX(), r.centerY() + size * 0.36F + 2.0F, size, Color::rgb(255, 177, 58), Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
}

// SILVETON_NEW_LOOK_V1: T SCAN / Q SCAN - two lines (name, and what is set now); while a scan waits for the notes the key blinks
void SilvetonSamplerView::listScanKey(Canvas& c, const RectF& r, int mode, const std::string& sub) {
    const bool on = scanMode == mode;
    const bool blink = on && (nowMs() / 300) % 2 == 0;
    nlBtn(c, r, "", on ? (blink ? NlBtn::Sel : NlBtn::On) : NlBtn::Plain, 14.0F, true);
    const ColorInt line1Color = on ? (blink ? Color::WHITE : Color::rgb(28, 19, 4)) : Color::rgb(179, 187, 196);
    const ColorInt line2Color = on ? line1Color : Color::rgb(147, 155, 164);
    text(c, on ? std::string("SCAN…") : std::string(mode == 1 ? "T SCAN" : "Q SCAN"), r.centerX(), r.centerY() - 4.0F, 14.0F, line1Color,
         Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
    text(c, on ? std::string("PLAY THE NOTES") : sub, r.centerX(), r.centerY() + 10.0F, 10.5F, line2Color, Opt().center().spacing(0.05F).maxW(r.width() - 10.0F));
    hit(r, [this, mode](float, float) {
        if (scanMode == mode) sampler.cancelScan();
        else if (mode == 1) sampler.startTercaScan();
        else sampler.startScaleScan();
        scanMode = sampler.pollScan();
        invalidate();
    });
}

// ---------------------------------------------------------------- SILVETON_SCALE_TUNING_V1: SCALE = musical tuning
// 12 offsets in cents, one per real note (C ... B), -100.00 ... +100.00, to the hundredth. Three ways: by hand, ready ones, your own saved ones.
// It is heard on the Uppers that have Q on (the Q key of the LIST row switches them all together).
// SILVETON_LIST_NAME_ONLY_V1 (Цветомир, 01.11.2026): the marked blends leave the LIST - only their names go and their places are free again.
// The blends themselves and their sounds stay. From the last position down (asked once).
void SilvetonSamplerView::deleteMarkedListEntries() {
    if (listMarked_.empty()) { flash("TOUCH THE BLENDS TO DELETE"); return; }
    std::vector<int> order(listMarked_.rbegin(), listMarked_.rend());
    std::string names;
    std::size_t shown = 0U;
    for (auto it = listMarked_.begin(); it != listMarked_.end(); ++it) {
        const auto item = realListItem(*it);
        if (!item) continue;
        if (shown < 10U) names += (shown == 0U ? "" : ", ") + pad3(*it + 1) + " " + item->name;
        ++shown;
    }
    if (shown > 10U) names += " … (" + std::to_string(shown) + ")";
    showConfirm("DELETE " + std::to_string(order.size()) + (order.size() == 1U ? " BLEND" : " BLENDS"),   // SILVETON_NEW_LOOK_V1: the words of the picture dialogs_misc
                "They are removed from the LIST and their places are free again. Only the positions are freed. The sounds stay.\n" + names,
                "DELETE", [this, order]() {
                    if (!sampler.deleteLiveListEntries(order)) {
                        showMessage("DELETING FAILED", failureText(sampler.lastFailure()));
                        return;
                    }
                    refreshListCache();
                    listFavs = sampler.listFavourites();
                    loadedFromList = cachedActiveListEntry;
                    listEndMarking();
                    invalidate();
                }, "CANCEL");
}

// SILVETON_NEW_LOOK_V1: the face of a LIST cell (the CSS "cell" of the pictures). kind: 0 = a blend, 1 = empty position, 2 = the open blend (blue),
// 3 = marked (amber frame). ring = the chosen position (blue frame, also on an empty place: it is where STORE writes).
void SilvetonSamplerView::listCellFace(Canvas& c, const RectF& r, int kind, bool ring) {
    const float rad = 8.0F;
    if (kind == 3 || ring) {   // a 3 px frame and a soft glow of a few translucent rings
        const ColorInt rc = kind == 3 ? NL_AMBER : NL_BLUE;
        for (int k = 3; k >= 1; --k) {
            const float kk = 3.0F + static_cast<float>(k) * 3.0F;
            fill(c, RectF(r.left - kk, r.top - kk, r.right + kk, r.bottom + kk), rad + kk, colorWithAlpha(rc, 14));
        }
        fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), rad + 3.0F, rc);
    } else if (kind != 1) {
        shadow(c, r, rad, 2.0F, 140);
    }
    if (kind == 1) {
        fill(c, r, rad, Color::rgb(24, 26, 30));
        line(c, r.left + rad, r.top + 1.5F, r.right - rad, r.top + 1.5F, Color::argb(150, 0, 0, 0), 2.0F);
    } else {
        ColorInt top = Color::rgb(44, 48, 55), bot = Color::rgb(35, 38, 43);
        if (kind == 2) { top = Color::rgb(82, 180, 255); bot = Color::rgb(23, 96, 194); }
        else if (kind == 3) { top = Color::rgb(58, 50, 36); bot = Color::rgb(43, 38, 25); }
        fillV(c, r, rad, top, bot);
        line(c, r.left + rad, r.top + 1.5F, r.right - rad, r.top + 1.5F, Color::argb(kind == 2 ? 110 : 30, 255, 255, 255), 1.0F);
    }
    strokeRR(c, r, rad, Color::rgb(8, 9, 11), 1.0F);
}

void SilvetonSamplerView::listGridCell(Canvas& c, const RectF& r, int idx, const std::optional<ListItem>& item, bool active, bool chosen, bool isMarked) {
    listCellFace(c, r, isMarked ? 3 : (active ? 2 : (item ? 0 : 1)), chosen);
    if (isDown(r)) fill(c, r, 8.0F, Color::argb(60, 0, 0, 0));
    text(c, pad3(idx + 1), r.left + 12.0F, r.top + 20.0F, 14.0F, active ? Color::rgb(207, 230, 255) : Color::rgb(127, 139, 152), Opt().monoBold());
    if (listFavs.count(idx) != 0) {
        text(c, "★", r.right - 12.0F, r.top + 21.0F, 17.0F, active ? Color::WHITE : NL_AMBER, Opt().right());
    }
    if (item) {
        text(c, item->name, r.left + 12.0F, r.top + 39.0F, 16.0F, active ? Color::WHITE : Color::rgb(233, 237, 242), Opt().bold().maxW(r.width() - 50.0F));
    } else {
        text(c, "—", r.left + 12.0F, r.top + 39.0F, 16.0F, Color::rgb(91, 99, 108));
    }
}

// SILVETON_NEW_LOOK_V1: the INFO of a blend (picture list_info.png). It is drawn over the whole screen at the end of drawList and, like a dialog,
// only it answers touches while it is open: OK closes it (and ends the marking), a tap on the dark outside closes it.
void SilvetonSamplerView::drawListInfo(Canvas& c) {
    hits.clear();
    pairHits.clear();
    smoothRangeHits.clear();
    listLongHits.clear();
    listCells_.clear();
    fill(c, RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), 0.0F, Color::argb(199, 0, 0, 0));
    // (the drag handler is only there so that a swipe over the dark does not turn the LIST page under it)
    hit(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), [](float, float) {}, nullptr, [this](float, float, bool final) {
        if (final && !dragMoved) { listInfoOpen_ = false; invalidate(); }
    });
    const RectF dlg(190.0F, 40.0F, 1150.0F, 760.0F);
    for (int k = 3; k >= 1; --k) {   // the amber frame of a window: a soft glow
        const float kk = static_cast<float>(k) * 3.0F;
        fill(c, RectF(dlg.left - kk, dlg.top - kk, dlg.right + kk, dlg.bottom + kk), 12.0F + kk, colorWithAlpha(NL_AMBER, 16));
    }
    nlPanel(c, dlg);
    strokeRR(c, dlg, 12.0F, NL_AMBER, 2.0F);
    hit(dlg, [](float, float) {}, nullptr, [](float, float, bool) {});

    text(c, listInfo_.title, 220.0F, 82.0F, 24.0F, Color::WHITE, Opt().bold().maxW(900.0F));
    const RectF nameBox(220.0F, 104.0F, 1120.0F, 168.0F);
    nlLcd(c, nameBox);
    text(c, listInfo_.name, nameBox.left + 16.0F, nameBox.top + 38.0F, 24.0F, NL_VALUE, Opt().bold().maxW(nameBox.width() - 32.0F));

    nlLabel(c, "SOUNDS OF THE BLEND", 220.0F, 194.0F, false, NL_TXT2, 11.0F);
    for (int i = 0; i < 7; ++i) {
        const float y = 204.0F + static_cast<float>(i) * 36.0F;
        const bool has = !listInfo_.upNo[i].empty();
        listCellFace(c, RectF(220.0F, y, 1120.0F, y + 32.0F), has ? 0 : 1, false);
        text(c, i == 6 ? std::string("LOWER") : "UPPER " + std::to_string(i + 1), 236.0F, y + 19.0F, 13.0F, Color::rgb(138, 147, 157), Opt().bold().spacing(0.1F));
        text(c, has ? listInfo_.upNo[i] : std::string("—"), 360.0F, y + 20.0F, 14.0F, Color::rgb(127, 139, 152), Opt().monoBold());
        text(c, has ? listInfo_.upName[i] : std::string("—"), 440.0F, y + 20.0F, 15.0F, has ? Color::WHITE : Color::rgb(91, 99, 108),
             Opt().bold().maxW(660.0F));
    }

    // a black box with one line of text for each entry (the picture has one line in 44 units; more lines make the box higher)
    const auto linesBox = [this, &c](const RectF& at, const std::vector<std::string>& rows) {
        const int n = static_cast<int>(rows.size());
        const float lineH = n <= 1 ? 22.0F : std::min(22.0F, 132.0F / static_cast<float>(n));
        const float h = n <= 1 ? 44.0F : 12.0F + static_cast<float>(n) * lineH;
        const RectF box(at.left, at.top, at.right, at.top + h);
        nlLcd(c, box);
        const float size = n <= 1 ? 14.0F : std::min(14.0F, lineH - 3.5F);
        for (int i = 0; i < n; ++i) {
            const float base = n <= 1 ? box.top + 25.0F : box.top + 6.0F + lineH * (static_cast<float>(i) + 0.5F) + size * 0.36F;
            text(c, rows[static_cast<std::size_t>(i)], box.left + 14.0F, base, size, NL_VALUE, Opt().maxW(box.width() - 28.0F));
        }
    };
    nlLabel(c, "ENGINE PLACES", 220.0F, 476.0F, false, NL_TXT2, 11.0F);
    linesBox(RectF(220.0F, 486.0F, 656.0F, 530.0F), listInfo_.places.empty() ? std::vector<std::string>{"—"} : listInfo_.places);
    nlLabel(c, "EFFECTS", 684.0F, 476.0F, false, NL_TXT2, 11.0F);
    std::vector<std::string> fxRows;
    fxRows.push_back(listInfo_.sends.empty() ? std::string("—") : listInfo_.sends);
    if (!listInfo_.inserts.empty()) fxRows.push_back("INSERT  " + listInfo_.inserts);
    linesBox(RectF(684.0F, 486.0F, 1120.0F, 530.0F), fxRows);
    // (the picture also shows T / Q / TRANSPOSE here: a stored blend does not keep them, the program has nothing to show; the star is on the title row)
    if (listInfo_.fav) text(c, "★ FAVOURITE", 1120.0F, 82.0F, 14.0F, Color::rgb(207, 214, 222), Opt().right().monoBold());

    if (listInfoK_ + 1U < infoQueue_.size()) {   // several blends were marked: the next one
        const RectF nextR(508.0F, 640.0F, 808.0F, 710.0F);
        nlBtn(c, nextR, "NEXT  " + std::to_string(listInfoK_ + 2U) + " / " + std::to_string(infoQueue_.size()), NlBtn::Plain, 16.0F, true);
        hit(nextR, [this](float, float) { showBlendInfo(listInfoK_ + 1U); });
    }
    const RectF okR(820.0F, 640.0F, 1120.0F, 710.0F);
    nlBtn(c, okR, "OK", NlBtn::On, 16.0F, true);
    hit(okR, [this](float, float) { listInfoOpen_ = false; listEndMarking(); invalidate(); });
}

// SILVETON_PASTE_V1 (the Manager's copy)
void SilvetonSamplerView::setPasteOffer(const std::string& label, std::function<void(int)> paste) {
    pasteLabel_ = label;
    pasteAction_ = std::move(paste);
    listPasteMode_ = false;
    invalidate();
}

void SilvetonSamplerView::showPasteMenu(int index) {
    listSelected = index;
    showItems("LIST " + pad3(index + 1), {"PASTE: " + pasteLabel_}, [this, index](int which) {   // SILVETON_NEW_LOOK_V1: the words of the pictures
        if (which == 0 && pasteAction_) { const auto act = pasteAction_; act(index); }
    }, "CANCEL");
}

void SilvetonSamplerView::listPasted(int first, int count) {
    if (first < 0 || count <= 0) return;
    listPasteMode_ = false;
    page_ = Page::LIST;
    listSelected = first;
    listPage = std::clamp(first / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    refreshListCache();
    flash(count == 1 ? "PASTED: LIST " + pad3(first + 1) : "PASTED " + std::to_string(count) + " SOUNDS FROM LIST " + pad3(first + 1));
    invalidate();
}

// SILVETON_SET_SAVE_AS_V1
void SilvetonSamplerView::saveSetAs() {
    showTextPage("SAVE SET  (LIST + BLENDS + SETTINGS)", "SILVETON SET", [this](const std::string& name) {
        const auto doSave = [this, name]() {
            const std::optional<std::string> err = sampler.saveSetAs(name);
            flash(!err ? "THE SET IS SAVED: " + trimmed(name) : "ERROR: " + *err);
        };
        if (sampler.setExists(name)) {
            showConfirm("SAVE SET", "The set “" + trimmed(name) + "” already exists.\nSave over it?", "YES, SAVE", doSave, "NO");
        } else {
            doSave();
        }
    });
}

void SilvetonSamplerView::loadSet() {
    const std::vector<std::string> sets = sampler.savedSets();
    if (sets.empty()) {
        showMessage("LOAD SET", "There are no saved sets.\nSave one from SETTINGS → SET. Folder: " + sampler.setsFolders());
        return;
    }
    std::vector<std::pair<std::string, std::string>> items;
    for (std::size_t i = 0; i < sets.size(); ++i) items.emplace_back(fmtZeroPad(static_cast<long long>(i) + 1, 2), sets[i]);
    showGridPicker("LOAD SET  -  SAVED SETS", items, -1, std::nullopt, [this, sets](int index) {
        const std::string name = sets[static_cast<std::size_t>(index)];
        showConfirm("LOAD SET  “" + name + "“",
                    "The whole LIST, the blends and the settings are replaced by those of the set.\nThe current ones are lost if they are not saved as a set.",
                    "LOAD", [this, name]() {
                        setPasteOffer("", nullptr);
                        copiedClip.reset();
                        copiedSound_.reset();
                        const std::optional<std::string> err = sampler.loadSavedSet(name);
                        if (!err) {
                            refreshListCache();
                            loadedFromList = cachedActiveListEntry;
                            listSelected = cachedActiveListEntry;
                            listFollowedActive = cachedActiveListEntry;
                            editingCombiSlot.reset();
                            if (const auto item = realListItem(cachedActiveListEntry); item && item->combiBank == 0 && item->combiPage == 0)
                                editingCombiSlot = item->combiSlot;
                            listPage = listSelected >= 0 ? listSelected / LIST_PER_PAGE : 0;
                            cachedCombiName = sampler.combiName();
                            refreshAllUppers();
                            refreshFx();
                            refreshGlobal();
                            flash("SET LOADED: " + name);
                            reportMissingSounds();
                        } else {
                            flash("ERROR: " + *err);
                        }
                    }, "CANCEL");
    });
}

// SILVETON_LIST_POSITIONS_V1: a LIST position with a BLEND (nullopt = empty position).
std::optional<SilvetonSamplerView::ListItem> SilvetonSamplerView::realListItem(int index) {
    if (index < 0 || index >= static_cast<int>(cachedListItems.size())) return std::nullopt;
    const ListItem& it = cachedListItems[static_cast<std::size_t>(index)];
    if (sampler.isEmptyListItem(it)) return std::nullopt;
    return it;
}

void SilvetonSamplerView::listCard(Canvas& c, const RectF& r, const std::optional<ListItem>& item, int idx, bool selected) {
    if (selected) fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), 15.0F, C_ACCENT);
    else if (item) shadow(c, r, 12.0F, 2.0F, 50);
    fill(c, r, 12.0F, !item ? C_EMPTY_CARD : (selected ? C_STRIP_SEL : C_STRIP));
    if (isDown(r)) fill(c, r, 12.0F, Color::argb(28, 0, 0, 0));
    led(c, r.left + 22.0F, r.centerY(), selected, 5.0F, true);
    const RectF box(r.left + 40.0F, r.centerY() - 22.0F, r.left + 124.0F, r.centerY() + 22.0F);
    lcd(c, box, 8.0F);
    text(c, pad3(idx + 1), box.centerX(), box.centerY() + 8.0F, 22.0F, item ? C_LCD : C_LCD_DIM, Opt().center().mono());
    if (item) {
        text(c, item->name, r.left + 142.0F, r.centerY() + 3.0F, 24.0F, C_INK, Opt().bold().maxW(r.width() - 160.0F));
        text(c, blendAddress(*item), r.left + 142.0F, r.centerY() + 27.0F, 12.0F, C_LABEL_GREY, Opt().mono().spacing(0.1F));
    } else {
        text(c, "—", r.left + 142.0F, r.centerY() + 9.0F, 24.0F, C_EMPTY_TEXT);
    }
}

std::string SilvetonSamplerView::blendAddress(const ListItem& item) {
    if (item.combiBank == 0 && item.combiPage == 0) return "BLEND " + pad3(item.combiSlot);
    return "COMBI B" + std::to_string(item.combiBank + 1) + " P" + std::to_string(item.combiPage + 1) + " S" + std::to_string(item.combiSlot);
}

void SilvetonSamplerView::editListCombi(const ListItem& item, int index) {
    askSaveThen([this, item, index]() {   // SILVETON_SAVEQ_V1
        if (sampler.activateListEntry(0, 0, 0, index)) {
            editingCombiSlot = item.combiSlot;
            loadedFromList = index;
            page_ = Page::COMBI;
            cachedCombiName = sampler.combiName();
            refreshAllUppers();
            refreshFx();
            reportMissingSounds();   // SILVETON_OPEN_WITHOUT_SOUND_V1
            invalidate();
        }
    });
}

// SILVETON_SAVEQ_V1 (Цветомир, 01.11.2026): before another blend is opened, a change of the open one is asked about:
// ЗАПИШИ (into the place it came from, same name) / НЕ ЗАПАЗВАЙ / ОТКАЗ (stay). MUTE / SOLO alone are not a change (they are played live).
void SilvetonSamplerView::askSaveThen(std::function<void()> proceed) {
    if (!sampler.blendEdited()) { proceed(); return; }
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Message;
    d->title = "SAVE THE CHANGES?";   // SILVETON_NEW_LOOK_V1: the words of the picture dialogs_misc
    // the name the player knows is the one in the LIST (the name inside the blend is only "COMBI" until it is written under a name)
    const std::optional<ListItem> open = loadedFromList >= 0 ? realListItem(loadedFromList) : std::nullopt;
    d->message = (open ? "You changed “" + open->name + "”" : std::string("You changed the open blend")) +
                 " and have not stored it yet. If you open another blend, the changes are lost.";
    d->buttons.push_back({"CANCEL", nullptr});
    d->buttons.push_back({"DO NOT SAVE", proceed});
    d->buttons.push_back({"SAVE", [this, proceed]() { saveOpenThen(proceed); }});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::saveOpenThen(std::function<void()> proceed) {
    const std::optional<ListItem> item = loadedFromList >= 0 ? realListItem(loadedFromList) : std::nullopt;
    if (!item) { openStore(); return; }   // this blend has no place in the ЛИСТ yet: choose one on the ЗАПИШИ screen
    const int index = sampler.writeCombiToList(loadedFromList, item->name);
    if (index < 0) { showMessage("SAVING FAILED", failureText(sampler.lastFailure())); return; }
    refreshListCache();
    flash("STORED: LIST " + pad3(index + 1) + "  „" + item->name + "“");
    proceed();
}

// SILVETON_OPEN_WITHOUT_SOUND_V1: the blend opened without a sound that is no longer in the bank; say which parts are off.
void SilvetonSamplerView::reportMissingSounds() {
    const std::string raw = sampler.lastRecallMissing();
    if (raw.empty()) return;
    std::string lines;
    int count = 0;
    std::size_t at = 0U;
    while (at < raw.size()) {
        std::size_t end = raw.find('\n', at);
        if (end == std::string::npos) end = raw.size();
        const std::string row = raw.substr(at, end - at);
        at = end + 1U;
        std::vector<std::string> f;
        std::size_t s = 0U;
        for (;;) {
            const std::size_t t = row.find('\t', s);
            f.push_back(row.substr(s, t == std::string::npos ? std::string::npos : t - s));
            if (t == std::string::npos) break;
            s = t + 1U;
        }
        if (f.size() < 4U) continue;
        ++count;
        if (count > 8) continue;
        const int part = std::atoi(f[0].c_str());
        const int layer = std::atoi(f[1].c_str());
        // SILVETON_NEW_LOOK_V1: the words of the picture dialogs_misc ("UPPER 2 · slot 044"); the 7th Upper is called LOWER
        const std::string who = (part < 7 ? "UPPER " + std::to_string(part) : (part == 7 ? std::string("LOWER") : "ENGINE " + std::to_string(part - 7))) +
                                (layer == 0 ? std::string() : " · L" + std::to_string(layer));
        lines += "\n" + who + " · slot " + pad3(std::atoi(f[3].c_str())) + (f[2].empty() ? std::string() : " · " + f[2]);
    }
    if (count > 8) lines += "\n… and " + std::to_string(count - 8) + " more";
    showMessage("MISSING SOUNDS", "These sounds are not in the bank:" + lines);
}

void SilvetonSamplerView::showListContextMenu(int index, const ListItem& item) {
    // SILVETON_LIST_MENU_V2: EDIT COMBI, FAVOURITE, RENAME, INFO, DUPLICATE, COPY, CUT, MOVE, DELETE.
    // SILVETON_NEW_LOOK_V1: the words of the picture list_menu, two keys in a row (the picture has no MOVE key; MOVE stays, a function must not be lost).
    // The codes are the ones of listRowAction (0..5 as before, 6 INFO, 7 DUPLICATE, 8 CUT).
    const std::vector<int> targets = listTargets(index);
    bool allFav = true;
    for (const int t : targets) if (listFavs.count(t) == 0U) allFav = false;
    const std::string favLabel = allFav ? "☆ REMOVE FAVOURITE" : "★ FAVOURITE";
    static const int kCodes[9] = {0, 1, 2, 6, 7, 3, 8, 4, 5};
    std::vector<std::string> actions = {"EDIT BLEND", favLabel, "RENAME", "INFO", "DUPLICATE", "COPY", "CUT", "MOVE", "DELETE"};
    const bool paste = static_cast<bool>(pasteAction_);   // SILVETON_PASTE_V1: first item while the Manager has copied sounds
    if (paste) actions.insert(actions.begin(), "PASTE: " + pasteLabel_);
    const std::string title = targets.size() > 1U ? std::to_string(targets.size()) + " MARKED BLENDS" : pad3(index + 1) + "   " + item.name;
    showItems(title, actions, [this, index, paste](int which) {
        if (paste) {
            if (which == 0) { if (pasteAction_) { const auto act = pasteAction_; act(index); } return; }
            --which;
        }
        listRowAction(index, kCodes[std::clamp(which, 0, 8)]);
    }, "CANCEL");
    if (!dialogStack.empty()) dialogStack.back()->itemCols = 2;
}

// the blends an action of the menu works on: all the marked ones, or the one that was held
std::vector<int> SilvetonSamplerView::listTargets(int index) {
    std::vector<int> out;
    if (listMarkMode_) for (const int i : listMarked_) if (realListItem(i)) out.push_back(i);   // (a set: in the order of the positions)
    if (!listMarkMode_ && realListItem(index)) out.push_back(index);
    return out;
}

void SilvetonSamplerView::listEndMarking() {
    listMarkMode_ = false;
    listMarked_.clear();
    listPaintMode_ = -1;
}

// Marking by dragging: the drag starts on the cell where the finger went down. Started on an unmarked blend it marks everything the finger
// passes, started on a marked one it unmarks. A tap without a drag toggles that one cell.
void SilvetonSamplerView::listPaintTouch(float x, float y, bool final) {
    const auto cellAt = [this](float px, float py) {
        for (const auto& cell : listCells_) if (cell.second.contains(px, py)) return cell.first;
        return -1;
    };
    const auto apply = [this](int idx, bool mark) {
        if (idx < 0 || !realListItem(idx)) return;
        if (mark) listMarked_.insert(idx); else listMarked_.erase(idx);
    };
    if (listPaintMode_ < 0) {
        const int start = cellAt(downX, downY);
        if (start < 0 || !realListItem(start)) return;
        listPaintMode_ = listMarked_.count(start) != 0U ? 0 : 1;
        apply(start, listPaintMode_ == 1);
        listPaintX_ = downX;
        listPaintY_ = downY;
    }
    const float dx = x - listPaintX_, dy = y - listPaintY_;
    const int steps = std::max(1, static_cast<int>(std::sqrt(dx * dx + dy * dy) / 12.0F));   // no cell is skipped by a fast finger
    for (int k = 1; k <= steps; ++k) {
        const float f = static_cast<float>(k) / static_cast<float>(steps);
        apply(cellAt(listPaintX_ + dx * f, listPaintY_ + dy * f), listPaintMode_ == 1);
    }
    listPaintX_ = x;
    listPaintY_ = y;
    if (final) listPaintMode_ = -1;
    invalidate();
}

// SILVETON_WORKFLOW_V1: the actions of the LIST menu, for the screens' own menu and for the Mac's menu
int SilvetonSamplerView::listRowAt(float rawX, float rawY) const {
    if (page_ != Page::LIST || writeOpen || dialogIsOpen() || picker || listInfoOpen_) return -1;
    const float x = (rawX - uiOffsetX) / uiScale;
    const float y = (rawY - uiOffsetY) / uiScale;
    for (const auto& cell : listCells_) if (cell.second.contains(x, y)) return cell.first;
    return -1;
}

bool SilvetonSamplerView::listRowInfo(int index, std::string& name, bool& favourite) {
    favourite = listFavs.count(index) != 0;
    const std::optional<ListItem> item = realListItem(index);
    if (!item) { name.clear(); return false; }
    name = item->name;
    return true;
}

void SilvetonSamplerView::listRowAction(int index, int which) {
    const std::optional<ListItem> found = realListItem(index);
    if (!found) return;
    const ListItem item = *found;
    listSelected = index;
    const std::vector<int> targets = listTargets(index);   // SILVETON_LIST_MENU_V2: all the marked blends, or this one
    if (targets.empty()) return;
    const bool many = targets.size() > 1U;
    switch (which) {
        case 0: {   // EDIT COMBI: one blend opens in COMBI - with several marked, the first of them
            const std::optional<ListItem> first = realListItem(targets.front());
            if (first) editListCombi(*first, targets.front());
            listEndMarking();
            break;
        }
        case 1: {   // FAVOURITE: all marked get the star, or lose it when they all have it
            bool allFav = true;
            for (const int t : targets) if (listFavs.count(t) == 0U) allFav = false;
            for (const int t : targets) { if (allFav) listFavs.erase(t); else listFavs.insert(t); }
            sampler.saveListFavourites(listFavs);
            break;
        }
        case 2:   // RENAME: one after the other
            renameQueue_ = targets;
            renameNext(0U);
            break;
        case 3:   // COPY / MOVE: done on the LIST screen itself, like CUT (Цветомир, 04.11.2026: no screen for choosing the place) - hold an empty position
            listCopyOffer(targets);
            break;
        case 4:
            listCutOffer(targets, "MOVE");
            break;
        case 5:
            if (many) { deleteMarkedListEntries(); break; }
            // SILVETON_LIST_NAME_ONLY_V1 (Цветомир, 01.11.2026): only the name leaves the LIST and the place is free again; the blend and its sounds stay
            // SILVETON_NEW_LOOK_V1: the words of the picture dialogs_misc
            showConfirm("DELETE LIST " + pad3(index + 1),
                        "“" + item.name + "” will be removed from the LIST.\nOnly the position is freed. The sounds stay.",
                        "DELETE", [this, index]() {
                            if (sampler.deleteLiveListEntry(index)) {
                                if (loadedFromList == index) loadedFromList = -1;
                                listFavs.erase(index);
                                sampler.saveListFavourites(listFavs);
                                refreshListCache();
                            } else {
                                showMessage("DELETING FAILED", failureText(sampler.lastFailure()));
                            }
                            listEndMarking();
                            invalidate();
                        }, "CANCEL");
            break;
        case 6:   // INFO: what the blend holds, one blend after the other
            infoQueue_ = targets;
            showBlendInfo(0U);
            break;
        case 7: listDuplicate(targets); break;   // DUPLICATE
        case 8: listCutOffer(targets); break;    // CUT
        default: break;
    }
    invalidate();
}

void SilvetonSamplerView::renameNext(std::size_t k) {
    while (k < renameQueue_.size() && !realListItem(renameQueue_[k])) ++k;
    if (k >= renameQueue_.size()) { listEndMarking(); refreshListCache(); invalidate(); return; }
    const int idx = renameQueue_[k];
    const std::string head = renameQueue_.size() > 1U ? "RENAME BLEND  " + std::to_string(k + 1U) + " / " + std::to_string(renameQueue_.size()) : "RENAME BLEND";   // SILVETON_NEW_LOOK_V1
    showTextPage(head, realListItem(idx)->name, [this, idx, k](const std::string& newName) {
        if (!sampler.renameLiveListEntry(idx, newName)) {
            showMessage("RENAME FAILED", failureText(sampler.lastFailure()));
            return;
        }
        refreshListCache();
        if (loadedFromList == idx) cachedCombiName = trimmed(newName);
        renameNext(k + 1U);
    });
}

// INFO of a stored blend: the sounds of the 7 Uppers, the SILVETON SYNTH places in use, the effects
// SILVETON_NEW_LOOK_V1: shown as the INFO window of the picture list_info (drawListInfo, drawn over the LIST); the facts are read here, once
void SilvetonSamplerView::showBlendInfo(std::size_t k) {
    if (k >= infoQueue_.size()) { listInfoOpen_ = false; listEndMarking(); invalidate(); return; }
    const int idx = infoQueue_[k];
    const std::optional<ListItem> item = realListItem(idx);
    if (!item) { showBlendInfo(k + 1U); return; }
    const std::string raw = sampler.blendInfo(*item);
    ListInfoView v;
    v.title = "INFO  ·  LIST " + pad3(idx + 1);
    v.name = item->name;
    v.fav = listFavs.count(idx) != 0U;
    std::size_t at = 0U;
    while (at < raw.size()) {
        std::size_t end = raw.find('\n', at);
        if (end == std::string::npos) end = raw.size();
        const std::string row = raw.substr(at, end - at);
        at = end + 1U;
        std::vector<std::string> f;
        std::size_t s0 = 0U;
        for (;;) {
            const std::size_t t = row.find('\t', s0);
            f.push_back(row.substr(s0, t == std::string::npos ? std::string::npos : t - s0));
            if (t == std::string::npos) break;
            s0 = t + 1U;
        }
        if (f.size() < 3U) continue;
        if (f[0] == "U" && f.size() >= 5U) {
            const int upper = std::atoi(f[1].c_str());
            const int no = std::atoi(f[2].c_str());
            if (upper >= 1 && upper <= 7 && no > 0) {
                v.upNo[upper - 1] = pad3(no);
                v.upName[upper - 1] = (f[3].empty() ? std::string("no name") : f[3]) + (f[4] == "0" ? std::string("  (OFF)") : std::string());
            }
        } else if (f[0] == "P" && f.size() >= 5U) {
            std::string line = "PLACE " + f[1] + " · SILVETON SOLO";
            if (f[4] == "0") line += "  (OFF)";
            v.places.push_back(line);
        } else if (f[0] == "F") {
            const int t = std::atoi(f[2].c_str());
            if (t > 0) v.sends += (v.sends.empty() ? "" : "  ·  ") + std::string("FX ") + f[1] + " " + utf8Upper(effectName(t));
        } else if (f[0] == "I") {
            v.inserts += (v.inserts.empty() ? "" : "   ") + f[1] + " " + utf8Upper(effectName(std::atoi(f[2].c_str())));
        }
    }
    listInfo_ = v;
    listInfoK_ = k;
    listInfoOpen_ = true;
    invalidate();
}

// The toolbar and context menu use the same operations and selection.
void SilvetonSamplerView::listToolbarAction(int which) {
    const auto targets = listTargets(listSelected);
    if (targets.empty()) { flash("SELECT A BLEND FIRST"); return; }
    listRowAction(targets.front(), which);
}

void SilvetonSamplerView::listPasteAt(int index) {
    if (!pasteAction_ || index < 0 || index >= LIST_SIZE) return;
    listSelected = index;
    const auto paste = pasteAction_; // a successful CUT clears its own offer
    paste(index);
}

// Duplicate makes independent stored blends from a frozen clipboard snapshot.
void SilvetonSamplerView::listDuplicate(const std::vector<int>& from) {
    if (from.empty()) return;
    if (!listClipboardOffer(from, false, "DUPLICATE")) return;
    const int destination = std::min(LIST_SIZE - static_cast<int>(from.size()), from.back() + 1);
    listPasteAt(destination);
}

bool SilvetonSamplerView::listClipboardOffer(const std::vector<int>& from, bool cut, const std::string& word) {
    Ctrl::ListClipboard clipboard;
    if (!sampler.captureListClipboard(from, cut, clipboard)) {
        showMessage(word + " FAILED", failureText(sampler.lastFailure()));
        return false;
    }
    const std::string label = clipboard.items.size() == 1U ? clipboard.items.front().name
        : std::to_string(clipboard.items.size()) + " BLENDS";
    listEndMarking();
    listStoreMode_ = false;
    setPasteOffer(word + " " + label, [this, clipboard](int destination) {
        int first = -1;
        if (!sampler.pasteListClipboard(clipboard, destination, first)) {
            showMessage(clipboard.cut ? "MOVE FAILED" : "PASTE FAILED", failureText(sampler.lastFailure()));
            return;
        }
        refreshListCache();
        listFavs = sampler.listFavourites();
        loadedFromList = cachedActiveListEntry;
        listFollowedActive = cachedActiveListEntry;
        listSelected = first;
        listPage = std::clamp(first / LIST_PER_PAGE, 0, LIST_PAGES - 1);
        listPasteMode_ = false;
        if (clipboard.cut) { pasteAction_ = nullptr; pasteLabel_.clear(); }
        flash(std::string(clipboard.cut ? "MOVED " : "PASTED ") + std::to_string(clipboard.items.size()) + " · LIST " + pad3(first + 1));
        invalidate();
    });
    listPasteMode_ = true;
    flash(word + " · TAP THE DESTINATION · OTHER BLENDS SHIFT");
    invalidate();
    return true;
}

void SilvetonSamplerView::listCutOffer(const std::vector<int>& from, const char* word) {
    listClipboardOffer(from, true, word);
}

void SilvetonSamplerView::listCopyOffer(const std::vector<int>& from) {
    listClipboardOffer(from, false, "COPY");
}

} // namespace silveton::ui::classic
