// SILVETON_NEW_LOOK_V1 - the approved new look (pictures in gui/png): colours, widgets, top bar and bottom nav.
// Everything here is drawn with plain gradients and lines (no blur filters), so it stays light for the tablet's video card.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
constexpr double kPiL = 3.14159265358979323846;
int roundToInt(float v) { return static_cast<int>(std::nearbyint(v)); }
// a colour a little darker (amount 0..255 taken off every channel)
ColorInt shade(ColorInt color, int amount) {
    return Color::rgb(std::max(0, Color::red(color) - amount), std::max(0, Color::green(color) - amount), std::max(0, Color::blue(color) - amount));
}
}

void SilvetonSamplerView::strokeRR(Canvas& c, const RectF& r, float radius, ColorInt color, float w) {
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = w;
    paint.color = color;
    c.drawRoundRect(r, radius, radius, paint);
    paint.style = Style::Fill;
}

void SilvetonSamplerView::nlChassis(Canvas& c) {
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    paint.shader = linearGradient(0.0F, 0.0F, 0.0F, DESIGN_H, std::vector<ColorInt>{Color::rgb(29, 31, 35), Color::rgb(19, 20, 23), Color::rgb(14, 15, 17)},
                                  std::vector<float>{0.0F, 0.55F, 1.0F}, TileMode::Clamp);
    c.drawRect(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), paint);
    paint.shader = nullptr;
    strokeRR(c, RectF(1.0F, 1.0F, DESIGN_W - 1.0F, DESIGN_H - 1.0F), 2.0F, Color::rgb(43, 47, 53), 2.0F);
}

void SilvetonSamplerView::nlPanel(Canvas& c, const RectF& r, const std::string& title, bool sel, bool dim) {
    shadow(c, r, 12.0F, 4.0F, dim ? 50 : 90);
    if (sel) {   // a soft blue glow: a few translucent rings
        for (int k = 3; k >= 1; --k) {
            const float kk = static_cast<float>(k) * 3.0F;
            fill(c, RectF(r.left - kk, r.top - kk, r.right + kk, r.bottom + kk), 12.0F + kk, colorWithAlpha(NL_BLUE, 16));
        }
    }
    fillV(c, r, 12.0F, dim ? Color::rgb(36, 39, 44) : Color::rgb(43, 47, 53), dim ? Color::rgb(24, 26, 30) : Color::rgb(28, 31, 35));
    line(c, r.left + 12.0F, r.top + 1.0F, r.right - 12.0F, r.top + 1.0F, Color::argb(dim ? 20 : 30, 255, 255, 255), 1.0F);
    strokeRR(c, r, 12.0F, sel ? NL_BLUE : Color::rgb(8, 9, 11), sel ? 2.0F : 1.0F);
    if (!title.empty()) text(c, title, r.left + 14.0F, r.top + 20.0F, 11.0F, dim ? NL_MUT : NL_BLUE, Opt().bold().spacing(0.16F).maxW(r.width() - 28.0F));
}

void SilvetonSamplerView::nlSub(Canvas& c, const RectF& r) {
    fillV(c, r, 10.0F, Color::rgb(32, 35, 40), Color::rgb(25, 27, 31));
    line(c, r.left + 10.0F, r.top + 1.0F, r.right - 10.0F, r.top + 1.0F, Color::argb(150, 0, 0, 0), 2.0F);
    strokeRR(c, r, 10.0F, Color::rgb(8, 9, 11), 1.0F);
    line(c, r.left + 10.0F, r.bottom + 0.5F, r.right - 10.0F, r.bottom + 0.5F, Color::argb(18, 255, 255, 255), 1.0F);
}

void SilvetonSamplerView::nlLcd(Canvas& c, const RectF& r, float radius) {
    glass_.push_back(r);   // SILVETON_COLOR_KEYS_V1
    fillV(c, r, radius, Color::rgb(5, 7, 10), Color::rgb(13, 18, 24));
    paint.color = Color::BLACK;
    paint.shader = linearGradient(0.0F, r.top, 0.0F, r.top + 10.0F, Color::argb(190, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawRoundRect(r, radius, radius, paint);
    paint.shader = nullptr;
    strokeRR(c, r, radius, Color::rgb(2, 3, 4), 1.0F);
    line(c, r.left + radius, r.bottom + 0.5F, r.right - radius, r.bottom + 0.5F, Color::argb(20, 255, 255, 255), 1.0F);
}

void SilvetonSamplerView::nlBtn(Canvas& c, const RectF& r, const std::string& label, NlBtn state, float size, bool lamp) {
    const bool down = isDown(r);
    ColorInt top, bot, txt, lampOn = Color::rgb(20, 23, 26);
    bool glow = false;
    ColorInt glowC = NL_BLUE;
    switch (state) {
        case NlBtn::Sel:   top = Color::rgb(82, 180, 255); bot = Color::rgb(23, 96, 194); txt = Color::WHITE; lampOn = Color::rgb(228, 243, 255); glow = true; break;
        case NlBtn::On:    top = Color::rgb(255, 197, 98); bot = Color::rgb(224, 135, 0); txt = Color::rgb(28, 19, 4); lampOn = Color::rgb(255, 244, 216); glow = true; glowC = NL_AMBER; break;
        case NlBtn::Red:   top = Color::rgb(255, 122, 126); bot = Color::rgb(183, 42, 47); txt = Color::WHITE; lampOn = Color::rgb(255, 217, 218); glow = true; glowC = NL_RED; break;
        case NlBtn::Panic: top = Color::rgb(238, 90, 95); bot = Color::rgb(154, 31, 36); txt = Color::WHITE; lampOn = Color::rgb(255, 201, 203); break;
        case NlBtn::Green: top = Color::rgb(96, 206, 130); bot = Color::rgb(30, 118, 64); txt = Color::WHITE; lampOn = Color::rgb(220, 255, 230); break;
        case NlBtn::Off:   top = Color::rgb(71, 77, 85); bot = Color::rgb(39, 43, 48); txt = Color::rgb(121, 130, 140); break;
        default:           top = Color::rgb(71, 77, 85); bot = Color::rgb(39, 43, 48); txt = Color::rgb(179, 187, 196); break;
    }
    const float rad = std::min(8.0F, r.height() * 0.3F);
    if (!down) shadow(c, r, rad, 3.0F, 130);
    if (glow && !down) {
        for (int k = 2; k >= 1; --k) {
            const float kk = static_cast<float>(k) * 3.0F;
            fill(c, RectF(r.left - kk, r.top - kk, r.right + kk, r.bottom + kk), rad + kk, colorWithAlpha(glowC, 20));
        }
    }
    fill(c, r, rad, Color::rgb(8, 9, 11));
    const RectF face(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - (down ? 1.0F : 2.0F));
    fillV(c, face, rad - 1.0F, down ? shade(top, 18) : top, down ? shade(bot, 18) : bot);
    if (!down) line(c, face.left + rad, face.top + 1.0F, face.right - rad, face.top + 1.0F, Color::argb(state == NlBtn::Plain || state == NlBtn::Off ? 60 : 110, 255, 255, 255), 1.0F);
    if (lamp && r.height() >= 30.0F) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, lampOn);
    }
    // two lines: "SOUND\nSELECT"
    const std::size_t nl = label.find('\n');
    if (nl == std::string::npos) {
        text(c, label, r.centerX(), r.centerY() + size * 0.36F + (lamp && r.height() >= 30.0F ? 2.0F : 0.0F), size, txt, Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
    } else {
        text(c, label.substr(0U, nl), r.centerX(), r.centerY() - size * 0.05F + (lamp ? 2.0F : 0.0F), size, txt, Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
        text(c, label.substr(nl + 1U), r.centerX(), r.centerY() + size * 1.05F + (lamp ? 2.0F : 0.0F), size, txt, Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
    }
}

void SilvetonSamplerView::nlValue(Canvas& c, const RectF& r, const std::string& value, float size, ColorInt color) {
    glass_.push_back(r);   // SILVETON_COLOR_KEYS_V1
    fillV(c, r, 6.0F, Color::rgb(5, 7, 10), Color::rgb(13, 18, 24));
    paint.color = Color::BLACK;
    paint.shader = linearGradient(0.0F, r.top, 0.0F, r.top + 6.0F, Color::argb(170, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawRoundRect(r, 6.0F, 6.0F, paint);
    paint.shader = nullptr;
    strokeRR(c, r, 6.0F, Color::rgb(2, 3, 4), 1.0F);
    text(c, value, r.centerX(), r.centerY() + size * 0.36F, size, color, Opt().center().monoBold().maxW(r.width() - 8.0F));
}

void SilvetonSamplerView::nlLabel(Canvas& c, const std::string& s, float x, float y, bool center, ColorInt color, float size) {
    Opt o = Opt().bold().spacing(0.13F);
    if (center) o = o.center();
    text(c, s, x, y, size, color, o);
}

void SilvetonSamplerView::nlKnob(Canvas& c, float cx, float cy, float r, float t, bool bipolar, bool amber, bool dots) {
    const float tt = std::clamp(t, 0.0F, 1.0F);
    paint.shader = nullptr;
    paint.style = Style::Fill;
    if (dots) {   // the value: a ring of small dots, the lit ones blue
        const int n = 21;
        const float rr = r * 1.30F + 3.0F;
        const float dotR = std::max(1.6F, r * 0.06F);
        for (int i = 0; i < n; ++i) {
            const float f = static_cast<float>(i) / static_cast<float>(n - 1);
            const double a = (135.0 + 270.0 * static_cast<double>(f)) * kPiL / 180.0;
            bool lit;
            if (bipolar) lit = tt >= 0.5F ? (f >= 0.5F - 0.001F && f <= tt + 0.001F) : (f <= 0.5F + 0.001F && f >= tt - 0.001F);
            else lit = f <= tt + 0.001F && tt > 0.002F;
            paint.color = lit ? NL_BLUE : Color::rgb(38, 42, 48);
            c.drawCircle(cx + static_cast<float>(std::cos(a)) * rr, cy + static_cast<float>(std::sin(a)) * rr, dotR, paint);
        }
    }
    // bezel with a drop shadow
    paint.color = Color::BLACK;
    paint.shader = radialGradient(cx, cy + r * 0.28F, r * 1.3F, Color::argb(150, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawCircle(cx, cy + r * 0.22F, r * 1.3F, paint);
    paint.shader = radialGradient(cx, cy, r, Color::rgb(44, 48, 54), Color::rgb(19, 21, 24), TileMode::Clamp);
    c.drawCircle(cx, cy, r, paint);
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = 1.0F;
    paint.color = Color::rgb(5, 6, 7);
    c.drawCircle(cx, cy, r, paint);
    paint.color = Color::argb(40, 255, 255, 255);
    c.drawArc(RectF(cx - r + 1.5F, cy - r + 1.5F, cx + r - 1.5F, cy + r - 1.5F), 200.0F, 140.0F, false, paint);
    paint.style = Style::Fill;
    paint.color = Color::BLACK;   // a shader is drawn with the alpha of the paint colour
    // silver cap
    const float cr = r * 0.80F;
    paint.shader = sweepGradient(cx, cy, std::vector<ColorInt>{Color::rgb(225, 229, 233), Color::rgb(140, 147, 155), Color::rgb(241, 243, 245), Color::rgb(123, 130, 138),
                                                               Color::rgb(214, 218, 222), Color::rgb(148, 155, 163), Color::rgb(236, 238, 241), Color::rgb(132, 139, 147),
                                                               Color::rgb(225, 229, 233)}, {});
    c.drawCircle(cx, cy, cr, paint);
    paint.shader = radialGradient(cx - cr * 0.32F, cy - cr * 0.48F, cr * 1.05F, Color::argb(160, 255, 255, 255), Color::argb(0, 255, 255, 255), TileMode::Clamp);
    c.drawCircle(cx, cy, cr, paint);
    paint.shader = radialGradient(cx, cy, cr, Color::argb(0, 0, 0, 0), Color::argb(72, 0, 0, 0), TileMode::Clamp);
    c.drawCircle(cx, cy, cr, paint);
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = 1.0F;
    paint.color = Color::argb(150, 0, 0, 0);
    c.drawCircle(cx, cy, cr, paint);
    // indicator
    const double ang = (135.0 + 270.0 * static_cast<double>(tt)) * kPiL / 180.0;
    const float cs = static_cast<float>(std::cos(ang));
    const float sn = static_cast<float>(std::sin(ang));
    paint.color = amber ? NL_AMBER : Color::rgb(19, 22, 26);
    paint.strokeWidth = std::max(3.0F, r * 0.11F);
    paint.strokeCap = Cap::Round;
    c.drawLine(cx + cs * cr * 0.22F, cy + sn * cr * 0.22F, cx + cs * cr * 0.80F, cy + sn * cr * 0.80F, paint);
    paint.strokeCap = Cap::Butt;
    paint.style = Style::Fill;
}

void SilvetonSamplerView::nlFaderCap(Canvas& c, float cx, float cy, float w, float h) {
    const RectF r(cx - w / 2.0F, cy - h / 2.0F, cx + w / 2.0F, cy + h / 2.0F);
    shadow(c, r, 7.0F, 4.0F, 150);
    fill(c, r, 8.0F, Color::rgb(16, 18, 20));
    const RectF f(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F);
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    paint.shader = linearGradient(f.left, 0.0F, f.right, 0.0F,
                                  std::vector<ColorInt>{Color::rgb(138, 145, 153), Color::rgb(227, 231, 234), Color::rgb(169, 176, 183), Color::rgb(227, 231, 234), Color::rgb(124, 131, 139)},
                                  std::vector<float>{0.0F, 0.18F, 0.5F, 0.82F, 1.0F}, TileMode::Clamp);
    c.drawRoundRect(f, 7.0F, 7.0F, paint);
    paint.shader = nullptr;
    for (float y = f.top + 3.0F; y < f.bottom - 2.0F; y += 4.0F) line(c, f.left + 3.0F, y, f.right - 3.0F, y, Color::argb(70, 0, 0, 0), 2.0F);
    fill(c, RectF(f.left + 4.0F, cy - 1.5F, f.right - 4.0F, cy + 1.5F), 1.0F, Color::rgb(19, 22, 26));
    strokeRR(c, r, 8.0F, Color::rgb(16, 18, 20), 1.0F);
}

// ---------------------------------------------------------------------------------------------- pages
void SilvetonSamplerView::goPage(Page p, int combiMode) {
    if (scaleOpen_) closeScalePage();
    page_ = p;
    flashText.reset();
    scaleOpen_ = false;   // SILVETON_SCALE_PAGE_V1: any page key leaves the SCALE page
    saveOpen_ = false;
    listCancelPasteSelection();
    markMode = false;   // strip selection must never silently remain a marking gesture on LIVE
    if (p == Page::COMBI && combiMode == MODE_LIVE) { linkOn = false; marked.fill(false); }
    if (p != Page::LIST) listStoreMode_ = false;   // SILVETON_LIST_STORE_V1
    if (p == Page::COMBI && combiMode >= 0) combiMode_ = combiMode;
    if (p == Page::LIST) refreshListCache();
    if (p == Page::COMBI) cachedCombiName = sampler.combiName();
    if (p == Page::EFFECTS) refreshFx();
    if (p == Page::SETTINGS) refreshGlobal();
    invalidate();
}

void SilvetonSamplerView::openListEntry(int idx) {
    const std::optional<ListItem> item = realListItem(idx);
    if (!item) return;
    const ListItem it = *item;
    listSelected = idx;
    askSaveThen([this, idx, it]() {   // changes of the open blend are asked about first
        if (sampler.activateListEntry(0, 0, 0, idx)) {
            cachedActiveListEntry = idx;
            listFollowedActive = idx;
            loadedFromList = idx;
            if (it.combiBank == 0 && it.combiPage == 0) editingCombiSlot = it.combiSlot;
            cachedCombiName = sampler.combiName();
            refreshAllUppers();
            refreshFx();
            reportMissingSounds();
            invalidate();
        }
    });
}

void SilvetonSamplerView::stepBlend(int dir) {
    int from = loadedFromList >= 0 ? loadedFromList : cachedActiveListEntry;
    if (from < 0) from = dir > 0 ? -1 : LIST_SIZE;
    for (int i = from + dir; i >= 0 && i < LIST_SIZE; i += dir) {
        if (realListItem(i)) { openListEntry(i); return; }
    }
    flash(dir > 0 ? "THIS IS THE LAST BLEND" : "THIS IS THE FIRST BLEND");
}

// ---------------------------------------------------------------------------------------------- top bar
void SilvetonSamplerView::drawTopBar(Canvas& c) {
    const Ctrl::AudioStatus a = frameAudioStatus;
    const Ctrl::MidiStatus m = frameMidiStatus;
    const std::int64_t now = nowMs();
    const bool midiRx = now < midiFlashUntilMs;
    const bool keyFlash = midiRx && (m.status & 0xF0) == 0x90 && m.data2 > 0;
    const bool midiConnected = std::max(midiConnections, m.deviceCount) > 0;
    std::string midiValue;
    if (keyFlash) midiValue = midiNoteName(m.data1);
    else if (midiRx) midiValue = "RX";
    else if (midiConnected) midiValue = "ON";
    else if (m.lastError != 0) midiValue = "E" + std::to_string(-m.lastError);
    else midiValue = "OFF";
    const bool running = sampler.audioRunning();
    const bool classicAudio = a.sampleRate == 96000 && a.framesPerBurst == 96 && a.bufferSizeFrames == 192;
    const bool audioOk = running && (classicAudio ||
        (a.sampleRate >= 44100 && a.framesPerBurst >= 16 && a.framesPerBurst <= 512 && a.bufferSizeFrames == a.framesPerBurst * 2));

    // logo
    text(c, "SILVETON", 22.0F, 38.0F, 24.0F, Color::rgb(238, 242, 246), Opt().bold().spacing(0.2F));
    text(c, "SAMPLER", 22.0F, 56.0F, 10.0F, NL_BLUE, Opt().bold().spacing(0.3F));
    paint.shader = linearGradient(20.0F, 0.0F, 196.0F, 0.0F, NL_BLUE, Color::argb(0, 51, 160, 255), TileMode::Clamp);
    paint.style = Style::Fill;
    c.drawRect(RectF(20.0F, 79.0F, 196.0F, 81.0F), paint);
    paint.shader = nullptr;

    // PREV / NEXT
    const RectF prev(206.0F, 10.0F, 270.0F, 82.0F);
    const RectF next(688.0F, 10.0F, 752.0F, 82.0F);
    nlBtn(c, prev, "◀ PREV", NlBtn::Plain, 10.5F);
    nlBtn(c, next, "NEXT ▶", NlBtn::Plain, 10.5F);
    hit(prev, [this](float, float) { stepBlend(-1); });
    hit(next, [this](float, float) { stepBlend(1); });

    // the display: BLEND number, name, where it came from
    const RectF big(280.0F, 10.0F, 678.0F, 82.0F);
    nlLcd(c, big);
    const bool flashOn = flashText.has_value() && now < flashUntilMs;
    const std::string num = loadedFromList >= 0 ? fmtZeroPad(loadedFromList + 1, 3) : std::string("---");
    text(c, "LIST " + num + " / " + std::to_string(LIST_SIZE), big.left + 14.0F, big.top + 18.0F, 11.0F, NL_BLUE, Opt().bold());
    text(c, openBlendLabel(), big.left + 14.0F, big.top + 46.0F, 23.0F, Color::WHITE, Opt().bold().maxW(368.0F));
    const bool edited = sampler.blendEdited();
    const std::string sub = loadedFromList >= 0 ? "Tap to open this LIST position" : "Current blend · choose SAVE TO LIST to store";
    text(c, flashOn ? *flashText : sub, big.left + 14.0F, big.top + 64.0F, 10.5F, flashOn ? C_LCD_OK : NL_TXT2, Opt().maxW(368.0F));
    if (edited) {
        fill(c, RectF(big.right - 91.0F, big.top + 6.0F, big.right - 12.0F, big.top + 24.0F), 4.0F, Color::rgb(78, 54, 22));
        text(c, "EDITED", big.right - 51.5F, big.top + 19.0F, 10.0F, NL_AMBER, Opt().center().bold());
    }
    hit(big, [this](float, float) {
        goPage(Page::LIST);
        if (loadedFromList >= 0) { listSelected = loadedFromList; listPage = loadedFromList / LIST_PER_PAGE; listSearch.clear(); listFavOnly = false; }
        invalidate();
    });

    const RectF list(764.0F, 10.0F, 852.0F, 82.0F);
    nlBtn(c, list, "OPEN\nLIST", page_ == Page::LIST && !scaleOpen_ && !saveOpen_ ? NlBtn::Sel : NlBtn::Plain, 14.0F);
    hit(list, [this](float, float) { goPage(Page::LIST); });
    const RectF save(864.0F, 10.0F, 952.0F, 82.0F);
    nlBtn(c, save, "SAVE", saveOpen_ ? NlBtn::Sel : (edited ? NlBtn::On : NlBtn::Plain), 16.0F);
    hit(save, [this](float, float) { if (saveOpen_) { saveOpen_ = false; invalidate(); } else openSavePage(); });

    // status: AUDIO / XRUN / MIDI and CPU / VOICES / MASTER
    const RectF st(964.0F, 10.0F, 1200.0F, 82.0F);
    nlLcd(c, st);
    std::optional<GlobalUiState> gm = globalState;
    if (!gm) { gm = sampler.globalUiState(); if (gm) globalState = gm; }
    const float mg = gm ? gm->masterGainDb : -6.0F;
    struct Cell { const char* label; std::string value; ColorInt color; bool dot; };
    const Cell colA[3] = {
        {"AUDIO", a.estimatedLatencyMs >= 0.0 ? fmtFixed(a.estimatedLatencyMs, 1) + " ms" : std::string("—"), audioOk ? NL_VALUE : C_LCD_BAD, audioOk},
        {"XRUN", std::to_string(a.xrunCount), a.xrunCount > 0 ? C_LCD_BAD : NL_VALUE, false},
        {"MIDI", midiValue, midiRx ? Color::WHITE : (midiConnected ? C_LCD_OK : NL_VALUE), false}};
    const Cell colB[3] = {
        {"CPU", std::to_string(roundToInt(a.cpuLoadPercent)) + " %", a.cpuLoadPercent > 95.0F ? C_LCD_BAD : NL_VALUE, false},
        {"VOICES", std::to_string(a.activeVoices), NL_VALUE, false},
        {"MASTER", fmtFixed(static_cast<double>(mg), 1) + " dB", mg > 0.0F ? C_LCD_BAD : NL_VALUE, false}};
    for (int col = 0; col < 2; ++col) {
        const Cell* cells = col == 0 ? colA : colB;
        const float x0 = st.left + 8.0F + static_cast<float>(col) * 114.0F;
        for (int k = 0; k < 3; ++k) {
            const float yy = st.top + 22.0F + static_cast<float>(k) * 21.0F;
            if (cells[k].dot) { paint.style = Style::Fill; paint.color = NL_BLUE; c.drawCircle(x0 + 3.5F, yy - 4.0F, 3.5F, paint); }
            text(c, cells[k].label, x0 + (cells[k].dot ? 10.0F : 0.0F), yy - 1.0F, 8.5F, Color::rgb(127, 139, 152), Opt().bold().spacing(0.05F));
            text(c, cells[k].value, x0 + 104.0F, yy, 11.5F, cells[k].color, Opt().right().monoBold().maxW(62.0F));
        }
    }
    hit(RectF(st.left, st.top, st.left + 114.0F, st.bottom), [this](float, float) { settingsTab = 0; goPage(Page::SETTINGS); });
    hit(RectF(st.left + 114.0F, st.top, st.right, st.top + 44.0F), [this](float, float) { settingsTab = 0; goPage(Page::SETTINGS); });
    // MASTER: tap = number, double tap = -6 dB
    hit(RectF(st.left + 114.0F, st.top + 46.0F, st.right, st.bottom),
        [this, gm](float, float) {
            if (gm) {
                const GlobalUiState gg = *gm;
                showNumber("MASTER dB", gg.masterGainDb, -60.0F, 18.0F, 1, [this, gg](float v) { GlobalUiState n = gg; n.masterGainDb = v; commitGlobal(n); });
            }
        },
        [this, gm]() { if (gm) { GlobalUiState n = *gm; n.masterGainDb = -6.0F; commitGlobal(n); } });

    // PANIC
    const RectF panic(1210.0F, 10.0F, 1320.0F, 82.0F);
    nlBtn(c, panic, "PANIC", NlBtn::Panic, 15.0F);
    hit(panic, [this](float, float) { sampler.panic(); });
}

// ---------------------------------------------------------------------------------------------- bottom nav
namespace {
// small line icons, drawn in a 26 x 26 box centred on (cx, cy)
void navIcon(SilvetonSamplerView& v, Canvas& c, int kind, float cx, float cy, ColorInt col);
}

void SilvetonSamplerView::drawBottomNav(Canvas& c) {
    struct Tab { const char* label; Page page; int mode; };
    static const Tab tabs[7] = {{"LIVE", Page::COMBI, MODE_LIVE}, {"MIXER", Page::COMBI, MODE_MIXER}, {"LIST", Page::LIST, -1}, {"SOUND EDIT", Page::COMBI, MODE_EDIT},
                                {"ENGINE", Page::ENGINES, -1}, {"EFFECTS", Page::EFFECTS, -1}, {"SETTINGS", Page::SETTINGS, -1}};
    for (int i = 0; i < 7; ++i) {
        const RectF b(20.0F + static_cast<float>(i) * 187.0F, 706.0F, 198.0F + static_cast<float>(i) * 187.0F, 782.0F);
        const bool on = page_ == tabs[i].page && (tabs[i].page != Page::COMBI || combiMode_ == tabs[i].mode);
        nlBtn(c, b, "", on ? NlBtn::Sel : NlBtn::Plain, 15.0F);
        const ColorInt col = on ? Color::WHITE : Color::rgb(179, 187, 196);
        const float labW = textWidth(tabs[i].label, 15.0F, Face::Bold, 0.07F);
        const float total = 26.0F + 9.0F + labW;
        const float x0 = b.centerX() - total / 2.0F;
        navIcon(*this, c, i, x0 + 13.0F, b.centerY() + 2.0F, col);
        text(c, tabs[i].label, x0 + 35.0F, b.centerY() + 8.0F, 15.0F, col, Opt().bold().spacing(0.07F).maxW(b.width() - 56.0F));
        const Page p = tabs[i].page;
        const int mode = tabs[i].mode;
        hit(b, [this, p, mode](float, float) { goPage(p, mode); });
    }
}

namespace {
void navIcon(SilvetonSamplerView& v, Canvas& c, int kind, float cx, float cy, ColorInt col) {
    (void)v;
    Paint p;
    p.antiAlias = true;
    p.style = Style::Stroke;
    p.strokeWidth = 2.4F;
    p.strokeCap = Cap::Round;
    p.color = col;
    auto ln = [&](float x1, float y1, float x2, float y2) { c.drawLine(cx + x1, cy + y1, cx + x2, cy + y2, p); };
    switch (kind) {
        case 0:   // LIVE: level bars
            ln(-9, 8, -9, 0); ln(-4, 8, -4, -6); ln(1, 8, 1, -9); ln(6, 8, 6, -3); ln(11, 8, 11, 2);
            break;
        case 1:   // MIXER: three sliders
            ln(-8, -9, -8, 9); ln(0, -9, 0, 9); ln(8, -9, 8, 9);
            ln(-11, -2, -5, -2); ln(-3, 4, 3, 4); ln(5, -5, 11, -5);
            break;
        case 2:   // LIST
            ln(-4, -8, 11, -8); ln(-4, 0, 11, 0); ln(-4, 8, 11, 8);
            p.style = Style::Fill; c.drawCircle(cx - 10.0F, cy - 8.0F, 1.8F, p); c.drawCircle(cx - 10.0F, cy, 1.8F, p); c.drawCircle(cx - 10.0F, cy + 8.0F, 1.8F, p);
            break;
        case 3:   // SOUND EDIT: a wave
            ln(-12, 2, -9, -6); ln(-9, -6, -5, 8); ln(-5, 8, -1, -8); ln(-1, -8, 3, 6); ln(3, 6, 7, -4); ln(7, -4, 12, 1);
            break;
        case 4:   // ENGINE: a chip
            p.style = Style::Stroke; c.drawRoundRect(RectF(cx - 7.0F, cy - 7.0F, cx + 7.0F, cy + 7.0F), 2.5F, 2.5F, p);
            ln(-3, -11, -3, -7); ln(3, -11, 3, -7); ln(-3, 7, -3, 11); ln(3, 7, 3, 11); ln(-11, -3, -7, -3); ln(-11, 3, -7, 3); ln(7, -3, 11, -3); ln(7, 3, 11, 3);
            break;
        case 5:   // EFFECTS: a dot and two arcs
            p.style = Style::Fill; c.drawCircle(cx - 5.0F, cy, 3.0F, p);   // both arcs are centred on the dot (the picture: a dot and two close arcs)
            p.style = Style::Stroke;
            c.drawArc(RectF(cx - 13.0F, cy - 8.0F, cx + 3.0F, cy + 8.0F), -50.0F, 100.0F, false, p);
            c.drawArc(RectF(cx - 19.0F, cy - 14.0F, cx + 9.0F, cy + 14.0F), -45.0F, 90.0F, false, p);
            break;
        default: {   // SETTINGS: a small gear
            p.style = Style::Stroke;
            c.drawCircle(cx, cy, 5.0F, p);
            for (int k = 0; k < 8; ++k) {
                const double a = k * kPiL / 4.0;
                const float cs = static_cast<float>(std::cos(a)), sn = static_cast<float>(std::sin(a));
                c.drawLine(cx + cs * 8.0F, cy + sn * 8.0F, cx + cs * 12.0F, cy + sn * 12.0F, p);
            }
            break;
        }
    }
}
}   // namespace

} // namespace silveton::ui::classic
