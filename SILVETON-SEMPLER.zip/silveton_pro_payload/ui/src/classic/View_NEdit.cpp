// SILVETON_NEW_LOOK_V1 - SOUND EDIT of the new look: the frame (UPPER chips, group list, content panel with the SOUND selector, hint line,
// MARK / LINK / COPY / PASTE row) and the groups SAMPLE (drawEditTune), MULTISAMPLE (drawEditRange), FILTER, ENVELOPE, MODULATION.
// VELOCITY (drawEditVelocity, neSoundRows) is in View_Velocity.cpp; WAVE, EQ, VOICE, MIDI CONTROL are in View_NEdit2.cpp / View_Eq.cpp.
// Every group function draws only the BODY of the content panel (232,160,1088x490) in absolute design units, with the numbers measured
// from the approved pictures (gui/png/sample.png, multisample.png, velocity.png, filter.png, envelope.png, modulation.png).
// Nothing here changes what a control does: the same values, ranges and commit functions as the old TUNE / RANGE / TONE pages are used.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expf_(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rnd(float v) { return static_cast<int>(std::nearbyint(v)); }
float rndf(float v) { return std::nearbyint(v); }

constexpr int kOfsN = 4;                                         // MS1..MS4 (= kOfsZones of the engine)
const float kStartQuick[5] = {0.0F, 10.0F, 25.0F, 60.0F, 120.0F};   // the quick values of OFS / START (ms)
constexpr ColorInt kLitText = Color::rgb(255, 177, 58);          // text of a lit key (#ffb13a)
constexpr ColorInt kDashEdge = Color::rgb(75, 82, 91);           // the dashed frame (#4b525b)
const char* const kGroupNames[10] = {"SAMPLE", "MULTISAMPLE", "VELOCITY", "FILTER", "ENVELOPE", "MODULATION", "WAVE", "EQ", "VOICE", "MIDI CONTROL"};
const char* const kLegacyNames[6] = {"ATTACK", "DECAY", "SUSTAIN", "RELEASE", "CUTOFF", "RESONANCE"};

// a time: "OFF" (or "0 ms") at zero, else milliseconds / seconds (the old msText)
std::string msTxt(float v, bool zeroOff) {
    if (v <= 0.0F) return zeroOff ? std::string("OFF") : std::string("0 ms");
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), 2) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}
// the part of a drag that counts after the first few units (so a handle does not jump when the drag starts)
float afterSlop(float d, float slop) {
    const float sgn = d > 0.0F ? 1.0F : (d < 0.0F ? -1.0F : 0.0F);
    return std::fabs(d) <= slop ? 0.0F : d - sgn * slop;
}
} // namespace

// ---------------------------------------------------------------- small parts
std::string SilvetonSamplerView::neUpperName(int u) { return u == 6 ? std::string("LOWER") : "UPPER " + std::to_string(u + 1); }

SilvetonSamplerView::UpperTab SilvetonSamplerView::neTabOf(int group) {
    switch (group) {
        case EG_TUNE: return UpperTab::TUNE;
        case EG_RANGE: return UpperTab::RANGE;
        case EG_VELOCITY: return UpperTab::VELOCITY;
        case EG_FILTER:
        case EG_ENVELOPE:
        case EG_MODULATION: return UpperTab::TONE;
        case EG_WAVE: return UpperTab::WAVE;
        case EG_EQ: return UpperTab::EQ;
        case EG_VOICE: return UpperTab::PORTA;
        case EG_MIDICTL: return UpperTab::CONTROL;
        default: break;
    }
    return UpperTab::TUNE;
}

void SilvetonSamplerView::neKey(Canvas& c, const RectF& r, const std::string& label, NeKey state, float size, bool lamp) {
    switch (state) {
        case NeKey::Sel: nlBtn(c, r, label, NlBtn::Sel, size, lamp); return;
        case NeKey::On: nlBtn(c, r, label, NlBtn::On, size, lamp); return;
        case NeKey::Off: nlBtn(c, r, label, NlBtn::Off, size, lamp); return;
        case NeKey::Plain: nlBtn(c, r, label, NlBtn::Plain, size, lamp); return;
        case NeKey::Lit: break;
    }
    // Lit: a dark key, an amber lamp bar on top, amber text
    nlBtn(c, r, std::string(), NlBtn::Plain, size, lamp);
    const bool lampOk = lamp && r.height() >= 30.0F;
    if (lampOk) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
    }
    text(c, label, r.centerX(), r.centerY() + size * 0.36F + (lampOk ? 2.0F : 0.0F), size, kLitText, Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
}

void SilvetonSamplerView::neDial(Canvas& c, float cx, float cy, float d, const std::string& label, const std::string& valueText, float value, float minV,
                                 float maxV, float step, float travel, bool bipolar, std::function<void(float)> onChange, std::function<void()> exact,
                                 std::function<void()> reset, float vw, float hitW, bool inert) {
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    nlKnob(c, cx, cy, d * 0.35F, t, bipolar, false, true);
    if (!label.empty()) nlLabel(c, label, cx, cy - d / 2.0F - 4.0F, true, NL_TXT2, 11.0F);
    const float boxW = vw > 0.0F ? vw : std::floor(d * 0.85F);
    const float fs = d >= 80.0F ? 13.0F : 12.0F;
    const float vTop = cy + d / 2.0F - 2.0F;
    nlValue(c, RectF(cx - boxW / 2.0F, vTop, cx + boxW / 2.0F, vTop + fs + 10.0F), valueText, fs);
    if (inert) return;
    const float hw = hitW > 0.0F ? hitW : std::max(boxW, d) + 10.0F;
    knobHit(RectF(cx - hw / 2.0F, cy - d / 2.0F - 14.0F, cx + hw / 2.0F, vTop), value, minV, maxV, step, travel, std::move(onChange), exact, reset);
    hit(RectF(cx - hw / 2.0F, vTop, cx + hw / 2.0F, vTop + fs + 14.0F), [exact](float, float) { exact(); }, reset);
}

void SilvetonSamplerView::neStepper(Canvas& c, float x, float y, const std::string& label, const std::string& value, std::function<void()> onMinus,
                                    std::function<void()> onPlus, std::function<void()> onReset) {
    nlLabel(c, label, x, y + 11.5F, false, NL_TXT2, 11.0F);
    const RectF minus(x, y + 22.0F, x + 64.0F, y + 86.0F);
    const RectF box(x + 72.0F, y + 22.0F, x + 184.0F, y + 86.0F);
    const RectF plus(x + 192.0F, y + 22.0F, x + 256.0F, y + 86.0F);
    nlBtn(c, minus, "−", NlBtn::Plain, 26.0F, false);
    nlLcd(c, box);
    text(c, value, box.centerX(), box.centerY() + 28.0F * 0.36F, 28.0F, NL_VALUE, Opt().center().monoBold().maxW(box.width() - 12.0F));
    nlBtn(c, plus, "+", NlBtn::Plain, 26.0F, false);
    hit(box, [](float, float) {}, onReset);   // a double tap on the value = 0
    hit(minus, [this, onMinus](float, float) { onMinus(); invalidate(); });
    hit(plus, [this, onPlus](float, float) { onPlus(); invalidate(); });
    pairHits.push_back(PairHit{minus, plus, [this, onReset] { onReset(); invalidate(); }});
}

void SilvetonSamplerView::neTrack(Canvas& c, const RectF& r) {
    const float rad = std::min(6.0F, r.height() / 2.0F);
    fill(c, r, rad, Color::rgb(11, 14, 18));
    line(c, r.left + rad, r.top + 1.0F, r.right - rad, r.top + 1.0F, Color::argb(160, 0, 0, 0), 2.0F);
}

void SilvetonSamplerView::neBar(Canvas& c, float x, float y, float w, float h, float lo, float hi, bool handles, float hr, bool dim, float fadeIn, float fadeOut) {
    neTrack(c, RectF(x, y, x + w, y + h));
    const float xl = x + w * std::clamp(lo, 0.0F, 1.0F);
    const float xr = x + w * std::clamp(hi, 0.0F, 1.0F);
    const ColorInt col = dim ? colorWithAlpha(NL_BLUE, 115) : NL_BLUE;
    if (fadeIn <= 0.0F && fadeOut <= 0.0F) {
        fill(c, RectF(xl, y, std::max(xr, xl + 2.0F), y + h), 5.0F, col);
    } else {   // the sound comes in over the fade-in and goes out over the fade-out: a ramp
        float xi = std::min(xl + w * fadeIn, xr);
        float xo = std::max(xr - w * fadeOut, xl);
        if (xi > xo) xi = xo = (xi + xo) * 0.5F;
        Path path;
        path.moveTo(xl, y + h);
        path.lineTo(xi, y);
        path.lineTo(xo, y);
        path.lineTo(xr, y + h);
        path.close();
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = col;
        c.drawPath(path, paint);
    }
    if (!handles) return;
    for (const float hx : {xl, xr}) {
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = dim ? colorWithAlpha(NL_AMBER, 128) : NL_AMBER;
        c.drawCircle(hx, y + h / 2.0F, hr, paint);
        paint.color = Color::rgb(11, 16, 20);
        c.drawCircle(hx, y + h / 2.0F, hr - 3.0F, paint);
    }
}

void SilvetonSamplerView::neDashed(Canvas& c, const RectF& r, ColorInt color) {
    const float rad = 10.0F;
    const float dash = 7.0F;
    const float gap = 5.0F;
    const auto edge = [&](float x1, float y1, float x2, float y2) {
        const float len = std::hypot(x2 - x1, y2 - y1);
        if (len < 1.0F) return;
        const float dx = (x2 - x1) / len;
        const float dy = (y2 - y1) / len;
        for (float p = 0.0F; p < len; p += dash + gap) {
            const float e = std::min(p + dash, len);
            line(c, x1 + dx * p, y1 + dy * p, x1 + dx * e, y1 + dy * e, color, 2.0F);
        }
    };
    edge(r.left + rad, r.top + 1.0F, r.right - rad, r.top + 1.0F);
    edge(r.left + rad, r.bottom - 1.0F, r.right - rad, r.bottom - 1.0F);
    edge(r.left + 1.0F, r.top + rad, r.left + 1.0F, r.bottom - rad);
    edge(r.right - 1.0F, r.top + rad, r.right - 1.0F, r.bottom - rad);
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = 2.0F;
    paint.color = color;
    const float d2 = rad * 2.0F;
    c.drawArc(RectF(r.left + 1.0F, r.top + 1.0F, r.left + 1.0F + d2, r.top + 1.0F + d2), 180.0F, 90.0F, false, paint);
    c.drawArc(RectF(r.right - 1.0F - d2, r.top + 1.0F, r.right - 1.0F, r.top + 1.0F + d2), 270.0F, 90.0F, false, paint);
    c.drawArc(RectF(r.right - 1.0F - d2, r.bottom - 1.0F - d2, r.right - 1.0F, r.bottom - 1.0F), 0.0F, 90.0F, false, paint);
    c.drawArc(RectF(r.left + 1.0F, r.bottom - 1.0F - d2, r.left + 1.0F + d2, r.bottom - 1.0F), 90.0F, 90.0F, false, paint);
    paint.style = Style::Fill;
}

// all 128 keys of a piano, the range low..high lit blue (the picture's mini keyboard)
void SilvetonSamplerView::neKeyboard(Canvas& c, const RectF& r, int low, int high) {
    const auto isBlack = [](int n) { const int pc = n % 12; return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10; };
    const float ww = r.width() / 75.0F;   // 75 white keys in 0..127
    int w = 0;
    for (int n = 0; n < 128; ++n) {
        if (isBlack(n)) continue;
        const float x0 = r.left + static_cast<float>(w) * ww;
        fill(c, RectF(x0, r.top, x0 + ww - 1.0F, r.bottom), 1.5F, (n >= low && n <= high) ? Color::rgb(127, 192, 255) : Color::rgb(217, 221, 226));
        ++w;
    }
    w = 0;
    for (int n = 0; n < 128; ++n) {
        if (!isBlack(n)) { ++w; continue; }
        const float bx = r.left + static_cast<float>(w) * ww;
        fill(c, RectF(bx - ww * 0.3F, r.top, bx + ww * 0.3F, r.top + r.height() * 0.62F), 1.5F, (n >= low && n <= high) ? Color::rgb(23, 102, 201) : Color::rgb(21, 24, 28));
    }
}

// the SOUND selector: MAIN (0) / L1..L4 (the old drop-down of an UPPER). An empty place opens the sound list at once.
void SilvetonSamplerView::neSelectSound(int u, int k) {
    selectSound(u, k);
    bool has;
    if (k == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        has = st && st->soundName != "EMPTY" && !isBlank(st->soundName);
    } else {
        has = layerSlot(u, k - 1) > 0;
    }
    if (!has) openPicker(u, k - 1);   // an empty place (MAIN or a layer): choose its sound straight away, like the old drop-down
}

void SilvetonSamplerView::neSetTranspose(int u, int sound, int v) {
    const int t = std::clamp(v, -12, 12);
    if (sound == 0) {
        if (!upperStates[static_cast<std::size_t>(u)]) return;
        UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
        n.transpose = t;
        commitTune(n);
    } else {
        setLParam(u, sound - 1, 3, static_cast<float>(t));
    }
}

// ---------------------------------------------------------------- the six legacy TONE values of a sound
float SilvetonSamplerView::neLegacy(int u, int sound, int k) {
    static const float defaults[6] = {5.0F, 80.0F, 1.0F, 120.0F, 20000.0F, 0.0F};
    const int kk = std::clamp(k, 0, 5);
    if (sound == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        return st ? toneValue(*st, static_cast<TonePar>(kk)) : defaults[kk];
    }
    const float v = getOr(lParams(u, sound - 1), 10 + kk, -1.0F);
    return v >= 0.0F ? v : defaults[kk];
}

void SilvetonSamplerView::neSetLegacy(int u, int sound, int k, float v) {
    if (sound == 0) setTone(static_cast<TonePar>(k), v);
    else setLParam(u, sound - 1, 10 + k, v);
}

void SilvetonSamplerView::neLegacyExact(int u, int sound, int k) {
    const TonePar p = static_cast<TonePar>(k);
    const float v = neLegacy(u, sound, k);
    const ToneRange range = toneRange(p);
    const bool pct = k == 2 || k == 5;
    showNumber(kLegacyNames[k], pct ? v * 100.0F : v, range.lo, range.hi, range.decimals,
               [this, u, sound, k, pct](float nv) { neSetLegacy(u, sound, k, pct ? nv / 100.0F : nv); }, true, [this, u, sound, k, v] { neSetLegacy(u, sound, k, v); });
}

void SilvetonSamplerView::neLegacyKnob(Canvas& c, float cx, float cy, float d, const std::string& label, int k) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    const TonePar p = static_cast<TonePar>(k);
    const float v = neLegacy(u, sound, k);
    neDial(c, cx, cy, d, label, toneText(p, v), toneToNorm(p, v), 0.0F, 1.0F, 0.002F, 260.0F, false,
           [this, u, sound, k, p](float nv) { neSetLegacy(u, sound, k, toneFromNorm(p, nv)); },
           [this, u, sound, k] { neLegacyExact(u, sound, k); },
           [this, u, sound, k] { neSetLegacy(u, sound, k, -1.0F); });   // double tap = the sound's own default
}

// ---------------------------------------------------------------- OFS (where the sample starts)
std::vector<int> SilvetonSamplerView::neVelZones(int u, int sound) {
    if (u < 0 || u > 6 || sound < 0 || sound > 4) return {};
    std::string key;
    if (sound == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        key = st ? st->soundName : std::string();
    } else {
        key = std::to_string(layerSlot(u, sound - 1));
    }
    NeZones& z = neZones_[static_cast<std::size_t>(u)][static_cast<std::size_t>(sound)];
    if (!z.valid || z.key != key) {   // asked from the engine only when the sound of the place changed
        z.zones = sampler.soundVelocityZones(u, sound);
        z.key = key;
        z.valid = true;
    }
    return z.zones;
}

float SilvetonSamplerView::neOfsZone(int u, int sound, int k) {
    const std::size_t id = static_cast<std::size_t>((sound == 0 ? 68 : 48) + std::clamp(k, 0, kOfsN - 1));
    const std::vector<float> p = sound == 0 ? uParams(u) : lParams(u, sound - 1);
    return id < p.size() ? p[id] : -1.0F;
}

void SilvetonSamplerView::neSetOfsZone(int u, int sound, int k, float ms) {
    const int id = (sound == 0 ? 68 : 48) + std::clamp(k, 0, kOfsN - 1);
    if (sound == 0) setUParam(u, id, ms); else setLParam(u, sound - 1, id, ms);
}

void SilvetonSamplerView::neSetOfsAll(int u, int sound, float ms) {
    setToneX(u, sound, 0, ms);
    for (int k = 0; k < kOfsN; ++k) if (neOfsZone(u, sound, k) >= 0.0F) neSetOfsZone(u, sound, k, -1.0F);
}

std::string SilvetonSamplerView::neOfsRange(const std::vector<int>& b, int k) {
    if (k < 0 || k >= static_cast<int>(b.size())) return "—";
    const int hi = k == 0 ? 127 : b[static_cast<std::size_t>(k - 1)] - 1;
    const int lo = k == kOfsN - 1 ? b.back() : b[static_cast<std::size_t>(k)];
    return std::to_string(lo) + "–" + std::to_string(hi);
}

// ---------------------------------------------------------------- the frame
void SilvetonSamplerView::drawSoundEdit(Canvas& c) {
    for (int i = 0; i < 7; ++i) {
        auto& slot = upperStates[static_cast<std::size_t>(i)];
        if (!slot) slot = sampler.upperState(i);
    }
    const int u = std::clamp(selectedUpper_, 0, 6);
    selectedUpper_ = u;
    editGroup_ = std::clamp(editGroup_, 0, static_cast<int>(EG_COUNT) - 1);
    int& chosen = stripSound[static_cast<std::size_t>(u)];
    chosen = std::clamp(chosen, 0, 4);
    editSound = chosen;          // the sound the groups edit: MAIN (0) or L1..L4 (the same number the old strips used)
    dropUpper = -1;
    tab = neTabOf(editGroup_);   // old code that reads `tab` still sees the page that belongs to the group

    // the seven UPPERs (touch = choose it; in mark mode = mark it)
    for (int i = 0; i < 7; ++i) {
        const RectF r(20.0F + static_cast<float>(i) * 187.0F, 98.0F, 198.0F + static_cast<float>(i) * 187.0F, 150.0F);
        const bool sel = i == u;
        nlBtn(c, r, std::string(), sel ? NlBtn::Sel : NlBtn::Plain, 13.0F, true);
        const ColorInt ink = sel ? Color::WHITE : Color::rgb(179, 187, 196);
        text(c, neUpperName(i), r.centerX(), r.top + 22.0F, 13.0F, ink, Opt().center().bold().spacing(0.12F).maxW(r.width() - 16.0F));
        const auto& st = upperStates[static_cast<std::size_t>(i)];
        const bool empty = !st || st->soundName == "EMPTY" || isBlank(st->soundName);
        text(c, empty ? std::string("—") : st->soundName, r.centerX(), r.top + 39.0F, 11.5F, colorWithAlpha(ink, 217), Opt().center().maxW(r.width() - 16.0F));
        if (marked[static_cast<std::size_t>(i)]) strokeRR(c, r, 8.0F, NL_AMBER, 2.0F);
        upperSelectAreas_.push_back({r, i});
        hit(r, [this, i](float, float) {
            if (markMode) marked[static_cast<std::size_t>(i)] = !marked[static_cast<std::size_t>(i)];
            else selectedUpper_ = i;
            invalidate();
        });
    }

    // the group list
    nlPanel(c, RectF(20.0F, 160.0F, 220.0F, 650.0F));
    for (int k = 0; k < 10; ++k) {
        const RectF r(30.0F, 170.0F + static_cast<float>(k) * 47.0F, 210.0F, 212.0F + static_cast<float>(k) * 47.0F);
        nlBtn(c, r, kGroupNames[k], k == editGroup_ ? NlBtn::Sel : NlBtn::Plain, 13.0F, true);
        hit(r, [this, k](float, float) { editGroup_ = k; tab = neTabOf(k); invalidate(); });
    }

    // the content panel: title, the SOUND selector (only for the groups of one sound) or the note for the groups of the whole UPPER
    nlPanel(c, RectF(232.0F, 160.0F, 1320.0F, 650.0F));
    text(c, kGroupNames[editGroup_], 250.0F, 185.5F, 13.0F, NL_BLUE, Opt().bold().spacing(0.16F));
    if (editGroup_ <= EG_WAVE) {
        nlLabel(c, "SOUND", 640.0F, 191.0F, false, NL_TXT2, 11.0F);
        for (int k = 0; k < 5; ++k) {
            const RectF r(720.0F + static_cast<float>(k) * 119.2F, 166.0F, 833.2F + static_cast<float>(k) * 119.2F, 204.0F);
            bool has;
            bool on;
            if (k == 0) {
                const auto& st = upperStates[static_cast<std::size_t>(u)];
                has = st && st->soundName != "EMPTY" && !isBlank(st->soundName);
                on = has;
            } else {
                has = layerSlot(u, k - 1) > 0;
                on = has && layerOn(u, k - 1);
            }
            neKey(c, r, k == 0 ? std::string("MAIN") : "L" + std::to_string(k), k == chosen ? NeKey::Sel : (on ? NeKey::Lit : NeKey::Off), 13.0F, true);
            hit(r, [this, u, k](float, float) { neSelectSound(u, k); });
        }
    } else {
        text(c, "applies to the whole " + neUpperName(u) + " (not to one sound)", 1310.0F, 188.0F, 12.0F, NE_HINT, Opt().right().maxW(670.0F));
    }

    // the body of the chosen group
    if (upperStates[static_cast<std::size_t>(u)]) {
        switch (editGroup_) {
            case EG_TUNE: drawEditTune(c); break;
            case EG_RANGE: drawEditRange(c); break;
            case EG_VELOCITY: drawEditVelocity(c); break;
            case EG_FILTER: drawEditFilter(c); break;
            case EG_ENVELOPE: drawEditEnvelope(c); break;
            case EG_MODULATION: drawEditModulation(c); break;
            case EG_WAVE: drawEditWave(c); break;
            case EG_EQ: drawEditEq(c); break;
            case EG_VOICE: drawEditVoice(c); break;
            default: drawEditMidiControl(c); break;
        }
    }
    if (editGroup_ != EG_WAVE && editGroup_ != EG_EQ && editGroup_ != EG_VOICE) {
        text(c, "drag a knob · double-tap = default · tap the value (or hold the knob) = type a number", 250.0F, 636.0F, 12.0F, NE_HINT, Opt());
    }
    lvMarkRow(c, 656.0F, 40.0F);   // MARK / LINK / COPY / PASTE: the same row as LIVE and MIXER
}

// ---------------------------------------------------------------- SAMPLE
void SilvetonSamplerView::drawEditTune(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const UpperState s = *upperStates[static_cast<std::size_t>(u)];
    const int l = sound - 1;   // layer index (-1 = MAIN)
    const std::vector<float> lp = sound > 0 ? lParams(u, l) : std::vector<float>();

    // OCTAVE and TRANSPOSE of the chosen sound (- / + keys; both keys together = 0)
    const int oct = sound == 0 ? s.octave : rnd(getOr(lp, 4, 0.0F));
    const int octLo = sound == 0 ? -4 : -3;
    neStepper(c, 250.0F, 232.0F, "OCTAVE", signed_(oct),
              [this, s, u, sound, oct, octLo] {
                  if (sound == 0) { UpperState cur = currentUpper(s); cur.octave = std::max(cur.octave - 1, octLo); commitTune(cur); }
                  else setLParam(u, sound - 1, 4, static_cast<float>(std::max(oct - 1, octLo)));
              },
              [this, s, u, sound, oct, octLo] {
                  if (sound == 0) { UpperState cur = currentUpper(s); cur.octave = std::min(cur.octave + 1, -octLo); commitTune(cur); }
                  else setLParam(u, sound - 1, 4, static_cast<float>(std::min(oct + 1, -octLo)));
              },
              [this, s, u, sound] {
                  if (sound == 0) { UpperState cur = currentUpper(s); cur.octave = 0; commitTune(cur); }
                  else setLParam(u, sound - 1, 4, 0.0F);
              });
    const int tr = sound == 0 ? s.transpose : rnd(getOr(lp, 3, 0.0F));   // the same value as the TRANSPOSE of MULTISAMPLE
    neStepper(c, 540.0F, 232.0F, "TRANSPOSE", signed_(tr),
              [this, u, sound, tr] { neSetTranspose(u, sound, tr - 1); },
              [this, u, sound, tr] { neSetTranspose(u, sound, tr + 1); },
              [this, u, sound] { neSetTranspose(u, sound, 0); });

    // FINE TUNE (cents), START, END (ms into the sample)
    const float fine = sound == 0 ? s.fineCents : getOr(lp, 5, 0.0F);
    const float fineLim = sound == 0 ? 1200.0F : 100.0F;
    const auto setFine = [this, s, u, sound](float nv) {
        if (sound == 0) { UpperState n = currentUpper(s); n.fineCents = nv; commitTune(n); }
        else setLParam(u, sound - 1, 5, nv);
    };
    neDial(c, 960.0F, 290.0F, 88.0F, "FINE TUNE", fmtFixed(static_cast<double>(fine), 2) + " ct", fine, -fineLim, fineLim, 1.0F, sound == 0 ? 600.0F : 260.0F, true,
           setFine, [this, fine, fineLim, setFine] { showNumber("ФИНА НАСТРОЙКА ct", fine, -fineLim, fineLim, 0, setFine); }, [setFine] { setFine(0.0F); });
    for (int k = 0; k < 2; ++k) {
        const float maxV = k == 0 ? 2000.0F : 60000.0F;
        const float v = toneX(u, sound, k);
        const float norm = lnf(std::clamp(v, 0.0F, maxV) + 1.0F) / lnf(maxV + 1.0F);
        const std::string label = k == 0 ? "START" : "END";
        neDial(c, 1090.0F + 130.0F * static_cast<float>(k), 290.0F, 88.0F, label, msTxt(v, true), norm, 0.0F, 1.0F, 0.002F, 300.0F, false,
               [this, u, sound, k, maxV](float nv) { setToneX(u, sound, k, rndf(expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(maxV + 1.0F)) - 1.0F)); },
               [this, u, sound, k, label, v, maxV] {
                   showNumber("SAMPLE " + label + " ms", v, 0.0F, maxV, 0, [this, u, sound, k](float x) { setToneX(u, sound, k, x); });
               },
               [this, u, sound, k] { setToneX(u, sound, k, 0.0F); });
    }

    // OFS: where the sample starts - ALL = the START of the whole sound, MS1..MS4 = one value for each velocity layer of the sound
    nlPanel(c, RectF(250.0F, 392.0F, 750.0F, 606.0F), "OFS · WHERE THE SAMPLE STARTS");
    const std::vector<int> zones = neVelZones(u, sound);
    const int nz = std::min(static_cast<int>(zones.size()), kOfsN);
    if (ofsSel_ > nz) ofsSel_ = 0;
    const float st = toneX(u, sound, 0);
    const float zv = ofsSel_ > 0 ? neOfsZone(u, sound, ofsSel_ - 1) : -1.0F;
    const float eff = zv >= 0.0F ? zv : st;
    for (int k = 0; k < 5; ++k) {
        const RectF kr(264.0F + 94.0F * static_cast<float>(k), 428.0F, 352.0F + 94.0F * static_cast<float>(k), 474.0F);
        const bool exists = k == 0 || k <= nz;
        neKey(c, kr, k == 0 ? std::string("ALL") : (exists ? "MS" + std::to_string(k) : std::string("—")), ofsSel_ == k ? NeKey::Sel : NeKey::Off, 13.0F, true);
        if (exists) hit(kr, [this, k](float, float) { ofsSel_ = k; invalidate(); });
    }
    nlLabel(c, "QUICK VALUE", 264.0F, 498.0F, false, NL_TXT2, 11.0F);
    for (int k = 0; k < 5; ++k) {
        const RectF qr(264.0F + 94.0F * static_cast<float>(k), 508.0F, 352.0F + 94.0F * static_cast<float>(k), 554.0F);
        neKey(c, qr, k == 0 ? std::string("OFF") : std::to_string(rnd(kStartQuick[k])) + " ms", std::fabs(eff - kStartQuick[k]) < 0.5F ? NeKey::On : NeKey::Off, 13.0F, true);
        hit(qr, [this, u, sound, k](float, float) {
            if (ofsSel_ == 0) neSetOfsAll(u, sound, kStartQuick[k]);
            else neSetOfsZone(u, sound, ofsSel_ - 1, kStartQuick[k]);
        });
    }
    const std::string cap = ofsSel_ == 0 ? "OFS ALL · " + msTxt(st, false) : "OFS MS" + std::to_string(ofsSel_) + " · velocity " + neOfsRange(zones, ofsSel_ - 1) + " · " + msTxt(eff, false);
    text(c, cap + "   (one value for all velocity zones, or one per MS1–MS4)", 264.0F, 578.0F, 12.0F, NE_HINT, Opt().maxW(472.0F));

    // the dashed panel: only for a layer (L1..L4); with MAIN chosen it is shown veiled and does nothing
    neDashed(c, RectF(770.0F, 392.0F, 1310.0F, 606.0F), kDashEdge);
    nlLabel(c, "ONLY WHEN L1 – L4 IS CHOSEN", 784.0F, 409.5F, false, NL_TXT2, 11.0F);
    const bool onLayer = sound > 0;
    const int slot = onLayer ? layerSlot(u, l) : 0;
    const RectF nameR(784.0F, 424.0F, 1034.0F, 468.0F);
    nlLcd(c, nameR);
    const std::string nm = slot > 0 ? fmtZeroPad(slot, 3) + "  " + lName(u, l) : (onLayer ? std::string("— NO SOUND —") : std::string("—"));
    text(c, nm, nameR.left + 12.0F, 452.5F, 16.0F, slot > 0 ? Color::WHITE : NL_MUT, Opt().bold().maxW(nameR.width() - 24.0F));
    const RectF onR(1042.0F, 424.0F, 1162.0F, 468.0F);
    const RectF offR(1170.0F, 424.0F, 1300.0F, 468.0F);
    neKey(c, onR, "LAYER ON", slot > 0 && layerOn(u, l) ? NeKey::Lit : NeKey::Off, 12.0F, true);
    neKey(c, offR, "REMOVE", slot > 0 ? NeKey::Plain : NeKey::Off, 12.0F, false);
    const float lvl = onLayer ? getOr(lp, 1, 0.0F) : 0.0F;
    const float pan = onLayer ? getOr(lp, 2, 0.0F) : 0.0F;
    neDial(c, 850.0F, 540.0F, 64.0F, "LEVEL", dbText(lvl), lvl, -60.0F, 12.0F, 0.1F, 260.0F, false,
           [this, u, l](float nv) { setLParam(u, l, 1, nv); },
           [this, u, l, lvl] { showNumber("LAYER " + std::to_string(l + 1) + " LEVEL", lvl, -60.0F, 12.0F, 2, [this, u, l](float x) { setLParam(u, l, 1, x); }); },
           [this, u, l] { setLParam(u, l, 1, 0.0F); }, 60.0F, 0.0F, !onLayer);
    neDial(c, 960.0F, 540.0F, 64.0F, "PAN", panText(pan), pan, -1.0F, 1.0F, 0.01F, 260.0F, true,
           [this, u, l](float nv) { setLParam(u, l, 2, nv); },
           [this, u, l, pan] { showNumber("LAYER " + std::to_string(l + 1) + " PAN", pan, -1.0F, 1.0F, 2, [this, u, l](float x) { setLParam(u, l, 2, x); }); },
           [this, u, l] { setLParam(u, l, 2, 0.0F); }, 60.0F, 0.0F, !onLayer);
    if (onLayer) {
        hit(nameR, [this, u, l](float, float) { openPicker(u, l); });
        hit(onR, [this, u, l, slot](float, float) {
            if (slot > 0) setLParam(u, l, 0, layerOn(u, l) ? 0.0F : 1.0F);
            else openPicker(u, l);
        });
        hit(offR, [this, u, l, slot](float, float) {
            if (slot <= 0) return;
            sampler.setLayerSound(u, l, 0);
            dropParamCaches(u);
            mirrorSound(u, l, std::nullopt);
            invalidate();
        });
    } else {
        fill(c, RectF(771.0F, 393.0F, 1309.0F, 605.0F), 9.0F, colorWithAlpha(Color::rgb(33, 36, 41), 112));
    }
}

// ---------------------------------------------------------------- MULTISAMPLE
void SilvetonSamplerView::drawEditRange(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const SoundRanges rg = soundRanges(u, sound);
    const std::string who = sound == 0 ? std::string("MAIN") : "L" + std::to_string(sound);

    // KEY RANGE of the chosen sound: FROM, TO, the bar with two ends, the keyboard
    nlPanel(c, RectF(250.0F, 214.0F, 810.0F, 612.0F), "KEY RANGE · " + who);
    for (int e = 0; e < 2; ++e) {
        const RectF r(e == 0 ? 266.0F : 674.0F, 246.0F, e == 0 ? 386.0F : 794.0F, 332.0F);
        nlLcd(c, r);
        nlLabel(c, e == 0 ? "FROM" : "TO", r.centerX(), 265.5F, true, NL_TXT2, 10.5F);
        text(c, noteName(e == 0 ? rg.keyLow : rg.keyHigh), r.centerX(), 309.0F, 34.0F, NL_VALUE, Opt().center().monoBold().maxW(r.width() - 8.0F));
        hit(r,
            [this, u, sound, rg, e](float, float) {   // a tap on the note = the exact value
                if (e == 0) {
                    showNumber("КЛАВИШ ОТ (0 = C-1 · 60 = C4)", static_cast<float>(rg.keyLow), 0.0F, 127.0F, 0,
                               [this, u, sound, rg](float x) { setSoundKeyRange(u, sound, std::min(rnd(x), rg.keyHigh), rg.keyHigh); });
                } else {
                    showNumber("КЛАВИШ ДО (0 = C-1 · 60 = C4)", static_cast<float>(rg.keyHigh), 0.0F, 127.0F, 0,
                               [this, u, sound, rg](float x) { setSoundKeyRange(u, sound, rg.keyLow, std::max(rnd(x), rg.keyLow)); });
                }
            },
            [this, u, sound] { sampler.cancelKeyScan(); setSoundKeyRange(u, sound, 0, 127); });   // double tap = the whole keyboard
    }
    neBar(c, 410.0F, 282.0F, 240.0F, 14.0F, static_cast<float>(rg.keyLow) / 127.0F, static_cast<float>(rg.keyHigh) / 127.0F, true, 14.0F, false);
    registerSmoothRange(RectF(410.0F, 256.0F, 650.0F, 322.0F), 0.0F, 127.0F, 1.0F, static_cast<float>(rg.keyLow), static_cast<float>(rg.keyHigh),
                        [this, u, sound](float a, float b) { setSoundKeyRange(u, sound, rnd(a), rnd(b)); });
    neKeyboard(c, RectF(266.0F, 348.0F, 794.0F, 412.0F), rg.keyLow, rg.keyHigh);

    // the keys can also be set by playing: a tap, then the key on the MIDI keyboard
    for (int edge = 0; edge < 2; ++edge) {
        const RectF kr(edge == 0 ? 266.0F : 542.0F, 430.0F, edge == 0 ? 518.0F : 794.0F, 484.0F);
        const bool scanning = sampler.keyScanUpper() == u && sampler.keyScanSound() == sound && sampler.keyScanEdge() == edge;
        const bool blink = scanning && (nowMs() / 300) % 2 == 0;
        neKey(c, kr, scanning ? std::string("PRESS A KEY…") : (edge == 0 ? std::string("SET FROM · MIDI") : std::string("SET TO · MIDI")),
              scanning ? (blink ? NeKey::Sel : NeKey::On) : NeKey::Plain, 13.0F, true);
        if (scanning) postInvalidateDelayed(150);
        hit(kr, [this, u, sound, edge, scanning](float, float) {
            if (scanning) sampler.cancelKeyScan(); else sampler.startKeyScan(u, sound, edge);
            invalidate();
        });
    }
    text(c, "after SET press a key — it becomes the range end · double-tap = whole keyboard", 266.0F, 506.0F, 11.5F, NE_HINT, Opt().maxW(530.0F));

    // TRANSPOSE of the sound (the same value as on SAMPLE)
    neDial(c, 400.0F, 558.0F, 56.0F, "TRANSPOSE", signed_(rg.transpose) + " st", static_cast<float>(rg.transpose), -12.0F, 12.0F, 1.0F, 240.0F, true,
           [this, u, sound](float nv) { neSetTranspose(u, sound, rnd(nv)); },
           [this, u, sound, rg] {
               showNumber("ТРАНСПОНИРАНЕ (полутонове)", static_cast<float>(rg.transpose), -12.0F, 12.0F, 0, [this, u, sound](float x) { neSetTranspose(u, sound, rnd(x)); });
           },
           [this, u, sound] { neSetTranspose(u, sound, 0); }, 62.0F);

    // OVERLAP: all five sounds of the UPPER on the keyboard, and where they play together
    nlPanel(c, RectF(826.0F, 214.0F, 1310.0F, 612.0F), "OVERLAP · KEYS");
    neSoundRows(c, u, sound, false);
    nlLabel(c, "OVERLAP", 840.0F, 551.5F, false, NL_TXT2, 11.0F);
    const RectF strip(920.0F, 534.0F, 1210.0F, 544.0F);
    fill(c, strip, 5.0F, Color::rgb(26, 29, 33));
    int counts[128] = {};
    for (int k = 0; k <= 4; ++k) {
        const SoundRanges r2 = soundRanges(u, k);
        if (!r2.has || (k > 0 && !layerOn(u, k - 1))) continue;
        for (int v = r2.keyLow; v <= r2.keyHigh; ++v) ++counts[v];
    }
    int v = 0;
    while (v < 128) {
        int w = v;
        while (w < 128 && counts[w] == counts[v]) ++w;
        if (counts[v] > 0) {
            fill(c, RectF(strip.left + strip.width() * static_cast<float>(v) / 128.0F, strip.top, strip.left + strip.width() * static_cast<float>(w) / 128.0F, strip.bottom), 0.0F,
                 counts[v] >= 2 ? NL_AMBER : NL_BLUE);
        }
        v = w;
    }
    text(c, "blue = one sound · amber = two or more sounds play together", 840.0F, 572.0F, 11.5F, NE_HINT, Opt().maxW(456.0F));
}

// ---------------------------------------------------------------- FILTER
void SilvetonSamplerView::drawEditFilter(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;

    nlPanel(c, RectF(250.0F, 214.0F, 1310.0F, 446.0F), "FILTER");
    neLegacyKnob(c, 340.0F, 322.0F, 96.0F, "CUTOFF", 4);
    neLegacyKnob(c, 510.0F, 322.0F, 96.0F, "RESONANCE", 5);
    {   // ENV AMOUNT: how far the filter envelope opens the cutoff (octaves)
        const float v = toneX(u, sound, 2);
        neDial(c, 680.0F, 322.0F, 96.0F, "ENV AMOUNT", std::string(v >= 0.0F ? "+" : "") + fmtFixed(static_cast<double>(v), 2) + " oct", v, -8.0F, 8.0F, 0.05F, 280.0F, true,
               [this, u, sound](float nv) { setToneX(u, sound, 2, nv); },
               [this, u, sound, v] { showNumber("FILTER ENV (октави)", v, -8.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 2, x); }); },
               [this, u, sound] { setToneX(u, sound, 2, 0.0F); });
    }
    {   // ENV TIME: how fast the filter envelope runs (ms, logarithmic)
        const float t = toneX(u, sound, 3);
        const float norm = lnf(std::clamp(t, 1.0F, 20000.0F)) / lnf(20000.0F);
        neDial(c, 850.0F, 322.0F, 96.0F, "ENV TIME", msTxt(t, true), norm, 0.0F, 1.0F, 0.002F, 260.0F, false,
               [this, u, sound](float nv) { setToneX(u, sound, 3, rndf(std::clamp(expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(20000.0F)), 1.0F, 20000.0F))); },
               [this, u, sound, t] { showNumber("FILTER ENV TIME ms", t, 1.0F, 20000.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 3, x); }); },
               [this, u, sound] { setToneX(u, sound, 3, 120.0F); });
    }
    {   // HI-PASS (Hz, OFF below 10 Hz)
        const float hp = toneX(u, sound, 6);
        const float hn = hp < 10.0F ? 0.0F : lnf(hp / 10.0F) / lnf(400.0F);
        neDial(c, 1020.0F, 322.0F, 96.0F, "HI-PASS", hp < 10.0F ? std::string("OFF") : std::to_string(rnd(hp)) + " Hz", hn, 0.0F, 1.0F, 0.002F, 260.0F, false,
               [this, u, sound](float nv) { setToneX(u, sound, 6, nv <= 0.002F ? 0.0F : rndf(10.0F * static_cast<float>(std::pow(400.0, static_cast<double>(nv))))); },
               [this, u, sound, hp] { showNumber("HIGH-PASS Hz (0 = OFF)", hp, 0.0F, 4000.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 6, x); }); },
               [this, u, sound] { setToneX(u, sound, 6, 0.0F); });
    }
    {   // VEL->CUTOFF: how much a hard key opens the cutoff (octaves) - the same value as in VELOCITY
        const float vc = toneX(u, sound, 5);
        neDial(c, 1190.0F, 322.0F, 96.0F, "VEL→CUTOFF", fmtFixed(static_cast<double>(vc), 2) + " oct", vc, 0.0F, 8.0F, 0.05F, 250.0F, false,
               [this, u, sound](float nv) { setToneX(u, sound, 5, nv); },
               [this, u, sound, vc] { showNumber("VEL→CUTOFF (октави)", vc, 0.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 5, x); }); },
               [this, u, sound] { setToneX(u, sound, 5, 0.0F); });
    }

    // TONE EQ of this sound (the five-band EQ of the whole UPPER is on the EQ page)
    nlPanel(c, RectF(250.0F, 456.0F, 1310.0F, 612.0F), "TONE EQ · THIS SOUND");
    static const char* const eqNames[3] = {"EQ LOW", "EQ MID", "EQ HIGH"};
    for (int k = 0; k < 3; ++k) {
        const int id = 12 + k;
        const float v = toneX(u, sound, id);
        const std::string title = eqNames[k];
        neDial(c, 340.0F + 170.0F * static_cast<float>(k), 540.0F, 70.0F, title, fmtFixed(static_cast<double>(v), 1) + " dB", v, -18.0F, 18.0F, 0.1F, 300.0F, true,
               [this, u, sound, id](float nv) { setToneX(u, sound, id, nv); },
               [this, u, sound, id, title, v] { showNumber(title + " dB", v, -18.0F, 18.0F, 1, [this, u, sound, id](float x) { setToneX(u, sound, id, x); }); },
               [this, u, sound, id] { setToneX(u, sound, id, 0.0F); });
    }
    text(c, "The five-band EQ of the whole UPPER is on the EQ page.", 870.0F, 532.0F, 12.0F, NE_HINT, Opt().maxW(430.0F));
    const RectF eqR(870.0F, 548.0F, 1120.0F, 594.0F);
    neKey(c, eqR, "OPEN EQ PAGE ▶", NeKey::Plain, 13.0F, true);
    hit(eqR, [this](float, float) { editGroup_ = EG_EQ; tab = UpperTab::EQ; invalidate(); });
}

// ---------------------------------------------------------------- ENVELOPE
// The picture of the amplitude envelope: the four points A D S R are dragged (A, D, R sideways = time, S up / down = level).
void SilvetonSamplerView::neAdsr(Canvas& c, const RectF& r, int u, int sound) {
    nlLcd(c, r);
    const float w = r.width();
    const float h = r.height();
    for (int j = 0; j <= 10; ++j) {
        const float yy = r.top + 20.0F + (h - 56.0F) * static_cast<float>(j) / 10.0F;
        line(c, r.left + 20.0F, yy, r.right - 20.0F, yy, j % 5 != 0 ? Color::rgb(42, 50, 59) : Color::rgb(59, 70, 82), 1.0F);
    }
    for (int j = 0; j <= 12; ++j) {
        const float xx = r.left + 20.0F + (w - 40.0F) * static_cast<float>(j) / 12.0F;
        line(c, xx, r.top + 20.0F, xx, r.top + h - 36.0F, j % 4 != 0 ? Color::rgb(35, 43, 51) : Color::rgb(51, 64, 76), 1.0F);
    }
    const float att = neLegacy(u, sound, 0);
    const float dec = neLegacy(u, sound, 1);
    const float sus = std::clamp(neLegacy(u, sound, 2), 0.0F, 1.0F);
    const float rel = neLegacy(u, sound, 3);
    const float tA = toneToNorm(TonePar::ATTACK, att);
    const float tD = toneToNorm(TonePar::DECAY, dec);
    const float tR = toneToNorm(TonePar::RELEASE, rel);
    const float y1 = r.top + 26.0F;               // the top (level 100 %)
    const float y0 = r.top + h - 36.0F;           // the bottom (level 0)
    const float ys = y0 - (y0 - y1) * sus;
    const float x0 = r.left + 20.0F;
    const float xa = x0 + 140.0F * tA;            // end of the attack
    const float xd = xa + 140.0F * tD;            // end of the decay
    const float xe = xd + 80.0F;                  // end of the sustain (the key is released)
    const float xr = xe + 140.0F * tR;            // end of the release
    {
        Path area;
        area.moveTo(x0, y0);
        area.lineTo(xa, y1);
        area.lineTo(xd, ys);
        area.lineTo(xe, ys);
        area.lineTo(xr, y0);
        area.close();
        paint.style = Style::Fill;
        paint.color = Color::BLACK;
        paint.shader = linearGradient(0.0F, y1, 0.0F, y0, Color::argb(115, 51, 160, 255), Color::argb(10, 51, 160, 255), TileMode::Clamp);
        c.drawPath(area, paint);
        paint.shader = nullptr;
        Path curve;
        curve.moveTo(x0, y0);
        curve.lineTo(xa, y1);
        curve.lineTo(xd, ys);
        curve.lineTo(xe, ys);
        curve.lineTo(xr, y0);
        paint.style = Style::Stroke;
        paint.strokeWidth = 3.5F;
        paint.color = NL_BLUE;
        c.drawPath(curve, paint);
        paint.style = Style::Fill;
    }
    struct Pt { float x, y; const char* letter; };
    const Pt pts[4] = {{xa, y1, "A"}, {xd, ys, "D"}, {(xd + xe) / 2.0F, ys, "S"}, {xr, y0, "R"}};
    for (const Pt& p : pts) {
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = NL_AMBER;
        c.drawCircle(p.x, p.y, 15.0F, paint);
        paint.color = Color::rgb(11, 16, 20);
        c.drawCircle(p.x, p.y, 12.0F, paint);
        text(c, p.letter, p.x, p.y + 5.0F, 14.0F, NL_AMBER, Opt().center().bold());
    }
    text(c, "TIME →", r.left + w / 2.0F, r.top + h - 12.0F, 11.0F, Color::rgb(127, 139, 152), Opt().center().mono());
    text(c, "LEVEL ↑", r.right - 24.0F, r.top + 14.0F, 11.0F, Color::rgb(127, 139, 152), Opt().right().mono());

    // the touch: the point that was registered last wins where two points sit on each other (R, S, D, A)
    const auto timeDrag = [this, u, sound](int k, TonePar p, float startNorm) {
        return [this, u, sound, k, p, startNorm](float px, float, bool) {
            if (!dragMoved) return;
            neSetLegacy(u, sound, k, toneFromNorm(p, std::clamp(startNorm + afterSlop(px - downX, touchSlop) / 140.0F, 0.0F, 1.0F)));
        };
    };
    hit(RectF(xr - 20.0F, y0 - 20.0F, xr + 20.0F, y0 + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 3); },
        [this, u, sound] { neSetLegacy(u, sound, 3, -1.0F); }, timeDrag(3, TonePar::RELEASE, tR));
    hit(RectF((xd + xe) / 2.0F - 20.0F, ys - 20.0F, (xd + xe) / 2.0F + 20.0F, ys + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 2); },
        [this, u, sound] { neSetLegacy(u, sound, 2, -1.0F); },
        [this, u, sound, sus, y0, y1](float, float py, bool) {
            if (!dragMoved) return;
            const float n = std::clamp(sus + afterSlop(downY - py, touchSlop) / (y0 - y1), 0.0F, 1.0F);
            neSetLegacy(u, sound, 2, toneFromNorm(TonePar::SUSTAIN, n));
        });
    hit(RectF(xd - 20.0F, ys - 20.0F, xd + 20.0F, ys + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 1); },
        [this, u, sound] { neSetLegacy(u, sound, 1, -1.0F); }, timeDrag(1, TonePar::DECAY, tD));
    hit(RectF(xa - 20.0F, y1 - 20.0F, xa + 20.0F, y1 + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 0); },
        [this, u, sound] { neSetLegacy(u, sound, 0, -1.0F); }, timeDrag(0, TonePar::ATTACK, tA));
}

void SilvetonSamplerView::drawEditEnvelope(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const int sound = std::clamp(editSound, 0, 4);
    neAdsr(c, RectF(250.0F, 214.0F, 810.0F, 612.0F), u, sound);
    neLegacyKnob(c, 900.0F, 304.0F, 92.0F, "ATTACK", 0);
    neLegacyKnob(c, 1040.0F, 304.0F, 92.0F, "DECAY", 1);
    neLegacyKnob(c, 1180.0F, 304.0F, 92.0F, "SUSTAIN", 2);
    neLegacyKnob(c, 970.0F, 500.0F, 92.0F, "RELEASE", 3);
    // EVEN DECAY (the old ЗАТИХВАНЕ): every frequency dies away in this time (to -60 dB) or faster; OFF = as recorded. For the whole UPPER.
    const float dm = getOr(uParams(u), 49, 0.0F);
    const float dn = dm < 30.0F ? 0.0F : 0.05F + 0.95F * lnf(std::clamp(dm, 30.0F, 3000.0F) / 30.0F) / lnf(100.0F);
    neDial(c, 1110.0F, 500.0F, 92.0F, "EVEN DECAY", dm < 30.0F ? std::string("OFF") : msTxt(dm, true), dn, 0.0F, 1.0F, 0.002F, 260.0F, false,
           [this, u](float nv) {
               const float ms = nv < 0.03F ? 0.0F : rndf(30.0F * expf_(std::clamp((nv - 0.05F) / 0.95F, 0.0F, 1.0F) * lnf(100.0F)));
               setUParam(u, 49, ms);
           },
           [this, u, dm] { showNumber("ЗАТИХВАНЕ ms (0 = OFF)", dm, 0.0F, 3000.0F, 0, [this, u](float x) { setUParam(u, 49, x >= 30.0F ? x : 0.0F); }); },
           [this, u] { setUParam(u, 49, 0.0F); });
    text(c, "double-tap = the sound's own default (PROGRAM)", 840.0F, 592.0F, 12.0F, NE_HINT, Opt().maxW(470.0F));
}

// ---------------------------------------------------------------- MODULATION
void SilvetonSamplerView::drawEditModulation(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    nlPanel(c, RectF(250.0F, 214.0F, 1310.0F, 544.0F), "LFO · VIBRATO");
    struct Lfo { const char* label; int id; float lo; float hi; float step; };
    const Lfo lfo[4] = {{"RATE", 7, 0.1F, 20.0F, 0.05F}, {"DEPTH", 8, 0.0F, 200.0F, 1.0F}, {"DELAY", 9, 0.0F, 5000.0F, 10.0F}, {"FADE", 10, 0.0F, 5000.0F, 10.0F}};
    for (int k = 0; k < 4; ++k) {
        const Lfo f = lfo[k];
        const float v = toneX(u, sound, f.id);
        std::string shown;
        if (f.id == 7) shown = fmtFixed(static_cast<double>(v), 2) + " Hz";
        else if (f.id == 8) shown = std::to_string(rnd(v)) + " ct";
        else shown = msTxt(v, true);
        neDial(c, 350.0F + 190.0F * static_cast<float>(k), 360.0F, 124.0F, f.label, shown, v, f.lo, f.hi, f.step, 260.0F, false,
               [this, u, sound, f](float nv) { setToneX(u, sound, f.id, nv); },
               [this, u, sound, f, v] {
                   showNumber(std::string("ВИБРАТО ") + f.label, v, f.lo, f.hi, f.id == 7 ? 1 : 0, [this, u, sound, f](float x) { setToneX(u, sound, f.id, x); });
               },
               [this, u, sound, f] { setToneX(u, sound, f.id, f.id == 7 ? 5.5F : (f.id == 10 ? 300.0F : 0.0F)); }, 100.0F);
    }
    nlLabel(c, "VIBRATO FROM", 1060.0F, 301.5F, false, NL_TXT2, 11.0F);
    const bool wheelOn = toneX(u, sound, 11) >= 0.5F;
    const RectF wr(1060.0F, 312.0F, 1290.0F, 388.0F);
    neKey(c, wr, "MOD WHEEL", wheelOn ? NeKey::On : NeKey::Off, 16.0F, true);
    hit(wr, [this, u, sound, wheelOn](float, float) { setToneX(u, sound, 11, wheelOn ? 0.0F : 1.0F); });
    text(c, "depth follows the mod wheel (CC 1)", 1060.0F, 412.0F, 12.0F, NE_HINT, Opt().maxW(240.0F));
}

} // namespace silveton::ui::classic
