// SILVETON_NEW_LOOK_V1 - SOUND EDIT of the new look: the frame (UPPER chips, group list, content panel with the SOUND selector, hint line,
// MARK / LINK / COPY / PASTE row) and the groups SAMPLE (drawEditTune), MULTISAMPLE (drawEditRange), FILTER, ENVELOPE, MODULATION.
// VELOCITY (drawEditVelocity, neSoundRows) is in View_Velocity.cpp; WAVE, EQ, VOICE, MIDI CONTROL are in View_NEdit2.cpp / View_Eq.cpp.
// Every group function draws only the BODY of the content panel (232,160,1088x490) in absolute design units, with the numbers measured
// from the approved pictures (gui/png/sample.png, multisample.png, velocity.png, filter.png, envelope.png, modulation.png).
// Nothing here changes what a control does: the same values, ranges and commit functions as the old TUNE / RANGE / TONE pages are used.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expf_(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rnd(float v) { return static_cast<int>(std::nearbyint(v)); }
float rndf(float v) { return std::nearbyint(v); }

constexpr int kOfsN = 4;                                         // MS1..MS4 (= kOfsZones of the engine)
const float kStartQuick[5] = {0.0F, 10.0F, 25.0F, 60.0F, 120.0F};   // the quick values of OFS / START (ms)
constexpr ColorInt kLitText = Color::rgb(255, 177, 58);          // text of a lit key (#ffb13a)
constexpr ColorInt kDashEdge = Color::rgb(75, 82, 91);           // the dashed frame (#4b525b)
const char* const kGroupNames[11] = {"SAMPLE START", "KEY RANGE", "VELOCITY", "FILTER", "QUICK CONTROLS", "MODULATION", "SOURCE / WAVE", "EQ", "QUICK CONTROLS", "MIDI CONTROL", "DECAY / PORTA SETUP"};
const char* const kLegacyNames[6] = {"ATTACK", "DECAY", "SUSTAIN", "RELEASE", "CUTOFF", "RESONANCE"};

// a time: "OFF" (or "0 ms") at zero, else milliseconds / seconds (the old msText)
std::string msTxt(float v, bool zeroOff) {
    if (v <= 0.0F) return zeroOff ? std::string("OFF") : std::string("0 ms");
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), 2) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}
// the part of a drag that counts after the first few units (so a handle does not jump when the drag starts)
float afterSlop(float d, float slop) {
    const float sgn = d > 0.0F ? 1.0F : (d < 0.0F ? -1.0F : 0.0F);
    return std::fabs(d) <= slop ? 0.0F : d - sgn * slop;
}
} // namespace

// ---------------------------------------------------------------- small parts
std::string SilvetonSamplerView::neUpperName(int u) { return u == 6 ? std::string("LOWER") : "UPPER " + std::to_string(u + 1); }

SilvetonSamplerView::UpperTab SilvetonSamplerView::neTabOf(int group) {
    switch (group) {
        case EG_TUNE:
        case EG_PARTTUNE: return UpperTab::TUNE;
        case EG_RANGE: return UpperTab::RANGE;
        case EG_VELOCITY: return UpperTab::VELOCITY;
        case EG_FILTER:
        case EG_ENVELOPE:
        case EG_MODULATION: return UpperTab::TONE;
        case EG_WAVE: return UpperTab::WAVE;
        case EG_EQ: return UpperTab::EQ;
        case EG_VOICE: return UpperTab::PORTA;
        case EG_MIDICTL: return UpperTab::CONTROL;
        default: break;
    }
    return UpperTab::TUNE;
}

void SilvetonSamplerView::neKey(Canvas& c, const RectF& r, const std::string& label, NeKey state, float size, bool lamp) {
    switch (state) {
        case NeKey::Sel: nlBtn(c, r, label, NlBtn::Sel, size, lamp); return;
        case NeKey::On: nlBtn(c, r, label, NlBtn::On, size, lamp); return;
        case NeKey::Off: nlBtn(c, r, label, NlBtn::Off, size, lamp); return;
        case NeKey::Plain: nlBtn(c, r, label, NlBtn::Plain, size, lamp); return;
        case NeKey::Lit: break;
    }
    // Lit: a dark key, an amber lamp bar on top, amber text
    nlBtn(c, r, std::string(), NlBtn::Plain, size, lamp);
    const bool lampOk = lamp && r.height() >= 30.0F;
    if (lampOk) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
    }
    text(c, label, r.centerX(), r.centerY() + size * 0.36F + (lampOk ? 2.0F : 0.0F), size, kLitText, Opt().center().bold().spacing(0.07F).maxW(r.width() - 10.0F));
}

void SilvetonSamplerView::neDial(Canvas& c, float cx, float cy, float d, const std::string& label, const std::string& valueText, float value, float minV,
                                 float maxV, float step, float travel, bool bipolar, std::function<void(float)> onChange, std::function<void()> exact,
                                 std::function<void()> reset, float vw, float hitW, bool inert) {
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    nlKnob(c, cx, cy, d * 0.35F, t, bipolar, false, true);
    if (!label.empty()) nlLabel(c, label, cx, cy - d / 2.0F - 4.0F, true, NL_TXT2, 11.0F);
    const float boxW = vw > 0.0F ? vw : std::floor(d * 0.85F);
    const float fs = d >= 80.0F ? 13.0F : 12.0F;
    const float vTop = cy + d / 2.0F - 2.0F;
    nlValue(c, RectF(cx - boxW / 2.0F, vTop, cx + boxW / 2.0F, vTop + fs + 10.0F), valueText, fs);
    if (inert) return;
    const float hw = hitW > 0.0F ? hitW : std::max(boxW, d) + 10.0F;
    knobHit(RectF(cx - hw / 2.0F, cy - d / 2.0F - 14.0F, cx + hw / 2.0F, vTop), value, minV, maxV, step, travel, std::move(onChange), exact, reset);
    hit(RectF(cx - hw / 2.0F, vTop, cx + hw / 2.0F, vTop + fs + 14.0F), [exact](float, float) { exact(); }, reset);
}

void SilvetonSamplerView::neStepper(Canvas& c, float x, float y, const std::string& label, const std::string& value, std::function<void()> onMinus,
                                    std::function<void()> onPlus, std::function<void()> onReset) {
    neStepper(c,x,y,label,value,std::move(onMinus),std::move(onPlus),std::move(onReset),256,64,0,nullptr);
}

void SilvetonSamplerView::neStepper(Canvas& c, float x, float y, const std::string& label, const std::string& value, std::function<void()> onMinus,
                                    std::function<void()> onPlus, std::function<void()> onReset, float width, float height,
                                    float labelWidth, std::function<void()> onExact, float valueWidth) {
    const float left=x+labelWidth,top=labelWidth>0?y:y+22.0F;
    const float controlsWidth=width-labelWidth;
    const float buttonWidth=valueWidth>0?(controlsWidth-valueWidth-16.0F)*.5F:std::min(64.0F,(controlsWidth-16.0F)/3.0F);
    if(labelWidth>0) text(c,label,x,y+height*.5F+4,valueWidth>0?13:11,NL_TXT2,Opt().bold().maxW(labelWidth-12));
    else nlLabel(c,label,x,y+11.5F,false,NL_TXT2,11);
    const RectF minus(left,top,left+buttonWidth,top+height);
    const RectF box(left+buttonWidth+8,top,left+controlsWidth-buttonWidth-8,top+height);
    const RectF plus(left+controlsWidth-buttonWidth,top,left+controlsWidth,top+height);
    nlBtn(c, minus, "−", NlBtn::Plain, 26.0F, false);
    nlLcd(c, box);
    const float valueSize=valueWidth>0&&value.size()>5?20.F:28.F;
    text(c,value,box.centerX(),box.centerY()+valueSize*.36F,valueSize,NL_VALUE,Opt().center().monoBold().maxW(box.width()-12));
    nlBtn(c, plus, "+", NlBtn::Plain, 26.0F, false);
    hit(box, [onExact](float,float){if(onExact)onExact();}, onReset);
    hit(minus, [this, onMinus](float, float) { onMinus(); invalidate(); });
    hit(plus, [this, onPlus](float, float) { onPlus(); invalidate(); });
    pairHits.push_back(PairHit{minus, plus, [this, onReset] { onReset(); invalidate(); }});
}

// A wide finger target controls one normalized parameter; the existing setter
// owns its range and DSP mapping. The same slider serves ADSR and portamento.
void SilvetonSamplerView::neTouchSlider(Canvas& c,const RectF& r,bool vertical,float normalized,
                                      std::function<void(float)> onChange,std::function<void()> onReset) {
    const float n=std::clamp(normalized,0.F,1.F);
    const float start=vertical?r.top+14:r.left+52;
    const float end=vertical?r.bottom-14:r.right-52;
    const float span=std::max(1.F,end-start);
    const float pos=vertical?end-n*span:start+n*span;
    const RectF rail=vertical?RectF(r.centerX()-6,start,r.centerX()+6,end):RectF(start,r.centerY()-6,end,r.centerY()+6);
    neTrack(c,rail);
    if(vertical)fill(c,RectF(rail.left,pos,rail.right,end),6,NL_BLUE);
    else fill(c,RectF(start,rail.top,pos,rail.bottom),6,NL_BLUE);
    const RectF thumb=vertical?RectF(r.centerX()-52,pos-20,r.centerX()+52,pos+20):RectF(pos-52,r.centerY()-28,pos+52,r.centerY()+28);
    fillV(c,thumb,8,Color::rgb(70,170,246),Color::rgb(24,104,188));
    strokeRR(c,thumb,8,Color::rgb(10,25,40),1);
    if(vertical)line(c,thumb.left+34,pos,thumb.right-34,pos,Color::WHITE,3);
    else line(c,pos,thumb.top+17,pos,thumb.bottom-17,Color::WHITE,3);
    const RectF target=vertical?RectF(r.left,r.top-6,r.right,r.bottom+6):r;
    hit(target,[this,vertical,start,end,span,onChange](float x,float y){
        onChange(std::clamp((vertical?end-y:x-start)/span,0.F,1.F));invalidate();
    },std::move(onReset),[this,vertical,n,start,end,span,onChange](float x,float y,bool final){
        if(!dragMoved){
            if(final){onChange(std::clamp((vertical?end-y:x-start)/span,0.F,1.F));invalidate();}
            return;
        }
        const float delta=vertical?downY-y:x-downX;
        onChange(std::clamp(n+afterSlop(delta,touchSlop)/span,0.F,1.F));invalidate();
    });
}

void SilvetonSamplerView::neTrack(Canvas& c, const RectF& r) {
    const float rad = std::min(6.0F, r.height() / 2.0F);
    fill(c, r, rad, Color::rgb(11, 14, 18));
    line(c, r.left + rad, r.top + 1.0F, r.right - rad, r.top + 1.0F, Color::argb(160, 0, 0, 0), 2.0F);
}

void SilvetonSamplerView::neBar(Canvas& c, float x, float y, float w, float h, float lo, float hi, bool handles, float hr, bool dim, float fadeIn, float fadeOut) {
    neTrack(c, RectF(x, y, x + w, y + h));
    const float xl = x + w * std::clamp(lo, 0.0F, 1.0F);
    const float xr = x + w * std::clamp(hi, 0.0F, 1.0F);
    const ColorInt col = dim ? colorWithAlpha(NL_BLUE, 115) : NL_BLUE;
    if (fadeIn <= 0.0F && fadeOut <= 0.0F) {
        fill(c, RectF(xl, y, std::max(xr, xl + 2.0F), y + h), 5.0F, col);
    } else {   // the sound comes in over the fade-in and goes out over the fade-out: a ramp
        float xi = std::min(xl + w * fadeIn, xr);
        float xo = std::max(xr - w * fadeOut, xl);
        if (xi > xo) xi = xo = (xi + xo) * 0.5F;
        Path path;
        path.moveTo(xl, y + h);
        path.lineTo(xi, y);
        path.lineTo(xo, y);
        path.lineTo(xr, y + h);
        path.close();
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = col;
        c.drawPath(path, paint);
    }
    if (!handles) return;
    for (const float hx : {xl, xr}) {
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = dim ? colorWithAlpha(NL_AMBER, 128) : NL_AMBER;
        c.drawCircle(hx, y + h / 2.0F, hr, paint);
        paint.color = Color::rgb(11, 16, 20);
        c.drawCircle(hx, y + h / 2.0F, hr - 3.0F, paint);
    }
}

void SilvetonSamplerView::neDashed(Canvas& c, const RectF& r, ColorInt color) {
    const float rad = 10.0F;
    const float dash = 7.0F;
    const float gap = 5.0F;
    const auto edge = [&](float x1, float y1, float x2, float y2) {
        const float len = std::hypot(x2 - x1, y2 - y1);
        if (len < 1.0F) return;
        const float dx = (x2 - x1) / len;
        const float dy = (y2 - y1) / len;
        for (float p = 0.0F; p < len; p += dash + gap) {
            const float e = std::min(p + dash, len);
            line(c, x1 + dx * p, y1 + dy * p, x1 + dx * e, y1 + dy * e, color, 2.0F);
        }
    };
    edge(r.left + rad, r.top + 1.0F, r.right - rad, r.top + 1.0F);
    edge(r.left + rad, r.bottom - 1.0F, r.right - rad, r.bottom - 1.0F);
    edge(r.left + 1.0F, r.top + rad, r.left + 1.0F, r.bottom - rad);
    edge(r.right - 1.0F, r.top + rad, r.right - 1.0F, r.bottom - rad);
    paint.shader = nullptr;
    paint.style = Style::Stroke;
    paint.strokeWidth = 2.0F;
    paint.color = color;
    const float d2 = rad * 2.0F;
    c.drawArc(RectF(r.left + 1.0F, r.top + 1.0F, r.left + 1.0F + d2, r.top + 1.0F + d2), 180.0F, 90.0F, false, paint);
    c.drawArc(RectF(r.right - 1.0F - d2, r.top + 1.0F, r.right - 1.0F, r.top + 1.0F + d2), 270.0F, 90.0F, false, paint);
    c.drawArc(RectF(r.right - 1.0F - d2, r.bottom - 1.0F - d2, r.right - 1.0F, r.bottom - 1.0F), 0.0F, 90.0F, false, paint);
    c.drawArc(RectF(r.left + 1.0F, r.bottom - 1.0F - d2, r.left + 1.0F + d2, r.bottom - 1.0F), 90.0F, 90.0F, false, paint);
    paint.style = Style::Fill;
}

// all 128 keys of a piano, the range low..high lit blue (the picture's mini keyboard)
void SilvetonSamplerView::neKeyboard(Canvas& c, const RectF& r, int low, int high) {
    const auto isBlack = [](int n) { const int pc = n % 12; return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10; };
    const float ww = r.width() / 75.0F;   // 75 white keys in 0..127
    int w = 0;
    for (int n = 0; n < 128; ++n) {
        if (isBlack(n)) continue;
        const float x0 = r.left + static_cast<float>(w) * ww;
        fill(c, RectF(x0, r.top, x0 + ww - 1.0F, r.bottom), 1.5F, (n >= low && n <= high) ? Color::rgb(127, 192, 255) : Color::rgb(217, 221, 226));
        ++w;
    }
    w = 0;
    for (int n = 0; n < 128; ++n) {
        if (!isBlack(n)) { ++w; continue; }
        const float bx = r.left + static_cast<float>(w) * ww;
        fill(c, RectF(bx - ww * 0.3F, r.top, bx + ww * 0.3F, r.top + r.height() * 0.62F), 1.5F, (n >= low && n <= high) ? Color::rgb(23, 102, 201) : Color::rgb(21, 24, 28));
    }
}

// the SOUND selector: MAIN (0) / L1..L4 (the old drop-down of an UPPER). An empty place opens the sound list at once.
void SilvetonSamplerView::neSelectSound(int u, int k) {
    if (sampler.keyScanUpper() != u || sampler.keyScanSound() != k) sampler.cancelKeyScan();
    selectSound(u, k);
    bool has;
    if (k == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        has = st && st->soundName != "EMPTY" && !isBlank(st->soundName);
    } else {
        has = soundSlotHas(u, k);
    }
    // A clipboard destination must be selectable without a picker covering PASTE.
    if (!has && !copiedSound_) openPicker(u, k - 1);
}

int SilvetonSamplerView::soundSlotId(int upper, int slot) {
    if (upper < 0 || upper > 6 || slot < 0 || slot > 4) return 0;
    return slot == 0 ? sampler.upperSoundSlot(upper)
                     : static_cast<int>(getOr(sampler.layerParams(upper, slot - 1), 31, 0.0F));
}

std::string SilvetonSamplerView::soundSlotName(int upper, int slot) {
    if (!soundSlotHas(upper, slot)) return "EMPTY";
    if (slot > 0) return sampler.layerName(upper, slot - 1);
    const auto state = sampler.upperState(upper);
    return state ? state->soundName : std::string("EMPTY");
}

bool SilvetonSamplerView::clearSoundSlot(int upper, int slot) {
    if (upper < 0 || upper > 6 || slot < 0 || slot > 4) return false;
    bool ok;
    if (slot == 0) {
        // Removing MAIN is not an OFF command for the other four layers or engine.
        const auto state = sampler.upperState(upper);
        ok = sampler.clearUpperSound(upper);
        if (ok && state) ok = sampler.updateUpperMain(upper, *state);
        if (ok) lastPickedSound[static_cast<std::size_t>(upper)].reset();
    } else {
        ok = sampler.setLayerSound(upper, slot - 1, 0);
    }
    refreshUpper(upper);
    return ok;
}

void SilvetonSamplerView::copySoundSlot(int upper, int slot, bool cut) {
    const int id = soundSlotId(upper, slot);
    if (!soundSlotHas(upper, slot)) { flash("THIS SOUND PLACE IS EMPTY"); return; }
    SoundClip clip;
    clip.upper = upper;
    clip.slot = slot;
    clip.soundId = id;
    clip.source=sampler.soundSource(upper,slot);
    clip.name = soundSlotName(upper, slot);
    clip.bankSerial = sampler.bankSerial();
    clip.listEntry = sampler.activeListEntry(0, 0, 0);
    clip.blendName = sampler.combiName();
    clip.cut = cut;
    copiedSound_ = std::move(clip);
    flash(std::string(cut ? "CUT READY: " : "COPIED SOUND: ") + neUpperName(upper) + " / " + soundLabel(slot) +
          (cut ? " — CHOOSE A DESTINATION, THEN PASTE" : " — LEVELS AND SETTINGS STAY AT THE DESTINATION"));
    invalidate();
}

void SilvetonSamplerView::applySoundPaste(const SoundClip& clip, int upper, int slot) {
    if (upper < 0 || upper > 6 || slot < 0 || slot > 4) return;
    if (clip.bankSerial != sampler.bankSerial()) {
        showMessage("SOUND CLIPBOARD", "The sound bank or SET changed. Copy the sound again before pasting.");
        return;
    }
    if (clip.cut) {
        if (clip.upper == upper && clip.slot == slot) { flash("CHOOSE A DIFFERENT SOUND PLACE"); return; }
        if (clip.listEntry != sampler.activeListEntry(0, 0, 0) || clip.blendName != sampler.combiName() ||
            sampler.soundSource(clip.upper,clip.slot).program != clip.source.program ||
            sampler.soundSource(clip.upper,clip.slot).soloModel != clip.source.soloModel ||
            sampler.soundSource(clip.upper,clip.slot).engine.type != clip.source.engine.type) {
            showMessage("MOVE NOT APPLIED", "The source blend or sound changed after CUT. Nothing was moved. Cut the sound again.");
            return;
        }
    }
    const bool occupied = soundSlotHas(upper, slot);
    const auto before = sampler.upperState(upper);
    const bool oldLayerOn = slot > 0 && getOr(sampler.layerParams(upper, slot - 1), 0, 0.0F) >= 0.5F;
    if (!sampler.putSoundSource(upper, slot, clip.source)) {
        showMessage("PASTE FAILED", failureText(sampler.lastFailure()));
        return;
    }
    // A replacement preserves its previous ON state. A new empty place is enabled,
    // just as when choosing a sound in the picker. Level, ranges and all DSP stay put.
    if (occupied) {
        if (slot == 0 && before) (void)sampler.updateUpperMain(upper, *before);
        else if (slot > 0) (void)sampler.setLayerParam(upper, slot - 1, 0, oldLayerOn ? 1.0F : 0.0F);
    }
    if (clip.cut) {
        if (!clearSoundSlot(clip.upper, clip.slot)) {
            copiedSound_.reset();
            refreshUpper(upper);
            showMessage("SOUND COPIED", "The destination received the sound, but the source could not be cleared. The original is still available.");
            return;
        }
        copiedSound_.reset();
    }
    refreshUpper(upper);
    flash(std::string(clip.cut ? "MOVED SOUND TO " : "PASTED SOUND TO ") + neUpperName(upper) + " / " + soundLabel(slot));
    invalidate();
}

void SilvetonSamplerView::pasteSoundSlot(int upper, int slot) {
    if (!copiedSound_) { flash("COPY OR CUT A SOUND FIRST"); return; }
    const SoundClip clip = *copiedSound_;
    if (soundSlotHas(upper, slot)) {
        showConfirm("REPLACE SOUND", neUpperName(upper) + " / " + soundLabel(slot) + ":\n" + soundSlotName(upper, slot) +
                    "\nwill receive " + clip.name + ".\nDestination level, pan and ranges stay unchanged.", "PASTE SOUND",
                    [this, clip, upper, slot] { applySoundPaste(clip, upper, slot); });
    } else {
        applySoundPaste(clip, upper, slot);
    }
}

void SilvetonSamplerView::chooseSoundDestination(int upper, int slot) {
    copySoundSlot(upper, slot, true);
    if (!copiedSound_) return;
    std::vector<std::string> parts;
    for (int i = 0; i < 7; ++i) parts.push_back(neUpperName(i));
    showItems("MOVE SOUND — DESTINATION PART", parts, [this](int target) {
        if (target < 0 || target > 6) return;
        std::vector<std::string> places;
        for (int k = 0; k < 5; ++k) places.push_back(soundLabel(k) + " · " + soundSlotName(target, k));
        showItems("MOVE SOUND TO " + neUpperName(target), places, [this, target](int dest) {
            if (dest >= 0 && dest <= 4) pasteSoundSlot(target, dest);
        });
    });
}

void SilvetonSamplerView::showSoundActions(int upper, int slot) {
    if (upper < 0 || upper > 6 || slot < 0 || slot > 4) return;
    const bool has = soundSlotHas(upper, slot);
    enum Action { Choose, Copy, Cut, Paste, Move, Remove, CancelCut, Legacy };
    std::vector<Action> actions{Choose};
    std::vector<std::string> labels{"CHOOSE SOUND"};
    for(int i=7;i<15;++i)if(sampler.soundSource(i,0).engine.chosen()){
        actions.push_back(Legacy);labels.emplace_back("MOVE SOLO FROM OLD SET…");break;
    }
    if (has) { actions.push_back(Copy); labels.emplace_back("COPY SOUND"); actions.push_back(Cut); labels.emplace_back("CUT SOUND"); }
    if (copiedSound_) { actions.push_back(Paste); labels.emplace_back("PASTE SOUND"); }
    if (has) { actions.push_back(Move); labels.emplace_back("MOVE SOUND TO…"); actions.push_back(Remove); labels.emplace_back("REMOVE FROM THIS PLACE"); }
    if (copiedSound_ && copiedSound_->cut) { actions.push_back(CancelCut); labels.emplace_back("CANCEL CUT"); }
    showItems(neUpperName(upper) + " / " + soundLabel(slot) + " · " + soundSlotName(upper, slot), labels,
        [this, upper, slot, actions](int index) {
            if (index < 0 || index >= static_cast<int>(actions.size())) return;
            switch (actions[static_cast<std::size_t>(index)]) {
                case Choose: selectedUpper_ = upper; selectSound(upper, slot); openPicker(upper, slot - 1); break;
                case Legacy: moveLegacySolo(upper,slot); break;
                case Copy: copySoundSlot(upper, slot); break;
                case Cut: copySoundSlot(upper, slot, true); break;
                case Paste: pasteSoundSlot(upper, slot); break;
                case Move: chooseSoundDestination(upper, slot); break;
                case Remove:
                    showConfirm("REMOVE SOUND", "Remove " + soundSlotName(upper, slot) + " from " + neUpperName(upper) + " / " + soundLabel(slot) +
                                "?\nThe sound stays in the bank. Other layers keep their settings.", "REMOVE", [this, upper, slot] {
                        if (!clearSoundSlot(upper, slot)) showMessage("REMOVE FAILED", failureText(sampler.lastFailure()));
                        else flash("SOUND PLACE CLEARED");
                        invalidate();
                    });
                    break;
                case CancelCut: copiedSound_.reset(); flash("CUT CANCELED — SOURCE UNCHANGED"); invalidate(); break;
            }
        });
    if (!dialogStack.empty()) dialogStack.back()->itemCols = 2;
}

void SilvetonSamplerView::drawSoundActions(Canvas& c, int upper, int slot) {
    const bool has = soundSlotHas(upper, slot);
    const char* labels[4] = {"COPY SOUND", "CUT SOUND", "PASTE SOUND", "SAVE TO LIST"};
    for (int i = 0; i < 4; ++i) {
        const float x = 669.0F + 164.0F * static_cast<float>(i);
        const RectF r(x, 656.0F, x + 157.0F, 696.0F);
        const bool enabled = i < 2 ? has : (i == 2 ? copiedSound_.has_value() : true);
        const std::string sub = i == 3 ? std::string("WHOLE BLEND")
            : (i == 2 && copiedSound_ ? neUpperName(copiedSound_->upper) + " / " + soundLabel(copiedSound_->slot)
                                     : neUpperName(upper) + " / " + soundLabel(slot));
        lvKey(c, r, labels[i], sub, enabled ? LvLook::Plain : LvLook::Off, 11.5F, false);
        if (!enabled) continue;
        hit(r, [this, upper, slot, i](float, float) {
            if (i == 0) copySoundSlot(upper, slot);
            else if (i == 1) copySoundSlot(upper, slot, true);
            else if (i == 2) pasteSoundSlot(upper, slot);
            else openStore();
        });
    }
}

void SilvetonSamplerView::neSetTranspose(int u, int sound, int v) {
    const int t = std::clamp(v, -12, 12);
    if (sound == 0) {
        if (!upperStates[static_cast<std::size_t>(u)]) return;
        UpperState n = currentUpper(*upperStates[static_cast<std::size_t>(u)]);
        n.transpose = t;
        commitTune(n);
    } else {
        setLParam(u, sound - 1, 3, static_cast<float>(t));
    }
}

// ---------------------------------------------------------------- the six legacy TONE values of a sound
float SilvetonSamplerView::neLegacy(int u, int sound, int k) {
    static const float defaults[6] = {5.0F, 80.0F, 1.0F, 120.0F, 20000.0F, 0.0F};
    const int kk = std::clamp(k, 0, 5);
    if (sound == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        return st ? toneValue(*st, static_cast<TonePar>(kk)) : defaults[kk];
    }
    const float v = getOr(lParams(u, sound - 1), 10 + kk, -1.0F);
    return v >= 0.0F ? v : defaults[kk];
}

void SilvetonSamplerView::neSetLegacy(int u, int sound, int k, float v) {
    if (sound == 0) setTone(static_cast<TonePar>(k), v);
    else setLParam(u, sound - 1, 10 + k, v);
}

void SilvetonSamplerView::neLegacyExact(int u, int sound, int k) {
    const TonePar p = static_cast<TonePar>(k);
    const float v = neLegacy(u, sound, k);
    const ToneRange range = toneRange(p);
    const bool pct = k == 2 || k == 5;
    const std::string unit = pct ? " · %" : (k == 4 ? " · Hz" : " · ms");
    showNumber(std::string(kLegacyNames[k]) + " · " + neUpperName(u) + " / " + (sound == 0 ? "MAIN" : "L" + std::to_string(sound)) + unit,
               pct ? v * 100.0F : v, range.lo, range.hi, range.decimals,
               [this, u, sound, k, pct](float nv) { neSetLegacy(u, sound, k, pct ? nv / 100.0F : nv); }, true, [this, u, sound, k, v] { neSetLegacy(u, sound, k, v); });
}

void SilvetonSamplerView::neLegacyKnob(Canvas& c, float cx, float cy, float d, const std::string& label, int k) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    const TonePar p = static_cast<TonePar>(k);
    const float v = neLegacy(u, sound, k);
    neDial(c, cx, cy, d, label, toneText(p, v), toneToNorm(p, v), 0.0F, 1.0F, 0.002F, 260.0F, false,
           [this, u, sound, k, p](float nv) { neSetLegacy(u, sound, k, toneFromNorm(p, nv)); },
           [this, u, sound, k] { neLegacyExact(u, sound, k); },
           [this, u, sound, k] { neSetLegacy(u, sound, k, -1.0F); });   // double tap = the sound's own default
}

// ---------------------------------------------------------------- OFS (where the sample starts)
std::vector<int> SilvetonSamplerView::neVelZones(int u, int sound) {
    if (u < 0 || u > 6 || sound < 0 || sound > 4) return {};
    std::string key;
    if (sound == 0) {
        const auto& st = upperStates[static_cast<std::size_t>(u)];
        key = st ? st->soundName : std::string();
    } else {
        key = std::to_string(layerSlot(u, sound - 1));
    }
    NeZones& z = neZones_[static_cast<std::size_t>(u)][static_cast<std::size_t>(sound)];
    if (!z.valid || z.key != key) {   // asked from the engine only when the sound of the place changed
        z.zones = sampler.soundVelocityZones(u, sound);
        z.key = key;
        z.valid = true;
    }
    return z.zones;
}

float SilvetonSamplerView::neOfsZone(int u, int sound, int k) {
    const std::size_t id = static_cast<std::size_t>((sound == 0 ? 68 : 48) + std::clamp(k, 0, kOfsN - 1));
    const std::vector<float> p = sound == 0 ? uParams(u) : lParams(u, sound - 1);
    return id < p.size() ? p[id] : -1.0F;
}

void SilvetonSamplerView::neSetOfsZone(int u, int sound, int k, float ms) {
    const int id = (sound == 0 ? 68 : 48) + std::clamp(k, 0, kOfsN - 1);
    if (sound == 0) setUParam(u, id, ms); else setLParam(u, sound - 1, id, ms);
}

void SilvetonSamplerView::neSetOfsAll(int u, int sound, float ms) {
    setToneX(u, sound, 0, ms);
    for (int k = 0; k < kOfsN; ++k) if (neOfsZone(u, sound, k) >= 0.0F) neSetOfsZone(u, sound, k, -1.0F);
}

std::string SilvetonSamplerView::neOfsRange(const std::vector<int>& b, int k) {
    if (k < 0 || k >= static_cast<int>(b.size())) return "—";
    const int hi = k == 0 ? 127 : b[static_cast<std::size_t>(k - 1)] - 1;
    const int lo = k == kOfsN - 1 ? b.back() : b[static_cast<std::size_t>(k)];
    return std::to_string(lo) + "–" + std::to_string(hi);
}

// ---------------------------------------------------------------- the frame
void SilvetonSamplerView::drawSoundEdit(Canvas& c) {
    const int visibleUpper = std::clamp(selectedUpper_, 0, 6);
    const int visibleSound = std::clamp(stripSound[static_cast<std::size_t>(visibleUpper)], 0, 4);
    if (editGroup_ != EG_RANGE || sampler.keyScanUpper() != visibleUpper || sampler.keyScanSound() != visibleSound)
        sampler.cancelKeyScan();
    // Older entry points may still request ENVELOPE. ADSR and playing controls
    // now have a single editor, regardless of how the page was reached.
    if (editGroup_ == EG_ENVELOPE) editGroup_ = EG_VOICE;
    if (editGroup_ == EG_VOICE) { drawQuickControls(c); return; }
    for (int i = 0; i < 7; ++i) {
        auto& slot = upperStates[static_cast<std::size_t>(i)];
        if (!slot) slot = sampler.upperState(i);
    }
    const int u = std::clamp(selectedUpper_, 0, 6);
    selectedUpper_ = u;
    editGroup_ = std::clamp(editGroup_, 0, static_cast<int>(EG_COUNT) - 1);
    int& chosen = stripSound[static_cast<std::size_t>(u)];
    chosen = std::clamp(chosen, 0, 4);
    editSound = chosen;          // the sound the groups edit: MAIN (0) or L1..L4 (the same number the old strips used)
    dropUpper = -1;
    tab = neTabOf(editGroup_);   // old code that reads `tab` still sees the page that belongs to the group

    // the seven UPPERs (touch = choose it; in mark mode = mark it)
    for (int i = 0; i < 7; ++i) {
        const RectF r(20.0F + static_cast<float>(i) * 187.0F, 98.0F, 198.0F + static_cast<float>(i) * 187.0F, 150.0F);
        const bool sel = i == u;
        nlBtn(c, r, std::string(), sel ? NlBtn::Sel : NlBtn::Plain, 13.0F, true);
        const ColorInt ink = sel ? Color::WHITE : Color::rgb(179, 187, 196);
        text(c, neUpperName(i), r.centerX(), r.top + 22.0F, 13.0F, ink, Opt().center().bold().spacing(0.12F).maxW(r.width() - 16.0F));
        const auto& st = upperStates[static_cast<std::size_t>(i)];
        const bool empty = !st || st->soundName == "EMPTY" || isBlank(st->soundName);
        text(c, empty ? std::string("—") : st->soundName, r.centerX(), r.top + 39.0F, 11.5F, colorWithAlpha(ink, 217), Opt().center().maxW(r.width() - 16.0F));
        if (marked[static_cast<std::size_t>(i)]) strokeRR(c, r, 8.0F, NL_AMBER, 2.0F);
        upperSelectAreas_.push_back({r, i});
        hit(r, [this, i](float, float) {
            if (markMode) marked[static_cast<std::size_t>(i)] = !marked[static_cast<std::size_t>(i)];
            else selectedUpper_ = i;
            invalidate();
        });
    }

    // Follow the sound from its source to its shape and playing range. Shared
    // Upper controls have their own block, so the selected place never changes
    // the apparent scope of a common setting.
    nlPanel(c, RectF(20.0F, 160.0F, 220.0F, 650.0F));
    nlLabel(c, "SELECTED SOUND", 32.0F, 178.0F, false, NL_BLUE, 10.0F);
    const int soundGroups[7] = {EG_WAVE, EG_VOICE, EG_TUNE, EG_FILTER, EG_MODULATION, EG_VELOCITY, EG_RANGE};
    for (int row = 0; row < 7; ++row) {
        const int k = soundGroups[row];
        const RectF r(30.0F, 185.0F + static_cast<float>(row) * 42.0F, 210.0F, 223.0F + static_cast<float>(row) * 42.0F);
        nlBtn(c, r, kGroupNames[k], k == editGroup_ ? NlBtn::Sel : NlBtn::Plain, 12.0F, true);
        hit(r, [this, k](float, float) { editGroup_ = k; tab = neTabOf(k); invalidate(); });
    }
    nlLabel(c, "UPPER / GLOBAL", 32.0F, 496.0F, false, NL_BLUE, 10.0F);
    const int partGroups[3] = {EG_PARTTUNE, EG_EQ, EG_MIDICTL};
    for (int row = 0; row < 3; ++row) {
        const int k = partGroups[row];
        const RectF r(30.0F, 505.0F + static_cast<float>(row) * 35.0F, 210.0F, 537.0F + static_cast<float>(row) * 35.0F);
        nlBtn(c, r, kGroupNames[k], k == editGroup_ ? NlBtn::Sel : NlBtn::Plain, 11.5F, true);
        hit(r, [this, k](float, float) { editGroup_ = k; tab = neTabOf(k); invalidate(); });
    }

    // the content panel: title, the SOUND selector (only for the groups of one sound) or the note for the groups of the whole UPPER
    nlPanel(c, RectF(232.0F, 160.0F, 1320.0F, 650.0F));
    const bool portaSetup = editGroup_ == EG_PARTTUNE;
    const std::string scope = neUpperName(u) + (editGroup_ <= EG_WAVE ? " / " + soundLabel(chosen) : " / WHOLE PART");
    text(c, std::string(kGroupNames[editGroup_]) + (portaSetup ? std::string() : " · " + scope), 250.0F, 180.0F, 12.0F, NL_BLUE, Opt().bold().maxW(375.0F));
    text(c, portaSetup ? "EVEN DECAY: " + neUpperName(u) : (editGroup_ <= EG_WAVE ? soundSlotName(u, chosen) : "MAIN + L1–L4"), 250.0F, 198.5F, 12.0F, NL_TXT, Opt().bold().maxW(375.0F));
    if (editGroup_ <= EG_WAVE) {
        const RectF soundName(244.0F, 184.0F, 628.0F, 206.0F);
        hit(soundName, [this, u, chosen](float, float) { sampler.cancelKeyScan(); openPicker(u, chosen - 1); });
        listLongHit(soundName, [this, u, chosen](float, float) { showSoundActions(u, chosen); });
    }
    if (editGroup_ <= EG_WAVE) {
        nlLabel(c, "SOUND", 640.0F, 191.0F, false, NL_TXT2, 11.0F);
        for (int k = 0; k < 5; ++k) {
            const RectF r(720.0F + static_cast<float>(k) * 119.2F, 166.0F, 833.2F + static_cast<float>(k) * 119.2F, 204.0F);
            bool has;
            bool on;
            if (k == 0) {
                const auto& st = upperStates[static_cast<std::size_t>(u)];
                has = st && st->soundName != "EMPTY" && !isBlank(st->soundName);
                on = has;
            } else {
                has = soundSlotHas(u, k);
                on = has && layerOn(u, k - 1);
            }
            neKey(c, r, k == 0 ? std::string("MAIN") : "L" + std::to_string(k), k == chosen ? NeKey::Sel : (on ? NeKey::Lit : NeKey::Off), 13.0F, true);
            hit(r, [this, u, k](float, float) { neSelectSound(u, k); });
            listLongHit(r, [this, u, k](float, float) { selectSound(u, k); showSoundActions(u, k); });
        }
    } else {
        text(c, portaSetup ? "PORTAMENTO: ALL UPPERS · EVEN DECAY: " + neUpperName(u) : "applies to the whole " + neUpperName(u) + " (not to one sound)", 1310.0F, 188.0F, 12.0F, NE_HINT, Opt().right().maxW(670.0F));
    }

    // the body of the chosen group
    if (upperStates[static_cast<std::size_t>(u)]) {
        switch (editGroup_) {
            case EG_TUNE: drawEditTune(c); break;
            case EG_RANGE: drawEditRange(c); break;
            case EG_VELOCITY: drawEditVelocity(c); break;
            case EG_FILTER: drawEditFilter(c); break;
            case EG_ENVELOPE: drawEditEnvelope(c); break;
            case EG_MODULATION: drawEditModulation(c); break;
            case EG_WAVE: drawEditWave(c); break;
            case EG_EQ: drawEditEq(c); break;
            case EG_VOICE: drawEditVoice(c); break;
            case EG_PARTTUNE: drawEditPartTune(c); break;
            default: drawEditMidiControl(c); break;
        }
    }
    if (editGroup_ != EG_WAVE && editGroup_ != EG_EQ && editGroup_ != EG_VOICE && editGroup_ != EG_PARTTUNE) {
        const std::string hint = copiedSound_ ? std::string(copiedSound_->cut ? "CUT READY: " : "SOUND CLIPBOARD: ") +
            neUpperName(copiedSound_->upper) + " / " + soundLabel(copiedSound_->slot) + " · " + copiedSound_->name + " — select the destination, then PASTE SOUND"
            : "drag a knob · double-tap = default · tap a value = number · hold MAIN / L1–L4 = sound actions";
        text(c, hint, 250.0F, 636.0F, 11.5F, copiedSound_ && copiedSound_->cut ? NL_AMBER : NE_HINT, Opt().maxW(1050.0F));
    }
    lvMarkRow(c, 656.0F, 40.0F);   // MARK / LINK / COPY / PASTE: the same row as LIVE and MIXER
    drawSoundActions(c, u, chosen);
}

// One proposed screen, backed by the existing Upper and sound parameters.
void SilvetonSamplerView::drawQuickControls(Canvas& c) {
    // LINK and MARK are not displayed here: never inherit an invisible edit
    // scope from the mixer or an advanced editor.
    linkOn = false;
    markMode = false;
    const int u=std::clamp(selectedUpper_,0,6);
    selectedUpper_=u;
    int& chosen=stripSound[static_cast<std::size_t>(u)];
    chosen=std::clamp(chosen,0,4);editSound=chosen;tab=UpperTab::PORTA;
    for(int i=0;i<7;++i) {
        auto& state=upperStates[static_cast<std::size_t>(i)];
        if(!state) state=sampler.upperState(i);
        const RectF r(20+i*187.F,98,198+i*187.F,154);
        nlBtn(c,r,"",i==u?NlBtn::Sel:NlBtn::Plain,13,true);
        const ColorInt ink=i==u?Color::WHITE:NL_TXT2;
        text(c,neUpperName(i),r.centerX(),120,13,ink,Opt().center().bold());
        text(c,state&&!isBlank(state->soundName)&&state->soundName!="EMPTY"?state->soundName:"—",r.centerX(),139,11,ink,Opt().center().maxW(156));
        upperSelectAreas_.push_back({r,i});
        hit(r,[this,i](float,float){selectedUpper_=i;invalidate();});
    }
    const auto& state=upperStates[static_cast<std::size_t>(u)];
    if(!state)return;
    const UpperState s=*state;
    const int sound=chosen;
    const std::string place=sound==0?"MAIN":"L"+std::to_string(sound);
    const std::string part=neUpperName(u);
    const RectF source(20,164,698,220);
    nlLcd(c,source);
    text(c,part+" / "+place,36,184,11,NL_BLUE,Opt().bold());
    text(c,soundSlotName(u,sound),36,207,18,NL_VALUE,Opt().bold().maxW(640));
    hit(source,[this,u,sound](float,float){openPicker(u,sound-1);});
    listLongHit(source,[this,u,sound](float,float){showSoundActions(u,sound);});
    for(int k=0;k<5;++k) {
        const RectF r(720+k*119.2F,164,833.2F+k*119.2F,220);
        nlBtn(c,r,k==0?"MAIN":"L"+std::to_string(k),k==sound?NlBtn::Sel:NlBtn::Plain,13,true);
        hit(r,[this,u,k](float,float){neSelectSound(u,k);});
        listLongHit(r,[this,u,k](float,float){selectSound(u,k);showSoundActions(u,k);});
    }

    nlPanel(c,RectF(20,234,752,436),"ADSR · "+place,true);
    static const char* const adsr[4]={"ATTACK","DECAY","SUSTAIN","RELEASE"};
    for(int k=0;k<4;++k) {
        const float cx=116+k*180.F;
        const TonePar parameter=static_cast<TonePar>(k);
        const float value=neLegacy(u,sound,k);
        nlLabel(c,adsr[k],cx,270,true,NL_TXT2,13);
        neTouchSlider(c,RectF(cx-72,286,cx+72,362),true,toneToNorm(parameter,value),
            [this,u,sound,k,parameter](float n){neSetLegacy(u,sound,k,toneFromNorm(parameter,n));},
            [this,u,sound,k]{neSetLegacy(u,sound,k,-1);});
        const RectF number(cx-50,372,cx+50,428);
        nlValue(c,RectF(cx-50,380,cx+50,420),toneText(parameter,value),15);
        hit(number,[this,u,sound,k](float,float){neLegacyExact(u,sound,k);},[this,u,sound,k]{neSetLegacy(u,sound,k,-1);});
    }

    nlPanel(c,RectF(766,234,1320,436),"ГЛАС · "+part);
    static const char* const voices[3]={"POLY","MONO","LEGATO"};
    for(int k=0;k<3;++k) {
        const RectF r(786+k*174.F,292,950+k*174.F,366);
        nlBtn(c,r,voices[k],s.voiceMode==k?NlBtn::On:NlBtn::Plain,17,true);
        hit(r,[this,u,s,k](float,float){auto next=currentUpper(s);next.voiceMode=k;commitMain(u,next);invalidate();});
    }
    text(c,"LEGATO — свързано монофонично свирене",786,408,13,NL_TXT2,Opt().maxW(510));

    nlPanel(c,RectF(20,450,640,744),"PORTAMENTO · "+part);
    const auto params=uParams(u);
    const int mode=std::clamp(rnd(getOr(params,42,0)),0,3);
    static const char* const modes[4]={"SILVETON","KRONOS","INSTRUMENT","BASS"};
    for(int k=0;k<4;++k) {
        const RectF r(36+k*148.F,490,176+k*148.F,550);
        nlBtn(c,r,modes[k],mode==k?NlBtn::On:NlBtn::Plain,12,true);
        hit(r,[this,u,k](float,float){setUParam(u,42,static_cast<float>(k));});
    }
    const float porta=mode==0?portamentoUiValue(s.portamentoSec):getOr(params,45,40);
    const float portaMax=mode==0?100.F:127.F;
    const auto setPorta=[this,u,s,mode](float v){
        if(mode==0){auto next=currentUpper(s);next.portamentoSec=portamentoSecondsFromUi(v);commitTune(next);}
        else setUParam(u,45,rndf(v));
    };
    const RectF portaValue(496,566,620,622);
    nlValue(c,RectF(508,574,608,614),porta<=0?"OFF":fmtFixed(porta,0)+(mode==0?" ms":""),17);
    hit(portaValue,[this,porta,portaMax,setPorta,mode,part](float,float){showNumber("PORTAMENTO · "+part+(mode==0?" · ms":" · 0–127")+" · 0 = OFF",porta,0,portaMax,0,setPorta);},[setPorta]{setPorta(0);});
    neTouchSlider(c,RectF(36,632,620,716),false,porta/portaMax,
        [setPorta,portaMax](float n){setPorta(rndf(n*portaMax));},[setPorta]{setPorta(0);});
    if(mode==0) {
        text(c,"TIME",36,590,15,NL_TXT,Opt().bold());
        text(c,"0 = ИЗКЛЮЧЕНО",170,603,13,NL_TXT2,Opt().maxW(290));
    } else {
        if(mode==1) {
            const bool fingered=getOr(params,43,0)>=.5F;
            const RectF r(36,566,180,622);
            nlBtn(c,r,"FINGERED",fingered?NlBtn::On:NlBtn::Plain,12,true);
            hit(r,[this,u,fingered](float,float){setUParam(u,43,fingered?0:1);});
        } else if(mode==2) {
            const int instrument=std::clamp(rnd(getOr(params,53,0)),0,6);
            const std::vector<std::string> names{"NEUTRAL","BASS","BOWED","WOODWIND","BRASS","PLUCKED","SYNTH"};
            const RectF r(36,566,180,622);
            nlBtn(c,r,names[static_cast<std::size_t>(instrument)],NlBtn::Plain,11,true);
            hit(r,[this,u,names](float,float){showItems("PORTAMENTO · INSTRUMENT",names,[this,u](int k){if(k>=0&&k<7)setUParam(u,53,static_cast<float>(k));});});
        } else {
            text(c,"TIME",36,601,15,NL_TXT,Opt().bold());
        }
        const bool rate=getOr(params,44,0)>=.5F;
        for(int k=0;k<2;++k) {
            const RectF r(188+k*144.F,566,324+k*144.F,622);
            nlBtn(c,r,k==0?"TIME":"RATE",rate==(k==1)?NlBtn::On:NlBtn::Plain,13,true);
            hit(r,[this,u,k](float,float){setUParam(u,44,static_cast<float>(k));});
        }
    }
    text(c,"Плъзни за време · 0 = изключено",36,731,13,NL_TXT2,Opt().maxW(575));

    nlPanel(c,RectF(654,450,1320,744),"ВИСОЧИНА НА ТОНА");
    const auto layer=sound>0?lParams(u,sound-1):std::vector<float>();
    const float octave=sound==0?static_cast<float>(s.octave):getOr(layer,4,0);
    const float octMax=sound==0?4.F:3.F;
    const auto setOctave=[this,u,s,sound](float v){
        if(sound==0){auto next=currentUpper(s);next.octave=rnd(v);commitTune(next);}
        else setLParam(u,sound-1,4,rndf(v));
    };
    neStepper(c,674,486,"OCTAVE",signed_(rnd(octave)),
       [setOctave,octave,octMax]{setOctave(std::max(octave-1,-octMax));},
       [setOctave,octave,octMax]{setOctave(std::min(octave+1,octMax));},[setOctave]{setOctave(0);},628,56,128,
       [this,octave,octMax,setOctave,part,place]{showNumber("OCTAVE · "+part+" / "+place,octave,-octMax,octMax,0,setOctave);},100);
    const float transpose=sound==0?static_cast<float>(s.transpose):getOr(layer,3,0);
    const auto setTranspose=[this,u,sound](float v){neSetTranspose(u,sound,rnd(v));};
    neStepper(c,674,550,"TRANSPOSE",signed_(rnd(transpose))+" st",
       [setTranspose,transpose]{setTranspose(std::max(transpose-1,-12.F));},
       [setTranspose,transpose]{setTranspose(std::min(transpose+1,12.F));},[setTranspose]{setTranspose(0);},628,56,128,
       [this,transpose,setTranspose,part,place,sound]{showNumber("TRANSPOSE · "+part+(sound==0?" / ALL SOUNDS":" / "+place)+" · st",transpose,-12,12,0,setTranspose);},100);
    const float fine=sound==0?s.fineCents:getOr(layer,5,0);
    // MAIN and layers share the native ±1200-cent range. A recalled layer
    // outside ±100 must keep its value when a one-cent button is touched.
    const float fineMax=1200.F;
    const auto setFine=[this,u,s,sound](float v){
        if(sound==0){auto next=currentUpper(s);next.fineCents=v;commitTune(next);}
        else setLParam(u,sound-1,5,v);
    };
    neStepper(c,674,614,"TUNE ct",fmtFixed(fine,1),
       [setFine,fine,fineMax]{setFine(std::max(fine-1,-fineMax));},
       [setFine,fine,fineMax]{setFine(std::min(fine+1,fineMax));},[setFine]{setFine(0);},628,56,128,
       [this,fine,fineMax,setFine,part,place,sound]{showNumber("TUNE · "+part+(sound==0?" / ALL SOUNDS":" / "+place)+" · cents",fine,-fineMax,fineMax,1,setFine);},100);
    const float bend=getOr(params,48,static_cast<float>(s.pitchBendRange));
    const auto setBend=[this,u](float v){setUParam(u,48,rndf(v));refreshUpper(u);};
    neStepper(c,674,678,"PITCH BEND",fmtFixed(bend,0)+" st",
       [setBend,bend]{setBend(std::max(bend-1,0.F));},
       [setBend,bend]{setBend(std::min(bend+1,24.F));},[setBend]{setBend(2);},628,56,128,
       [this,bend,setBend,part]{showNumber("PITCH BEND · "+part+" / ALL SOUNDS · st",bend,0,24,0,setBend);},100);
    text(c,"ADSR/OCTAVE: "+place+" · TRANSPOSE/TUNE: "+(sound==0?part:place)+" · PITCH BEND: "+part,20,769,11,NL_TXT2,Opt().maxW(1290));
}

// ---------------------------------------------------------------- SAMPLE
void SilvetonSamplerView::drawEditTune(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const int l = sound - 1;   // layer index (-1 = MAIN)
    const std::vector<float> lp = sound > 0 ? lParams(u, l) : std::vector<float>();

    // Pitch and ADSR are edited once on QUICK CONTROLS. This page owns
    // sample start/end and the per-velocity start offsets.
    const RectF quick(264.0F, 254.0F, 984.0F, 316.0F);
    nlBtn(c, quick, "ADSR / OCTAVE / TRANSPOSE / TUNE", NlBtn::Plain, 14.0F, true);
    hit(quick, [this](float, float) { editGroup_ = EG_VOICE; invalidate(); });
    if(!sampler.soundSource(u,sound).engine.chosen()) {
    for (int k = 0; k < 2; ++k) {
        const float maxV = k == 0 ? 2000.0F : 60000.0F;
        const float v = toneX(u, sound, k);
        const float norm = lnf(std::clamp(v, 0.0F, maxV) + 1.0F) / lnf(maxV + 1.0F);
        const std::string label = k == 0 ? "START" : "END";
        neDial(c, 1090.0F + 130.0F * static_cast<float>(k), 290.0F, 88.0F, label, msTxt(v, true), norm, 0.0F, 1.0F, 0.002F, 300.0F, false,
               [this, u, sound, k, maxV](float nv) { setToneX(u, sound, k, rndf(expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(maxV + 1.0F)) - 1.0F)); },
               [this, u, sound, k, label, v, maxV] {
                   showNumber("SAMPLE " + label + " ms", v, 0.0F, maxV, 0, [this, u, sound, k](float x) { setToneX(u, sound, k, x); });
               },
               [this, u, sound, k] { setToneX(u, sound, k, 0.0F); });
    }

    // OFS: where the sample starts - ALL = the START of the whole sound, MS1..MS4 = one value for each velocity layer of the sound
    nlPanel(c, RectF(250.0F, 392.0F, 750.0F, 606.0F), "OFS · WHERE THE SAMPLE STARTS");
    const std::vector<int> zones = neVelZones(u, sound);
    const int nz = std::min(static_cast<int>(zones.size()), kOfsN);
    if (ofsSel_ > nz) ofsSel_ = 0;
    const float st = toneX(u, sound, 0);
    const float zv = ofsSel_ > 0 ? neOfsZone(u, sound, ofsSel_ - 1) : -1.0F;
    const float eff = zv >= 0.0F ? zv : st;
    for (int k = 0; k < 5; ++k) {
        const RectF kr(264.0F + 94.0F * static_cast<float>(k), 428.0F, 352.0F + 94.0F * static_cast<float>(k), 474.0F);
        const bool exists = k == 0 || k <= nz;
        neKey(c, kr, k == 0 ? std::string("ALL") : (exists ? "MS" + std::to_string(k) : std::string("—")), ofsSel_ == k ? NeKey::Sel : NeKey::Off, 13.0F, true);
        if (exists) hit(kr, [this, k](float, float) { ofsSel_ = k; invalidate(); });
    }
    nlLabel(c, "QUICK VALUE", 264.0F, 498.0F, false, NL_TXT2, 11.0F);
    for (int k = 0; k < 5; ++k) {
        const RectF qr(264.0F + 94.0F * static_cast<float>(k), 508.0F, 352.0F + 94.0F * static_cast<float>(k), 554.0F);
        neKey(c, qr, k == 0 ? std::string("OFF") : std::to_string(rnd(kStartQuick[k])) + " ms", std::fabs(eff - kStartQuick[k]) < 0.5F ? NeKey::On : NeKey::Off, 13.0F, true);
        hit(qr, [this, u, sound, k](float, float) {
            if (ofsSel_ == 0) neSetOfsAll(u, sound, kStartQuick[k]);
            else neSetOfsZone(u, sound, ofsSel_ - 1, kStartQuick[k]);
        });
    }
    const std::string cap = ofsSel_ == 0 ? "OFS ALL · " + msTxt(st, false) : "OFS MS" + std::to_string(ofsSel_) + " · velocity " + neOfsRange(zones, ofsSel_ - 1) + " · " + msTxt(eff, false);
    text(c, cap + "   (one value for all velocity zones, or one per MS1–MS4)", 264.0F, 578.0F, 12.0F, NE_HINT, Opt().maxW(472.0F));

    } else {
        nlPanel(c,RectF(250,392,750,606),"SOLO SOURCE");
        text(c,"Source colour: SOURCE / WAVE",272,450,16,NL_TXT,Opt().maxW(460));
        text(c,"Attack / decay / sustain / release: QUICK CONTROLS",272,486,14,NL_TXT2,Opt().maxW(460));
        const RectF source(272,524,728,574);nlBtn(c,source,"OPEN SOURCE",NlBtn::On,14,true);
        hit(source,[this](float,float){editGroup_=EG_WAVE;invalidate();});
    }

    // the dashed panel: only for a layer (L1..L4); with MAIN chosen it is shown veiled and does nothing
    neDashed(c, RectF(770.0F, 392.0F, 1310.0F, 606.0F), kDashEdge);
    nlLabel(c, "ONLY WHEN L1 – L4 IS CHOSEN", 784.0F, 409.5F, false, NL_TXT2, 11.0F);
    const bool onLayer = sound > 0;
    const int slot = onLayer ? layerSlot(u, l) : 0;
    const bool sourcePresent=onLayer&&soundSlotHas(u,sound);
    const RectF nameR(784.0F, 424.0F, 1034.0F, 468.0F);
    nlLcd(c, nameR);
    const std::string nm = sourcePresent ? (slot>0?fmtZeroPad(slot,3)+"  ":std::string("SOLO  ")) + lName(u,l) : (onLayer ? std::string("— NO SOUND —") : std::string("—"));
    text(c, nm, nameR.left + 12.0F, 452.5F, 16.0F, sourcePresent ? Color::WHITE : NL_MUT, Opt().bold().maxW(nameR.width() - 24.0F));
    const RectF onR(1042.0F, 424.0F, 1162.0F, 468.0F);
    const RectF offR(1170.0F, 424.0F, 1300.0F, 468.0F);
    neKey(c, onR, "LAYER ON", sourcePresent && layerOn(u, l) ? NeKey::Lit : NeKey::Off, 12.0F, true);
    neKey(c, offR, "REMOVE", sourcePresent ? NeKey::Plain : NeKey::Off, 12.0F, false);
    const float lvl = onLayer ? getOr(lp, 1, 0.0F) : 0.0F;
    const float pan = onLayer ? getOr(lp, 2, 0.0F) : 0.0F;
    neDial(c, 850.0F, 540.0F, 64.0F, "LEVEL", dbText(lvl), lvl, -60.0F, 12.0F, 0.1F, 260.0F, false,
           [this, u, l](float nv) { setLParam(u, l, 1, nv); },
           [this, u, l, lvl] { showNumber("LAYER " + std::to_string(l + 1) + " LEVEL", lvl, -60.0F, 12.0F, 2, [this, u, l](float x) { setLParam(u, l, 1, x); }); },
           [this, u, l] { setLParam(u, l, 1, 0.0F); }, 60.0F, 0.0F, !onLayer);
    neDial(c, 960.0F, 540.0F, 64.0F, "PAN", panText(pan), pan, -1.0F, 1.0F, 0.01F, 260.0F, true,
           [this, u, l](float nv) { setLParam(u, l, 2, nv); },
           [this, u, l, pan] { showNumber("LAYER " + std::to_string(l + 1) + " PAN", pan, -1.0F, 1.0F, 2, [this, u, l](float x) { setLParam(u, l, 2, x); }); },
           [this, u, l] { setLParam(u, l, 2, 0.0F); }, 60.0F, 0.0F, !onLayer);
    if (onLayer) {
        hit(nameR, [this, u, l](float, float) { openPicker(u, l); });
        hit(onR, [this, u, l, sourcePresent](float, float) {
            if (sourcePresent) setLParam(u, l, 0, layerOn(u, l) ? 0.0F : 1.0F);
            else openPicker(u, l);
        });
        hit(offR, [this, u, l, sourcePresent](float, float) {
            if (!sourcePresent) return;
            sampler.setLayerSound(u, l, 0);
            dropParamCaches(u);
            mirrorSound(u, l);
            invalidate();
        });
    } else {
        fill(c, RectF(771.0F, 393.0F, 1309.0F, 605.0F), 9.0F, colorWithAlpha(Color::rgb(33, 36, 41), 112));
    }
}

// ---------------------------------------------------------------- MULTISAMPLE
void SilvetonSamplerView::drawEditRange(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const SoundRanges rg = soundRanges(u, sound);
    const std::string who = sound == 0 ? std::string("MAIN") : "L" + std::to_string(sound);

    // KEY RANGE of the chosen sound: FROM, TO, the bar with two ends, the keyboard
    nlPanel(c, RectF(250.0F, 214.0F, 810.0F, 612.0F), "KEY RANGE · " + who);
    for (int e = 0; e < 2; ++e) {
        const RectF r(e == 0 ? 266.0F : 674.0F, 246.0F, e == 0 ? 386.0F : 794.0F, 332.0F);
        nlLcd(c, r);
        nlLabel(c, e == 0 ? "FROM" : "TO", r.centerX(), 265.5F, true, NL_TXT2, 10.5F);
        text(c, noteName(e == 0 ? rg.keyLow : rg.keyHigh), r.centerX(), 309.0F, 34.0F, NL_VALUE, Opt().center().monoBold().maxW(r.width() - 8.0F));
        hit(r,
            [this, u, sound, rg, e](float, float) {   // a tap on the note = the exact value
                if (e == 0) {
                    showNumber("KEY FROM (0 = C-1 · 60 = C4)", static_cast<float>(rg.keyLow), 0.0F, 127.0F, 0,
                               [this, u, sound, rg](float x) { setSoundKeyRange(u, sound, std::min(rnd(x), rg.keyHigh), rg.keyHigh); });
                } else {
                    showNumber("KEY TO (0 = C-1 · 60 = C4)", static_cast<float>(rg.keyHigh), 0.0F, 127.0F, 0,
                               [this, u, sound, rg](float x) { setSoundKeyRange(u, sound, rg.keyLow, std::max(rnd(x), rg.keyLow)); });
                }
            },
            [this, u, sound] { sampler.cancelKeyScan(); setSoundKeyRange(u, sound, 0, 127); });   // double tap = the whole keyboard
    }
    neBar(c, 410.0F, 282.0F, 240.0F, 14.0F, static_cast<float>(rg.keyLow) / 127.0F, static_cast<float>(rg.keyHigh) / 127.0F, true, 14.0F, false);
    registerSmoothRange(RectF(410.0F, 256.0F, 650.0F, 322.0F), 0.0F, 127.0F, 1.0F, static_cast<float>(rg.keyLow), static_cast<float>(rg.keyHigh),
                        [this, u, sound](float a, float b) { setSoundKeyRange(u, sound, rnd(a), rnd(b)); });
    neKeyboard(c, RectF(266.0F, 348.0F, 794.0F, 412.0F), rg.keyLow, rg.keyHigh);

    // the keys can also be set by playing: a tap, then the key on the MIDI keyboard
    for (int edge = 0; edge < 2; ++edge) {
        const RectF kr(edge == 0 ? 266.0F : 542.0F, 430.0F, edge == 0 ? 518.0F : 794.0F, 484.0F);
        const bool scanning = sampler.keyScanUpper() == u && sampler.keyScanSound() == sound && sampler.keyScanEdge() == edge;
        const bool blink = scanning && (nowMs() / 300) % 2 == 0;
        neKey(c, kr, scanning ? std::string("PRESS A KEY…") : (edge == 0 ? std::string("SET FROM · MIDI") : std::string("SET TO · MIDI")),
              scanning ? (blink ? NeKey::Sel : NeKey::On) : NeKey::Plain, 13.0F, true);
        if (scanning) postInvalidateDelayed(150);
        hit(kr, [this, u, sound, edge, scanning](float, float) {
            if (scanning) sampler.cancelKeyScan(); else sampler.startKeyScan(u, sound, edge);
            invalidate();
        });
    }
    text(c, "after SET press a key — it becomes the range end · double-tap = whole keyboard", 266.0F, 506.0F, 11.5F, NE_HINT, Opt().maxW(530.0F));

    const RectF quick(266.0F, 536.0F, 794.0F, 592.0F);
    nlBtn(c, quick, "TRANSPOSE / OCTAVE / TUNE", NlBtn::Plain, 13.0F, true);
    hit(quick, [this](float, float) { editGroup_ = EG_VOICE; invalidate(); });

    // OVERLAP: all five sounds of the UPPER on the keyboard, and where they play together
    nlPanel(c, RectF(826.0F, 214.0F, 1310.0F, 612.0F), "OVERLAP · KEYS");
    neSoundRows(c, u, sound, false);
    nlLabel(c, "OVERLAP", 840.0F, 551.5F, false, NL_TXT2, 11.0F);
    const RectF strip(920.0F, 534.0F, 1210.0F, 544.0F);
    fill(c, strip, 5.0F, Color::rgb(26, 29, 33));
    int counts[128] = {};
    for (int k = 0; k <= 4; ++k) {
        const SoundRanges r2 = soundRanges(u, k);
        if (!r2.has || (k > 0 && !layerOn(u, k - 1))) continue;
        for (int v = r2.keyLow; v <= r2.keyHigh; ++v) ++counts[v];
    }
    int v = 0;
    while (v < 128) {
        int w = v;
        while (w < 128 && counts[w] == counts[v]) ++w;
        if (counts[v] > 0) {
            fill(c, RectF(strip.left + strip.width() * static_cast<float>(v) / 128.0F, strip.top, strip.left + strip.width() * static_cast<float>(w) / 128.0F, strip.bottom), 0.0F,
                 counts[v] >= 2 ? NL_AMBER : NL_BLUE);
        }
        v = w;
    }
    text(c, "blue = one sound · amber = two or more sounds play together", 840.0F, 572.0F, 11.5F, NE_HINT, Opt().maxW(456.0F));
}

// ---------------------------------------------------------------- FILTER
void SilvetonSamplerView::drawEditFilter(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;

    nlPanel(c, RectF(250.0F, 214.0F, 1310.0F, 446.0F), "FILTER");
    neLegacyKnob(c, 340.0F, 322.0F, 96.0F, "CUTOFF", 4);
    neLegacyKnob(c, 510.0F, 322.0F, 96.0F, "RESONANCE", 5);
    {   // ENV AMOUNT: how far the filter envelope opens the cutoff (octaves)
        const float v = toneX(u, sound, 2);
        neDial(c, 680.0F, 322.0F, 96.0F, "ENV AMOUNT", std::string(v >= 0.0F ? "+" : "") + fmtFixed(static_cast<double>(v), 2) + " oct", v, -8.0F, 8.0F, 0.05F, 280.0F, true,
               [this, u, sound](float nv) { setToneX(u, sound, 2, nv); },
               [this, u, sound, v] { showNumber("FILTER ENV (octaves)", v, -8.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 2, x); }); },
               [this, u, sound] { setToneX(u, sound, 2, 0.0F); });
    }
    {   // ENV TIME: how fast the filter envelope runs (ms, logarithmic)
        const float t = toneX(u, sound, 3);
        const float norm = lnf(std::clamp(t, 1.0F, 20000.0F)) / lnf(20000.0F);
        neDial(c, 850.0F, 322.0F, 96.0F, "ENV TIME", msTxt(t, true), norm, 0.0F, 1.0F, 0.002F, 260.0F, false,
               [this, u, sound](float nv) { setToneX(u, sound, 3, rndf(std::clamp(expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(20000.0F)), 1.0F, 20000.0F))); },
               [this, u, sound, t] { showNumber("FILTER ENV TIME ms", t, 1.0F, 20000.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 3, x); }); },
               [this, u, sound] { setToneX(u, sound, 3, 120.0F); });
    }
    {   // HI-PASS (Hz, OFF below 10 Hz)
        const float hp = toneX(u, sound, 6);
        const float hn = hp < 10.0F ? 0.0F : lnf(hp / 10.0F) / lnf(400.0F);
        neDial(c, 1020.0F, 322.0F, 96.0F, "HI-PASS", hp < 10.0F ? std::string("OFF") : std::to_string(rnd(hp)) + " Hz", hn, 0.0F, 1.0F, 0.002F, 260.0F, false,
               [this, u, sound](float nv) { setToneX(u, sound, 6, nv <= 0.002F ? 0.0F : rndf(10.0F * static_cast<float>(std::pow(400.0, static_cast<double>(nv))))); },
               [this, u, sound, hp] { showNumber("HIGH-PASS Hz (0 = OFF)", hp, 0.0F, 4000.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 6, x); }); },
               [this, u, sound] { setToneX(u, sound, 6, 0.0F); });
    }
    {   // VEL->CUTOFF: how much a hard key opens the cutoff (octaves) - the same value as in VELOCITY
        const float vc = toneX(u, sound, 5);
        neDial(c, 1190.0F, 322.0F, 96.0F, "VEL→CUTOFF", fmtFixed(static_cast<double>(vc), 2) + " oct", vc, 0.0F, 8.0F, 0.05F, 250.0F, false,
               [this, u, sound](float nv) { setToneX(u, sound, 5, nv); },
               [this, u, sound, vc] { showNumber("VEL→CUTOFF (octaves)", vc, 0.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 5, x); }); },
               [this, u, sound] { setToneX(u, sound, 5, 0.0F); });
    }

    // TONE EQ of this sound (the five-band EQ of the whole UPPER is on the EQ page)
    nlPanel(c, RectF(250.0F, 456.0F, 1310.0F, 612.0F), "TONE EQ · THIS SOUND");
    static const char* const eqNames[3] = {"EQ LOW", "EQ MID", "EQ HIGH"};
    for (int k = 0; k < 3; ++k) {
        const int id = 12 + k;
        const float v = toneX(u, sound, id);
        const std::string title = eqNames[k];
        neDial(c, 340.0F + 170.0F * static_cast<float>(k), 540.0F, 70.0F, title, fmtFixed(static_cast<double>(v), 1) + " dB", v, -18.0F, 18.0F, 0.1F, 300.0F, true,
               [this, u, sound, id](float nv) { setToneX(u, sound, id, nv); },
               [this, u, sound, id, title, v] { showNumber(title + " dB", v, -18.0F, 18.0F, 1, [this, u, sound, id](float x) { setToneX(u, sound, id, x); }); },
               [this, u, sound, id] { setToneX(u, sound, id, 0.0F); });
    }
    text(c, "The five-band EQ of the whole UPPER is on the EQ page.", 870.0F, 532.0F, 12.0F, NE_HINT, Opt().maxW(430.0F));
    const RectF eqR(870.0F, 548.0F, 1120.0F, 594.0F);
    neKey(c, eqR, "OPEN EQ PAGE ▶", NeKey::Plain, 13.0F, true);
    hit(eqR, [this](float, float) { editGroup_ = EG_EQ; tab = UpperTab::EQ; invalidate(); });
}

// ---------------------------------------------------------------- ENVELOPE
// The picture of the amplitude envelope: the four points A D S R are dragged (A, D, R sideways = time, S up / down = level).
void SilvetonSamplerView::neAdsr(Canvas& c, const RectF& r, int u, int sound) {
    nlLcd(c, r);
    const float w = r.width();
    const float h = r.height();
    for (int j = 0; j <= 10; ++j) {
        const float yy = r.top + 20.0F + (h - 56.0F) * static_cast<float>(j) / 10.0F;
        line(c, r.left + 20.0F, yy, r.right - 20.0F, yy, j % 5 != 0 ? Color::rgb(42, 50, 59) : Color::rgb(59, 70, 82), 1.0F);
    }
    for (int j = 0; j <= 12; ++j) {
        const float xx = r.left + 20.0F + (w - 40.0F) * static_cast<float>(j) / 12.0F;
        line(c, xx, r.top + 20.0F, xx, r.top + h - 36.0F, j % 4 != 0 ? Color::rgb(35, 43, 51) : Color::rgb(51, 64, 76), 1.0F);
    }
    const float att = neLegacy(u, sound, 0);
    const float dec = neLegacy(u, sound, 1);
    const float sus = std::clamp(neLegacy(u, sound, 2), 0.0F, 1.0F);
    const float rel = neLegacy(u, sound, 3);
    const float tA = toneToNorm(TonePar::ATTACK, att);
    const float tD = toneToNorm(TonePar::DECAY, dec);
    const float tR = toneToNorm(TonePar::RELEASE, rel);
    const float y1 = r.top + 26.0F;               // the top (level 100 %)
    const float y0 = r.top + h - 36.0F;           // the bottom (level 0)
    const float ys = y0 - (y0 - y1) * sus;
    const float x0 = r.left + 20.0F;
    const float xa = x0 + 140.0F * tA;            // end of the attack
    const float xd = xa + 140.0F * tD;            // end of the decay
    const float xe = xd + 80.0F;                  // end of the sustain (the key is released)
    const float xr = xe + 140.0F * tR;            // end of the release
    {
        Path area;
        area.moveTo(x0, y0);
        area.lineTo(xa, y1);
        area.lineTo(xd, ys);
        area.lineTo(xe, ys);
        area.lineTo(xr, y0);
        area.close();
        paint.style = Style::Fill;
        paint.color = Color::BLACK;
        paint.shader = linearGradient(0.0F, y1, 0.0F, y0, Color::argb(115, 51, 160, 255), Color::argb(10, 51, 160, 255), TileMode::Clamp);
        c.drawPath(area, paint);
        paint.shader = nullptr;
        Path curve;
        curve.moveTo(x0, y0);
        curve.lineTo(xa, y1);
        curve.lineTo(xd, ys);
        curve.lineTo(xe, ys);
        curve.lineTo(xr, y0);
        paint.style = Style::Stroke;
        paint.strokeWidth = 3.5F;
        paint.color = NL_BLUE;
        c.drawPath(curve, paint);
        paint.style = Style::Fill;
    }
    struct Pt { float x, y; const char* letter; };
    const Pt pts[4] = {{xa, y1, "A"}, {xd, ys, "D"}, {(xd + xe) / 2.0F, ys, "S"}, {xr, y0, "R"}};
    for (const Pt& p : pts) {
        paint.shader = nullptr;
        paint.style = Style::Fill;
        paint.color = NL_AMBER;
        c.drawCircle(p.x, p.y, 15.0F, paint);
        paint.color = Color::rgb(11, 16, 20);
        c.drawCircle(p.x, p.y, 12.0F, paint);
        text(c, p.letter, p.x, p.y + 5.0F, 14.0F, NL_AMBER, Opt().center().bold());
    }
    text(c, "TIME →", r.left + w / 2.0F, r.top + h - 12.0F, 11.0F, Color::rgb(127, 139, 152), Opt().center().mono());
    text(c, "LEVEL ↑", r.right - 24.0F, r.top + 14.0F, 11.0F, Color::rgb(127, 139, 152), Opt().right().mono());

    // the touch: the point that was registered last wins where two points sit on each other (R, S, D, A)
    const auto timeDrag = [this, u, sound](int k, TonePar p, float startNorm) {
        return [this, u, sound, k, p, startNorm](float px, float, bool) {
            if (!dragMoved) return;
            neSetLegacy(u, sound, k, toneFromNorm(p, std::clamp(startNorm + afterSlop(px - downX, touchSlop) / 140.0F, 0.0F, 1.0F)));
        };
    };
    hit(RectF(xr - 20.0F, y0 - 20.0F, xr + 20.0F, y0 + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 3); },
        [this, u, sound] { neSetLegacy(u, sound, 3, -1.0F); }, timeDrag(3, TonePar::RELEASE, tR));
    hit(RectF((xd + xe) / 2.0F - 20.0F, ys - 20.0F, (xd + xe) / 2.0F + 20.0F, ys + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 2); },
        [this, u, sound] { neSetLegacy(u, sound, 2, -1.0F); },
        [this, u, sound, sus, y0, y1](float, float py, bool) {
            if (!dragMoved) return;
            const float n = std::clamp(sus + afterSlop(downY - py, touchSlop) / (y0 - y1), 0.0F, 1.0F);
            neSetLegacy(u, sound, 2, toneFromNorm(TonePar::SUSTAIN, n));
        });
    hit(RectF(xd - 20.0F, ys - 20.0F, xd + 20.0F, ys + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 1); },
        [this, u, sound] { neSetLegacy(u, sound, 1, -1.0F); }, timeDrag(1, TonePar::DECAY, tD));
    hit(RectF(xa - 20.0F, y1 - 20.0F, xa + 20.0F, y1 + 20.0F), [this, u, sound](float, float) { neLegacyExact(u, sound, 0); },
        [this, u, sound] { neSetLegacy(u, sound, 0, -1.0F); }, timeDrag(0, TonePar::ATTACK, tA));
}

void SilvetonSamplerView::drawEditEnvelope(Canvas& c) {
    drawQuickControls(c);
}

// ---------------------------------------------------------------- MODULATION
void SilvetonSamplerView::drawEditModulation(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const int sound = std::clamp(editSound, 0, 4);
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    nlPanel(c, RectF(250.0F, 214.0F, 1310.0F, 544.0F), "LFO · VIBRATO");
    struct Lfo { const char* label; int id; float lo; float hi; float step; };
    const Lfo lfo[4] = {{"RATE", 7, 0.1F, 20.0F, 0.05F}, {"DEPTH", 8, 0.0F, 200.0F, 1.0F}, {"DELAY", 9, 0.0F, 5000.0F, 10.0F}, {"FADE", 10, 0.0F, 5000.0F, 10.0F}};
    for (int k = 0; k < 4; ++k) {
        const Lfo f = lfo[k];
        const float v = toneX(u, sound, f.id);
        std::string shown;
        if (f.id == 7) shown = fmtFixed(static_cast<double>(v), 2) + " Hz";
        else if (f.id == 8) shown = std::to_string(rnd(v)) + " ct";
        else shown = msTxt(v, true);
        neDial(c, 350.0F + 190.0F * static_cast<float>(k), 360.0F, 124.0F, f.label, shown, v, f.lo, f.hi, f.step, 260.0F, false,
               [this, u, sound, f](float nv) { setToneX(u, sound, f.id, nv); },
               [this, u, sound, f, v] {
                   showNumber(std::string("VIBRATO ") + f.label, v, f.lo, f.hi, f.id == 7 ? 1 : 0, [this, u, sound, f](float x) { setToneX(u, sound, f.id, x); });
               },
               [this, u, sound, f] { setToneX(u, sound, f.id, f.id == 7 ? 5.5F : (f.id == 10 ? 300.0F : 0.0F)); }, 100.0F);
    }
    nlLabel(c, "VIBRATO FROM", 1060.0F, 301.5F, false, NL_TXT2, 11.0F);
    const bool wheelOn = toneX(u, sound, 11) >= 0.5F;
    const RectF wr(1060.0F, 312.0F, 1290.0F, 388.0F);
    neKey(c, wr, "MOD WHEEL", wheelOn ? NeKey::On : NeKey::Off, 16.0F, true);
    hit(wr, [this, u, sound, wheelOn](float, float) { setToneX(u, sound, 11, wheelOn ? 0.0F : 1.0F); });
    text(c, "depth follows the mod wheel (CC 1)", 1060.0F, 412.0F, 12.0F, NE_HINT, Opt().maxW(240.0F));
}

} // namespace silveton::ui::classic
