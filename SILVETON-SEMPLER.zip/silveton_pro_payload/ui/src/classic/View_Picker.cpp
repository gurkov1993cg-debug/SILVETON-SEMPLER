// SILVETON_MAC_VIEW_V1 - the sound picker (tablet lines 3263-3400), moved here from View_Eq.cpp
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
bool containsIgnoreCase(const std::string& hay, const std::string& needle) {
    return utf8Upper(hay).find(utf8Upper(needle)) != std::string::npos;
}
} // namespace

// ---------------------------------------------------------------- SILVETON_PICKER_V1 full-screen sound picker
void SilvetonSamplerView::openPicker(int upper, int layer) {
    const std::vector<SoundItem> all = sampler.soundCatalog();
    if (all.empty()) { showSoundPicker(upper); return; }
    int prevSlot = 0;
    if (layer < 0) {
        const auto& picked = lastPickedSound[static_cast<std::size_t>(upper)];
        if (picked) {
            prevSlot = picked->slot;
        } else {
            const auto& st = upperStates[static_cast<std::size_t>(upper)];
            for (const auto& it : all) if (st && it.name == st->soundName) { prevSlot = it.slot; break; }
        }
    } else if (layer >= kWavePickerBase) {   // SILVETON_TRANSWAVE_V1: a frame of MULTI
        const int k = layer - kWavePickerBase;
        prevSlot = static_cast<int>(std::lround(waveP(upper, k / 8, 10 + k % 8)));
    } else {
        prevSlot = layerSlot(upper, layer);
    }
    std::string prevName;
    if (layer >= kWavePickerBase) { for (const auto& it : all) if (it.slot == prevSlot) { prevName = it.name; break; } }
    else if (layer < 0) prevName = upperStates[static_cast<std::size_t>(upper)] ? upperStates[static_cast<std::size_t>(upper)]->soundName : std::string();
    else prevName = lName(upper, layer);
    auto pk = std::make_shared<PickerState>(upper, layer, prevSlot, prevName);
    int idx = -1;
    for (std::size_t i = 0U; i < all.size(); ++i) if (all[i].slot == prevSlot) { idx = static_cast<int>(i); break; }
    pk->page = idx >= 0 ? idx / 40 : 0;
    picker = pk;
    page_ = Page::COMBI;
    invalidate();
}

std::vector<SilvetonSamplerView::SoundItem> SilvetonSamplerView::pickerItems(PickerState& pk) {
    const std::vector<SoundItem> all = sampler.soundCatalog();
    std::vector<SoundItem> out;
    if (!pk.search.empty()) {
        for (const auto& it : all) if (containsIgnoreCase(it.name, pk.search)) out.push_back(it);
    } else if (pk.favOnly) {
        const std::set<int> f = sampler.soundFavourites();
        for (const auto& it : all) if (f.count(it.slot) != 0U) out.push_back(it);
    } else if (pk.recentOnly) {
        for (const int slot : sampler.recentSounds()) {
            for (const auto& it : all) if (it.slot == slot) { out.push_back(it); break; }
        }
    } else {
        // SILVETON_SOUND_BY_NUMBER_V2: all 500 places are shown, the empty ones too (an empty place = no name), then the built-in waves
        std::vector<const SoundItem*> at(501U, nullptr);
        std::vector<const SoundItem*> builtIn;
        for (const auto& it : all) {
            if (it.slot >= 1 && it.slot <= 500 && it.bank == 0 && it.page == 0) at[static_cast<std::size_t>(it.slot)] = &it;
            else builtIn.push_back(&it);
        }
        for (int slot = 1; slot <= 500; ++slot) {
            if (at[static_cast<std::size_t>(slot)] != nullptr) out.push_back(*at[static_cast<std::size_t>(slot)]);
            else out.push_back(SoundItem{0, 0, slot, std::string()});
        }
        for (const SoundItem* b : builtIn) out.push_back(*b);
    }
    return out;
}

void SilvetonSamplerView::pickerAssign(PickerState& pk, const std::optional<SoundItem>& item) {
    if (pk.layer < 0) {
        if (!item) {
            sampler.clearUpperSound(pk.upper);
            lastPickedSound[static_cast<std::size_t>(pk.upper)].reset();
        } else {
            sampler.assignUpperSound(pk.upper, *item);
            lastPickedSound[static_cast<std::size_t>(pk.upper)] = *item;
        }
    } else if (pk.layer >= kWavePickerBase) {
        const int k = pk.layer - kWavePickerBase;
        setWaveP(pk.upper, k / 8, 10 + k % 8, item ? static_cast<float>(item->slot) : 0.0F);
    } else {
        sampler.setLayerSound(pk.upper, pk.layer, item ? item->slot : 0);
    }
    pk.chosenSlot = item ? item->slot : 0;
    refreshUpper(pk.upper);
}

// SILVETON_MULTI_DELETE_V1: the marked sounds leave the sampler (asked once, with their names).
void SilvetonSamplerView::deleteMarkedSounds(const std::shared_ptr<PickerState>& pkp) {
    if (pkp->marked.empty()) { flash("TOUCH THE SOUNDS TO DELETE"); return; }
    std::vector<int> places(pkp->marked.begin(), pkp->marked.end());
    std::string names;
    std::size_t shown = 0U;
    for (const auto& it : sampler.soundCatalog()) {
        if (pkp->marked.count(it.slot) == 0U) continue;
        if (shown < 12U) names += (shown == 0U ? "" : ", ") + it.name;
        ++shown;
    }
    if (shown > 12U) names += " … (" + std::to_string(shown) + ")";
    showConfirm("DELETE " + std::to_string(places.size()) + (places.size() == 1U ? " SOUND" : " SOUNDS"),
                "They leave the sampler for good. The blends that use them stay without them:\n" + names,
                "DELETE", [this, pkp, places]() {
                    const auto err = sampler.deleteSounds(places);
                    if (pkp->marked.count(pkp->chosenSlot) != 0U) pkp->chosenSlot = 0;
                    pkp->marked.clear();
                    pkp->markMode = false;
                    dropParamCaches(pkp->upper);
                    refreshAllUppers();
                    if (err) flash("ERROR: " + *err);
                    invalidate();
                }, "CANCEL");
}

// SILVETON_NEW_LOOK_V1: the sound picker in the content area y 96..698 (picker.png): the top bar and the bottom menu stay.
// Row 1: SEARCH, RECENT, ★, the display of the chosen sound, DELETE, CANCEL, OK. Row 2: the page keys. Then 5 x 8 cells.
void SilvetonSamplerView::drawPicker(Canvas& c, const std::shared_ptr<PickerState>& pkp) {
    PickerState& pk = *pkp;
    const std::vector<SoundItem> items = pickerItems(pk);
    const int pages = std::max(1, (static_cast<int>(items.size()) + 39) / 40);
    pk.page = std::clamp(pk.page, 0, pages - 1);
    // top row: SEARCH · RECENT · ★ · target · DELETE · CANCEL · OK
    const RectF fr(20.0F, 98.0F, 120.0F, 142.0F);
    nlBtn(c, fr, "SEARCH", pk.search.empty() ? NlBtn::Off : NlBtn::On, 13.0F, false);
    hit(fr, [this, pkp](float, float) {
        if (!pkp->search.empty()) {
            pkp->search.clear();
            pkp->page = 0;
            invalidate();
        } else {
            showTextPage("SEARCH SOUND BY NAME", "", [this, pkp](const std::string& q) {
                pkp->search = trimmed(q);
                pkp->favOnly = false;
                pkp->recentOnly = false;
                pkp->page = 0;
                invalidate();
            });
        }
    });
    const RectF rr(129.0F, 98.0F, 249.0F, 142.0F);
    nlBtn(c, rr, "RECENT", pk.recentOnly ? NlBtn::On : NlBtn::Off, 13.0F, false);
    hit(rr, [pkp](float, float) { pkp->recentOnly = !pkp->recentOnly; pkp->favOnly = false; pkp->search.clear(); pkp->page = 0; });
    const RectF sr(258.0F, 98.0F, 314.0F, 142.0F);
    nlBtn(c, sr, "★", pk.favOnly ? NlBtn::Sel : NlBtn::Off, 17.0F, false);
    hit(sr, [pkp](float, float) { pkp->favOnly = !pkp->favOnly; pkp->recentOnly = false; pkp->search.clear(); pkp->page = 0; });
    const RectF tgt(323.0F, 98.0F, 893.0F, 142.0F);
    nlLcd(c, tgt);
    std::string who = pk.layer < 0 ? "UPPER " + std::to_string(pk.upper + 1) + " · MAIN" : "UPPER " + std::to_string(pk.upper + 1) + " · L" + std::to_string(pk.layer + 1);
    if (pk.layer >= kWavePickerBase) who = "UPPER " + std::to_string(pk.upper + 1) + " · WAVE FRAME " + std::to_string((pk.layer - kWavePickerBase) % 8 + 1);
    std::string nowName;
    if (pk.layer >= kWavePickerBase) { for (const auto& it : sampler.soundCatalog()) if (it.slot == pk.chosenSlot) { nowName = it.name; break; } }
    else if (pk.layer < 0) nowName = upperStates[static_cast<std::size_t>(pk.upper)] ? upperStates[static_cast<std::size_t>(pk.upper)]->soundName : std::string();
    else nowName = lName(pk.upper, pk.layer);
    text(c, who, tgt.left + 14.0F, tgt.top + 16.0F, 10.0F, NL_BLUE, Opt().bold().spacing(0.13F).maxW(tgt.width() - 28.0F));
    // SILVETON_MULTI_DELETE_V1: DELETE = a tap marks sounds (as many as you like); the DELETE n key (in the place of OK) takes the marked ones out of the sampler
    const std::size_t markedCount = pk.marked.size();
    if (pk.markMode) {
        text(c, markedCount == 0U ? std::string("MARK: tap the sounds that are to be deleted")
                                  : "MARKED: " + std::to_string(markedCount) + "  ·  tap more, or DELETE " + std::to_string(markedCount),
             tgt.left + 14.0F, tgt.top + 36.0F, 16.0F, C_LCD_BAD, Opt().bold().maxW(tgt.width() - 28.0F));
    } else {
        text(c, "▶ " + (pk.chosenSlot > 0 ? fmtZeroPad(pk.chosenSlot, 3) + "  " : std::string()) + nowName, tgt.left + 14.0F, tgt.top + 36.0F, 17.0F, Color::WHITE,
             Opt().bold().maxW(tgt.width() - 28.0F));
    }
    const RectF markR(902.0F, 98.0F, 1022.0F, 142.0F);
    nlBtn(c, markR, "DELETE", pk.markMode ? NlBtn::Red : NlBtn::Off, 13.0F, false);
    hit(markR, [pkp](float, float) { pkp->markMode = !pkp->markMode; if (!pkp->markMode) pkp->marked.clear(); });
    const RectF cancel(1031.0F, 98.0F, 1171.0F, 142.0F);
    const RectF ok(1180.0F, 98.0F, 1320.0F, 142.0F);
    nlBtn(c, cancel, "CANCEL", NlBtn::Plain, 14.0F, false);
    if (pk.markMode) nlBtn(c, ok, markedCount == 0U ? std::string("DELETE") : "DELETE " + std::to_string(markedCount), markedCount > 0U ? NlBtn::Red : NlBtn::Off, 15.0F, false);
    else nlBtn(c, ok, "OK", NlBtn::Sel, 16.0F, false);
    hit(cancel, [this, pkp](float, float) {
        if (pkp->markMode) { pkp->markMode = false; pkp->marked.clear(); return; }   // only out of the marking, the picker stays
        const std::vector<SoundItem> all = sampler.soundCatalog();
        std::optional<SoundItem> prev;
        for (const auto& it : all) if (it.slot == pkp->previousSlot) { prev = it; break; }
        if (pkp->chosenSlot != pkp->previousSlot) pickerAssign(*pkp, prev);
        picker.reset();
    });
    hit(ok, [this, pkp](float, float) {
        if (pkp->markMode) { deleteMarkedSounds(pkp); return; }
        if (pkp->chosenSlot > 0) sampler.rememberRecentSound(pkp->chosenSlot);
        // LINK: the sound that stays after OK goes to the other marked Uppers too
        if (pkp->chosenSlot != pkp->previousSlot) {
            std::optional<SoundItem> chosen;
            for (const auto& it : sampler.soundCatalog()) if (it.slot == pkp->chosenSlot) { chosen = it; break; }
            if (pkp->layer < kWavePickerBase) mirrorSound(pkp->upper, pkp->layer, chosen);
        }
        picker.reset();
    });
    // page keys
    const float pw = std::min(94.15F, (1300.0F - static_cast<float>(pages - 1) * 6.0F) / static_cast<float>(pages));
    for (int pg = 0; pg < pages; ++pg) {
        const RectF pr(20.0F + static_cast<float>(pg) * (pw + 6.0F), 150.0F, 20.0F + static_cast<float>(pg) * (pw + 6.0F) + pw, 186.0F);
        nlBtn(c, pr, std::to_string(pg + 1), pk.page == pg ? NlBtn::Sel : NlBtn::Off, 13.0F, false);
        hit(pr, [pkp, pg](float, float) { pkp->page = pg; });
    }
    // grid 5 x 8
    const std::set<int> favs = sampler.soundFavourites();
    const float cw = 253.6F;
    const float ch = 56.0F;
    for (int k = 0; k < 40; ++k) {
        const int idx = pk.page * 40 + k;
        if (idx >= static_cast<int>(items.size())) break;
        const SoundItem item = items[static_cast<std::size_t>(idx)];
        const int col = k % 5;
        const int row = k / 5;
        const RectF cr(20.0F + static_cast<float>(col) * (cw + 8.0F), 194.0F + static_cast<float>(row) * (ch + 6.0F),
                       20.0F + static_cast<float>(col) * (cw + 8.0F) + cw, 194.0F + static_cast<float>(row) * (ch + 6.0F) + ch);
        if (item.name.empty()) {   // SILVETON_SOUND_BY_NUMBER_V2: an empty place - the next sent sound takes the first of these
            dlgCell(c, cr, 2);
            text(c, fmtZeroPad(item.slot, 3), cr.left + 12.0F, cr.top + 18.0F, 13.0F, Color::rgb(127, 139, 152), Opt().monoBold());
            text(c, "— empty —", cr.left + 12.0F, cr.top + 42.0F, 17.0F, NL_MUT, Opt().bold().maxW(cw - 24.0F));
            hit(cr, [this](float, float) { flash("EMPTY POSITION - THE NEXT SENT SOUND WILL TAKE ITS PLACE HERE"); });
            continue;
        }
        const bool isMarked = pk.markMode && pk.marked.count(item.slot) != 0U;
        const bool chosen = !pk.markMode && item.slot == pk.chosenSlot;
        dlgCell(c, cr, isMarked ? 3 : (chosen ? 1 : 0));
        text(c, fmtZeroPad(item.slot, 3), cr.left + 12.0F, cr.top + 18.0F, 13.0F, chosen ? Color::rgb(207, 230, 255) : Color::rgb(127, 139, 152), Opt().monoBold());
        text(c, item.name, cr.left + 12.0F, cr.top + 42.0F, 17.0F, Color::WHITE, Opt().bold().maxW(cw - 46.0F));
        if (favs.count(item.slot) != 0U) text(c, "★", cr.right - 10.0F, cr.top + 22.0F, 17.0F, chosen ? Color::WHITE : NL_AMBER, Opt().right().bold());
        hit(cr, [this, pkp, item](float, float) {
                if (pkp->markMode) { if (pkp->marked.count(item.slot) != 0U) pkp->marked.erase(item.slot); else pkp->marked.insert(item.slot); invalidate(); return; }
                pickerAssign(*pkp, item);
            },
            [this, item, favs] {
                std::set<int> f = favs;
                if (f.count(item.slot) != 0U) f.erase(item.slot); else f.insert(item.slot);
                sampler.saveSoundFavourites(f);
                invalidate();
            });
    }
    if (items.empty()) text(c, "NO SOUNDS", 670.0F, 440.0F, 24.0F, NL_MUT, Opt().center().bold());
}

// ---------------------------------------------------------------- SILVETON_GUI_V3 helpers

} // namespace silveton::ui::classic
