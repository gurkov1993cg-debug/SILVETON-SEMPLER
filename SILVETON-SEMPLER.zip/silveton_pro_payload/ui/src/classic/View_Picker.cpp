// SILVETON_MAC_VIEW_V1 - the sound picker (tablet lines 3263-3400), moved here from View_Eq.cpp
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SoloDefs.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
bool containsIgnoreCase(const std::string& hay, const std::string& needle) {
    return utf8Upper(hay).find(utf8Upper(needle)) != std::string::npos;
}
} // namespace

// ---------------------------------------------------------------- SILVETON_PICKER_V1 full-screen sound picker
void SilvetonSamplerView::moveLegacySolo(int upper,int sound) {
    std::vector<int> legacy;std::vector<std::string> names;
    for(int i=7;i<15;++i)if(sampler.soundSource(i,0).engine.chosen()){
        legacy.push_back(i);names.push_back(sampler.soundSource(i,0).name+" · SOLO "+std::to_string(i-6));
    }
    if(legacy.empty())return;
    showItems("OLD SET SOLO",names,[this,upper,sound,legacy](int index){
        if(index<0||index>=static_cast<int>(legacy.size()))return;
        const int old=legacy[static_cast<std::size_t>(index)];auto source=sampler.soundSource(old,0);
        showConfirm("MOVE TO "+neUpperName(upper)+" / "+soundLabel(sound),
            "Move "+source.name+" here? This place's tuning, envelope and the UPPER's effects/portamento will apply. The previous SOLO place will be cleared.","MOVE",
            [this,upper,sound,old,source]()mutable{source.commonProcessing=true;
                if(!sampler.putSoundSource(upper,sound,source)||!sampler.putSoundSource(old,0,{})){showMessage("MOVE FAILED",failureText(sampler.lastFailure()));return;}
                showSoloPart(upper,sound);soloSessionDirty();});
    });
}
void SilvetonSamplerView::openPicker(int upper, int layer) {
    if(upper<0||upper>=7||layer<-1||(layer>=4&&layer<kWavePickerBase))return;
    if(layer<4)selectSound(upper,layer+1);
    const std::vector<SoundItem> all = sampler.soundCatalog();
    int prevSlot = 0;
    if (layer < 0) {
        prevSlot = sampler.upperSoundSlot(upper);
    } else if (layer >= kWavePickerBase) {   // SILVETON_TRANSWAVE_V1: a frame of MULTI
        const int k = layer - kWavePickerBase;
        prevSlot = static_cast<int>(std::lround(waveP(upper, k / 8, 10 + k % 8)));
    } else {
        prevSlot = layerSlot(upper, layer);
    }
    std::string prevName;
    if (layer >= kWavePickerBase) { for (const auto& it : all) if (it.slot == prevSlot) { prevName = it.name; break; } }
    else if (layer < 0) prevName = upperStates[static_cast<std::size_t>(upper)] ? upperStates[static_cast<std::size_t>(upper)]->soundName : std::string();
    else prevName = lName(upper, layer);
    auto pk = std::make_shared<PickerState>(upper, layer, prevSlot, prevName);
    if(layer<4){
        pk->previousSource=sampler.soundSource(upper,layer+1);
        const auto st=sampler.upperState(upper);
        pk->previousUpperEnabled=st&&st->enabled;
        if(layer>=0)pk->previousLayerEnabled=getOr(sampler.layerParams(upper,layer),0,0)>0.5F;
    }
    if(layer<4){
        namespace sv=::silveton::sampler;
        for(int i=0;i<sv::solo::kPresets;++i){
            sv::SoundAssignment source;source.engine=sv::engineDefaults(sv::EngineType::Solo);
            sv::solo::factory(i,source.engine.p.data());source.name=sv::solo::presetName(i);source.commonProcessing=true;
            const int id=10001+i;pk->sources.emplace(id,std::move(source));
            if(pk->previousSource.engine.chosen()&&!pk->previousSource.soloModel&&pk->previousSource.name==sv::solo::presetName(i))
                pk->previousSlot=pk->chosenSlot=id;
        }
    }
    const auto items=pickerItems(*pk);
    int idx = -1;
    for (std::size_t i = 0U; i < items.size(); ++i) if (items[i].slot == pk->previousSlot) { idx = static_cast<int>(i); break; }
    if(idx<0)for(std::size_t i=0;i<items.size();++i)if(!items[i].name.empty()){idx=static_cast<int>(i);break;}
    pk->page = idx >= 0 ? idx / 40 : 0;
    picker = pk;
    page_ = Page::COMBI;
    invalidate();
}

std::vector<SilvetonSamplerView::SoundItem> SilvetonSamplerView::pickerItems(PickerState& pk) {
    // One playable list: the existing synth voices and waves are immediately
    // available, followed by occupied bank addresses. Empty bank storage places
    // are not sounds and do not belong in the performance picker.
    std::vector<SoundItem> all;
    for (const auto& source : pk.sources)
        if (!source.second.name.empty()) all.push_back(SoundItem{0, 0, source.first, source.second.name});
    const auto catalog = sampler.soundCatalog();
    for (const auto& item : catalog)
        if (!item.name.empty() && item.slot > 500) all.push_back(item);
    for (const auto& item : catalog)
        if (!item.name.empty() && item.slot >= 1 && item.slot <= 500) all.push_back(item);
    std::vector<SoundItem> out;
    if (!pk.search.empty()) {
        for (const auto& it : all) if (containsIgnoreCase(it.name, pk.search)) out.push_back(it);
    } else if (pk.favOnly) {
        const std::set<int> f = sampler.soundFavourites();
        for (const auto& it : all) if (f.count(it.slot) != 0U) out.push_back(it);
    } else if (pk.recentOnly) {
        for (const int slot : sampler.recentSounds()) {
            for (const auto& it : all) if (it.slot == slot) { out.push_back(it); break; }
        }
    } else {
        out = std::move(all);
    }
    return out;
}

void SilvetonSamplerView::cancelPicker() {
    const auto pkp=picker;
    if(!pkp)return;
    if (pkp->markMode) { pkp->markMode = false; pkp->marked.clear(); return; }   // only out of the marking, the picker stays
    const std::vector<SoundItem> all = sampler.soundCatalog();
    std::optional<SoundItem> prev;
    for (const auto& it : all) if (it.slot == pkp->previousSlot) { prev = it; break; }
    if (pkp->previewChanged) {
        if(pkp->layer<4){
            if(!sampler.putSoundSource(pkp->upper,pkp->layer+1,pkp->previousSource)){
                showMessage("RESTORE FAILED",failureText(sampler.lastFailure()));return;
            }
            if(pkp->layer>=0)sampler.setLayerParam(pkp->upper,pkp->layer,0,pkp->previousLayerEnabled?1.F:0.F);
            auto st=sampler.upperState(pkp->upper);
            if(st){st->enabled=pkp->previousUpperEnabled;sampler.updateUpperMain(pkp->upper,*st);}
            lastPickedSound[static_cast<std::size_t>(pkp->upper)].reset();
            refreshUpper(pkp->upper);
        }
        else pickerAssign(*pkp, prev);
    }
    picker.reset();
    invalidate();
}

void SilvetonSamplerView::pickerAssign(PickerState& pk, const std::optional<SoundItem>& item) {
    const auto extra=item?pk.sources.find(item->slot):pk.sources.end();
    if(extra!=pk.sources.end()){
        if(!sampler.putSoundSource(pk.upper,pk.layer+1,extra->second)){
            showMessage("SOUND NOT LOADED",failureText(sampler.lastFailure()));return;
        }
        if(pk.layer<0)lastPickedSound[static_cast<std::size_t>(pk.upper)].reset();
    } else if (pk.layer < 0) {
        if (!item) {
            sampler.clearUpperSound(pk.upper);
            lastPickedSound[static_cast<std::size_t>(pk.upper)].reset();
        } else {
            sampler.assignUpperSound(pk.upper, *item);
            lastPickedSound[static_cast<std::size_t>(pk.upper)] = *item;
        }
    } else if (pk.layer >= kWavePickerBase) {
        const int k = pk.layer - kWavePickerBase;
        setWaveP(pk.upper, k / 8, 10 + k % 8, item ? static_cast<float>(item->slot) : 0.0F);
    } else {
        sampler.setLayerSound(pk.upper, pk.layer, item ? item->slot : 0);
    }
    pk.previewChanged=true;
    pk.chosenSlot = item ? item->slot : 0;
    refreshUpper(pk.upper);
}

// SILVETON_MULTI_DELETE_V1: the marked sounds leave the sampler (asked once, with their names).
void SilvetonSamplerView::deleteMarkedSounds(const std::shared_ptr<PickerState>& pkp) {
    if (pkp->marked.empty()) { flash("TOUCH THE SOUNDS TO DELETE"); return; }
    std::vector<int> places(pkp->marked.begin(), pkp->marked.end());
    std::string names;
    std::size_t shown = 0U;
    for (const auto& it : sampler.soundCatalog()) {
        if (pkp->marked.count(it.slot) == 0U) continue;
        if (shown < 12U) names += (shown == 0U ? "" : ", ") + it.name;
        ++shown;
    }
    if (shown > 12U) names += " … (" + std::to_string(shown) + ")";
    showConfirm("DELETE " + std::to_string(places.size()) + (places.size() == 1U ? " SOUND" : " SOUNDS"),
                "They leave the sampler for good. The blends that use them stay without them:\n" + names,
                "DELETE", [this, pkp, places]() {
                    const auto err = sampler.deleteSounds(places);
                    if (pkp->marked.count(pkp->chosenSlot) != 0U) pkp->chosenSlot = 0;
                    pkp->marked.clear();
                    pkp->markMode = false;
                    dropParamCaches(pkp->upper);
                    refreshAllUppers();
                    if (err) flash("ERROR: " + *err);
                    invalidate();
                }, "CANCEL");
}

// SILVETON_NEW_LOOK_V1: the sound picker in the content area y 96..698 (picker.png): the top bar and the bottom menu stay.
// Row 1: SEARCH, RECENT, ★, the display of the chosen sound, DELETE, CANCEL, OK. Row 2: the page keys. Then 5 x 8 cells.
void SilvetonSamplerView::drawPicker(Canvas& c, const std::shared_ptr<PickerState>& pkp) {
    PickerState& pk = *pkp;
    const std::vector<SoundItem> items = pickerItems(pk);
    const int pages = std::max(1, (static_cast<int>(items.size()) + 39) / 40);
    pk.page = std::clamp(pk.page, 0, pages - 1);
    // top row: SEARCH · RECENT · ★ · target · DELETE · CANCEL · OK
    const RectF fr(20.0F, 98.0F, 120.0F, 142.0F);
    nlBtn(c, fr, "SEARCH", pk.search.empty() ? NlBtn::Off : NlBtn::On, 13.0F, false);
    hit(fr, [this, pkp](float, float) {
        if (!pkp->search.empty()) {
            pkp->search.clear();
            pkp->page = 0;
            invalidate();
        } else {
            showTextPage("SEARCH SOUND BY NAME", "", [this, pkp](const std::string& q) {
                pkp->search = trimmed(q);
                pkp->favOnly = false;
                pkp->recentOnly = false;
                pkp->page = 0;
                invalidate();
            });
        }
    });
    const RectF rr(129.0F, 98.0F, 249.0F, 142.0F);
    nlBtn(c, rr, "RECENT", pk.recentOnly ? NlBtn::On : NlBtn::Off, 13.0F, false);
    hit(rr, [pkp](float, float) { pkp->recentOnly = !pkp->recentOnly; pkp->favOnly = false; pkp->search.clear(); pkp->page = 0; });
    const RectF sr(258.0F, 98.0F, 314.0F, 142.0F);
    nlBtn(c, sr, "★", pk.favOnly ? NlBtn::Sel : NlBtn::Off, 17.0F, false);
    hit(sr, [pkp](float, float) { pkp->favOnly = !pkp->favOnly; pkp->recentOnly = false; pkp->search.clear(); pkp->page = 0; });
    const bool canLoad=pk.layer<4&&sampler.canChooseSoloModel();
    const RectF tgt(323.0F, 98.0F, canLoad?715.0F:893.0F, 142.0F);
    if(canLoad){
        const RectF load(724,98,893,142);nlBtn(c,load,"LOAD .svsolo…",NlBtn::Plain,12,false);
        hit(load,[this,pkp](float,float){sampler.chooseSoloModel(pkp->upper,pkp->layer+1);});
    }
    nlLcd(c, tgt);
    std::string who = neUpperName(pk.upper)+" · "+(pk.layer<0?std::string("MAIN"):"L"+std::to_string(pk.layer+1));
    if (pk.layer >= kWavePickerBase) who = "UPPER " + std::to_string(pk.upper + 1) + " · WAVE FRAME " + std::to_string((pk.layer - kWavePickerBase) % 8 + 1);
    std::string nowName;
    if (pk.layer >= kWavePickerBase) { for (const auto& it : sampler.soundCatalog()) if (it.slot == pk.chosenSlot) { nowName = it.name; break; } }
    else if (pk.layer < 0) nowName = upperStates[static_cast<std::size_t>(pk.upper)] ? upperStates[static_cast<std::size_t>(pk.upper)]->soundName : std::string();
    else nowName = lName(pk.upper, pk.layer);
    text(c, who, tgt.left + 14.0F, tgt.top + 16.0F, 10.0F, NL_BLUE, Opt().bold().spacing(0.13F).maxW(tgt.width() - 28.0F));
    // SILVETON_MULTI_DELETE_V1: DELETE = a tap marks sounds (as many as you like); the DELETE n key (in the place of OK) takes the marked ones out of the sampler
    const std::size_t markedCount = pk.marked.size();
    if (pk.markMode) {
        text(c, markedCount == 0U ? std::string("MARK: tap the sounds that are to be deleted")
                                  : "MARKED: " + std::to_string(markedCount) + "  ·  tap more, or DELETE " + std::to_string(markedCount),
             tgt.left + 14.0F, tgt.top + 36.0F, 16.0F, C_LCD_BAD, Opt().bold().maxW(tgt.width() - 28.0F));
    } else {
        text(c, "▶ " + (pk.chosenSlot >= 1 && pk.chosenSlot <= 500 ? fmtZeroPad(pk.chosenSlot, 3) + "  " : std::string()) + nowName, tgt.left + 14.0F, tgt.top + 36.0F, 17.0F, Color::WHITE,
             Opt().bold().maxW(tgt.width() - 28.0F));
    }
    const RectF markR(902.0F, 98.0F, 1022.0F, 142.0F);
    nlBtn(c, markR, "DELETE", pk.markMode ? NlBtn::Red : NlBtn::Off, 13.0F, false);
    hit(markR, [pkp](float, float) { pkp->markMode = !pkp->markMode; if (!pkp->markMode) pkp->marked.clear(); });
    const RectF cancel(1031.0F, 98.0F, 1171.0F, 142.0F);
    const RectF ok(1180.0F, 98.0F, 1320.0F, 142.0F);
    nlBtn(c, cancel, "CANCEL", NlBtn::Plain, 14.0F, false);
    if (pk.markMode) nlBtn(c, ok, markedCount == 0U ? std::string("DELETE") : "DELETE " + std::to_string(markedCount), markedCount > 0U ? NlBtn::Red : NlBtn::Off, 15.0F, false);
    else nlBtn(c, ok, "OK", NlBtn::Sel, 16.0F, false);
    hit(cancel, [this](float, float) { cancelPicker(); });
    hit(ok, [this, pkp](float, float) {
        if (pkp->markMode) { deleteMarkedSounds(pkp); return; }
        if (pkp->chosenSlot > 0) sampler.rememberRecentSound(pkp->chosenSlot);
        // Copy the chosen source through the common assignment for linked UPPERs.
        if(pkp->previewChanged&&pkp->layer<4)mirrorSound(pkp->upper,pkp->layer);
        picker.reset();
    });
    // page keys
    const float pw = std::min(94.15F, (1300.0F - static_cast<float>(pages - 1) * 6.0F) / static_cast<float>(pages));
    for (int pg = 0; pg < pages; ++pg) {
        const RectF pr(20.0F + static_cast<float>(pg) * (pw + 6.0F), 150.0F, 20.0F + static_cast<float>(pg) * (pw + 6.0F) + pw, 186.0F);
        nlBtn(c, pr, std::to_string(pg + 1), pk.page == pg ? NlBtn::Sel : NlBtn::Off, 13.0F, false);
        hit(pr, [pkp, pg](float, float) { pkp->page = pg; });
    }
    // grid 5 x 8
    const std::set<int> favs = sampler.soundFavourites();
    const float cw = 253.6F;
    const float ch = 56.0F;
    for (int k = 0; k < 40; ++k) {
        const int idx = pk.page * 40 + k;
        if (idx >= static_cast<int>(items.size())) break;
        const SoundItem item = items[static_cast<std::size_t>(idx)];
        const int col = k % 5;
        const int row = k / 5;
        const RectF cr(20.0F + static_cast<float>(col) * (cw + 8.0F), 194.0F + static_cast<float>(row) * (ch + 6.0F),
                       20.0F + static_cast<float>(col) * (cw + 8.0F) + cw, 194.0F + static_cast<float>(row) * (ch + 6.0F) + ch);
        const bool isMarked = pk.markMode && pk.marked.count(item.slot) != 0U;
        const bool chosen = !pk.markMode && item.slot == pk.chosenSlot;
        dlgCell(c, cr, isMarked ? 3 : (chosen ? 1 : 0));
        const std::string kind = pk.sources.count(item.slot) ? "SYNTH" :
            (item.slot > 500 ? "WAVE" : fmtZeroPad(item.slot, 3));
        text(c, kind, cr.left + 12.0F, cr.top + 18.0F, 13.0F, chosen ? Color::rgb(207, 230, 255) : Color::rgb(127, 139, 152), Opt().monoBold());
        text(c, item.name, cr.left + 12.0F, cr.top + 42.0F, 17.0F, Color::WHITE, Opt().bold().maxW(cw - 46.0F));
        if (favs.count(item.slot) != 0U) text(c, "★", cr.right - 10.0F, cr.top + 22.0F, 17.0F, chosen ? Color::WHITE : NL_AMBER, Opt().right().bold());
        hit(cr, [this, pkp, item](float, float) {
                if (pkp->markMode) { if(item.slot>500){flash("BUILT-IN SOUND");return;} if (pkp->marked.count(item.slot) != 0U) pkp->marked.erase(item.slot); else pkp->marked.insert(item.slot); invalidate(); return; }
                pickerAssign(*pkp, item);
            },
            [this, item, favs] {
                std::set<int> f = favs;
                if (f.count(item.slot) != 0U) f.erase(item.slot); else f.insert(item.slot);
                sampler.saveSoundFavourites(f);
                invalidate();
            });
    }
    if (items.empty()) text(c, "NO SOUNDS", 670.0F, 440.0F, 24.0F, NL_MUT, Opt().center().bold());
}

// ---------------------------------------------------------------- SILVETON_GUI_V3 helpers

} // namespace silveton::ui::classic
