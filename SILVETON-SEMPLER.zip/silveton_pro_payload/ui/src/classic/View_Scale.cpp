// Arabic scale editor, separated from LIST for shared LIVE access.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace silveton::ui::classic {

void SilvetonSamplerView::openScalePage() {
    listCancelPasteSelection();
    listStoreMode_ = false;
    listEndMarking();
    flashText.reset();
    sampler.syncScaleFromEngine();
    scaleTonic_ = sampler.scaleTonic();
    scaleLivePc_ = -1;
    scaleOpen_ = true;
    saveOpen_ = false;
    invalidate();
}
void SilvetonSamplerView::closeScalePage() {
    if (scanMode == 2) { sampler.cancelScan(); scanMode = 0; }
    scaleLivePc_ = -1;
    scaleOpen_ = false;
    invalidate();
}

std::string SilvetonSamplerView::scaleTitle() const {
    const std::vector<float> now = sampler.scaleCents();
    bool flat = true;
    for (const float v : now) if (std::fabs(v) > 0.004F) { flat = false; break; }
    if (!sampler.scaleName().empty()) return "SCALE: " + sampler.scaleName();
    return flat ? std::string("SCALE: EQUAL") : std::string("SCALE: SCAN (played notes)");
}

static std::string scaleCentsText(float v) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%+.2f", static_cast<double>(v));
    return buf;
}

void SilvetonSamplerView::showScaleMenu() {
    const int own = sampler.userScaleCount();
    const std::vector<std::string> items = {"MANUAL - EVERY NOTE", "READY-MADE SCALES", "MY SCALES (" + std::to_string(own) + ")",
                                            "SAVE THE CURRENT ONE AS MINE", "DELETE MY SCALE"};
    showItems(scaleTitle(), items, [this, own](int i) {
        if (i == 0) showScaleManual();
        else if (i == 1) showScalePresets();
        else if (i == 2) { if (own == 0) showMessage("MY SCALES", "You have no saved scales yet. Set up a scale and press SAVE THE CURRENT ONE AS MINE."); else showScaleOwn(false); }
        else if (i == 3) {
            showTextPage("NAME OF THE SCALE", sampler.scaleName().empty() ? std::string("MY SCALE") : sampler.scaleName(), [this](const std::string& name) {
                if (sampler.saveUserScale(name)) flash("THE SCALE “" + name + "” IS SAVED");
                else flash("THE SCALE WAS NOT SAVED");
                invalidate();
            });
        } else if (i == 4) { if (own == 0) showMessage("DELETE MY SCALE", "You have no saved scales."); else showScaleOwn(true); }
    }, "CLOSE");
}

void SilvetonSamplerView::showScaleManual() {
    const std::vector<float> now = sampler.scaleCents();
    std::vector<std::pair<std::string, std::string>> items;
    for (int pc = 0; pc < 12; ++pc) items.emplace_back(Ctrl::NOTE_NAMES()[static_cast<std::size_t>(pc)], scaleCentsText(now[static_cast<std::size_t>(pc)]) + " ¢");
    showGridPicker("SCALE - MANUAL: touch a note and tune it (¢ = hundredths of a semitone)", items, -1, std::nullopt, [this, now](int pc) {
        if (pc < 0 || pc > 11) return;
        const std::string name = Ctrl::NOTE_NAMES()[static_cast<std::size_t>(pc)];
        showNumber("NOTE " + name + "  (¢ against equal temperament)", now[static_cast<std::size_t>(pc)], -100.0F, 100.0F, 2, [this, pc](float v) {
            sampler.setScaleNote(pc, v);
            showScaleManual();
        }, false);
    });
}

void SilvetonSamplerView::showScalePresets() {
    std::vector<std::string> names;
    for (const auto& p : Ctrl::scalePresets()) names.push_back(p.name);
    showItems("READY-MADE SCALES", names, [this](int i) {
        if (i == 0) { sampler.setScale(std::vector<float>(12U, 0.0F), Ctrl::scalePresets()[0].name); flash("SCALE: EQUAL"); invalidate(); }
        else showScaleTonic(i);
    }, "BACK");
}

// The ready scales are written with the tonic C; this turns them to the tonic you choose.
void SilvetonSamplerView::showScaleTonic(int preset) {
    if (preset < 0 || preset >= static_cast<int>(Ctrl::scalePresets().size())) return;
    std::vector<std::pair<std::string, std::string>> items;
    for (int pc = 0; pc < 12; ++pc) items.emplace_back(Ctrl::NOTE_NAMES()[static_cast<std::size_t>(pc)], "tonic");
    const std::string pname = Ctrl::scalePresets()[static_cast<std::size_t>(preset)].name;
    showGridPicker(pname + " - WHICH IS THE TONIC?", items, 0, std::nullopt, [this, preset, pname](int tonic) {
        if (tonic < 0 || tonic > 11) return;
        sampler.setScale(Ctrl::scaleTurned(Ctrl::scalePresets()[static_cast<std::size_t>(preset)].cents, tonic),
                         pname + " / " + Ctrl::NOTE_NAMES()[static_cast<std::size_t>(tonic)], tonic);
        flash("SCALE: " + sampler.scaleName());
        invalidate();
    });
}

void SilvetonSamplerView::showScaleOwn(bool deleting) {
    std::vector<std::string> names;
    for (int i = 0; i < sampler.userScaleCount(); ++i) names.push_back(sampler.userScaleName(i));
    showItems(deleting ? "DELETE MY SCALE" : "MY SCALES", names, [this, deleting](int i) {
        if (i < 0 || i >= sampler.userScaleCount()) return;
        const std::string name = sampler.userScaleName(i);
        if (!deleting) {
            if (sampler.useUserScale(i)) flash("SCALE: " + name);
            invalidate();
            return;
        }
        showConfirm("DELETE SCALE", "The scale “" + name + "” will be deleted from your list.", "DELETE", [this, i]() {
            sampler.deleteUserScale(i);
            invalidate();
        });
    }, deleting ? "CANCEL" : "CLOSE");
}

// ---------------------------------------------------------------- SILVETON_SCALE_PAGE_V1 (Цветомир, 04.11.2026): the SCALE page
// Left: the READY-MADE scales (with the little picture of their shape) and the TONIC they are turned to. Middle: ONE OCTAVE OF THE KEYBOARD
// (C ... B): every key shows its tuning (-100.00 ... +100.00 cents against equal temperament); tap a key, then the knob / the step keys / a typed number tune it.
// Right: MY SCALES (tap a row = use it, x = delete) and SAVE AS MINE. It is heard on the Uppers that have Q on.
int SilvetonSamplerView::scaleActivePreset() const {
    const std::string& name = sampler.scaleName();
    const auto& presets = Ctrl::scalePresets();
    for (std::size_t i = 0U; i < presets.size(); ++i) {
        const std::string& pn = presets[i].name;
        if (name == pn || name.rfind(pn + " / ", 0U) == 0U) return static_cast<int>(i);
    }
    return -1;
}

void SilvetonSamplerView::scaleApplyPreset(int i) {
    const auto& presets = Ctrl::scalePresets();
    if (i < 0 || i >= static_cast<int>(presets.size())) return;
    const auto& p = presets[static_cast<std::size_t>(i)];
    if (i == 0) sampler.setScale(std::vector<float>(12U, 0.0F), p.name, scaleTonic_);
    else sampler.setScale(Ctrl::scaleTurned(p.cents, scaleTonic_), p.name + " / " + Ctrl::NOTE_NAMES()[static_cast<std::size_t>(scaleTonic_)], scaleTonic_);
    scaleLivePc_ = -1;
    invalidate();
}

// 12 thin bars, one per note: up = higher than equal temperament, down = lower (100 cents = 16 units)
void SilvetonSamplerView::scaleSpark(Canvas& c, float x, float cy, const std::vector<float>& cents) {
    line(c, x - 2.0F, cy, x + 98.0F, cy, Color::rgb(70, 78, 88), 1.0F);
    for (int k = 0; k < 12; ++k) {
        const float v = k < static_cast<int>(cents.size()) ? cents[static_cast<std::size_t>(k)] : 0.0F;
        const float h = std::clamp(v, -100.0F, 100.0F) * 0.16F;
        const float bx = x + static_cast<float>(k) * 8.0F;
        if (std::fabs(v) < 0.5F) { fill(c, RectF(bx, cy - 1.0F, bx + 5.0F, cy + 1.0F), 0.5F, Color::rgb(110, 118, 128)); continue; }
        fill(c, RectF(bx, std::min(cy, cy - h), bx + 5.0F, std::max(cy, cy - h)), 1.0F, v > 0.0F ? NL_BLUE : NL_AMBER);
    }
}

void SilvetonSamplerView::drawScalePage(Canvas& c) {
    sampler.syncScaleFromEngine();
    scaleTonic_ = sampler.scaleTonic();
    const std::vector<float> cents = sampler.scaleCents();
    const std::string curName = sampler.scaleName();
    const auto& presets = Ctrl::scalePresets();
    const auto& noteNames = Ctrl::NOTE_NAMES();
    bool flat = true;
    for (const float v : cents) if (std::fabs(v) > 0.004F) { flat = false; break; }
    const int activePreset = scaleActivePreset();
    scaleTonic_ = std::clamp(scaleTonic_, 0, 11);

    // Return to the page that opened the editor; tuning remains live.
    const RectF backR(20.0F, 98.0F, 150.0F, 142.0F);
    nlBtn(c, backR, "◀ BACK", NlBtn::Plain, 14.0F, false);
    hit(backR, [this](float, float) { closeScalePage(); });
    const RectF nameR(160.0F, 98.0F, 790.0F, 142.0F);
    nlLcd(c, nameR);
    nlLabel(c, "ARABIC SCALE", nameR.left + 14.0F, nameR.top + 27.0F, false, NL_BLUE, 10.0F);
    text(c, !curName.empty() ? curName : (flat ? std::string("EQUAL") : std::string("CUSTOM")), nameR.left + 130.0F, nameR.top + 30.0F, 20.0F, NL_VALUE,
         Opt().bold().maxW(nameR.width() - 146.0F));
    const RectF onR(802.0F, 98.0F, 1000.0F, 142.0F);
    nlBtn(c, onR, sampler.scaleEnabled() ? "SCALE ON" : "SCALE OFF", sampler.scaleEnabled() ? NlBtn::On : NlBtn::Off, 15.0F, true);
    hit(onR, [this](float, float) { sampler.toggleScaleMaster(); invalidate(); });
    text(c, sampler.hasScaleUppers() ? (sampler.scaleEnabled() ? "ON: selected parts below" : "OFF: tuning and parts retained") : "Choose target parts below",
         1318.0F, 117.0F, 11.0F, sampler.scaleMasterOn() ? NL_TXT2 : NL_AMBER, Opt().right().bold().maxW(310.0F));
    text(c, "WRITE BLEND / SAVE SET keeps this scale", 1318.0F, 136.0F, 10.0F, NL_MUT, Opt().right().maxW(310.0F));

    // ---- left: READY-MADE SCALES and the TONIC
    nlPanel(c, RectF(20.0F, 150.0F, 340.0F, 644.0F), "PRESETS  ·  EDITABLE TUNINGS");
    for (std::size_t i = 0U; i < presets.size(); ++i) {
        const float y = 178.0F + static_cast<float>(i) * 46.0F;
        const RectF rowR(32.0F, y, 328.0F, y + 42.0F);
        const bool on = static_cast<int>(i) == activePreset;
        listCellFace(c, rowR, on ? 2 : 0, false);
        if (isDown(rowR)) fill(c, rowR, 8.0F, Color::argb(60, 0, 0, 0));
        text(c, presets[i].name, rowR.left + 12.0F, y + 26.0F, 14.0F, on ? Color::WHITE : NL_TXT, Opt().bold().maxW(165.0F));
        scaleSpark(c, rowR.right - 108.0F, y + 21.0F, i == 0U ? std::vector<float>(12U, 0.0F) : Ctrl::scaleTurned(presets[i].cents, scaleTonic_));
        hit(rowR, [this, i](float, float) { scaleApplyPreset(static_cast<int>(i)); });
    }
    const float tonicTop = 178.0F + static_cast<float>(presets.size()) * 46.0F + 8.0F;
    nlLabel(c, "TONIC  -  THE READY SCALES ARE TURNED TO IT", 32.0F, tonicTop + 10.0F, false, NL_TXT2, 10.0F);
    for (int pc = 0; pc < 12; ++pc) {
        const float kx = 32.0F + static_cast<float>(pc % 6) * 50.0F;
        const float ky = tonicTop + 20.0F + static_cast<float>(pc / 6) * 46.0F;
        const RectF kr(kx, ky, kx + 46.0F, ky + 40.0F);
        nlBtn(c, kr, noteNames[static_cast<std::size_t>(pc)], pc == scaleTonic_ ? NlBtn::Sel : NlBtn::Plain, 13.0F, false);
        hit(kr, [this, pc](float, float) {
            scaleTonic_ = pc;
            const int ap = scaleActivePreset();
            if (ap >= 1) scaleApplyPreset(ap);
            else sampler.setScale(sampler.scaleCents(), sampler.scaleName(), pc);
            invalidate();
        });
    }

    text(c, "RAST / BAYATI: quarter-tone approximations", 32.0F, 633.0F, 10.0F, NL_MUT, Opt().maxW(296.0F));

    // ---- middle: one octave of the keyboard (C ... B). Every key shows its tuning (a tuner needle and the number); a tap chooses the note,
    // the knob / the step keys / the typed number tune it.
    nlPanel(c, RectF(350.0F, 150.0F, 1010.0F, 644.0F), "TUNING OF EVERY NOTE  ·  CENTS AGAINST EQUAL TEMPERAMENT");
    scaleSel_ = std::clamp(scaleSel_, 0, 11);
    const auto valueOf = [&](int pc) { return pc == scaleLivePc_ ? scaleLiveVal_ : cents[static_cast<std::size_t>(pc)]; };
    const auto signedText = [](float v) {
        char b[24];
        std::snprintf(b, sizeof(b), std::fabs(v) >= 99.995F ? "%+.1f" : "%+.2f", static_cast<double>(v));
        return std::string(b);
    };
    // the tuner needle of a key: the middle tick = equal temperament, right = higher, left = lower (100 cents = 20 units)
    const auto needle = [&](float cx, float cy, float v, ColorInt trackCol) {
        fill(c, RectF(cx - 21.0F, cy - 2.0F, cx + 21.0F, cy + 2.0F), 2.0F, trackCol);
        fill(c, RectF(cx - 0.8F, cy - 7.0F, cx + 0.8F, cy + 7.0F), 0.5F, trackCol);
        const float mx = cx + std::clamp(v, -100.0F, 100.0F) * 0.2F;
        fill(c, RectF(mx - 3.0F, cy - 8.0F, mx + 3.0F, cy + 8.0F), 2.0F, std::fabs(v) < 0.004F ? Color::rgb(120, 128, 138) : (v > 0.0F ? NL_BLUE : NL_AMBER));
    };
    const float kx0 = 372.0F, kw = 88.0F, kTop = 186.0F, kBot = 446.0F, bBot = 340.0F, bw = 52.0F;
    static const int whitePc[7] = {0, 2, 4, 5, 7, 9, 11};
    static const int blackPc[5] = {1, 3, 6, 8, 10};
    static const int blackAfter[5] = {0, 1, 3, 4, 5};   // a black key sits on the line after this white key
    for (int w = 0; w < 7; ++w) {
        const int pc = whitePc[w];
        const bool sel = pc == scaleSel_;
        const float v = valueOf(pc);
        const RectF kr(kx0 + static_cast<float>(w) * kw + 1.0F, kTop, kx0 + static_cast<float>(w + 1) * kw - 1.0F, kBot);
        shadow(c, kr, 5.0F, 3.0F, 110);
        fillV(c, kr, 5.0F, sel ? Color::rgb(168, 214, 255) : Color::rgb(238, 241, 245), sel ? Color::rgb(92, 168, 240) : Color::rgb(203, 208, 216));
        strokeRR(c, kr, 5.0F, Color::rgb(8, 9, 11), 1.0F);
        if (isDown(kr)) fill(c, kr, 5.0F, Color::argb(40, 0, 0, 0));
        needle(kr.centerX(), 366.0F, v, Color::rgb(150, 157, 167));
        text(c, signedText(v), kr.centerX(), 398.0F, 12.0F, std::fabs(v) < 0.004F ? Color::rgb(110, 118, 128) : (v > 0.0F ? Color::rgb(18, 88, 176) : Color::rgb(176, 98, 0)),
             Opt().center().monoBold());
        text(c, noteNames[static_cast<std::size_t>(pc)], kr.centerX(), 432.0F, 20.0F, Color::rgb(28, 31, 36), Opt().center().bold());
        hit(kr, [this, pc](float, float) { scaleSel_ = pc; scaleLivePc_ = -1; invalidate(); });
    }
    for (int b = 0; b < 5; ++b) {
        const int pc = blackPc[b];
        const bool sel = pc == scaleSel_;
        const float v = valueOf(pc);
        const float cx = kx0 + static_cast<float>(blackAfter[b] + 1) * kw;
        const RectF kr(cx - bw / 2.0F, kTop, cx + bw / 2.0F, bBot);
        shadow(c, kr, 5.0F, 4.0F, 170);
        fillV(c, kr, 5.0F, sel ? NL_BLUE : Color::rgb(58, 62, 69), sel ? NL_BLUE_DARK : Color::rgb(14, 16, 19));
        strokeRR(c, kr, 5.0F, Color::rgb(4, 5, 6), 1.0F);
        if (isDown(kr)) fill(c, kr, 5.0F, Color::argb(50, 0, 0, 0));
        needle(cx, 262.0F, v, sel ? Color::rgb(190, 222, 255) : Color::rgb(92, 99, 108));
        text(c, signedText(v), cx, 292.0F, 10.0F, sel ? Color::WHITE : (std::fabs(v) < 0.004F ? Color::rgb(125, 133, 143) : (v > 0.0F ? NL_BLUE : NL_AMBER)),
             Opt().center().monoBold().maxW(bw - 4.0F));
        text(c, noteNames[static_cast<std::size_t>(pc)], cx, 326.0F, 14.0F, Color::rgb(222, 227, 234), Opt().center().bold());
        hit(kr, [this, pc](float, float) { scaleSel_ = pc; scaleLivePc_ = -1; invalidate(); });
    }

    // the chosen note: its number (a tap types it exactly), the knob, the step keys
    const int sp = scaleSel_;
    const float sv = valueOf(sp);
    const std::string selName = noteNames[static_cast<std::size_t>(sp)];
    const std::function<void()> exact = [this, sp, selName, sv]() {
        showNumber("NOTE " + selName + "  (¢ against equal temperament)", sv, -100.0F, 100.0F, 2, [this, sp](float nv) {
            scaleLivePc_ = -1;
            sampler.setScaleNote(sp, nv);
            invalidate();
        }, false);
    };
    const std::function<void()> zero = [this, sp]() { scaleLivePc_ = -1; sampler.setScaleNote(sp, 0.0F); invalidate(); };
    const RectF lcdR(372.0F, 462.0F, 590.0F, 526.0F);
    nlLcd(c, lcdR);
    nlLabel(c, "NOTE " + selName, lcdR.left + 14.0F, lcdR.top + 19.0F, false, NL_BLUE, 11.0F);
    text(c, signedText(sv) + " ¢", lcdR.centerX(), lcdR.top + 52.0F, 26.0F, NL_VALUE, Opt().center().monoBold().maxW(lcdR.width() - 16.0F));
    hit(lcdR, [exact](float, float) { exact(); }, zero);
    const float knobCx = 668.0F, knobCy = 494.0F;
    nlKnob(c, knobCx, knobCy, 24.0F, (std::clamp(sv, -100.0F, 100.0F) + 100.0F) / 200.0F, true, false, true);
    knobHit(RectF(knobCx - 38.0F, knobCy - 36.0F, knobCx + 38.0F, knobCy + 36.0F), sv, -100.0F, 100.0F, 0.1F, 120.0F,
            [this, sp, last = static_cast<std::int64_t>(0)](float nv) mutable {
                scaleLivePc_ = sp;
                scaleLiveVal_ = nv;
                const std::int64_t now = nowMs();
                if (now - last >= 120) { last = now; sampler.setScaleNote(sp, nv); }   // you hear it while you turn
            },
            exact, zero,
            [this, sp](float nv) { sampler.setScaleNote(sp, nv); scaleLivePc_ = -1; invalidate(); });
    const float quickValues[3] = {-50.0F, 0.0F, 50.0F};
    const char* quickNames[3] = {"-50 ¢", "0 ¢", "+50 ¢"};
    for (int i = 0; i < 3; ++i) {
        const float x = 716.0F + static_cast<float>(i) * 94.0F;
        const RectF quick(x, 470.0F, x + 86.0F, 518.0F);
        nlBtn(c, quick, quickNames[i], std::fabs(sv - quickValues[i]) < 0.005F ? NlBtn::Sel : NlBtn::Plain, 14.0F, false);
        const float value = quickValues[i];
        hit(quick, [this, sp, value](float, float) { sampler.setScaleNote(sp, value); scaleLivePc_ = -1; invalidate(); });
    }
    static const float stepVal[6] = {-1.0F, -0.1F, -0.01F, 0.01F, 0.1F, 1.0F};
    for (int k = 0; k < 6; ++k) {
        const RectF sr(372.0F + static_cast<float>(k) * 103.0F, 540.0F, 372.0F + static_cast<float>(k) * 103.0F + 98.0F, 584.0F);
        char lab[16];
        std::snprintf(lab, sizeof(lab), "%+.2f", static_cast<double>(stepVal[k]));
        nlBtn(c, sr, lab, NlBtn::Plain, 14.0F, false);
        hit(sr, [this, sp, sv, k](float, float) {
            sampler.setScaleNote(sp, quantizeControl(sv + stepVal[k], -100.0F, 100.0F, 0.01F));
            scaleLivePc_ = -1;
            invalidate();
        });
    }
    const ColorInt hintC = Color::rgb(138, 147, 157);
    text(c, "1. Choose a key   2. Set cents   3. Choose parts below   4. SCALE ON", 372.0F, 606.0F, 11.0F, hintC, Opt().spacing(0.02F).maxW(626.0F));
    text(c, "Tuning follows the played key in every octave; TRANSPOSE keeps the same keys.", 372.0F, 624.0F, 11.0F, hintC,
         Opt().spacing(0.02F).maxW(626.0F));

    // ---- right: MY SCALES
    const int own = sampler.userScaleCount();
    nlPanel(c, RectF(1020.0F, 150.0F, 1320.0F, 644.0F), "MY SCALES  (" + std::to_string(own) + ")");
    const int visibleRows = 5;
    scaleOwnTop_ = std::clamp(scaleOwnTop_, 0, std::max(0, own - visibleRows));
    if (own == 0) {
        text(c, "no saved scales yet", 1034.0F, 206.0F, 13.0F, NL_MUT, Opt().bold());
        text(c, "tune the notes or take a ready scale,", 1034.0F, 228.0F, 11.0F, NL_MUT, Opt().maxW(270.0F));
        text(c, "then press SAVE AS MINE", 1034.0F, 244.0F, 11.0F, NL_MUT, Opt().maxW(270.0F));
    }
    for (int k = 0; k < visibleRows; ++k) {
        const int i = scaleOwnTop_ + k;
        if (i >= own) break;
        const float y = 178.0F + static_cast<float>(k) * 46.0F;
        const RectF rowR(1032.0F, y, 1308.0F, y + 42.0F);
        const std::string name = sampler.userScaleName(i);
        const bool on = !curName.empty() && curName == name;
        listCellFace(c, rowR, on ? 2 : 0, false);
        if (isDown(rowR)) fill(c, rowR, 8.0F, Color::argb(60, 0, 0, 0));
        text(c, name, rowR.left + 12.0F, y + 26.0F, 14.0F, on ? Color::WHITE : NL_TXT, Opt().bold().maxW(110.0F));
        scaleSpark(c, rowR.left + 130.0F, y + 21.0F, sampler.userScaleCents(i));
        hit(rowR, [this, i](float, float) { if (sampler.useUserScale(i)) { scaleLivePc_ = -1; invalidate(); } });
        const RectF delR(rowR.right - 42.0F, y + 6.0F, rowR.right - 6.0F, y + 36.0F);
        nlBtn(c, delR, "×", NlBtn::Plain, 18.0F, false);
        hit(delR, [this, i, name](float, float) {
            showConfirm("DELETE SCALE", "The scale “" + name + "” will be deleted from your list.", "DELETE", [this, i]() {
                sampler.deleteUserScale(i);
                invalidate();
            });
        });
    }
    if (own > visibleRows) {
        const RectF upR(1032.0F, 414.0F, 1164.0F, 450.0F);
        const RectF dnR(1176.0F, 414.0F, 1308.0F, 450.0F);
        nlBtn(c, upR, "▲", scaleOwnTop_ > 0 ? NlBtn::Plain : NlBtn::Off, 13.0F, false);
        nlBtn(c, dnR, "▼", scaleOwnTop_ < own - visibleRows ? NlBtn::Plain : NlBtn::Off, 13.0F, false);
        hit(upR, [this](float, float) { scaleOwnTop_ = std::max(0, scaleOwnTop_ - 1); invalidate(); });
        hit(dnR, [this](float, float) { ++scaleOwnTop_; invalidate(); });
    }
    const RectF saveR(1032.0F, 470.0F, 1308.0F, 526.0F);
    nlBtn(c, saveR, "SAVE AS MINE", NlBtn::Sel, 16.0F, true);
    hit(saveR, [this](float, float) {
        const std::string cur = sampler.scaleName();
        showTextPage("NAME OF THE SCALE", cur.empty() || cur == "MANUAL" ? std::string("MY SCALE") : cur, [this](const std::string& name) {
            if (sampler.saveUserScale(name)) flash("THE SCALE “" + name + "” IS SAVED");
            else flash("THE SCALE WAS NOT SAVED");
            invalidate();
        });
    });
    const RectF resetR(1032.0F, 540.0F, 1164.0F, 584.0F);
    const RectF scanR(1176.0F, 540.0F, 1308.0F, 584.0F);
    nlBtn(c, resetR, "RESET ALL", NlBtn::Plain, 12.0F, false);
    hit(resetR, [this](float, float) {
        showConfirm("RESET SCALE", "Set all 12 notes to equal temperament? Target parts are retained.", "RESET", [this] {
            sampler.setScale(std::vector<float>(12U, 0.0F), "EQUAL", sampler.scaleTonic());
            scaleLivePc_ = -1; invalidate();
        });
    });
    nlBtn(c, scanR, scanMode == 2 ? "STOP SCAN" : "SCAN -50 ¢", scanMode == 2 ? NlBtn::On : NlBtn::Plain, 12.0F, false);
    hit(scanR, [this](float, float) {
        if (scanMode == 2) { sampler.cancelScan(); scanMode = 0; }
        else { sampler.startScaleScan(); scanMode = 2; }
        invalidate();
    });
    text(c, scanMode == 2 ? "Play and release keys: lowers them by 50 ¢" : "Save a tuning here; save a blend with WRITE.", 1034.0F, 608.0F, 10.0F, NL_TXT2, Opt().maxW(274.0F));
    text(c, "SCAN adds -50 ¢ to the selected played keys.", 1034.0F, 628.0F, 10.0F, NL_MUT, Opt().maxW(274.0F));

    // Assignment is independent of bypass: choosing a part never enables the
    // master unexpectedly. Existing SYNTH place assignments remain accessible.
    const int targetCount = scaleEngineTargets_ ? 8 : 7;
    const float targetStep = 1160.0F / static_cast<float>(targetCount);
    for (int i = 0; i < targetCount; ++i) {
        const int part = scaleEngineTargets_ ? i + 7 : i;
        const bool selected = sampler.quarterChosen(part);
        const float x = 20.0F + static_cast<float>(i) * targetStep;
        const RectF targetR(x, 652.0F, x + targetStep - 10.0F, 696.0F);
        const std::string label = scaleEngineTargets_ ? "SYNTH " + std::to_string(i + 1) : (i == 6 ? "LOWER" : "UPPER " + std::to_string(i + 1));
        nlBtn(c, targetR, label, selected ? NlBtn::On : NlBtn::Off, 13.0F, true);
        hit(targetR, [this, part](float, float) { sampler.setScaleTarget(part, !sampler.quarterChosen(part)); invalidate(); });
    }
    const RectF targetPage(1182.0F, 652.0F, 1320.0F, 696.0F);
    nlBtn(c, targetPage, scaleEngineTargets_ ? "UPPERS >" : "SYNTH >", NlBtn::Plain, 13.0F, false);
    hit(targetPage, [this](float, float) { scaleEngineTargets_ = !scaleEngineTargets_; invalidate(); });

}


} // namespace silveton::ui::classic
