#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
bool isSetName(const std::string& name) {
    const auto upper=utf8Upper(name);
    return upper.size()>=6U&&upper.compare(upper.size()-6U,6U,".SVSET")==0;
}
constexpr int kImportRows=6;
constexpr int kImportDestinations=18;
}

void SilvetonSamplerView::openSetImport() {
    listEndMarking();
    listPasteMode_=false;
    listStoreMode_=false;
    setImport_=std::make_shared<SetImportState>();
    setImport_->destination=std::clamp(listSelected,0,LIST_SIZE-1);
    setImportReadDirectory(sampler.setsFolders());
    invalidate();
}

void SilvetonSamplerView::setImportBack() {
    if(!setImport_)return;
    auto& state=*setImport_;
    using Stage=SetImportState::Stage;
    state.error.clear();state.paintMode=-1;
    if(state.stage==Stage::Files)setImport_.reset();
    else if(state.stage==Stage::Blends){state.stage=Stage::Files;state.page=0;}
    else if(state.stage==Stage::Destination){state.stage=Stage::Blends;state.page=0;}
    else {state.stage=Stage::Destination;state.page=state.destination/kImportDestinations;}
    invalidate();
}

void SilvetonSamplerView::setImportReadDirectory(const std::string& directory) {
    if(!setImport_)return;
    auto& state=*setImport_;
    state.directory=files::absolute(directory);
    state.stage=SetImportState::Stage::Files;
    state.page=0;state.fileSelected=-1;state.entries.clear();state.error.clear();
    if(!files::isDirectory(state.directory)||!files::readable(state.directory)) {
        state.error="Няма достъп до тази папка.";invalidate();return;
    }
    for(const auto& name:files::listNames(state.directory)) {
        if(name.empty()||name[0]=='.')continue;
        const auto upper=utf8Upper(name);
        if(upper=="SILVETON_BLENDS.SVSET"||upper=="SILVETON_USER_STATE.SVSET")continue;
        const auto path=files::join(state.directory,name);
        const bool directoryEntry=files::isDirectory(path);
        if(isSetName(name)) {
            if(files::isFile(path)||(directoryEntry&&files::isFile(files::join(path,"manifest.svs"))))
                state.entries.push_back({name,path,false});
        } else if(directoryEntry) state.entries.push_back({name,path,true});
    }
    std::sort(state.entries.begin(),state.entries.end(),[](const SetImportState::Entry&a,const SetImportState::Entry&b){
        if(a.folder!=b.folder)return a.folder;
        return utf8Upper(a.name)<utf8Upper(b.name);
    });
    invalidate();
}

void SilvetonSamplerView::setImportOpenFile(const std::string& path) {
    const auto state=setImport_;
    if(!state)return;
    showWait("ОТВАРЯНЕ НА SET",files::nameOf(path),[this,state,path]() -> std::function<void()> {
        const auto catalog=std::make_shared<Ctrl::ListClipboard>();
        const bool opened=sampler.readSetBlends(path,*catalog);
        const std::string error=opened?std::string():failureText(sampler.lastFailure());
        return [this,state,path,catalog,opened,error] {
            if(setImport_!=state)return;
            if(!opened) {
                state->error=error;
                showMessage("SET НЕ Е ОТВОРЕН",error);return;
            }
            state->sourcePath=path;state->catalog=std::move(*catalog);state->selected.clear();
            state->stage=SetImportState::Stage::Blends;state->page=0;state->paintMode=-1;state->error.clear();
            invalidate();
        };
    });
}

void SilvetonSamplerView::setImportChooseDestination() {
    if(!setImport_)return;
    auto& state=*setImport_;
    if(state.selected.empty()) {state.error="Избери поне една бленда.";invalidate();return;}
    if(state.selected.size()>static_cast<std::size_t>(LIST_SIZE)) {state.error="Можеш да внесеш до 200 бленди наведнъж.";invalidate();return;}
    state.destination=std::clamp(state.destination,0,LIST_SIZE-static_cast<int>(state.selected.size()));
    state.stage=SetImportState::Stage::Destination;state.page=state.destination/kImportDestinations;state.error.clear();
    invalidate();
}

void SilvetonSamplerView::setImportApply() {
    const auto state=setImport_;
    if(!state)return;
    const std::vector<int> selected(state->selected.begin(),state->selected.end());
    int first=-1;
    if(!sampler.importSetBlends(state->catalog,selected,state->destination,first)) {
        state->error=failureText(sampler.lastFailure());
        showMessage("БЛЕНДИТЕ НЕ СА ВНЕСЕНИ",state->error);return;
    }
    setImport_.reset();
    refreshListCache();listFavs=sampler.listFavourites();
    loadedFromList=cachedActiveListEntry;listFollowedActive=cachedActiveListEntry;
    listSelected=first;listPage=std::clamp(first/LIST_PER_PAGE,0,LIST_PAGES-1);
    flash("ВНЕСЕНИ "+std::to_string(selected.size())+" · ПОЗИЦИЯ "+fmtZeroPad(first+1,3));
    invalidate();
}

void SilvetonSamplerView::drawSetImport(Canvas& c) {
    const auto state=setImport_;
    if(!state)return;
    using Stage=SetImportState::Stage;
    const auto stage=state->stage;
    const RectF back(20,98,180,158),cancel(1110,98,1320,158);
    nlBtn(c,back,"◀ НАЗАД",NlBtn::Plain,15,true);
    hit(back,[this](float,float){setImportBack();});
    nlBtn(c,cancel,"ОТКАЗ",NlBtn::Plain,16,true);
    hit(cancel,[this](float,float){setImport_.reset();invalidate();});
    const char* title=stage==Stage::Files?"1 · ОТВОРИ ДРУГ SET":stage==Stage::Blends?"2 · ИЗБЕРИ БЛЕНДИ":stage==Stage::Destination?"3 · ИЗБЕРИ МЯСТО":"4 · ВНЕСИ В ТЕКУЩИЯ SET";
    text(c,title,202,135,22,NL_VALUE,Opt().bold().maxW(880));
    nlLcd(c,RectF(20,170,1320,226));
    text(c,stage==Stage::Files?state->directory:files::nameOf(state->sourcePath),36,205,16,NL_BLUE,Opt().maxW(1268));

    if(stage==Stage::Confirm) {
        nlPanel(c,RectF(20,242,1020,648),"ИЗБРАНИТЕ БЛЕНДИ",true);
        text(c,"В текущия списък от позиция "+fmtZeroPad(state->destination+1,3),44,293,23,NL_VALUE,Opt().bold().maxW(940));
        int row=0;
        for(const int index:state->selected) {
            if(row>=5)break;
            if(index<0||index>=static_cast<int>(state->catalog.items.size()))continue;
            text(c,fmtZeroPad(state->destination+row+1,3)+"  "+state->catalog.items[static_cast<std::size_t>(index)].name,
                 44,342+row*48.F,19,NL_TXT,Opt().bold().maxW(940));
            ++row;
        }
        if(state->selected.size()>5U)text(c,"… и още "+std::to_string(state->selected.size()-5U),44,594,16,NL_TXT2);
        text(c,"Заетите позиции ще се изместят. Останалите бленди се запазват.",44,626,14,NL_TXT2,Opt().maxW(940));
        nlPanel(c,RectF(1040,242,1320,648));
        text(c,std::to_string(state->selected.size()),1180,322,42,NL_VALUE,Opt().center().monoBold());
        text(c,"бленди за внасяне",1180,356,16,NL_TXT2,Opt().center().maxW(240));
        const RectF load(1056,560,1304,632);
        nlBtn(c,load,"ВНЕСИ",NlBtn::On,21,true);
        hit(load,[this](float,float){setImportApply();});
    } else {
        const bool filesStage=stage==Stage::Files;
        const bool destinationStage=stage==Stage::Destination;
        const int perPage=destinationStage?kImportDestinations:kImportRows;
        const int count=filesStage?static_cast<int>(state->entries.size()):destinationStage?LIST_SIZE:static_cast<int>(state->catalog.items.size());
        const int pages=std::max(1,(count+perPage-1)/perPage);
        state->page=std::clamp(state->page,0,pages-1);
        if(count==0)text(c,filesStage?"В тази папка няма SET файлове.":"В този SET няма бленди.",40,294,20,NL_TXT2,Opt().maxW(940));
        for(int k=0;k<perPage;++k) {
            const int index=state->page*perPage+k;
            if(index>=count)break;
            RectF row;
            if(destinationStage) {
                constexpr float width=(1000.F-24.F)/3.F;
                row=RectF(20+(k%3)*(width+12),242+(k/3)*64.F,20+(k%3)*(width+12)+width,300+(k/3)*64.F);
            } else row=RectF(20,242+k*64.F,1020,300+k*64.F);
            bool chosen=false;
            std::string line1,line2;
            if(filesStage) {
                const auto& entry=state->entries[static_cast<std::size_t>(index)];
                chosen=state->fileSelected==index;line1=entry.folder?"ПАПКА":"SET";line2=entry.name;
            } else if(destinationStage) {
                const auto item=realListItem(index);chosen=state->destination==index;
                line1="ПОЗИЦИЯ "+fmtZeroPad(index+1,3);line2=item?item->name:"Свободно място";
            } else {
                chosen=state->selected.count(index)!=0U;
                const int original=index<static_cast<int>(state->catalog.sources.size())?state->catalog.sources[static_cast<std::size_t>(index)]:index;
                line1=fmtZeroPad(original+1,3);
                line2=state->catalog.items[static_cast<std::size_t>(index)].name;
            }
            nlBtn(c,row,"",chosen?NlBtn::Sel:NlBtn::Plain,15,false);
            const bool sourceRow=!filesStage&&!destinationStage;
            const float inset=sourceRow?54.F:18.F;
            if(sourceRow){
                const RectF check(row.left+16,row.top+17,row.left+40,row.top+41);
                fill(c,check,4,chosen?NL_AMBER:Color::rgb(20,24,30));
                strokeRR(c,check,4,chosen?NL_AMBER:NL_TXT2,1);
                if(chosen){const auto ink=Color::rgb(24,24,24);line(c,check.left+5,check.top+12,check.left+10,check.top+17,ink,3);line(c,check.left+10,check.top+17,check.left+19,check.top+7,ink,3);}
            }
            text(c,line1,row.left+inset,row.top+20,12,chosen?Color::WHITE:NL_BLUE,Opt().bold().maxW(row.width()-inset-18));
            text(c,line2,row.left+inset,row.top+44,18,chosen?Color::WHITE:NL_VALUE,Opt().bold().maxW(row.width()-inset-18));
            const auto toggle=[this,state,index]{
                if(state->selected.count(index))state->selected.erase(index);else state->selected.insert(index);
                state->error.clear();invalidate();
            };
            if(filesStage)hit(row,[this,state,index](float,float){state->fileSelected=index;state->error.clear();invalidate();});
            else if(destinationStage)hit(row,[this,state,index](float,float){state->destination=index;state->error.clear();invalidate();});
            else hit(row,[toggle](float,float){toggle();},nullptr,[this,state,index,toggle](float,float y,bool final){
                if(!dragMoved){if(final)toggle();state->paintMode=-1;return;}
                if(state->paintMode<0)state->paintMode=state->selected.count(index)?0:1;
                const int local=std::clamp(static_cast<int>(std::floor((y-242.F)/64.F)),0,kImportRows-1);
                const int end=std::min(static_cast<int>(state->catalog.items.size())-1,state->page*kImportRows+local);
                for(int selected=std::min(index,end);selected<=std::max(index,end);++selected) {
                    if(state->paintMode)state->selected.insert(selected);else state->selected.erase(selected);
                }
                if(final)state->paintMode=-1;
                invalidate();
            });
        }
        if(pages>1) {
            const RectF prev(1040,324,1174,384),next(1186,324,1320,384);
            nlBtn(c,prev,"◀",state->page>0?NlBtn::Plain:NlBtn::Off,24,false);
            nlBtn(c,next,"▶",state->page+1<pages?NlBtn::Plain:NlBtn::Off,24,false);
            if(state->page>0)hit(prev,[this,state](float,float){--state->page;invalidate();});
            if(state->page+1<pages)hit(next,[this,state](float,float){++state->page;invalidate();});
        }
        text(c,"Страница "+std::to_string(state->page+1)+" / "+std::to_string(pages),1180,413,15,NL_TXT2,Opt().center());
        if(filesStage) {
            const RectF up(1040,242,1320,302);
            const auto parent=files::parentOf(state->directory);
            const bool canGoUp=!parent.empty()&&parent!=state->directory;
            nlBtn(c,up,"↑ НАГОРЕ",canGoUp?NlBtn::Plain:NlBtn::Off,16,true);
            if(canGoUp)hit(up,[this,parent](float,float){setImportReadDirectory(parent);});
            const bool picked=state->fileSelected>=0&&state->fileSelected<count;
            const RectF open(1040,566,1320,638);
            nlBtn(c,open,"ОТВОРИ",picked?NlBtn::On:NlBtn::Off,20,true);
            if(picked)hit(open,[this,state](float,float){
                const auto entry=state->entries[static_cast<std::size_t>(state->fileSelected)];
                if(entry.folder)setImportReadDirectory(entry.path);else setImportOpenFile(entry.path);
            });
        } else if(!destinationStage) {
            text(c,"Избрани: "+std::to_string(state->selected.size()),1180,282,18,NL_VALUE,Opt().center().bold());
            const RectF all(1040,450,1320,510);
            nlBtn(c,all,"ИЗБЕРИ ВСИЧКИ",NlBtn::Plain,14,true);
            hit(all,[this,state,count](float,float){
                if(count>LIST_SIZE){state->error="Избери до 200 бленди.";invalidate();return;}
                if(state->selected.size()==static_cast<std::size_t>(count))state->selected.clear();
                else {state->selected.clear();for(int k=0;k<count;++k)state->selected.insert(k);}
                invalidate();
            });
            const RectF target(1040,566,1320,638);
            nlBtn(c,target,"ИЗБЕРИ МЯСТО",state->selected.empty()?NlBtn::Off:NlBtn::On,16,true);
            if(!state->selected.empty())hit(target,[this](float,float){setImportChooseDestination();});
        } else {
            text(c,"Начало: "+fmtZeroPad(state->destination+1,3),1180,282,18,NL_VALUE,Opt().center().bold());
            const RectF position(1040,450,1320,510);
            nlBtn(c,position,"ВЪВЕДИ ПОЗИЦИЯ",NlBtn::Plain,14,true);
            hit(position,[this,state](float,float){
                const int maximum=LIST_SIZE-static_cast<int>(state->selected.size())+1;
                showNumber("ПОЗИЦИЯ В СПИСЪКА",static_cast<float>(state->destination+1),1,static_cast<float>(maximum),0,[this,state,maximum](float number){
                    state->destination=std::clamp(static_cast<int>(std::nearbyint(number))-1,0,maximum-1);
                    state->page=state->destination/kImportDestinations;invalidate();
                },false);
            });
            const RectF proceed(1040,566,1320,638);
            nlBtn(c,proceed,"ПРОДЪЛЖИ",NlBtn::On,18,true);
            hit(proceed,[this,state](float,float){
                const int maximum=LIST_SIZE-static_cast<int>(state->selected.size());
                if(state->destination>maximum){state->error="Избраните бленди не се побират от тази позиция.";invalidate();return;}
                state->stage=Stage::Confirm;state->error.clear();invalidate();
            });
        }
    }
    const std::string hint=!state->error.empty()?state->error:
        stage==Stage::Files?"Избери папка или SET и натисни ОТВОРИ.":
        stage==Stage::Blends?"Докосни или плъзни по блендите, които искаш да внесеш.":
        stage==Stage::Destination?"Избери начална позиция. Заетите бленди ще се изместят.":"Внасят се само избраните бленди.";
    text(c,hint,20,682,14,state->error.empty()?NL_TXT2:NL_AMBER,Opt().maxW(1290));
}

} // namespace silveton::ui::classic
