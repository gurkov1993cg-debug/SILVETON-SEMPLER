// SILVETON_MAC_VIEW_V1 - the SETTINGS page (tablet SilvetonSamplerView.kt lines 2723-2928 and 3388-3470)
// SILVETON_NEW_LOOK_V1: the approved new look (gui/png sets_general, sets_midi, sets_info, sets_set, pedal_cal): tabs GENERAL, MIDI, INFO, SET
// and the calibration screen of the expression pedal. The page always uses the dark keys and panels of the new look.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
int roundToInt(float v) { return static_cast<int>(std::nearbyint(v)); }   // Kotlin round(x).toInt()
// SILVETON_NEW_LOOK_V1: colours of the pictures that the common look has no name for
constexpr ColorInt kHint = Color::rgb(138, 147, 157);       // the grey help text under the controls
constexpr ColorInt kSoft = Color::rgb(207, 214, 222);       // quiet text on a panel
constexpr ColorInt kLitText = Color::rgb(255, 177, 58);     // the text of a lit key
constexpr ColorInt kLcdAmber = Color::rgb(255, 208, 138);   // the title inside a display
constexpr ColorInt kLive = Color::rgb(143, 208, 255);       // the live number of the pedal
// the baseline of a text that starts at `top` in the picture (HTML top + font size * 0.945)
constexpr float tb(float top, float fs) { return top + fs * 0.945F; }
// SILVETON_SET_MENU_V1 (Цветомир, 03.11.2026): "меню в самите настройки" - the fourth tab SET (picture sets_set) is shown again: one file, no samples.
// SAVE SET and LOAD SET are only here (Цветомир, 04.11.2026: "не искам да е в лист а само в настройки").
constexpr bool kShowSetTab = true;
} // namespace

// ---------------------------------------------------------------------------------------------- small helpers of the page
// SILVETON_NEW_LOOK_V1: a dark key; mode 0 = plain, 1 = off (dim), 2 = lit (amber text and an amber lamp bar); sub = the small second line
void SilvetonSamplerView::stgKey(Canvas& c, const RectF& r, const std::string& label, const std::string& sub, int mode, float size, bool lamp, float spacing) {
    nlBtn(c, r, "", mode == 1 ? NlBtn::Off : NlBtn::Plain, size, lamp && mode != 2);
    if (mode == 2 && lamp && r.height() >= 30.0F) {
        const float lw = std::min(24.0F, r.width() * 0.5F);
        fill(c, RectF(r.centerX() - lw / 2.0F - 2.0F, r.top + 3.0F, r.centerX() + lw / 2.0F + 2.0F, r.top + 10.0F), 3.5F, colorWithAlpha(NL_AMBER, 46));
        fill(c, RectF(r.centerX() - lw / 2.0F, r.top + 5.0F, r.centerX() + lw / 2.0F, r.top + 8.0F), 1.5F, NL_AMBER);
    }
    const ColorInt col = mode == 2 ? kLitText : (mode == 1 ? Color::rgb(121, 130, 140) : Color::rgb(179, 187, 196));
    const float inner = r.width() - 12.0F;
    if (sub.empty()) {
        text(c, label, r.centerX(), r.centerY() + size * 0.36F, size, col, Opt().center().bold().spacing(spacing).maxW(inner));
        return;
    }
    const float total = size * 1.15F + 12.1F;
    const float top = r.centerY() - total / 2.0F;
    text(c, label, r.centerX(), top + size * 0.935F, size, col, Opt().center().bold().spacing(spacing).maxW(inner));
    text(c, sub, r.centerX(), top + size * 1.15F + 9.85F, 10.5F, colorWithAlpha(col, 205), Opt().center().spacing(0.06F).maxW(inner));
}

void SilvetonSamplerView::stgCell(Canvas& c, const RectF& r, const std::string& label, const std::string& value, int mode, float size, bool lamp, float spacing,
                                  std::function<void()> tap) {
    stgKey(c, r, label, value, mode, size, lamp, spacing);
    hit(r, [this, tap](float, float) { tap(); invalidate(); });
}

void SilvetonSamplerView::stgKnob(Canvas& c, float cx, float cy, float d, float value, float minV, float maxV, float step, float travel, bool bipolar,
                                  const std::string& valueText, const std::string& label, float vw, float hitW,
                                  std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset) {
    const float t = maxV > minV ? std::clamp((value - minV) / (maxV - minV), 0.0F, 1.0F) : 0.0F;
    nlKnob(c, cx, cy, d * 0.32F, t, bipolar, false, true);
    nlLabel(c, label, cx, cy - d / 2.0F - 3.5F, true, NL_TXT2, 11.0F);
    const RectF vb(cx - vw / 2.0F, cy + d / 2.0F - 2.0F, cx + vw / 2.0F, cy + d / 2.0F + 20.0F);
    nlValue(c, vb, valueText, 12.0F);
    knobHit(RectF(cx - hitW / 2.0F, cy - d / 2.0F - 16.0F, cx + hitW / 2.0F, cy + d / 2.0F - 2.0F), value, minV, maxV, step, travel, onChange, exact, reset);
    hit(RectF(cx - hitW / 2.0F, vb.top, cx + hitW / 2.0F, vb.bottom + 8.0F), [exact](float, float) { exact(); }, reset);
}

// ---------------------------------------------------------------------------------------------- the page
void SilvetonSamplerView::drawSettings(Canvas& c) {
    const std::int64_t now = nowMs();
    if (now - settingsLastDrawMs_ > 1000) { pedalCalOpen_ = false; setsListDirty_ = true; }   // SILVETON_NEW_LOOK_V1: the page was left and is entered again
    settingsLastDrawMs_ = now;
    if (settingsTab != 1) pedalCalOpen_ = false;   // SILVETON_PEDAL_CAL_V1: the calibration page lives on the MIDI tab only
    if (pedalCalOpen_) {   // the calibration screen has no tabs (picture pedal_cal)
        std::optional<GlobalUiState> gOpt = globalState;
        if (!gOpt) { gOpt = sampler.globalUiState(); if (gOpt) globalState = gOpt; }
        const std::optional<Ctrl::GlobalAdvanced> aOpt = sampler.globalAdvanced();
        if (gOpt && aOpt) { drawPedalCalibration(c, *gOpt, *aOpt); return; }
        pedalCalOpen_ = false;
    }
    // SILVETON_LOGIC_V1: GENERAL / MIDI / INFO (what is in the bank) / SET (save and load the whole set; its tab is hidden, see kShowSetTab)
    static const char* const tabs[] = {"GENERAL", "MIDI", "INFO", "SET"};
    const int tabCount = kShowSetTab ? 4 : 3;
    if (settingsTab < 0 || settingsTab >= tabCount) settingsTab = 0;
    for (int t = 0; t < tabCount; ++t) {
        const float ft = static_cast<float>(t);
        const RectF tr(20.0F + ft * 306.0F, 98.0F, 320.0F + ft * 306.0F, 138.0F);
        nlBtn(c, tr, tabs[t], settingsTab == t ? NlBtn::Sel : NlBtn::Off, 13.0F);
        hit(tr, [this, t](float, float) {
            settingsTab = t;
            if (t == 2) bankInfoCache = sampler.bankInfo();
            if (t == 3) setsListDirty_ = true;
        });
    }
    switch (settingsTab) {
        case 1: drawMidiSettings(c); break;
        case 2: drawBankInfo(c); break;
        case 3: drawSetSettings(c); break;
        default: drawGeneralSettings(c); break;
    }
}

/** SILVETON_NEW_LOOK_V1: GENERAL - tuning and level, the global EQ, the voices, the MIDI controllers, the language and the theme. */
void SilvetonSamplerView::drawGeneralSettings(Canvas& c) {
    std::optional<GlobalUiState> gOpt = globalState;
    if (!gOpt) { gOpt = sampler.globalUiState(); if (gOpt) globalState = gOpt; }
    if (!gOpt) return;
    const GlobalUiState g = *gOpt;
    // one knob of the global settings: the same drag, number and default as the old page (i = the old number of the setting)
    const auto knob = [&](int i, float cx, float cy, bool bip, float vw, float hitW, const char* label) {
        const std::array<float, 3> spec = globalSliderSpec(i, g);
        stgKnob(c, cx, cy, 64.0F, spec[0], spec[1], spec[2], globalStep(i), globalTravel(i), bip, globalValueText(i, g), label, vw, hitW,
                [this, i, g](float nv) { commitGlobal(globalWithSliderValue(i, globalState ? *globalState : g, nv)); },
                [this, i, g]() { editGlobal(i, globalState ? *globalState : g); },
                [this, i, g]() { resetGlobal(i, globalState ? *globalState : g); });
    };

    // TUNING · LEVEL
    nlPanel(c, RectF(20.0F, 146.0F, 520.0F, 312.0F), "TUNING · LEVEL");
    knob(0, 100.0F, 232.0F, true, 96.0F, 150.0F, "MASTER TUNE");
    knob(1, 260.0F, 232.0F, true, 96.0F, 150.0F, "TRANSPOSE");
    knob(2, 420.0F, 232.0F, false, 96.0F, 150.0F, "MASTER GAIN");
    // GLOBAL EQ
    nlPanel(c, RectF(530.0F, 146.0F, 880.0F, 312.0F), "GLOBAL EQ");
    knob(3, 590.0F, 232.0F, true, 84.0F, 104.0F, "EQ LOW");
    knob(4, 700.0F, 232.0F, true, 84.0F, 104.0F, "EQ MID");
    knob(5, 810.0F, 232.0F, true, 84.0F, 104.0F, "EQ HIGH");

    // The switch and ceiling control the optional master peak limiter.
    nlPanel(c, RectF(890.0F, 146.0F, 1320.0F, 312.0F), "LIMITER");
    const RectF limR(906.0F, 190.0F, 1106.0F, 246.0F);
    stgKey(c, limR, "LIMITER", g.limiterEnabled ? "ON" : "OFF", g.limiterEnabled ? 2 : 1, 12.0F, true, 0.05F);
    hit(limR, [this, g](float, float) { editGlobal(6, g); }, [this, g]() { resetGlobal(6, g); });
    text(c, "tap to switch on / off", 906.0F, tb(264.0F, 11.0F), 11.0F, kHint, Opt().maxW(190.0F));
    knob(7, 1180.0F, 232.0F, false, 90.0F, 130.0F, "CEILING");

    // CONTROLLERS · MIDI MESSAGES
    nlPanel(c, RectF(20.0F, 320.0F, 1030.0F, 486.0F), "CONTROLLERS · MIDI MESSAGES");
    knob(8, 100.0F, 406.0F, false, 94.0F, 140.0F, "VELOCITY CURVE");
    knob(9, 250.0F, 406.0F, false, 94.0F, 140.0F, "BREATH CC");
    knob(10, 400.0F, 406.0F, false, 94.0F, 140.0F, "EXPRESSION CC");
    knob(11, 550.0F, 406.0F, false, 94.0F, 140.0F, "DAMPER CC");
    for (int k = 0; k < 2; ++k) {   // PITCH BEND / AFTERTOUCH: on or off (double tap = on again)
        const int i = 12 + k;
        const bool on = k == 0 ? g.pitchBendEnabled : g.aftertouchEnabled;
        const RectF key(700.0F + static_cast<float>(k) * 160.0F, 358.0F, 850.0F + static_cast<float>(k) * 160.0F, 414.0F);
        stgKey(c, key, k == 0 ? "PITCH BEND" : "AFTERTOUCH", on ? "ON" : "OFF", on ? 2 : 1, 12.0F, true, 0.05F);
        hit(key, [this, i, g](float, float) { editGlobal(i, g); }, [this, i, g]() { resetGlobal(i, g); });
    }
    text(c, "all per-UPPER controller keys are on SOUND EDIT › MIDI CONTROL", 700.0F, tb(433.0F, 11.0F), 11.0F, kHint, Opt().maxW(326.0F));

    // VOICES: how many notes may sound at once (SILVETON_VOICE_CEILING_V1)
    const RectF vp(1040.0F, 320.0F, 1320.0F, 486.0F);
    nlPanel(c, vp, "VOICES");
    const int ceiling = sampler.voiceCeiling();
    stgKey(c, RectF(1056.0F, 360.0F, 1304.0F, 444.0F), ceiling >= 128 ? std::string("ALL") : std::to_string(ceiling), "maximum voices", ceiling < 128 ? 2 : 0, 18.0F, true, 0.05F);
    hit(vp, [this, ceiling](float, float) {
            showNumber("MAXIMUM VOICES", static_cast<float>(ceiling), 8.0F, 128.0F, 0, [this](float nv) {
                sampler.setVoiceCeiling(static_cast<int>(nv));
                invalidate();
            });
        },
        [this]() { sampler.setVoiceCeiling(128); invalidate(); });

    // LANGUAGE: the choice is kept in the saved settings (the same setting the controller has always had)
    nlPanel(c, RectF(20.0F, 494.0F, 440.0F, 650.0F), "LANGUAGE");
    if (uiLangShown_ < 0) uiLangShown_ = sampler.uiLanguage();
    static const char* const langs[] = {"БЪЛГАРСКИ", "ENGLISH"};
    for (int k = 0; k < 2; ++k) {
        const RectF key(36.0F + static_cast<float>(k) * 200.0F, 534.0F, 224.0F + static_cast<float>(k) * 200.0F, 596.0F);
        nlBtn(c, key, langs[k], uiLangShown_ == k ? NlBtn::On : NlBtn::Off, 14.0F);
        hit(key, [this, k](float, float) { sampler.setUiLanguage(k); uiLangShown_ = k; invalidate(); });
    }

    // THEME: the five keys of the picture. The choice is kept in the saved settings and the program opens with it.
    nlPanel(c, RectF(450.0F, 494.0F, 1320.0F, 650.0F), "THEME");
    static const char* const themes[] = {"GRAPHITE", "LIGHT", "BLACK", "CLASSIC", "OLD"};
    for (int k = 0; k < 5; ++k) {
        const RectF key(466.0F + static_cast<float>(k) * 169.5F, 534.0F, 626.0F + static_cast<float>(k) * 169.5F, 596.0F);
        nlBtn(c, key, themes[k], colorKey_ == k ? NlBtn::On : NlBtn::Off, 13.0F);
        hit(key, [this, k](float, float) { applyColor(k, true); });
    }
}

// SILVETON_BANK_INFO_V1: what is in SILVETON_BANK.sv, DELETE of whole SOUNDs.
std::string SilvetonSamplerView::mb(long long bytes) { return fmtFixed(static_cast<double>(bytes) / 1048576.0, 1) + " MB"; }

/** SILVETON_NEW_LOOK_V1: INFO - SOUND BANK (counts, the biggest sounds, delete, refresh) and MY WAVES (SILVETON_OSC.sv). */
void SilvetonSamplerView::drawBankInfo(Canvas& c) {
    if (!bankInfoCache) bankInfoCache = sampler.bankInfo();
    // ---- SOUND BANK
    nlPanel(c, RectF(20.0F, 146.0F, 660.0F, 436.0F), "SOUND BANK");
    const RectF box(34.0F, 180.0F, 646.0F, 310.0F);
    nlLcd(c, box);
    if (!bankInfoCache) {
        text(c, "SILVETON_BANK.sv NOT FOUND", box.left + 20.0F, box.top + 62.0F, 22.0F, C_LCD_BAD, Opt().mono().maxW(box.width() - 40.0F));
    } else {
        const Ctrl::BankInfo& info = *bankInfoCache;
        const std::pair<std::string, std::string> rows[] = {
            {"SOUNDS", std::to_string(info.sounds)},
            {"SAMPLES", std::to_string(info.samples)},
            {"AUDIO", mb(info.audioBytes)},
            {"FILE", mb(info.fileBytes)}};
        for (int k = 0; k < 4; ++k) {
            const float top = 190.0F + static_cast<float>(k) * 30.0F;
            text(c, rows[k].first, 52.0F, tb(top, 13.0F), 13.0F, kHint, Opt().bold().spacing(0.12F));
            text(c, rows[k].second, 320.0F, tb(top, 15.0F), 15.0F, NL_VALUE, Opt().monoBold().maxW(300.0F));
        }
        text(c, info.path, 34.0F, tb(322.0F, 12.0F), 12.0F, kHint, Opt().mono().maxW(612.0F));
        nlLabel(c, "LARGEST SOUNDS", 34.0F, tb(350.0F, 11.0F), false, NL_TXT2, 11.0F);
        std::vector<Ctrl::BankSound> big = info.list;
        std::stable_sort(big.begin(), big.end(), [](const Ctrl::BankSound& x, const Ctrl::BankSound& y) { return x.bytes > y.bytes; });
        if (big.size() > 3U) big.resize(3U);   // the picture has room for three
        for (std::size_t k = 0; k < big.size(); ++k) {
            const float top = 372.0F + static_cast<float>(k) * 20.0F;
            text(c, fmtZeroPad(big[k].slot, 3) + "  " + big[k].name, 34.0F, tb(top, 12.0F), 12.0F, kSoft, Opt().mono().maxW(480.0F));
            text(c, mb(big[k].bytes), 612.0F, tb(top, 12.0F), 12.0F, kSoft, Opt().mono().right());
        }
    }
    const RectF delR(20.0F, 450.0F, 420.0F, 512.0F);
    const RectF refR(430.0F, 450.0F, 660.0F, 512.0F);
    nlBtn(c, delR, "CHOOSE SOUNDS TO DELETE", bankInfoCache ? NlBtn::On : NlBtn::Off, 13.0F);
    nlBtn(c, refR, "REFRESH", NlBtn::Plain, 13.0F, false);
    if (bankInfoCache) {
        const Ctrl::BankInfo info = *bankInfoCache;
        hit(delR, [this, info](float, float) { showDeleteSounds(info); });
    }
    hit(refR, [this](float, float) { bankInfoCache = sampler.bankInfo(); sampler.reloadUserWaves(); invalidate(); });   // (SILVETON_USER_WAVES_V1: the waves too)
    text(c, "delete: tick sounds → DELETE → confirm → wait (do not switch the tablet off)", 20.0F, tb(528.0F, 11.5F), 11.5F, kHint, Opt().maxW(640.0F));

    // ---- MY WAVES (SILVETON_USER_WAVES_V1: the user's waves are shown also when the bank is not found)
    nlPanel(c, RectF(670.0F, 146.0F, 1320.0F, 436.0F), "MY WAVES · SILVETON_OSC.sv");
    nlLcd(c, RectF(684.0F, 180.0F, 1306.0F, 310.0F));
    const auto uw = sampler.userWaves();
    const std::size_t count = uw.names.size();
    const std::string loaded = !uw.folderFound ? std::string("there is no SILVETON_OSC.sv")
                               : (count == 0U ? std::string("no ready waves") : std::to_string(count) + "  (USER 1 – " + std::to_string(count) + ")");
    const std::string vals[3] = {loaded, std::to_string(uw.skipped.size()), uw.folderFound ? uw.folder : std::string("—")};
    static const char* const labs[3] = {"LOADED", "SKIPPED", "FOLDER"};
    for (int k = 0; k < 3; ++k) {
        const float top = 192.0F + static_cast<float>(k) * 38.0F;
        text(c, labs[k], 702.0F, tb(top, 13.0F), 13.0F, kHint, Opt().bold().spacing(0.12F));
        text(c, vals[k], 900.0F, tb(top, 14.0F), 14.0F, NL_VALUE, Opt().monoBold().maxW(396.0F));
    }
    text(c, "if the file is missing: “there is no SILVETON_OSC.sv” · if empty: “no ready waves”", 684.0F, tb(322.0F, 11.5F), 11.5F, kHint, Opt().maxW(622.0F));
    text(c, "REFRESH also reloads the waves and the models", 684.0F, tb(342.0F, 11.5F), 11.5F, kHint, Opt().maxW(622.0F));
    std::string list;   // the names of the waves (as the old page showed them), then what was skipped
    for (std::size_t k = 0; k < count && k < 6U; ++k) {
        list += (k > 0U ? "   " : "") + std::string("U") + std::to_string(k + 1U) + " " + uw.names[k];
        if (k < uw.zoneCounts.size() && uw.zoneCounts[k] > 1) list += " (" + std::to_string(uw.zoneCounts[k]) + " zones)";   // a KMP: a wave per zone
    }
    if (count > 6U) list += "   …";
    if (!list.empty()) text(c, list, 684.0F, tb(376.0F, 12.0F), 12.0F, kSoft, Opt().mono().maxW(622.0F));
    if (!uw.skipped.empty())
        text(c, "SKIPPED: " + uw.skipped[0] + (uw.skipped.size() > 1U ? "  (+" + std::to_string(uw.skipped.size() - 1U) + ")" : std::string()),
             684.0F, tb(398.0F, 12.0F), 12.0F, kHint, Opt().mono().maxW(622.0F));

    // ---- MODELS (SILVETON_MODELS_FROM_FILE_V1: Цветомир, 04.11.2026 - "четенето на моделите от таблета да става прозрачно без никакви скрити настройки",
    // "махни моделите, които са вградени в семплера ... да мога да ги трия"): nothing is built into the sampler; the models are the sounds of SILVETON_OSC.sv
    {
        nlPanel(c, RectF(670.0F, 446.0F, 1320.0F, 690.0F), "MODELS · the sounds of SILVETON_OSC.sv · nothing is built in");
        nlLcd(c, RectF(684.0F, 480.0F, 1306.0F, 574.0F));
        const Ctrl::ModelsInfo mi = sampler.learnedModelsInfo();
        std::string modelsText = mi.models <= 0 ? std::string("none") : std::to_string(mi.models) + "   (" + std::to_string(mi.zones) + " zones)";
        if (mi.models > 0 && mi.soundsInFile > mi.models) modelsText += "   the file holds " + std::to_string(mi.soundsInFile) + ", the first " + std::to_string(mi.models) + " are used";
        const std::string fileText = !mi.fileFound ? std::string("there is no SILVETON_OSC.sv") : mb(mi.fileBytes);
        const std::string readText = !mi.note.empty() ? mi.note : (!mi.fileFound ? std::string("—") : (mi.models > 0 ? std::string("read, all of it") : std::string("the file holds no sounds")));
        const std::string mv[3] = {modelsText, fileText, readText};
        static const char* const mlabs[3] = {"MODELS", "FILE", "READ"};
        for (int k = 0; k < 3; ++k) {
            const float top = 489.0F + static_cast<float>(k) * 28.0F;
            text(c, mlabs[k], 702.0F, tb(top, 13.0F), 13.0F, kHint, Opt().bold().spacing(0.12F));
            text(c, mv[k], 830.0F, tb(top, 14.0F), 14.0F, NL_VALUE, Opt().monoBold().maxW(466.0F));
        }
        const RectF delM(684.0F, 588.0F, 1084.0F, 650.0F);
        nlBtn(c, delM, "CHOOSE MODELS TO DELETE", mi.models > 0 ? NlBtn::On : NlBtn::Off, 13.0F);
        if (mi.models > 0) hit(delM, [this](float, float) { showDeleteModels(); });
        text(c, "delete: tick models → DELETE → confirm. They are taken out of the file for good (also at the next start).", 684.0F, tb(662.0F, 11.5F), 11.5F, kHint, Opt().maxW(622.0F));
    }
}

void SilvetonSamplerView::showDeleteModels() {
    const std::vector<std::string> names = sampler.learnedModelNames();
    if (names.empty()) { flash("THERE ARE NO MODELS"); return; }
    std::vector<std::string> labels;
    for (std::size_t k = 0; k < names.size(); ++k) labels.push_back(fmtZeroPad(static_cast<long long>(k) + 1, 3) + "   " + names[k]);
    const std::size_t count = names.size();
    showMultiChoice("DELETE MODELS FROM SILVETON_OSC.sv", labels, [this, count](const std::vector<bool>& checked) {
        std::vector<int> chosen;
        for (std::size_t k = 0; k < count; ++k) if (k < checked.size() && checked[k]) chosen.push_back(static_cast<int>(k));
        if (chosen.empty()) return;
        askDeleteModels(chosen, nullptr);
    }, "DELETE", "CANCEL");
}

void SilvetonSamplerView::askDeleteModels(const std::vector<int>& indices, std::function<void()> afterDone) {
    showConfirm("DELETE " + std::to_string(indices.size()) + (indices.size() == 1U ? " MODEL" : " MODELS"),
                "The models are taken out of SILVETON_OSC.sv for good - they do not come back when the sampler starts.\n"
                "A place that plays another model keeps it; a place that plays a deleted one is left on NONE.\nDelete?",
                "YES, DELETE", [this, indices, afterDone]() { runDeleteModels(indices, afterDone); }, "NO");
}

void SilvetonSamplerView::runDeleteModels(const std::vector<int>& indices, std::function<void()> afterDone) {
    showWait("DELETING…", "SILVETON_OSC.sv is rewritten. Do not switch the tablet off.", [this, indices, afterDone]() -> std::function<void()> {
        const std::optional<std::string> err = sampler.deleteLearnedModels(indices);
        return [this, err, count = indices.size(), afterDone]() {
            for (auto& e : engineParamsCache) e.reset();
            invalidate();
            flash(!err ? "DELETED: " + std::to_string(count) + (count == 1U ? " MODEL" : " MODELS") : "ERROR: " + *err);
            if (afterDone) afterDone();
        };
    });
}

void SilvetonSamplerView::showDeleteSounds(const Ctrl::BankInfo& info) {
    if (info.list.empty()) return;
    std::vector<std::string> labels;
    for (const auto& it : info.list) {
        labels.push_back(fmtZeroPad(it.slot, 3) + "   " + it.name + "   ·   " + std::to_string(it.samples) + " samples   ·   " + mb(it.bytes));
    }
    const std::vector<Ctrl::BankSound> list = info.list;
    showMultiChoice("DELETE SOUNDS FROM THE BANK", labels, [this, list](const std::vector<bool>& checked) {
        std::vector<Ctrl::BankSound> chosen;
        for (std::size_t k = 0; k < list.size(); ++k) if (k < checked.size() && checked[k]) chosen.push_back(list[k]);
        if (chosen.empty()) return;
        long long freed = 0;
        std::vector<int> slots;
        for (const auto& s : chosen) { freed += s.bytes; slots.push_back(s.slot); }
        showConfirm("DELETE " + std::to_string(chosen.size()) + " SOUNDS",
                    "The sounds are deleted from SILVETON_BANK.sv for good (together with the samples only they use, up to " + mb(freed) + ").\n" +
                        "The blends that use them stay without them.\nDelete?",
                    "YES, DELETE", [this, slots]() { runDeleteSounds(slots); }, "NO");
    }, "DELETE", "CANCEL");
}

void SilvetonSamplerView::runDeleteSounds(const std::vector<int>& slots) {
    showWait("DELETING…", "The bank is rewritten. Do not switch the tablet off.", [this, slots]() -> std::function<void()> {
        const std::optional<std::string> err = sampler.deleteBankSounds(slots);
        return [this, err, count = slots.size()]() {
            bankInfoCache = sampler.bankInfo();
            cachedCombiName = sampler.combiName();
            refreshAllUppers();
            refreshListCache();
            flash(!err ? "DELETED: " + std::to_string(count) + " SOUNDS" : "ERROR: " + *err);
        };
    });
}

float SilvetonSamplerView::globalStep(int i) {
    switch (i) {
        case 1: case 8: case 9: case 10: case 11: return 1.0F;
        default: return 0.1F;
    }
}

float SilvetonSamplerView::globalTravel(int i) {
    switch (i) {
        case 0: return 400.0F;
        case 1: return 240.0F;
        case 2: return 390.0F;
        case 3: case 4: case 5: return 360.0F;
        case 7: return 240.0F;
        case 8: return 160.0F;
        default: return 508.0F;
    }
}

void SilvetonSamplerView::editGlobal(int i, const GlobalUiState& g) {
    switch (i) {
        case 0: showNumber("MASTER TUNE Hz", g.masterTuneHz, 400.0F, 480.0F, 1, [this, g](float v) { GlobalUiState n = g; n.masterTuneHz = v; commitGlobal(n); }); break;
        case 1: showNumber("TRANSPOSE", static_cast<float>(g.transpose), -12.0F, 12.0F, 0, [this, g](float v) { GlobalUiState n = g; n.transpose = static_cast<int>(v); commitGlobal(n); }); break;
        case 2: showNumber("MASTER GAIN dB", g.masterGainDb, -60.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.masterGainDb = v; commitGlobal(n); }); break;
        case 3: showNumber("EQ LOW dB", g.eqLowDb, -18.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.eqLowDb = v; commitGlobal(n); }); break;
        case 4: showNumber("EQ MID dB", g.eqMidDb, -18.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.eqMidDb = v; commitGlobal(n); }); break;
        case 5: showNumber("EQ HIGH dB", g.eqHighDb, -18.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.eqHighDb = v; commitGlobal(n); }); break;
        case 6: { GlobalUiState n = g; n.limiterEnabled = !g.limiterEnabled; commitGlobal(n); break; }
        case 7: showNumber("CEILING dB", std::min(g.limiterCeilingDb, -6.0F), -12.0F, -6.0F, 1, [this, g](float v) { GlobalUiState n = g; n.limiterCeilingDb = v; commitGlobal(n); }); break;
        case 8: showNumber("VELOCITY CURVE", static_cast<float>(g.velocityCurve), 0.0F, 4.0F, 0, [this, g](float v) { GlobalUiState n = g; n.velocityCurve = static_cast<int>(v); commitGlobal(n); }); break;
        case 9: showNumber("BREATH CC", static_cast<float>(g.breathCc), 0.0F, 127.0F, 0, [this, g](float v) { GlobalUiState n = g; n.breathCc = static_cast<int>(v); commitGlobal(n); }); break;
        case 10: showNumber("EXPRESSION CC", static_cast<float>(g.expressionCc), 0.0F, 127.0F, 0, [this, g](float v) { GlobalUiState n = g; n.expressionCc = static_cast<int>(v); commitGlobal(n); }); break;
        case 11: showNumber("DAMPER CC", static_cast<float>(g.damperCc), 0.0F, 127.0F, 0, [this, g](float v) { GlobalUiState n = g; n.damperCc = static_cast<int>(v); commitGlobal(n); }); break;
        case 12: { GlobalUiState n = g; n.pitchBendEnabled = !g.pitchBendEnabled; commitGlobal(n); break; }
        case 13: { GlobalUiState n = g; n.aftertouchEnabled = !g.aftertouchEnabled; commitGlobal(n); break; }
        default: break;
    }
}

void SilvetonSamplerView::resetGlobal(int i, const GlobalUiState& g) {
    GlobalUiState n = g;
    switch (i) {
        case 0: n.masterTuneHz = 440.0F; break;
        case 1: n.transpose = 0; break;
        case 2: n.masterGainDb = -6.0F; break;   // SILVETON_NEW_LOOK_V1: MASTER GAIN is on this page now; its default is -6 dB (the same as the top bar)
        case 3: n.eqLowDb = 0.0F; break;
        case 4: n.eqMidDb = 0.0F; break;
        case 5: n.eqHighDb = 0.0F; break;
        case 6: n.limiterEnabled = false; break;
        case 7: n.limiterCeilingDb = -6.0F; break;
        case 8: n.velocityCurve = 0; break;
        case 9: n.breathCc = 2; break;
        case 10: n.expressionCc = 11; break;
        case 11: n.damperCc = 64; break;
        case 12: n.pitchBendEnabled = true; break;
        default: n.aftertouchEnabled = true; break;
    }
    commitGlobal(n);
}

std::array<float, 3> SilvetonSamplerView::globalSliderSpec(int i, const GlobalUiState& g) {
    switch (i) {
        case 0: return {g.masterTuneHz, 400.0F, 480.0F};
        case 1: return {static_cast<float>(g.transpose), -12.0F, 12.0F};
        case 2: return {g.masterGainDb, -60.0F, 18.0F};   // SILVETON_NEW_LOOK_V1: shown on GENERAL
        case 3: return {g.eqLowDb, -18.0F, 18.0F};
        case 4: return {g.eqMidDb, -18.0F, 18.0F};
        case 5: return {g.eqHighDb, -18.0F, 18.0F};
        case 7: return {std::min(g.limiterCeilingDb, -6.0F), -12.0F, -6.0F};
        case 8: return {static_cast<float>(g.velocityCurve), 0.0F, 4.0F};
        case 9: return {static_cast<float>(g.breathCc), 0.0F, 127.0F};
        case 10: return {static_cast<float>(g.expressionCc), 0.0F, 127.0F};
        case 11: return {static_cast<float>(g.damperCc), 0.0F, 127.0F};
        default: return {0.0F, 0.0F, 1.0F};
    }
}

SilvetonSamplerView::GlobalUiState SilvetonSamplerView::globalWithSliderValue(int i, const GlobalUiState& g, float v) {
    GlobalUiState n = g;
    switch (i) {
        case 0: n.masterTuneHz = v; break;
        case 1: n.transpose = roundToInt(v); break;
        case 2: n.masterGainDb = v; break;
        case 3: n.eqLowDb = v; break;
        case 4: n.eqMidDb = v; break;
        case 5: n.eqHighDb = v; break;
        case 7: n.limiterCeilingDb = v; break;
        case 8: n.velocityCurve = roundToInt(v); break;
        case 9: n.breathCc = roundToInt(v); break;
        case 10: n.expressionCc = roundToInt(v); break;
        case 11: n.damperCc = roundToInt(v); break;
        default: break;
    }
    return n;
}

std::string SilvetonSamplerView::globalValueText(int i, const GlobalUiState& g) {
    const auto f2 = [](float v) { return fmtFixed(static_cast<double>(v), 2); };
    switch (i) {
        case 0: return f2(g.masterTuneHz) + " Hz";
        case 1: return signed_(g.transpose);
        case 2: return f2(g.masterGainDb) + " dB";
        case 3: return f2(g.eqLowDb) + " dB";
        case 4: return f2(g.eqMidDb) + " dB";
        case 5: return f2(g.eqHighDb) + " dB";
        case 7: return f2(g.limiterCeilingDb) + " dB";
        case 8: return std::to_string(g.velocityCurve);
        case 9: return "CC " + std::to_string(g.breathCc);
        case 10: return "CC " + std::to_string(g.expressionCc);
        case 11: return "CC " + std::to_string(g.damperCc);
        default: return "";
    }
}

// ---------------------------------------------------------------------------------------------- SET
// SILVETON_NEW_LOOK_V1: the saved sets are read again (names newest first, with the size of the file)
void SilvetonSamplerView::refreshSetList() {
    setsListDirty_ = false;
    setsFolder_ = sampler.setsFolders();
    setsList_.clear();
    for (const std::string& name : sampler.savedSets()) setsList_.emplace_back(name, files::fileSize(files::join(setsFolder_, name + ".SVSET")));
    setsScroll_ = std::clamp(setsScroll_, 0, std::max(0, static_cast<int>(setsList_.size()) - 4));
}

// the same as the old ЗАПИШИ СЕТ (View_List.cpp saveSetAs) but the name comes from the SET NAME field
void SilvetonSamplerView::saveSetNamed(const std::string& name) {
    const auto doSave = [this, name]() {
        const std::optional<std::string> err = sampler.saveSetAs(name);
        flash(!err ? "SET SAVED: " + trimmed(name) : "ERROR: " + *err);
        setsListDirty_ = true;
        invalidate();
    };
    if (sampler.setExists(name)) {
        showConfirm("SAVE SET", "A set “" + trimmed(name) + "” already exists.\nSave over it?", "YES, SAVE", doSave, "NO");
    } else {
        doSave();
    }
}

// the same as the old ЗАРЕДИ СЕТ (View_List.cpp loadSet) for the chosen set
void SilvetonSamplerView::loadSetNamed(const std::string& name) {
    showConfirm("LOAD SET  “" + name + "”",
                "The whole LIST, the blends and the settings are replaced with those of the set.\nThe current ones, if not saved as a set, are lost.",
                "LOAD", [this, name]() {
                    const std::optional<std::string> err = sampler.loadSavedSet(name);
                    if (!err) {
                        refreshListCache();
                        loadedFromList = cachedActiveListEntry;
                        listSelected = cachedActiveListEntry;
                        listFollowedActive = cachedActiveListEntry;
                        editingCombiSlot.reset();
                        if (const auto item = realListItem(cachedActiveListEntry); item && item->combiBank == 0 && item->combiPage == 0)
                            editingCombiSlot = item->combiSlot;
                        listPage = listSelected >= 0 ? listSelected / LIST_PER_PAGE : 0;
                        cachedCombiName = sampler.combiName();
                        refreshAllUppers();
                        refreshFx();
                        refreshGlobal();
                        flash("SET LOADED: " + name);
                        reportMissingSounds();
                    } else {
                        flash("ERROR: " + *err);
                    }
                }, "CANCEL");
}

/** SILVETON_LOGIC_V1: SET - the whole SET (the LIST, all blends and the settings) in a file: save it, load it. */
void SilvetonSamplerView::drawSetSettings(Canvas& c) {
    if (setsListDirty_) refreshSetList();
    // ---- SAVE SET
    nlPanel(c, RectF(20.0F, 146.0F, 660.0F, 446.0F), "SAVE SET");
    nlLabel(c, "SET NAME", 34.0F, tb(182.0F, 11.0F), false, NL_TXT2, 11.0F);
    const RectF nameR(34.0F, 200.0F, 646.0F, 256.0F);
    nlLcd(c, nameR);
    text(c, setsName_, 50.0F, tb(214.0F, 22.0F), 22.0F, NL_VALUE, Opt().bold().maxW(580.0F));
    hit(nameR, [this](float, float) {
        showTextPage("SET NAME", setsName_, [this](const std::string& name) {
            if (!isBlank(name)) setsName_ = trimmed(name);
            invalidate();
        });
    });
    const RectF saveR(34.0F, 270.0F, 646.0F, 340.0F);
    nlBtn(c, saveR, "SAVE SET", NlBtn::On, 18.0F);
    hit(saveR, [this](float, float) { saveSetNamed(setsName_); });
    text(c, "ONE FILE: the LIST, all blends and all their settings (portamento, oscillation, effects …)", 34.0F, tb(356.0F, 12.5F), 12.5F, kSoft, Opt().maxW(612.0F));
    text(c, "and your user settings", 34.0F, tb(378.0F, 12.5F), 12.5F, kSoft, Opt());
    text(c, setsFolder_ + "/" + trimmed(setsName_) + ".SVSET", 34.0F, tb(408.0F, 12.0F), 12.0F, kHint, Opt().mono().maxW(612.0F));

    // ---- SAVED SETS (a list of four rows; with more sets the list is dragged up and down)
    nlPanel(c, RectF(670.0F, 146.0F, 1320.0F, 446.0F), "SAVED SETS");
    const int total = static_cast<int>(setsList_.size());
    int pick = 0;
    for (int k = 0; k < total; ++k) if (setsList_[static_cast<std::size_t>(k)].first == setsPick_) pick = k;
    for (int row = 0; row < 4; ++row) {
        const int k = setsScroll_ + row;
        if (k >= total) break;
        const float y = 180.0F + static_cast<float>(row) * 52.0F;
        const RectF rr(684.0F, y, 1306.0F, y + 46.0F);
        const bool sel = k == pick;
        const auto& item = setsList_[static_cast<std::size_t>(k)];
        nlBtn(c, rr, "", sel ? NlBtn::Sel : NlBtn::Plain, 14.0F, false);
        text(c, item.first, 702.0F, tb(y + 12.0F, 17.0F), 17.0F, sel ? Color::WHITE : NL_TXT, Opt().bold().maxW(900.0F));
        const std::string size = item.second < 0 ? std::string() : (item.second < 1048576LL ? std::to_string((item.second + 512LL) / 1024LL) + " KB" : mb(item.second));
        text(c, size, 1290.0F, tb(y + 14.0F, 13.0F), 13.0F, sel ? Color::rgb(207, 230, 255) : kHint, Opt().mono().right());
    }
    if (total == 0) text(c, "no saved sets yet", 702.0F, tb(196.0F, 15.0F), 15.0F, kHint, Opt());
    if (total > 4) {   // a thin bar tells that the list goes on
        const float th = std::max(24.0F, 208.0F * 4.0F / static_cast<float>(total));
        const float ty = 180.0F + (208.0F - th) * static_cast<float>(setsScroll_) / static_cast<float>(total - 4);
        fill(c, RectF(1310.0F, 180.0F, 1314.0F, 388.0F), 2.0F, Color::rgb(22, 25, 29));
        fill(c, RectF(1310.0F, ty, 1314.0F, ty + th), 2.0F, Color::rgb(96, 104, 114));
    }
    {
        const int start = setsScroll_;
        const std::vector<std::pair<std::string, long long>> list = setsList_;
        hit(RectF(684.0F, 180.0F, 1306.0F, 388.0F), [this, list, start](float, float y) {   // held: the same as a tap
                const int k = start + std::clamp(static_cast<int>((y - 180.0F) / 52.0F), 0, 3);
                if (k < static_cast<int>(list.size())) setsPick_ = list[static_cast<std::size_t>(k)].first;
                invalidate();
            }, nullptr,
            [this, list, start](float, float y, bool final) {
                if (!dragMoved) {   // a short tap arrives here (the key is lifted)
                    if (final) {
                        const int k = start + std::clamp(static_cast<int>((y - 180.0F) / 52.0F), 0, 3);
                        if (k < static_cast<int>(list.size())) setsPick_ = list[static_cast<std::size_t>(k)].first;
                    }
                    return;
                }
                const int most = std::max(0, static_cast<int>(list.size()) - 4);
                setsScroll_ = std::clamp(start - static_cast<int>(std::nearbyint((y - downY) / 52.0F)), 0, most);
            });
    }
    const RectF loadR(684.0F, 392.0F, 1306.0F, 436.0F);
    nlBtn(c, loadR, "LOAD SET", NlBtn::On, 16.0F);
    hit(loadR, [this, pick](float, float) {
        if (setsList_.empty()) {
            showMessage("LOAD SET", "There are no saved sets.\nSave one on SETTINGS › SET. Folder: " + setsFolder_);
            return;
        }
        loadSetNamed(setsList_[static_cast<std::size_t>(std::clamp(pick, 0, static_cast<int>(setsList_.size()) - 1))].first);
    });

    // ---- SAMPLES
    nlPanel(c, RectF(20.0F, 456.0F, 1320.0F, 650.0F), "SAMPLES");
    const RectF s1(34.0F, 490.0F, 664.0F, 590.0F);
    const RectF s2(676.0F, 490.0F, 1306.0F, 590.0F);
    nlLcd(c, s1);
    nlLcd(c, s2);
    text(c, "SAVE SET", s1.left + 18.0F, tb(s1.top + 14.0F, 20.0F), 20.0F, kLcdAmber, Opt().bold().spacing(0.04F));
    text(c, "samples are NOT saved", s1.left + 18.0F, tb(s1.top + 50.0F, 17.0F), 17.0F, NL_VALUE, Opt());
    text(c, "LOAD SET", s2.left + 18.0F, tb(s2.top + 14.0F, 20.0F), 20.0F, kLcdAmber, Opt().bold().spacing(0.04F));
    text(c, "samples are NOT loaded", s2.left + 18.0F, tb(s2.top + 50.0F, 17.0F), 17.0F, NL_VALUE, Opt());
    text(c, "the samples are read from the sound bank, exactly as now · a set holds everything else", 34.0F, tb(606.0F, 12.0F), 12.0F, kHint, Opt().maxW(1270.0F));
}

// ---------------------------------------------------------------------------------------------- MIDI
/** SILVETON_MIDI_FULL_V1: every MIDI setting of the sampler on one page. */
void SilvetonSamplerView::drawMidiSettings(Canvas& c) {
    std::optional<GlobalUiState> gOpt = globalState;
    if (!gOpt) { gOpt = sampler.globalUiState(); if (gOpt) globalState = gOpt; }
    if (!gOpt) return;
    const GlobalUiState g = *gOpt;
    const std::optional<Ctrl::GlobalAdvanced> aOpt = sampler.globalAdvanced();
    if (!aOpt) return;
    const Ctrl::GlobalAdvanced a = *aOpt;

    // MIDI CHANNEL OF EVERY UPPER
    nlPanel(c, RectF(20.0F, 146.0F, 1320.0F, 244.0F), "MIDI CHANNEL OF EVERY UPPER");
    for (int i = 0; i < 7; ++i) {
        auto& slot = upperStates[static_cast<std::size_t>(i)];
        if (!slot) { slot = sampler.upperState(i); if (!slot) continue; }
        const UpperState st = *slot;
        const float x = 34.0F + static_cast<float>(i) * 184.0F;
        const std::string who = i == 6 ? std::string("LOWER") : "UPPER " + std::to_string(i + 1);   // the 7th Upper is called LOWER (the picture sets_midi still says UPPER 7)
        stgCell(c, RectF(x, 180.0F, x + 176.0F, 224.0F), who, "CH " + std::to_string(st.midiChannel + 1), 0, 11.0F, false, 0.0F, [this, i, st, who]() {
            showNumber(who + " MIDI CHANNEL", static_cast<float>(st.midiChannel + 1), 1.0F, 16.0F, 0, [this, i, st](float nv) {
                const auto& cur = upperStates[static_cast<std::size_t>(i)];
                UpperState next = cur ? *cur : st;
                next.midiChannel = std::clamp(roundToInt(nv), 1, 16) - 1;
                commitControlFor(i, next);   // LINK: the marked Uppers get the same MIDI channel
            }, false);
        });
    }

    // MIDI IN: which channels are received (lit = received)
    nlPanel(c, RectF(20.0F, 252.0F, 1320.0F, 350.0F), "MIDI IN · WHICH CHANNELS ARE RECEIVED");
    for (int ch = 0; ch < 16; ++ch) {
        const float x = 34.0F + static_cast<float>(ch) * 80.0F;
        const RectF r(x, 290.0F, x + 74.0F, 334.0F);
        const bool on = (a.midiInMask & (1 << ch)) != 0;
        stgKey(c, r, std::to_string(ch + 1), "", on ? 2 : 1, 13.0F);
        hit(r, [this, a, ch](float, float) {
            Ctrl::GlobalAdvanced n = a;
            n.midiInMask = a.midiInMask ^ (1 << ch);
            sampler.updateGlobalAdvanced(n);
            invalidate();
        });
    }

    // FILTERS: ON = ignored (PEDAL REVERSED is the polarity of the damper)
    nlPanel(c, RectF(20.0F, 358.0F, 1320.0F, 456.0F), "FILTERS · ON = IGNORED");
    struct Filter { const char* name; bool on; };
    const Filter filters[5] = {{"NOTES", a.filterNotes}, {"CC", a.filterCc}, {"PITCH BEND", a.filterBend}, {"AFTERTOUCH", a.filterAftertouch}, {"PEDAL REVERSED", a.damperReversed}};
    for (int k = 0; k < 5; ++k) {
        const float x = 34.0F + static_cast<float>(k) * 200.0F;
        stgCell(c, RectF(x, 394.0F, x + 192.0F, 440.0F), filters[k].name, "", filters[k].on ? 2 : 1, 12.0F, true, 0.07F, [this, a, k]() {
            Ctrl::GlobalAdvanced n = a;
            switch (k) {
                case 0: n.filterNotes = !a.filterNotes; break;
                case 1: n.filterCc = !a.filterCc; break;
                case 2: n.filterBend = !a.filterBend; break;
                case 3: n.filterAftertouch = !a.filterAftertouch; break;
                default: n.damperReversed = !a.damperReversed; break;
            }
            sampler.updateGlobalAdvanced(n);
        });
    }
    text(c, "PEDAL REVERSED = polarity,", 1050.0F, tb(408.0F, 11.0F), 11.0F, kHint, Opt().maxW(260.0F));
    text(c, "not an ignore switch", 1050.0F, tb(424.0F, 11.0F), 11.0F, kHint, Opt().maxW(260.0F));

    // CONTROLLERS: BREATH, EXPRESSION, DAMPER, VELOCITY, BEND, AFTERTOUCH
    nlPanel(c, RectF(20.0F, 464.0F, 1320.0F, 650.0F), "CONTROLLERS");
    const auto cell = [](float y, int k) {
        const float x = 34.0F + static_cast<float>(k) * 150.0F;
        return RectF(x, y, x + 144.0F, y + 44.0F);
    };
    const float y1 = 498.0F;
    const float y2 = 550.0F;
    const auto pct = [](float v) { return fmtFixed(static_cast<double>(v * 100.0F), 2) + " %"; };
    const auto f2 = [](float v) { return fmtFixed(static_cast<double>(v), 2); };
    const auto advNumber = [this, a](const std::string& title, float value, float lo, float hi, int decimals, std::function<void(Ctrl::GlobalAdvanced&, float)> set) {
        showNumber(title, value, lo, hi, decimals, [this, a, set](float v) {
            Ctrl::GlobalAdvanced n = a;
            set(n, v);
            sampler.updateGlobalAdvanced(n);
        }, false);
    };
    const auto vcell = [&](const RectF& r, const std::string& name, const std::string& value, std::function<void()> tap) { stgCell(c, r, name, value, 0, 11.0F, false, 0.0F, std::move(tap)); };
    vcell(cell(y1, 0), "BREATH CC", "CC " + std::to_string(g.breathCc), [this, g]() { editGlobal(9, g); });
    vcell(cell(y1, 1), "BREATH MIN", pct(a.breathMin), [=]() { advNumber("BREATH MIN %", a.breathMin * 100.0F, 0.0F, 99.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.breathMin = v / 100.0F; }); });
    vcell(cell(y1, 2), "BREATH MAX", pct(a.breathMax), [=]() { advNumber("BREATH MAX %", a.breathMax * 100.0F, 1.0F, 100.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.breathMax = v / 100.0F; }); });
    vcell(cell(y1, 3), "BREATH CURVE", f2(a.breathCurve), [=]() { advNumber("BREATH CURVE", a.breathCurve, 0.1F, 8.0F, 2, [](Ctrl::GlobalAdvanced& n, float v) { n.breathCurve = v; }); });
    vcell(cell(y1, 4), "VELOCITY CURVE", std::to_string(g.velocityCurve), [this, g]() { editGlobal(8, g); });
    vcell(cell(y2, 0), "EXPRESSION CC", "CC " + std::to_string(g.expressionCc), [this, g]() { editGlobal(10, g); });
    vcell(cell(y2, 1), "EXPRESSION MIN", pct(a.expressionMin), [=]() { advNumber("EXPRESSION MIN %", a.expressionMin * 100.0F, 0.0F, 99.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.expressionMin = v / 100.0F; }); });
    vcell(cell(y2, 2), "EXPRESSION MAX", pct(a.expressionMax), [=]() { advNumber("EXPRESSION MAX %", a.expressionMax * 100.0F, 1.0F, 100.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.expressionMax = v / 100.0F; }); });
    vcell(cell(y2, 3), "EXPRESSION CURVE", f2(a.expressionCurve), [=]() { advNumber("EXPRESSION CURVE", a.expressionCurve, 0.1F, 8.0F, 2, [](Ctrl::GlobalAdvanced& n, float v) { n.expressionCurve = v; }); });
    vcell(cell(y2, 4), "DAMPER CC", "CC " + std::to_string(g.damperCc), [this, g]() { editGlobal(11, g); });
    stgCell(c, RectF(800.0F, 498.0F, 960.0F, 544.0F), "PITCH BEND", g.pitchBendEnabled ? "ON" : "OFF", g.pitchBendEnabled ? 2 : 1, 11.0F, true, 0.05F, [this, g]() { editGlobal(12, g); });
    stgCell(c, RectF(968.0F, 498.0F, 1128.0F, 544.0F), "AFTERTOUCH", g.aftertouchEnabled ? "ON" : "OFF", g.aftertouchEnabled ? 2 : 1, 11.0F, true, 0.05F, [this, g]() { editGlobal(13, g); });
    const RectF calR(800.0F, 550.0F, 1128.0F, 596.0F);   // SILVETON_PEDAL_CAL_V1
    nlBtn(c, calR, "EXPRESSION PEDAL · CALIBRATION ▶", NlBtn::Plain, 12.0F);
    hit(calR, [this](float, float) { pedalCalOpen_ = true; invalidate(); });
    text(c, "every cell is a tap: it opens a number window (channels and filters switch on tap) · per-UPPER controller keys: SOUND EDIT › MIDI CONTROL", 34.0F, tb(612.0F, 11.0F), 11.0F, kHint, Opt().maxW(1270.0F));
}

/** SILVETON_PEDAL_CAL_V1 (Цветомир, 01.11.2026): calibration of the expression pedal. The number the pedal sends is shown live; with the heel
 *  down REMEMBER MIN keeps it as the bottom, with the toe down REMEMBER MAX keeps it as the top. The values go into the same EXPRESSION MIN / MAX
 *  the MIDI tab has always had (the sound engine is not touched): below MIN the sound is zero, above MAX it is full.
 *  SILVETON_NEW_LOOK_V1: the picture pedal_cal - one panel, no tabs; the page is drawn again every 40 ms while it is open (nextWorkMs). */
void SilvetonSamplerView::drawPedalCalibration(Canvas& c, const GlobalUiState& g, const Ctrl::GlobalAdvanced& a) {
    nlPanel(c, RectF(20.0F, 98.0F, 1320.0F, 650.0F), "EXPRESSION PEDAL · CALIBRATION");
    const int cc = g.expressionCc;
    const int cur = sampler.midiCcValue(cc);
    const int minV = roundToInt(a.expressionMin * 127.0F);
    const int maxV = roundToInt(a.expressionMax * 127.0F);

    // the live number
    nlLabel(c, "LIVE CC", 44.0F, tb(190.0F, 11.0F), false, NL_TXT2, 11.0F);
    const RectF ccBox(44.0F, 210.0F, 284.0F, 300.0F);
    const RectF valBox(300.0F, 210.0F, 460.0F, 300.0F);
    nlLcd(c, ccBox);
    nlLcd(c, valBox);
    text(c, "CC " + std::to_string(cc), ccBox.centerX(), tb(230.0F, 44.0F), 44.0F, NL_VALUE, Opt().center().monoBold());
    text(c, cur >= 0 ? std::to_string(cur) : std::string("--"), valBox.centerX(), tb(230.0F, 44.0F), 44.0F, kLive, Opt().center().monoBold());

    // the bar 0..127 with the stored MIN and MAX
    const float x0 = 60.0F;
    const float bw = 1200.0F;
    const RectF track(x0, 350.0F, x0 + bw, 378.0F);
    fill(c, track, 6.0F, Color::rgb(11, 14, 18));
    line(c, track.left + 6.0F, track.top + 1.0F, track.right - 6.0F, track.top + 1.0F, Color::argb(150, 0, 0, 0), 2.0F);
    line(c, track.left + 6.0F, track.bottom + 0.5F, track.right - 6.0F, track.bottom + 0.5F, Color::argb(20, 255, 255, 255), 1.0F);
    if (cur > 0) fillV(c, RectF(x0, track.top, std::max(x0 + 10.0F, x0 + bw * static_cast<float>(cur) / 127.0F), track.bottom), 5.0F, Color::rgb(82, 180, 255), NL_BLUE_DARK);
    const float minX = x0 + bw * static_cast<float>(minV) / 127.0F;
    const float maxX = x0 + bw * static_cast<float>(maxV) / 127.0F;
    const auto mark = [&](float x, const std::string& label) {
        fill(c, RectF(x - 2.0F, 336.0F, x + 2.0F, 392.0F), 1.0F, NL_AMBER);
        text(c, label, x, tb(398.0F, 13.0F), 13.0F, NL_AMBER, Opt().monoBold().center());
    };
    mark(minX, "MIN " + std::to_string(minV));
    mark(maxX, "MAX " + std::to_string(maxV));
    if (minX - x0 > 50.0F) text(c, "0", x0, tb(398.0F, 12.0F), 12.0F, kHint, Opt().mono());
    if (x0 + bw - maxX > 50.0F) text(c, "127", x0 + bw, tb(398.0F, 12.0F), 12.0F, kHint, Opt().mono().right());

    // the keys
    const RectF minR(60.0F, 470.0F, 340.0F, 546.0F);
    const RectF maxR(360.0F, 470.0F, 640.0F, 546.0F);
    const RectF resetR(660.0F, 470.0F, 1000.0F, 546.0F);
    const RectF doneR(1020.0F, 470.0F, 1260.0F, 546.0F);
    nlBtn(c, minR, "REMEMBER MIN", NlBtn::Plain, 16.0F, false);
    nlBtn(c, maxR, "REMEMBER MAX", NlBtn::Plain, 16.0F, false);
    nlBtn(c, resetR, "BACK TO 0 – 127", NlBtn::Plain, 15.0F, false);
    nlBtn(c, doneR, "DONE", NlBtn::On, 16.0F);
    hit(minR, [this, cc, a](float, float) {
        const int v = sampler.midiCcValue(cc);
        if (v < 0) { flash("MOVE THE PEDAL - NO NUMBER FROM IT YET"); return; }
        const float f = static_cast<float>(v) / 127.0F;
        if (f >= a.expressionMax - 0.0001F) { flash("MIN MUST BE BELOW MAX"); return; }
        Ctrl::GlobalAdvanced n = a;
        n.expressionMin = f;
        sampler.updateGlobalAdvanced(n);
        flash("MIN SAVED: " + std::to_string(v));
        invalidate();
    });
    hit(maxR, [this, cc, a](float, float) {
        const int v = sampler.midiCcValue(cc);
        if (v < 0) { flash("MOVE THE PEDAL - NO NUMBER FROM IT YET"); return; }
        const float f = static_cast<float>(v) / 127.0F;
        if (f <= a.expressionMin + 0.0001F) { flash("MAX MUST BE ABOVE MIN"); return; }
        Ctrl::GlobalAdvanced n = a;
        n.expressionMax = f;
        sampler.updateGlobalAdvanced(n);
        flash("MAX SAVED: " + std::to_string(v));
        invalidate();
    });
    hit(resetR, [this, a](float, float) {
        Ctrl::GlobalAdvanced n = a;
        n.expressionMin = 0.0F;
        n.expressionMax = 1.0F;
        sampler.updateGlobalAdvanced(n);
        flash("PEDAL BACK TO 0 – 127");
        invalidate();
    });
    hit(doneR, [this](float, float) { pedalCalOpen_ = false; invalidate(); });
    text(c, "leaving the MIDI page closes this calibration", 60.0F, tb(580.0F, 12.0F), 12.0F, kHint, Opt().maxW(1200.0F));
}

} // namespace silveton::ui::classic
