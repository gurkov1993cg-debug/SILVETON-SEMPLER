// SILVETON_MAC_VIEW_V1 - the SETTINGS page (tablet SilvetonSamplerView.kt lines 2723-2928 and 3388-3470)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
int roundToInt(float v) { return static_cast<int>(std::nearbyint(v)); }   // Kotlin round(x).toInt()
} // namespace

void SilvetonSamplerView::drawSettings(Canvas& c) {
    // SILVETON_GUI_V3: ОБЩИ / MIDI / SCALE · ТЕРЦА
    static const char* const tabs[] = {"ОБЩИ", "MIDI", "INFO"};
    for (int t = 0; t < 3; ++t) {
        const float ft = static_cast<float>(t);
        const RectF tr(112.0F + ft * 226.0F, 108.0F, 332.0F + ft * 226.0F, 146.0F);
        stripToggle(c, tr, tabs[t], settingsTab == t, C_AMBER, 14.0F);
        hit(tr, [this, t](float, float) {
            settingsTab = t;
            if (t == 2) bankInfoCache = sampler.bankInfo();
        });
    }
    if (settingsTab == 1) { drawMidiSettings(c, RectF(112.0F, 154.0F, 1326.0F, 786.0F)); return; }
    if (settingsTab == 2) { drawBankInfo(c, RectF(112.0F, 154.0F, 1326.0F, 786.0F)); return; }
    std::optional<GlobalUiState> gOpt = globalState;
    if (!gOpt) { gOpt = sampler.globalUiState(); if (gOpt) globalState = gOpt; }
    if (!gOpt) return;
    const GlobalUiState g = *gOpt;
    const RectF b(112.0F, 154.0F, 1326.0F, 786.0F);
    board(c, b);
    static const char* const labels[] = {"MASTER TUNE", "TRANSPOSE", "MASTER GAIN", "EQ LOW", "EQ MID", "EQ HIGH", "LIMITER", "CEILING",
                                         "VELOCITY CURVE", "BREATH CC", "EXPRESSION CC", "DAMPER CC", "PITCH BEND", "AFTERTOUCH", "ТЕМА",   // SILVETON_THEME_V1
                                         "ГЛАСОВЕ"};   // SILVETON_VOICE_CEILING_V1
    const int count = 16;   // SILVETON_ONLY_OLD_V1: the "НОВИ ТЕМИ" cell is gone, the old look has no way back to the new screens
    const int cols = 6;
    const float gap = 10.0F;
    const float cw = (b.width() - 32.0F - gap * static_cast<float>(cols - 1)) / static_cast<float>(cols);
    const int rows = (count + cols - 1) / cols;
    const float ch = (b.height() - 32.0F - gap * static_cast<float>(rows - 1)) / static_cast<float>(rows);
    for (int i = 0; i < count; ++i) {
        const float col = static_cast<float>(i % cols);
        const float row = static_cast<float>(i / cols);
        const RectF rr(b.left + 16.0F + col * (cw + gap), b.top + 16.0F + row * (ch + gap),
                       b.left + 16.0F + col * (cw + gap) + cw, b.top + 16.0F + row * (ch + gap) + ch);
        section(c, rr, labels[i]);
        const float cx = rr.centerX();
        const float cy = rr.top + 98.0F;
        switch (i) {
            case 14: {   // SILVETON_THEME_V1: СВЕТЛА / ТЪМНА
                const RectF a(rr.left + 14.0F, rr.top + 56.0F, cx - 4.0F, rr.top + 146.0F);
                const RectF bb(cx + 4.0F, rr.top + 56.0F, rr.right - 14.0F, rr.top + 146.0F);
                stripToggle(c, a, "СВЕТЛА", !darkTheme, C_AMBER, 16.0F);
                stripToggle(c, bb, "ТЪМНА", darkTheme, C_AMBER, 16.0F);
                hit(a, [this](float, float) { sampler.setThemeDark(false); applyTheme(false); woodBitmap_.reset(); invalidate(); });
                hit(bb, [this](float, float) { sampler.setThemeDark(true); applyTheme(true); invalidate(); });
                break;
            }
            case 15: {   // SILVETON_VOICE_CEILING_V1: how many notes may sound at once
                const int ceiling = sampler.voiceCeiling();
                const RectF key(cx - 80.0F, rr.top + 56.0F, cx + 80.0F, rr.top + 146.0F);
                switchKey(c, key, ceiling >= 128 ? std::string("ВСИЧКИ") : std::to_string(ceiling), "", ceiling < 128);
                hit(rr, [this, ceiling](float, float) {
                        showNumber("ГЛАСОВЕ", static_cast<float>(ceiling), 8.0F, 128.0F, 0, [this](float nv) {
                            sampler.setVoiceCeiling(static_cast<int>(nv));
                            invalidate();
                        });
                    },
                    [this]() { sampler.setVoiceCeiling(128); invalidate(); });
                break;
            }
            case 6: case 12: case 13: {
                const bool on = i == 6 ? g.limiterEnabled : (i == 12 ? g.pitchBendEnabled : g.aftertouchEnabled);
                const RectF key(cx - 80.0F, rr.top + 56.0F, cx + 80.0F, rr.top + 146.0F);
                switchKey(c, key, on ? "ON" : "OFF", "", on);
                hit(rr, [this, i, g](float, float) { editGlobal(i, g); }, [this, i, g]() { resetGlobal(i, g); });
                break;
            }
            default: {
                const std::array<float, 3> spec = globalSliderSpec(i, g);
                const bool bipolar = i == 0 || i == 1 || (i >= 3 && i <= 5);
                knobControl(c, cx, cy, 34.0F, spec[0], spec[1], spec[2], globalStep(i), globalTravel(i), bipolar,
                            globalValueText(i, g), "", cw - 10.0F,
                            [this, i, g](float nv) { commitGlobal(globalWithSliderValue(i, globalState ? *globalState : g, nv)); },
                            [this, i, g]() { editGlobal(i, globalState ? *globalState : g); },
                            [this, i, g]() { resetGlobal(i, globalState ? *globalState : g); });
                break;
            }
        }
    }
}

// SILVETON_BANK_INFO_V1: what is in SILVETON_BANK.sv, DELETE of whole SOUNDs.
std::string SilvetonSamplerView::mb(long long bytes) { return fmtFixed(static_cast<double>(bytes) / 1048576.0, 1) + " MB"; }

void SilvetonSamplerView::drawBankInfo(Canvas& c, const RectF& b) {
    board(c, b);
    if (!bankInfoCache) bankInfoCache = sampler.bankInfo();
    const RectF box(b.left + 24.0F, b.top + 24.0F, b.left + 640.0F, b.top + 300.0F);
    lcd(c, box);
    if (!bankInfoCache) {
        text(c, "SILVETON_BANK.sv НЕ Е НАМЕРЕН", box.left + 24.0F, box.top + 60.0F, 22.0F, C_LCD_BAD, Opt().mono());
        return;
    }
    const Ctrl::BankInfo info = *bankInfoCache;
    const std::pair<std::string, std::string> rows[] = {
        {"ЗВУЦИ (SOUND)", std::to_string(info.sounds)},
        {"СЕМПЛИ", std::to_string(info.samples)},
        {"АУДИО", mb(info.audioBytes)},
        {"ФАЙЛ", mb(info.fileBytes)}};
    for (int k = 0; k < 4; ++k) {
        const float y = box.top + 56.0F + static_cast<float>(k) * 56.0F;
        text(c, rows[k].first, box.left + 24.0F, y, 14.0F, C_LCD_DIM, Opt().mono().spacing(0.15F));
        text(c, rows[k].second, box.right - 24.0F, y, 26.0F, C_LCD, Opt().right().mono());
    }
    text(c, info.path, b.left + 24.0F, box.bottom + 30.0F, 12.0F, C_BOARD_INK_SOFT, Opt().mono().maxW(b.width() - 48.0F));
    std::vector<Ctrl::BankSound> big = info.list;
    std::stable_sort(big.begin(), big.end(), [](const Ctrl::BankSound& x, const Ctrl::BankSound& y) { return x.bytes > y.bytes; });
    if (big.size() > 8U) big.resize(8U);
    const RectF side(b.left + 670.0F, b.top + 24.0F, b.right - 24.0F, b.top + 470.0F);
    section(c, side, "НАЙ-ГОЛЕМИ ЗВУЦИ");
    for (std::size_t k = 0; k < big.size(); ++k) {
        const Ctrl::BankSound& snd = big[k];
        const float y = side.top + 64.0F + static_cast<float>(k) * 48.0F;
        text(c, fmtZeroPad(snd.slot, 3) + "  " + snd.name, side.left + 20.0F, y, 17.0F, C_BOARD_INK, Opt().bold().maxW(side.width() - 190.0F));
        text(c, mb(snd.bytes), side.right - 20.0F, y, 17.0F, C_BOARD_INK_SOFT, Opt().right().monoBold());
    }
    const RectF delR(b.left + 24.0F, b.bottom - 90.0F, b.left + 520.0F, b.bottom - 30.0F);
    accentKey(c, delR, "ИЗБЕРИ ЗВУЦИ ЗА ТРИЕНЕ", true);
    hit(delR, [this, info](float, float) { showDeleteSounds(info); });
    const RectF refR(delR.right + 16.0F, b.bottom - 90.0F, delR.right + 236.0F, b.bottom - 30.0F);
    lightKey(c, refR, "ОБНОВИ", true, 16.0F);
    hit(refR, [this](float, float) { bankInfoCache = sampler.bankInfo(); invalidate(); });
}

void SilvetonSamplerView::showDeleteSounds(const Ctrl::BankInfo& info) {
    if (info.list.empty()) return;
    std::vector<std::string> labels;
    for (const auto& it : info.list) {
        labels.push_back(fmtZeroPad(it.slot, 3) + "   " + it.name + "   ·   " + std::to_string(it.samples) + " семпъла   ·   " + mb(it.bytes));
    }
    const std::vector<Ctrl::BankSound> list = info.list;
    showMultiChoice("ТРИЕНЕ НА ЗВУЦИ ОТ БАНКАТА", labels, [this, list](const std::vector<bool>& checked) {
        std::vector<Ctrl::BankSound> chosen;
        for (std::size_t k = 0; k < list.size(); ++k) if (k < checked.size() && checked[k]) chosen.push_back(list[k]);
        if (chosen.empty()) return;
        long long freed = 0;
        std::vector<int> slots;
        for (const auto& s : chosen) { freed += s.bytes; slots.push_back(s.slot); }
        showConfirm("ИЗТРИВАНЕ НА " + std::to_string(chosen.size()) + " ЗВУКА",
                    "Звуците се трият от SILVETON_BANK.sv завинаги (заедно със семплите, които само те ползват, до " + mb(freed) + ").\n" +
                        "Блендите, които ги ползват, остават без тях.\nДа изтрия ли?",
                    "ДА, ИЗТРИЙ", [this, slots]() { runDeleteSounds(slots); }, "НЕ");
    }, "ИЗТРИЙ", "CANCEL");
}

void SilvetonSamplerView::runDeleteSounds(const std::vector<int>& slots) {
    showWait("ТРИЕНЕ…", "Банката се записва наново. Не изключвай таблета.", [this, slots]() -> std::function<void()> {
        const std::optional<std::string> err = sampler.deleteBankSounds(slots);
        return [this, err, count = slots.size()]() {
            bankInfoCache = sampler.bankInfo();
            cachedCombiName = sampler.combiName();
            refreshAllUppers();
            refreshListCache();
            flash(!err ? "ИЗТРИТИ: " + std::to_string(count) + " ЗВУКА" : "ГРЕШКА: " + *err);
        };
    });
}

float SilvetonSamplerView::globalStep(int i) {
    switch (i) {
        case 1: case 8: case 9: case 10: case 11: return 1.0F;
        default: return 0.1F;
    }
}

float SilvetonSamplerView::globalTravel(int i) {
    switch (i) {
        case 0: return 400.0F;
        case 1: return 240.0F;
        case 2: return 390.0F;
        case 3: case 4: case 5: return 360.0F;
        case 7: return 240.0F;
        case 8: return 160.0F;
        default: return 508.0F;
    }
}

void SilvetonSamplerView::editGlobal(int i, const GlobalUiState& g) {
    switch (i) {
        case 0: showNumber("Master Tune Hz", g.masterTuneHz, 400.0F, 480.0F, 1, [this, g](float v) { GlobalUiState n = g; n.masterTuneHz = v; commitGlobal(n); }); break;
        case 1: showNumber("Transpose", static_cast<float>(g.transpose), -12.0F, 12.0F, 0, [this, g](float v) { GlobalUiState n = g; n.transpose = static_cast<int>(v); commitGlobal(n); }); break;
        case 2: showNumber("Master Gain dB", g.masterGainDb, -60.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.masterGainDb = v; commitGlobal(n); }); break;
        case 3: showNumber("EQ Low dB", g.eqLowDb, -18.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.eqLowDb = v; commitGlobal(n); }); break;
        case 4: showNumber("EQ Mid dB", g.eqMidDb, -18.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.eqMidDb = v; commitGlobal(n); }); break;
        case 5: showNumber("EQ High dB", g.eqHighDb, -18.0F, 18.0F, 1, [this, g](float v) { GlobalUiState n = g; n.eqHighDb = v; commitGlobal(n); }); break;
        case 6: flash("ЛИМИТЕРЪТ Е ВИНАГИ ВКЛЮЧЕН (ТАВАН -6 dB)"); break;
        case 7: showNumber("Limiter Ceiling", std::min(g.limiterCeilingDb, -6.0F), -12.0F, -6.0F, 1, [this, g](float v) { GlobalUiState n = g; n.limiterCeilingDb = v; commitGlobal(n); }); break;
        case 8: showNumber("Velocity Curve", static_cast<float>(g.velocityCurve), 0.0F, 4.0F, 0, [this, g](float v) { GlobalUiState n = g; n.velocityCurve = static_cast<int>(v); commitGlobal(n); }); break;
        case 9: showNumber("Breath CC", static_cast<float>(g.breathCc), 0.0F, 127.0F, 0, [this, g](float v) { GlobalUiState n = g; n.breathCc = static_cast<int>(v); commitGlobal(n); }); break;
        case 10: showNumber("Expression CC", static_cast<float>(g.expressionCc), 0.0F, 127.0F, 0, [this, g](float v) { GlobalUiState n = g; n.expressionCc = static_cast<int>(v); commitGlobal(n); }); break;
        case 11: showNumber("Damper CC", static_cast<float>(g.damperCc), 0.0F, 127.0F, 0, [this, g](float v) { GlobalUiState n = g; n.damperCc = static_cast<int>(v); commitGlobal(n); }); break;
        case 12: { GlobalUiState n = g; n.pitchBendEnabled = !g.pitchBendEnabled; commitGlobal(n); break; }
        case 13: { GlobalUiState n = g; n.aftertouchEnabled = !g.aftertouchEnabled; commitGlobal(n); break; }
        default: break;
    }
}

void SilvetonSamplerView::resetGlobal(int i, const GlobalUiState& g) {
    GlobalUiState n = g;
    switch (i) {
        case 0: n.masterTuneHz = 440.0F; break;
        case 1: n.transpose = 0; break;
        case 2: n.masterGainDb = 0.0F; break;
        case 3: n.eqLowDb = 0.0F; break;
        case 4: n.eqMidDb = 0.0F; break;
        case 5: n.eqHighDb = 0.0F; break;
        case 6: n.limiterEnabled = true; break;
        case 7: n.limiterCeilingDb = -6.0F; break;
        case 8: n.velocityCurve = 0; break;
        case 9: n.breathCc = 2; break;
        case 10: n.expressionCc = 11; break;
        case 11: n.damperCc = 64; break;
        case 12: n.pitchBendEnabled = true; break;
        default: n.aftertouchEnabled = true; break;
    }
    commitGlobal(n);
}

std::array<float, 3> SilvetonSamplerView::globalSliderSpec(int i, const GlobalUiState& g) {
    switch (i) {
        case 0: return {g.masterTuneHz, 400.0F, 480.0F};
        case 1: return {static_cast<float>(g.transpose), -12.0F, 12.0F};
        case 2: return {g.masterGainDb, -60.0F, 18.0F};
        case 3: return {g.eqLowDb, -18.0F, 18.0F};
        case 4: return {g.eqMidDb, -18.0F, 18.0F};
        case 5: return {g.eqHighDb, -18.0F, 18.0F};
        case 7: return {std::min(g.limiterCeilingDb, -6.0F), -12.0F, -6.0F};
        case 8: return {static_cast<float>(g.velocityCurve), 0.0F, 4.0F};
        case 9: return {static_cast<float>(g.breathCc), 0.0F, 127.0F};
        case 10: return {static_cast<float>(g.expressionCc), 0.0F, 127.0F};
        case 11: return {static_cast<float>(g.damperCc), 0.0F, 127.0F};
        default: return {0.0F, 0.0F, 1.0F};
    }
}

SilvetonSamplerView::GlobalUiState SilvetonSamplerView::globalWithSliderValue(int i, const GlobalUiState& g, float v) {
    GlobalUiState n = g;
    switch (i) {
        case 0: n.masterTuneHz = v; break;
        case 1: n.transpose = roundToInt(v); break;
        case 2: n.masterGainDb = v; break;
        case 3: n.eqLowDb = v; break;
        case 4: n.eqMidDb = v; break;
        case 5: n.eqHighDb = v; break;
        case 7: n.limiterCeilingDb = v; break;
        case 8: n.velocityCurve = roundToInt(v); break;
        case 9: n.breathCc = roundToInt(v); break;
        case 10: n.expressionCc = roundToInt(v); break;
        case 11: n.damperCc = roundToInt(v); break;
        default: break;
    }
    return n;
}

std::string SilvetonSamplerView::globalValueText(int i, const GlobalUiState& g) {
    const auto f2 = [](float v) { return fmtFixed(static_cast<double>(v), 2); };
    switch (i) {
        case 0: return f2(g.masterTuneHz) + " Hz";
        case 1: return signed_(g.transpose);
        case 2: return f2(g.masterGainDb) + " dB";
        case 3: return f2(g.eqLowDb) + " dB";
        case 4: return f2(g.eqMidDb) + " dB";
        case 5: return f2(g.eqHighDb) + " dB";
        case 7: return f2(g.limiterCeilingDb) + " dB";
        case 8: return std::to_string(g.velocityCurve);
        case 9: return "CC " + std::to_string(g.breathCc);
        case 10: return "CC " + std::to_string(g.expressionCc);
        case 11: return "CC " + std::to_string(g.damperCc);
        default: return "";
    }
}

/** SILVETON_MIDI_FULL_V1: every MIDI setting of the sampler on one page. */
void SilvetonSamplerView::drawMidiSettings(Canvas& c, const RectF& b) {
    board(c, b);
    std::optional<GlobalUiState> gOpt = globalState;
    if (!gOpt) { gOpt = sampler.globalUiState(); if (gOpt) globalState = gOpt; }
    if (!gOpt) return;
    const GlobalUiState g = *gOpt;
    const std::optional<Ctrl::GlobalAdvanced> aOpt = sampler.globalAdvanced();
    if (!aOpt) return;
    const Ctrl::GlobalAdvanced a = *aOpt;
    const float L = b.left + 16.0F;
    const float W = b.width() - 32.0F;
    // Row 1: MIDI channel of each Upper
    text(c, "MIDI КАНАЛ НА ВСЕКИ UPPER", L, b.top + 26.0F, 12.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F));
    const float uw = (W - 6.0F * 8.0F) / 7.0F;
    for (int i = 0; i < 7; ++i) {
        auto& slot = upperStates[static_cast<std::size_t>(i)];
        if (!slot) { slot = sampler.upperState(i); if (!slot) continue; }
        const UpperState st = *slot;
        const float fi = static_cast<float>(i);
        const RectF r(L + fi * (uw + 8.0F), b.top + 36.0F, L + fi * (uw + 8.0F) + uw, b.top + 96.0F);
        cellKey(c, r, "UPPER " + std::to_string(i + 1), "CH " + std::to_string(st.midiChannel + 1), [this, i, st]() {
            showNumber("UPPER " + std::to_string(i + 1) + " MIDI КАНАЛ", static_cast<float>(st.midiChannel + 1), 1.0F, 16.0F, 0, [this, i, st](float nv) {
                const auto& cur = upperStates[static_cast<std::size_t>(i)];
                UpperState next = cur ? *cur : st;
                next.midiChannel = std::clamp(roundToInt(nv), 1, 16) - 1;
                commitControlFor(i, next);   // ЛИНК: the marked Uppers get the same MIDI channel
            }, false);
        });
    }
    // Row 2: MIDI IN channels
    text(c, "MIDI IN - КОИ КАНАЛИ СЕ ПРИЕМАТ", L, b.top + 124.0F, 12.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F));
    const float cw = (W - 15.0F * 6.0F) / 16.0F;
    for (int ch = 0; ch < 16; ++ch) {
        const float fc = static_cast<float>(ch);
        const RectF r(L + fc * (cw + 6.0F), b.top + 134.0F, L + fc * (cw + 6.0F) + cw, b.top + 178.0F);
        const bool on = (a.midiInMask & (1 << ch)) != 0;
        stripToggle(c, r, std::to_string(ch + 1), on, C_AMBER, 15.0F);
        hit(r, [this, a, ch](float, float) {
            Ctrl::GlobalAdvanced n = a;
            n.midiInMask = a.midiInMask ^ (1 << ch);
            sampler.updateGlobalAdvanced(n);
            invalidate();
        });
    }
    // Row 3: filters + damper polarity
    text(c, "ФИЛТРИ (ON = СЕ ИГНОРИРА)", L, b.top + 206.0F, 12.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F));
    const float fw = (W - 4.0F * 8.0F) / 5.0F;
    struct Filter { const char* name; bool on; };
    const Filter filters[5] = {{"НОТИ", a.filterNotes}, {"CC", a.filterCc}, {"PITCH BEND", a.filterBend}, {"AFTERTOUCH", a.filterAftertouch}, {"ПЕДАЛ ОБЪРНАТ", a.damperReversed}};
    for (int k = 0; k < 5; ++k) {
        const float fk = static_cast<float>(k);
        const RectF r(L + fk * (fw + 8.0F), b.top + 216.0F, L + fk * (fw + 8.0F) + fw, b.top + 266.0F);
        cellKey(c, r, filters[k].name, "", [this, a, k]() {
            Ctrl::GlobalAdvanced n = a;
            switch (k) {
                case 0: n.filterNotes = !a.filterNotes; break;
                case 1: n.filterCc = !a.filterCc; break;
                case 2: n.filterBend = !a.filterBend; break;
                case 3: n.filterAftertouch = !a.filterAftertouch; break;
                default: n.damperReversed = !a.damperReversed; break;
            }
            sampler.updateGlobalAdvanced(n);
        }, filters[k].on);
    }
    // Rows 4/5: BREATH, EXPRESSION, DAMPER, VELOCITY, BEND, AFTERTOUCH
    text(c, "КОНТРОЛЕРИ", L, b.top + 294.0F, 12.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F));
    const float kw = (W - 4.0F * 8.0F) / 5.0F;
    const auto row = [L, kw](float y, int k) {
        const float fk = static_cast<float>(k);
        return RectF(L + fk * (kw + 8.0F), y, L + fk * (kw + 8.0F) + kw, y + 62.0F);
    };
    const float y1 = b.top + 304.0F;
    const float y2 = b.top + 374.0F;
    const float y3 = b.top + 444.0F;
    const auto pct = [](float v) { return fmtFixed(static_cast<double>(v * 100.0F), 2) + " %"; };
    const auto f2 = [](float v) { return fmtFixed(static_cast<double>(v), 2); };
    const auto advNumber = [this, a](const std::string& title, float value, float lo, float hi, int decimals, std::function<void(Ctrl::GlobalAdvanced&, float)> set) {
        showNumber(title, value, lo, hi, decimals, [this, a, set](float v) {
            Ctrl::GlobalAdvanced n = a;
            set(n, v);
            sampler.updateGlobalAdvanced(n);
        }, false);
    };
    cellKey(c, row(y1, 0), "BREATH CC", "CC " + std::to_string(g.breathCc), [this, g]() { editGlobal(9, g); });
    cellKey(c, row(y1, 1), "BREATH MIN", pct(a.breathMin), [=]() { advNumber("BREATH MIN %", a.breathMin * 100.0F, 0.0F, 99.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.breathMin = v / 100.0F; }); });
    cellKey(c, row(y1, 2), "BREATH MAX", pct(a.breathMax), [=]() { advNumber("BREATH MAX %", a.breathMax * 100.0F, 1.0F, 100.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.breathMax = v / 100.0F; }); });
    cellKey(c, row(y1, 3), "BREATH CURVE", f2(a.breathCurve), [=]() { advNumber("BREATH CURVE", a.breathCurve, 0.1F, 8.0F, 2, [](Ctrl::GlobalAdvanced& n, float v) { n.breathCurve = v; }); });
    cellKey(c, row(y1, 4), "VELOCITY CURVE", std::to_string(g.velocityCurve), [this, g]() { editGlobal(8, g); });
    cellKey(c, row(y2, 0), "EXPRESSION CC", "CC " + std::to_string(g.expressionCc), [this, g]() { editGlobal(10, g); });
    cellKey(c, row(y2, 1), "EXPRESSION MIN", pct(a.expressionMin), [=]() { advNumber("EXPRESSION MIN %", a.expressionMin * 100.0F, 0.0F, 99.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.expressionMin = v / 100.0F; }); });
    cellKey(c, row(y2, 2), "EXPRESSION MAX", pct(a.expressionMax), [=]() { advNumber("EXPRESSION MAX %", a.expressionMax * 100.0F, 1.0F, 100.0F, 0, [](Ctrl::GlobalAdvanced& n, float v) { n.expressionMax = v / 100.0F; }); });
    cellKey(c, row(y2, 3), "EXPRESSION CURVE", f2(a.expressionCurve), [=]() { advNumber("EXPRESSION CURVE", a.expressionCurve, 0.1F, 8.0F, 2, [](Ctrl::GlobalAdvanced& n, float v) { n.expressionCurve = v; }); });
    cellKey(c, row(y2, 4), "DAMPER CC", "CC " + std::to_string(g.damperCc), [this, g]() { editGlobal(11, g); });
    cellKey(c, row(y3, 0), "PITCH BEND", "", [this, g]() { editGlobal(12, g); }, g.pitchBendEnabled);
    cellKey(c, row(y3, 1), "AFTERTOUCH", "", [this, g]() { editGlobal(13, g); }, g.aftertouchEnabled);
    text(c, "Контролерите на всеки Upper (BREATH / EXPRESSION / AFTERTOUCH / ПЕДАЛ) са в КОМБИ → CONTROL.", L, b.bottom - 16.0F, 12.0F, C_BOARD_INK_SOFT,
         Opt().maxW(W));
}

} // namespace silveton::ui::classic
