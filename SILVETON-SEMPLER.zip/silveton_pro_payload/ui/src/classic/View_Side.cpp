// SILVETON_NEW_LOOK_V1 - the left wooden menu and the big header are gone: the frame is the top bar and the bottom menu (View_Look.cpp).
#include "silveton/ui/classic/SilvetonSamplerView.h"

namespace silveton::ui::classic {

void SilvetonSamplerView::drawSideNav(Canvas& c) { drawBottomNav(c); }

void SilvetonSamplerView::drawHeader(Canvas& c) { drawTopBar(c); }

} // namespace silveton::ui::classic
