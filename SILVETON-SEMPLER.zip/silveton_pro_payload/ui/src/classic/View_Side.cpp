// SILVETON_MAC_VIEW_V1 - side navigation and the header (tablet SilvetonSamplerView.kt lines 734-927)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
int roundToInt(float v) { return static_cast<int>(std::nearbyint(v)); }   // Kotlin round(x).toInt()
} // namespace

void SilvetonSamplerView::drawSideNav(Canvas& c) {
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    if (darkTheme) {   // SILVETON_THEME_V1: walnut side like a real synthesizer
        paint.shader = nullptr;
        c.drawImage(*wood(), RectF(0.0F, 0.0F, 96.0F, DESIGN_H), paint);
        line(c, 96.0F, 0.0F, 96.0F, DESIGN_H, Color::rgb(10, 8, 6), 3.0F);
        line(c, 98.0F, 0.0F, 98.0F, DESIGN_H, Color::rgb(120, 124, 134), 1.0F);
    } else {
        paint.shader = linearGradient(0.0F, 0.0F, 96.0F, 0.0F, C_SIDE_A, C_SIDE_B, TileMode::Clamp);
        c.drawRect(RectF(0.0F, 0.0F, 96.0F, DESIGN_H), paint);
    }
    paint.shader = linearGradient(96.0F, 0.0F, 104.0F, 0.0F, Color::argb(80, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawRect(RectF(96.0F, 0.0F, 104.0F, DESIGN_H), paint);
    paint.shader = nullptr;

    c.save();
    c.rotate(90.0F, 48.0F, 66.0F);   // SILVETON_GUI_V3: reads top to bottom
    text(c, "SILVETON", 48.0F, 70.0F, 13.0F, C_LOGO, Opt().center().bold().spacing(0.23F));
    c.restore();

    const std::pair<Page, const char*> labels[] = {
        {Page::LIST, "ЛИСТ"}, {Page::COMBI, "КОМБИ"}, {Page::EFFECTS, "ЕФЕКТИ"}, {Page::SETTINGS, "НАСТРОЙКИ"}};
    for (int i = 0; i < 4; ++i) {
        const Page p = labels[i].first;
        const std::string label = labels[i].second;
        const RectF b(10.0F, 128.0F + static_cast<float>(i) * 104.0F, 86.0F, 224.0F + static_cast<float>(i) * 104.0F);
        const bool on = page_ == p;
        navKey(c, b, on);
        led(c, b.centerX(), b.centerY() - 14.0F, on, 5.0F);
        text(c, label, b.centerX(), b.centerY() + 22.0F, 11.0F, on ? C_NAV_ON_TEXT : C_NAV_TEXT,
             Opt().center().face(on ? Face::Bold : Face::Regular).spacing(0.06F).maxW(70.0F));
        hit(b, [this, p](float, float) {
            page_ = p;
            if (p == Page::LIST) refreshListCache();
            if (p == Page::COMBI) cachedCombiName = sampler.combiName();
            if (p == Page::EFFECTS) refreshFx();
            if (p == Page::SETTINGS) refreshGlobal();
        });
    }

    const RectF gear(10.0F, 734.0F, 86.0F, 786.0F);
    navKey(c, gear, page_ == Page::SETTINGS);
    drawGear(c, gear.centerX(), gear.centerY(), 11.0F);
    hit(gear, [this](float, float) { page_ = Page::SETTINGS; refreshGlobal(); });
}

void SilvetonSamplerView::drawHeader(Canvas& c) {
    const Ctrl::AudioStatus a = frameAudioStatus;
    const Ctrl::MidiStatus m = frameMidiStatus;
    const std::int64_t now = nowMs();
    const bool midiRx = now < midiFlashUntilMs;
    const bool keyFlash = midiRx && (m.status & 0xF0) == 0x90 && m.data2 > 0;
    const bool midiConnected = std::max(midiConnections, m.deviceCount) > 0;
    std::string midiValue;
    if (keyFlash) midiValue = midiNoteName(m.data1);
    else if (midiRx) midiValue = "RX";
    else if (midiConnected) midiValue = "ON";
    else if (m.lastError != 0) midiValue = "E" + std::to_string(-m.lastError);
    else midiValue = "OFF";

    const bool running = sampler.audioRunning();
    const int lastAudioError = sampler.audioLastError();
    // SILVETON_HALF_RATE_V1: the proven profile, or any other the chip gave us (two portions)
    const bool classicAudio = a.sampleRate == 96000 && a.framesPerBurst == 96 && a.bufferSizeFrames == 192;
    const bool audioOk = running && (classicAudio ||
        (a.sampleRate >= 44100 && a.framesPerBurst >= 16 && a.framesPerBurst <= 512 && a.bufferSizeFrames == a.framesPerBurst * 2));
    bool audioSignal = a.activeVoices > 0;
    for (const auto& pr : frameUpperMeters) if (pr.first > 0.0001F || pr.second > 0.0001F) audioSignal = true;
    std::string audioValue;
    if (audioOk && classicAudio) audioValue = "96k 96x2";
    else if (audioOk) audioValue = std::to_string(a.sampleRate / 1000) + "k " + std::to_string(a.framesPerBurst) + "x" + std::to_string(a.bufferSizeFrames / std::max(1, a.framesPerBurst));
    else if (running) audioValue = std::to_string(a.sampleRate / 1000) + "k " + std::to_string(a.framesPerBurst);
    else if (lastAudioError != 0) audioValue = "OFF E" + std::to_string(-lastAudioError);
    else audioValue = "OFF";

    // Big LCD: where you are and what is loaded.
    const bool isList = page_ == Page::LIST;
    const RectF big = isList ? RectF(112.0F, 14.0F, 560.0F, 96.0F) : RectF(112.0F, 14.0F, 672.0F, 96.0F);
    lcd(c, big);
    const std::string slotText = editingCombiSlot ? fmtZeroPad(*editingCombiSlot, 3) : "---";
    const std::optional<ListItem> activeItem = realListItem(cachedActiveListEntry);
    std::string line1;
    switch (page_) {
        case Page::COMBI:
            line1 = "КОМБИ " + slotText + (loadedFromList >= 0 ? " · ЛИСТ " + fmtZeroPad(loadedFromList + 1, 3) : std::string());
            break;
        case Page::LIST:
            if (!listSearch.empty()) {
                line1 = "ЛИСТ · ТЪРСЕНЕ: " + utf8Upper(listSearch);
            } else if (listFavOnly) {
                line1 = "ЛИСТ · ЛЮБИМИ · " + std::to_string(listFavs.size());
            } else {
                int used = 0;
                for (const auto& it : cachedListItems) if (!sampler.isEmptyListItem(it)) ++used;
                line1 = "ЛИСТ · СТРАНИЦА " + std::to_string(listPage + 1) + " · " + std::to_string(used) + " / " + std::to_string(LIST_SIZE);
            }
            break;
        case Page::EFFECTS: line1 = "ЕФЕКТИ · КОМБИ " + slotText; break;
        case Page::SETTINGS: line1 = "НАСТРОЙКИ · ГЛОБАЛНИ"; break;
    }
    const std::string line2 = (page_ == Page::LIST && activeItem) ? fmtZeroPad(cachedActiveListEntry + 1, 3) + " " + activeItem->name : cachedCombiName;
    const bool flashOn = flashText.has_value() && now < flashUntilMs;
    text(c, flashOn ? *flashText : line1, big.left + 18.0F, big.top + 22.0F, 12.0F, flashOn ? C_LCD_OK : C_LCD_DIM,
         Opt().mono().spacing(0.25F).maxW(big.width() - 36.0F));
    text(c, line2, big.left + 18.0F, big.top + 60.0F, 32.0F, C_LCD, Opt().mono().maxW(big.width() - 36.0F));

    // Status LCD.
    const RectF st = isList ? RectF(572.0F, 14.0F, 1000.0F, 96.0F) : RectF(684.0F, 14.0F, 1206.0F, 96.0F);
    if (isList) {
        // SILVETON_LIST_V2: SAVE AS / LOAD / SEARCH / star live up here on the LIST page.
        const RectF saveR(1012.0F, 14.0F, 1108.0F, 52.0F); lightKey(c, saveR, "SAVE AS", true, 11.0F); hit(saveR, [this](float, float) { saveSetAs(); });
        const RectF loadR(1012.0F, 58.0F, 1108.0F, 96.0F); lightKey(c, loadR, "LOAD", true, 11.0F); hit(loadR, [this](float, float) { loadSet(); });
        const RectF findR(1120.0F, 14.0F, 1206.0F, 52.0F);
        stripToggle(c, findR, "ТЪРСИ", !listSearch.empty(), C_AMBER, 11.0F);
        hit(findR, [this](float, float) {
            if (!listSearch.empty()) { listSearch.clear(); listPage = 0; invalidate(); }
            else showTextPage("ТЪРСИ БЛЕНДА ПО ИМЕ", "", [this](const std::string& q) { listSearch = trimmed(q); listFavOnly = false; listPage = 0; invalidate(); });
        });
        const RectF favR(1120.0F, 58.0F, 1206.0F, 96.0F);
        stripToggle(c, favR, "★", listFavOnly, C_ACCENT, 18.0F);
        hit(favR, [this](float, float) { listFavOnly = !listFavOnly; listSearch.clear(); listPage = 0; invalidate(); });
    }
    if (isList) {
        lcd(c, st);
        const float colW = (st.width() - 32.0F) / 4.0F;
        auto cell = [&](int col, int row, const std::string& label, const std::string& value, ColorInt valueColor) {
            const float x = st.left + 16.0F + static_cast<float>(col) * colW;
            const float ly = st.top + 20.0F + static_cast<float>(row) * 38.0F;
            text(c, label, x, ly, 11.0F, C_LCD_DIM, Opt().mono().spacing(0.15F).maxW(colW - 6.0F));
            text(c, value, x, ly + 19.0F, 17.0F, valueColor, Opt().mono().maxW(colW - 6.0F));
        };
        cell(0, 0, "AUDIO", audioValue, audioOk ? C_LCD_OK : (running ? C_LCD_VALUE : C_LCD_BAD));
        cell(1, 0, "MIDI", midiValue, midiRx ? C_LCD : (midiConnected ? C_LCD_OK : C_LCD_VALUE));
        cell(2, 0, "ГЛАСОВЕ", std::to_string(a.activeVoices), audioSignal ? C_LCD : C_LCD_VALUE);
        cell(0, 1, "XRUN", std::to_string(a.xrunCount), a.xrunCount > 0 ? C_LCD_BAD : C_LCD_VALUE);
        cell(1, 1, "ЛАТЕНЦИЯ", a.estimatedLatencyMs >= 0.0 ? fmtFixed(a.estimatedLatencyMs, 2) + " ms" : "—", C_LCD_VALUE);
        cell(2, 1, "CPU", std::to_string(roundToInt(a.cpuLoadPercent)) + " % · " + std::to_string(a.coresWorking) + "я",
             a.cpuLoadPercent > 95.0F ? C_LCD_BAD : (a.cpuLoadPercent > 80.0F ? C_LCD : C_LCD_VALUE));
    } else {
        // SILVETON_STATUS_V2: SOUND - MASTER - PORTA boxes
        const RectF zv(684.0F, 14.0F, 926.0F, 96.0F);
        const RectF ms(934.0F, 14.0F, 1066.0F, 96.0F);
        const RectF po(1074.0F, 14.0F, 1206.0F, 96.0F);
        lcd(c, zv); lcd(c, ms); lcd(c, po);
        led(c, zv.left + 18.0F, zv.top + 18.0F, audioOk, 6.0F);
        if (!audioOk && running) led(c, zv.left + 18.0F, zv.top + 18.0F, true, 6.0F);
        text(c, audioOk ? std::string("ЗВУК OK") : "ЗВУК " + audioValue, zv.left + 32.0F, zv.top + 23.0F, 11.0F, audioOk ? C_LCD_OK : C_LCD_BAD,
             Opt().mono().spacing(0.2F).maxW(110.0F));
        text(c, a.estimatedLatencyMs >= 0.0 ? fmtFixed(a.estimatedLatencyMs, 2) + " ms" : "—", zv.left + 14.0F, zv.top + 66.0F, 30.0F, C_LCD, Opt().mono());
        const float cpu = a.cpuLoadPercent;
        const ColorInt cpuCol = cpu > 95.0F ? C_LCD_BAD : (cpu > 80.0F ? C_LCD : C_LCD_OK);
        // SILVETON_MULTICORE_V1: how many cores really share the sound right now
        text(c, "ЯДРА " + std::to_string(a.coresWorking), zv.left + 32.0F, zv.top + 40.0F, 11.0F,
             a.coresWorking > 1 ? C_LCD : C_LCD_DIM, Opt().mono().maxW(110.0F));
        text(c, "XRUN " + std::to_string(a.xrunCount), zv.left + 150.0F, zv.top + 23.0F, 11.0F, a.xrunCount > 0 ? C_LCD_BAD : C_LCD_DIM, Opt().mono());
        text(c, "MIDI " + midiValue, zv.left + 150.0F, zv.top + 40.0F, 11.0F, midiRx ? C_LCD : C_LCD_DIM, Opt().mono().maxW(86.0F));
        text(c, "CPU", zv.left + 150.0F, zv.top + 57.0F, 11.0F, C_LCD_DIM, Opt().mono());
        text(c, std::to_string(roundToInt(cpu)) + " %", zv.left + 186.0F, zv.top + 57.0F, 13.0F, cpuCol, Opt().monoBold());

        // voices bar 0..128
        const RectF vb(zv.left + 150.0F, zv.top + 62.0F, zv.right - 10.0F, zv.top + 67.0F);
        fill(c, vb, 3.0F, Color::rgb(40, 42, 40));
        fill(c, RectF(vb.left, vb.top, vb.left + vb.width() * std::clamp(static_cast<float>(a.activeVoices) / 128.0F, 0.0F, 1.0F), vb.bottom), 3.0F,
             a.activeVoices > 110 ? C_LCD_BAD : C_LCD_OK);
        text(c, std::to_string(a.activeVoices) + " ГЛ.", zv.left + 150.0F, zv.bottom - 4.0F, 11.0F, C_LCD_DIM, Opt().mono());
        hit(zv, [this](float, float) { page_ = Page::SETTINGS; settingsTab = 0; });
        // MASTER
        std::optional<GlobalUiState> g = globalState;
        if (!g) { g = sampler.globalUiState(); if (g) globalState = g; }
        const float master = g ? g->masterGainDb : -6.0F;
        text(c, "MASTER", ms.left + 12.0F, ms.top + 22.0F, 11.0F, C_LCD_DIM, Opt().mono().spacing(0.2F));
        text(c, fmtFixed(static_cast<double>(master), 2) + " dB", ms.left + 12.0F, ms.top + 56.0F, 24.0F, master > 0.0F ? C_LCD_BAD : C_LCD, Opt().mono());
        float pkMax = 0.0F;
        for (const auto& pr : frameUpperMeters) pkMax = std::max(pkMax, std::max(pr.first, pr.second));
        const float pk = std::max(pkMax, 0.0F);
        const RectF mb(ms.left + 12.0F, ms.bottom - 16.0F, ms.right - 12.0F, ms.bottom - 10.0F);
        fill(c, mb, 3.0F, Color::rgb(40, 42, 40));
        const float mt = std::clamp((20.0F * std::log10(std::max(pk, 1e-5F)) + 60.0F) / 60.0F, 0.0F, 1.0F);
        fill(c, RectF(mb.left, mb.top, mb.left + mb.width() * mt, mb.bottom), 3.0F, mt > 0.9F ? C_LCD_BAD : C_LCD_OK);
        hit(ms, [this, g](float, float) {
                if (g) {
                    const GlobalUiState gg = *g;
                    showNumber("MASTER dB", gg.masterGainDb, -60.0F, 18.0F, 1, [this, gg](float v) { GlobalUiState n = gg; n.masterGainDb = v; commitGlobal(n); });
                }
            },
            [this, g]() { if (g) { GlobalUiState n = *g; n.masterGainDb = -6.0F; commitGlobal(n); } });
        // PORTA of the selected Upper
        const std::vector<float> up = uParams(selectedUpper_);
        const int portaMode = std::clamp(roundToInt(at(up, 42U, 0.0F)), 0, 3);
        const bool kronos = portaMode >= 1;   // KRONOS, INSTRUMENT and BASS all use TIME 0..127
        static const char* const kPortaNames[4] = {"SILVETON", "KRONOS", "INSTRUMENT", "BASS"};   // SILVETON_BASS_PORTA_V1: the real name of the mode
        const auto& selState = upperStates[static_cast<std::size_t>(selectedUpper_)];
        const float porta = selState ? selState->portamentoSec : 0.0F;
        text(c, "PORTA U" + std::to_string(selectedUpper_ + 1) + " · " + kPortaNames[portaMode], po.left + 10.0F, po.top + 22.0F, 11.0F, C_LCD_DIM,
             Opt().mono().maxW(po.width() - 16.0F));
        std::string tv;
        if (kronos) { const int t = static_cast<int>(at(up, 45U, 0.0F)); tv = t <= 0 ? "OFF" : "TIME " + std::to_string(t); }
        else if (porta <= 0.0F) tv = "OFF";
        else tv = std::to_string(roundToInt(porta * 1000.0F)) + " ms";
        text(c, tv, po.left + 10.0F, po.top + 52.0F, 20.0F, C_LCD, Opt().mono().maxW(po.width() - 16.0F));
        std::string sub;
        if (kronos) sub = std::string(at(up, 43U, 0.0F) >= 0.5F ? "FINGERED" : "ВИНАГИ") + " · " + (at(up, 44U, 0.0F) >= 0.5F ? "RATE" : "TIME");
        else sub = "СЪСЕДНИ " + std::to_string(sampler.portaNear()) + " · BAL " + std::to_string(sampler.portaBalance());
        text(c, sub, po.left + 10.0F, po.top + 74.0F, 11.0F, C_LCD_VALUE, Opt().mono().maxW(po.width() - 16.0F));
        hit(po, [this](float, float) { page_ = Page::COMBI; tab = UpperTab::PORTA; });
    }

    // SILVETON_LIST_GRID_V1: BLENDS / WRITE / + LIST are gone - a COMBI is stored
    // from the LIST page (STORE), and changed with EDIT.

    const RectF panic(1218.0F, 14.0F, 1326.0F, 96.0F);
    const bool down = isDown(panic);
    if (!down) shadow(c, panic, 12.0F, 4.0F, 100);
    fillV(c, panic, 12.0F, down ? C_PANIC : Color::rgb(198, 52, 44), down ? Color::rgb(140, 28, 22) : C_PANIC);
    line(c, panic.left + 12.0F, panic.top + 1.5F, panic.right - 12.0F, panic.top + 1.5F, C_PANIC_TOP, 2.0F);
    text(c, "PANIC", panic.centerX(), panic.centerY() + 6.0F, 15.0F, Color::WHITE, Opt().center().bold().spacing(0.2F));
    hit(panic, [this](float, float) { sampler.panic(); });
}

} // namespace silveton::ui::classic
