#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SoloDefs.h"
#include <algorithm>
#include <cctype>

namespace silveton::ui::classic {
namespace sv=::silveton::sampler;
namespace so=::silveton::sampler::solo;

int SilvetonSamplerView::selectedSoloPart() const { return std::clamp(selectedUpper_,0,6); }
int SilvetonSamplerView::selectedSoloSound() const { return std::clamp(stripSound[static_cast<std::size_t>(selectedSoloPart())],0,4); }
void SilvetonSamplerView::showSoloPart(int upper,int sound) {
    if(upper<0||upper>=7||sound<0||sound>4)return;
    sampler.cancelKeyScan();
    picker.reset();selectSound(upper,sound);page_=Page::COMBI;combiMode_=MODE_EDIT;editGroup_=EG_WAVE;
    refreshEverything();invalidate();
}

// NativeActivity uses the same touch dialogs as the rest of the sampler.
// Browse folders without introducing a second sound catalog or engine selector.
void SilvetonSamplerView::chooseSoloModelFile(int upper, int sound, const std::string& directory) {
    if (upper < 0 || upper >= 7 || sound < 0 || sound > 4) return;
    if (!files::isDirectory(directory) || !files::readable(directory)) {
        showMessage("LOAD .svsolo", "Cannot read " + directory +
                    "\nAllow SILVETON SAMPLER access to all files in Android settings.");
        return;
    }
    std::vector<std::string> labels, paths;
    const auto parent = files::parentOf(directory);
    if (!parent.empty() && parent != directory) {
        labels.push_back("[..]  UP");
        paths.push_back(parent);
    }
    auto names = files::listNames(directory);
    std::sort(names.begin(), names.end());
    for (const auto& name : names) {
        if (name.empty() || name.front() == '.') continue;
        const auto path = files::join(directory, name);
        if (files::isDirectory(path)) { labels.push_back("[+]  " + name); paths.push_back(path); }
    }
    int models = 0;
    for (const auto& name : names) {
        auto lower = name;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        const auto path = files::join(directory, name);
        if (endsWith(lower, ".svsolo") && files::isFile(path)) {
            labels.push_back(name); paths.push_back(path); ++models;
        }
    }
    if(labels.empty()) {showMessage("LOAD .svsolo", "No .svsolo files or folders in " + directory);return;}
    showItems(std::string(models==0?"NO .svsolo · ":"LOAD .svsolo — ") + files::nameOf(directory), labels,
              [this, upper, sound, paths](int index) {
        if (index < 0 || index >= static_cast<int>(paths.size())) return;
        const auto path = paths[static_cast<std::size_t>(index)];
        if (files::isDirectory(path)) { chooseSoloModelFile(upper, sound, path); return; }
        showWait("LOADING .svsolo", files::nameOf(path), [this, upper, sound, path]() -> std::function<void()> {
            const auto error = sampler.loadSoloModelFile(upper, path, sound);
            return [this, upper, sound, error] {
                showSoloPart(upper, sound);
                if (error) showMessage("LOAD .svsolo", *error);
                else flash("TRAINED SOUND LOADED");
            };
        });
    });
}
// Only source colour lives here. All tuning, ADSR, filter, modulation, MIDI,
// voice/portamento, EQ and effects stay in the one existing Upper editor.
void SilvetonSamplerView::drawSoloSource(Canvas& c,int upper,int sound) {
    const auto source=sampler.soundSource(upper,sound);
    const bool canLoad=sampler.canChooseSoloModel();
    const RectF load(250,230,590,272),sounds(canLoad?604.F:250.F,230,1300,272);
    if(canLoad)nlBtn(c,load,"LOAD TRAINED .svsolo…",NlBtn::On,13,true);
    nlBtn(c,sounds,"CHOOSE SOUND…",NlBtn::Plain,13,true);
    if(canLoad)hit(load,[this,upper,sound](float,float){sampler.chooseSoloModel(upper,sound);});
    hit(sounds,[this,upper,sound](float,float){openPicker(upper,sound-1);});
    text(c,source.name,270,310,20,NL_VALUE,Opt().bold().maxW(1000));
    nlPanel(c,RectF(250,330,708,610),"CHARACTER / STEREO · DRAG THE POINT");
    const RectF pad(270,380,688,572);
    nlLcd(c,pad,6);
    for(int i=1;i<4;++i){
        const float x=pad.left+pad.width()*i/4,y=pad.top+pad.height()*i/4;
        line(c,x,pad.top,x,pad.bottom,Color::rgb(36,48,61),1);
        line(c,pad.left,y,pad.right,y,Color::rgb(36,48,61),1);
    }
    const float character=source.engine.p[so::MorphX],stereo=source.engine.p[so::MorphY];
    text(c,"STEREO "+fmtFixed(stereo*100,0)+" %",479,371,11,NL_TXT2,Opt().center().bold());
    text(c,source.soloModel?"MODEL":"STAVROS",270,596,11,NL_TXT2,Opt().bold());
    text(c,fmtFixed(character*100,0)+" %",479,596,11,NL_VALUE,Opt().center().bold());
    text(c,"DRUGO",688,596,11,NL_TXT2,Opt().right().bold());
    const float px=pad.left+pad.width()*character,py=pad.bottom-pad.height()*stereo;
    fill(c,RectF(px-9,py-9,px+9,py+9),9,NL_BLUE);
    fill(c,RectF(px-3,py-3,px+3,py+3),3,Color::WHITE);
    // LINK follows the same sound place in marked UPPERs. A sample in that
    // place has no SOLO character controls, so leave it intact.
    const auto setParam=[this,upper,sound](int id,float value){
        if (!sampler.setSourceParam(upper,sound,id,value)) return false;
        bool ok=true;
        for (const int target : linkTargets(upper)) {
            if (sampler.soundSource(target,sound).engine.type != sv::EngineType::Solo) continue;
            if (!sampler.setSourceParam(target,sound,id,value)) ok=false;
        }
        return ok;
    };
    const auto move=[this,setParam,pad](float x,float y){
        const bool a=setParam(so::MorphX,std::clamp((x-pad.left)/pad.width(),0.F,1.F));
        const bool b=setParam(so::MorphY,std::clamp((pad.bottom-y)/pad.height(),0.F,1.F));
        if(a&&b){soloSessionDirty();invalidate();}
    };
    hit(pad,move,[move,pad]{move(pad.left,pad.bottom);},[move](float x,float y,bool){move(x,y);});
    for(int id=so::Brightness;id<=so::Response;++id){
        const auto* def=so::parameter(id);if(!def)continue;
        const int index=id-so::Brightness;
        const float x=810+190.F*(index%3),y=index<3?382.F:526.F,value=source.engine.p[static_cast<std::size_t>(id)];
        const auto set=[this,setParam,id](float v){if(setParam(id,v)){soloSessionDirty();invalidate();}};
        neDial(c,x,y,70,def->label,fmtFixed(value*100,0)+" %",value,0,1,.005F,180,false,set,
            [this,value,set,def]{showNumber(def->label,value*100,0,100,0,[set](float v){set(v/100);});},[set,def]{set(def->def);},85);
    }
    text(c,linkOn?"LINK follows this sound place in marked UPPERs with a SYNTH source.":
         "This sound's CHARACTER / STEREO · UPPER voice, MIDI, EQ and effects are shared.",250,622,12,NL_TXT2,Opt().maxW(1040));
}
void SilvetonSamplerView::soloSessionDirty(){soloSaveDueMs_=nowMs()+1500;}
void SilvetonSamplerView::soloCheckSession(){
    if(soloSaveDueMs_&&nowMs()>=soloSaveDueMs_){
        if(sampler.soloSaveSession())soloSaveDueMs_=0;
        else {soloSaveDueMs_=nowMs()+5000;postInvalidateDelayed(5000);}
    }
    else if(soloSaveDueMs_)postInvalidateDelayed(300);
}
}
