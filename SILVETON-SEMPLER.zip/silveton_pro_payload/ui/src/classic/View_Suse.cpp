// SILVETON_NEW_LOOK_V1: the SILVETON SYNTH editor is drawn in the new look (black wells, blue values and curves, amber = on, dark lists); every control and touch is the same as before.
// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH on the ДВИГАТЕЛИ page (part 1: the tools, ОСЦИЛ., FM / PM, ФИЗИКА).
// Every control here is one number of the patch (core/include/silveton/sampler/SuseDefs.h). Its name, range and text come from
// SuseTools.h, the same place the sound and the tests use, so the screen can show nothing that the sound does not do.
// Drag = turn, tap = exact number, double tap = the starting value.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;
namespace sv = ::silveton::sampler;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
}  // namespace

// ---------------------------------------------------------------- the numbers
const std::vector<float>& SilvetonSamplerView::suP(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    if (static_cast<int>(slot->size()) < su::kParamCount + 1) {   // (a place that is not SILVETON SYNTH yet: the start sound, never read as a sound)
        static std::vector<float> fallback;
        if (fallback.empty()) { fallback.assign(static_cast<std::size_t>(su::kParamCount) + 1U, 0.0F); su::setDefaults(fallback.data() + 1); }
        return fallback;
    }
    return *slot;
}

float SilvetonSamplerView::suV(int u, int id) {
    const auto& a = suP(u);
    return id >= 0 && id < su::kParamCount ? a[static_cast<std::size_t>(id) + 1U] : 0.0F;
}

void SilvetonSamplerView::suSessionDirty() { suSaveDueMs_ = nowMs() + 1500; }

void SilvetonSamplerView::suCheckSession() {
    if (suSaveDueMs_ != 0 && nowMs() >= suSaveDueMs_) { suSaveDueMs_ = 0; sampler.suseSaveSession(); }
    else if (suSaveDueMs_ != 0) postInvalidateDelayed(300);
}

void SilvetonSamplerView::suSet(int u, int id, float v) {
    const float cv = su::clampParam(id, v);
    // A link with the type OFF does nothing, so a turned AMOUNT knob would feel dead: the type is chosen for the player
    // (PM when the changed generator is a WAVE, else AM) and the screen says so.
    if (id >= su::kLinkBase && id < su::kFilterBase && (id - su::kLinkBase) % 2 == 1 && cv > 0.0F && rI(suV(u, id - 1)) == su::L_OFF) {
        const int dst = (id - su::kLinkBase) / 2 / su::kGens;
        const int t = rI(suV(u, su::genId(dst, su::GN_METHOD))) == su::M_WAVE ? su::L_PM : su::L_AM;
        sampler.setUpperEngineParam(u, id - 1 + 1, static_cast<float>(t));
        auto& cache = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
        if (cache && static_cast<std::size_t>(id) < cache->size()) (*cache)[static_cast<std::size_t>(id - 1) + 1U] = static_cast<float>(t);
        suStatus_ = std::string("The kind of link was chosen automatically: ") + su::linkTypeName(t) + " (you can change it)";
        suStatusUntilMs_ = nowMs() + 4000;
    }
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id + 1, cv);
    const bool methodChange = id >= su::kGenBase && id < su::kLinkBase && (id - su::kGenBase) % su::kGenStride == su::GN_METHOD;
    if (!ok || methodChange) slot.reset();   // a new method loads its own starting knobs: read everything again
    else if (slot && static_cast<std::size_t>(id) + 1U < slot->size()) (*slot)[static_cast<std::size_t>(id) + 1U] = cv;
    suSessionDirty();
    invalidate();
}

void SilvetonSamplerView::suBlock(int u, int firstId, const std::vector<float>& values) {
    sampler.setUpperEngineBlock(u, firstId + 1, values);
    engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))].reset();
    suSessionDirty();
    invalidate();
}

void SilvetonSamplerView::suLoadPatch(int u, const float* patch) {
    std::vector<float> v(patch, patch + su::kParamCount);
    // the places' switches (E_SOURCE, bypass, bend) stay as the player has them
    const std::vector<float>& now = suP(u);
    for (int id : {su::E_SOURCE_ID, su::E_BYPASS_ID, su::E_BEND_UP_ID, su::E_BEND_DOWN_ID}) v[static_cast<std::size_t>(id)] = now[static_cast<std::size_t>(id) + 1U];
    suBlock(u, 0, v);
}

float SilvetonSamplerView::suDefault(int u, int id) {
    std::vector<float> t(static_cast<std::size_t>(su::kParamCount));
    su::setDefaults(t.data());
    if (id >= su::kGenBase && id < su::kLinkBase) {
        const int g = (id - su::kGenBase) / su::kGenStride, off = (id - su::kGenBase) % su::kGenStride;
        if (off >= su::GN_SEL1 && off <= su::GN_SEL4) { su::setMethod(t.data(), g, rI(suV(u, su::genId(g, su::GN_METHOD)))); }
        else if (off >= su::GN_F0 && off < su::GN_F0 + su::kGenFloats) { su::setMethod(t.data(), g, rI(suV(u, su::genId(g, su::GN_METHOD)))); }
    }
    return t[static_cast<std::size_t>(id)];
}

// ---------------------------------------------------------------- the controls
void SilvetonSamplerView::suKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, int id, const char* labelOverride) {
    const float* patch = suP(u).data() + 1;
    const char* nm = su::paramName(id, patch);
    if (nm == nullptr) return;
    if (labelOverride != nullptr) nm = labelOverride;
    const su::Disp d = su::paramDisp(id, patch);
    const float v = suV(u, id);
    const std::string label = nm;
    const std::string shown = su::dispText(d, v);
    if (d.kind == su::Disp::Whole) {
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, 1.0F, 260.0F, d.lo < 0.0F, shown, label, hw,
                    [this, u, id](float nv) { suSet(u, id, std::round(nv)); },
                    [this, u, id, v, label, d] { showNumber(label, v, d.lo, d.hi, 0, [this, u, id](float x) { suSet(u, id, std::round(x)); }); },
                    [this, u, id] { suSet(u, id, suDefault(u, id)); });
        return;
    }
    const bool bipolar = d.kind == su::Disp::PctBi || (d.kind == su::Disp::Lin && d.lo < 0.0F);
    float lo = d.lo, hi = d.hi;
    int dec = d.decimals;
    if (d.kind == su::Disp::Pct) { lo = 0.0F; hi = 100.0F; dec = 0; }
    else if (d.kind == su::Disp::PctBi) { lo = -100.0F; hi = 100.0F; dec = 0; }
    else if (d.kind == su::Disp::Time) { lo = 0.0F; hi = 10.0F; dec = 3; }
    knobControl(c, cx, cy, rad, v, 0.0F, 1.0F, 0.002F, 260.0F, bipolar, shown, label, hw,
                [this, u, id](float nv) { suSet(u, id, nv); },
                [this, u, id, d, v, label, lo, hi, dec] {
                    showNumber(label + std::string(d.unit), su::dispFromNorm(d, v), lo, hi, dec, [this, u, id, d](float x) { suSet(u, id, su::dispToNorm(d, x)); });
                },
                [this, u, id] { suSet(u, id, suDefault(u, id)); });
}

void SilvetonSamplerView::suChoice(Canvas& c, const RectF& r, int u, int id, int count, const std::function<std::string(int)>& nameOf, const std::string& label, int first) {
    const int cur = std::clamp(rI(suV(u, id)) - first, 0, std::max(0, count - 1));
    stripToggle(c, r, nameOf(cur), cur != 0 || first != 0, C_AMBER, 11.0F);
    text(c, count > 6 ? label + " ▼" : label, r.centerX(), r.bottom + 16.0F, 11.0F, NL_TXT2, Opt().center().spacing(0.1F).maxW(r.width() + 24.0F));
    if (count > 6) {
        std::vector<std::pair<std::string, std::string>> items;
        items.reserve(static_cast<std::size_t>(count));
        for (int k = 0; k < count; ++k) items.emplace_back(fmtZeroPad(k + first, 2), nameOf(k));
        const std::string title = label + " — choose from the list · touch outside the window = close";
        hit(r, [this, u, id, cur, items, title, first](float, float) {
                showGridPicker(title, items, cur, std::nullopt, [this, u, id, first](int k) { if (k >= 0) suSet(u, id, static_cast<float>(k + first)); });
                if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;
            },
            [this, u, id] { suSet(u, id, suDefault(u, id)); });
    } else {
        hit(r, [this, u, id, cur, count, first](float, float) { suSet(u, id, static_cast<float>(first + (cur + 1) % std::max(1, count))); },
            [this, u, id] { suSet(u, id, suDefault(u, id)); });
    }
}

void SilvetonSamplerView::suSeg(Canvas& c, const RectF& r, int u, int id, int count, const std::function<std::string(int)>& nameOf, int first) {
    const int cur = rI(suV(u, id)) - first;
    const float gap = 4.0F;
    const float w = (r.width() - gap * static_cast<float>(count - 1)) / static_cast<float>(std::max(1, count));
    for (int k = 0; k < count; ++k) {
        const RectF kr(r.left + static_cast<float>(k) * (w + gap), r.top, r.left + static_cast<float>(k) * (w + gap) + w, r.bottom);
        stripToggle(c, kr, nameOf(k), cur == k, C_ACCENT, 11.0F);
        hit(kr, [this, u, id, k, first](float, float) { suSet(u, id, static_cast<float>(k + first)); });
    }
}

void SilvetonSamplerView::suSwitch(Canvas& c, const RectF& r, int u, int id, const std::string& label, const std::string& onText, const std::string& offText) {
    const bool on = suV(u, id) >= 0.5F;
    stripToggle(c, r, on ? onText : offText, on, C_AMBER, 11.0F);
    text(c, label, r.centerX(), r.bottom + 16.0F, 11.0F, NL_TXT2, Opt().center().spacing(0.1F).maxW(r.width() + 24.0F));
    hit(r, [this, u, id, on](float, float) { suSet(u, id, on ? 0.0F : 1.0F); }, [this, u, id] { suSet(u, id, suDefault(u, id)); });
}

void SilvetonSamplerView::suPickWave(int u, std::function<void(int)> done, const std::string& title) {
    (void)u;
    std::vector<std::pair<std::string, std::string>> items;
    for (int k = 0; k < su::kWaveChoices; ++k) items.emplace_back(fmtZeroPad(k, 2), su::waveName(k));
    showGridPicker(title, items, -1, std::nullopt, [done](int k) { if (k >= 0) done(k); });
}

// ---------------------------------------------------------------- the generators row, the method panel
void SilvetonSamplerView::suGenRow(Canvas& c, const RectF& sec, int u, bool physicalOnly) {
    const float w = (sec.width() - 5.0F * 6.0F) / 6.0F;
    for (int g = 0; g < su::kGens; ++g) {
        const RectF r(sec.left + static_cast<float>(g) * (w + 6.0F), sec.top, sec.left + static_cast<float>(g) * (w + 6.0F) + w, sec.top + 42.0F);
        const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
        const bool phys = m == su::M_STRING || m == su::M_WIND || m == su::M_MODAL;
        const bool muted = suV(u, su::genId(g, su::GN_MUTE)) >= 0.5F && m != su::M_OFF;
        const bool sel = suGen_ == g;
        stripToggle(c, r, "", sel, C_ACCENT, 12.0F);
        // the words sit on a key: dark on the light (or dark-theme) key, light on the green one
        const ColorInt tc = sel ? Color::WHITE : Color::rgb(179, 187, 196);   // SILVETON_NEW_LOOK_V1: white on the blue key, light grey on the dark one
        const ColorInt warn = sel ? tc : NL_AMBER;
        text(c, "OSCILLATOR " + std::to_string(g + 1) + (muted ? " · MUTED" : ""), r.centerX(), r.top + 15.0F, 9.0F, muted ? warn : tc, Opt().center().bold().spacing(0.1F).maxW(w - 6.0F));
        text(c, std::string(su::methodName(m)) + (physicalOnly && !phys && m != su::M_OFF ? " ·" : ""), r.centerX(), r.top + 33.0F, 13.0F, tc, m == su::M_OFF ? Opt().center().maxW(w - 6.0F) : Opt().center().bold().maxW(w - 6.0F));
        hit(r, [this, g](float, float) { suGen_ = g; invalidate(); });
    }
}

// the choices (SEL1..4) and the own knobs of the generator's method
void SilvetonSamplerView::suGenMethod(Canvas& c, const RectF& area, int u, int g, bool segmented) {
    const float* patch = suP(u).data() + 1;
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    if (m == su::M_OFF) {
        text(c, "This oscillator is off. Choose a METHOD to make it sound.", area.centerX(), area.top + 90.0F, 15.0F, NL_TXT, Opt().center().maxW(area.width() - 30.0F));
        return;
    }
    text(c, su::methodHelp(m), area.left, area.bottom - 6.0F, 12.0F, NL_TXT2, Opt().maxW(area.width() - 4.0F));
    // the pictures of the waves are one tap away
    if (m == su::M_WAVE) {
        const RectF gr(area.left, area.top - 25.0F, area.left + 190.0F, area.top - 5.0F);
        stripToggle(c, gr, "PICTURES OF THE WAVES", false, C_ACCENT, 10.5F);
        hit(gr, [this, g](float, float) { suPickGen_ = g; suPage_ = 1; invalidate(); });
    }
    // the choices
    int nSel = 0;
    for (int s = su::GN_SEL1; s <= su::GN_SEL4; ++s) if (su::selLabel(m, s) != nullptr) ++nSel;
    float y = area.top;
    if (nSel > 0) {
        const float gap = 14.0F;
        const float w = (area.width() - gap * static_cast<float>(nSel - 1)) / static_cast<float>(nSel);
        int k = 0;
        for (int s = su::GN_SEL1; s <= su::GN_SEL4; ++s) {
            const char* lab = su::selLabel(m, s);
            if (lab == nullptr) continue;
            const int id = su::genId(g, s);
            const int count = su::selChoices(m, s);
            const RectF r(area.left + static_cast<float>(k) * (w + gap), y, area.left + static_cast<float>(k) * (w + gap) + w, y + 36.0F);
            const auto nameOf = [m, s](int ch) { return su::selChoiceName(m, s, ch); };
            if (segmented && count <= 7 && nSel == 1) { suSeg(c, r, u, id, count, nameOf); text(c, lab, r.centerX(), r.bottom + 16.0F, 11.0F, NL_TXT, Opt().center().spacing(0.1F)); }
            else suChoice(c, r, u, id, count, nameOf, lab);
            ++k;
        }
        y += 54.0F;
    }
    // the own knobs: up to 7 in a row
    int n = 0;
    for (int i = 0; i < su::kGenFloats; ++i) if (su::methodKnobName(m, i) != nullptr) ++n;
    if (n == 0) return;
    const int perRow = n <= 7 ? n : (n + 1) / 2;
    const float unit = area.width() / static_cast<float>(std::max(perRow, 1));
    int k = 0;
    for (int i = 0; i < su::kGenFloats; ++i) {
        if (su::methodKnobName(m, i) == nullptr) continue;
        const int row = k / perRow, col = k % perRow;
        const float cx = area.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = y + 30.0F + static_cast<float>(row) * 90.0F;
        suKnob(c, cx, cy, 16.0F, std::min(unit - 4.0F, 120.0F), u, su::genId(g, su::GN_F0 + i));
        ++k;
    }
    (void)patch;
}

// ---------------------------------------------------------------- ОСЦИЛ.: the generators of the graph (the simple start screen is in View_Suse4.cpp)
void SilvetonSamplerView::suPageOsc(Canvas& c, const RectF& sec, int u) {
    if (!suOscAdv_) { suPageOscSimple(c, sec, u); return; }
    suGenRow(c, sec, u, false);
    const int g = std::clamp(suGen_, 0, su::kGens - 1);
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    // sub pages and the keys that always matter
    const float y0 = sec.top + 52.0F, y1 = y0 + 34.0F;
    static const char* const subs[3] = {"SOUND AND WAVES", "PITCH AND LEVEL", "OSCILLATOR FILTER"};
    float x = sec.left;
    for (int i = 0; i < 3; ++i) {
        const float w = i == 2 ? 170.0F : 110.0F;
        const RectF r(x, y0, x + w, y1);
        stripToggle(c, r, subs[i], suSub_ == i, C_AMBER, 11.0F);
        hit(r, [this, i](float, float) { suSub_ = i; invalidate(); });
        x += w + 8.0F;
    }
    {   // the way back to the simple screen
        const RectF rb(x + 6.0F, y0, x + 116.0F, y1);
        stripToggle(c, rb, "◀ SIMPLE SCREEN", false, C_ACCENT, 10.5F);
        hit(rb, [this](float, float) { suOscAdv_ = false; invalidate(); });
    }
    {
        const RectF rm(sec.right - 372.0F, y0, sec.right - 202.0F, y1);
        // only the sound off and the wave are offered now: one tap switches between them, a long press gives the default back
        const int methodId = su::genId(g, su::GN_METHOD);
        const int curMethod = rI(suV(u, methodId));
        stripToggle(c, rm, su::methodName(curMethod), curMethod == su::M_WAVE, C_AMBER, 11.0F);
        text(c, "SOUND METHOD", rm.centerX(), rm.bottom + 16.0F, 11.0F, NL_TXT, Opt().center().spacing(0.1F).maxW(rm.width() + 24.0F));
        hit(rm, [this, u, methodId, curMethod](float, float) { suSet(u, methodId, static_cast<float>(curMethod == su::M_WAVE ? su::M_OFF : su::M_WAVE)); },
            [this, u, methodId] { suSet(u, methodId, suDefault(u, methodId)); });
        const RectF rr(sec.right - 192.0F, y0, sec.right - 82.0F, y1);
        suChoice(c, rr, u, su::genId(g, su::GN_ROUTE), su::kRoutes, [](int k) { return std::string(su::routeName(k)); }, "GOES THROUGH");
        const RectF rmu(sec.right - 74.0F, y0, sec.right, y1);
        suSwitch(c, rmu, u, su::genId(g, su::GN_MUTE), "MUTE", "YES", "NO");
    }
    const RectF area(sec.left, y1 + 28.0F, sec.right, sec.bottom);
    if (m == su::M_OFF && suSub_ != 0) {
        text(c, "This oscillator is off. Choose a METHOD (top right) to make it sound.", area.centerX(), area.top + 100.0F, 15.0F, NL_TXT, Opt().center().maxW(area.width() - 30.0F));
        return;
    }
    if (suSub_ == 0) { suGenMethod(c, area, u, g, false); return; }
    const float unit = area.width() / 9.0F;
    const float hw = unit - 4.0F;
    const auto cellX = [&](int col) { return area.left + unit * (static_cast<float>(col) + 0.5F); };
    const float yA = area.top + 26.0F, yB = area.top + 126.0F;
    const auto envName = [](int k) { return k == 0 ? std::string("NONE") : "ENV " + std::to_string(k); };
    if (suSub_ == 1) {
        const bool wave = m == su::M_WAVE;
        const bool fixed = suV(u, su::genId(g, su::GN_FIXED)) >= 0.5F;
        suKnob(c, cellX(0), yA, 16.0F, hw, u, su::genId(g, su::GN_LEVEL));
        suKnob(c, cellX(1), yA, 16.0F, hw, u, su::genId(g, su::GN_PAN));
        suKnob(c, cellX(2), yA, 16.0F, hw, u, su::genId(g, su::GN_OCT));
        suKnob(c, cellX(3), yA, 16.0F, hw, u, su::genId(g, su::GN_SEMI));
        suKnob(c, cellX(4), yA, 16.0F, hw, u, su::genId(g, su::GN_FINE));
        suSwitch(c, RectF(cellX(5) - 36.0F, yA - 20.0F, cellX(5) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FIXED), "FIXED", "YES", "NO");
        if (fixed) suKnob(c, cellX(6), yA, 16.0F, hw, u, su::genId(g, su::GN_FIXHZ)); else suKnob(c, cellX(6), yA, 16.0F, hw, u, su::genId(g, su::GN_RATIO));
        suKnob(c, cellX(7), yA, 16.0F, hw, u, su::genId(g, su::GN_VELLEV));
        suChoice(c, RectF(cellX(0) - 36.0F, yB - 20.0F, cellX(0) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_AMPENV), su::kEnvs + 1,
                 envName, "LEVEL FROM ENV.");
        suChoice(c, RectF(cellX(1) - 36.0F, yB - 20.0F, cellX(1) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_PENV), su::kEnvs + 1,
                 envName, "PITCH FROM ENV.");
        if (rI(suV(u, su::genId(g, su::GN_PENV))) > 0) suKnob(c, cellX(2), yB, 16.0F, hw, u, su::genId(g, su::GN_PENVAMT));
        if (wave) {
            suChoice(c, RectF(cellX(3) - 36.0F, yB - 20.0F, cellX(3) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_UNISON), 4, [](int k) { return std::to_string(k + 1); }, "UNISON", 1);
            suKnob(c, cellX(4), yB, 16.0F, hw, u, su::genId(g, su::GN_UNIDET));
            suKnob(c, cellX(5), yB, 16.0F, hw, u, su::genId(g, su::GN_UNISPR));
            suKnob(c, cellX(6), yB, 16.0F, hw, u, su::genId(g, su::GN_PHASE));
            suSwitch(c, RectF(cellX(7) - 36.0F, yB - 20.0F, cellX(7) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_SYNC), "SYNC", "YES", "NO");
            if (suV(u, su::genId(g, su::GN_SYNC)) >= 0.5F) suKnob(c, cellX(8), yB, 16.0F, hw, u, su::genId(g, su::GN_SYNCR));
        } else {
            text(c, "Unison (copy), phase and sync exist only in the WAVE method.", cellX(3) - 40.0F, yB + 4.0F, 12.0F, NL_TXT2, Opt().maxW(area.right - cellX(3)));
        }
    } else {
        suChoice(c, RectF(cellX(0) - 36.0F, yA - 20.0F, cellX(0) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FTYPE), su::kOwnFilters, [](int k) { return std::string(su::ownFilterName(k)); }, "FILTER TYPE");
        if (rI(suV(u, su::genId(g, su::GN_FTYPE))) != su::OF_OFF) {
            suKnob(c, cellX(1), yA, 16.0F, hw, u, su::genId(g, su::GN_FCUT));
            suKnob(c, cellX(2), yA, 16.0F, hw, u, su::genId(g, su::GN_FRES));
            suKnob(c, cellX(3), yA, 16.0F, hw, u, su::genId(g, su::GN_FKEY));
            suChoice(c, RectF(cellX(4) - 36.0F, yA - 20.0F, cellX(4) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FENV), su::kEnvs + 1,
                     envName, "WHICH ENVELOPE");
            if (rI(suV(u, su::genId(g, su::GN_FENV))) > 0) suKnob(c, cellX(5), yA, 16.0F, hw, u, su::genId(g, su::GN_FENVAMT));
            text(c, su::filterTypeHelp(rI(suV(u, su::genId(g, su::GN_FTYPE)))), area.left, area.bottom - 8.0F, 12.0F, NL_TXT2, Opt().maxW(area.width()));
        } else {
            text(c, "Every oscillator can have its own filter. Besides it there are two shared ones (FILTERS page).", cellX(1) - 30.0F, yA + 4.0F, 13.0F, NL_TXT2, Opt().maxW(area.right - cellX(1) + 20.0F));
        }
    }
}

// ---------------------------------------------------------------- FM / PM: the links between the generators
void SilvetonSamplerView::suPageLinks(Canvas& c, const RectF& sec, int u) {
    suLinkDst_ = std::clamp(suLinkDst_, 0, su::kGens - 1);
    suLinkSrc_ = std::clamp(suLinkSrc_, 0, su::kGens - 1);
    // the matrix: a row = the generator that is changed, a column = the one that changes it
    const float labW = 62.0F, cw = 70.0F, ch = 40.0F, top = sec.top + 36.0F;
    text(c, "COLUMN = WHO CHANGES  ·  ROW = WHO IS CHANGED", sec.left + 2.0F, sec.top + 12.0F, 10.0F, NL_BLUE, Opt().bold().spacing(0.1F).maxW(labW + 6.0F * cw));
    for (int s = 0; s < su::kGens; ++s) text(c, "OSC " + std::to_string(s + 1), sec.left + labW + static_cast<float>(s) * cw + cw * 0.5F, sec.top + 30.0F, 12.0F, NL_VALUE, Opt().center().bold());
    for (int d = 0; d < su::kGens; ++d) {
        const float y = top + static_cast<float>(d) * (ch + 3.0F);
        const int md = rI(suV(u, su::genId(d, su::GN_METHOD)));
        text(c, "OSC " + std::to_string(d + 1), sec.left + 2.0F, y + 25.0F, 12.0F, md == su::M_OFF ? NL_TXT2 : NL_VALUE, Opt().bold());
        for (int s = 0; s < su::kGens; ++s) {
            const RectF r(sec.left + labW + static_cast<float>(s) * cw, y, sec.left + labW + static_cast<float>(s) * cw + cw - 3.0F, y + ch);
            const int t = rI(suV(u, su::linkType(d, s)));
            const float amt = suV(u, su::linkAmt(d, s));
            const bool sel = d == suLinkDst_ && s == suLinkSrc_;
            nlLcd(c, r, 6.0F);   // SILVETON_NEW_LOOK_V1: a black cell, a blue tint when a link is set, a blue frame for the chosen one
            if (t != 0) fill(c, r, 6.0F, Color::argb(46, 51, 160, 255));
            if (sel) strokeRR(c, r, 6.0F, NL_BLUE, 2.0F);
            if (t != 0) {
                text(c, su::linkTypeName(t), r.centerX(), r.top + 17.0F, 12.0F, NL_VALUE, Opt().center().bold().maxW(r.width() - 4.0F));
                fill(c, RectF(r.left + 8.0F, r.top + 26.0F, r.left + 8.0F + (r.width() - 16.0F) * amt, r.top + 31.0F), 2.0F, NL_BLUE);
            } else if (d == s) text(c, "·", r.centerX(), r.centerY() + 5.0F, 14.0F, NL_TXT2, Opt().center());
            hit(r, [this, d, s](float, float) { suLinkDst_ = d; suLinkSrc_ = s; invalidate(); });
        }
    }
    // the chosen link
    const float L = sec.left + labW + 6.0F * cw + 22.0F, R = sec.right;
    const int d = suLinkDst_, s = suLinkSrc_;
    const int md = rI(suV(u, su::genId(d, su::GN_METHOD)));
    const int ms = rI(suV(u, su::genId(s, su::GN_METHOD)));
    text(c, "OSC " + std::to_string(d + 1) + " ← OSC " + std::to_string(s + 1), L, sec.top + 20.0F, 17.0F, NL_VALUE, Opt().bold().maxW(R - L));
    text(c, std::string(su::methodName(md)) + " ← " + su::methodName(ms), L, sec.top + 36.0F, 11.0F, NL_TXT, Opt().maxW(R - L));
    const int tNow = rI(suV(u, su::linkType(d, s)));
    const float kw = (R - L - 3.0F * 6.0F) / 4.0F;
    for (int t = 0; t < su::kLinkTypes; ++t) {
        if (t != su::L_OFF && t != su::L_PM) continue;   // only the link off and PM are shown now (the others are hidden, not removed)
        const bool waveOnly = t == su::L_PM || t == su::L_FM || t == su::L_SYNC || t == su::L_WARP;
        const bool usable = md == su::M_WAVE || !waveOnly;   // PM, FM, SYNC and WARP act on the wave generator only
        const RectF r(L + static_cast<float>(t % 4) * (kw + 6.0F), sec.top + 46.0F + static_cast<float>(t / 4) * 38.0F, L + static_cast<float>(t % 4) * (kw + 6.0F) + kw, sec.top + 76.0F + static_cast<float>(t / 4) * 38.0F);
        if (usable) {
            stripToggle(c, r, su::linkTypeName(t), tNow == t, C_ACCENT, 12.0F);
            hit(r, [this, u, d, s, t](float, float) { suSet(u, su::linkType(d, s), static_cast<float>(t)); });
        } else {
            nlBtn(c, r, su::linkTypeName(t), NlBtn::Off, 12.0F, false);   // SILVETON_NEW_LOOK_V1: a dim key (this link type needs a wave oscillator)
        }
    }
    {
        const auto lines = wrapLines(su::linkTypeHelp(tNow), 12.0F, Face::Regular, R - L);
        for (std::size_t i = 0; i < lines.size() && i < 2; ++i) text(c, lines[i], L, sec.top + 128.0F + static_cast<float>(i) * 15.0F, 12.0F, NL_VALUE, Opt());
        text(c, tNow == su::L_OFF ? "Choose a kind or just turn AMOUNT — the kind is chosen automatically." : "PM, FM, SYNC and BEND act only on an oscillator with the WAVE method.", L, sec.top + 160.0F, 10.0F, NL_TXT2, Opt().maxW(R - L));
        if (md == su::M_OFF || ms == su::M_OFF) {
            text(c, std::string("OSCILLATOR ") + std::to_string(md == su::M_OFF ? d + 1 : s + 1) + " is off — this link cannot be heard. Turn it on from the OSC page.", L, sec.top + 238.0F, 11.0F, NL_AMBER, Opt().bold().maxW(R - L));
        }
    }
    suKnob(c, L + 56.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::linkAmt(d, s));
    // the operator (the generator that is changed): its ratio and level
    const bool fixed = suV(u, su::genId(d, su::GN_FIXED)) >= 0.5F;
    if (fixed) suKnob(c, L + 166.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_FIXHZ));
    else suKnob(c, L + 166.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_RATIO));
    suKnob(c, L + 276.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_LEVEL));
    suSwitch(c, RectF(L + 340.0F, sec.top + 172.0F, R, sec.top + 206.0F), u, su::genId(d, su::GN_FIXED), "FIXED", "YES", "NO");
    suSwitch(c, RectF(L, sec.top + 262.0F, L + 110.0F, sec.top + 292.0F), u, su::genId(d, su::GN_MUTE), "MUTE OSC " + std::to_string(d + 1), "YES", "NO");
    suSwitch(c, RectF(L + 130.0F, sec.top + 262.0F, L + 240.0F, sec.top + 292.0F), u, su::genId(s, su::GN_MUTE), "MUTE OSC " + std::to_string(s + 1), "YES", "NO");
    text(c, "A muted oscillator is not heard, but it still changes the others.", L, sec.top + 328.0F, 10.0F, NL_TXT2, Opt().maxW(R - L));
}

// ---------------------------------------------------------------- ФИЗИКА: strings, tubes, reeds, modes
void SilvetonSamplerView::suPagePhysics(Canvas& c, const RectF& sec, int u) {
    suGenRow(c, sec, u, true);
    const int g = std::clamp(suGen_, 0, su::kGens - 1);
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    const bool phys = m == su::M_STRING || m == su::M_WIND || m == su::M_MODAL;
    const float y0 = sec.top + 58.0F;
    if (!phys) {
        text(c, "OSCILLATOR " + std::to_string(g + 1) + " is not physical. Make it:", sec.left + 4.0F, y0 + 20.0F, 15.0F, NL_VALUE, Opt().bold());
        static const int kinds[3] = {su::M_STRING, su::M_WIND, su::M_MODAL};
        static const char* const nm[3] = {"STRING (pluck, hammer, bow)", "WIND (clarinet, sax, zurna…)", "PERCUSSIVE BODY (bell, plate…)"};
        for (int i = 0; i < 3; ++i) {
            const RectF r(sec.left + 4.0F + static_cast<float>(i) * 290.0F, y0 + 40.0F, sec.left + 4.0F + static_cast<float>(i) * 290.0F + 280.0F, y0 + 84.0F);
            stripToggle(c, r, nm[i], false, C_AMBER, 12.0F);
            hit(r, [this, u, g, i](float, float) { suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(kinds[i])); });
        }
        text(c, "The string and the wind are a model of a delay line (waveguide), the percussive body is a set of resonators. Each can be excited by another oscillator (EXCITED BY).",
             sec.left + 4.0F, y0 + 120.0F, 12.0F, NL_TXT2, Opt().maxW(sec.width() - 8.0F));
        return;
    }
    suGenMethod(c, RectF(sec.left, y0, sec.right, sec.bottom - 22.0F), u, g, true);
    if (m == su::M_WIND) text(c, "The breath (BREATH FROM CONTROLLER) follows controller CC2; key velocity and CC11 are connected on the MOD. / MIDI page.", sec.left + 4.0F, sec.bottom - 6.0F, 11.0F, NL_TXT2, Opt().maxW(sec.width() - 8.0F));
    else text(c, "A string and a percussive body sound and fade by themselves (DECAY = how long). Turn a knob while holding a key — the strike repeats.", sec.left + 4.0F, sec.bottom - 6.0F, 11.0F, NL_TXT2, Opt().maxW(sec.width() - 8.0F));
}

} // namespace silveton::ui::classic
