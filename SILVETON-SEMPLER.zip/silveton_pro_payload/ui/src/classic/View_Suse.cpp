// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH on the ДВИГАТЕЛИ page (part 1: the tools, ОСЦИЛ., FM / PM, ФИЗИКА).
// Every control here is one number of the patch (core/include/silveton/sampler/SuseDefs.h). Its name, range and text come from
// SuseTools.h, the same place the sound and the tests use, so the screen can show nothing that the sound does not do.
// Drag = turn, tap = exact number, double tap = the starting value.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;
namespace sv = ::silveton::sampler;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
}  // namespace

// ---------------------------------------------------------------- the numbers
const std::vector<float>& SilvetonSamplerView::suP(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    if (static_cast<int>(slot->size()) < su::kParamCount + 1) {   // (a place that is not SILVETON SYNTH yet: the start sound, never read as a sound)
        static std::vector<float> fallback;
        if (fallback.empty()) { fallback.assign(static_cast<std::size_t>(su::kParamCount) + 1U, 0.0F); su::setDefaults(fallback.data() + 1); }
        return fallback;
    }
    return *slot;
}

float SilvetonSamplerView::suV(int u, int id) {
    const auto& a = suP(u);
    return id >= 0 && id < su::kParamCount ? a[static_cast<std::size_t>(id) + 1U] : 0.0F;
}

void SilvetonSamplerView::suSessionDirty() { suSaveDueMs_ = nowMs() + 1500; }

void SilvetonSamplerView::suCheckSession() {
    if (suSaveDueMs_ != 0 && nowMs() >= suSaveDueMs_) { suSaveDueMs_ = 0; sampler.suseSaveSession(); }
    else if (suSaveDueMs_ != 0) postInvalidateDelayed(300);
}

void SilvetonSamplerView::suSet(int u, int id, float v) {
    const float cv = su::clampParam(id, v);
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id + 1, cv);
    const bool methodChange = id >= su::kGenBase && id < su::kLinkBase && (id - su::kGenBase) % su::kGenStride == su::GN_METHOD;
    if (!ok || methodChange) slot.reset();   // a new method loads its own starting knobs: read everything again
    else if (slot && static_cast<std::size_t>(id) + 1U < slot->size()) (*slot)[static_cast<std::size_t>(id) + 1U] = cv;
    suSessionDirty();
    invalidate();
}

void SilvetonSamplerView::suBlock(int u, int firstId, const std::vector<float>& values) {
    sampler.setUpperEngineBlock(u, firstId + 1, values);
    engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))].reset();
    suSessionDirty();
    invalidate();
}

void SilvetonSamplerView::suLoadPatch(int u, const float* patch) {
    std::vector<float> v(patch, patch + su::kParamCount);
    // the places' switches (E_SOURCE, bypass, bend) stay as the player has them
    const std::vector<float>& now = suP(u);
    for (int id : {su::E_SOURCE_ID, su::E_BYPASS_ID, su::E_BEND_UP_ID, su::E_BEND_DOWN_ID}) v[static_cast<std::size_t>(id)] = now[static_cast<std::size_t>(id) + 1U];
    suBlock(u, 0, v);
}

float SilvetonSamplerView::suDefault(int u, int id) {
    std::vector<float> t(static_cast<std::size_t>(su::kParamCount));
    su::setDefaults(t.data());
    if (id >= su::kGenBase && id < su::kLinkBase) {
        const int g = (id - su::kGenBase) / su::kGenStride, off = (id - su::kGenBase) % su::kGenStride;
        if (off >= su::GN_SEL1 && off <= su::GN_SEL4) { su::setMethod(t.data(), g, rI(suV(u, su::genId(g, su::GN_METHOD)))); }
        else if (off >= su::GN_F0 && off < su::GN_F0 + su::kGenFloats) { su::setMethod(t.data(), g, rI(suV(u, su::genId(g, su::GN_METHOD)))); }
    }
    return t[static_cast<std::size_t>(id)];
}

// ---------------------------------------------------------------- the controls
void SilvetonSamplerView::suKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, int id) {
    const float* patch = suP(u).data() + 1;
    const char* nm = su::paramName(id, patch);
    if (nm == nullptr) return;
    const su::Disp d = su::paramDisp(id, patch);
    const float v = suV(u, id);
    const std::string label = nm;
    const std::string shown = su::dispText(d, v);
    if (d.kind == su::Disp::Whole) {
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, 1.0F, 260.0F, d.lo < 0.0F, shown, label, hw,
                    [this, u, id](float nv) { suSet(u, id, std::round(nv)); },
                    [this, u, id, v, label, d] { showNumber(label, v, d.lo, d.hi, 0, [this, u, id](float x) { suSet(u, id, std::round(x)); }); },
                    [this, u, id] { suSet(u, id, suDefault(u, id)); });
        return;
    }
    const bool bipolar = d.kind == su::Disp::PctBi || (d.kind == su::Disp::Lin && d.lo < 0.0F);
    float lo = d.lo, hi = d.hi;
    int dec = d.decimals;
    if (d.kind == su::Disp::Pct) { lo = 0.0F; hi = 100.0F; dec = 0; }
    else if (d.kind == su::Disp::PctBi) { lo = -100.0F; hi = 100.0F; dec = 0; }
    else if (d.kind == su::Disp::Time) { lo = 0.0F; hi = 10.0F; dec = 3; }
    knobControl(c, cx, cy, rad, v, 0.0F, 1.0F, 0.002F, 260.0F, bipolar, shown, label, hw,
                [this, u, id](float nv) { suSet(u, id, nv); },
                [this, u, id, d, v, label, lo, hi, dec] {
                    showNumber(label + std::string(d.unit), su::dispFromNorm(d, v), lo, hi, dec, [this, u, id, d](float x) { suSet(u, id, su::dispToNorm(d, x)); });
                },
                [this, u, id] { suSet(u, id, suDefault(u, id)); });
}

void SilvetonSamplerView::suChoice(Canvas& c, const RectF& r, int u, int id, int count, const std::function<std::string(int)>& nameOf, const std::string& label, int first) {
    const int cur = std::clamp(rI(suV(u, id)) - first, 0, std::max(0, count - 1));
    stripToggle(c, r, nameOf(cur), cur != 0 || first != 0, C_AMBER, 11.0F);
    text(c, label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 24.0F));
    if (count > 6) {
        std::vector<std::pair<std::string, std::string>> items;
        items.reserve(static_cast<std::size_t>(count));
        for (int k = 0; k < count; ++k) items.emplace_back(fmtZeroPad(k + first, 2), nameOf(k));
        const std::string title = label + " — избери · допир извън прозореца = затваряне";
        hit(r, [this, u, id, cur, items, title, first](float, float) {
                showGridPicker(title, items, cur, std::nullopt, [this, u, id, first](int k) { if (k >= 0) suSet(u, id, static_cast<float>(k + first)); });
                if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;
            },
            [this, u, id] { suSet(u, id, suDefault(u, id)); });
    } else {
        hit(r, [this, u, id, cur, count, first](float, float) { suSet(u, id, static_cast<float>(first + (cur + 1) % std::max(1, count))); },
            [this, u, id] { suSet(u, id, suDefault(u, id)); });
    }
}

void SilvetonSamplerView::suSeg(Canvas& c, const RectF& r, int u, int id, int count, const std::function<std::string(int)>& nameOf, int first) {
    const int cur = rI(suV(u, id)) - first;
    const float gap = 4.0F;
    const float w = (r.width() - gap * static_cast<float>(count - 1)) / static_cast<float>(std::max(1, count));
    for (int k = 0; k < count; ++k) {
        const RectF kr(r.left + static_cast<float>(k) * (w + gap), r.top, r.left + static_cast<float>(k) * (w + gap) + w, r.bottom);
        stripToggle(c, kr, nameOf(k), cur == k, C_ACCENT, 11.0F);
        hit(kr, [this, u, id, k, first](float, float) { suSet(u, id, static_cast<float>(k + first)); });
    }
}

void SilvetonSamplerView::suSwitch(Canvas& c, const RectF& r, int u, int id, const std::string& label, const std::string& onText, const std::string& offText) {
    const bool on = suV(u, id) >= 0.5F;
    stripToggle(c, r, on ? onText : offText, on, C_AMBER, 11.0F);
    text(c, label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 24.0F));
    hit(r, [this, u, id, on](float, float) { suSet(u, id, on ? 0.0F : 1.0F); }, [this, u, id] { suSet(u, id, suDefault(u, id)); });
}

void SilvetonSamplerView::suPickWave(int u, std::function<void(int)> done, const std::string& title) {
    (void)u;
    std::vector<std::pair<std::string, std::string>> items;
    for (int k = 0; k < su::kWaveChoices; ++k) items.emplace_back(fmtZeroPad(k, 2), su::waveName(k));
    showGridPicker(title, items, -1, std::nullopt, [done](int k) { if (k >= 0) done(k); });
}

// ---------------------------------------------------------------- the generators row, the method panel
void SilvetonSamplerView::suGenRow(Canvas& c, const RectF& sec, int u, bool physicalOnly) {
    const float w = (sec.width() - 5.0F * 6.0F) / 6.0F;
    for (int g = 0; g < su::kGens; ++g) {
        const RectF r(sec.left + static_cast<float>(g) * (w + 6.0F), sec.top, sec.left + static_cast<float>(g) * (w + 6.0F) + w, sec.top + 42.0F);
        const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
        const bool phys = m == su::M_STRING || m == su::M_WIND || m == su::M_MODAL;
        std::string label = std::to_string(g + 1) + "  " + su::methodName(m);
        if (physicalOnly && !phys && m != su::M_OFF) label += " ·";
        if (suV(u, su::genId(g, su::GN_MUTE)) >= 0.5F && m != su::M_OFF) label += "  (M)";
        stripToggle(c, r, label, suGen_ == g, C_ACCENT, 12.0F);
        hit(r, [this, g](float, float) { suGen_ = g; invalidate(); });
    }
}

// the choices (SEL1..4) and the own knobs of the generator's method
void SilvetonSamplerView::suGenMethod(Canvas& c, const RectF& area, int u, int g, bool segmented) {
    const float* patch = suP(u).data() + 1;
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    if (m == su::M_OFF) {
        text(c, "Този генератор е изключен. Избери метод (горе вдясно), за да звучи.", area.centerX(), area.top + 90.0F, 15.0F, C_KNOB_LABEL, Opt().center().maxW(area.width() - 30.0F));
        return;
    }
    // the choices
    int nSel = 0;
    for (int s = su::GN_SEL1; s <= su::GN_SEL4; ++s) if (su::selLabel(m, s) != nullptr) ++nSel;
    float y = area.top;
    if (nSel > 0) {
        const float gap = 14.0F;
        const float w = (area.width() - gap * static_cast<float>(nSel - 1)) / static_cast<float>(nSel);
        int k = 0;
        for (int s = su::GN_SEL1; s <= su::GN_SEL4; ++s) {
            const char* lab = su::selLabel(m, s);
            if (lab == nullptr) continue;
            const int id = su::genId(g, s);
            const int count = su::selChoices(m, s);
            const RectF r(area.left + static_cast<float>(k) * (w + gap), y, area.left + static_cast<float>(k) * (w + gap) + w, y + 36.0F);
            const auto nameOf = [m, s](int ch) { return su::selChoiceName(m, s, ch); };
            if (segmented && count <= 7 && nSel == 1) { suSeg(c, r, u, id, count, nameOf); text(c, lab, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F)); }
            else suChoice(c, r, u, id, count, nameOf, lab);
            ++k;
        }
        y += 54.0F;
    }
    // the own knobs: up to 7 in a row
    int n = 0;
    for (int i = 0; i < su::kGenFloats; ++i) if (su::methodKnobName(m, i) != nullptr) ++n;
    if (n == 0) return;
    const int perRow = n <= 7 ? n : (n + 1) / 2;
    const float unit = area.width() / static_cast<float>(std::max(perRow, 1));
    int k = 0;
    for (int i = 0; i < su::kGenFloats; ++i) {
        if (su::methodKnobName(m, i) == nullptr) continue;
        const int row = k / perRow, col = k % perRow;
        const float cx = area.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = y + 30.0F + static_cast<float>(row) * 90.0F;
        suKnob(c, cx, cy, 16.0F, std::min(unit - 4.0F, 120.0F), u, su::genId(g, su::GN_F0 + i));
        ++k;
    }
    (void)patch;
}

// ---------------------------------------------------------------- ОСЦИЛ.: the generators of the graph
void SilvetonSamplerView::suPageOsc(Canvas& c, const RectF& sec, int u) {
    suGenRow(c, sec, u, false);
    const int g = std::clamp(suGen_, 0, su::kGens - 1);
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    // sub pages and the keys that always matter
    const float y0 = sec.top + 52.0F, y1 = y0 + 34.0F;
    static const char* const subs[3] = {"ТОН", "МЕТОД", "СОБСТВЕН ФИЛТЪР"};
    float x = sec.left;
    for (int i = 0; i < 3; ++i) {
        const float w = i == 2 ? 170.0F : 110.0F;
        const RectF r(x, y0, x + w, y1);
        stripToggle(c, r, subs[i], suSub_ == i, C_AMBER, 11.0F);
        hit(r, [this, i](float, float) { suSub_ = i; invalidate(); });
        x += w + 8.0F;
    }
    {
        const RectF rm(sec.right - 330.0F, y0, sec.right - 170.0F, y1);
        suChoice(c, rm, u, su::genId(g, su::GN_METHOD), su::kMethods, [](int k) { return std::string(su::methodName(k)); }, "МЕТОД НА ГЕНЕРАТОРА");
        const RectF rr(sec.right - 162.0F, y0, sec.right - 82.0F, y1);
        suChoice(c, rr, u, su::genId(g, su::GN_ROUTE), su::kRoutes, [](int k) { return std::string(su::routeName(k)); }, "КЪМ");
        const RectF rmu(sec.right - 74.0F, y0, sec.right, y1);
        suSwitch(c, rmu, u, su::genId(g, su::GN_MUTE), "ЗАГЛУШИ", "ДА", "НЕ");
    }
    const RectF area(sec.left, y1 + 28.0F, sec.right, sec.bottom);
    if (m == su::M_OFF && suSub_ != 1) {
        text(c, "Този генератор е изключен. Избери метод (горе вдясно), за да звучи.", area.centerX(), area.top + 100.0F, 15.0F, C_KNOB_LABEL, Opt().center().maxW(area.width() - 30.0F));
        return;
    }
    if (suSub_ == 1) { suGenMethod(c, area, u, g, false); return; }
    const float unit = area.width() / 9.0F;
    const float hw = unit - 4.0F;
    const auto cellX = [&](int col) { return area.left + unit * (static_cast<float>(col) + 0.5F); };
    const float yA = area.top + 26.0F, yB = area.top + 126.0F;
    if (suSub_ == 0) {
        const bool wave = m == su::M_WAVE;
        const bool fixed = suV(u, su::genId(g, su::GN_FIXED)) >= 0.5F;
        suKnob(c, cellX(0), yA, 16.0F, hw, u, su::genId(g, su::GN_LEVEL));
        suKnob(c, cellX(1), yA, 16.0F, hw, u, su::genId(g, su::GN_PAN));
        suKnob(c, cellX(2), yA, 16.0F, hw, u, su::genId(g, su::GN_OCT));
        suKnob(c, cellX(3), yA, 16.0F, hw, u, su::genId(g, su::GN_SEMI));
        suKnob(c, cellX(4), yA, 16.0F, hw, u, su::genId(g, su::GN_FINE));
        suSwitch(c, RectF(cellX(5) - 36.0F, yA - 20.0F, cellX(5) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FIXED), "ФИКСИРАНА ЧЕСТОТА", "ДА", "НЕ");
        if (fixed) suKnob(c, cellX(6), yA, 16.0F, hw, u, su::genId(g, su::GN_FIXHZ)); else suKnob(c, cellX(6), yA, 16.0F, hw, u, su::genId(g, su::GN_RATIO));
        suKnob(c, cellX(7), yA, 16.0F, hw, u, su::genId(g, su::GN_VELLEV));
        suChoice(c, RectF(cellX(0) - 36.0F, yB - 20.0F, cellX(0) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_AMPENV), su::kEnvs + 1,
                 [](int k) { return k == 0 ? std::string("НЯМА") : "ENV " + std::to_string(k); }, "СИЛА ← ENV");
        suChoice(c, RectF(cellX(1) - 36.0F, yB - 20.0F, cellX(1) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_PENV), su::kEnvs + 1,
                 [](int k) { return k == 0 ? std::string("НЯМА") : "ENV " + std::to_string(k); }, "ТОН ← ENV");
        if (rI(suV(u, su::genId(g, su::GN_PENV))) > 0) suKnob(c, cellX(2), yB, 16.0F, hw, u, su::genId(g, su::GN_PENVAMT));
        if (wave) {
            suChoice(c, RectF(cellX(3) - 36.0F, yB - 20.0F, cellX(3) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_UNISON), 4, [](int k) { return std::to_string(k + 1); }, "UNISON", 1);
            suKnob(c, cellX(4), yB, 16.0F, hw, u, su::genId(g, su::GN_UNIDET));
            suKnob(c, cellX(5), yB, 16.0F, hw, u, su::genId(g, su::GN_UNISPR));
            suKnob(c, cellX(6), yB, 16.0F, hw, u, su::genId(g, su::GN_PHASE));
            suSwitch(c, RectF(cellX(7) - 36.0F, yB - 20.0F, cellX(7) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_SYNC), "СИНХРОН", "ДА", "НЕ");
            if (suV(u, su::genId(g, su::GN_SYNC)) >= 0.5F) suKnob(c, cellX(8), yB, 16.0F, hw, u, su::genId(g, su::GN_SYNCR));
        } else {
            text(c, "Копия (unison), начална фаза и синхрон има само методът WAVE.", cellX(3) - 40.0F, yB + 4.0F, 12.0F, C_HINT, Opt().maxW(area.right - cellX(3)));
        }
    } else {
        suChoice(c, RectF(cellX(0) - 36.0F, yA - 20.0F, cellX(0) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FTYPE), su::kOwnFilters, [](int k) { return std::string(su::ownFilterName(k)); }, "ФИЛТЪР");
        if (rI(suV(u, su::genId(g, su::GN_FTYPE))) != su::OF_OFF) {
            suKnob(c, cellX(1), yA, 16.0F, hw, u, su::genId(g, su::GN_FCUT));
            suKnob(c, cellX(2), yA, 16.0F, hw, u, su::genId(g, su::GN_FRES));
            suKnob(c, cellX(3), yA, 16.0F, hw, u, su::genId(g, su::GN_FKEY));
            suChoice(c, RectF(cellX(4) - 36.0F, yA - 20.0F, cellX(4) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FENV), su::kEnvs + 1,
                     [](int k) { return k == 0 ? std::string("НЯМА") : "ENV " + std::to_string(k); }, "СРЕЗ ← ENV");
            if (rI(suV(u, su::genId(g, su::GN_FENV))) > 0) suKnob(c, cellX(5), yA, 16.0F, hw, u, su::genId(g, su::GN_FENVAMT));
        } else {
            text(c, "Всеки генератор може да има свой филтър. Освен него има и два общи (страница ФИЛТРИ).", cellX(1) - 30.0F, yA + 4.0F, 13.0F, C_HINT, Opt().maxW(area.right - cellX(1) + 20.0F));
        }
    }
}

// ---------------------------------------------------------------- FM / PM: the links between the generators
void SilvetonSamplerView::suPageLinks(Canvas& c, const RectF& sec, int u) {
    suLinkDst_ = std::clamp(suLinkDst_, 0, su::kGens - 1);
    suLinkSrc_ = std::clamp(suLinkSrc_, 0, su::kGens - 1);
    // the matrix: a row = the generator that is changed, a column = the one that changes it
    const float labW = 62.0F, cw = 70.0F, ch = 40.0F, top = sec.top + 36.0F;
    text(c, "ПРОМЕНЯ ←", sec.left + 2.0F, sec.top + 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    for (int s = 0; s < su::kGens; ++s) text(c, "G" + std::to_string(s + 1), sec.left + labW + static_cast<float>(s) * cw + cw * 0.5F, sec.top + 30.0F, 13.0F, C_VALUE, Opt().center().bold());
    for (int d = 0; d < su::kGens; ++d) {
        const float y = top + static_cast<float>(d) * (ch + 3.0F);
        const int md = rI(suV(u, su::genId(d, su::GN_METHOD)));
        text(c, "G" + std::to_string(d + 1), sec.left + 8.0F, y + 25.0F, 13.0F, md == su::M_OFF ? C_HINT : C_VALUE, Opt().bold());
        for (int s = 0; s < su::kGens; ++s) {
            const RectF r(sec.left + labW + static_cast<float>(s) * cw, y, sec.left + labW + static_cast<float>(s) * cw + cw - 3.0F, y + ch);
            const int t = rI(suV(u, su::linkType(d, s)));
            const float amt = suV(u, su::linkAmt(d, s));
            const bool sel = d == suLinkDst_ && s == suLinkSrc_;
            fill(c, r, 6.0F, sel ? Color::rgb(86, 92, 106) : (t != 0 ? Color::rgb(66, 72, 86) : Color::rgb(44, 48, 56)));
            if (sel) fill(c, RectF(r.left, r.bottom - 3.0F, r.right, r.bottom), 1.5F, C_ACCENT);
            if (t != 0) {
                text(c, su::linkTypeName(t), r.centerX(), r.top + 17.0F, 12.0F, C_VALUE, Opt().center().bold().maxW(r.width() - 4.0F));
                fill(c, RectF(r.left + 8.0F, r.top + 26.0F, r.left + 8.0F + (r.width() - 16.0F) * amt, r.top + 31.0F), 2.0F, C_ACCENT);
            } else if (d == s) text(c, "·", r.centerX(), r.centerY() + 5.0F, 14.0F, C_HINT, Opt().center());
            hit(r, [this, d, s](float, float) { suLinkDst_ = d; suLinkSrc_ = s; invalidate(); });
        }
    }
    // the chosen link
    const float L = sec.left + labW + 6.0F * cw + 22.0F, R = sec.right;
    const int d = suLinkDst_, s = suLinkSrc_;
    const int md = rI(suV(u, su::genId(d, su::GN_METHOD)));
    text(c, "G" + std::to_string(d + 1) + "  ←  G" + std::to_string(s + 1), L, sec.top + 20.0F, 20.0F, C_VALUE, Opt().bold());
    text(c, std::string(su::methodName(md)) + " ← " + su::methodName(rI(suV(u, su::genId(s, su::GN_METHOD)))), L + 150.0F, sec.top + 20.0F, 12.0F, C_KNOB_LABEL, Opt().maxW(R - L - 150.0F));
    const int tNow = rI(suV(u, su::linkType(d, s)));
    const float kw = (R - L - 3.0F * 6.0F) / 4.0F;
    for (int t = 0; t < su::kLinkTypes; ++t) {
        const bool waveOnly = t == su::L_PM || t == su::L_FM || t == su::L_SYNC || t == su::L_WARP;
        const bool usable = md == su::M_WAVE || !waveOnly;   // PM, FM, SYNC and WARP act on the wave generator only
        const RectF r(L + static_cast<float>(t % 4) * (kw + 6.0F), sec.top + 40.0F + static_cast<float>(t / 4) * 40.0F, L + static_cast<float>(t % 4) * (kw + 6.0F) + kw, sec.top + 72.0F + static_cast<float>(t / 4) * 40.0F);
        if (usable) {
            stripToggle(c, r, su::linkTypeName(t), tNow == t, C_ACCENT, 12.0F);
            hit(r, [this, u, d, s, t](float, float) { suSet(u, su::linkType(d, s), static_cast<float>(t)); });
        } else {
            fill(c, r, 6.0F, Color::rgb(38, 41, 48));
            text(c, su::linkTypeName(t), r.centerX(), r.centerY() + 4.0F, 12.0F, C_HINT, Opt().center());
        }
    }
    text(c, "PM FM SYNC WARP: само върху WAVE. AM RING: върху всеки. FILT FM: иска собствен филтър.",
         L, sec.top + 142.0F, 11.0F, C_HINT, Opt().maxW(R - L));
    suKnob(c, L + 56.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::linkAmt(d, s));
    // the operator (the generator that is changed): its ratio and level
    const bool fixed = suV(u, su::genId(d, su::GN_FIXED)) >= 0.5F;
    if (fixed) suKnob(c, L + 166.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_FIXHZ));
    else suKnob(c, L + 166.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_RATIO));
    suKnob(c, L + 276.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_LEVEL));
    suSwitch(c, RectF(L + 340.0F, sec.top + 172.0F, R, sec.top + 206.0F), u, su::genId(d, su::GN_FIXED), "ФИКСИРАНА", "ДА", "НЕ");
    suSwitch(c, RectF(L, sec.top + 258.0F, L + 110.0F, sec.top + 292.0F), u, su::genId(d, su::GN_MUTE), "G" + std::to_string(d + 1) + " ЗАГЛУШЕН", "ДА", "НЕ");
    suSwitch(c, RectF(L + 130.0F, sec.top + 258.0F, L + 240.0F, sec.top + 292.0F), u, su::genId(s, su::GN_MUTE), "G" + std::to_string(s + 1) + " ЗАГЛУШЕН", "ДА", "НЕ");
    text(c, "Заглушен генератор не се чува, но все така променя другите.", L + 250.0F, sec.top + 280.0F, 11.0F, C_HINT, Opt().maxW(R - L - 250.0F));
}

// ---------------------------------------------------------------- ФИЗИКА: strings, tubes, reeds, modes
void SilvetonSamplerView::suPagePhysics(Canvas& c, const RectF& sec, int u) {
    suGenRow(c, sec, u, true);
    const int g = std::clamp(suGen_, 0, su::kGens - 1);
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    const bool phys = m == su::M_STRING || m == su::M_WIND || m == su::M_MODAL;
    const float y0 = sec.top + 58.0F;
    if (!phys) {
        text(c, "G" + std::to_string(g + 1) + " не е физичен генератор. Направи го:", sec.left + 4.0F, y0 + 20.0F, 15.0F, C_VALUE, Opt().bold());
        static const int kinds[3] = {su::M_STRING, su::M_WIND, su::M_MODAL};
        static const char* const nm[3] = {"СТРУНА", "ДУХОВ (тръба, тръстика)", "МОДАЛЕН (камбана, пръчка)"};
        for (int i = 0; i < 3; ++i) {
            const RectF r(sec.left + 4.0F + static_cast<float>(i) * 290.0F, y0 + 40.0F, sec.left + 4.0F + static_cast<float>(i) * 290.0F + 280.0F, y0 + 84.0F);
            stripToggle(c, r, nm[i], false, C_AMBER, 14.0F);
            hit(r, [this, u, g, i](float, float) { suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(kinds[i])); });
        }
        text(c, "Струната и тръбата са вълноводи (линия със закъснение), модалният е набор от резонатори. Всеки може да се удря от друг генератор (EXCITED BY).",
             sec.left + 4.0F, y0 + 120.0F, 12.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
        return;
    }
    suGenMethod(c, RectF(sec.left, y0, sec.right, sec.bottom), u, g, true);
    if (m == su::M_WIND) text(c, "Дишането (BREATH CTL) следва контролер CC2; силата на клавиша и CC11 се връзват от страница МОДУЛ. / MIDI.", sec.left + 4.0F, sec.bottom - 6.0F, 11.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
}

} // namespace silveton::ui::classic
