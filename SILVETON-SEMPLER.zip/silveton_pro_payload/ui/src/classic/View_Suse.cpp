// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH on the ДВИГАТЕЛИ page (part 1: the tools, ОСЦИЛ., FM / PM, ФИЗИКА).
// Every control here is one number of the patch (core/include/silveton/sampler/SuseDefs.h). Its name, range and text come from
// SuseTools.h, the same place the sound and the tests use, so the screen can show nothing that the sound does not do.
// Drag = turn, tap = exact number, double tap = the starting value.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;
namespace sv = ::silveton::sampler;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
}  // namespace

// ---------------------------------------------------------------- the numbers
const std::vector<float>& SilvetonSamplerView::suP(int u) {
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    if (!slot) slot = sampler.upperEngineParams(u);
    if (static_cast<int>(slot->size()) < su::kParamCount + 1) {   // (a place that is not SILVETON SYNTH yet: the start sound, never read as a sound)
        static std::vector<float> fallback;
        if (fallback.empty()) { fallback.assign(static_cast<std::size_t>(su::kParamCount) + 1U, 0.0F); su::setDefaults(fallback.data() + 1); }
        return fallback;
    }
    return *slot;
}

float SilvetonSamplerView::suV(int u, int id) {
    const auto& a = suP(u);
    return id >= 0 && id < su::kParamCount ? a[static_cast<std::size_t>(id) + 1U] : 0.0F;
}

void SilvetonSamplerView::suSessionDirty() { suSaveDueMs_ = nowMs() + 1500; }

void SilvetonSamplerView::suCheckSession() {
    if (suSaveDueMs_ != 0 && nowMs() >= suSaveDueMs_) { suSaveDueMs_ = 0; sampler.suseSaveSession(); }
    else if (suSaveDueMs_ != 0) postInvalidateDelayed(300);
}

void SilvetonSamplerView::suSet(int u, int id, float v) {
    const float cv = su::clampParam(id, v);
    // A link with the type OFF does nothing, so a turned AMOUNT knob would feel dead: the type is chosen for the player
    // (PM when the changed generator is a WAVE, else AM) and the screen says so.
    if (id >= su::kLinkBase && id < su::kFilterBase && (id - su::kLinkBase) % 2 == 1 && cv > 0.0F && rI(suV(u, id - 1)) == su::L_OFF) {
        const int dst = (id - su::kLinkBase) / 2 / su::kGens;
        const int t = rI(suV(u, su::genId(dst, su::GN_METHOD))) == su::M_WAVE ? su::L_PM : su::L_AM;
        sampler.setUpperEngineParam(u, id - 1 + 1, static_cast<float>(t));
        auto& cache = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
        if (cache && static_cast<std::size_t>(id) < cache->size()) (*cache)[static_cast<std::size_t>(id - 1) + 1U] = static_cast<float>(t);
        suStatus_ = std::string("Видът на връзката е избран сам: ") + su::linkTypeName(t) + " (можеш да го смениш)";
        suStatusUntilMs_ = nowMs() + 4000;
    }
    auto& slot = engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))];
    const bool ok = sampler.setUpperEngineParam(u, id + 1, cv);
    const bool methodChange = id >= su::kGenBase && id < su::kLinkBase && (id - su::kGenBase) % su::kGenStride == su::GN_METHOD;
    if (!ok || methodChange) slot.reset();   // a new method loads its own starting knobs: read everything again
    else if (slot && static_cast<std::size_t>(id) + 1U < slot->size()) (*slot)[static_cast<std::size_t>(id) + 1U] = cv;
    suSessionDirty();
    invalidate();
}

void SilvetonSamplerView::suBlock(int u, int firstId, const std::vector<float>& values) {
    sampler.setUpperEngineBlock(u, firstId + 1, values);
    engineParamsCache[static_cast<std::size_t>(std::clamp(u, 0, kParts - 1))].reset();
    suSessionDirty();
    invalidate();
}

void SilvetonSamplerView::suLoadPatch(int u, const float* patch) {
    std::vector<float> v(patch, patch + su::kParamCount);
    // the places' switches (E_SOURCE, bypass, bend) stay as the player has them
    const std::vector<float>& now = suP(u);
    for (int id : {su::E_SOURCE_ID, su::E_BYPASS_ID, su::E_BEND_UP_ID, su::E_BEND_DOWN_ID}) v[static_cast<std::size_t>(id)] = now[static_cast<std::size_t>(id) + 1U];
    suBlock(u, 0, v);
}

float SilvetonSamplerView::suDefault(int u, int id) {
    std::vector<float> t(static_cast<std::size_t>(su::kParamCount));
    su::setDefaults(t.data());
    if (id >= su::kGenBase && id < su::kLinkBase) {
        const int g = (id - su::kGenBase) / su::kGenStride, off = (id - su::kGenBase) % su::kGenStride;
        if (off >= su::GN_SEL1 && off <= su::GN_SEL4) { su::setMethod(t.data(), g, rI(suV(u, su::genId(g, su::GN_METHOD)))); }
        else if (off >= su::GN_F0 && off < su::GN_F0 + su::kGenFloats) { su::setMethod(t.data(), g, rI(suV(u, su::genId(g, su::GN_METHOD)))); }
    }
    return t[static_cast<std::size_t>(id)];
}

// ---------------------------------------------------------------- the controls
void SilvetonSamplerView::suKnob(Canvas& c, float cx, float cy, float rad, float hw, int u, int id, const char* labelOverride) {
    const float* patch = suP(u).data() + 1;
    const char* nm = su::paramName(id, patch);
    if (nm == nullptr) return;
    if (labelOverride != nullptr) nm = labelOverride;
    const su::Disp d = su::paramDisp(id, patch);
    const float v = suV(u, id);
    const std::string label = nm;
    const std::string shown = su::dispText(d, v);
    if (d.kind == su::Disp::Whole) {
        knobControl(c, cx, cy, rad, v, d.lo, d.hi, 1.0F, 260.0F, d.lo < 0.0F, shown, label, hw,
                    [this, u, id](float nv) { suSet(u, id, std::round(nv)); },
                    [this, u, id, v, label, d] { showNumber(label, v, d.lo, d.hi, 0, [this, u, id](float x) { suSet(u, id, std::round(x)); }); },
                    [this, u, id] { suSet(u, id, suDefault(u, id)); });
        return;
    }
    const bool bipolar = d.kind == su::Disp::PctBi || (d.kind == su::Disp::Lin && d.lo < 0.0F);
    float lo = d.lo, hi = d.hi;
    int dec = d.decimals;
    if (d.kind == su::Disp::Pct) { lo = 0.0F; hi = 100.0F; dec = 0; }
    else if (d.kind == su::Disp::PctBi) { lo = -100.0F; hi = 100.0F; dec = 0; }
    else if (d.kind == su::Disp::Time) { lo = 0.0F; hi = 10.0F; dec = 3; }
    knobControl(c, cx, cy, rad, v, 0.0F, 1.0F, 0.002F, 260.0F, bipolar, shown, label, hw,
                [this, u, id](float nv) { suSet(u, id, nv); },
                [this, u, id, d, v, label, lo, hi, dec] {
                    showNumber(label + std::string(d.unit), su::dispFromNorm(d, v), lo, hi, dec, [this, u, id, d](float x) { suSet(u, id, su::dispToNorm(d, x)); });
                },
                [this, u, id] { suSet(u, id, suDefault(u, id)); });
}

void SilvetonSamplerView::suChoice(Canvas& c, const RectF& r, int u, int id, int count, const std::function<std::string(int)>& nameOf, const std::string& label, int first) {
    const int cur = std::clamp(rI(suV(u, id)) - first, 0, std::max(0, count - 1));
    stripToggle(c, r, nameOf(cur), cur != 0 || first != 0, C_AMBER, 11.0F);
    text(c, count > 6 ? label + " ▼" : label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 24.0F));
    if (count > 6) {
        std::vector<std::pair<std::string, std::string>> items;
        items.reserve(static_cast<std::size_t>(count));
        for (int k = 0; k < count; ++k) items.emplace_back(fmtZeroPad(k + first, 2), nameOf(k));
        const std::string title = label + " — избери от списъка · допир извън прозореца = затваряне";
        hit(r, [this, u, id, cur, items, title, first](float, float) {
                showGridPicker(title, items, cur, std::nullopt, [this, u, id, first](int k) { if (k >= 0) suSet(u, id, static_cast<float>(k + first)); });
                if (!dialogStack.empty()) dialogStack.back()->keepOpen = true;
            },
            [this, u, id] { suSet(u, id, suDefault(u, id)); });
    } else {
        hit(r, [this, u, id, cur, count, first](float, float) { suSet(u, id, static_cast<float>(first + (cur + 1) % std::max(1, count))); },
            [this, u, id] { suSet(u, id, suDefault(u, id)); });
    }
}

void SilvetonSamplerView::suSeg(Canvas& c, const RectF& r, int u, int id, int count, const std::function<std::string(int)>& nameOf, int first) {
    const int cur = rI(suV(u, id)) - first;
    const float gap = 4.0F;
    const float w = (r.width() - gap * static_cast<float>(count - 1)) / static_cast<float>(std::max(1, count));
    for (int k = 0; k < count; ++k) {
        const RectF kr(r.left + static_cast<float>(k) * (w + gap), r.top, r.left + static_cast<float>(k) * (w + gap) + w, r.bottom);
        stripToggle(c, kr, nameOf(k), cur == k, C_ACCENT, 11.0F);
        hit(kr, [this, u, id, k, first](float, float) { suSet(u, id, static_cast<float>(k + first)); });
    }
}

void SilvetonSamplerView::suSwitch(Canvas& c, const RectF& r, int u, int id, const std::string& label, const std::string& onText, const std::string& offText) {
    const bool on = suV(u, id) >= 0.5F;
    stripToggle(c, r, on ? onText : offText, on, C_AMBER, 11.0F);
    text(c, label, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(r.width() + 24.0F));
    hit(r, [this, u, id, on](float, float) { suSet(u, id, on ? 0.0F : 1.0F); }, [this, u, id] { suSet(u, id, suDefault(u, id)); });
}

void SilvetonSamplerView::suPickWave(int u, std::function<void(int)> done, const std::string& title) {
    (void)u;
    std::vector<std::pair<std::string, std::string>> items;
    for (int k = 0; k < su::kWaveChoices; ++k) items.emplace_back(fmtZeroPad(k, 2), su::waveName(k));
    showGridPicker(title, items, -1, std::nullopt, [done](int k) { if (k >= 0) done(k); });
}

// ---------------------------------------------------------------- the generators row, the method panel
void SilvetonSamplerView::suGenRow(Canvas& c, const RectF& sec, int u, bool physicalOnly) {
    const float w = (sec.width() - 5.0F * 6.0F) / 6.0F;
    for (int g = 0; g < su::kGens; ++g) {
        const RectF r(sec.left + static_cast<float>(g) * (w + 6.0F), sec.top, sec.left + static_cast<float>(g) * (w + 6.0F) + w, sec.top + 42.0F);
        const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
        const bool phys = m == su::M_STRING || m == su::M_WIND || m == su::M_MODAL;
        const bool muted = suV(u, su::genId(g, su::GN_MUTE)) >= 0.5F && m != su::M_OFF;
        const bool sel = suGen_ == g;
        stripToggle(c, r, "", sel, C_ACCENT, 12.0F);
        // the words sit on a key: dark on the light (or dark-theme) key, light on the green one
        const ColorInt tc = sel ? litText(litFill(C_ACCENT)) : (darkTheme ? C_KEY_DARK_TEXT : C_TOGGLE_TEXT);
        const ColorInt warn = sel ? tc : (darkTheme ? C_AMBER : Color::rgb(176, 96, 0));
        text(c, "ОСЦИЛАТОР " + std::to_string(g + 1) + (muted ? " · ЗАГЛУШЕН" : ""), r.centerX(), r.top + 15.0F, 9.0F, muted ? warn : tc, Opt().center().bold().spacing(0.1F).maxW(w - 6.0F));
        text(c, std::string(su::methodName(m)) + (physicalOnly && !phys && m != su::M_OFF ? " ·" : ""), r.centerX(), r.top + 33.0F, 13.0F, tc, m == su::M_OFF ? Opt().center().maxW(w - 6.0F) : Opt().center().bold().maxW(w - 6.0F));
        hit(r, [this, g](float, float) { suGen_ = g; invalidate(); });
    }
}

// the choices (SEL1..4) and the own knobs of the generator's method
void SilvetonSamplerView::suGenMethod(Canvas& c, const RectF& area, int u, int g, bool segmented) {
    const float* patch = suP(u).data() + 1;
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    if (m == su::M_OFF) {
        text(c, "Този осцилатор е изключен. Избери МЕТОД, за да звучи.", area.centerX(), area.top + 90.0F, 15.0F, C_KNOB_LABEL, Opt().center().maxW(area.width() - 30.0F));
        return;
    }
    text(c, su::methodHelp(m), area.left, area.bottom - 6.0F, 12.0F, C_HINT, Opt().maxW(area.width() - 4.0F));
    // the pictures of the waves are one tap away
    if (m == su::M_WAVE) {
        const RectF gr(area.left, area.top - 25.0F, area.left + 190.0F, area.top - 5.0F);
        stripToggle(c, gr, "КАРТИНКИ НА ВЪЛНИТЕ", false, C_ACCENT, 10.5F);
        hit(gr, [this, g](float, float) { suPickGen_ = g; suPage_ = 1; invalidate(); });
    }
    // the choices
    int nSel = 0;
    for (int s = su::GN_SEL1; s <= su::GN_SEL4; ++s) if (su::selLabel(m, s) != nullptr) ++nSel;
    float y = area.top;
    if (nSel > 0) {
        const float gap = 14.0F;
        const float w = (area.width() - gap * static_cast<float>(nSel - 1)) / static_cast<float>(nSel);
        int k = 0;
        for (int s = su::GN_SEL1; s <= su::GN_SEL4; ++s) {
            const char* lab = su::selLabel(m, s);
            if (lab == nullptr) continue;
            const int id = su::genId(g, s);
            const int count = su::selChoices(m, s);
            const RectF r(area.left + static_cast<float>(k) * (w + gap), y, area.left + static_cast<float>(k) * (w + gap) + w, y + 36.0F);
            const auto nameOf = [m, s](int ch) { return su::selChoiceName(m, s, ch); };
            if (segmented && count <= 7 && nSel == 1) { suSeg(c, r, u, id, count, nameOf); text(c, lab, r.centerX(), r.bottom + 16.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F)); }
            else suChoice(c, r, u, id, count, nameOf, lab);
            ++k;
        }
        y += 54.0F;
    }
    // the own knobs: up to 7 in a row
    int n = 0;
    for (int i = 0; i < su::kGenFloats; ++i) if (su::methodKnobName(m, i) != nullptr) ++n;
    if (n == 0) return;
    const int perRow = n <= 7 ? n : (n + 1) / 2;
    const float unit = area.width() / static_cast<float>(std::max(perRow, 1));
    int k = 0;
    for (int i = 0; i < su::kGenFloats; ++i) {
        if (su::methodKnobName(m, i) == nullptr) continue;
        const int row = k / perRow, col = k % perRow;
        const float cx = area.left + unit * (static_cast<float>(col) + 0.5F);
        const float cy = y + 30.0F + static_cast<float>(row) * 90.0F;
        suKnob(c, cx, cy, 16.0F, std::min(unit - 4.0F, 120.0F), u, su::genId(g, su::GN_F0 + i));
        ++k;
    }
    (void)patch;
}

// ---------------------------------------------------------------- ОСЦИЛ.: the generators of the graph
// ---------------------------------------------------------------- ОСЦИЛ.: the simple screen
void SilvetonSamplerView::suPageOscSimple(Canvas& c, const RectF& sec, int u) {
    const float* patch = suP(u).data() + 1;
    suGen_ = std::clamp(suGen_, 0, su::kGens - 1);
    const int g = suGen_;
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    const bool wave = m == su::M_WAVE;
    const ColorInt keyText = darkTheme ? C_KEY_DARK_TEXT : C_TOGGLE_TEXT;
    // the upper's own settings: the portamento, the octave and the transpose (common for every oscillator of the upper)
    const auto stOpt = upperStates[static_cast<std::size_t>(u)];
    const bool haveSt = stOpt.has_value();
    const UpperState st = haveSt ? *stOpt : UpperState{};
    const std::vector<float> up = uParams(u);
    const auto upv = [&up](int id, float dflt) { return id >= 0 && id < static_cast<int>(up.size()) ? up[static_cast<std::size_t>(id)] : dflt; };
    const auto sgn = [](int v) { return v > 0 ? "+" + std::to_string(v) : std::to_string(v); };

    // ---- which oscillator (there are six; every one has its own waves and level)
    text(c, "OSCILLATOR:", sec.left + 2.0F, sec.top + 17.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    const float kw = (sec.width() - 110.0F - 5.0F * 6.0F) / 6.0F;
    for (int i = 0; i < su::kGens; ++i) {
        const float x0 = sec.left + 110.0F + static_cast<float>(i) * (kw + 6.0F);
        const RectF r(x0, sec.top, x0 + kw, sec.top + 26.0F);
        const int mi = rI(suV(u, su::genId(i, su::GN_METHOD)));
        stripToggle(c, r, std::to_string(i + 1) + " · " + su::methodName(mi), suGen_ == i, C_ACCENT, 11.0F);
        hit(r, [this, i](float, float) { suGen_ = i; invalidate(); });
    }

    // ---- wave A, the mix, wave B
    const float wy0 = sec.top + 34.0F, wy1 = wy0 + 84.0F;
    if (wave) {
        const float bw = 290.0F;
        const auto waveKey = [&](const RectF& r, int slot) {
            const int sel = rI(suV(u, su::genId(g, slot == 0 ? su::GN_SEL1 : su::GN_SEL2)));
            stripToggle(c, r, "", false, C_ACCENT, 12.0F);
            const RectF pic(r.left + 10.0F, r.top + 10.0F, r.left + 132.0F, r.bottom - 12.0F);
            fill(c, pic, 6.0F, Color::rgb(24, 27, 32));
            line(c, pic.left + 3.0F, pic.centerY(), pic.right - 3.0F, pic.centerY(), Color::argb(60, 255, 255, 255), 1.0F);
            float pts[su::kDrawLen];
            su::waveChoicePoints(sel, patch, pts);
            const float amp = pic.height() * 0.5F - 4.0F, dx = (pic.width() - 8.0F) / static_cast<float>(su::kDrawLen - 1);
            for (int i = 0; i + 1 < su::kDrawLen; ++i)
                line(c, pic.left + 4.0F + dx * static_cast<float>(i), pic.centerY() - std::clamp(pts[i], -1.0F, 1.0F) * amp,
                     pic.left + 4.0F + dx * static_cast<float>(i + 1), pic.centerY() - std::clamp(pts[i + 1], -1.0F, 1.0F) * amp, C_ACCENT, 1.8F);
            const float tx = pic.right + 12.0F, tw = r.right - tx - 8.0F;
            text(c, slot == 0 ? "WAVE A" : "WAVE B", tx, r.top + 22.0F, 10.5F, keyText, Opt().bold().spacing(0.1F).maxW(tw));
            const auto lines = wrapLines(su::waveName(sel), 15.0F, Face::Bold, tw);
            for (std::size_t k = 0; k < lines.size() && k < 2; ++k) text(c, lines[k], tx, r.top + 44.0F + static_cast<float>(k) * 18.0F, 15.0F, keyText, Opt().bold());
            text(c, "докосни за избор ▶", tx, r.bottom - 10.0F, 10.0F, keyText, Opt().maxW(tw));
            hit(r, [this, g, slot, sel](float, float) { suPickGen_ = g; suPickSlot_ = slot; suPick_ = sel; suPage_ = 1; invalidate(); });
        };
        waveKey(RectF(sec.left, wy0, sec.left + bw, wy1), 0);
        waveKey(RectF(sec.right - bw, wy0, sec.right, wy1), 1);
        // the mix: a slider from only A to only B
        const float mx0 = sec.left + bw + 22.0F, mx1 = sec.right - bw - 22.0F;
        const int morphId = su::genId(g, su::GN_F0);
        const float morph = std::clamp(suV(u, morphId), 0.0F, 1.0F);
        text(c, "MIX", (mx0 + mx1) * 0.5F, wy0 + 12.0F, 12.0F, C_SECTION_TITLE, Opt().center().bold().spacing(0.2F));
        const RectF track(mx0 + 40.0F, wy0 + 36.0F, mx1 - 40.0F, wy0 + 48.0F);
        fill(c, track, 6.0F, Color::rgb(28, 31, 36));
        fill(c, RectF(track.left, track.top, track.left + track.width() * morph, track.bottom), 6.0F, C_ACCENT);
        fill(c, RectF(track.left + track.width() * morph - 12.0F, track.centerY() - 12.0F, track.left + track.width() * morph + 12.0F, track.centerY() + 12.0F), 12.0F, Color::rgb(226, 229, 234));
        text(c, "A", mx0 + 12.0F, track.centerY() + 6.0F, 16.0F, C_VALUE, Opt().center().bold());
        text(c, "B", mx1 - 12.0F, track.centerY() + 6.0F, 16.0F, C_VALUE, Opt().center().bold());
        const int pc = rI(morph * 100.0F);
        text(c, pc == 0 ? std::string("only A") : (pc == 100 ? std::string("only B") : "A " + std::to_string(100 - pc) + " %   ·   B " + std::to_string(pc) + " %"),
             (mx0 + mx1) * 0.5F, wy0 + 66.0F, 12.0F, C_VALUE, Opt().center().bold().maxW(mx1 - mx0));
        text(c, "плъзни, за да смесиш двете форми", (mx0 + mx1) * 0.5F, wy0 + 80.0F, 10.0F, C_HINT, Opt().center().maxW(mx1 - mx0));
        const auto setMix = [this, u, morphId, track](float x, float) { suSet(u, morphId, std::clamp((x - track.left) / track.width(), 0.0F, 1.0F)); };
        const RectF touch(mx0, wy0 + 20.0F, mx1, wy0 + 60.0F);
        hit(touch, setMix, [this, u, morphId] { suSet(u, morphId, 0.0F); }, [setMix](float x, float y, bool) { setMix(x, y); });
    } else {
        const RectF box(sec.left, wy0, sec.right, wy1);
        fill(c, box, 8.0F, Color::rgb(30, 33, 39));
        text(c, "OSCILLATOR " + std::to_string(g + 1) + (m == su::M_OFF ? " is off." : std::string(" is ") + su::methodName(m) + " — no waves."),
             box.left + 20.0F, box.top + 30.0F, 15.0F, C_VALUE, Opt().bold().maxW(box.width() - 40.0F));
        text(c, "Вълнови форми А и Б има при метод ВЪЛНА. Другите методи са в ADVANCED (и в ФИЗИКА).", box.left + 20.0F, box.top + 48.0F, 11.0F, C_KNOB_LABEL, Opt().maxW(box.width() - 40.0F));
        const RectF kb(box.left + 20.0F, box.top + 56.0F, box.left + 300.0F, box.top + 80.0F);
        stripToggle(c, kb, "SWITCH TO WAVE", false, C_ACCENT, 12.0F);
        hit(kb, [this, u, g](float, float) { suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(su::M_WAVE)); });
    }

    // ---- the sound (brightness, level) and how it starts and ends (attack, decay, sustain, release)
    const float unit = sec.width() / 6.0F;
    const auto cx = [&](int col) { return sec.left + unit * (static_cast<float>(col) + 0.5F); };
    const float ky = sec.top + 162.0F;
    text(c, "SOUND", sec.left + 4.0F, sec.top + 128.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    line(c, sec.left + unit * 2.0F, sec.top + 122.0F, sec.left + unit * 2.0F, sec.top + 252.0F, Color::argb(50, 255, 255, 255), 1.0F);
    const int envSel = rI(suV(u, su::genId(g, su::GN_AMPENV)));
    const int e = std::clamp(envSel - 1, 0, su::kEnvs - 1);
    text(c, envSel > 0 ? "ENVELOPE " + std::to_string(envSel) : std::string("ENVELOPE"), sec.left + unit * 2.0F + 12.0F, sec.top + 128.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F).maxW(unit * 4.0F - 16.0F));
    const auto describe = [&](int col, const char* s2) {
        const auto lines = wrapLines(s2, 10.0F, Face::Regular, unit - 16.0F);
        for (std::size_t k = 0; k < lines.size() && k < 2; ++k) text(c, lines[k], cx(col), sec.top + 236.0F + static_cast<float>(k) * 12.0F, 10.0F, C_HINT, Opt().center());
    };
    if (wave) {
        suKnob(c, cx(0), ky, 16.0F, unit - 6.0F, u, su::genId(g, su::GN_F0 + 2), "BRIGHTNESS");
        describe(0, "по-ниско — по-мек, тъмен звук; по-високо — по-ярък");
    }
    suKnob(c, cx(1), ky, 16.0F, unit - 6.0F, u, su::genId(g, su::GN_LEVEL), "LEVEL");
    describe(1, "колко силно звучи този осцилатор");
    if (envSel > 0) {
        suKnob(c, cx(2), ky, 16.0F, unit - 6.0F, u, su::envId(e, su::envT(0)), "ATTACK");
        suKnob(c, cx(3), ky, 16.0F, unit - 6.0F, u, su::envId(e, su::envT(1)), "DECAY");
        suKnob(c, cx(4), ky, 16.0F, unit - 6.0F, u, su::envId(e, su::envL(1)), "SUSTAIN");
        suKnob(c, cx(5), ky, 16.0F, unit - 6.0F, u, su::envId(e, su::EV_REL), "RELEASE");
        describe(2, "колко бързо стига до най-силното");
        describe(3, "колко бавно пада до нивото на ДЪРЖАНЕ");
        describe(4, "нивото, докато държиш клавиша");
        describe(5, "колко бавно угасва, след като пуснеш клавиша");
        bool classic = rI(suV(u, su::envId(e, su::EV_SUS))) == 1;
        for (int i = 2; i < su::kEnvPoints; ++i) classic = classic && suV(u, su::envId(e, su::envT(i))) <= 0.001F;
        if (!classic) text(c, "Тази обвивка има още точки — пълният ѝ вид е в страница ОБВИВКИ.", sec.left + unit * 2.0F + 12.0F, sec.top + 254.0F, 10.0F, C_AMBER, Opt().bold().maxW(unit * 4.0F - 16.0F));
    } else {
        text(c, "Този осцилатор няма обвивка на силата — звучи постоянно.", sec.left + unit * 2.0F + 12.0F, sec.top + 186.0F, 12.0F, C_VALUE, Opt().maxW(unit * 4.0F - 16.0F));
        const RectF kb(sec.left + unit * 2.0F + 12.0F, sec.top + 198.0F, sec.left + unit * 2.0F + 232.0F, sec.top + 226.0F);
        stripToggle(c, kb, "TURN ON ENVELOPE 1", false, C_ACCENT, 12.0F);
        hit(kb, [this, u, g](float, float) { suSet(u, su::genId(g, su::GN_AMPENV), 1.0F); });
    }

    // ---- the upper's portamento, octave and transpose (one row)
    const float colW = (sec.width() - 104.0F) / 5.0F;
    const auto tcx = [&](int col) { return sec.left + 104.0F + colW * (static_cast<float>(col) + 0.5F); };
    const float kpy = sec.top + 292.0F, kpr = 14.0F;
    const auto upLabel = [&](float x, const char* s2) { text(c, s2, x, sec.top + 265.0F, 10.0F, C_KNOB_LABEL, Opt().center().bold().spacing(0.12F).maxW(colW - 8.0F)); };
    const auto upValue = [&](float x, const std::string& s2) { text(c, s2, x, sec.top + 326.0F, 12.0F, C_VALUE, Opt().center().mono().maxW(colW - 8.0F)); };
    text(c, "PORTAMENTO", sec.left, sec.top + 258.0F, 9.5F, C_SECTION_TITLE, Opt().bold().spacing(0.12F));
    if (haveSt) {
        const int pmode = std::clamp(rI(upv(42, 0.0F)), 0, 3);
        const RectF kS(sec.left, sec.top + 262.0F, sec.left + 96.0F, sec.top + 286.0F), kK(sec.left, sec.top + 292.0F, sec.left + 96.0F, sec.top + 316.0F);
        stripToggle(c, kS, "SILVETON", pmode == 0, C_AMBER, 11.0F);
        stripToggle(c, kK, "KRONOS", pmode == 1, C_AMBER, 11.0F);
        hit(kS, [this, u](float, float) { setUParam(u, 42, 0.0F); invalidate(); });
        hit(kK, [this, u](float, float) { setUParam(u, 42, 1.0F); invalidate(); });
        if (pmode == 0) {   // SILVETON: TIME, BALANCE, NEAR TIME
            const float porta = portamentoUiValue(st.portamentoSec);
            auto setPorta = [this, st](float v) { UpperState n = currentUpper(st); n.portamentoSec = portamentoSecondsFromUi(v); commitTune(n); };
            knobControl(c, tcx(0), kpy, kpr, porta, 0.0F, 100.0F, 1.0F, 300.0F, false, "", "", 110.0F, setPorta,
                        [this, porta, setPorta] { showNumber("PORTAMENTO TIME ms (0 = OFF)", porta, 0.0F, 100.0F, 0, setPorta); },
                        [this, st] { UpperState n = currentUpper(st); n.portamentoSec = 0.0F; commitTune(n); });
            upLabel(tcx(0), "TIME");
            upValue(tcx(0), porta <= 0.0F ? std::string("OFF") : fmtFixed(static_cast<double>(porta), 2) + " ms");
            const float bal = static_cast<float>(sampler.portaBalance());
            knobControl(c, tcx(1), kpy, kpr, bal, 3.0F, 40.0F, 1.0F, 300.0F, false, "", "", 110.0F,
                        [this](float nv) { sampler.setPortaBalance(rI(nv)); },
                        [this, bal] { showNumber("PORTA BALANCE", bal, 3.0F, 40.0F, 0, [this](float x) { sampler.setPortaBalance(rI(x)); }); },
                        [this] { sampler.setPortaBalance(11); });
            upLabel(tcx(1), "BALANCE");
            upValue(tcx(1), std::to_string(rI(bal)));
            const float nearV = static_cast<float>(sampler.portaNear());
            knobControl(c, tcx(2), kpy, kpr, nearV, 0.0F, 400.0F, 1.0F, 300.0F, false, "", "", 110.0F,
                        [this](float nv) { sampler.setPortaNear(rI(nv)); },
                        [this, nearV] { showNumber("NEAR TIME ms", nearV, 0.0F, 400.0F, 0, [this](float x) { sampler.setPortaNear(rI(x)); }); },
                        [this] { sampler.setPortaNear(90); });
            upLabel(tcx(2), "NEAR TIME");
            upValue(tcx(2), std::to_string(rI(nearV)) + " ms");
        } else if (pmode == 1) {   // KRONOS: TIME, FINGERED, TIME / RATE
            const float t = upv(45, 40.0F);
            knobControl(c, tcx(0), kpy, kpr, t, 0.0F, 127.0F, 1.0F, 300.0F, false, "", "", 110.0F,
                        [this, u](float nv) { setUParam(u, 45, std::nearbyint(nv)); },
                        [this, u, t] { showNumber("KRONOS PORTA TIME (0 = OFF)", t, 0.0F, 127.0F, 0, [this, u](float x) { setUParam(u, 45, std::nearbyint(x)); }); },
                        [this, u] { setUParam(u, 45, 0.0F); });
            upLabel(tcx(0), "TIME");
            upValue(tcx(0), t <= 0.0F ? std::string("OFF") : std::to_string(rI(t)));
            const bool fing = upv(43, 0.0F) >= 0.5F;
            const RectF fr(tcx(1) - 70.0F, kpy - 11.0F, tcx(1) + 70.0F, kpy + 11.0F);
            stripToggle(c, fr, "FINGERED", fing, C_AMBER, 11.0F);
            hit(fr, [this, u, fing](float, float) { setUParam(u, 43, fing ? 0.0F : 1.0F); invalidate(); });
            const bool rate = upv(44, 0.0F) >= 0.5F;
            const RectF rA(tcx(2) - 70.0F, kpy - 11.0F, tcx(2) - 4.0F, kpy + 11.0F), rB(tcx(2) + 4.0F, kpy - 11.0F, tcx(2) + 70.0F, kpy + 11.0F);
            stripToggle(c, rA, "TIME", !rate, C_AMBER, 11.0F);
            stripToggle(c, rB, "RATE", rate, C_AMBER, 11.0F);
            hit(rA, [this, u](float, float) { setUParam(u, 44, 0.0F); invalidate(); });
            hit(rB, [this, u](float, float) { setUParam(u, 44, 1.0F); invalidate(); });
            upLabel(tcx(2), "TIME / RATE");
        } else {
            text(c, "INSTRUMENT / BASS (стара настройка): натисни SILVETON или KRONOS", tcx(0) - colW * 0.5F, kpy + 4.0F, 10.5F, C_HINT, Opt().maxW(colW * 3.0F));
        }
        // octave and transpose (the upper's own, common for all oscillators)
        const float octV = static_cast<float>(st.octave);
        knobControl(c, tcx(3), kpy, kpr, octV, -4.0F, 4.0F, 1.0F, 300.0F, false, "", "", 110.0F,
                    [this, st](float nv) { UpperState cur = currentUpper(st); cur.octave = static_cast<std::int8_t>(std::clamp(rI(nv), -4, 4)); commitTune(cur); },
                    [this, st, octV] { showNumber("OCTAVE (-4 .. +4)", octV, -4.0F, 4.0F, 0, [this, st](float x) { UpperState cur = currentUpper(st); cur.octave = static_cast<std::int8_t>(std::clamp(rI(x), -4, 4)); commitTune(cur); }); },
                    [this, st] { UpperState cur = currentUpper(st); cur.octave = 0; commitTune(cur); });
        upLabel(tcx(3), "OCTAVE");
        upValue(tcx(3), sgn(st.octave));
        const float trV = static_cast<float>(st.transpose);
        knobControl(c, tcx(4), kpy, kpr, trV, -12.0F, 12.0F, 1.0F, 300.0F, false, "", "", 110.0F,
                    [this, st](float nv) { UpperState cur = currentUpper(st); cur.transpose = static_cast<std::int8_t>(std::clamp(rI(nv), -12, 12)); commitTune(cur); },
                    [this, st, trV] { showNumber("TRANSPOSE (-12 .. +12)", trV, -12.0F, 12.0F, 0, [this, st](float x) { UpperState cur = currentUpper(st); cur.transpose = static_cast<std::int8_t>(std::clamp(rI(x), -12, 12)); commitTune(cur); }); },
                    [this, st] { UpperState cur = currentUpper(st); cur.transpose = 0; commitTune(cur); });
        upLabel(tcx(4), "TRANSPOSE");
        upValue(tcx(4), sgn(st.transpose));
    }

    // ---- the keys at the bottom
    const float by0 = sec.bottom - 30.0F, by1 = sec.bottom - 4.0F;
    const RectF kp(sec.left, by0, sec.left + 200.0F, by1), kr(sec.left + 216.0F, by0, sec.left + 416.0F, by1), ke(sec.right - 300.0F, by0, sec.right, by1);
    stripToggle(c, kp, "PRESETS", false, C_ACCENT, 13.0F);
    stripToggle(c, kr, "RESET", false, C_AMBER, 13.0F);
    stripToggle(c, ke, "ADVANCED (all settings)", false, C_ACCENT, 12.0F);
    hit(kp, [this](float, float) { suPage_ = 11; invalidate(); });
    hit(kr, [this, u](float, float) { suAskReset(u); });
    hit(ke, [this](float, float) { suOscAdv_ = true; invalidate(); });
}

void SilvetonSamplerView::suPageOsc(Canvas& c, const RectF& sec, int u) {
    if (!suOscAdv_) { suPageOscSimple(c, sec, u); return; }
    suGenRow(c, sec, u, false);
    const int g = std::clamp(suGen_, 0, su::kGens - 1);
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    // sub pages and the keys that always matter
    const float y0 = sec.top + 52.0F, y1 = y0 + 34.0F;
    static const char* const subs[3] = {"ЗВУК И ВЪЛНИ", "ТОН И СИЛА", "ФИЛТЪР НА ОСЦИЛАТОРА"};
    float x = sec.left;
    for (int i = 0; i < 3; ++i) {
        const float w = i == 2 ? 170.0F : 110.0F;
        const RectF r(x, y0, x + w, y1);
        stripToggle(c, r, subs[i], suSub_ == i, C_AMBER, 11.0F);
        hit(r, [this, i](float, float) { suSub_ = i; invalidate(); });
        x += w + 8.0F;
    }
    {   // the way back to the simple screen
        const RectF rb(x + 6.0F, y0, x + 116.0F, y1);
        stripToggle(c, rb, "◀ ПРОСТ ЕКРАН", false, C_ACCENT, 10.5F);
        hit(rb, [this](float, float) { suOscAdv_ = false; invalidate(); });
    }
    {
        const RectF rm(sec.right - 372.0F, y0, sec.right - 202.0F, y1);
        suChoice(c, rm, u, su::genId(g, su::GN_METHOD), su::kMethods, [](int k) { return std::string(su::methodName(k)); }, "МЕТОД НА ЗВУКА");
        const RectF rr(sec.right - 192.0F, y0, sec.right - 82.0F, y1);
        suChoice(c, rr, u, su::genId(g, su::GN_ROUTE), su::kRoutes, [](int k) { return std::string(su::routeName(k)); }, "ПРЕМИНАВА ПРЕЗ");
        const RectF rmu(sec.right - 74.0F, y0, sec.right, y1);
        suSwitch(c, rmu, u, su::genId(g, su::GN_MUTE), "ЗАГЛУШИ", "ДА", "НЕ");
    }
    const RectF area(sec.left, y1 + 28.0F, sec.right, sec.bottom);
    if (m == su::M_OFF && suSub_ != 0) {
        text(c, "Този осцилатор е изключен. Избери МЕТОД (горе вдясно), за да звучи.", area.centerX(), area.top + 100.0F, 15.0F, C_KNOB_LABEL, Opt().center().maxW(area.width() - 30.0F));
        return;
    }
    if (suSub_ == 0) { suGenMethod(c, area, u, g, false); return; }
    const float unit = area.width() / 9.0F;
    const float hw = unit - 4.0F;
    const auto cellX = [&](int col) { return area.left + unit * (static_cast<float>(col) + 0.5F); };
    const float yA = area.top + 26.0F, yB = area.top + 126.0F;
    const auto envName = [](int k) { return k == 0 ? std::string("НЯМА") : "ОБВ. " + std::to_string(k); };
    if (suSub_ == 1) {
        const bool wave = m == su::M_WAVE;
        const bool fixed = suV(u, su::genId(g, su::GN_FIXED)) >= 0.5F;
        suKnob(c, cellX(0), yA, 16.0F, hw, u, su::genId(g, su::GN_LEVEL));
        suKnob(c, cellX(1), yA, 16.0F, hw, u, su::genId(g, su::GN_PAN));
        suKnob(c, cellX(2), yA, 16.0F, hw, u, su::genId(g, su::GN_OCT));
        suKnob(c, cellX(3), yA, 16.0F, hw, u, su::genId(g, su::GN_SEMI));
        suKnob(c, cellX(4), yA, 16.0F, hw, u, su::genId(g, su::GN_FINE));
        suSwitch(c, RectF(cellX(5) - 36.0F, yA - 20.0F, cellX(5) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FIXED), "ФИКСИРАНО", "ДА", "НЕ");
        if (fixed) suKnob(c, cellX(6), yA, 16.0F, hw, u, su::genId(g, su::GN_FIXHZ)); else suKnob(c, cellX(6), yA, 16.0F, hw, u, su::genId(g, su::GN_RATIO));
        suKnob(c, cellX(7), yA, 16.0F, hw, u, su::genId(g, su::GN_VELLEV));
        suChoice(c, RectF(cellX(0) - 36.0F, yB - 20.0F, cellX(0) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_AMPENV), su::kEnvs + 1,
                 envName, "СИЛА ОТ ОБВ.");
        suChoice(c, RectF(cellX(1) - 36.0F, yB - 20.0F, cellX(1) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_PENV), su::kEnvs + 1,
                 envName, "ТОН ОТ ОБВ.");
        if (rI(suV(u, su::genId(g, su::GN_PENV))) > 0) suKnob(c, cellX(2), yB, 16.0F, hw, u, su::genId(g, su::GN_PENVAMT));
        if (wave) {
            suChoice(c, RectF(cellX(3) - 36.0F, yB - 20.0F, cellX(3) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_UNISON), 4, [](int k) { return std::to_string(k + 1); }, "ЮНИСОН", 1);
            suKnob(c, cellX(4), yB, 16.0F, hw, u, su::genId(g, su::GN_UNIDET));
            suKnob(c, cellX(5), yB, 16.0F, hw, u, su::genId(g, su::GN_UNISPR));
            suKnob(c, cellX(6), yB, 16.0F, hw, u, su::genId(g, su::GN_PHASE));
            suSwitch(c, RectF(cellX(7) - 36.0F, yB - 20.0F, cellX(7) + 36.0F, yB + 14.0F), u, su::genId(g, su::GN_SYNC), "СИНХРОН", "ДА", "НЕ");
            if (suV(u, su::genId(g, su::GN_SYNC)) >= 0.5F) suKnob(c, cellX(8), yB, 16.0F, hw, u, su::genId(g, su::GN_SYNCR));
        } else {
            text(c, "Юнисон (копия), фаза и синхрон има само методът ВЪЛНА.", cellX(3) - 40.0F, yB + 4.0F, 12.0F, C_HINT, Opt().maxW(area.right - cellX(3)));
        }
    } else {
        suChoice(c, RectF(cellX(0) - 36.0F, yA - 20.0F, cellX(0) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FTYPE), su::kOwnFilters, [](int k) { return std::string(su::ownFilterName(k)); }, "ВИД ФИЛТЪР");
        if (rI(suV(u, su::genId(g, su::GN_FTYPE))) != su::OF_OFF) {
            suKnob(c, cellX(1), yA, 16.0F, hw, u, su::genId(g, su::GN_FCUT));
            suKnob(c, cellX(2), yA, 16.0F, hw, u, su::genId(g, su::GN_FRES));
            suKnob(c, cellX(3), yA, 16.0F, hw, u, su::genId(g, su::GN_FKEY));
            suChoice(c, RectF(cellX(4) - 36.0F, yA - 20.0F, cellX(4) + 36.0F, yA + 14.0F), u, su::genId(g, su::GN_FENV), su::kEnvs + 1,
                     envName, "КОЯ ОБВИВКА");
            if (rI(suV(u, su::genId(g, su::GN_FENV))) > 0) suKnob(c, cellX(5), yA, 16.0F, hw, u, su::genId(g, su::GN_FENVAMT));
            text(c, su::filterTypeHelp(rI(suV(u, su::genId(g, su::GN_FTYPE)))), area.left, area.bottom - 8.0F, 12.0F, C_HINT, Opt().maxW(area.width()));
        } else {
            text(c, "Всеки осцилатор може да има свой филтър. Освен него има и два общи (страница ФИЛТРИ).", cellX(1) - 30.0F, yA + 4.0F, 13.0F, C_HINT, Opt().maxW(area.right - cellX(1) + 20.0F));
        }
    }
}

// ---------------------------------------------------------------- FM / PM: the links between the generators
void SilvetonSamplerView::suPageLinks(Canvas& c, const RectF& sec, int u) {
    suLinkDst_ = std::clamp(suLinkDst_, 0, su::kGens - 1);
    suLinkSrc_ = std::clamp(suLinkSrc_, 0, su::kGens - 1);
    // the matrix: a row = the generator that is changed, a column = the one that changes it
    const float labW = 62.0F, cw = 70.0F, ch = 40.0F, top = sec.top + 36.0F;
    text(c, "КОЛОНА = КОЙ ПРОМЕНЯ  ·  РЕД = КОЙ СЕ ПРОМЕНЯ", sec.left + 2.0F, sec.top + 12.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.1F).maxW(labW + 6.0F * cw));
    for (int s = 0; s < su::kGens; ++s) text(c, "ОСЦ " + std::to_string(s + 1), sec.left + labW + static_cast<float>(s) * cw + cw * 0.5F, sec.top + 30.0F, 12.0F, C_VALUE, Opt().center().bold());
    for (int d = 0; d < su::kGens; ++d) {
        const float y = top + static_cast<float>(d) * (ch + 3.0F);
        const int md = rI(suV(u, su::genId(d, su::GN_METHOD)));
        text(c, "ОСЦ " + std::to_string(d + 1), sec.left + 2.0F, y + 25.0F, 12.0F, md == su::M_OFF ? C_HINT : C_VALUE, Opt().bold());
        for (int s = 0; s < su::kGens; ++s) {
            const RectF r(sec.left + labW + static_cast<float>(s) * cw, y, sec.left + labW + static_cast<float>(s) * cw + cw - 3.0F, y + ch);
            const int t = rI(suV(u, su::linkType(d, s)));
            const float amt = suV(u, su::linkAmt(d, s));
            const bool sel = d == suLinkDst_ && s == suLinkSrc_;
            fill(c, r, 6.0F, sel ? Color::rgb(86, 92, 106) : (t != 0 ? Color::rgb(66, 72, 86) : Color::rgb(44, 48, 56)));
            if (sel) fill(c, RectF(r.left, r.bottom - 3.0F, r.right, r.bottom), 1.5F, C_ACCENT);
            if (t != 0) {
                text(c, su::linkTypeName(t), r.centerX(), r.top + 17.0F, 12.0F, C_VALUE, Opt().center().bold().maxW(r.width() - 4.0F));
                fill(c, RectF(r.left + 8.0F, r.top + 26.0F, r.left + 8.0F + (r.width() - 16.0F) * amt, r.top + 31.0F), 2.0F, C_ACCENT);
            } else if (d == s) text(c, "·", r.centerX(), r.centerY() + 5.0F, 14.0F, C_HINT, Opt().center());
            hit(r, [this, d, s](float, float) { suLinkDst_ = d; suLinkSrc_ = s; invalidate(); });
        }
    }
    // the chosen link
    const float L = sec.left + labW + 6.0F * cw + 22.0F, R = sec.right;
    const int d = suLinkDst_, s = suLinkSrc_;
    const int md = rI(suV(u, su::genId(d, su::GN_METHOD)));
    const int ms = rI(suV(u, su::genId(s, su::GN_METHOD)));
    text(c, "ОСЦ " + std::to_string(d + 1) + " ← ОСЦ " + std::to_string(s + 1), L, sec.top + 20.0F, 17.0F, C_VALUE, Opt().bold().maxW(R - L));
    text(c, std::string(su::methodName(md)) + " ← " + su::methodName(ms), L, sec.top + 36.0F, 11.0F, C_KNOB_LABEL, Opt().maxW(R - L));
    const int tNow = rI(suV(u, su::linkType(d, s)));
    const float kw = (R - L - 3.0F * 6.0F) / 4.0F;
    for (int t = 0; t < su::kLinkTypes; ++t) {
        const bool waveOnly = t == su::L_PM || t == su::L_FM || t == su::L_SYNC || t == su::L_WARP;
        const bool usable = md == su::M_WAVE || !waveOnly;   // PM, FM, SYNC and WARP act on the wave generator only
        const RectF r(L + static_cast<float>(t % 4) * (kw + 6.0F), sec.top + 46.0F + static_cast<float>(t / 4) * 38.0F, L + static_cast<float>(t % 4) * (kw + 6.0F) + kw, sec.top + 76.0F + static_cast<float>(t / 4) * 38.0F);
        if (usable) {
            stripToggle(c, r, su::linkTypeName(t), tNow == t, C_ACCENT, 12.0F);
            hit(r, [this, u, d, s, t](float, float) { suSet(u, su::linkType(d, s), static_cast<float>(t)); });
        } else {
            fill(c, r, 6.0F, Color::rgb(38, 41, 48));
            text(c, su::linkTypeName(t), r.centerX(), r.centerY() + 4.0F, 12.0F, C_HINT, Opt().center());
        }
    }
    {
        const auto lines = wrapLines(su::linkTypeHelp(tNow), 12.0F, Face::Regular, R - L);
        for (std::size_t i = 0; i < lines.size() && i < 2; ++i) text(c, lines[i], L, sec.top + 128.0F + static_cast<float>(i) * 15.0F, 12.0F, C_VALUE, Opt());
        text(c, tNow == su::L_OFF ? "Избери вид или само завърти КОЛКО — видът се избира сам." : "PM, FM, СИНХР. и ОГЪВ. действат само върху осцилатор с метод ВЪЛНА.", L, sec.top + 160.0F, 10.0F, C_HINT, Opt().maxW(R - L));
        if (md == su::M_OFF || ms == su::M_OFF) {
            text(c, std::string("ОСЦИЛАТОР ") + std::to_string(md == su::M_OFF ? d + 1 : s + 1) + " е изключен — тази връзка не се чува. Включи го от страница ОСЦИЛ.", L, sec.top + 238.0F, 11.0F, C_AMBER, Opt().bold().maxW(R - L));
        }
    }
    suKnob(c, L + 56.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::linkAmt(d, s));
    // the operator (the generator that is changed): its ratio and level
    const bool fixed = suV(u, su::genId(d, su::GN_FIXED)) >= 0.5F;
    if (fixed) suKnob(c, L + 166.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_FIXHZ));
    else suKnob(c, L + 166.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_RATIO));
    suKnob(c, L + 276.0F, sec.top + 192.0F, 16.0F, 110.0F, u, su::genId(d, su::GN_LEVEL));
    suSwitch(c, RectF(L + 340.0F, sec.top + 172.0F, R, sec.top + 206.0F), u, su::genId(d, su::GN_FIXED), "ФИКСИРАНО", "ДА", "НЕ");
    suSwitch(c, RectF(L, sec.top + 262.0F, L + 110.0F, sec.top + 292.0F), u, su::genId(d, su::GN_MUTE), "ЗАГЛУШИ ОСЦ " + std::to_string(d + 1), "ДА", "НЕ");
    suSwitch(c, RectF(L + 130.0F, sec.top + 262.0F, L + 240.0F, sec.top + 292.0F), u, su::genId(s, su::GN_MUTE), "ЗАГЛУШИ ОСЦ " + std::to_string(s + 1), "ДА", "НЕ");
    text(c, "Заглушеният осцилатор не се чува, но все така променя другите.", L, sec.top + 328.0F, 10.0F, C_HINT, Opt().maxW(R - L));
}

// ---------------------------------------------------------------- ФИЗИКА: strings, tubes, reeds, modes
void SilvetonSamplerView::suPagePhysics(Canvas& c, const RectF& sec, int u) {
    suGenRow(c, sec, u, true);
    const int g = std::clamp(suGen_, 0, su::kGens - 1);
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    const bool phys = m == su::M_STRING || m == su::M_WIND || m == su::M_MODAL;
    const float y0 = sec.top + 58.0F;
    if (!phys) {
        text(c, "ОСЦИЛАТОР " + std::to_string(g + 1) + " не е физичен. Направи го:", sec.left + 4.0F, y0 + 20.0F, 15.0F, C_VALUE, Opt().bold());
        static const int kinds[3] = {su::M_STRING, su::M_WIND, su::M_MODAL};
        static const char* const nm[3] = {"СТРУНА (щипване, чук, лък)", "ДУХОВ (кларинет, сакс, зурна…)", "УДАРНО ТЯЛО (камбана, плоча…)"};
        for (int i = 0; i < 3; ++i) {
            const RectF r(sec.left + 4.0F + static_cast<float>(i) * 290.0F, y0 + 40.0F, sec.left + 4.0F + static_cast<float>(i) * 290.0F + 280.0F, y0 + 84.0F);
            stripToggle(c, r, nm[i], false, C_AMBER, 12.0F);
            hit(r, [this, u, g, i](float, float) { suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(kinds[i])); });
        }
        text(c, "Струната и духовият са модел на линия със закъснение (вълновод), ударното тяло е набор от резонатори. Всеки може да се възбужда от друг осцилатор (ВЪЗБУДЕН ОТ).",
             sec.left + 4.0F, y0 + 120.0F, 12.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
        return;
    }
    suGenMethod(c, RectF(sec.left, y0, sec.right, sec.bottom - 22.0F), u, g, true);
    if (m == su::M_WIND) text(c, "Дъхът (ДЪХ ОТ КОНТРОЛЕР) следва контролер CC2; силата на клавиша и CC11 се връзват от страница МОДУЛ. / MIDI.", sec.left + 4.0F, sec.bottom - 6.0F, 11.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
    else text(c, "Струна и ударно тяло звучат и затихват сами (ЗАТИХВАНЕ = колко дълго). Върти регулатор при държан клавиш — ударът се повтаря.", sec.left + 4.0F, sec.bottom - 6.0F, 11.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
}

} // namespace silveton::ui::classic
