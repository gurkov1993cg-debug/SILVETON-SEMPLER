// SILVETON_NEW_LOOK_V1: the SILVETON SYNTH editor is drawn in the new look (black wells, blue values and curves, amber = on, dark lists); every control and touch is the same as before.
// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH (part 2: ВЪЛНИ = the wave editor, ФИЛТРИ, ОБВИВКИ, МОДУЛ.).
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
constexpr float kPiF = 3.14159265358979F;
}  // namespace

// a drawn wave (64 points -1..1) into slot 0..3 of the patch (kept as 0.5 + 0.5 * v)
void SilvetonSamplerView::suWaveSet(int u, int slot, const float* pts) {
    std::vector<float> v(static_cast<std::size_t>(su::kDrawLen));
    for (int i = 0; i < su::kDrawLen; ++i) v[static_cast<std::size_t>(i)] = 0.5F + 0.5F * std::clamp(pts[i], -1.0F, 1.0F);
    suBlock(u, su::drawId(slot, 0), v);
}

// ---------------------------------------------------------------- ВЪЛНИ: pictures of the waves
void SilvetonSamplerView::suPageGallery(Canvas& c, const RectF& sec, int u) {
    // the picture of a wave: 64 points -1..1 in a rect (every `step`-th point)
    const auto drawWavePicture = [this](Canvas& cv, const RectF& r, const float* pts, ColorInt col, float width, int step) {
        const float mid = r.centerY();
        const float amp = r.height() * 0.5F - 3.0F;
        const float dx = r.width() / static_cast<float>(su::kDrawLen);
        for (int i = 0; i + step < su::kDrawLen; i += step) {
            const float x0 = r.left + (static_cast<float>(i) + 0.5F) * dx, x1 = r.left + (static_cast<float>(i + step) + 0.5F) * dx;
            line(cv, x0, mid - std::clamp(pts[i], -1.0F, 1.0F) * amp, x1, mid - std::clamp(pts[i + step], -1.0F, 1.0F) * amp, col, width);
        }
    };
    const float* patch = suP(u).data() + 1;
    suPickGen_ = std::clamp(suPickGen_, 0, su::kGens - 1);
    const int total = su::kWaveDrawn0 + su::kDrawnWaves;   // 64 calculated + 4 drawn
    suPick_ = std::clamp(suPick_, 0, total - 1);
    // the pictures of the 64 calculated waves are made once; the 4 drawn ones are read from the patch every time
    static std::vector<float> cache;
    if (cache.empty()) {
        cache.assign(static_cast<std::size_t>(su::kMathWaves) * static_cast<std::size_t>(su::kDrawLen), 0.0F);
        for (int w = 0; w < su::kMathWaves; ++w) su::waveChoicePoints(w, nullptr, cache.data() + static_cast<std::size_t>(w) * static_cast<std::size_t>(su::kDrawLen));
    }
    float drawn[su::kDrawnWaves][su::kDrawLen];
    for (int i = 0; i < su::kDrawnWaves; ++i) su::waveChoicePoints(su::kWaveDrawn0 + i, patch, drawn[i]);
    const auto ptsOf = [&](int w) -> const float* { return w < su::kMathWaves ? cache.data() + static_cast<std::size_t>(w) * static_cast<std::size_t>(su::kDrawLen) : drawn[w - su::kMathWaves]; };
    const int g = suPickGen_;
    const bool isWave = rI(suV(u, su::genId(g, su::GN_METHOD))) == su::M_WAVE;
    const int curA = isWave ? rI(suV(u, su::genId(g, su::GN_SEL1))) : -1, curB = isWave ? rI(suV(u, su::genId(g, su::GN_SEL2))) : -1;

    const bool choose = suPickSlot_ >= 0;
    if (choose) {
        suPickGen_ = std::clamp(suPickGen_, 0, su::kGens - 1);
        text(c, std::string("CHOOSE WAVEFORM ") + (suPickSlot_ == 0 ? "A" : "B") + " FOR OSCILLATOR " + std::to_string(suPickGen_ + 1) + " — touch a picture", sec.left + 2.0F, sec.top + 12.0F, 12.0F, NL_AMBER, Opt().bold().spacing(0.12F).maxW(610.0F));
    } else {
        text(c, "WAVES — touch a picture to see it large on the right", sec.left + 2.0F, sec.top + 12.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.12F).maxW(600.0F));
    }
    // the grid
    constexpr int kCols = 10, kRows = 7;
    const float gx = sec.left, gy = sec.top + 22.0F, gw = 600.0F, gap = 4.0F;
    const float cw = (gw - gap * static_cast<float>(kCols - 1)) / static_cast<float>(kCols);
    const float ch = (sec.bottom - gy - gap * static_cast<float>(kRows - 1)) / static_cast<float>(kRows);
    for (int w = 0; w < total; ++w) {
        const int col = w % kCols, row = w / kCols;
        const RectF r(gx + static_cast<float>(col) * (cw + gap), gy + static_cast<float>(row) * (ch + gap), gx + static_cast<float>(col) * (cw + gap) + cw, gy + static_cast<float>(row) * (ch + gap) + ch);
        const bool sel = w == suPick_;
        if (sel) fill(c, r, 6.0F, NL_BLUE);
        fill(c, sel ? RectF(r.left + 2.0F, r.top + 2.0F, r.right - 2.0F, r.bottom - 2.0F) : r, 5.0F, w >= su::kWaveDrawn0 ? Color::rgb(36, 30, 14) : Color::rgb(11, 14, 18));   // SILVETON_NEW_LOOK_V1: black wells, the drawn waves a little warm
        drawWavePicture(c, RectF(r.left + 4.0F, r.top + 9.0F, r.right - 4.0F, r.bottom - 3.0F), ptsOf(w), sel ? NL_VALUE : NL_BLUE, 1.3F, 1);
        text(c, std::to_string(w + 1), r.left + 4.0F, r.top + 9.0F, 8.0F, NL_TXT2, Opt());
        if (w == curA) text(c, "A", r.right - 5.0F, r.top + 10.0F, 9.0F, NL_AMBER, Opt().right().bold());
        if (w == curB) text(c, "B", r.right - (w == curA ? 15.0F : 5.0F), r.top + 10.0F, 9.0F, NL_AMBER, Opt().right().bold());
        hit(r, [this, w, u](float, float) {
            if (suPickSlot_ < 0) { suPick_ = w; invalidate(); return; }
            // choosing: the tap puts the wave into the oscillator and the player is back on ОСЦИЛ.
            const int gg = suPickGen_, slot = suPickSlot_;
            if (rI(suV(u, su::genId(gg, su::GN_METHOD))) != su::M_WAVE) suSet(u, su::genId(gg, su::GN_METHOD), static_cast<float>(su::M_WAVE));
            suSet(u, su::genId(gg, slot == 0 ? su::GN_SEL1 : su::GN_SEL2), static_cast<float>(w));
            suStatus_ = "OSC " + std::to_string(gg + 1) + ": WAVEFORM " + (slot == 0 ? "A" : "B") + " = " + su::waveName(w);
            suStatusUntilMs_ = nowMs() + 4000;
            suPickSlot_ = -1; suPage_ = 0;
            invalidate();
        });
    }
    // МОИ ВЪЛНИ: the own waves saved with ЗАПАЗИ ВЪЛНАТА (the WAVES folder) - in the two free cells of the grid
    {
        const RectF rMy(gx + static_cast<float>(kCols - 2) * (cw + gap), gy + static_cast<float>(kRows - 1) * (ch + gap),
                        gx + static_cast<float>(kCols) * cw + static_cast<float>(kCols - 1) * gap, gy + static_cast<float>(kRows - 1) * (ch + gap) + ch);
        stripToggle(c, rMy, "MY WAVES", false, C_AMBER, 11.0F);
        hit(rMy, [this, u](float, float) {
            const auto names = sampler.suseUserWaves();
            if (names.empty()) { showMessage("WAVES", "You have no saved waves yet. Draw one in DRAW and press SAVE THE WAVE."); return; }
            showItems("MY WAVES — choose", names, [this, u, names](int k) {
                if (k < 0 || k >= static_cast<int>(names.size())) return;
                std::vector<float> loaded;
                const auto err = sampler.suseLoadWave(names[static_cast<std::size_t>(k)], loaded);
                if (err) { suStatus_ = *err; suStatusUntilMs_ = nowMs() + 4000; invalidate(); return; }
                suWaveSlot_ = std::clamp(suWaveSlot_, 0, su::kDrawnWaves - 1);
                suWaveSet(u, suWaveSlot_, loaded.data());
                const int gg = std::clamp(suPickGen_, 0, su::kGens - 1);
                const int sel = suPickSlot_ == 1 ? su::GN_SEL2 : su::GN_SEL1;   // in the choose mode: the slot asked for
                if (rI(suV(u, su::genId(gg, su::GN_METHOD))) != su::M_WAVE) suSet(u, su::genId(gg, su::GN_METHOD), static_cast<float>(su::M_WAVE));
                suSet(u, su::genId(gg, sel), static_cast<float>(su::kWaveDrawn0 + suWaveSlot_));
                if (suPickSlot_ >= 0) { suPickSlot_ = -1; suPage_ = 0; }
                suPick_ = su::kWaveDrawn0 + suWaveSlot_;
                suStatus_ = std::string("The saved wave is WAVE ") + (sel == su::GN_SEL1 ? "A" : "B") + " of OSC " + std::to_string(gg + 1) + ".";
                suStatusUntilMs_ = nowMs() + 4000; invalidate();
            });
        });
    }
    // the chosen wave, big
    const float X = sec.left + 620.0F, W = sec.right - X;
    const RectF pic(X, sec.top + 22.0F, X + W, sec.top + 142.0F);
    nlLcd(c, pic, 8.0F);   // SILVETON_NEW_LOOK_V1
    line(c, pic.left, pic.centerY(), pic.right, pic.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
    for (int q = 1; q < 4; ++q) line(c, pic.left + pic.width() * static_cast<float>(q) / 4.0F, pic.top + 4.0F, pic.left + pic.width() * static_cast<float>(q) / 4.0F, pic.bottom - 4.0F, Color::argb(28, 255, 255, 255), 1.0F);
    drawWavePicture(c, RectF(pic.left + 6.0F, pic.top + 4.0F, pic.right - 6.0F, pic.bottom - 4.0F), ptsOf(suPick_), NL_BLUE, 2.4F, 1);
    text(c, su::waveName(suPick_), X, sec.top + 164.0F, 16.0F, NL_VALUE, Opt().bold().maxW(W));
    text(c, suPick_ >= su::kWaveDrawn0 ? "drawn wave " + std::to_string(suPick_ - su::kWaveDrawn0 + 1) + " (edited in DRAW)" : "wave no. " + std::to_string(suPick_ + 1), X, sec.top + 180.0F, 10.0F, NL_TXT2, Opt().maxW(W));
    if (choose) {   // the small panel of the choose mode: what is there now, and the way back
        text(c, isWave ? std::string("Now: ") + su::waveName(suPickSlot_ == 0 ? curA : curB) : std::string("This oscillator does not have the WAVE method yet."), X, sec.top + 202.0F, 11.0F, NL_BLUE, Opt().bold().maxW(W));
        const RectF rc(X, sec.top + 214.0F, X + W, sec.top + 252.0F);
        stripToggle(c, rc, "◀ CANCEL — back", false, C_AMBER, 13.0F);
        hit(rc, [this](float, float) { suPickSlot_ = -1; suPage_ = 0; invalidate(); });
        text(c, "Touch a picture on the left and it becomes the waveform.", X, sec.top + 276.0F, 10.0F, NL_TXT2, Opt().maxW(W));
        return;
    }
    // into which oscillator
    text(c, "PUT INTO OSCILLATOR:", X, sec.top + 202.0F, 10.0F, NL_BLUE, Opt().bold().spacing(0.12F));
    const float kw = (W - 5.0F * 4.0F) / 6.0F;
    for (int i = 0; i < su::kGens; ++i) {
        const RectF r(X + static_cast<float>(i) * (kw + 4.0F), sec.top + 208.0F, X + static_cast<float>(i) * (kw + 4.0F) + kw, sec.top + 234.0F);
        stripToggle(c, r, "OSC " + std::to_string(i + 1), g == i, C_ACCENT, 10.0F);
        hit(r, [this, i](float, float) { suPickGen_ = i; invalidate(); });
    }
    const auto put = [this, u, g](int sel, const char* which) {
        if (rI(suV(u, su::genId(g, su::GN_METHOD))) != su::M_WAVE) suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(su::M_WAVE));
        suSet(u, su::genId(g, sel), static_cast<float>(suPick_));
        suStatus_ = "OSC " + std::to_string(g + 1) + ": " + which + " = " + su::waveName(suPick_);
        suStatusUntilMs_ = nowMs() + 4000;
        invalidate();
    };
    const RectF ba(X, sec.top + 242.0F, X + W, sec.top + 272.0F), bb(X, sec.top + 278.0F, X + W, sec.top + 308.0F);
    stripToggle(c, ba, "PUT AS WAVE A", curA == suPick_, C_ACCENT, 12.0F);
    stripToggle(c, bb, "PUT AS WAVE B", curB == suPick_, C_ACCENT, 12.0F);
    hit(ba, [put](float, float) { put(su::GN_SEL1, "WAVE A"); });
    hit(bb, [put](float, float) { put(su::GN_SEL2, "WAVE B"); });
    if (isWave) text(c, "Now in OSC " + std::to_string(g + 1) + ":  A = " + su::waveName(curA) + "   B = " + su::waveName(curB), X, sec.top + 324.0F, 10.0F, NL_VALUE, Opt().maxW(W));
    else text(c, "OSC " + std::to_string(g + 1) + " does not have the WAVE method yet — it will, as soon as you put a wave.", X, sec.top + 324.0F, 10.0F, NL_AMBER, Opt().maxW(W));
    text(c, "A and B are mixed with the MIX A→B knob (OSC. → SOUND AND WAVES).", X, sec.top + 340.0F, 9.0F, NL_TXT2, Opt().maxW(W));
}

// ---------------------------------------------------------------- РИСУВАНЕ: the wave editor
void SilvetonSamplerView::suPageWaves(Canvas& c, const RectF& sec, int u) {
    suWaveSlot_ = std::clamp(suWaveSlot_, 0, su::kDrawnWaves - 1);
    const int slot = suWaveSlot_;
    const float* patch = suP(u).data() + 1;
    float pts[su::kDrawLen];
    su::waveChoicePoints(su::kWaveDrawn0 + slot, patch, pts);
    // row 1: the four drawn waves and the way of working
    for (int i = 0; i < su::kDrawnWaves; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 86.0F, sec.top, sec.left + static_cast<float>(i) * 86.0F + 80.0F, sec.top + 34.0F);
        stripToggle(c, r, su::waveName(su::kWaveDrawn0 + i), slot == i, C_ACCENT, 10.0F);
        hit(r, [this, i](float, float) { suWaveSlot_ = i; invalidate(); });
    }
    static const char* const modes[2] = {"DRAW", "HARMONICS"};
    for (int i = 0; i < 2; ++i) {
        const RectF r(sec.left + 356.0F + static_cast<float>(i) * 100.0F, sec.top, sec.left + 356.0F + static_cast<float>(i) * 100.0F + (i == 0 ? 94.0F : 104.0F), sec.top + 34.0F);
        stripToggle(c, r, modes[i], suWaveMode_ == i, C_AMBER, 11.0F);
        hit(r, [this, i](float, float) { suWaveMode_ = i; invalidate(); });
    }
    // the wave
    const RectF cv(sec.left, sec.top + 44.0F, sec.left + 560.0F, sec.top + 260.0F);
    nlLcd(c, cv, 8.0F);   // SILVETON_NEW_LOOK_V1
    line(c, cv.left, cv.centerY(), cv.right, cv.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
    for (int q = 1; q < 4; ++q) line(c, cv.left + cv.width() * static_cast<float>(q) / 4.0F, cv.top + 4.0F, cv.left + cv.width() * static_cast<float>(q) / 4.0F, cv.bottom - 4.0F, Color::argb(28, 255, 255, 255), 1.0F);
    const float px = cv.width() / static_cast<float>(su::kDrawLen);
    for (int i = 0; i < su::kDrawLen; ++i) {
        const float x = cv.left + (static_cast<float>(i) + 0.5F) * px;
        const float y = cv.centerY() - pts[i] * (cv.height() * 0.5F - 6.0F);
        line(c, x, cv.centerY(), x, y, Color::argb(90, 51, 160, 255), px * 0.7F);
        if (i + 1 < su::kDrawLen) {
            const float x2 = x + px, y2 = cv.centerY() - pts[i + 1] * (cv.height() * 0.5F - 6.0F);
            line(c, x, y, x2, y2, NL_BLUE, 2.0F);
        }
    }
    text(c, std::string(su::waveName(su::kWaveDrawn0 + slot)) + " · one wave = 64 points", cv.left + 10.0F, cv.top + 16.0F, 11.0F, NL_TXT, Opt());
    if (suWaveMode_ == 0) {
        const auto drawPoint = [this, u, slot, cv](float x, float y, bool final) {
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            const auto idxOf = [cv](float xp) { return std::clamp(static_cast<int>((xp - cv.left) / cv.width() * static_cast<float>(su::kDrawLen)), 0, su::kDrawLen - 1); };
            const auto valOf = [cv](float py) { return std::clamp(1.0F - 2.0F * (py - cv.top - 6.0F) / (cv.height() - 12.0F), -1.0F, 1.0F); };
            const int i1 = idxOf(x);
            const float v1 = valOf(y);
            // the first part of a stroke starts at the press point: the drag reports only after the finger has moved
            const bool strokeStart = suDrawLastI_ < 0;
            int i0 = strokeStart ? idxOf(downX) : suDrawLastI_;
            float v0 = strokeStart ? valOf(downY) : suDrawLastV_;
            const int step = i1 >= i0 ? 1 : -1;
            for (int i = i0;; i += step) {
                const float t = i1 == i0 ? 1.0F : static_cast<float>(i - i0) / static_cast<float>(i1 - i0);
                cur[i] = v0 + (v1 - v0) * t;
                if (i == i1) break;
            }
            suDrawLastI_ = final ? -1 : i1; suDrawLastV_ = v1;
            suWaveSet(u, slot, cur);
            // the drawn wave sounds at once: it becomes ВЪЛНА А of the oscillator the page is set to (suPickGen_);
            // SILVETON_SUSE_SAMPLE_V1: a СЕМПЪЛ oscillator stays СЕМПЪЛ - the drawn wave becomes its curve / PM wave
            const int gg = std::clamp(suPickGen_, 0, su::kGens - 1);
            const int mg = rI(suV(u, su::genId(gg, su::GN_METHOD)));
            if (mg != su::M_WAVE && mg != su::M_SAMPLE) suSet(u, su::genId(gg, su::GN_METHOD), static_cast<float>(su::M_WAVE));
            if (rI(suV(u, su::genId(gg, su::GN_SEL1))) != su::kWaveDrawn0 + slot) suSet(u, su::genId(gg, su::GN_SEL1), static_cast<float>(su::kWaveDrawn0 + slot));
        };
        hit(cv, [drawPoint](float x, float y) { drawPoint(x, y, true); }, nullptr, drawPoint);
    }
    // the spectrum (amplitude of harmonic 1..31) and the phases
    float amp[su::kEditHarmonics], ph[su::kEditHarmonics];
    su::waveHarmonics(pts, amp, ph);
    const RectF ar(sec.left, sec.top + 266.0F, sec.left + 560.0F, sec.top + 306.0F);
    const RectF pr(sec.left, sec.top + 322.0F, sec.left + 560.0F, sec.top + 356.0F);
    nlLcd(c, ar, 6.0F);   // SILVETON_NEW_LOOK_V1
    nlLcd(c, pr, 6.0F);   // SILVETON_NEW_LOOK_V1
    line(c, pr.left, pr.centerY(), pr.right, pr.centerY(), Color::argb(60, 255, 255, 255), 1.0F);
    const float bw = ar.width() / static_cast<float>(su::kEditHarmonics);
    for (int k = 0; k < su::kEditHarmonics; ++k) {
        const float x0 = ar.left + static_cast<float>(k) * bw;
        const float h = std::clamp(amp[k], 0.0F, 1.0F) * (ar.height() - 6.0F);
        if (h > 0.5F) fill(c, RectF(x0 + 2.0F, ar.bottom - 3.0F - h, x0 + bw - 2.0F, ar.bottom - 3.0F), 2.0F, suWaveMode_ == 1 ? NL_BLUE : Color::rgb(23, 102, 201));
        if (k % 5 == 0) text(c, std::to_string(k + 1), x0 + bw * 0.5F, ar.bottom + 11.0F, 9.0F, NL_TXT2, Opt().center());
        const float pv = ph[k] / kPiF;   // -1..1
        const float yy = pr.centerY() - pv * (pr.height() * 0.5F - 4.0F);
        if (amp[k] > 0.004F) fill(c, RectF(x0 + 3.0F, std::min(yy, pr.centerY()), x0 + bw - 3.0F, std::max(yy, pr.centerY()) + 1.0F), 1.0F, suWaveMode_ == 1 ? NL_AMBER : Color::rgb(150, 105, 30));
    }
    text(c, "SPECTRUM (level of harmonics 1-31)", ar.left + 8.0F, ar.top + 13.0F, 10.0F, NL_TXT, Opt());
    text(c, "PHASES", pr.left + 8.0F, pr.top + 13.0F, 10.0F, NL_TXT, Opt());
    if (suWaveMode_ == 1) {
        const auto edit = [this, u, slot, ar, pr, bw](bool phase, float x, float y) {
            float cur[su::kDrawLen], a[su::kEditHarmonics], p[su::kEditHarmonics], out[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            su::waveHarmonics(cur, a, p);
            const int k = std::clamp(static_cast<int>((x - ar.left) / bw), 0, su::kEditHarmonics - 1);
            if (phase) p[k] = std::clamp((pr.centerY() - y) / (pr.height() * 0.5F - 4.0F), -1.0F, 1.0F) * kPiF;
            else a[k] = std::clamp((ar.bottom - 3.0F - y) / (ar.height() - 6.0F), 0.0F, 1.0F);
            if (!phase && a[k] > 0.0F && std::fabs(p[k]) < 1.0e-6F) p[k] = 0.0F;
            su::waveFromHarmonics(a, p, out);
            suWaveSet(u, slot, out);
        };
        hit(ar, [edit](float x, float y) { edit(false, x, y); }, nullptr, [edit](float x, float y, bool) { edit(false, x, y); });
        hit(pr, [edit](float x, float y) { edit(true, x, y); }, nullptr, [edit](float x, float y, bool) { edit(true, x, y); });
    }
    // the right side: what can be done to the wave
    const float L = sec.left + 580.0F, R = sec.right;
    text(c, "OPERATIONS (symmetry, spectrum)", L, sec.top + 12.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.15F));
    const float ow = (R - L - 6.0F) / 2.0F;
    for (int op = 0; op < su::kWaveOps; ++op) {
        const RectF r(L + static_cast<float>(op % 2) * (ow + 6.0F), sec.top + 22.0F + static_cast<float>(op / 2) * 34.0F, L + static_cast<float>(op % 2) * (ow + 6.0F) + ow, sec.top + 50.0F + static_cast<float>(op / 2) * 34.0F);
        stripToggle(c, r, su::waveOpName(op), false, C_AMBER, 11.0F);
        hit(r, [this, u, slot, op](float, float) {
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            su::waveApplyOp(op, cur);
            suWaveSet(u, slot, cur);
        });
    }
    // a slider in a strip: drag along it = the value, tap = the value at the finger, right button = the start value
    const auto slider = [this, &c](const RectF& r, const std::string& label, float v01, const std::string& shown, std::function<void(float)> set, std::function<void()> reset) {
        nlLcd(c, r, 8.0F);   // SILVETON_NEW_LOOK_V1
        fill(c, RectF(r.left + 1.0F, r.top + 1.0F, r.left + 1.0F + (r.width() - 2.0F) * std::clamp(v01, 0.0F, 1.0F), r.bottom - 1.0F), 8.0F, Color::argb(150, 51, 160, 255));
        text(c, label, r.left + 8.0F, r.centerY() + 4.0F, 10.5F, NL_TXT, Opt().bold().spacing(0.1F).maxW(r.width() * 0.6F));
        text(c, shown, r.right - 8.0F, r.centerY() + 4.0F, 11.0F, NL_VALUE, Opt().right().mono().maxW(r.width() * 0.4F));
        const auto at = [r, set](float x, float) { set(std::clamp((x - r.left) / std::max(1.0F, r.width()), 0.0F, 1.0F)); };
        hit(r, at, reset, [at](float x, float y, bool) { at(x, y); });
    };
    // two waves into this one - LIVE (Цветомир, 02.11.2026): every change of А, Б, the way or the slider is written into the wave at once
    text(c, "MIX TWO WAVES → " + std::string(su::waveName(su::kWaveDrawn0 + slot)) + " · live", L, sec.top + 170.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.15F));
    const auto applyComb = [this, u, slot]() {
        float a[su::kDrawLen], b[su::kDrawLen], out[su::kDrawLen];
        const float* pp = suP(u).data() + 1;
        su::waveChoicePoints(suCombA_, pp, a); su::waveChoicePoints(suCombB_, pp, b);
        su::waveCombine(suCombMode_, a, b, suCombT_, out);
        suWaveSet(u, slot, out);
    };
    const RectF ra(L, sec.top + 178.0F, L + ow, sec.top + 208.0F), rb(L + ow + 6.0F, sec.top + 178.0F, R, sec.top + 208.0F);
    stripToggle(c, ra, "A: " + std::string(su::waveName(suCombA_)), false, C_AMBER, 11.0F);
    stripToggle(c, rb, "B: " + std::string(su::waveName(suCombB_)), false, C_AMBER, 11.0F);
    hit(ra, [this, u, applyComb](float, float) { suPickWave(u, [this, applyComb](int k) { suCombA_ = k; applyComb(); }, "WAVE A — choose"); });
    hit(rb, [this, u, applyComb](float, float) { suPickWave(u, [this, applyComb](int k) { suCombB_ = k; applyComb(); }, "WAVE B — choose"); });
    const RectF rm(L, sec.top + 214.0F, L + 110.0F, sec.top + 244.0F);
    stripToggle(c, rm, su::combineName(suCombMode_), true, C_AMBER, 11.0F);
    hit(rm, [this, applyComb](float, float) { suCombMode_ = (suCombMode_ + 1) % su::kCombines; applyComb(); });
    slider(RectF(L + 116.0F, sec.top + 214.0F, R, sec.top + 244.0F), "FROM A TO B", suCombT_, std::to_string(rI(suCombT_ * 100.0F)) + " %",
           [this, applyComb](float v) { suCombT_ = v; applyComb(); }, [this, applyComb] { suCombT_ = 0.5F; applyComb(); });
    // SILVETON_SUSE_SAMPLE_V1 (Цветомир, 02.11.2026): the recordings of the blend through THIS wave - all of them, each on its own keys.
    // The generator with the method СЕМПЪЛ sounds them; this wave is its curve (КРИВА) and its PM wave. Only an Upper of a blend has recordings.
    text(c, "THE SAMPLES OF THE BLEND THROUGH THIS WAVE", L, sec.top + 254.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.15F));
    int sg = -1;   // the СЕМПЪЛ generator of the place (the first one)
    for (int g = 0; g < su::kGens && sg < 0; ++g) if (rI(suV(u, su::genId(g, su::GN_METHOD))) == su::M_SAMPLE) sg = g;
    const bool on = sg >= 0;
    if (u < 7) {
        const RectF ron(L, sec.top + 262.0F, L + 100.0F, sec.top + 292.0F);
        stripToggle(c, ron, on ? "ON" : "OFF", on, C_ACCENT, 12.0F);
        hit(ron, [this, u, slot, sg](float, float) {
            if (sg >= 0) { suSet(u, su::genId(sg, su::GN_METHOD), static_cast<float>(su::M_OFF)); return; }
            int g = std::clamp(suPickGen_, 0, su::kGens - 1);   // the oscillator the page is set to, or the first free one
            if (rI(suV(u, su::genId(g, su::GN_METHOD))) != su::M_OFF) { g = -1; for (int k = 0; k < su::kGens && g < 0; ++k) if (rI(suV(u, su::genId(k, su::GN_METHOD))) == su::M_OFF) g = k; }
            if (g < 0) { suStatus_ = "All six oscillators are in use - stop one (OFF) and try again."; suStatusUntilMs_ = nowMs() + 4000; invalidate(); return; }
            suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(su::M_SAMPLE));
            suSet(u, su::genId(g, su::GN_SEL1), static_cast<float>(su::kWaveDrawn0 + slot));
            suPickGen_ = g;
        });
        if (on) {
            const int idCurve = su::genId(sg, su::GN_F0), idPm = su::genId(sg, su::GN_F0 + 1), idRatio = su::genId(sg, su::GN_F0 + 3), idWave = su::genId(sg, su::GN_SEL1);
            const bool thisWave = rI(suV(u, idWave)) == su::kWaveDrawn0 + slot;
            const RectF rw(L + 106.0F, sec.top + 262.0F, R, sec.top + 292.0F);
            stripToggle(c, rw, thisWave ? "OSC " + std::to_string(sg + 1) + " · THROUGH " + su::waveName(su::kWaveDrawn0 + slot) : "OSC " + std::to_string(sg + 1) + " is through " + su::waveName(rI(suV(u, idWave))) + " → THIS ONE", thisWave, C_AMBER, 10.5F);
            hit(rw, [this, u, idWave, slot](float, float) { suSet(u, idWave, static_cast<float>(su::kWaveDrawn0 + slot)); });
            const float cur = std::clamp(suV(u, idCurve), 0.0F, 1.0F), pm = std::clamp(suV(u, idPm), 0.0F, 1.0F), rt = std::clamp(suV(u, idRatio), 0.0F, 1.0F);
            slider(RectF(L, sec.top + 298.0F, L + ow, sec.top + 328.0F), "CURVE", cur, std::to_string(rI(cur * 100.0F)) + " %",
                   [this, u, idCurve](float v) { suSet(u, idCurve, v); }, [this, u, idCurve] { suSet(u, idCurve, 0.0F); });
            slider(RectF(L + ow + 6.0F, sec.top + 298.0F, R, sec.top + 328.0F), "PM", pm, std::to_string(rI(pm * 100.0F)) + " %",
                   [this, u, idPm](float v) { suSet(u, idPm, v); }, [this, u, idPm] { suSet(u, idPm, 0.0F); });
            slider(RectF(L, sec.top + 334.0F, L + ow, sec.top + 356.0F), "PM RATIO", rt, fmtFixed(static_cast<double>(su::mapLog(rt, su::rng::kRatioLo, su::rng::kRatioHi)), 2) + " x",
                   [this, u, idRatio](float v) { suSet(u, idRatio, v); }, [this, u, idRatio] { suSet(u, idRatio, su::unmapLog(1.0F, su::rng::kRatioLo, su::rng::kRatioHi)); });
        } else {
            text(c, "OFF = the samples of the blend do not go through the engine. ON = all of them play, through this wave (CURVE, PM).", L + 108.0F, sec.top + 274.0F, 10.0F, NL_TXT2, Opt().maxW(R - L - 110.0F));
            text(c, "While CURVE and PM are 0, they sound as recorded.", L + 108.0F, sec.top + 288.0F, 10.0F, NL_TXT2, Opt().maxW(R - L - 110.0F));
        }
    } else {
        text(c, "This place is an engine without samples. Samples are in a blend: LIST → blend → COMBI → ENGINE → SILVETON SYNTH.", L, sec.top + 274.0F, 10.5F, NL_TXT2, Opt().maxW(R - L));
        text(c, "There this wave shapes all the samples of the blend.", L, sec.top + 290.0F, 10.5F, NL_TXT2, Opt().maxW(R - L));
    }
    // the files of own waves (on an Upper of a blend the sliders of the recordings take the room: the keys sit beside PM ОТНОШЕНИЕ)
    const bool tight = u < 7 && on;
    float fy0 = sec.top + 312.0F, fy1 = sec.top + 346.0F, fx0 = L, fx1 = R;
    if (tight) { fy0 = sec.top + 334.0F; fy1 = sec.top + 356.0F; fx0 = L + ow + 6.0F; }
    const float fw = (fx1 - fx0 - 6.0F) / 2.0F;
    const RectF rs(fx0, fy0, fx0 + fw, fy1), rl(fx0 + fw + 6.0F, fy0, fx1, fy1);
    stripToggle(c, rs, tight ? "SAVE" : "SAVE THE WAVE", false, C_AMBER, 11.0F);
    stripToggle(c, rl, tight ? "LOAD" : "LOAD WAVE", false, C_AMBER, 11.0F);
    hit(rs, [this, u, slot](float, float) {
        showTextPage("NAME OF THE WAVE", suWaveName_, [this, u, slot](const std::string& nm) {
            suWaveName_ = nm;
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            const auto err = sampler.suseSaveWave(nm, std::vector<float>(cur, cur + su::kDrawLen));
            suStatus_ = err ? *err : "The wave is saved: " + nm;
            suStatusUntilMs_ = nowMs() + 4000; invalidate();
        });
    });
    hit(rl, [this, u, slot](float, float) {
        const auto names = sampler.suseUserWaves();
        if (names.empty()) { showMessage("DRAW", "You have no saved waves of your own yet. Draw one and press SAVE THE WAVE."); return; }
        showItems("LOAD WAVE into " + std::string(su::waveName(su::kWaveDrawn0 + slot)), names, [this, u, slot, names](int k) {
            if (k < 0 || k >= static_cast<int>(names.size())) return;
            std::vector<float> loaded;
            const auto err = sampler.suseLoadWave(names[static_cast<std::size_t>(k)], loaded);
            if (err) { suStatus_ = *err; suStatusUntilMs_ = nowMs() + 4000; invalidate(); return; }
            suWaveSet(u, slot, loaded.data());
        });
    });
}

// ---------------------------------------------------------------- ФИЛТРИ: the two shared filters
void SilvetonSamplerView::suPageFilters(Canvas& c, const RectF& sec, int u) {
    const float pw = (sec.width() - 14.0F) / 2.0F;
    for (int f = 0; f < su::kFilters; ++f) {
        const float x0 = sec.left + static_cast<float>(f) * (pw + 14.0F);
        const int type = rI(suV(u, su::filterId(f, su::FL_TYPE)));
        text(c, f == 0 ? "FILTER A" : "FILTER B", x0 + 2.0F, sec.top + 14.0F, 13.0F, NL_VALUE, Opt().bold().spacing(0.15F));
        text(c, std::string("(gets sound from the oscillators with GOES THROUGH ") + (f == 0 ? "FILTER A" : "FILTER B") + ")", x0 + 100.0F, sec.top + 14.0F, 10.0F, NL_TXT2, Opt().maxW(pw - 100.0F));
        const float kw = (pw - 4.0F * 5.0F) / 5.0F;
        for (int t = 0; t < su::kFilterTypes; ++t) {
            const RectF r(x0 + static_cast<float>(t % 5) * (kw + 5.0F), sec.top + 24.0F + static_cast<float>(t / 5) * 34.0F, x0 + static_cast<float>(t % 5) * (kw + 5.0F) + kw, sec.top + 54.0F + static_cast<float>(t / 5) * 34.0F);
            stripToggle(c, r, su::filterTypeName(t), type == t, C_ACCENT, 11.0F);
            hit(r, [this, u, f, t](float, float) { suSet(u, su::filterId(f, su::FL_TYPE), static_cast<float>(t)); });
        }
        if (type == su::FT_OFF) {
            text(c, "The filter is off — the sound passes through it unchanged.", x0 + 6.0F, sec.top + 150.0F, 13.0F, NL_TXT2, Opt().maxW(pw - 12.0F));
            continue;
        }
        {
            const auto lines = wrapLines(su::filterTypeHelp(type), 11.0F, Face::Regular, pw - 8.0F);
            for (std::size_t i = 0; i < lines.size() && i < 2; ++i) text(c, lines[i], x0 + 4.0F, sec.top + 102.0F + static_cast<float>(i) * 14.0F, 11.0F, NL_VALUE, Opt());
        }
        const float unit = pw / 4.0F;
        const auto cx = [&](int col) { return x0 + unit * (static_cast<float>(col) + 0.5F); };
        const float y1 = sec.top + 152.0F, y2 = sec.top + 252.0F;
        suKnob(c, cx(0), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_CUT));
        suKnob(c, cx(1), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_RES));
        suKnob(c, cx(2), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_DRIVE));
        suKnob(c, cx(3), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_KEY));
        suKnob(c, cx(0), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_VEL));
        suChoice(c, RectF(cx(1) - 36.0F, y2 - 20.0F, cx(1) + 36.0F, y2 + 14.0F), u, su::filterId(f, su::FL_ENV), su::kEnvs + 1,
                 [](int k) { return k == 0 ? std::string("NONE") : "ENV " + std::to_string(k); }, "WHICH ENVELOPE");
        if (rI(suV(u, su::filterId(f, su::FL_ENV))) > 0) suKnob(c, cx(2), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_ENVAMT));
        if (type == su::FT_FORMANT) suKnob(c, cx(3), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_VOWEL));
        else if (type == su::FT_SVF) suKnob(c, cx(3), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_MORPH));
    }
    text(c, "THE TWO FILTERS:", sec.left + 4.0F, sec.bottom - 14.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.15F));
    suSwitch(c, RectF(sec.left + 132.0F, sec.bottom - 38.0F, sec.left + 332.0F, sec.bottom - 8.0F), u, su::G_FILTER_LINK, "", "SERIES (A → B)", "PARALLEL (A + B)");
}

// ---------------------------------------------------------------- ОБВИВКИ: four envelopes; the classic АТАКА - ЗАТИХВАНЕ - ДЪРЖАНЕ - ПУСКАНЕ, or the five points
void SilvetonSamplerView::suPageEnvelopes(Canvas& c, const RectF& sec, int u) {
    suEnv_ = std::clamp(suEnv_, 0, su::kEnvs - 1);
    const int e = suEnv_;
    const bool adv = suEnvAdv_;
    for (int i = 0; i < su::kEnvs; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 106.0F, sec.top, sec.left + static_cast<float>(i) * 106.0F + 100.0F, sec.top + 32.0F);
        stripToggle(c, r, "ENVELOPE " + std::to_string(i + 1), e == i, C_ACCENT, 12.0F);
        hit(r, [this, i](float, float) { suEnv_ = i; invalidate(); });
    }
    text(c, "ENVELOPE 1 drives the level of the oscillators by default.", sec.left + 436.0F, sec.top + 21.0F, 10.0F, NL_TXT2, Opt().maxW(sec.width() - 436.0F - 244.0F));
    {
        const RectF r(sec.right - 236.0F, sec.top, sec.right, sec.top + 32.0F);
        stripToggle(c, r, adv ? "SIMPLE MODE (4 KNOBS)" : "EXTENDED MODE (5 POINTS)", adv, C_AMBER, 10.5F);
        hit(r, [this](float, float) { suEnvAdv_ = !suEnvAdv_; invalidate(); });
    }
    const float* patch = suP(u).data() + 1;
    const int sus = std::clamp(rI(suV(u, su::envId(e, su::EV_SUS))), 0, su::kEnvPoints - 1);
    bool classic = sus == 1;
    for (int i = 2; i < su::kEnvPoints; ++i) classic = classic && suV(u, su::envId(e, su::envT(i))) <= 0.001F;

    // ---- the drawing: every part has a width you can see, the curve inside is the real one
    const RectF g(sec.left, sec.top + 40.0F, sec.left + 560.0F, sec.top + (adv ? 150.0F : 196.0F));
    nlLcd(c, g, 8.0F);   // SILVETON_NEW_LOOK_V1
    float shape[200];
    su::EnvPart parts[su::kEnvPartsMax];
    const int np = su::envelopeSchematic(patch, e, 200, shape, parts);
    const float gx0 = g.left + 12.0F, gx1 = g.right - 12.0F, gy0 = g.bottom - 24.0F, gy1 = g.top + 14.0F;
    const auto X = [&](float x) { return gx0 + (gx1 - gx0) * x; };
    const auto Y = [&](float v) { return gy0 - (gy0 - gy1) * std::clamp(v, 0.0F, 1.0F); };
    for (int i = 0; i < np; i += 2) fill(c, RectF(X(parts[i].x0), g.top + 4.0F, X(parts[i].x1), g.bottom - 4.0F), 0.0F, Color::argb(16, 255, 255, 255));
    line(c, gx0, gy0, gx1, gy0, Color::argb(70, 255, 255, 255), 1.0F);
    for (int j = 0; j + 1 < 200; ++j) line(c, X(static_cast<float>(j) / 199.0F), Y(shape[j]), X(static_cast<float>(j + 1) / 199.0F), Y(shape[j + 1]), NL_BLUE, 2.2F);
    int decays = 0;
    for (int i = 0; i < np; ++i) if (parts[i].kind == 1) ++decays;
    for (int i = 0; i < np; ++i) {
        const su::EnvPart& pt = parts[i];
        const float cx = X((pt.x0 + pt.x1) * 0.5F);
        std::string name = pt.kind == 0 ? "ATTACK" : (pt.kind == 1 ? "DECAY" : (pt.kind == 2 ? "HOLD" : (pt.kind == 3 ? "REL. t." : "RELEASE")));
        if (adv && pt.kind == 1 && decays > 1) name += " " + std::to_string(pt.point + 1);
        if (adv && pt.kind == 3) name += std::to_string(pt.point + 1);
        text(c, name, cx, g.bottom - 8.0F, 9.5F, pt.kind == 2 ? NL_AMBER : NL_TXT, Opt().center().bold().maxW(X(pt.x1) - X(pt.x0) - 2.0F));
        if (pt.kind == 2) {
            const int j = std::clamp(static_cast<int>((pt.x0 + pt.x1) * 0.5F * 199.0F), 0, 199);
            text(c, std::to_string(rI(shape[j] * 100.0F)) + " %", cx, Y(shape[j]) - 7.0F, 10.0F, NL_AMBER, Opt().center().bold());
        } else {
            const int j = std::clamp(static_cast<int>(pt.x1 * 199.0F), 0, 199);
            fill(c, RectF(X(pt.x1) - 4.0F, Y(shape[j]) - 4.0F, X(pt.x1) + 4.0F, Y(shape[j]) + 4.0F), 4.0F, Color::rgb(226, 229, 234));
            if (adv && pt.kind != 4) text(c, std::to_string(pt.point + 1), X(pt.x1), Y(shape[j]) - 9.0F, 9.0F, NL_VALUE, Opt().center());
        }
    }
    if (!adv && !classic) text(c, "This envelope has more points — see EXTENDED MODE.", g.left + 10.0F, g.top + 16.0F, 10.5F, NL_AMBER, Opt().bold().maxW(g.width() - 20.0F));

    if (!adv) {
        // ---- the four classic knobs
        static const char* const nm[4] = {"ATTACK", "DECAY", "HOLD", "RELEASE"};
        static const char* const ds[4] = {"how fast it reaches the loudest", "how slowly it falls to the HOLD level", "the level it stays at while you hold the key", "how slowly it dies away after you release the key"};
        const int ids[4] = {su::envId(e, su::envT(0)), su::envId(e, su::envT(1)), su::envId(e, su::envL(1)), su::envId(e, su::EV_REL)};
        for (int i = 0; i < 4; ++i) {
            const float cx = sec.left + 70.0F + static_cast<float>(i) * 140.0F;
            suKnob(c, cx, sec.top + 240.0F, 20.0F, 132.0F, u, ids[i], nm[i]);
            const auto lines = wrapLines(ds[i], 10.0F, Face::Regular, 128.0F);
            for (std::size_t k = 0; k < lines.size() && k < 2; ++k) text(c, lines[k], cx, sec.top + 322.0F + static_cast<float>(k) * 13.0F, 10.0F, NL_TXT2, Opt().center());
        }
        // ---- the rest
        const float L = sec.left + 586.0F, R = sec.right;
        const float u3 = (R - L) / 3.0F;
        text(c, "EXTRA", L + 4.0F, sec.top + 54.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.2F));
        suKnob(c, L + u3 * 0.5F, sec.top + 100.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::EV_START));
        suKnob(c, L + u3 * 1.5F, sec.top + 100.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::envL(0)), "PEAK LEVEL");
        suKnob(c, L + u3 * 2.5F, sec.top + 100.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::EV_CURVE));
        suKnob(c, L + u3 * 0.5F, sec.top + 190.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::EV_KEYT));
        suSwitch(c, RectF(L + u3 * 1.5F - 36.0F, sec.top + 172.0F, L + u3 * 1.5F + 36.0F, sec.top + 206.0F), u, su::envId(e, su::EV_LOOP), "REPEAT", "YES", "NO");
        static const char* const hint[3] = {
            "CURVE: + = fast at the start and slow at the end; − = the opposite.",
            "NOTE→TIME: + makes the times shorter on high notes.",
            "REPEAT (YES): while you hold the key, the envelope returns and repeats."};
        float y = sec.top + 268.0F;
        for (const char* h : hint) {
            const auto lines = wrapLines(h, 10.0F, Face::Regular, R - L);
            for (const auto& ln : lines) { text(c, ln, L + 2.0F, y, 10.0F, NL_TXT2, Opt()); y += 13.0F; }
            y += 3.0F;
        }
        return;
    }

    // ---- the five points (the whole power: more stages, a sustain point anywhere)
    const float unit = 112.0F;
    for (int p = 0; p < su::kEnvPoints; ++p) {
        const float cx = sec.left + unit * (static_cast<float>(p) + 0.5F);
        const char* role = p == 0 && sus == 0 ? "ATTACK · HOLD" : (p == 0 ? "ATTACK" : (p < sus ? "DECAY" : (p == sus ? "DECAY · HOLD" : "AFTER HOLD")));
        const char* timeName = p == 0 ? "ATTACK" : (p <= sus ? "DECAY" : "TIME");
        const char* levelName = (p == sus) ? "HOLD LEVEL" : (p == 0 ? "PEAK LEVEL" : "LEVEL");
        text(c, role, cx, sec.top + 166.0F, 10.0F, p == sus ? NL_AMBER : NL_VALUE, Opt().center().bold().maxW(unit - 4.0F));
        text(c, "point " + std::to_string(p + 1), cx, sec.top + 179.0F, 9.0F, NL_TXT2, Opt().center());
        suKnob(c, cx, sec.top + 214.0F, 15.0F, unit - 6.0F, u, su::envId(e, su::envT(p)), timeName);
        suKnob(c, cx, sec.top + 306.0F, 15.0F, unit - 6.0F, u, su::envId(e, su::envL(p)), levelName);
    }
    const float L = sec.left + 586.0F, R = sec.right;
    const float u2 = (R - L) / 3.0F;
    text(c, "RELEASE", L + 4.0F, sec.top + 52.0F, 11.0F, NL_AMBER, Opt().bold().spacing(0.15F));
    text(c, "how slowly the sound dies away after you release the key", L + 74.0F, sec.top + 52.0F, 9.0F, NL_TXT2, Opt().maxW(R - L - 78.0F));
    suKnob(c, L + u2 * 0.5F, sec.top + 90.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_START));
    suKnob(c, L + u2 * 1.5F, sec.top + 90.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_REL));
    suKnob(c, L + u2 * 2.5F, sec.top + 90.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_CURVE));
    suChoice(c, RectF(L + u2 * 0.5F - 40.0F, sec.top + 168.0F, L + u2 * 0.5F + 40.0F, sec.top + 202.0F), u, su::envId(e, su::EV_SUS), su::kEnvPoints, [](int k) { return "POINT " + std::to_string(k + 1); }, "HOLD AT", 0);
    suKnob(c, L + u2 * 1.5F, sec.top + 186.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_KEYT));
    suSwitch(c, RectF(L + u2 * 2.5F - 36.0F, sec.top + 168.0F, L + u2 * 2.5F + 36.0F, sec.top + 202.0F), u, su::envId(e, su::EV_LOOP), "REPEAT", "YES", "NO");
    text(c, "The ordinary envelope is: point 1 = ATTACK, point 2 = DECAY and HOLD.", L, sec.top + 262.0F, 10.0F, NL_TXT2, Opt().maxW(R - L));
    text(c, "The points after HOLD with a time work after the key is released,", L, sec.top + 277.0F, 10.0F, NL_TXT2, Opt().maxW(R - L));
    text(c, "before the last RELEASE.", L, sec.top + 292.0F, 10.0F, NL_TXT2, Opt().maxW(R - L));
}

// ---------------------------------------------------------------- МОДУЛ.: LFOs, the step modulator and the free matrix
void SilvetonSamplerView::suPageMod(Canvas& c, const RectF& sec, int u) {
    static const char* const tabs[3] = {"LFO", "STEPS", "MATRIX"};
    for (int i = 0; i < 3; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 116.0F, sec.top, sec.left + static_cast<float>(i) * 116.0F + 110.0F, sec.top + 32.0F);
        stripToggle(c, r, tabs[i], suModTab_ == i, C_AMBER, 12.0F);
        hit(r, [this, i](float, float) { suModTab_ = i; invalidate(); });
    }
    const float* patch = suP(u).data() + 1;
    if (suModTab_ == 0) {
        suLfo_ = std::clamp(suLfo_, 0, su::kLfos - 1);
        const int l = suLfo_;
        for (int i = 0; i < su::kLfos; ++i) {
            const RectF r(sec.left + 380.0F + static_cast<float>(i) * 86.0F, sec.top, sec.left + 380.0F + static_cast<float>(i) * 86.0F + 80.0F, sec.top + 32.0F);
            stripToggle(c, r, "LFO " + std::to_string(i + 1), l == i, C_ACCENT, 12.0F);
            hit(r, [this, i](float, float) { suLfo_ = i; invalidate(); });
        }
        const float unit = sec.width() / 4.0F;
        const auto cx = [&](int col) { return sec.left + unit * (static_cast<float>(col) + 0.5F); };
        suChoice(c, RectF(cx(0) - 60.0F, sec.top + 90.0F, cx(0) + 60.0F, sec.top + 124.0F), u, su::lfoId(l, su::LF_WAVE), su::kLfoWaves, [](int k) { return std::string(su::lfoWaveName(k)); }, "SHAPE");
        suKnob(c, cx(1), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_RATE));
        suKnob(c, cx(2), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_DELAY));
        suKnob(c, cx(3), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_FADE));
        suKnob(c, cx(0), sec.top + 214.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_PHASE));
        suKnob(c, cx(1), sec.top + 214.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_KEYF));
        suSwitch(c, RectF(cx(2) - 50.0F, sec.top + 196.0F, cx(2) + 50.0F, sec.top + 230.0F), u, su::lfoId(l, su::LF_UNI), "UNIPOLAR (0..+)", "YES", "NO");
        suSwitch(c, RectF(cx(3) - 50.0F, sec.top + 196.0F, cx(3) + 50.0F, sec.top + 230.0F), u, su::lfoId(l, su::LF_FREE), "RANDOM START", "YES", "NO");
        text(c, "An LFO is a slow wave that moves a knob. Where the LFO goes " + std::to_string(l + 1) + " — in the MATRIX (source LFO " + std::to_string(l + 1) + ").", sec.left + 6.0F, sec.bottom - 14.0F, 12.0F, NL_TXT2, Opt().maxW(sec.width()));
        return;
    }
    if (suModTab_ == 1) {
        const int len = rI(suV(u, su::stepId(su::ST_LEN)));
        const RectF bars(sec.left, sec.top + 44.0F, sec.left + 600.0F, sec.top + 230.0F);
        nlLcd(c, bars, 8.0F);   // SILVETON_NEW_LOOK_V1
        line(c, bars.left, bars.centerY(), bars.right, bars.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
        const float bw = bars.width() / static_cast<float>(su::kStepCount);
        for (int i = 0; i < su::kStepCount; ++i) {
            const float v = (suV(u, su::stepId(su::ST_STEPS + i)) - 0.5F) * 2.0F;
            const float x0 = bars.left + static_cast<float>(i) * bw;
            const bool used = i < len;
            const float y = bars.centerY() - v * (bars.height() * 0.5F - 6.0F);
            fill(c, RectF(x0 + 4.0F, std::min(y, bars.centerY()), x0 + bw - 4.0F, std::max(y, bars.centerY()) + 1.0F), 3.0F, used ? NL_BLUE : Color::rgb(70, 74, 82));
            text(c, std::to_string(i + 1), x0 + bw * 0.5F, bars.bottom + 13.0F, 10.0F, used ? NL_TXT : NL_TXT2, Opt().center());
        }
        const auto setBar = [this, u, bars, bw](float x, float y) {
            const int i = std::clamp(static_cast<int>((x - bars.left) / bw), 0, su::kStepCount - 1);
            const float v = std::clamp((bars.centerY() - y) / (bars.height() * 0.5F - 6.0F), -1.0F, 1.0F);
            suSet(u, su::stepId(su::ST_STEPS + i), 0.5F + 0.5F * v);
        };
        hit(bars, setBar, nullptr, [setBar](float x, float y, bool) { setBar(x, y); });
        const float L = sec.left + 626.0F, unit = (sec.right - L) / 2.0F;
        suKnob(c, L + unit * 0.5F, sec.top + 70.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_LEN));
        suKnob(c, L + unit * 1.5F, sec.top + 70.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_RATE));
        suKnob(c, L + unit * 0.5F, sec.top + 170.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_GLIDE));
        static const char* const dirs[4] = {"FORWARD", "BACK", "FORWARD-BACKWARD", "RANDOM"};
        suChoice(c, RectF(L + unit * 1.5F - 50.0F, sec.top + 152.0F, L + unit * 1.5F + 50.0F, sec.top + 186.0F), u, su::stepId(su::ST_DIR), 4, [](int k) { return std::string(dirs[k]); }, "DIRECTION");
        text(c, "Touch or drag over the bars. The values go to the MATRIX (source STEPS).", sec.left + 6.0F, sec.bottom - 10.0F, 12.0F, NL_TXT2, Opt().maxW(sec.width()));
        return;
    }
    // the matrix: 16 lines, source -> target, amount
    for (int m = 0; m < su::kMods; ++m) {
        const int col = m / 8, row = m % 8;
        const float x0 = sec.left + static_cast<float>(col) * 456.0F;
        const float y0 = sec.top + 42.0F + static_cast<float>(row) * 39.0F;
        const int src = rI(suV(u, su::modId(m, 0))), dst = rI(suV(u, su::modId(m, 1)));
        const float amt = (suV(u, su::modId(m, 2)) - 0.5F) * 2.0F;
        text(c, std::to_string(m + 1), x0 + 2.0F, y0 + 22.0F, 11.0F, NL_TXT2, Opt());
        const RectF rs(x0 + 20.0F, y0, x0 + 132.0F, y0 + 32.0F), rd(x0 + 138.0F, y0, x0 + 318.0F, y0 + 32.0F), ra(x0 + 324.0F, y0, x0 + 440.0F, y0 + 32.0F);
        stripToggle(c, rs, su::modSourceName(src), src != 0, C_AMBER, 10.0F);
        stripToggle(c, rd, src == 0 ? std::string("—") : su::destName(dst, patch), src != 0, C_AMBER, 10.0F);
        hit(rs, [this, u, m](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            for (int k = 0; k < su::kModSources; ++k) items.emplace_back(fmtZeroPad(k, 2), su::modSourceName(k));
            showGridPicker("WHERE IT COMES FROM (line " + std::to_string(m + 1) + ")", items, rI(suV(u, su::modId(m, 0))), std::nullopt, [this, u, m](int k) { if (k >= 0) suSet(u, su::modId(m, 0), static_cast<float>(k)); });
        }, [this, u, m] { suSet(u, su::modId(m, 0), 0.0F); });
        hit(rd, [this, u, m](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            std::vector<int> ids;
            const float* pp = suP(u).data() + 1;
            int cur = 0;
            for (int k = 0; k < su::kDestCount; ++k) {
                if (!su::destUsable(k, pp)) continue;
                if (k == rI(suV(u, su::modId(m, 1)))) cur = static_cast<int>(ids.size());
                items.emplace_back(fmtZeroPad(static_cast<int>(ids.size()), 2), su::destName(k, pp));
                ids.push_back(k);
            }
            showGridPicker("WHERE IT GOES (line " + std::to_string(m + 1) + ")", items, cur, std::nullopt, [this, u, m, ids](int k) { if (k >= 0 && k < static_cast<int>(ids.size())) suSet(u, su::modId(m, 1), static_cast<float>(ids[static_cast<std::size_t>(k)])); });
        });
        // the amount: a bar from -100 % to +100 %
        nlLcd(c, ra, 6.0F);   // SILVETON_NEW_LOOK_V1
        line(c, ra.centerX(), ra.top + 4.0F, ra.centerX(), ra.bottom - 4.0F, Color::argb(80, 255, 255, 255), 1.0F);
        const float half = ra.width() * 0.5F - 4.0F;
        if (amt != 0.0F) fill(c, RectF(std::min(ra.centerX(), ra.centerX() + amt * half), ra.top + 8.0F, std::max(ra.centerX(), ra.centerX() + amt * half), ra.bottom - 8.0F), 3.0F, src != 0 ? NL_BLUE : Color::rgb(90, 94, 102));
        text(c, std::to_string(rI(amt * 100.0F)) + "%", ra.centerX(), ra.centerY() + 4.0F, 11.0F, NL_VALUE, Opt().center().bold());
        const auto setAmt = [this, u, m, ra](float x, float) { suSet(u, su::modId(m, 2), 0.5F + 0.5F * std::clamp((x - ra.centerX()) / (ra.width() * 0.5F - 4.0F), -1.0F, 1.0F)); };
        hit(ra, setAmt, [this, u, m] { suSet(u, su::modId(m, 2), 0.5F); }, [setAmt](float x, float y, bool) { setAmt(x, y); });
    }
    text(c, "Every line: WHERE FROM → WHERE TO and how much (-100..+100 %). Double tap on the amount = 0.", sec.left + 6.0F, sec.bottom - 8.0F, 11.0F, NL_TXT2, Opt().maxW(sec.width()));
}

} // namespace silveton::ui::classic
