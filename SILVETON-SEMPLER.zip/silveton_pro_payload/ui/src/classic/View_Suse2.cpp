// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH (part 2: ВЪЛНИ = the wave editor, ФИЛТРИ, ОБВИВКИ, МОДУЛ.).
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
constexpr float kPiF = 3.14159265358979F;
}  // namespace

// a drawn wave (64 points -1..1) into slot 0..3 of the patch (kept as 0.5 + 0.5 * v)
void SilvetonSamplerView::suWaveSet(int u, int slot, const float* pts) {
    std::vector<float> v(static_cast<std::size_t>(su::kDrawLen));
    for (int i = 0; i < su::kDrawLen; ++i) v[static_cast<std::size_t>(i)] = 0.5F + 0.5F * std::clamp(pts[i], -1.0F, 1.0F);
    suBlock(u, su::drawId(slot, 0), v);
}

// ---------------------------------------------------------------- ВЪЛНИ: the wave editor
void SilvetonSamplerView::suPageWaves(Canvas& c, const RectF& sec, int u) {
    suWaveSlot_ = std::clamp(suWaveSlot_, 0, su::kDrawnWaves - 1);
    const int slot = suWaveSlot_;
    const float* patch = suP(u).data() + 1;
    float pts[su::kDrawLen];
    su::waveChoicePoints(su::kWaveDrawn0 + slot, patch, pts);
    // row 1: the four drawn waves and the way of working
    for (int i = 0; i < su::kDrawnWaves; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 86.0F, sec.top, sec.left + static_cast<float>(i) * 86.0F + 80.0F, sec.top + 34.0F);
        stripToggle(c, r, su::waveName(su::kWaveDrawn0 + i), slot == i, C_ACCENT, 12.0F);
        hit(r, [this, i](float, float) { suWaveSlot_ = i; invalidate(); });
    }
    static const char* const modes[2] = {"РИСУВАЙ", "ХАРМОНИЦИ"};
    for (int i = 0; i < 2; ++i) {
        const RectF r(sec.left + 356.0F + static_cast<float>(i) * 100.0F, sec.top, sec.left + 356.0F + static_cast<float>(i) * 100.0F + (i == 0 ? 94.0F : 104.0F), sec.top + 34.0F);
        stripToggle(c, r, modes[i], suWaveMode_ == i, C_AMBER, 11.0F);
        hit(r, [this, i](float, float) { suWaveMode_ = i; invalidate(); });
    }
    // the wave
    const RectF cv(sec.left, sec.top + 44.0F, sec.left + 560.0F, sec.top + 196.0F);
    fill(c, cv, 8.0F, Color::rgb(24, 27, 32));
    line(c, cv.left, cv.centerY(), cv.right, cv.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
    for (int q = 1; q < 4; ++q) line(c, cv.left + cv.width() * static_cast<float>(q) / 4.0F, cv.top + 4.0F, cv.left + cv.width() * static_cast<float>(q) / 4.0F, cv.bottom - 4.0F, Color::argb(28, 255, 255, 255), 1.0F);
    const float px = cv.width() / static_cast<float>(su::kDrawLen);
    for (int i = 0; i < su::kDrawLen; ++i) {
        const float x = cv.left + (static_cast<float>(i) + 0.5F) * px;
        const float y = cv.centerY() - pts[i] * (cv.height() * 0.5F - 6.0F);
        line(c, x, cv.centerY(), x, y, Color::argb(90, 80, 220, 120), px * 0.7F);
        if (i + 1 < su::kDrawLen) {
            const float x2 = x + px, y2 = cv.centerY() - pts[i + 1] * (cv.height() * 0.5F - 6.0F);
            line(c, x, y, x2, y2, C_ACCENT, 2.0F);
        }
    }
    text(c, std::string(su::waveName(su::kWaveDrawn0 + slot)) + " · една вълна = 64 точки", cv.left + 10.0F, cv.top + 16.0F, 11.0F, C_KNOB_LABEL, Opt());
    if (suWaveMode_ == 0) {
        const auto drawPoint = [this, u, slot, cv](float x, float y, bool final) {
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            const int i1 = std::clamp(static_cast<int>((x - cv.left) / cv.width() * static_cast<float>(su::kDrawLen)), 0, su::kDrawLen - 1);
            const float v1 = std::clamp(1.0F - 2.0F * (y - cv.top - 6.0F) / (cv.height() - 12.0F), -1.0F, 1.0F);
            int i0 = suDrawLastI_ < 0 ? i1 : suDrawLastI_;
            float v0 = suDrawLastI_ < 0 ? v1 : suDrawLastV_;
            const int step = i1 >= i0 ? 1 : -1;
            for (int i = i0;; i += step) {
                const float t = i1 == i0 ? 1.0F : static_cast<float>(i - i0) / static_cast<float>(i1 - i0);
                cur[i] = v0 + (v1 - v0) * t;
                if (i == i1) break;
            }
            suDrawLastI_ = final ? -1 : i1; suDrawLastV_ = v1;
            suWaveSet(u, slot, cur);
        };
        hit(cv, [drawPoint](float x, float y) { drawPoint(x, y, true); }, nullptr, drawPoint);
    }
    // the spectrum (amplitude of harmonic 1..31) and the phases
    float amp[su::kEditHarmonics], ph[su::kEditHarmonics];
    su::waveHarmonics(pts, amp, ph);
    const RectF ar(sec.left, sec.top + 206.0F, sec.left + 560.0F, sec.top + 280.0F);
    const RectF pr(sec.left, sec.top + 288.0F, sec.left + 560.0F, sec.top + 350.0F);
    fill(c, ar, 6.0F, Color::rgb(30, 33, 39));
    fill(c, pr, 6.0F, Color::rgb(30, 33, 39));
    line(c, pr.left, pr.centerY(), pr.right, pr.centerY(), Color::argb(60, 255, 255, 255), 1.0F);
    const float bw = ar.width() / static_cast<float>(su::kEditHarmonics);
    for (int k = 0; k < su::kEditHarmonics; ++k) {
        const float x0 = ar.left + static_cast<float>(k) * bw;
        const float h = std::clamp(amp[k], 0.0F, 1.0F) * (ar.height() - 6.0F);
        if (h > 0.5F) fill(c, RectF(x0 + 2.0F, ar.bottom - 3.0F - h, x0 + bw - 2.0F, ar.bottom - 3.0F), 2.0F, suWaveMode_ == 1 ? C_ACCENT : Color::rgb(110, 150, 120));
        if (k % 5 == 0) text(c, std::to_string(k + 1), x0 + bw * 0.5F, ar.bottom + 11.0F, 9.0F, C_HINT, Opt().center());
        const float pv = ph[k] / kPiF;   // -1..1
        const float yy = pr.centerY() - pv * (pr.height() * 0.5F - 4.0F);
        if (amp[k] > 0.004F) fill(c, RectF(x0 + 3.0F, std::min(yy, pr.centerY()), x0 + bw - 3.0F, std::max(yy, pr.centerY()) + 1.0F), 1.0F, suWaveMode_ == 1 ? C_AMBER : Color::rgb(130, 120, 90));
    }
    text(c, "СПЕКТЪР (сила на хармониците 1-31)", ar.left + 8.0F, ar.top + 13.0F, 10.0F, C_KNOB_LABEL, Opt());
    text(c, "ФАЗИ", pr.left + 8.0F, pr.top + 13.0F, 10.0F, C_KNOB_LABEL, Opt());
    if (suWaveMode_ == 1) {
        const auto edit = [this, u, slot, ar, pr, bw](bool phase, float x, float y) {
            float cur[su::kDrawLen], a[su::kEditHarmonics], p[su::kEditHarmonics], out[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            su::waveHarmonics(cur, a, p);
            const int k = std::clamp(static_cast<int>((x - ar.left) / bw), 0, su::kEditHarmonics - 1);
            if (phase) p[k] = std::clamp((pr.centerY() - y) / (pr.height() * 0.5F - 4.0F), -1.0F, 1.0F) * kPiF;
            else a[k] = std::clamp((ar.bottom - 3.0F - y) / (ar.height() - 6.0F), 0.0F, 1.0F);
            if (!phase && a[k] > 0.0F && std::fabs(p[k]) < 1.0e-6F) p[k] = 0.0F;
            su::waveFromHarmonics(a, p, out);
            suWaveSet(u, slot, out);
        };
        hit(ar, [edit](float x, float y) { edit(false, x, y); }, nullptr, [edit](float x, float y, bool) { edit(false, x, y); });
        hit(pr, [edit](float x, float y) { edit(true, x, y); }, nullptr, [edit](float x, float y, bool) { edit(true, x, y); });
    }
    // the right side: what can be done to the wave
    const float L = sec.left + 580.0F, R = sec.right;
    text(c, "ОПЕРАЦИИ (симетрия, спектър)", L, sec.top + 12.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    const float ow = (R - L - 6.0F) / 2.0F;
    for (int op = 0; op < su::kWaveOps; ++op) {
        const RectF r(L + static_cast<float>(op % 2) * (ow + 6.0F), sec.top + 22.0F + static_cast<float>(op / 2) * 34.0F, L + static_cast<float>(op % 2) * (ow + 6.0F) + ow, sec.top + 50.0F + static_cast<float>(op / 2) * 34.0F);
        stripToggle(c, r, su::waveOpName(op), false, C_AMBER, 11.0F);
        hit(r, [this, u, slot, op](float, float) {
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            su::waveApplyOp(op, cur);
            suWaveSet(u, slot, cur);
        });
    }
    // two waves into this one
    text(c, "СМЕСИ ДВЕ ВЪЛНИ → " + std::string(su::waveName(su::kWaveDrawn0 + slot)), L, sec.top + 176.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    const RectF ra(L, sec.top + 186.0F, L + ow, sec.top + 216.0F), rb(L + ow + 6.0F, sec.top + 186.0F, R, sec.top + 216.0F);
    stripToggle(c, ra, "A: " + std::string(su::waveName(suCombA_)), false, C_AMBER, 11.0F);
    stripToggle(c, rb, "B: " + std::string(su::waveName(suCombB_)), false, C_AMBER, 11.0F);
    hit(ra, [this, u](float, float) { suPickWave(u, [this](int k) { suCombA_ = k; invalidate(); }, "ВЪЛНА A — избери"); });
    hit(rb, [this, u](float, float) { suPickWave(u, [this](int k) { suCombB_ = k; invalidate(); }, "ВЪЛНА B — избери"); });
    const RectF rm(L, sec.top + 226.0F, L + 110.0F, sec.top + 258.0F);
    stripToggle(c, rm, su::combineName(suCombMode_), true, C_AMBER, 11.0F);
    hit(rm, [this](float, float) { suCombMode_ = (suCombMode_ + 1) % su::kCombines; invalidate(); });
    knobControl(c, L + 168.0F, sec.top + 242.0F, 14.0F, suCombT_, 0.0F, 1.0F, 0.01F, 200.0F, false, std::to_string(rI(suCombT_ * 100.0F)) + "%", "ОТ A КЪМ B", 90.0F,
                [this](float nv) { suCombT_ = nv; invalidate(); },
                [this] { showNumber("ОТ A КЪМ B %", suCombT_ * 100.0F, 0.0F, 100.0F, 0, [this](float x) { suCombT_ = x / 100.0F; invalidate(); }); },
                [this] { suCombT_ = 0.5F; invalidate(); });
    const RectF rapply(L + 232.0F, sec.top + 226.0F, R, sec.top + 258.0F);
    stripToggle(c, rapply, "ПРИЛОЖИ", false, C_ACCENT, 12.0F);
    hit(rapply, [this, u, slot](float, float) {
        float a[su::kDrawLen], b[su::kDrawLen], out[su::kDrawLen];
        const float* pp = suP(u).data() + 1;
        su::waveChoicePoints(suCombA_, pp, a); su::waveChoicePoints(suCombB_, pp, b);
        su::waveCombine(suCombMode_, a, b, suCombT_, out);
        suWaveSet(u, slot, out);
    });
    // the files of own waves
    const RectF rs(L, sec.top + 312.0F, L + ow, sec.top + 346.0F), rl(L + ow + 6.0F, sec.top + 312.0F, R, sec.top + 346.0F);
    stripToggle(c, rs, "ЗАПАЗИ ВЪЛНАТА", false, C_AMBER, 11.0F);
    stripToggle(c, rl, "ЗАРЕДИ ВЪЛНА", false, C_AMBER, 11.0F);
    hit(rs, [this, u, slot](float, float) {
        showTextPage("ИМЕ НА ВЪЛНАТА", suWaveName_, [this, u, slot](const std::string& nm) {
            suWaveName_ = nm;
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            const auto err = sampler.suseSaveWave(nm, std::vector<float>(cur, cur + su::kDrawLen));
            suStatus_ = err ? *err : "Вълната е записана: " + nm;
            suStatusUntilMs_ = nowMs() + 4000; invalidate();
        });
    });
    hit(rl, [this, u, slot](float, float) {
        const auto names = sampler.suseUserWaves();
        if (names.empty()) { showMessage("ВЪЛНИ", "Още няма записани твои вълни. Нарисувай една и натисни ЗАПАЗИ ВЪЛНАТА."); return; }
        showItems("ЗАРЕДИ ВЪЛНА в " + std::string(su::waveName(su::kWaveDrawn0 + slot)), names, [this, u, slot, names](int k) {
            if (k < 0 || k >= static_cast<int>(names.size())) return;
            std::vector<float> loaded;
            const auto err = sampler.suseLoadWave(names[static_cast<std::size_t>(k)], loaded);
            if (err) { suStatus_ = *err; suStatusUntilMs_ = nowMs() + 4000; invalidate(); return; }
            suWaveSet(u, slot, loaded.data());
        });
    });
}

// ---------------------------------------------------------------- ФИЛТРИ: the two shared filters
void SilvetonSamplerView::suPageFilters(Canvas& c, const RectF& sec, int u) {
    const float pw = (sec.width() - 14.0F) / 2.0F;
    for (int f = 0; f < su::kFilters; ++f) {
        const float x0 = sec.left + static_cast<float>(f) * (pw + 14.0F);
        const int type = rI(suV(u, su::filterId(f, su::FL_TYPE)));
        text(c, f == 0 ? "ФИЛТЪР A" : "ФИЛТЪР B", x0 + 2.0F, sec.top + 14.0F, 13.0F, C_VALUE, Opt().bold().spacing(0.15F));
        text(c, "(идва от генераторите с КЪМ " + std::string(f == 0 ? "FILTER A" : "FILTER B") + ")", x0 + 100.0F, sec.top + 14.0F, 10.0F, C_HINT, Opt().maxW(pw - 100.0F));
        const float kw = (pw - 4.0F * 5.0F) / 5.0F;
        for (int t = 0; t < su::kFilterTypes; ++t) {
            const RectF r(x0 + static_cast<float>(t % 5) * (kw + 5.0F), sec.top + 24.0F + static_cast<float>(t / 5) * 34.0F, x0 + static_cast<float>(t % 5) * (kw + 5.0F) + kw, sec.top + 54.0F + static_cast<float>(t / 5) * 34.0F);
            stripToggle(c, r, su::filterTypeName(t), type == t, C_ACCENT, 11.0F);
            hit(r, [this, u, f, t](float, float) { suSet(u, su::filterId(f, su::FL_TYPE), static_cast<float>(t)); });
        }
        if (type == su::FT_OFF) {
            text(c, "Филтърът е изключен — звукът минава през него непроменен.", x0 + 6.0F, sec.top + 150.0F, 13.0F, C_HINT, Opt().maxW(pw - 12.0F));
            continue;
        }
        const float unit = pw / 4.0F;
        const auto cx = [&](int col) { return x0 + unit * (static_cast<float>(col) + 0.5F); };
        const float y1 = sec.top + 124.0F, y2 = sec.top + 228.0F;
        suKnob(c, cx(0), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_CUT));
        suKnob(c, cx(1), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_RES));
        suKnob(c, cx(2), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_DRIVE));
        suKnob(c, cx(3), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_KEY));
        suKnob(c, cx(0), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_VEL));
        suChoice(c, RectF(cx(1) - 36.0F, y2 - 20.0F, cx(1) + 36.0F, y2 + 14.0F), u, su::filterId(f, su::FL_ENV), su::kEnvs + 1,
                 [](int k) { return k == 0 ? std::string("НЯМА") : "ENV " + std::to_string(k); }, "СРЕЗ ← ОБВИВКА");
        if (rI(suV(u, su::filterId(f, su::FL_ENV))) > 0) suKnob(c, cx(2), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_ENVAMT));
        if (type == su::FT_FORMANT) suKnob(c, cx(3), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_VOWEL));
        else if (type == su::FT_SVF) suKnob(c, cx(3), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_MORPH));
    }
    text(c, "ДВА ФИЛТЪРА:", sec.left + 4.0F, sec.bottom - 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    suSwitch(c, RectF(sec.left + 110.0F, sec.bottom - 38.0F, sec.left + 300.0F, sec.bottom - 8.0F), u, su::G_FILTER_LINK, "", "ПОРЕДНО (A → B)", "УСПОРЕДНО (A + B)");
}

// ---------------------------------------------------------------- ОБВИВКИ: four envelopes with five points
void SilvetonSamplerView::suPageEnvelopes(Canvas& c, const RectF& sec, int u) {
    suEnv_ = std::clamp(suEnv_, 0, su::kEnvs - 1);
    const int e = suEnv_;
    for (int i = 0; i < su::kEnvs; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 106.0F, sec.top, sec.left + static_cast<float>(i) * 106.0F + 100.0F, sec.top + 32.0F);
        stripToggle(c, r, "ENV " + std::to_string(i + 1), e == i, C_ACCENT, 12.0F);
        hit(r, [this, i](float, float) { suEnv_ = i; invalidate(); });
    }
    text(c, "ENV 1 води силата по подразбиране; ENV 2–4 — както ги вържеш (ОСЦИЛ., ФИЛТРИ, МОДУЛ.).", sec.left + 440.0F, sec.top + 20.0F, 10.0F, C_HINT, Opt().maxW(sec.width() - 440.0F));
    // the drawing: the real run of the envelope
    const RectF g(sec.left, sec.top + 40.0F, sec.left + 560.0F, sec.top + 150.0F);
    fill(c, g, 8.0F, Color::rgb(24, 27, 32));
    float shape[140], total = 0.0F, relAt = 0.0F;
    su::envelopePreview(suP(u).data() + 1, e, 140, shape, &total, &relAt);
    const auto X = [&](float t) { return g.left + 10.0F + (g.width() - 20.0F) * t / std::max(total, 0.05F); };
    const auto Y = [&](float v) { return g.bottom - 10.0F - (g.height() - 24.0F) * std::clamp(v, 0.0F, 1.0F); };
    line(c, X(relAt), g.top + 6.0F, X(relAt), g.bottom - 6.0F, Color::argb(80, 255, 140, 60), 1.0F);
    text(c, "пускане на клавиша", X(relAt) + 4.0F, g.top + 14.0F, 9.0F, C_HINT, Opt());
    for (int i = 0; i + 1 < 140; ++i) {
        const float t0 = total * static_cast<float>(i) / 139.0F, t1 = total * static_cast<float>(i + 1) / 139.0F;
        line(c, X(t0), Y(shape[i]), X(t1), Y(shape[i + 1]), C_ACCENT, 2.0F);
    }
    const float* patch = suP(u).data() + 1;
    float cum = 0.0F;
    const int sus = rI(suV(u, su::envId(e, su::EV_SUS)));
    for (int p = 0; p < su::kEnvPoints; ++p) {
        const float t = su::envelopePointTime(patch, e, p);
        cum = t;
        if (p > sus) break;
        const float lv = suV(u, su::envId(e, su::envL(p)));
        fill(c, RectF(X(cum) - 4.0F, Y(lv) - 4.0F, X(cum) + 4.0F, Y(lv) + 4.0F), 4.0F, p == sus ? C_AMBER : Color::rgb(226, 229, 234));
        text(c, std::to_string(p + 1), X(cum), Y(lv) - 8.0F, 9.0F, C_VALUE, Opt().center());
    }
    text(c, "до " + su::dispText(su::Disp{su::Disp::Time, 0.0F, 1.0F, " s", 2}, std::clamp(std::log10(std::max(total, 0.001F) / 0.001F) / 4.0F, 0.0F, 1.0F)), g.right - 6.0F, g.bottom - 4.0F, 9.0F, C_HINT, Opt().right());
    // the points
    const float unit = 112.0F;
    for (int p = 0; p < su::kEnvPoints; ++p) {
        const float cx = sec.left + unit * (static_cast<float>(p) + 0.5F);
        text(c, "ТОЧКА " + std::to_string(p + 1) + (p == sus ? "  ▸ПАУЗА" : ""), cx, sec.top + 168.0F, 10.0F, p == sus ? C_AMBER : C_KNOB_LABEL, Opt().center().bold());
        suKnob(c, cx, sec.top + 204.0F, 15.0F, unit - 6.0F, u, su::envId(e, su::envT(p)));
        suKnob(c, cx, sec.top + 298.0F, 15.0F, unit - 6.0F, u, su::envId(e, su::envL(p)));
    }
    // the rest
    const float L = sec.left + 586.0F, R = sec.right;
    const float u2 = (R - L) / 3.0F;
    suKnob(c, L + u2 * 0.5F, sec.top + 70.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_START));
    suKnob(c, L + u2 * 1.5F, sec.top + 70.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_REL));
    suKnob(c, L + u2 * 2.5F, sec.top + 70.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_CURVE));
    suChoice(c, RectF(L + u2 * 0.5F - 36.0F, sec.top + 152.0F, L + u2 * 0.5F + 36.0F, sec.top + 186.0F), u, su::envId(e, su::EV_SUS), su::kEnvPoints, [](int k) { return "ТОЧКА " + std::to_string(k + 1); }, "ПАУЗА ПРИ", 0);
    suKnob(c, L + u2 * 1.5F, sec.top + 168.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_KEYT));
    suSwitch(c, RectF(L + u2 * 2.5F - 36.0F, sec.top + 152.0F, L + u2 * 2.5F + 36.0F, sec.top + 186.0F), u, su::envId(e, su::EV_LOOP), "ПОВТАРЯНЕ", "ДА", "НЕ");
    text(c, "След пускане на клавиша: RELEASE и точките след паузата.", L, sec.top + 262.0F, 10.0F, C_HINT, Opt().maxW(R - L));
}

// ---------------------------------------------------------------- МОДУЛ.: LFOs, the step modulator and the free matrix
void SilvetonSamplerView::suPageMod(Canvas& c, const RectF& sec, int u) {
    static const char* const tabs[3] = {"LFO", "СТЪПКИ", "МАТРИЦА"};
    for (int i = 0; i < 3; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 116.0F, sec.top, sec.left + static_cast<float>(i) * 116.0F + 110.0F, sec.top + 32.0F);
        stripToggle(c, r, tabs[i], suModTab_ == i, C_AMBER, 12.0F);
        hit(r, [this, i](float, float) { suModTab_ = i; invalidate(); });
    }
    const float* patch = suP(u).data() + 1;
    if (suModTab_ == 0) {
        suLfo_ = std::clamp(suLfo_, 0, su::kLfos - 1);
        const int l = suLfo_;
        for (int i = 0; i < su::kLfos; ++i) {
            const RectF r(sec.left + 380.0F + static_cast<float>(i) * 86.0F, sec.top, sec.left + 380.0F + static_cast<float>(i) * 86.0F + 80.0F, sec.top + 32.0F);
            stripToggle(c, r, "LFO " + std::to_string(i + 1), l == i, C_ACCENT, 12.0F);
            hit(r, [this, i](float, float) { suLfo_ = i; invalidate(); });
        }
        const float unit = sec.width() / 4.0F;
        const auto cx = [&](int col) { return sec.left + unit * (static_cast<float>(col) + 0.5F); };
        suChoice(c, RectF(cx(0) - 60.0F, sec.top + 90.0F, cx(0) + 60.0F, sec.top + 124.0F), u, su::lfoId(l, su::LF_WAVE), su::kLfoWaves, [](int k) { return std::string(su::lfoWaveName(k)); }, "ФОРМА");
        suKnob(c, cx(1), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_RATE));
        suKnob(c, cx(2), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_DELAY));
        suKnob(c, cx(3), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_FADE));
        suKnob(c, cx(0), sec.top + 214.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_PHASE));
        suKnob(c, cx(1), sec.top + 214.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_KEYF));
        suSwitch(c, RectF(cx(2) - 50.0F, sec.top + 196.0F, cx(2) + 50.0F, sec.top + 230.0F), u, su::lfoId(l, su::LF_UNI), "ЕДНОПОЛЮСЕН (0..+)", "ДА", "НЕ");
        suSwitch(c, RectF(cx(3) - 50.0F, sec.top + 196.0F, cx(3) + 50.0F, sec.top + 230.0F), u, su::lfoId(l, su::LF_FREE), "СЛУЧАЙНО НАЧАЛО", "ДА", "НЕ");
        text(c, "Накъде отива LFO " + std::to_string(l + 1) + " — в МАТРИЦА (източник LFO " + std::to_string(l + 1) + ").", sec.left + 6.0F, sec.bottom - 14.0F, 12.0F, C_HINT, Opt().maxW(sec.width()));
        return;
    }
    if (suModTab_ == 1) {
        const int len = rI(suV(u, su::stepId(su::ST_LEN)));
        const RectF bars(sec.left, sec.top + 44.0F, sec.left + 600.0F, sec.top + 230.0F);
        fill(c, bars, 8.0F, Color::rgb(24, 27, 32));
        line(c, bars.left, bars.centerY(), bars.right, bars.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
        const float bw = bars.width() / static_cast<float>(su::kStepCount);
        for (int i = 0; i < su::kStepCount; ++i) {
            const float v = (suV(u, su::stepId(su::ST_STEPS + i)) - 0.5F) * 2.0F;
            const float x0 = bars.left + static_cast<float>(i) * bw;
            const bool used = i < len;
            const float y = bars.centerY() - v * (bars.height() * 0.5F - 6.0F);
            fill(c, RectF(x0 + 4.0F, std::min(y, bars.centerY()), x0 + bw - 4.0F, std::max(y, bars.centerY()) + 1.0F), 3.0F, used ? C_ACCENT : Color::rgb(70, 74, 82));
            text(c, std::to_string(i + 1), x0 + bw * 0.5F, bars.bottom + 13.0F, 10.0F, used ? C_KNOB_LABEL : C_HINT, Opt().center());
        }
        const auto setBar = [this, u, bars, bw](float x, float y) {
            const int i = std::clamp(static_cast<int>((x - bars.left) / bw), 0, su::kStepCount - 1);
            const float v = std::clamp((bars.centerY() - y) / (bars.height() * 0.5F - 6.0F), -1.0F, 1.0F);
            suSet(u, su::stepId(su::ST_STEPS + i), 0.5F + 0.5F * v);
        };
        hit(bars, setBar, nullptr, [setBar](float x, float y, bool) { setBar(x, y); });
        const float L = sec.left + 626.0F, unit = (sec.right - L) / 2.0F;
        suKnob(c, L + unit * 0.5F, sec.top + 70.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_LEN));
        suKnob(c, L + unit * 1.5F, sec.top + 70.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_RATE));
        suKnob(c, L + unit * 0.5F, sec.top + 170.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_GLIDE));
        static const char* const dirs[4] = {"НАПРЕД", "НАЗАД", "НАПРЕД-НАЗАД", "СЛУЧАЙНО"};
        suChoice(c, RectF(L + unit * 1.5F - 50.0F, sec.top + 152.0F, L + unit * 1.5F + 50.0F, sec.top + 186.0F), u, su::stepId(su::ST_DIR), 4, [](int k) { return std::string(dirs[k]); }, "ПОСОКА");
        text(c, "Докосни или влачи по стълбчетата. Стойностите отиват в МАТРИЦА (източник STEP).", sec.left + 6.0F, sec.bottom - 10.0F, 12.0F, C_HINT, Opt().maxW(sec.width()));
        return;
    }
    // the matrix: 16 lines, source -> target, amount
    for (int m = 0; m < su::kMods; ++m) {
        const int col = m / 8, row = m % 8;
        const float x0 = sec.left + static_cast<float>(col) * 456.0F;
        const float y0 = sec.top + 42.0F + static_cast<float>(row) * 39.0F;
        const int src = rI(suV(u, su::modId(m, 0))), dst = rI(suV(u, su::modId(m, 1)));
        const float amt = (suV(u, su::modId(m, 2)) - 0.5F) * 2.0F;
        text(c, std::to_string(m + 1), x0 + 2.0F, y0 + 22.0F, 11.0F, C_HINT, Opt());
        const RectF rs(x0 + 20.0F, y0, x0 + 132.0F, y0 + 32.0F), rd(x0 + 138.0F, y0, x0 + 318.0F, y0 + 32.0F), ra(x0 + 324.0F, y0, x0 + 440.0F, y0 + 32.0F);
        stripToggle(c, rs, su::modSourceName(src), src != 0, C_AMBER, 10.0F);
        stripToggle(c, rd, src == 0 ? std::string("—") : su::destName(dst, patch), src != 0, C_AMBER, 10.0F);
        hit(rs, [this, u, m](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            for (int k = 0; k < su::kModSources; ++k) items.emplace_back(fmtZeroPad(k, 2), su::modSourceName(k));
            showGridPicker("ОТКЪДЕ ИДВА (линия " + std::to_string(m + 1) + ")", items, rI(suV(u, su::modId(m, 0))), std::nullopt, [this, u, m](int k) { if (k >= 0) suSet(u, su::modId(m, 0), static_cast<float>(k)); });
        }, [this, u, m] { suSet(u, su::modId(m, 0), 0.0F); });
        hit(rd, [this, u, m](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            std::vector<int> ids;
            const float* pp = suP(u).data() + 1;
            int cur = 0;
            for (int k = 0; k < su::kDestCount; ++k) {
                if (!su::destUsable(k, pp)) continue;
                if (k == rI(suV(u, su::modId(m, 1)))) cur = static_cast<int>(ids.size());
                items.emplace_back(fmtZeroPad(static_cast<int>(ids.size()), 2), su::destName(k, pp));
                ids.push_back(k);
            }
            showGridPicker("НАКЪДЕ ОТИВА (линия " + std::to_string(m + 1) + ")", items, cur, std::nullopt, [this, u, m, ids](int k) { if (k >= 0 && k < static_cast<int>(ids.size())) suSet(u, su::modId(m, 1), static_cast<float>(ids[static_cast<std::size_t>(k)])); });
        });
        // the amount: a bar from -100 % to +100 %
        fill(c, ra, 6.0F, Color::rgb(30, 33, 39));
        line(c, ra.centerX(), ra.top + 4.0F, ra.centerX(), ra.bottom - 4.0F, Color::argb(80, 255, 255, 255), 1.0F);
        const float half = ra.width() * 0.5F - 4.0F;
        if (amt != 0.0F) fill(c, RectF(std::min(ra.centerX(), ra.centerX() + amt * half), ra.top + 8.0F, std::max(ra.centerX(), ra.centerX() + amt * half), ra.bottom - 8.0F), 3.0F, src != 0 ? C_ACCENT : Color::rgb(90, 94, 102));
        text(c, std::to_string(rI(amt * 100.0F)) + "%", ra.centerX(), ra.centerY() + 4.0F, 11.0F, C_VALUE, Opt().center().bold());
        const auto setAmt = [this, u, m, ra](float x, float) { suSet(u, su::modId(m, 2), 0.5F + 0.5F * std::clamp((x - ra.centerX()) / (ra.width() * 0.5F - 4.0F), -1.0F, 1.0F)); };
        hit(ra, setAmt, [this, u, m] { suSet(u, su::modId(m, 2), 0.5F); }, [setAmt](float x, float y, bool) { setAmt(x, y); });
    }
    text(c, "Всяка линия: ОТКЪДЕ → НАКЪДЕ и колко (-100..+100 %). Двоен допир върху силата = 0.", sec.left + 6.0F, sec.bottom - 8.0F, 11.0F, C_HINT, Opt().maxW(sec.width()));
}

} // namespace silveton::ui::classic
