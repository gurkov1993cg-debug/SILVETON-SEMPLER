// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH (part 2: ВЪЛНИ = the wave editor, ФИЛТРИ, ОБВИВКИ, МОДУЛ.).
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
constexpr float kPiF = 3.14159265358979F;
}  // namespace

// a drawn wave (64 points -1..1) into slot 0..3 of the patch (kept as 0.5 + 0.5 * v)
void SilvetonSamplerView::suWaveSet(int u, int slot, const float* pts) {
    std::vector<float> v(static_cast<std::size_t>(su::kDrawLen));
    for (int i = 0; i < su::kDrawLen; ++i) v[static_cast<std::size_t>(i)] = 0.5F + 0.5F * std::clamp(pts[i], -1.0F, 1.0F);
    suBlock(u, su::drawId(slot, 0), v);
}

// ---------------------------------------------------------------- ВЪЛНИ: pictures of the waves
void SilvetonSamplerView::suPageGallery(Canvas& c, const RectF& sec, int u) {
    // the picture of a wave: 64 points -1..1 in a rect (every `step`-th point)
    const auto drawWavePicture = [this](Canvas& cv, const RectF& r, const float* pts, ColorInt col, float width, int step) {
        const float mid = r.centerY();
        const float amp = r.height() * 0.5F - 3.0F;
        const float dx = r.width() / static_cast<float>(su::kDrawLen);
        for (int i = 0; i + step < su::kDrawLen; i += step) {
            const float x0 = r.left + (static_cast<float>(i) + 0.5F) * dx, x1 = r.left + (static_cast<float>(i + step) + 0.5F) * dx;
            line(cv, x0, mid - std::clamp(pts[i], -1.0F, 1.0F) * amp, x1, mid - std::clamp(pts[i + step], -1.0F, 1.0F) * amp, col, width);
        }
    };
    const float* patch = suP(u).data() + 1;
    suPickGen_ = std::clamp(suPickGen_, 0, su::kGens - 1);
    const int total = su::kWaveDrawn0 + su::kDrawnWaves;   // 64 calculated + 4 drawn
    suPick_ = std::clamp(suPick_, 0, total - 1);
    // the pictures of the 64 calculated waves are made once; the 4 drawn ones are read from the patch every time
    static std::vector<float> cache;
    if (cache.empty()) {
        cache.assign(static_cast<std::size_t>(su::kMathWaves) * static_cast<std::size_t>(su::kDrawLen), 0.0F);
        for (int w = 0; w < su::kMathWaves; ++w) su::waveChoicePoints(w, nullptr, cache.data() + static_cast<std::size_t>(w) * static_cast<std::size_t>(su::kDrawLen));
    }
    float drawn[su::kDrawnWaves][su::kDrawLen];
    for (int i = 0; i < su::kDrawnWaves; ++i) su::waveChoicePoints(su::kWaveDrawn0 + i, patch, drawn[i]);
    const auto ptsOf = [&](int w) -> const float* { return w < su::kMathWaves ? cache.data() + static_cast<std::size_t>(w) * static_cast<std::size_t>(su::kDrawLen) : drawn[w - su::kMathWaves]; };
    const int g = suPickGen_;
    const bool isWave = rI(suV(u, su::genId(g, su::GN_METHOD))) == su::M_WAVE;
    const int curA = isWave ? rI(suV(u, su::genId(g, su::GN_SEL1))) : -1, curB = isWave ? rI(suV(u, su::genId(g, su::GN_SEL2))) : -1;

    const bool choose = suPickSlot_ >= 0;
    if (choose) {
        suPickGen_ = std::clamp(suPickGen_, 0, su::kGens - 1);
        text(c, std::string("ИЗБЕРИ ВЪЛНОВА ФОРМА ") + (suPickSlot_ == 0 ? "А" : "Б") + " ЗА ОСЦИЛАТОР " + std::to_string(suPickGen_ + 1) + " — докосни картинка", sec.left + 2.0F, sec.top + 12.0F, 12.0F, C_AMBER, Opt().bold().spacing(0.12F).maxW(610.0F));
    } else {
        text(c, "ВЪЛНИ — докосни картинка, за да я видиш голяма вдясно", sec.left + 2.0F, sec.top + 12.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F).maxW(600.0F));
    }
    // the grid
    constexpr int kCols = 10, kRows = 7;
    const float gx = sec.left, gy = sec.top + 22.0F, gw = 600.0F, gap = 4.0F;
    const float cw = (gw - gap * static_cast<float>(kCols - 1)) / static_cast<float>(kCols);
    const float ch = (sec.bottom - gy - gap * static_cast<float>(kRows - 1)) / static_cast<float>(kRows);
    for (int w = 0; w < total; ++w) {
        const int col = w % kCols, row = w / kCols;
        const RectF r(gx + static_cast<float>(col) * (cw + gap), gy + static_cast<float>(row) * (ch + gap), gx + static_cast<float>(col) * (cw + gap) + cw, gy + static_cast<float>(row) * (ch + gap) + ch);
        const bool sel = w == suPick_;
        if (sel) fill(c, r, 6.0F, C_ACCENT);
        fill(c, sel ? RectF(r.left + 2.0F, r.top + 2.0F, r.right - 2.0F, r.bottom - 2.0F) : r, 5.0F, w >= su::kWaveDrawn0 ? Color::rgb(42, 40, 30) : Color::rgb(30, 33, 39));
        drawWavePicture(c, RectF(r.left + 4.0F, r.top + 9.0F, r.right - 4.0F, r.bottom - 3.0F), ptsOf(w), sel ? C_VALUE : C_ACCENT, 1.3F, 1);
        text(c, std::to_string(w + 1), r.left + 4.0F, r.top + 9.0F, 8.0F, C_HINT, Opt());
        if (w == curA) text(c, "А", r.right - 5.0F, r.top + 10.0F, 9.0F, C_AMBER, Opt().right().bold());
        if (w == curB) text(c, "Б", r.right - (w == curA ? 15.0F : 5.0F), r.top + 10.0F, 9.0F, C_AMBER, Opt().right().bold());
        hit(r, [this, w, u](float, float) {
            if (suPickSlot_ < 0) { suPick_ = w; invalidate(); return; }
            // choosing: the tap puts the wave into the oscillator and the player is back on ОСЦИЛ.
            const int gg = suPickGen_, slot = suPickSlot_;
            if (rI(suV(u, su::genId(gg, su::GN_METHOD))) != su::M_WAVE) suSet(u, su::genId(gg, su::GN_METHOD), static_cast<float>(su::M_WAVE));
            suSet(u, su::genId(gg, slot == 0 ? su::GN_SEL1 : su::GN_SEL2), static_cast<float>(w));
            suStatus_ = "ОСЦ " + std::to_string(gg + 1) + ": ВЪЛНОВА ФОРМА " + (slot == 0 ? "А" : "Б") + " = " + su::waveName(w);
            suStatusUntilMs_ = nowMs() + 4000;
            suPickSlot_ = -1; suPage_ = 0;
            invalidate();
        });
    }
    // the chosen wave, big
    const float X = sec.left + 620.0F, W = sec.right - X;
    const RectF pic(X, sec.top + 22.0F, X + W, sec.top + 142.0F);
    fill(c, pic, 8.0F, Color::rgb(24, 27, 32));
    line(c, pic.left, pic.centerY(), pic.right, pic.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
    for (int q = 1; q < 4; ++q) line(c, pic.left + pic.width() * static_cast<float>(q) / 4.0F, pic.top + 4.0F, pic.left + pic.width() * static_cast<float>(q) / 4.0F, pic.bottom - 4.0F, Color::argb(28, 255, 255, 255), 1.0F);
    drawWavePicture(c, RectF(pic.left + 6.0F, pic.top + 4.0F, pic.right - 6.0F, pic.bottom - 4.0F), ptsOf(suPick_), C_ACCENT, 2.4F, 1);
    text(c, su::waveName(suPick_), X, sec.top + 164.0F, 16.0F, C_VALUE, Opt().bold().maxW(W));
    text(c, suPick_ >= su::kWaveDrawn0 ? "нарисувана вълна " + std::to_string(suPick_ - su::kWaveDrawn0 + 1) + " (редактира се в РИСУВАНЕ)" : "вълна № " + std::to_string(suPick_ + 1), X, sec.top + 180.0F, 10.0F, C_HINT, Opt().maxW(W));
    if (choose) {   // the small panel of the choose mode: what is there now, and the way back
        text(c, isWave ? std::string("Сега е: ") + su::waveName(suPickSlot_ == 0 ? curA : curB) : std::string("Този осцилатор още не е с метод ВЪЛНА."), X, sec.top + 202.0F, 11.0F, C_SECTION_TITLE, Opt().bold().maxW(W));
        const RectF rc(X, sec.top + 214.0F, X + W, sec.top + 252.0F);
        stripToggle(c, rc, "◀ ОТКАЗ — назад", false, C_AMBER, 13.0F);
        hit(rc, [this](float, float) { suPickSlot_ = -1; suPage_ = 0; invalidate(); });
        text(c, "Докосни картинка отляво и тя става вълновата форма.", X, sec.top + 276.0F, 10.0F, C_HINT, Opt().maxW(W));
        return;
    }
    // into which oscillator
    text(c, "ПОСТАВИ В ОСЦИЛАТОР:", X, sec.top + 202.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F));
    const float kw = (W - 5.0F * 4.0F) / 6.0F;
    for (int i = 0; i < su::kGens; ++i) {
        const RectF r(X + static_cast<float>(i) * (kw + 4.0F), sec.top + 208.0F, X + static_cast<float>(i) * (kw + 4.0F) + kw, sec.top + 234.0F);
        stripToggle(c, r, "ОСЦ " + std::to_string(i + 1), g == i, C_ACCENT, 10.0F);
        hit(r, [this, i](float, float) { suPickGen_ = i; invalidate(); });
    }
    const auto put = [this, u, g](int sel, const char* which) {
        if (rI(suV(u, su::genId(g, su::GN_METHOD))) != su::M_WAVE) suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(su::M_WAVE));
        suSet(u, su::genId(g, sel), static_cast<float>(suPick_));
        suStatus_ = "ОСЦ " + std::to_string(g + 1) + ": " + which + " = " + su::waveName(suPick_);
        suStatusUntilMs_ = nowMs() + 4000;
        invalidate();
    };
    const RectF ba(X, sec.top + 242.0F, X + W, sec.top + 272.0F), bb(X, sec.top + 278.0F, X + W, sec.top + 308.0F);
    stripToggle(c, ba, "ПОСТАВИ КАТО ВЪЛНА А", curA == suPick_, C_ACCENT, 12.0F);
    stripToggle(c, bb, "ПОСТАВИ КАТО ВЪЛНА Б", curB == suPick_, C_ACCENT, 12.0F);
    hit(ba, [put](float, float) { put(su::GN_SEL1, "ВЪЛНА А"); });
    hit(bb, [put](float, float) { put(su::GN_SEL2, "ВЪЛНА Б"); });
    if (isWave) text(c, "Сега в ОСЦ " + std::to_string(g + 1) + ":  А = " + su::waveName(curA) + "   Б = " + su::waveName(curB), X, sec.top + 324.0F, 10.0F, C_VALUE, Opt().maxW(W));
    else text(c, "ОСЦ " + std::to_string(g + 1) + " още не е с метод ВЪЛНА — ще стане, щом поставиш вълна.", X, sec.top + 324.0F, 10.0F, C_AMBER, Opt().maxW(W));
    text(c, "А и Б се смесват с копчето СМЕС А→Б (ОСЦИЛ. → ЗВУК И ВЪЛНИ).", X, sec.top + 340.0F, 9.0F, C_HINT, Opt().maxW(W));
}

// ---------------------------------------------------------------- РИСУВАНЕ: the wave editor
void SilvetonSamplerView::suPageWaves(Canvas& c, const RectF& sec, int u) {
    suWaveSlot_ = std::clamp(suWaveSlot_, 0, su::kDrawnWaves - 1);
    const int slot = suWaveSlot_;
    const float* patch = suP(u).data() + 1;
    float pts[su::kDrawLen];
    su::waveChoicePoints(su::kWaveDrawn0 + slot, patch, pts);
    // row 1: the four drawn waves and the way of working
    for (int i = 0; i < su::kDrawnWaves; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 86.0F, sec.top, sec.left + static_cast<float>(i) * 86.0F + 80.0F, sec.top + 34.0F);
        stripToggle(c, r, su::waveName(su::kWaveDrawn0 + i), slot == i, C_ACCENT, 10.0F);
        hit(r, [this, i](float, float) { suWaveSlot_ = i; invalidate(); });
    }
    static const char* const modes[2] = {"РИСУВАЙ", "ХАРМОНИЦИ"};
    for (int i = 0; i < 2; ++i) {
        const RectF r(sec.left + 356.0F + static_cast<float>(i) * 100.0F, sec.top, sec.left + 356.0F + static_cast<float>(i) * 100.0F + (i == 0 ? 94.0F : 104.0F), sec.top + 34.0F);
        stripToggle(c, r, modes[i], suWaveMode_ == i, C_AMBER, 11.0F);
        hit(r, [this, i](float, float) { suWaveMode_ = i; invalidate(); });
    }
    // the wave
    const RectF cv(sec.left, sec.top + 44.0F, sec.left + 560.0F, sec.top + 196.0F);
    fill(c, cv, 8.0F, Color::rgb(24, 27, 32));
    line(c, cv.left, cv.centerY(), cv.right, cv.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
    for (int q = 1; q < 4; ++q) line(c, cv.left + cv.width() * static_cast<float>(q) / 4.0F, cv.top + 4.0F, cv.left + cv.width() * static_cast<float>(q) / 4.0F, cv.bottom - 4.0F, Color::argb(28, 255, 255, 255), 1.0F);
    const float px = cv.width() / static_cast<float>(su::kDrawLen);
    for (int i = 0; i < su::kDrawLen; ++i) {
        const float x = cv.left + (static_cast<float>(i) + 0.5F) * px;
        const float y = cv.centerY() - pts[i] * (cv.height() * 0.5F - 6.0F);
        line(c, x, cv.centerY(), x, y, Color::argb(90, 80, 220, 120), px * 0.7F);
        if (i + 1 < su::kDrawLen) {
            const float x2 = x + px, y2 = cv.centerY() - pts[i + 1] * (cv.height() * 0.5F - 6.0F);
            line(c, x, y, x2, y2, C_ACCENT, 2.0F);
        }
    }
    text(c, std::string(su::waveName(su::kWaveDrawn0 + slot)) + " · една вълна = 64 точки", cv.left + 10.0F, cv.top + 16.0F, 11.0F, C_KNOB_LABEL, Opt());
    if (suWaveMode_ == 0) {
        const auto drawPoint = [this, u, slot, cv](float x, float y, bool final) {
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            const int i1 = std::clamp(static_cast<int>((x - cv.left) / cv.width() * static_cast<float>(su::kDrawLen)), 0, su::kDrawLen - 1);
            const float v1 = std::clamp(1.0F - 2.0F * (y - cv.top - 6.0F) / (cv.height() - 12.0F), -1.0F, 1.0F);
            int i0 = suDrawLastI_ < 0 ? i1 : suDrawLastI_;
            float v0 = suDrawLastI_ < 0 ? v1 : suDrawLastV_;
            const int step = i1 >= i0 ? 1 : -1;
            for (int i = i0;; i += step) {
                const float t = i1 == i0 ? 1.0F : static_cast<float>(i - i0) / static_cast<float>(i1 - i0);
                cur[i] = v0 + (v1 - v0) * t;
                if (i == i1) break;
            }
            suDrawLastI_ = final ? -1 : i1; suDrawLastV_ = v1;
            suWaveSet(u, slot, cur);
        };
        hit(cv, [drawPoint](float x, float y) { drawPoint(x, y, true); }, nullptr, drawPoint);
    }
    // the spectrum (amplitude of harmonic 1..31) and the phases
    float amp[su::kEditHarmonics], ph[su::kEditHarmonics];
    su::waveHarmonics(pts, amp, ph);
    const RectF ar(sec.left, sec.top + 206.0F, sec.left + 560.0F, sec.top + 280.0F);
    const RectF pr(sec.left, sec.top + 288.0F, sec.left + 560.0F, sec.top + 350.0F);
    fill(c, ar, 6.0F, Color::rgb(30, 33, 39));
    fill(c, pr, 6.0F, Color::rgb(30, 33, 39));
    line(c, pr.left, pr.centerY(), pr.right, pr.centerY(), Color::argb(60, 255, 255, 255), 1.0F);
    const float bw = ar.width() / static_cast<float>(su::kEditHarmonics);
    for (int k = 0; k < su::kEditHarmonics; ++k) {
        const float x0 = ar.left + static_cast<float>(k) * bw;
        const float h = std::clamp(amp[k], 0.0F, 1.0F) * (ar.height() - 6.0F);
        if (h > 0.5F) fill(c, RectF(x0 + 2.0F, ar.bottom - 3.0F - h, x0 + bw - 2.0F, ar.bottom - 3.0F), 2.0F, suWaveMode_ == 1 ? C_ACCENT : Color::rgb(110, 150, 120));
        if (k % 5 == 0) text(c, std::to_string(k + 1), x0 + bw * 0.5F, ar.bottom + 11.0F, 9.0F, C_HINT, Opt().center());
        const float pv = ph[k] / kPiF;   // -1..1
        const float yy = pr.centerY() - pv * (pr.height() * 0.5F - 4.0F);
        if (amp[k] > 0.004F) fill(c, RectF(x0 + 3.0F, std::min(yy, pr.centerY()), x0 + bw - 3.0F, std::max(yy, pr.centerY()) + 1.0F), 1.0F, suWaveMode_ == 1 ? C_AMBER : Color::rgb(130, 120, 90));
    }
    text(c, "СПЕКТЪР (сила на хармониците 1-31)", ar.left + 8.0F, ar.top + 13.0F, 10.0F, C_KNOB_LABEL, Opt());
    text(c, "ФАЗИ", pr.left + 8.0F, pr.top + 13.0F, 10.0F, C_KNOB_LABEL, Opt());
    if (suWaveMode_ == 1) {
        const auto edit = [this, u, slot, ar, pr, bw](bool phase, float x, float y) {
            float cur[su::kDrawLen], a[su::kEditHarmonics], p[su::kEditHarmonics], out[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            su::waveHarmonics(cur, a, p);
            const int k = std::clamp(static_cast<int>((x - ar.left) / bw), 0, su::kEditHarmonics - 1);
            if (phase) p[k] = std::clamp((pr.centerY() - y) / (pr.height() * 0.5F - 4.0F), -1.0F, 1.0F) * kPiF;
            else a[k] = std::clamp((ar.bottom - 3.0F - y) / (ar.height() - 6.0F), 0.0F, 1.0F);
            if (!phase && a[k] > 0.0F && std::fabs(p[k]) < 1.0e-6F) p[k] = 0.0F;
            su::waveFromHarmonics(a, p, out);
            suWaveSet(u, slot, out);
        };
        hit(ar, [edit](float x, float y) { edit(false, x, y); }, nullptr, [edit](float x, float y, bool) { edit(false, x, y); });
        hit(pr, [edit](float x, float y) { edit(true, x, y); }, nullptr, [edit](float x, float y, bool) { edit(true, x, y); });
    }
    // the right side: what can be done to the wave
    const float L = sec.left + 580.0F, R = sec.right;
    text(c, "ОПЕРАЦИИ (симетрия, спектър)", L, sec.top + 12.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    const float ow = (R - L - 6.0F) / 2.0F;
    for (int op = 0; op < su::kWaveOps; ++op) {
        const RectF r(L + static_cast<float>(op % 2) * (ow + 6.0F), sec.top + 22.0F + static_cast<float>(op / 2) * 34.0F, L + static_cast<float>(op % 2) * (ow + 6.0F) + ow, sec.top + 50.0F + static_cast<float>(op / 2) * 34.0F);
        stripToggle(c, r, su::waveOpName(op), false, C_AMBER, 11.0F);
        hit(r, [this, u, slot, op](float, float) {
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            su::waveApplyOp(op, cur);
            suWaveSet(u, slot, cur);
        });
    }
    // two waves into this one
    text(c, "СМЕСИ ДВЕ ВЪЛНИ → " + std::string(su::waveName(su::kWaveDrawn0 + slot)), L, sec.top + 176.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    const RectF ra(L, sec.top + 186.0F, L + ow, sec.top + 216.0F), rb(L + ow + 6.0F, sec.top + 186.0F, R, sec.top + 216.0F);
    stripToggle(c, ra, "А: " + std::string(su::waveName(suCombA_)), false, C_AMBER, 11.0F);
    stripToggle(c, rb, "Б: " + std::string(su::waveName(suCombB_)), false, C_AMBER, 11.0F);
    hit(ra, [this, u](float, float) { suPickWave(u, [this](int k) { suCombA_ = k; invalidate(); }, "ВЪЛНА А — избери"); });
    hit(rb, [this, u](float, float) { suPickWave(u, [this](int k) { suCombB_ = k; invalidate(); }, "ВЪЛНА Б — избери"); });
    const RectF rm(L, sec.top + 226.0F, L + 110.0F, sec.top + 258.0F);
    stripToggle(c, rm, su::combineName(suCombMode_), true, C_AMBER, 11.0F);
    hit(rm, [this](float, float) { suCombMode_ = (suCombMode_ + 1) % su::kCombines; invalidate(); });
    knobControl(c, L + 168.0F, sec.top + 242.0F, 14.0F, suCombT_, 0.0F, 1.0F, 0.01F, 200.0F, false, std::to_string(rI(suCombT_ * 100.0F)) + "%", "ОТ А КЪМ Б", 90.0F,
                [this](float nv) { suCombT_ = nv; invalidate(); },
                [this] { showNumber("ОТ А КЪМ Б %", suCombT_ * 100.0F, 0.0F, 100.0F, 0, [this](float x) { suCombT_ = x / 100.0F; invalidate(); }); },
                [this] { suCombT_ = 0.5F; invalidate(); });
    const RectF rapply(L + 232.0F, sec.top + 226.0F, R, sec.top + 258.0F);
    stripToggle(c, rapply, "ПРИЛОЖИ", false, C_ACCENT, 12.0F);
    hit(rapply, [this, u, slot](float, float) {
        float a[su::kDrawLen], b[su::kDrawLen], out[su::kDrawLen];
        const float* pp = suP(u).data() + 1;
        su::waveChoicePoints(suCombA_, pp, a); su::waveChoicePoints(suCombB_, pp, b);
        su::waveCombine(suCombMode_, a, b, suCombT_, out);
        suWaveSet(u, slot, out);
    });
    // the files of own waves
    const RectF rs(L, sec.top + 312.0F, L + ow, sec.top + 346.0F), rl(L + ow + 6.0F, sec.top + 312.0F, R, sec.top + 346.0F);
    stripToggle(c, rs, "ЗАПАЗИ ВЪЛНАТА", false, C_AMBER, 11.0F);
    stripToggle(c, rl, "ЗАРЕДИ ВЪЛНА", false, C_AMBER, 11.0F);
    hit(rs, [this, u, slot](float, float) {
        showTextPage("ИМЕ НА ВЪЛНАТА", suWaveName_, [this, u, slot](const std::string& nm) {
            suWaveName_ = nm;
            float cur[su::kDrawLen];
            su::waveChoicePoints(su::kWaveDrawn0 + slot, suP(u).data() + 1, cur);
            const auto err = sampler.suseSaveWave(nm, std::vector<float>(cur, cur + su::kDrawLen));
            suStatus_ = err ? *err : "Вълната е записана: " + nm;
            suStatusUntilMs_ = nowMs() + 4000; invalidate();
        });
    });
    hit(rl, [this, u, slot](float, float) {
        const auto names = sampler.suseUserWaves();
        if (names.empty()) { showMessage("РИСУВАНЕ", "Още няма записани твои вълни. Нарисувай една и натисни ЗАПАЗИ ВЪЛНАТА."); return; }
        showItems("ЗАРЕДИ ВЪЛНА в " + std::string(su::waveName(su::kWaveDrawn0 + slot)), names, [this, u, slot, names](int k) {
            if (k < 0 || k >= static_cast<int>(names.size())) return;
            std::vector<float> loaded;
            const auto err = sampler.suseLoadWave(names[static_cast<std::size_t>(k)], loaded);
            if (err) { suStatus_ = *err; suStatusUntilMs_ = nowMs() + 4000; invalidate(); return; }
            suWaveSet(u, slot, loaded.data());
        });
    });
}

// ---------------------------------------------------------------- ФИЛТРИ: the two shared filters
void SilvetonSamplerView::suPageFilters(Canvas& c, const RectF& sec, int u) {
    const float pw = (sec.width() - 14.0F) / 2.0F;
    for (int f = 0; f < su::kFilters; ++f) {
        const float x0 = sec.left + static_cast<float>(f) * (pw + 14.0F);
        const int type = rI(suV(u, su::filterId(f, su::FL_TYPE)));
        text(c, f == 0 ? "ФИЛТЪР А" : "ФИЛТЪР Б", x0 + 2.0F, sec.top + 14.0F, 13.0F, C_VALUE, Opt().bold().spacing(0.15F));
        text(c, std::string("(получава звук от осцилаторите с ПРЕМИНАВА ПРЕЗ ") + (f == 0 ? "ФИЛТЪР А" : "ФИЛТЪР Б") + ")", x0 + 100.0F, sec.top + 14.0F, 10.0F, C_HINT, Opt().maxW(pw - 100.0F));
        const float kw = (pw - 4.0F * 5.0F) / 5.0F;
        for (int t = 0; t < su::kFilterTypes; ++t) {
            const RectF r(x0 + static_cast<float>(t % 5) * (kw + 5.0F), sec.top + 24.0F + static_cast<float>(t / 5) * 34.0F, x0 + static_cast<float>(t % 5) * (kw + 5.0F) + kw, sec.top + 54.0F + static_cast<float>(t / 5) * 34.0F);
            stripToggle(c, r, su::filterTypeName(t), type == t, C_ACCENT, 11.0F);
            hit(r, [this, u, f, t](float, float) { suSet(u, su::filterId(f, su::FL_TYPE), static_cast<float>(t)); });
        }
        if (type == su::FT_OFF) {
            text(c, "Филтърът е изключен — звукът минава през него непроменен.", x0 + 6.0F, sec.top + 150.0F, 13.0F, C_HINT, Opt().maxW(pw - 12.0F));
            continue;
        }
        {
            const auto lines = wrapLines(su::filterTypeHelp(type), 11.0F, Face::Regular, pw - 8.0F);
            for (std::size_t i = 0; i < lines.size() && i < 2; ++i) text(c, lines[i], x0 + 4.0F, sec.top + 102.0F + static_cast<float>(i) * 14.0F, 11.0F, C_VALUE, Opt());
        }
        const float unit = pw / 4.0F;
        const auto cx = [&](int col) { return x0 + unit * (static_cast<float>(col) + 0.5F); };
        const float y1 = sec.top + 152.0F, y2 = sec.top + 252.0F;
        suKnob(c, cx(0), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_CUT));
        suKnob(c, cx(1), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_RES));
        suKnob(c, cx(2), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_DRIVE));
        suKnob(c, cx(3), y1, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_KEY));
        suKnob(c, cx(0), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_VEL));
        suChoice(c, RectF(cx(1) - 36.0F, y2 - 20.0F, cx(1) + 36.0F, y2 + 14.0F), u, su::filterId(f, su::FL_ENV), su::kEnvs + 1,
                 [](int k) { return k == 0 ? std::string("НЯМА") : "ОБВ. " + std::to_string(k); }, "КОЯ ОБВИВКА");
        if (rI(suV(u, su::filterId(f, su::FL_ENV))) > 0) suKnob(c, cx(2), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_ENVAMT));
        if (type == su::FT_FORMANT) suKnob(c, cx(3), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_VOWEL));
        else if (type == su::FT_SVF) suKnob(c, cx(3), y2, 16.0F, unit - 4.0F, u, su::filterId(f, su::FL_MORPH));
    }
    text(c, "ДВАТА ФИЛТЪРА:", sec.left + 4.0F, sec.bottom - 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    suSwitch(c, RectF(sec.left + 132.0F, sec.bottom - 38.0F, sec.left + 332.0F, sec.bottom - 8.0F), u, su::G_FILTER_LINK, "", "ПОРЕДНО (А → Б)", "УСПОРЕДНО (А + Б)");
}

// ---------------------------------------------------------------- ОБВИВКИ: four envelopes; the classic АТАКА - ЗАТИХВАНЕ - ДЪРЖАНЕ - ПУСКАНЕ, or the five points
void SilvetonSamplerView::suPageEnvelopes(Canvas& c, const RectF& sec, int u) {
    suEnv_ = std::clamp(suEnv_, 0, su::kEnvs - 1);
    const int e = suEnv_;
    const bool adv = suEnvAdv_;
    for (int i = 0; i < su::kEnvs; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 106.0F, sec.top, sec.left + static_cast<float>(i) * 106.0F + 100.0F, sec.top + 32.0F);
        stripToggle(c, r, "ОБВИВКА " + std::to_string(i + 1), e == i, C_ACCENT, 12.0F);
        hit(r, [this, i](float, float) { suEnv_ = i; invalidate(); });
    }
    text(c, "ОБВИВКА 1 води силата на осцилаторите по подразбиране.", sec.left + 436.0F, sec.top + 21.0F, 10.0F, C_HINT, Opt().maxW(sec.width() - 436.0F - 244.0F));
    {
        const RectF r(sec.right - 236.0F, sec.top, sec.right, sec.top + 32.0F);
        stripToggle(c, r, adv ? "ПРОСТ РЕЖИМ (4 РЕГУЛАТОРА)" : "РАЗШИРЕН РЕЖИМ (5 ТОЧКИ)", adv, C_AMBER, 10.5F);
        hit(r, [this](float, float) { suEnvAdv_ = !suEnvAdv_; invalidate(); });
    }
    const float* patch = suP(u).data() + 1;
    const int sus = std::clamp(rI(suV(u, su::envId(e, su::EV_SUS))), 0, su::kEnvPoints - 1);
    bool classic = sus == 1;
    for (int i = 2; i < su::kEnvPoints; ++i) classic = classic && suV(u, su::envId(e, su::envT(i))) <= 0.001F;

    // ---- the drawing: every part has a width you can see, the curve inside is the real one
    const RectF g(sec.left, sec.top + 40.0F, sec.left + 560.0F, sec.top + (adv ? 150.0F : 196.0F));
    fill(c, g, 8.0F, Color::rgb(24, 27, 32));
    float shape[200];
    su::EnvPart parts[su::kEnvPartsMax];
    const int np = su::envelopeSchematic(patch, e, 200, shape, parts);
    const float gx0 = g.left + 12.0F, gx1 = g.right - 12.0F, gy0 = g.bottom - 24.0F, gy1 = g.top + 14.0F;
    const auto X = [&](float x) { return gx0 + (gx1 - gx0) * x; };
    const auto Y = [&](float v) { return gy0 - (gy0 - gy1) * std::clamp(v, 0.0F, 1.0F); };
    for (int i = 0; i < np; i += 2) fill(c, RectF(X(parts[i].x0), g.top + 4.0F, X(parts[i].x1), g.bottom - 4.0F), 0.0F, Color::argb(16, 255, 255, 255));
    line(c, gx0, gy0, gx1, gy0, Color::argb(70, 255, 255, 255), 1.0F);
    for (int j = 0; j + 1 < 200; ++j) line(c, X(static_cast<float>(j) / 199.0F), Y(shape[j]), X(static_cast<float>(j + 1) / 199.0F), Y(shape[j + 1]), C_ACCENT, 2.2F);
    int decays = 0;
    for (int i = 0; i < np; ++i) if (parts[i].kind == 1) ++decays;
    for (int i = 0; i < np; ++i) {
        const su::EnvPart& pt = parts[i];
        const float cx = X((pt.x0 + pt.x1) * 0.5F);
        std::string name = pt.kind == 0 ? "АТАКА" : (pt.kind == 1 ? "ЗАТИХВАНЕ" : (pt.kind == 2 ? "ДЪРЖАНЕ" : (pt.kind == 3 ? "ПУСК. т." : "ПУСКАНЕ")));
        if (adv && pt.kind == 1 && decays > 1) name += " " + std::to_string(pt.point + 1);
        if (adv && pt.kind == 3) name += std::to_string(pt.point + 1);
        text(c, name, cx, g.bottom - 8.0F, 9.5F, pt.kind == 2 ? C_AMBER : C_KNOB_LABEL, Opt().center().bold().maxW(X(pt.x1) - X(pt.x0) - 2.0F));
        if (pt.kind == 2) {
            const int j = std::clamp(static_cast<int>((pt.x0 + pt.x1) * 0.5F * 199.0F), 0, 199);
            text(c, std::to_string(rI(shape[j] * 100.0F)) + " %", cx, Y(shape[j]) - 7.0F, 10.0F, C_AMBER, Opt().center().bold());
        } else {
            const int j = std::clamp(static_cast<int>(pt.x1 * 199.0F), 0, 199);
            fill(c, RectF(X(pt.x1) - 4.0F, Y(shape[j]) - 4.0F, X(pt.x1) + 4.0F, Y(shape[j]) + 4.0F), 4.0F, Color::rgb(226, 229, 234));
            if (adv && pt.kind != 4) text(c, std::to_string(pt.point + 1), X(pt.x1), Y(shape[j]) - 9.0F, 9.0F, C_VALUE, Opt().center());
        }
    }
    if (!adv && !classic) text(c, "Тази обвивка има още точки — виж РАЗШИРЕН РЕЖИМ.", g.left + 10.0F, g.top + 16.0F, 10.5F, C_AMBER, Opt().bold().maxW(g.width() - 20.0F));

    if (!adv) {
        // ---- the four classic knobs
        static const char* const nm[4] = {"АТАКА", "ЗАТИХВАНЕ", "ДЪРЖАНЕ", "ПУСКАНЕ"};
        static const char* const ds[4] = {"колко бързо стига до най-силното", "колко бавно пада до нивото на ДЪРЖАНЕ", "нивото, на което остава, докато държиш клавиша", "колко бавно угасва, след като пуснеш клавиша"};
        const int ids[4] = {su::envId(e, su::envT(0)), su::envId(e, su::envT(1)), su::envId(e, su::envL(1)), su::envId(e, su::EV_REL)};
        for (int i = 0; i < 4; ++i) {
            const float cx = sec.left + 70.0F + static_cast<float>(i) * 140.0F;
            suKnob(c, cx, sec.top + 240.0F, 20.0F, 132.0F, u, ids[i], nm[i]);
            const auto lines = wrapLines(ds[i], 10.0F, Face::Regular, 128.0F);
            for (std::size_t k = 0; k < lines.size() && k < 2; ++k) text(c, lines[k], cx, sec.top + 322.0F + static_cast<float>(k) * 13.0F, 10.0F, C_HINT, Opt().center());
        }
        // ---- the rest
        const float L = sec.left + 586.0F, R = sec.right;
        const float u3 = (R - L) / 3.0F;
        text(c, "ДОПЪЛНИТЕЛНО", L + 4.0F, sec.top + 54.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
        suKnob(c, L + u3 * 0.5F, sec.top + 100.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::EV_START));
        suKnob(c, L + u3 * 1.5F, sec.top + 100.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::envL(0)), "НИВО ВРЪХ");
        suKnob(c, L + u3 * 2.5F, sec.top + 100.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::EV_CURVE));
        suKnob(c, L + u3 * 0.5F, sec.top + 190.0F, 15.0F, u3 - 4.0F, u, su::envId(e, su::EV_KEYT));
        suSwitch(c, RectF(L + u3 * 1.5F - 36.0F, sec.top + 172.0F, L + u3 * 1.5F + 36.0F, sec.top + 206.0F), u, su::envId(e, su::EV_LOOP), "ПОВТАРЯНЕ", "ДА", "НЕ");
        static const char* const hint[3] = {
            "КРИВА: + = бързо в началото и бавно накрая; − = обратното.",
            "НОТА→ВРЕМЕ: + прави времената по-кратки при високите ноти.",
            "ПОВТАРЯНЕ (ДА): докато държиш клавиша, обвивката се връща и се повтаря."};
        float y = sec.top + 268.0F;
        for (const char* h : hint) {
            const auto lines = wrapLines(h, 10.0F, Face::Regular, R - L);
            for (const auto& ln : lines) { text(c, ln, L + 2.0F, y, 10.0F, C_HINT, Opt()); y += 13.0F; }
            y += 3.0F;
        }
        return;
    }

    // ---- the five points (the whole power: more stages, a sustain point anywhere)
    const float unit = 112.0F;
    for (int p = 0; p < su::kEnvPoints; ++p) {
        const float cx = sec.left + unit * (static_cast<float>(p) + 0.5F);
        const char* role = p == 0 && sus == 0 ? "АТАКА · ДЪРЖАНЕ" : (p == 0 ? "АТАКА" : (p < sus ? "ЗАТИХВАНЕ" : (p == sus ? "ЗАТИХВАНЕ · ДЪРЖАНЕ" : "СЛЕД ДЪРЖАНЕ")));
        const char* timeName = p == 0 ? "АТАКА" : (p <= sus ? "ЗАТИХВАНЕ" : "ВРЕМЕ");
        const char* levelName = (p == sus) ? "НИВО ДЪРЖАНЕ" : (p == 0 ? "НИВО ВРЪХ" : "НИВО");
        text(c, role, cx, sec.top + 166.0F, 10.0F, p == sus ? C_AMBER : C_VALUE, Opt().center().bold().maxW(unit - 4.0F));
        text(c, "точка " + std::to_string(p + 1), cx, sec.top + 179.0F, 9.0F, C_HINT, Opt().center());
        suKnob(c, cx, sec.top + 214.0F, 15.0F, unit - 6.0F, u, su::envId(e, su::envT(p)), timeName);
        suKnob(c, cx, sec.top + 306.0F, 15.0F, unit - 6.0F, u, su::envId(e, su::envL(p)), levelName);
    }
    const float L = sec.left + 586.0F, R = sec.right;
    const float u2 = (R - L) / 3.0F;
    text(c, "ПУСКАНЕ", L + 4.0F, sec.top + 52.0F, 11.0F, C_AMBER, Opt().bold().spacing(0.15F));
    text(c, "колко бавно угасва звукът, след като пуснеш клавиша", L + 74.0F, sec.top + 52.0F, 9.0F, C_HINT, Opt().maxW(R - L - 78.0F));
    suKnob(c, L + u2 * 0.5F, sec.top + 90.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_START));
    suKnob(c, L + u2 * 1.5F, sec.top + 90.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_REL));
    suKnob(c, L + u2 * 2.5F, sec.top + 90.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_CURVE));
    suChoice(c, RectF(L + u2 * 0.5F - 40.0F, sec.top + 168.0F, L + u2 * 0.5F + 40.0F, sec.top + 202.0F), u, su::envId(e, su::EV_SUS), su::kEnvPoints, [](int k) { return "ТОЧКА " + std::to_string(k + 1); }, "ДЪРЖАНЕ ПРИ", 0);
    suKnob(c, L + u2 * 1.5F, sec.top + 186.0F, 15.0F, u2 - 4.0F, u, su::envId(e, su::EV_KEYT));
    suSwitch(c, RectF(L + u2 * 2.5F - 36.0F, sec.top + 168.0F, L + u2 * 2.5F + 36.0F, sec.top + 202.0F), u, su::envId(e, su::EV_LOOP), "ПОВТАРЯНЕ", "ДА", "НЕ");
    text(c, "Обикновената обвивка е: точка 1 = АТАКА, точка 2 = ЗАТИХВАНЕ и ДЪРЖАНЕ.", L, sec.top + 262.0F, 10.0F, C_HINT, Opt().maxW(R - L));
    text(c, "Точките след ДЪРЖАНЕ с време работят след пускане на клавиша,", L, sec.top + 277.0F, 10.0F, C_HINT, Opt().maxW(R - L));
    text(c, "преди последното ПУСКАНЕ.", L, sec.top + 292.0F, 10.0F, C_HINT, Opt().maxW(R - L));
}

// ---------------------------------------------------------------- МОДУЛ.: LFOs, the step modulator and the free matrix
void SilvetonSamplerView::suPageMod(Canvas& c, const RectF& sec, int u) {
    static const char* const tabs[3] = {"LFO", "СТЪПКИ", "МАТРИЦА"};
    for (int i = 0; i < 3; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 116.0F, sec.top, sec.left + static_cast<float>(i) * 116.0F + 110.0F, sec.top + 32.0F);
        stripToggle(c, r, tabs[i], suModTab_ == i, C_AMBER, 12.0F);
        hit(r, [this, i](float, float) { suModTab_ = i; invalidate(); });
    }
    const float* patch = suP(u).data() + 1;
    if (suModTab_ == 0) {
        suLfo_ = std::clamp(suLfo_, 0, su::kLfos - 1);
        const int l = suLfo_;
        for (int i = 0; i < su::kLfos; ++i) {
            const RectF r(sec.left + 380.0F + static_cast<float>(i) * 86.0F, sec.top, sec.left + 380.0F + static_cast<float>(i) * 86.0F + 80.0F, sec.top + 32.0F);
            stripToggle(c, r, "LFO " + std::to_string(i + 1), l == i, C_ACCENT, 12.0F);
            hit(r, [this, i](float, float) { suLfo_ = i; invalidate(); });
        }
        const float unit = sec.width() / 4.0F;
        const auto cx = [&](int col) { return sec.left + unit * (static_cast<float>(col) + 0.5F); };
        suChoice(c, RectF(cx(0) - 60.0F, sec.top + 90.0F, cx(0) + 60.0F, sec.top + 124.0F), u, su::lfoId(l, su::LF_WAVE), su::kLfoWaves, [](int k) { return std::string(su::lfoWaveName(k)); }, "ФОРМА");
        suKnob(c, cx(1), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_RATE));
        suKnob(c, cx(2), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_DELAY));
        suKnob(c, cx(3), sec.top + 106.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_FADE));
        suKnob(c, cx(0), sec.top + 214.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_PHASE));
        suKnob(c, cx(1), sec.top + 214.0F, 16.0F, unit - 6.0F, u, su::lfoId(l, su::LF_KEYF));
        suSwitch(c, RectF(cx(2) - 50.0F, sec.top + 196.0F, cx(2) + 50.0F, sec.top + 230.0F), u, su::lfoId(l, su::LF_UNI), "ЕДНОПОЛЮСЕН (0..+)", "ДА", "НЕ");
        suSwitch(c, RectF(cx(3) - 50.0F, sec.top + 196.0F, cx(3) + 50.0F, sec.top + 230.0F), u, su::lfoId(l, su::LF_FREE), "СЛУЧАЙНО НАЧАЛО", "ДА", "НЕ");
        text(c, "LFO е бавна вълна, която движи регулатор. Накъде отива LFO " + std::to_string(l + 1) + " — в МАТРИЦА (източник LFO " + std::to_string(l + 1) + ").", sec.left + 6.0F, sec.bottom - 14.0F, 12.0F, C_HINT, Opt().maxW(sec.width()));
        return;
    }
    if (suModTab_ == 1) {
        const int len = rI(suV(u, su::stepId(su::ST_LEN)));
        const RectF bars(sec.left, sec.top + 44.0F, sec.left + 600.0F, sec.top + 230.0F);
        fill(c, bars, 8.0F, Color::rgb(24, 27, 32));
        line(c, bars.left, bars.centerY(), bars.right, bars.centerY(), Color::argb(70, 255, 255, 255), 1.0F);
        const float bw = bars.width() / static_cast<float>(su::kStepCount);
        for (int i = 0; i < su::kStepCount; ++i) {
            const float v = (suV(u, su::stepId(su::ST_STEPS + i)) - 0.5F) * 2.0F;
            const float x0 = bars.left + static_cast<float>(i) * bw;
            const bool used = i < len;
            const float y = bars.centerY() - v * (bars.height() * 0.5F - 6.0F);
            fill(c, RectF(x0 + 4.0F, std::min(y, bars.centerY()), x0 + bw - 4.0F, std::max(y, bars.centerY()) + 1.0F), 3.0F, used ? C_ACCENT : Color::rgb(70, 74, 82));
            text(c, std::to_string(i + 1), x0 + bw * 0.5F, bars.bottom + 13.0F, 10.0F, used ? C_KNOB_LABEL : C_HINT, Opt().center());
        }
        const auto setBar = [this, u, bars, bw](float x, float y) {
            const int i = std::clamp(static_cast<int>((x - bars.left) / bw), 0, su::kStepCount - 1);
            const float v = std::clamp((bars.centerY() - y) / (bars.height() * 0.5F - 6.0F), -1.0F, 1.0F);
            suSet(u, su::stepId(su::ST_STEPS + i), 0.5F + 0.5F * v);
        };
        hit(bars, setBar, nullptr, [setBar](float x, float y, bool) { setBar(x, y); });
        const float L = sec.left + 626.0F, unit = (sec.right - L) / 2.0F;
        suKnob(c, L + unit * 0.5F, sec.top + 70.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_LEN));
        suKnob(c, L + unit * 1.5F, sec.top + 70.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_RATE));
        suKnob(c, L + unit * 0.5F, sec.top + 170.0F, 16.0F, unit - 4.0F, u, su::stepId(su::ST_GLIDE));
        static const char* const dirs[4] = {"НАПРЕД", "НАЗАД", "НАПРЕД-НАЗАД", "СЛУЧАЙНО"};
        suChoice(c, RectF(L + unit * 1.5F - 50.0F, sec.top + 152.0F, L + unit * 1.5F + 50.0F, sec.top + 186.0F), u, su::stepId(su::ST_DIR), 4, [](int k) { return std::string(dirs[k]); }, "ПОСОКА");
        text(c, "Докосни или влачи по стълбчетата. Стойностите отиват в МАТРИЦА (източник СТЪПКИ).", sec.left + 6.0F, sec.bottom - 10.0F, 12.0F, C_HINT, Opt().maxW(sec.width()));
        return;
    }
    // the matrix: 16 lines, source -> target, amount
    for (int m = 0; m < su::kMods; ++m) {
        const int col = m / 8, row = m % 8;
        const float x0 = sec.left + static_cast<float>(col) * 456.0F;
        const float y0 = sec.top + 42.0F + static_cast<float>(row) * 39.0F;
        const int src = rI(suV(u, su::modId(m, 0))), dst = rI(suV(u, su::modId(m, 1)));
        const float amt = (suV(u, su::modId(m, 2)) - 0.5F) * 2.0F;
        text(c, std::to_string(m + 1), x0 + 2.0F, y0 + 22.0F, 11.0F, C_HINT, Opt());
        const RectF rs(x0 + 20.0F, y0, x0 + 132.0F, y0 + 32.0F), rd(x0 + 138.0F, y0, x0 + 318.0F, y0 + 32.0F), ra(x0 + 324.0F, y0, x0 + 440.0F, y0 + 32.0F);
        stripToggle(c, rs, su::modSourceName(src), src != 0, C_AMBER, 10.0F);
        stripToggle(c, rd, src == 0 ? std::string("—") : su::destName(dst, patch), src != 0, C_AMBER, 10.0F);
        hit(rs, [this, u, m](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            for (int k = 0; k < su::kModSources; ++k) items.emplace_back(fmtZeroPad(k, 2), su::modSourceName(k));
            showGridPicker("ОТКЪДЕ ИДВА (линия " + std::to_string(m + 1) + ")", items, rI(suV(u, su::modId(m, 0))), std::nullopt, [this, u, m](int k) { if (k >= 0) suSet(u, su::modId(m, 0), static_cast<float>(k)); });
        }, [this, u, m] { suSet(u, su::modId(m, 0), 0.0F); });
        hit(rd, [this, u, m](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            std::vector<int> ids;
            const float* pp = suP(u).data() + 1;
            int cur = 0;
            for (int k = 0; k < su::kDestCount; ++k) {
                if (!su::destUsable(k, pp)) continue;
                if (k == rI(suV(u, su::modId(m, 1)))) cur = static_cast<int>(ids.size());
                items.emplace_back(fmtZeroPad(static_cast<int>(ids.size()), 2), su::destName(k, pp));
                ids.push_back(k);
            }
            showGridPicker("НАКЪДЕ ОТИВА (линия " + std::to_string(m + 1) + ")", items, cur, std::nullopt, [this, u, m, ids](int k) { if (k >= 0 && k < static_cast<int>(ids.size())) suSet(u, su::modId(m, 1), static_cast<float>(ids[static_cast<std::size_t>(k)])); });
        });
        // the amount: a bar from -100 % to +100 %
        fill(c, ra, 6.0F, Color::rgb(30, 33, 39));
        line(c, ra.centerX(), ra.top + 4.0F, ra.centerX(), ra.bottom - 4.0F, Color::argb(80, 255, 255, 255), 1.0F);
        const float half = ra.width() * 0.5F - 4.0F;
        if (amt != 0.0F) fill(c, RectF(std::min(ra.centerX(), ra.centerX() + amt * half), ra.top + 8.0F, std::max(ra.centerX(), ra.centerX() + amt * half), ra.bottom - 8.0F), 3.0F, src != 0 ? C_ACCENT : Color::rgb(90, 94, 102));
        text(c, std::to_string(rI(amt * 100.0F)) + "%", ra.centerX(), ra.centerY() + 4.0F, 11.0F, C_VALUE, Opt().center().bold());
        const auto setAmt = [this, u, m, ra](float x, float) { suSet(u, su::modId(m, 2), 0.5F + 0.5F * std::clamp((x - ra.centerX()) / (ra.width() * 0.5F - 4.0F), -1.0F, 1.0F)); };
        hit(ra, setAmt, [this, u, m] { suSet(u, su::modId(m, 2), 0.5F); }, [setAmt](float x, float y, bool) { setAmt(x, y); });
    }
    text(c, "Всяка линия: ОТКЪДЕ → НАКЪДЕ и колко (-100..+100 %). Двоен допир върху силата = 0.", sec.left + 6.0F, sec.bottom - 8.0F, 11.0F, C_HINT, Opt().maxW(sec.width()));
}

} // namespace silveton::ui::classic
