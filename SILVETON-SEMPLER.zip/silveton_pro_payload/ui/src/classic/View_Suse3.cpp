// SILVETON_SUSE_V1 - the screens of SILVETON SYNTH (part 3: the head of the page, ЛЕГАТО, ТУНИНГ, MIDI, ПРЕСЕТИ + SOUND LAB).
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }

const char* const kNote[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};

const char* const kPageName[12] = {"ОСЦИЛ.", "ВЪЛНИ", "РИСУВАНЕ", "FM / PM", "ФИЗИКА", "ФИЛТРИ", "ОБВИВКИ", "МОДУЛ.", "ЛЕГАТО", "ТУНИНГ", "MIDI", "ПРЕСЕТИ"};

// two short lines for every page: what it is, and what it does to the sound
struct PageInfo { const char* what; const char* does; };
// the full oscillator page (РАЗШИРЕНИ)
const PageInfo kOscAdvInfo = {"ОСЦИЛАТОРЪТ е източник на звук. Имаш 6 — всеки може да е ВЪЛНА, СТРУНА, ДУХОВ, ШУМ…",
                              "Всички включени осцилатори звучат заедно. Тук им даваш вид, сила, височина и свой филтър."};
const PageInfo kPageInfo[12] = {
    {"Звукът се прави от две вълнови форми — А и Б. Избираш ги и колко от всяка да се чува (СМЕС).",
     "ЯРКОСТ го прави по-мек или по-ярък. АТАКА, ЗАТИХВАНЕ, ДЪРЖАНЕ и ПУСКАНЕ казват как започва и угасва."},
    {"Картинки на всички вълни. Докосни една, за да я видиш голяма вдясно.",
     "Формата на вълната е самият тембър: гладка вълна звучи меко, с остри ъгли — по-ярко."},
    {"Тук рисуваш своя вълна с пръст или я нагласяш по хармоници и я запазваш (до 4).",
     "Записаната вълна се появява във ВЪЛНИ и звучи като всяка друга вълна на осцилатор."},
    {"Един осцилатор променя друг (PM, FM, AM, РИНГ…). Избираш кой кого и колко.",
     "При PM и FM повече КОЛКО значи по-богат, по-метален звук (камбани, електрическо пиано)."},
    {"Звук от модел на предмет: струна, духов инструмент или ударно тяло (камбана, плоча).",
     "Звукът се удря или духа и затихва сам. ЗАТИХВАНЕ решава колко дълго ще звучи."},
    {"Филтърът пропуска едни честоти и спира други. ФИЛТЪР А и Б са общи за осцилаторите.",
     "CUTOFF е границата: при LP по-ниско значи по-тъмен звук. РЕЗОНАНС подчертава честотите около нея."},
    {"Обвивката казва как нещо се променя във времето: АТАКА, ЗАТИХВАНЕ, ДЪРЖАНЕ, ПУСКАНЕ.",
     "Води силата на нотата (как започва и как угасва), а може и CUTOFF или тона. Имаш 4 обвивки."},
    {"Модулация: нещо движи регулатор. Има 4 LFO (бавни вълни), 16 СТЪПКИ и МАТРИЦА.",
     "МАТРИЦАТА връзва източник (LFO, обвивка, колело, велосити…) с цел и казва колко силно действа."},
    {"Как се свързват нотите една с друга, колко гласа има, вибрато и тремоло.",
     "Тук са и общата сила, ширината (стерео), кривата на велосити и ДРАЙВ на целия звук."},
    {"Настройка на 12-те ноти — всяка може да е по-висока или по-ниска (в центове).",
     "Така се свири на строеве и скали, които не са равномерни (РАСТ, БАЯТИ), на обикновена клавиатура."},
    {"Вържи копче или колело от клавиатурата към регулатор на звука (8 контролера).",
     "Натискаш ЗАУЧИ и мърдаш копчето; после избираш накъде да действа и колко силно."},
    {"Готови звуци и твоите запазени. Докосни име и звукът се зарежда.",
     "ЗАПАЗИ КАТО… пази текущия звук. SOUND LAB сравнява два звука с еднаква сила."},
};

// the controller of a MIDI route, as a name
std::string ctlSrcName(int s) {
    if (s <= 0) return "ИЗКЛ.";
    if (s <= 128) {
        const int cc = s - 1;
        std::string n = "CC " + std::to_string(cc);
        if (cc == 1) n += " колело"; else if (cc == 2) n += " дишане"; else if (cc == 11) n += " експр.";
        return n;
    }
    return s == su::kCtlSrcAftertouch ? "АФТЪРТЪЧ" : "ПИЧ БЕНД";
}

std::vector<std::string> factoryGroups() {
    std::vector<std::string> g;
    for (int i = 0; i < su::factoryPresetCount(); ++i) {
        const std::string n = su::factoryPresetGroup(i);
        if (std::find(g.begin(), g.end(), n) == g.end()) g.push_back(n);
    }
    return g;
}

}  // namespace

// ---------------------------------------------------------------- the question before the starting sound comes back
void SilvetonSamplerView::suAskReset(int u) {
    showConfirm("НУЛИРАЙ ЗВУКА",
                "Всички настройки на този звук се връщат към начални: един осцилатор със зъбчата вълна, без връзки, модулации и твои вълни. "
                "Ако искаш да го запазиш, първо го запази от страница ПРЕСЕТИ (ЗАПАЗИ КАТО…). Да нулирам ли?",
                "ДА, НУЛИРАЙ", [this, u] {
                    std::vector<float> start(static_cast<std::size_t>(su::kParamCount));
                    su::setDefaults(start.data());
                    suLoadPatch(u, start.data());
                    suCurName_.clear();
                    suPresetPick_ = -1;
                    suGen_ = 0; suSub_ = 0; suEnv_ = 0; suLinkDst_ = 0; suLinkSrc_ = 1; suPickSlot_ = -1;
                    suStatus_ = "Звукът е нулиран — началният звук е върнат";
                    suStatusUntilMs_ = nowMs() + 4000;
                    invalidate();
                }, "НЕ");
}

// ---------------------------------------------------------------- the head: name, summary, meters, reset, two lines about the page, the 12 page keys
void SilvetonSamplerView::suHead(Canvas& c, const RectF& head, int u) {
    const float L = head.left, R = head.right;
    suPage_ = std::clamp(suPage_, 0, kSuPages - 1);
    text(c, "SILVETON SYNTH", L + (engUpper_ >= 0 ? 196.0F : 110.0F), 138.0F, 15.0F, C_VALUE, Opt().bold().maxW(160.0F));
    // the message of the last action takes the place of the summary for a few seconds
    const float sx = L + (engUpper_ >= 0 ? 366.0F : 282.0F), sw = R - sx - 232.0F;
    if (!suStatus_.empty() && nowMs() < suStatusUntilMs_) {
        text(c, suStatus_, sx, 138.0F, 12.0F, C_AMBER, Opt().bold().maxW(sw));
        postInvalidateDelayed(500);
    } else {
        text(c, su::patchSummary(suP(u).data() + 1), sx, 138.0F, 13.0F, C_VALUE, Opt().bold().maxW(sw));
    }
    // what this page is and what it does to the sound
    const PageInfo& info = (suPage_ == 0 && suOscAdv_) ? kOscAdvInfo : kPageInfo[suPage_];
    const bool bank = suPage_ == 0 && !suOscAdv_ && rI(suV(u, su::genId(std::clamp(suGen_, 0, su::kGens - 1), su::GN_METHOD))) == su::M_SAMPLE;   // SILVETON_SUSE_SAMPLE_V1
    text(c, bank ? "ИЗТОЧНИК = БАНКА: семплите на блендата (всеки на своите клавиши) минават през двигателя." : info.what, L + 22.0F, 160.0F, 12.0F, C_VALUE, Opt().maxW(R - L - 22.0F - 232.0F));
    text(c, bank ? "КРИВА и PM ги оформят с избраната вълна; СИЛА, ЯРКОСТ, обвивката и портаментото са техни." : info.does, L + 22.0F, 177.0F, 12.0F, C_KNOB_LABEL, Opt().maxW(R - L - 22.0F - 232.0F));
    // the real meters (the whole sampler, not only this place)
    const Ctrl::AudioStatus a = frameAudioStatus;
    text(c, "ПРОЦЕСОР (всичко)", R - 210.0F, 128.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    text(c, std::to_string(rI(a.cpuLoadPercent)) + " %", R - 22.0F, 128.0F, 13.0F, a.cpuLoadPercent > 80.0F ? C_AMBER : C_VALUE, Opt().right().mono().bold());
    fill(c, RectF(R - 210.0F, 134.0F, R - 22.0F, 139.0F), 2.5F, Color::rgb(28, 31, 36));
    fill(c, RectF(R - 210.0F, 134.0F, R - 210.0F + 188.0F * std::clamp(a.cpuLoadPercent / 100.0F, 0.0F, 1.0F), 139.0F), 2.5F, a.cpuLoadPercent > 80.0F ? C_AMBER : C_ACCENT);
    text(c, "ГЛАСОВЕ (всичко)", R - 210.0F, 156.0F, 10.0F, C_SECTION_TITLE, Opt().bold().spacing(0.15F));
    text(c, std::to_string(a.activeVoices), R - 22.0F, 156.0F, 13.0F, C_VALUE, Opt().right().mono().bold());
    // the button that gives the starting sound back (on every page)
    const RectF rr(R - 210.0F, 161.0F, R - 22.0F, 183.0F);
    stripToggle(c, rr, "НУЛИРАЙ ЗВУКА", false, C_AMBER, 11.0F);
    hit(rr, [this, u](float, float) { suAskReset(u); });
    // the pages shown now: the oscillator, the waves, the drawing and FM / PM (the other pages are hidden, not removed)
    static constexpr int kShownPages[] = {0, 1, 2, 3};
    constexpr int kShown = static_cast<int>(sizeof(kShownPages) / sizeof(kShownPages[0]));
    const float kw = (R - L - 44.0F - 6.0F * static_cast<float>(kShown - 1)) / static_cast<float>(kShown);
    for (int k = 0; k < kShown; ++k) {
        const int page = kShownPages[k];
        const float x0 = L + 22.0F + static_cast<float>(k) * (kw + 6.0F);
        const RectF kr(x0, 188.0F, x0 + kw, 228.0F);
        stripToggle(c, kr, kPageName[page], suPage_ == page, C_ACCENT, 10.5F);
        hit(kr, [this, page](float, float) { suPage_ = page; suPickSlot_ = -1; invalidate(); });
    }
}

// ---------------------------------------------------------------- the page that is open
void SilvetonSamplerView::drawSuse(Canvas& c, const RectF& sec, int u) {
    suCheckSession();
    // MIDI learn: the next controller that moves is taken
    if (suMidiLearn_ >= 0) {
        const Ctrl::MidiStatus m = frameMidiStatus;
        if (m.activitySerial != suMidiSerial_) {
            suMidiSerial_ = m.activitySerial;
            const int st = m.status & 0xF0;
            int src = -1;
            if (st == 0xB0 && m.data1 < 120) src = m.data1 + 1;   // CC 0..119 (120 and up are channel-mode messages)
            else if (st == 0xD0) src = su::kCtlSrcAftertouch;
            else if (st == 0xE0) src = su::kCtlSrcBend;
            if (src >= 0) {
                suSet(u, su::ctlId(suMidiLearn_, su::CT_SRC), static_cast<float>(src));
                suStatus_ = "Заучено: " + ctlSrcName(src);
                suStatusUntilMs_ = nowMs() + 3000;
                suMidiLearn_ = -1;
            }
        }
        if (suMidiLearn_ >= 0) postInvalidateDelayed(120);
    }
    suPage_ = std::clamp(suPage_, 0, kSuPages - 1);
    switch (suPage_) {
        case 0: suPageOsc(c, sec, u); break;
        case 1: suPageGallery(c, sec, u); break;
        case 2: suPageWaves(c, sec, u); break;
        case 3: suPageLinks(c, sec, u); break;
        case 4: suPagePhysics(c, sec, u); break;
        case 5: suPageFilters(c, sec, u); break;
        case 6: suPageEnvelopes(c, sec, u); break;
        case 7: suPageMod(c, sec, u); break;
        case 8: suPageLegato(c, sec, u); break;
        case 9: suPageTuning(c, sec, u); break;
        case 10: suPageMidi(c, sec, u); break;
        default: suPagePresets(c, sec, u); break;
    }
    suDrawDropList(c, sec);   // SILVETON_OSC_ROWS_V1: an open dropdown list lies over the page
}

void SilvetonSamplerView::suMidiLearnOn(int ctl) {
    suMidiLearn_ = ctl;
    suMidiSerial_ = frameMidiStatus.activitySerial;
    suStatus_ = "Движи контролера на клавиатурата…";
    suStatusUntilMs_ = nowMs() + 15000;
    invalidate();
}

// ---------------------------------------------------------------- ЛЕГАТО: how the notes meet, vibrato, the output
void SilvetonSamplerView::suPageLegato(Canvas& c, const RectF& sec, int u) {
    const float unit = sec.width() / 8.0F;
    const auto cx = [&](int col) { return sec.left + unit * (static_cast<float>(col) + 0.5F); };
    text(c, "НОТИ И ЗВУК", sec.left + 4.0F, sec.top + 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    suSwitch(c, RectF(cx(0) - 44.0F, sec.top + 36.0F, cx(0) + 44.0F, sec.top + 70.0F), u, su::G_RETRIG, "ОБВИВКИ", "ОТНАЧАЛО", "ПРОДЪЛЖАВАТ");
    suSwitch(c, RectF(cx(1) - 44.0F, sec.top + 36.0F, cx(1) + 44.0F, sec.top + 70.0F), u, su::G_KEEP_RES, "СТРУНА · ТРЪБА", "ПАЗИ СЕ", "ОТНАЧАЛО");
    suKnob(c, cx(2), sec.top + 54.0F, 16.0F, unit - 4.0F, u, su::G_VOICES);
    suKnob(c, cx(3), sec.top + 54.0F, 16.0F, unit - 4.0F, u, su::G_LEVEL);
    suKnob(c, cx(4), sec.top + 54.0F, 16.0F, unit - 4.0F, u, su::G_WIDTH);
    suKnob(c, cx(5), sec.top + 54.0F, 16.0F, unit - 4.0F, u, su::G_VEL_CURVE);
    suKnob(c, cx(6), sec.top + 54.0F, 16.0F, unit - 4.0F, u, su::G_DRIVE);
    text(c, "ВИБРАТО И ТРЕМОЛО", sec.left + 4.0F, sec.top + 134.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    suKnob(c, cx(0), sec.top + 176.0F, 16.0F, unit - 4.0F, u, su::G_VIB_RATE);
    suKnob(c, cx(1), sec.top + 176.0F, 16.0F, unit - 4.0F, u, su::G_VIB_DEPTH);
    suKnob(c, cx(2), sec.top + 176.0F, 16.0F, unit - 4.0F, u, su::G_VIB_DELAY);
    suSwitch(c, RectF(cx(3) - 44.0F, sec.top + 158.0F, cx(3) + 44.0F, sec.top + 192.0F), u, su::G_VIB_WHEEL, "ВИБРАТО", "КОЛЕЛО", "ВИНАГИ");
    suKnob(c, cx(4), sec.top + 176.0F, 16.0F, unit - 4.0F, u, su::G_TREM_RATE);
    suKnob(c, cx(5), sec.top + 176.0F, 16.0F, unit - 4.0F, u, su::G_TREM_DEPTH);
    const float ty = sec.top + 266.0F;
    const float tw = sec.width() - 8.0F;
    text(c, "POLY / MONO / LEGATO и ПОРТАМЕНТО (SILVETON / KRONOS) се избират над страниците — те са на цялото място.", sec.left + 4.0F, ty, 12.0F, C_HINT, Opt().maxW(tw));
    text(c, "ОБВИВКИ (само при LEGATO): ОТНАЧАЛО = обвивките почват пак с всяка нова нота; ПРОДЪЛЖАВАТ = те не се прекъсват.", sec.left + 4.0F, ty + 22.0F, 12.0F, C_HINT, Opt().maxW(tw));
    text(c, "СТРУНА · ТРЪБА (ПАЗИ СЕ): струната, тръбата и ударното тяло продължават да звучат при нова нота, вместо да започнат отначало.", sec.left + 4.0F, ty + 44.0F, 12.0F, C_HINT, Opt().maxW(tw));
    text(c, "ВИБРАТО (КОЛЕЛО): колелото (CC1) отваря вибрато; (ВИНАГИ): вибрато през цялото време. БРОЙ ГЛАСОВЕ: най-много ноти на това място (1–24).", sec.left + 4.0F, ty + 66.0F, 12.0F, C_HINT, Opt().maxW(tw));
}

// ---------------------------------------------------------------- ТУНИНГ: 12 notes, each can be a little higher or lower
void SilvetonSamplerView::suPageTuning(Canvas& c, const RectF& sec, int u) {
    const int root = std::clamp(rI(suV(u, su::tuneId(su::TN_ROOT))), 0, 11);
    const bool on = suV(u, su::tuneId(su::TN_ON)) >= 0.5F;
    suSwitch(c, RectF(sec.left, sec.top + 4.0F, sec.left + 110.0F, sec.top + 38.0F), u, su::tuneId(su::TN_ON), "ТУНИНГ", "ВКЛЮЧЕН", "ИЗКЛЮЧЕН");
    suChoice(c, RectF(sec.left + 128.0F, sec.top + 4.0F, sec.left + 208.0F, sec.top + 38.0F), u, su::tuneId(su::TN_ROOT), 12, [](int k) { return std::string(kNote[k]); }, "ОСНОВНА НОТА");
    suKnob(c, sec.left + 262.0F, sec.top + 22.0F, 16.0F, 110.0F, u, su::tuneId(su::TN_MASTER));
    text(c, "ГОТОВИ:", sec.left + 372.0F, sec.top + 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    static const char* const pn[3] = {"РАВНОМЕРЕН", "РАСТ (на C)", "БАЯТИ (на D)"};
    for (int i = 0; i < 3; ++i) {
        const RectF r(sec.left + 372.0F + static_cast<float>(i) * 178.0F, sec.top + 20.0F, sec.left + 372.0F + static_cast<float>(i) * 178.0F + 170.0F, sec.top + 54.0F);
        stripToggle(c, r, pn[i], false, C_AMBER, 12.0F);
        hit(r, [this, u, i](float, float) {
            // a block over TN_ON .. the 12 notes: the master tune stays as it is
            std::vector<float> v(15, 0.5F);
            v[static_cast<std::size_t>(su::TN_ON)] = i == 0 ? 0.0F : 1.0F;
            v[static_cast<std::size_t>(su::TN_ROOT)] = i == 2 ? 2.0F : 0.0F;
            v[static_cast<std::size_t>(su::TN_MASTER)] = suV(u, su::tuneId(su::TN_MASTER));
            if (i == 1) { v[static_cast<std::size_t>(su::TN_CENTS + 4)] = 0.25F; v[static_cast<std::size_t>(su::TN_CENTS + 11)] = 0.25F; }
            if (i == 2) v[static_cast<std::size_t>(su::TN_CENTS + 2)] = 0.25F;
            suBlock(u, su::tuneId(0), v);
        });
    }
    // the 12 notes above the root
    const RectF area(sec.left, sec.top + 84.0F, sec.right, sec.bottom - 44.0F);
    fill(c, area, 8.0F, Color::rgb(24, 27, 32));
    const float bw = area.width() / 12.0F;
    const float mid = area.centerY();
    line(c, area.left + 4.0F, mid, area.right - 4.0F, mid, Color::argb(90, 255, 255, 255), 1.0F);
    const float half = area.height() * 0.5F - 24.0F;
    for (int d = 0; d < 12; ++d) {
        const float x0 = area.left + static_cast<float>(d) * bw;
        const float cents = (suV(u, su::tuneId(su::TN_CENTS + d)) - 0.5F) * 200.0F;
        const float y = mid - cents / 100.0F * half;
        const bool changed = std::fabs(cents) > 0.5F;
        fill(c, RectF(x0 + 8.0F, std::min(y, mid), x0 + bw - 8.0F, std::max(y, mid) + 1.0F), 3.0F, !on ? Color::rgb(70, 74, 82) : (changed ? C_AMBER : C_ACCENT));
        text(c, kNote[(root + d) % 12], x0 + bw * 0.5F, area.top + 15.0F, 13.0F, d == 0 ? C_AMBER : C_VALUE, Opt().center().bold());
        text(c, (cents > 0.5F ? "+" : std::string()) + std::to_string(rI(cents)), x0 + bw * 0.5F, area.bottom - 7.0F, 11.0F, changed ? C_VALUE : C_HINT, Opt().center().mono());
    }
    const auto setBar = [this, u, area, bw, mid, half](float x, float y) {
        const int d = std::clamp(static_cast<int>((x - area.left) / bw), 0, 11);
        float cents = std::clamp((mid - y) / half * 100.0F, -100.0F, 100.0F);
        cents = std::nearbyint(cents);
        if (std::fabs(cents) <= 3.0F) cents = 0.0F;   // sticks to the normal note
        suSet(u, su::tuneId(su::TN_CENTS + d), 0.5F + cents / 200.0F);
    };
    hit(area, setBar, nullptr, [setBar](float x, float y, bool) { setBar(x, y); });
    text(c, "Всяка нота може да е по-висока или по-ниска до 100 цента (четвърттон = 50). Докосни или влачи стълб; близо до средата = 0.",
         sec.left + 4.0F, sec.bottom - 24.0F, 11.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
    text(c, "РАСТ и БАЯТИ са приблизителни — на 12 ноти, със снижен четвърттон.", sec.left + 4.0F, sec.bottom - 8.0F, 11.0F, C_HINT, Opt().maxW(sec.width() - 8.0F));
}

// ---------------------------------------------------------------- MIDI: 8 free controller routes, with learn
void SilvetonSamplerView::suPageMidi(Canvas& c, const RectF& sec, int u) {
    suCtl_ = std::clamp(suCtl_, 0, su::kCtls - 1);
    const float* patch = suP(u).data() + 1;
    // the routes
    text(c, "КОНТРОЛЕРИ", sec.left + 4.0F, sec.top + 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    for (int k = 0; k < su::kCtls; ++k) {
        const RectF r(sec.left, sec.top + 24.0F + static_cast<float>(k) * 34.0F, sec.left + 290.0F, sec.top + 54.0F + static_cast<float>(k) * 34.0F);
        const int s = rI(suV(u, su::ctlId(k, su::CT_SRC)));
        int targets = 0;
        for (int t = 0; t < 3; ++t) if (suV(u, su::ctlId(k, su::CT_A1 + 2 * t)) != 0.5F) ++targets;
        stripToggle(c, r, std::to_string(k + 1) + "   " + ctlSrcName(s) + (s > 0 ? "   · " + std::to_string(targets) + (targets == 1 ? " цел" : " цели") : std::string()), suCtl_ == k, C_ACCENT, 12.0F);
        hit(r, [this, k](float, float) { suCtl_ = k; invalidate(); });
    }
    // the chosen route
    const int k = suCtl_;
    const float L = sec.left + 316.0F, R = sec.right;
    text(c, "КОНТРОЛЕР " + std::to_string(k + 1), L, sec.top + 14.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.2F));
    const int s = rI(suV(u, su::ctlId(k, su::CT_SRC)));
    const RectF rs(L, sec.top + 24.0F, L + 190.0F, sec.top + 58.0F);
    stripToggle(c, rs, ctlSrcName(s), s > 0, C_AMBER, 13.0F);
    text(c, "ОТКЪДЕ ИДВА", rs.centerX(), rs.bottom + 15.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F));
    hit(rs, [this, u, k, s](float, float) {
        std::vector<std::pair<std::string, std::string>> items;
        for (int i = 0; i <= su::kCtlSrcBend; ++i) items.emplace_back(fmtZeroPad(i, 3), ctlSrcName(i));
        showGridPicker("КОНТРОЛЕР " + std::to_string(k + 1) + " — откъде идва", items, s, std::nullopt, [this, u, k](int i) { if (i >= 0) suSet(u, su::ctlId(k, su::CT_SRC), static_cast<float>(i)); });
    }, [this, u, k] { suSet(u, su::ctlId(k, su::CT_SRC), 0.0F); });
    const bool learning = suMidiLearn_ == k;
    const RectF rl(L + 200.0F, sec.top + 24.0F, L + 290.0F, sec.top + 58.0F);
    stripToggle(c, rl, learning ? "СЛУШАМ…" : "ЗАУЧИ", learning, C_AMBER, 12.0F);
    hit(rl, [this, k, learning](float, float) { if (learning) { suMidiLearn_ = -1; invalidate(); } else suMidiLearnOn(k); });
    static const char* const curveName[3] = {"ПРАВА", "БАВНО НАЧАЛО", "БЪРЗО НАЧАЛО"};
    suChoice(c, RectF(L + 306.0F, sec.top + 24.0F, L + 446.0F, sec.top + 58.0F), u, su::ctlId(k, su::CT_CURVE), 3, [](int i) { return std::string(curveName[i]); }, "КРИВА");
    // the three targets
    for (int t = 0; t < 3; ++t) {
        const float y0 = sec.top + 92.0F + static_cast<float>(t) * 52.0F;
        const int dst = rI(suV(u, su::ctlId(k, su::CT_D1 + 2 * t)));
        const float amt = (suV(u, su::ctlId(k, su::CT_A1 + 2 * t)) - 0.5F) * 2.0F;
        text(c, std::to_string(t + 1), L + 2.0F, y0 + 22.0F, 12.0F, C_HINT, Opt());
        const RectF rd(L + 20.0F, y0, L + 320.0F, y0 + 34.0F), ra(L + 330.0F, y0, R, y0 + 34.0F);
        stripToggle(c, rd, "→ " + su::destName(dst, patch), amt != 0.0F, C_AMBER, 11.0F);
        hit(rd, [this, u, k, t](float, float) {
            std::vector<std::pair<std::string, std::string>> items;
            std::vector<int> ids;
            const float* pp = suP(u).data() + 1;
            int cur = 0;
            const int now = rI(suV(u, su::ctlId(k, su::CT_D1 + 2 * t)));
            for (int d = 0; d < su::kDestCount; ++d) {
                if (!su::destUsable(d, pp)) continue;
                if (d == now) cur = static_cast<int>(ids.size());
                items.emplace_back(fmtZeroPad(static_cast<int>(ids.size()), 2), su::destName(d, pp));
                ids.push_back(d);
            }
            showGridPicker("КОНТРОЛЕР " + std::to_string(k + 1) + " — накъде отива (" + std::to_string(t + 1) + ")", items, cur, std::nullopt,
                           [this, u, k, t, ids](int i) { if (i >= 0 && i < static_cast<int>(ids.size())) suSet(u, su::ctlId(k, su::CT_D1 + 2 * t), static_cast<float>(ids[static_cast<std::size_t>(i)])); });
        });
        fill(c, ra, 6.0F, Color::rgb(30, 33, 39));
        line(c, ra.centerX(), ra.top + 4.0F, ra.centerX(), ra.bottom - 4.0F, Color::argb(80, 255, 255, 255), 1.0F);
        const float half = ra.width() * 0.5F - 4.0F;
        if (amt != 0.0F) fill(c, RectF(std::min(ra.centerX(), ra.centerX() + amt * half), ra.top + 8.0F, std::max(ra.centerX(), ra.centerX() + amt * half), ra.bottom - 8.0F), 3.0F, s > 0 ? C_ACCENT : Color::rgb(90, 94, 102));
        text(c, std::to_string(rI(amt * 100.0F)) + "%", ra.centerX(), ra.centerY() + 4.0F, 11.0F, C_VALUE, Opt().center().bold());
        const auto setAmt = [this, u, k, t, ra](float x, float) { suSet(u, su::ctlId(k, su::CT_A1 + 2 * t), 0.5F + 0.5F * std::clamp((x - ra.centerX()) / (ra.width() * 0.5F - 4.0F), -1.0F, 1.0F)); };
        hit(ra, setAmt, [this, u, k, t] { suSet(u, su::ctlId(k, su::CT_A1 + 2 * t), 0.5F); }, [setAmt](float x, float y, bool) { setAmt(x, y); });
    }
    // what really arrives
    const Ctrl::MidiStatus m = frameMidiStatus;
    std::string last = "още нищо";
    const int st = m.status & 0xF0;
    if (m.activitySerial != 0) {
        if (st == 0xB0) last = "CC " + std::to_string(m.data1) + " = " + std::to_string(m.data2);
        else if (st == 0x90) last = "нота " + std::to_string(m.data1) + " сила " + std::to_string(m.data2);
        else if (st == 0x80) last = "нота " + std::to_string(m.data1) + " пусната";
        else if (st == 0xD0) last = "афтъртач = " + std::to_string(m.data1);
        else if (st == 0xE0) last = "pitch bend " + std::to_string(m.data1 + 128 * m.data2 - 8192);
        else last = "статус " + std::to_string(m.status);
    }
    text(c, "ПОСЛЕДНО ОТ КЛАВИАТУРАТА:  " + last, L, sec.top + 262.0F, 13.0F, C_VALUE, Opt().bold().maxW(R - L));
    text(c, "Колело (CC1), дишане (CC2), експресия (CC11) и афтъртач са готови", L, sec.top + 288.0F, 11.0F, C_HINT, Opt().maxW(R - L));
    text(c, "като източници в МОДУЛ. → МАТРИЦА. Тук вързваш други контролери.", L, sec.top + 304.0F, 11.0F, C_HINT, Opt().maxW(R - L));
}

// ---------------------------------------------------------------- ПРЕСЕТИ: factory and own, files, SOUND LAB
void SilvetonSamplerView::suPagePresets(Canvas& c, const RectF& sec, int u) {
    const std::vector<std::string> groups = factoryGroups();
    const int nGroups = static_cast<int>(groups.size());
    suPresetGroup_ = std::clamp(suPresetGroup_, 0, nGroups);
    const bool userGroup = suPresetGroup_ == nGroups;
    if (!suUserListLoaded_) { suUserList_ = sampler.suseUserPresets(); suUserListLoaded_ = true; }
    // the groups: two rows
    const int perRow = (nGroups + 2) / 2;   // the last key = МОИ
    const float gw = (560.0F - static_cast<float>(perRow - 1) * 5.0F) / static_cast<float>(perRow);
    for (int g = 0; g <= nGroups; ++g) {
        const int row = g / perRow, col = g % perRow;
        const RectF r(sec.left + static_cast<float>(col) * (gw + 5.0F), sec.top + static_cast<float>(row) * 36.0F, sec.left + static_cast<float>(col) * (gw + 5.0F) + gw, sec.top + static_cast<float>(row) * 36.0F + 30.0F);
        stripToggle(c, r, g == nGroups ? std::string("МОИ") : groups[static_cast<std::size_t>(g)], suPresetGroup_ == g, g == nGroups ? C_AMBER : C_ACCENT, 11.0F);
        hit(r, [this, g](float, float) { suPresetGroup_ = g; suPresetPick_ = -1; suListPage_ = 0; invalidate(); });
    }
    // the presets of the group
    std::vector<int> factoryIdx;
    std::vector<std::string> names;
    if (userGroup) names = suUserList_;
    else for (int i = 0; i < su::factoryPresetCount(); ++i) if (groups[static_cast<std::size_t>(suPresetGroup_)] == su::factoryPresetGroup(i)) { factoryIdx.push_back(i); names.emplace_back(su::factoryPresetName(i)); }
    constexpr int kPerPage = 15;
    const int pages = std::max(1, (static_cast<int>(names.size()) + kPerPage - 1) / kPerPage);
    suListPage_ = std::clamp(suListPage_, 0, pages - 1);
    const float cw = (560.0F - 2.0F * 8.0F) / 3.0F;
    const float gy = sec.top + 80.0F;
    if (names.empty()) text(c, userGroup ? "Още нямаш свои пресети. Направи звук и натисни ЗАПАЗИ КАТО…" : "Няма пресети.", sec.left + 6.0F, gy + 24.0F, 14.0F, C_HINT, Opt().maxW(540.0F));
    for (int n = 0; n < kPerPage; ++n) {
        const int idx = suListPage_ * kPerPage + n;
        if (idx >= static_cast<int>(names.size())) break;
        const int row = n / 3, col = n % 3;
        const RectF r(sec.left + static_cast<float>(col) * (cw + 8.0F), gy + static_cast<float>(row) * 40.0F, sec.left + static_cast<float>(col) * (cw + 8.0F) + cw, gy + static_cast<float>(row) * 40.0F + 34.0F);
        stripToggle(c, r, names[static_cast<std::size_t>(idx)], suPresetPick_ == idx, C_ACCENT, 12.0F);
        hit(r, [this, u, idx, userGroup, factoryIdx, names](float, float) {
            std::vector<float> patch(static_cast<std::size_t>(su::kParamCount));
            if (userGroup) {
                const auto err = sampler.suseLoadPreset(names[static_cast<std::size_t>(idx)], patch);
                if (err) { suStatus_ = *err; suStatusUntilMs_ = nowMs() + 5000; invalidate(); return; }
            } else su::factoryPreset(factoryIdx[static_cast<std::size_t>(idx)], patch.data());
            suPresetPick_ = idx;
            suCurName_ = names[static_cast<std::size_t>(idx)];
            suLoadPatch(u, patch.data());
            suStatus_ = "Зареден: " + suCurName_;
            suStatusUntilMs_ = nowMs() + 3000;
        });
    }
    if (pages > 1) {
        const RectF pl(sec.left, sec.top + 290.0F, sec.left + 80.0F, sec.top + 322.0F), pr(sec.left + 90.0F, sec.top + 290.0F, sec.left + 170.0F, sec.top + 322.0F);
        stripToggle(c, pl, "◀", false, C_AMBER, 14.0F);
        stripToggle(c, pr, "▶", false, C_AMBER, 14.0F);
        hit(pl, [this](float, float) { --suListPage_; invalidate(); });
        hit(pr, [this](float, float) { ++suListPage_; invalidate(); });
        text(c, "стр. " + std::to_string(suListPage_ + 1) + " / " + std::to_string(pages), sec.left + 184.0F, sec.top + 311.0F, 12.0F, C_KNOB_LABEL, Opt());
    }
    if (!suCurName_.empty()) text(c, "последно зареден: " + suCurName_, sec.left + 6.0F, sec.bottom - 8.0F, 11.0F, C_HINT, Opt().maxW(540.0F));
    // the right side: files
    const float X = sec.left + 584.0F, W = sec.right - X, hw = (W - 6.0F) / 2.0F;
    const auto flash = [this](const std::string& msg) { suStatus_ = msg; suStatusUntilMs_ = nowMs() + 5000; invalidate(); };
    const RectF rsave(X, sec.top, X + W, sec.top + 34.0F);
    stripToggle(c, rsave, "ЗАПАЗИ КАТО…", false, C_ACCENT, 13.0F);
    hit(rsave, [this, u, flash](float, float) {
        showTextPage("ИМЕ НА ПРЕСЕТА", suCurName_.empty() ? std::string("МОЙ ПРЕСЕТ") : suCurName_, [this, u, flash](const std::string& nm) {
            const std::vector<float>& cur = suP(u);
            const std::vector<float> patch(cur.begin() + 1, cur.begin() + 1 + su::kParamCount);
            const auto err = sampler.suseSavePreset(nm, patch);
            if (err) { flash(*err); return; }
            suCurName_ = nm;
            suUserList_ = sampler.suseUserPresets();
            flash("Запазен пресет: " + nm);
        });
    });
    const RectF rdel(X, sec.top + 42.0F, X + hw, sec.top + 76.0F), rexp(X + hw + 6.0F, sec.top + 42.0F, X + W, sec.top + 76.0F);
    const bool canDel = userGroup && suPresetPick_ >= 0 && suPresetPick_ < static_cast<int>(suUserList_.size());
    stripToggle(c, rdel, "ИЗТРИЙ ИЗБРАНИЯ", false, canDel ? C_AMBER : Color::rgb(70, 74, 82), 11.0F);
    hit(rdel, [this, canDel, flash](float, float) {
        if (!canDel) { flash("Избери един от МОИ пресети, за да го изтриеш."); return; }
        const std::string nm = suUserList_[static_cast<std::size_t>(suPresetPick_)];
        showConfirm("ИЗТРИЙ ПРЕСЕТ", "Да изтрия ли \"" + nm + "\"? Не може да се върне.", "ДА", [this, nm, flash] {
            const auto err = sampler.suseDeletePreset(nm);
            suUserList_ = sampler.suseUserPresets();
            suPresetPick_ = -1;
            flash(err ? *err : "Изтрит: " + nm);
        });
    });
    stripToggle(c, rexp, "ИЗНЕСИ ВСИЧКИ МОИ", false, C_AMBER, 11.0F);
    hit(rexp, [this, flash](float, float) {
        std::string file;
        const auto err = sampler.suseExportBank(file);
        flash(err ? *err : "Изнесени в: " + file);
    });
    const RectF rimp(X, sec.top + 84.0F, X + W, sec.top + 118.0F);
    stripToggle(c, rimp, "ВНЕСИ ОТ ПАПКА IMPORT", false, C_AMBER, 11.0F);
    hit(rimp, [this, flash](float, float) {
        int count = 0;
        const auto err = sampler.suseImportBanks(count);
        suUserList_ = sampler.suseUserPresets();
        flash(err ? *err : "Внесени пресети: " + std::to_string(count));
    });
    // SOUND LAB: A / B with the same loudness
    text(c, "SOUND LAB — сравни два звука с еднаква сила", X, sec.top + 142.0F, 11.0F, C_SECTION_TITLE, Opt().bold().spacing(0.12F).maxW(W));
    const RectF ma(X, sec.top + 152.0F, X + hw, sec.top + 184.0F), mb(X + hw + 6.0F, sec.top + 152.0F, X + W, sec.top + 184.0F);
    stripToggle(c, ma, "ЗАПОМНИ ТУК → A", suLabA_.has_value(), C_AMBER, 11.0F);
    stripToggle(c, mb, "ЗАПОМНИ ТУК → B", suLabB_.has_value(), C_AMBER, 11.0F);
    const auto remember = [this, u](int slot) {
        const std::vector<float>& cur = suP(u);
        std::vector<float> patch(cur.begin() + 1, cur.begin() + 1 + su::kParamCount);
        const float loud = su::referenceLoudnessDb(patch.data());
        if (slot == 1) { suLabA_ = patch; suLabLoudA_ = loud; } else { suLabB_ = patch; suLabLoudB_ = loud; }
        suLabNow_ = 0;
        suStatus_ = std::string(slot == 1 ? "A" : "B") + " е запомнен · " + dbText(loud);
        suStatusUntilMs_ = nowMs() + 4000;
        invalidate();
    };
    hit(ma, [remember](float, float) { remember(1); });
    hit(mb, [remember](float, float) { remember(2); });
    // how much a slot is lowered so that both sound as loud as the quieter one
    const auto trimDb = [this](int slot) {
        if (!suLabMatch_ || !suLabA_ || !suLabB_) return 0.0F;
        return (slot == 1 ? suLabLoudA_ : suLabLoudB_) - std::min(suLabLoudA_, suLabLoudB_);
    };
    const RectF pa(X, sec.top + 192.0F, X + hw, sec.top + 226.0F), pb(X + hw + 6.0F, sec.top + 192.0F, X + W, sec.top + 226.0F);
    stripToggle(c, pa, "СЛУШАМ A", suLabNow_ == 1, C_ACCENT, 12.0F);
    stripToggle(c, pb, "СЛУШАМ B", suLabNow_ == 2, C_ACCENT, 12.0F);
    const auto audition = [this, u, flash, trimDb](int slot) {
        const auto& stored = slot == 1 ? suLabA_ : suLabB_;
        if (!stored) { flash(std::string("Първо запомни ") + (slot == 1 ? "A" : "B") + "."); return; }
        std::vector<float> v = *stored;
        const float trim = trimDb(slot);
        if (trim > 0.0F) {
            const float db = su::mapLin(v[su::G_LEVEL], su::rng::kLevelDbLo, su::rng::kLevelDbHi) - trim;
            v[su::G_LEVEL] = std::clamp(su::unmapLin(db, su::rng::kLevelDbLo, su::rng::kLevelDbHi), 0.0F, 1.0F);
        }
        suLoadPatch(u, v.data());
        suLabNow_ = slot;
    };
    hit(pa, [audition](float, float) { audition(1); });
    hit(pb, [audition](float, float) { audition(2); });
    const RectF rm(X, sec.top + 234.0F, X + hw, sec.top + 268.0F), rk(X + hw + 6.0F, sec.top + 234.0F, X + W, sec.top + 268.0F);
    stripToggle(c, rm, suLabMatch_ ? "ЕДНАКВА СИЛА: ДА" : "ЕДНАКВА СИЛА: НЕ", suLabMatch_, C_AMBER, 11.0F);
    hit(rm, [this](float, float) { suLabMatch_ = !suLabMatch_; invalidate(); });
    stripToggle(c, rk, "ОСТАВИ ТОЗИ", false, C_AMBER, 11.0F);
    hit(rk, [this, u, trimDb, flash](float, float) {
        if (suLabNow_ == 0) { flash("Първо чуй A или B."); return; }
        const float trim = trimDb(suLabNow_);
        if (trim > 0.0F) {   // give back what was taken away for the compare
            const float db = su::mapLin(suV(u, su::G_LEVEL), su::rng::kLevelDbLo, su::rng::kLevelDbHi) + trim;
            suSet(u, su::G_LEVEL, std::clamp(su::unmapLin(db, su::rng::kLevelDbLo, su::rng::kLevelDbHi), 0.0F, 1.0F));
        }
        suLabNow_ = 0;
        flash("Оставен. Силата е върната каквато си я направил.");
    });
    if (suLabA_ || suLabB_) {
        std::string t = "A: " + (suLabA_ ? dbText(suLabLoudA_) : std::string("—")) + "     B: " + (suLabB_ ? dbText(suLabLoudB_) : std::string("—"));
        text(c, t, X, sec.top + 288.0F, 12.0F, C_VALUE, Opt().mono().maxW(W));
        if (suLabNow_ != 0 && trimDb(suLabNow_) > 0.0F) text(c, std::string(suLabNow_ == 1 ? "A" : "B") + " е свален с " + dbText(trimDb(suLabNow_)), X, sec.top + 306.0F, 11.0F, C_AMBER, Opt().maxW(W));
        text(c, "Силата е мерена с една дълга нота C4.", X, sec.top + 322.0F, 10.0F, C_HINT, Opt().maxW(W));
    } else {
        text(c, "Направи звук, запомни го в A; промени го, запомни го в B; после слушай A и B.", X, sec.top + 288.0F, 11.0F, C_HINT, Opt().maxW(W));
    }
    text(c, "Папка: " + sampler.suseFolder(), X, sec.bottom - 8.0F, 9.0F, C_HINT, Opt().maxW(W));
}

} // namespace silveton::ui::classic
