// SILVETON_NEW_LOOK_V1: the SILVETON SYNTH editor is drawn in the new look (black wells, blue values and curves, amber = on, dark lists); every control and touch is the same as before.
// SILVETON_OSC_ROWS_V1 (Цветомир, 02.11.2026) - the start screen of SILVETON SYNTH in rows, like the sound pages of a workstation:
// boxes with a title, a label and a field on every row, a dropdown that opens a short list under its field, and three tabs at the
// bottom: ОСЦИЛАТОР (the source of the sound: БАНКА = the recordings of the blend, ВЪЛНИ = the waves; the waves, the curve / PM,
// octave / semitones / fine), ВИСОЧИНА (octave and transpose of the Upper, pitch bend, portamento, vibrato) and СИЛА (the envelope
// of the loudness with its picture, level, velocity). Every control is one number of the patch or of the Upper - nothing is new sound.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace su = ::silveton::sampler::suse;
namespace sv = ::silveton::sampler;

namespace {
int rI(float v) { return static_cast<int>(std::nearbyint(v)); }
constexpr float kRow = 32.0F;     // one row of a box
constexpr float kBoxPad = 10.0F;
}  // namespace

// ---------------------------------------------------------------- the pieces
// a value field: a dark box with the text (and a small ▼ when it opens a list); tap = the action, right button = the start value
void SilvetonSamplerView::suField(Canvas& c, const RectF& r, const std::string& t, std::function<void()> tap, std::function<void()> reset, bool arrow) {
    nlLcd(c, r, 6.0F);   // SILVETON_NEW_LOOK_V1: a black value box
    float tx = r.left + 8.0F;
    if (arrow) { text(c, "▼", tx, r.centerY() + 4.0F, 10.0F, NL_BLUE, Opt().bold()); tx += 16.0F; }
    text(c, t, tx, r.centerY() + 4.5F, 12.5F, NL_VALUE, Opt().bold().maxW(r.right - tx - 6.0F));
    hit(r, [tap](float, float) { if (tap) tap(); }, reset);
}

// a slider in a strip: drag along it = the value, tap = the value at the finger, right button = the start value
void SilvetonSamplerView::suSlider(Canvas& c, const RectF& r, const std::string& label, float v01, const std::string& shown, std::function<void(float)> set, std::function<void()> reset) {
    nlLcd(c, r, 6.0F);   // SILVETON_NEW_LOOK_V1: a black well with a blue fill
    fill(c, RectF(r.left + 1.0F, r.top + 1.0F, r.left + 1.0F + (r.width() - 2.0F) * std::clamp(v01, 0.0F, 1.0F), r.bottom - 1.0F), 6.0F, Color::argb(150, 51, 160, 255));
    text(c, label, r.left + 8.0F, r.centerY() + 4.0F, 10.5F, NL_TXT, Opt().bold().spacing(0.1F).maxW(r.width() * 0.62F));
    text(c, shown, r.right - 8.0F, r.centerY() + 4.0F, 11.5F, NL_VALUE, Opt().right().mono().maxW(r.width() * 0.38F));
    const auto at = [r, set](float x, float) { set(std::clamp((x - r.left) / std::max(1.0F, r.width()), 0.0F, 1.0F)); };
    hit(r, at, reset, [at](float x, float y, bool) { at(x, y); });
}

// the field of a dropdown: tap opens the list under it (drawn after the page, see suDrawDropList); the list closes with a choice or a tap outside
void SilvetonSamplerView::suDropdown(Canvas& c, const RectF& r, int id, const std::vector<std::string>& items, int cur, std::function<void(int)> pick, float size) {
    const bool open = suDropOpen_ == id;
    nlLcd(c, r, 6.0F);   // SILVETON_NEW_LOOK_V1: a black value box, a blue frame while its list is open
    if (open) strokeRR(c, r, 6.0F, NL_BLUE, 1.5F);
    text(c, "▼", r.left + 8.0F, r.centerY() + 4.0F, 10.0F, NL_BLUE, Opt().bold());
    const int k = std::clamp(cur, 0, std::max(0, static_cast<int>(items.size()) - 1));
    text(c, items.empty() ? std::string("—") : items[static_cast<std::size_t>(k)], r.left + 24.0F, r.centerY() + 4.5F, size, NL_VALUE, Opt().bold().maxW(r.width() - 30.0F));
    hit(r, [this, id](float, float) { suDropOpen_ = suDropOpen_ == id ? -1 : id; invalidate(); });
    if (open) { suDrop_.r = r; suDrop_.items = items; suDrop_.cur = k; suDrop_.pick = std::move(pick); suDrop_.have = true; }
}

void SilvetonSamplerView::suDrawDropList(Canvas& c, const RectF& sec) {
    if (suDropOpen_ < 0) return;
    if (!suDrop_.have) { suDropOpen_ = -1; return; }   // the field is not on this screen any more
    suDrop_.have = false;
    const SuDrop d = suDrop_;
    // a tap anywhere else closes the list (this hit comes after every hit of the page, so it wins)
    hit(RectF(0.0F, 0.0F, 4000.0F, 4000.0F), [this](float, float) { suDropOpen_ = -1; invalidate(); });
    const float h = 30.0F;
    const int n = static_cast<int>(d.items.size());
    float top = d.r.bottom + 2.0F;
    if (top + h * static_cast<float>(n) > sec.bottom + 40.0F) top = std::max(sec.top, d.r.top - 2.0F - h * static_cast<float>(n));   // no room below: above the field
    const RectF list(d.r.left, top, std::max(d.r.right, d.r.left + 150.0F), top + h * static_cast<float>(n));
    fill(c, RectF(list.left + 3.0F, list.top + 4.0F, list.right + 3.0F, list.bottom + 4.0F), 6.0F, Color::argb(120, 0, 0, 0));
    fillV(c, list, 8.0F, Color::rgb(43, 47, 53), Color::rgb(28, 31, 35));   // SILVETON_NEW_LOOK_V1: a dark list, the chosen line is blue
    strokeRR(c, list, 8.0F, Color::rgb(8, 9, 11), 1.0F);
    for (int i = 0; i < n; ++i) {
        const RectF r(list.left, list.top + h * static_cast<float>(i), list.right, list.top + h * static_cast<float>(i + 1));
        const bool sel = i == d.cur;
        if (sel) fill(c, RectF(r.left + 3.0F, r.top + 2.0F, r.right - 3.0F, r.bottom - 2.0F), 5.0F, NL_BLUE);
        text(c, d.items[static_cast<std::size_t>(i)], r.left + 14.0F, r.centerY() + 5.0F, 13.0F, sel ? Color::WHITE : NL_TXT, Opt().bold().maxW(r.width() - 20.0F));
        const auto pick = d.pick;
        hit(r, [this, pick, i](float, float) { suDropOpen_ = -1; if (pick) pick(i); invalidate(); });
    }
}

// ---------------------------------------------------------------- the start screen
void SilvetonSamplerView::suPageOscSimple(Canvas& c, const RectF& sec, int u) {
    suGen_ = std::clamp(suGen_, 0, su::kGens - 1);
    const int g = suGen_;
    // ---- which oscillator (there are six; every one has its own source, waves and level)
    text(c, "ОСЦИЛАТОР:", sec.left + 2.0F, sec.top + 17.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.15F));
    const float kw = (sec.width() - 110.0F - 5.0F * 6.0F) / 6.0F;
    for (int i = 0; i < su::kGens; ++i) {
        const float x0 = sec.left + 110.0F + static_cast<float>(i) * (kw + 6.0F);
        const RectF r(x0, sec.top, x0 + kw, sec.top + 26.0F);
        const int mi = rI(suV(u, su::genId(i, su::GN_METHOD)));
        const std::string nm = mi == su::M_SAMPLE ? std::string("БАНКА") : (mi == su::M_WAVE ? std::string("ВЪЛНИ") : std::string(su::methodName(mi)));
        stripToggle(c, r, std::to_string(i + 1) + " · " + nm, suGen_ == i, C_ACCENT, 11.0F);
        hit(r, [this, i](float, float) { suGen_ = i; suDropOpen_ = -1; invalidate(); });
    }
    // ---- the tab
    const RectF area(sec.left, sec.top + 34.0F, sec.right, sec.bottom - 36.0F);
    switch (std::clamp(suOscTab_, 0, 2)) {
        case 0: suOscTabOsc(c, area, u, g); break;
        case 1: suOscTabPitch(c, area, u, g); break;
        default: suOscTabAmp(c, area, u, g); break;
    }
    // ---- the keys at the bottom: the three tabs, then PRESETS / RESET / ADVANCED
    const float by0 = sec.bottom - 30.0F, by1 = sec.bottom - 4.0F;
    static const char* const tabs[3] = {"ОСЦИЛАТОР", "ВИСОЧИНА", "СИЛА"};
    for (int i = 0; i < 3; ++i) {
        const RectF r(sec.left + static_cast<float>(i) * 148.0F, by0, sec.left + static_cast<float>(i) * 148.0F + 140.0F, by1);
        stripToggle(c, r, tabs[i], suOscTab_ == i, C_AMBER, 12.0F);
        hit(r, [this, i](float, float) { suOscTab_ = i; suDropOpen_ = -1; invalidate(); });
    }
    const RectF kp(sec.right - 396.0F, by0, sec.right - 286.0F, by1), kr(sec.right - 278.0F, by0, sec.right - 188.0F, by1), ke(sec.right - 180.0F, by0, sec.right, by1);
    stripToggle(c, kp, "PRESETS", false, C_ACCENT, 12.0F);
    stripToggle(c, kr, "RESET", false, C_AMBER, 12.0F);
    stripToggle(c, ke, "ADVANCED (всичко)", false, C_ACCENT, 11.0F);
    hit(kp, [this](float, float) { suPage_ = 11; suDropOpen_ = -1; invalidate(); });
    hit(kr, [this, u](float, float) { suDropOpen_ = -1; suAskReset(u); });
    hit(ke, [this](float, float) { suOscAdv_ = true; suDropOpen_ = -1; invalidate(); });
}

// ---------------------------------------------------------------- tab ОСЦИЛАТОР
void SilvetonSamplerView::suOscTabOsc(Canvas& c, const RectF& a, int u, int g) {
    const float* patch = suP(u).data() + 1;
    const int m = rI(suV(u, su::genId(g, su::GN_METHOD)));
    const bool blendUpper = u < 7;   // only an Upper of a blend has recordings
    const auto box = [&](const RectF& r, const std::string& title) {
        nlSub(c, r);   // SILVETON_NEW_LOOK_V1: an inset well with a blue title
        text(c, title, r.left + 12.0F, r.top + 14.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.2F));
    };
    const auto label = [&](float x, float y, const std::string& s) { text(c, s, x, y + 4.5F, 11.5F, NL_TXT, Opt().bold().spacing(0.08F)); };

    // ---- box 1: the oscillator - its source, its waves, its pitch
    const RectF b1(a.left, a.top + 6.0F, a.right, a.top + 196.0F);
    box(b1, "ОСЦИЛАТОР " + std::to_string(g + 1));
    const float x0 = b1.left + kBoxPad, y1 = b1.top + 26.0F;
    // row 1: ИЗТОЧНИК (the dropdown: БАНКА / ВЪЛНИ / ИЗКЛ.) · СИЛА · ЯРКОСТ
    label(x0, y1 + kRow * 0.5F, "ИЗТОЧНИК:");
    std::vector<std::string> src;
    std::vector<int> srcMethod;
    if (blendUpper) { src.push_back("БАНКА"); srcMethod.push_back(su::M_SAMPLE); }
    src.push_back("ВЪЛНИ"); srcMethod.push_back(su::M_WAVE);
    src.push_back("ИЗКЛ."); srcMethod.push_back(su::M_OFF);
    int cur = static_cast<int>(src.size()) - 1;
    for (std::size_t i = 0; i < srcMethod.size(); ++i) if (srcMethod[i] == m) cur = static_cast<int>(i);
    const bool other = m != su::M_OFF && m != su::M_WAVE && m != su::M_SAMPLE;
    if (other) { src.insert(src.begin(), su::methodName(m)); srcMethod.insert(srcMethod.begin(), m); cur = 0; }
    suDropdown(c, RectF(x0 + 96.0F, y1, x0 + 276.0F, y1 + kRow), 100 + g, src, cur, [this, u, g, srcMethod](int k) {
        if (k < 0 || k >= static_cast<int>(srcMethod.size())) return;
        const int mm = srcMethod[static_cast<std::size_t>(k)];
        if (mm != rI(suV(u, su::genId(g, su::GN_METHOD)))) suSet(u, su::genId(g, su::GN_METHOD), static_cast<float>(mm));
    });
    const float sx = x0 + 300.0F, sw = (b1.right - kBoxPad - sx - 8.0F) / 2.0F;
    {
        const int id = su::genId(g, su::GN_LEVEL);
        const float v = std::clamp(suV(u, id), 0.0F, 1.0F);
        suSlider(c, RectF(sx, y1, sx + sw, y1 + kRow), "СИЛА", v, su::dispText(su::paramDisp(id, patch), v),
                 [this, u, id](float nv) { suSet(u, id, nv); }, [this, u, id] { suSet(u, id, suDefault(u, id)); });
    }
    if (m == su::M_WAVE || m == su::M_SAMPLE) {
        const int id = su::genId(g, su::GN_F0 + 2);
        const float v = std::clamp(suV(u, id), 0.0F, 1.0F);
        suSlider(c, RectF(sx + sw + 8.0F, y1, b1.right - kBoxPad, y1 + kRow), "ЯРКОСТ", v, su::dispText(su::paramDisp(id, patch), v),
                 [this, u, id](float nv) { suSet(u, id, nv); }, [this, u, id] { suSet(u, id, suDefault(u, id)); });
    }
    // rows 2 and 3: what the source needs
    const float y2 = y1 + kRow + 10.0F, y3 = y2 + kRow + 10.0F;
    if (m == su::M_WAVE) {
        const auto waveField = [&](float fx, float fy, float fw, int slot) {
            const int sel = rI(suV(u, su::genId(g, slot == 0 ? su::GN_SEL1 : su::GN_SEL2)));
            label(fx, fy + kRow * 0.5F, slot == 0 ? "ВЪЛНА А:" : "ВЪЛНА Б:");
            const RectF pic(fx + 84.0F, fy + 2.0F, fx + 84.0F + 64.0F, fy + kRow - 2.0F);
            nlLcd(c, pic, 4.0F);
            float pts[su::kDrawLen];
            su::waveChoicePoints(sel, patch, pts);
            const float amp = pic.height() * 0.5F - 2.0F, dx = (pic.width() - 6.0F) / static_cast<float>(su::kDrawLen - 1);
            for (int i = 0; i + 1 < su::kDrawLen; ++i)
                line(c, pic.left + 3.0F + dx * static_cast<float>(i), pic.centerY() - std::clamp(pts[i], -1.0F, 1.0F) * amp,
                     pic.left + 3.0F + dx * static_cast<float>(i + 1), pic.centerY() - std::clamp(pts[i + 1], -1.0F, 1.0F) * amp, NL_BLUE, 1.5F);
            suField(c, RectF(pic.right + 6.0F, fy, fx + fw, fy + kRow), std::string(su::waveName(sel)) + "  ▶",
                    [this, g, slot, sel] { suPickGen_ = g; suPickSlot_ = slot; suPick_ = sel; suPage_ = 1; suDropOpen_ = -1; invalidate(); }, nullptr, false);
        };
        const float half = (b1.width() - 2.0F * kBoxPad - 12.0F) / 2.0F;
        waveField(x0, y2, half, 0);
        waveField(x0 + half + 12.0F, y2, half, 1);
        const int morphId = su::genId(g, su::GN_F0);
        const float morph = std::clamp(suV(u, morphId), 0.0F, 1.0F);
        const int pc = rI(morph * 100.0F);
        suSlider(c, RectF(x0, y3, x0 + half, y3 + kRow), "СМЕС А → Б", morph, pc == 0 ? std::string("само А") : (pc == 100 ? std::string("само Б") : "А " + std::to_string(100 - pc) + " % · Б " + std::to_string(pc) + " %"),
                 [this, u, morphId](float nv) { suSet(u, morphId, nv); }, [this, u, morphId] { suSet(u, morphId, 0.0F); });
        const RectF gal(x0 + half + 12.0F, y3, b1.right - kBoxPad, y3 + kRow);
        stripToggle(c, gal, "КАРТИНКИ НА ВСИЧКИ ВЪЛНИ  ·  РИСУВАНЕ", false, C_ACCENT, 11.0F);
        hit(gal, [this, g](float, float) { suPickGen_ = g; suPickSlot_ = -1; suPage_ = 1; suDropOpen_ = -1; invalidate(); });
    } else if (m == su::M_SAMPLE) {
        const int idWave = su::genId(g, su::GN_SEL1), idCurve = su::genId(g, su::GN_F0), idPm = su::genId(g, su::GN_F0 + 1), idRatio = su::genId(g, su::GN_F0 + 3);
        const int sel = rI(suV(u, idWave));
        label(x0, y2 + kRow * 0.5F, "СЕМПЛИТЕ НА БЛЕНДАТА, ПРЕЗ ВЪЛНА:");
        const RectF pic(x0 + 262.0F, y2 + 2.0F, x0 + 262.0F + 64.0F, y2 + kRow - 2.0F);
        nlLcd(c, pic, 4.0F);
        float pts[su::kDrawLen];
        su::waveChoicePoints(sel, patch, pts);
        const float amp = pic.height() * 0.5F - 2.0F, dx = (pic.width() - 6.0F) / static_cast<float>(su::kDrawLen - 1);
        for (int i = 0; i + 1 < su::kDrawLen; ++i)
            line(c, pic.left + 3.0F + dx * static_cast<float>(i), pic.centerY() - std::clamp(pts[i], -1.0F, 1.0F) * amp,
                 pic.left + 3.0F + dx * static_cast<float>(i + 1), pic.centerY() - std::clamp(pts[i + 1], -1.0F, 1.0F) * amp, NL_BLUE, 1.5F);
        suField(c, RectF(pic.right + 6.0F, y2, pic.right + 6.0F + 250.0F, y2 + kRow), std::string(su::waveName(sel)) + "  ▶",
                [this, u, idWave] { suPickWave(u, [this, u, idWave](int k) { suSet(u, idWave, static_cast<float>(k)); }, "ВЪЛНА ЗА СЕМПЛИТЕ — избери"); }, nullptr, false);
        const RectF dr(pic.right + 262.0F, y2, b1.right - kBoxPad, y2 + kRow);
        stripToggle(c, dr, "РИСУВАЙ Я", false, C_ACCENT, 11.0F);
        hit(dr, [this, g, sel](float, float) {
            suPickGen_ = g;
            if (sel >= su::kWaveDrawn0 && sel < su::kWaveFile0) suWaveSlot_ = sel - su::kWaveDrawn0;
            suPage_ = 2; suDropOpen_ = -1; invalidate();
        });
        const float third = (b1.width() - 2.0F * kBoxPad - 16.0F) / 3.0F;
        const float cur2 = std::clamp(suV(u, idCurve), 0.0F, 1.0F), pm = std::clamp(suV(u, idPm), 0.0F, 1.0F), rt = std::clamp(suV(u, idRatio), 0.0F, 1.0F);
        suSlider(c, RectF(x0, y3, x0 + third, y3 + kRow), "КРИВА", cur2, std::to_string(rI(cur2 * 100.0F)) + " %",
                 [this, u, idCurve](float v) { suSet(u, idCurve, v); }, [this, u, idCurve] { suSet(u, idCurve, 0.0F); });
        suSlider(c, RectF(x0 + third + 8.0F, y3, x0 + 2.0F * third + 8.0F, y3 + kRow), "PM ОТ ВЪЛНАТА", pm, std::to_string(rI(pm * 100.0F)) + " %",
                 [this, u, idPm](float v) { suSet(u, idPm, v); }, [this, u, idPm] { suSet(u, idPm, 0.0F); });
        suSlider(c, RectF(x0 + 2.0F * third + 16.0F, y3, b1.right - kBoxPad, y3 + kRow), "PM ОТНОШЕНИЕ", rt, fmtFixed(static_cast<double>(su::mapLog(rt, su::rng::kRatioLo, su::rng::kRatioHi)), 2) + " x",
                 [this, u, idRatio](float v) { suSet(u, idRatio, v); }, [this, u, idRatio] { suSet(u, idRatio, su::unmapLog(1.0F, su::rng::kRatioLo, su::rng::kRatioHi)); });
    } else if (m == su::M_OFF) {
        text(c, "Този осцилатор е изключен. Избери ИЗТОЧНИК: " + std::string(blendUpper ? "БАНКА (семплите на блендата) или " : "") + "ВЪЛНИ.", x0, y2 + 20.0F, 12.5F, NL_TXT, Opt().maxW(b1.width() - 2.0F * kBoxPad));
    } else {
        text(c, std::string("Методът ") + su::methodName(m) + " се настройва в ADVANCED. Тук: ИЗТОЧНИК го сменя с БАНКА / ВЪЛНИ.", x0, y2 + 20.0F, 12.0F, NL_TXT, Opt().maxW(b1.width() - 2.0F * kBoxPad));
    }
    // row 4: the pitch of this oscillator - octave, semitones, fine
    const float y4 = y3 + kRow + 10.0F;
    if (m != su::M_OFF) {
        const auto whole = [&](float fx, const char* name, int off, int lo, int hi) {
            const int id = su::genId(g, off);
            const int v = rI(suV(u, id));
            label(fx, y4 + kRow * 0.5F, name);
            const RectF mr(fx + 108.0F, y4, fx + 140.0F, y4 + kRow), vr(fx + 144.0F, y4, fx + 204.0F, y4 + kRow), pr(fx + 208.0F, y4, fx + 240.0F, y4 + kRow);
            stripToggle(c, mr, "−", false, C_AMBER, 14.0F);
            stripToggle(c, pr, "+", false, C_AMBER, 14.0F);
            suField(c, vr, (v > 0 ? "+" : "") + std::to_string(v), [this, u, id, v, lo, hi, name] {
                showNumber(name, static_cast<float>(v), static_cast<float>(lo), static_cast<float>(hi), 0, [this, u, id](float x) { suSet(u, id, std::round(x)); });
            }, [this, u, id] { suSet(u, id, 0.0F); }, false);
            hit(mr, [this, u, id, v, lo](float, float) { suSet(u, id, static_cast<float>(std::max(lo, v - 1))); });
            hit(pr, [this, u, id, v, hi](float, float) { suSet(u, id, static_cast<float>(std::min(hi, v + 1))); });
        };
        whole(x0, "ОКТАВА:", su::GN_OCT, -3, 3);
        whole(x0 + 262.0F, "ПОЛУТОНОВЕ:", su::GN_SEMI, -24, 24);
        {
            const int id = su::genId(g, su::GN_FINE);
            const float v = std::clamp(suV(u, id), 0.0F, 1.0F);
            label(x0 + 524.0F, y4 + kRow * 0.5F, "ФИНО:");
            suSlider(c, RectF(x0 + 580.0F, y4, b1.right - kBoxPad, y4 + kRow), "", v, su::dispText(su::paramDisp(id, patch), v),
                     [this, u, id](float nv) { suSet(u, id, nv); }, [this, u, id] { suSet(u, id, 0.5F); });
        }
    }

    // ---- box 2: the notes at once, and where legato / portamento / release are
    const RectF b2(a.left, b1.bottom + 10.0F, a.right, a.bottom);
    box(b2, "НОТИ");
    const float yb = b2.top + 26.0F;
    {
        const int v = std::clamp(rI(suV(u, su::G_VOICES)), 1, 24);
        label(x0, yb + kRow * 0.5F, "НОТИ НАВЕДНЪЖ:");
        suField(c, RectF(x0 + 140.0F, yb, x0 + 300.0F, yb + kRow), std::to_string(v) + (blendUpper ? "  (на семпъл)" : ""),
                [this, u, v] { showNumber("НОТИ НАВЕДНЪЖ (1..24)", static_cast<float>(v), 1.0F, 24.0F, 0, [this, u](float x) { suSet(u, su::G_VOICES, std::round(x)); }); },
                [this, u] { suSet(u, su::G_VOICES, 24.0F); }, false);
        text(c, "ПОЛИ / МОНО / ЛЕГАТО са горе в СВИРЕНЕ  ·  портаментото и пич бендът са в ВИСОЧИНА  ·  атака и отпускане са в СИЛА",
             x0 + 316.0F, yb + kRow * 0.5F + 4.0F, 10.5F, NL_TXT2, Opt().maxW(b2.right - x0 - 326.0F));
    }
}

// ---------------------------------------------------------------- tab ВИСОЧИНА
void SilvetonSamplerView::suOscTabPitch(Canvas& c, const RectF& a, int u, int g) {
    (void)g;
    const auto box = [&](const RectF& r, const std::string& title) {
        nlSub(c, r);   // SILVETON_NEW_LOOK_V1: an inset well with a blue title
        text(c, title, r.left + 12.0F, r.top + 14.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.2F));
    };
    const auto label = [&](float x, float y, const std::string& s) { text(c, s, x, y + 4.5F, 11.5F, NL_TXT, Opt().bold().spacing(0.08F)); };
    const auto sgn = [](int v) { return v > 0 ? "+" + std::to_string(v) : std::to_string(v); };
    const auto stOpt = upperStates[static_cast<std::size_t>(u)];
    const std::vector<float> up = uParams(u);
    const auto upv = [&up](int id, float dflt) { return id >= 0 && id < static_cast<int>(up.size()) ? up[static_cast<std::size_t>(id)] : dflt; };
    const float x0 = a.left + kBoxPad;

    // ---- box 1: the pitch of the Upper (octave, transpose) and the pitch bend of the engine
    const RectF b1(a.left, a.top + 6.0F, a.right, a.top + 110.0F);
    box(b1, "ВИСОЧИНА");
    const float y1 = b1.top + 26.0F, y2 = y1 + kRow + 10.0F;
    if (stOpt) {
        const UpperState st = *stOpt;
        const auto whole = [&](float fx, float fy, const char* name, int v, int lo, int hi, std::function<void(int)> set) {
            label(fx, fy + kRow * 0.5F, name);
            const RectF mr(fx + 124.0F, fy, fx + 156.0F, fy + kRow), vr(fx + 160.0F, fy, fx + 220.0F, fy + kRow), pr(fx + 224.0F, fy, fx + 256.0F, fy + kRow);
            stripToggle(c, mr, "−", false, C_AMBER, 14.0F);
            stripToggle(c, pr, "+", false, C_AMBER, 14.0F);
            suField(c, vr, sgn(v), [this, name, v, lo, hi, set] { showNumber(name, static_cast<float>(v), static_cast<float>(lo), static_cast<float>(hi), 0, [set](float x) { set(rI(x)); }); },
                    [set] { set(0); }, false);
            hit(mr, [set, v, lo](float, float) { set(std::max(lo, v - 1)); });
            hit(pr, [set, v, hi](float, float) { set(std::min(hi, v + 1)); });
        };
        whole(x0, y1, "ОКТАВА:", st.octave, -4, 4, [this, st](int v) { UpperState cur = currentUpper(st); cur.octave = static_cast<std::int8_t>(std::clamp(v, -4, 4)); commitTune(cur); });
        whole(x0 + 290.0F, y1, "ТРАНСПОЗИЦИЯ:", st.transpose, -12, 12, [this, st](int v) { UpperState cur = currentUpper(st); cur.transpose = static_cast<std::int8_t>(std::clamp(v, -12, 12)); commitTune(cur); });
        text(c, "за целия Upper, всички осцилатори", x0 + 580.0F, y1 + kRow * 0.5F + 4.0F, 10.5F, NL_TXT2, Opt().maxW(b1.right - x0 - 590.0F));
    }
    {   // pitch bend up / down: -1 = OFF, 0 = as the Upper, 1..24 semitones
        const auto bend = [&](float fx, const char* name, int id) {
            const int v = std::clamp(rI(suV(u, id)), -1, 24);
            label(fx, y2 + kRow * 0.5F, name);
            const std::string shown = v < 0 ? std::string("ИЗКЛ.") : (v == 0 ? std::string("КАТО UPPER (" + std::to_string(stOpt ? static_cast<int>(stOpt->pitchBendRange) : 2) + " полут.)") : std::to_string(v) + " полутона");
            suField(c, RectF(fx + 124.0F, y2, fx + 400.0F, y2 + kRow), shown,
                    [this, u, id, v, name] { showNumber(std::string(name) + " (-1 = ИЗКЛ., 0 = като Upper, 1..24 полутона)", static_cast<float>(v), -1.0F, 24.0F, 0, [this, u, id](float x) { suSet(u, id, std::round(x)); }); },
                    [this, u, id] { suSet(u, id, 0.0F); }, false);
        };
        bend(x0, "ПИЧ БЕНД НАГОРЕ:", su::E_BEND_UP_ID);
        bend(x0 + 440.0F, "НАДОЛУ:", su::E_BEND_DOWN_ID);
    }

    // ---- box 2: portamento (the Upper's own: SILVETON or KRONOS way)
    const RectF b2(a.left, b1.bottom + 8.0F, a.right, b1.bottom + 8.0F + 104.0F);
    box(b2, "ПОРТАМЕНТО");
    const float p1 = b2.top + 26.0F, p2 = p1 + kRow + 10.0F;
    if (stOpt) {
        const UpperState st = *stOpt;
        const int pmode = std::clamp(rI(upv(42, 0.0F)), 0, 3);
        const bool silv = pmode != 1;
        const float porta = portamentoUiValue(st.portamentoSec);
        const float kt = upv(45, 40.0F);
        const bool on = silv ? porta > 0.0F : kt > 0.0F;
        const RectF onR(x0, p1, x0 + 110.0F, p1 + kRow);
        stripToggle(c, onR, on ? "ВКЛЮЧЕНО" : "ИЗКЛЮЧЕНО", on, C_AMBER, 11.0F);
        hit(onR, [this, u, st, silv, on](float, float) {
            if (silv) { UpperState n = currentUpper(st); n.portamentoSec = on ? 0.0F : portamentoSecondsFromUi(35.0F); commitTune(n); }
            else setUParam(u, 45, on ? 0.0F : 40.0F);
            invalidate();
        });
        label(x0 + 124.0F, p1 + kRow * 0.5F, "НАЧИН:");
        suDropdown(c, RectF(x0 + 190.0F, p1, x0 + 330.0F, p1 + kRow), 300, {"SILVETON", "KRONOS"}, silv ? 0 : 1, [this, u](int k) { setUParam(u, 42, k == 1 ? 1.0F : 0.0F); invalidate(); });
        if (silv) {
            suSlider(c, RectF(x0 + 346.0F, p1, b2.right - kBoxPad, p1 + kRow), "ВРЕМЕ", porta / 100.0F, porta <= 0.0F ? std::string("ИЗКЛ.") : fmtFixed(static_cast<double>(porta), 0) + " ms",
                     [this, st](float v) { UpperState n = currentUpper(st); n.portamentoSec = portamentoSecondsFromUi(v * 100.0F); commitTune(n); },
                     [this, st] { UpperState n = currentUpper(st); n.portamentoSec = 0.0F; commitTune(n); });
            const float bal = static_cast<float>(sampler.portaBalance()), nearV = static_cast<float>(sampler.portaNear());
            const float half = (b2.width() - 2.0F * kBoxPad - 12.0F) / 2.0F;
            suSlider(c, RectF(x0, p2, x0 + half, p2 + kRow), "БАЛАНС", (bal - 3.0F) / 37.0F, std::to_string(rI(bal)),
                     [this](float v) { sampler.setPortaBalance(rI(3.0F + v * 37.0F)); invalidate(); }, [this] { sampler.setPortaBalance(11); invalidate(); });
            suSlider(c, RectF(x0 + half + 12.0F, p2, b2.right - kBoxPad, p2 + kRow), "БЛИЗКИ НОТИ (ms)", nearV / 400.0F, std::to_string(rI(nearV)) + " ms",
                     [this](float v) { sampler.setPortaNear(rI(v * 400.0F)); invalidate(); }, [this] { sampler.setPortaNear(90); invalidate(); });
        } else {
            suSlider(c, RectF(x0 + 346.0F, p1, b2.right - kBoxPad, p1 + kRow), "ВРЕМЕ", kt / 127.0F, kt <= 0.0F ? std::string("ИЗКЛ.") : std::to_string(rI(kt)),
                     [this, u](float v) { setUParam(u, 45, std::nearbyint(v * 127.0F)); }, [this, u] { setUParam(u, 45, 0.0F); });
            const bool fing = upv(43, 0.0F) >= 0.5F, rate = upv(44, 0.0F) >= 0.5F;
            const RectF fr(x0, p2, x0 + 200.0F, p2 + kRow);
            stripToggle(c, fr, fing ? "С ПРЪСТИ: ДА" : "С ПРЪСТИ: НЕ", fing, C_AMBER, 11.0F);
            hit(fr, [this, u, fing](float, float) { setUParam(u, 43, fing ? 0.0F : 1.0F); invalidate(); });
            text(c, "ДА = само когато държиш предишната нота", x0 + 210.0F, p2 + kRow * 0.5F + 4.0F, 10.5F, NL_TXT2, Opt().maxW(300.0F));
            suDropdown(c, RectF(x0 + 520.0F, p2, x0 + 700.0F, p2 + kRow), 301, {"ПО ВРЕМЕ", "ПО СКОРОСТ"}, rate ? 1 : 0, [this, u](int k) { setUParam(u, 44, k == 1 ? 1.0F : 0.0F); invalidate(); });
        }
    }

    // ---- box 3: vibrato (the engine's own)
    const RectF b3(a.left, b2.bottom + 8.0F, a.right, a.bottom);
    box(b3, "ВИБРАТО");
    const float v1 = b3.top + 26.0F;
    {
        const float* patch = suP(u).data() + 1;
        const float third = (b3.width() - 2.0F * kBoxPad - 16.0F - 150.0F) / 2.0F;
        const auto sl = [&](float fx, float fw, const char* name, int id) {
            const float v = std::clamp(suV(u, id), 0.0F, 1.0F);
            suSlider(c, RectF(fx, v1, fx + fw, v1 + kRow), name, v, su::dispText(su::paramDisp(id, patch), v),
                     [this, u, id](float nv) { suSet(u, id, nv); }, [this, u, id] { suSet(u, id, suDefault(u, id)); });
        };
        sl(x0, third, "ДЪЛБОЧИНА", su::G_VIB_DEPTH);
        sl(x0 + third + 8.0F, third, "СКОРОСТ", su::G_VIB_RATE);
        const bool wheel = suV(u, su::G_VIB_WHEEL) >= 0.5F;
        const RectF wr(b3.right - kBoxPad - 150.0F, v1, b3.right - kBoxPad, v1 + kRow);
        stripToggle(c, wr, wheel ? "ОТ КОЛЕЛОТО" : "ВИНАГИ", wheel, C_AMBER, 11.0F);
        hit(wr, [this, u, wheel](float, float) { suSet(u, su::G_VIB_WHEEL, wheel ? 0.0F : 1.0F); });
    }
}

// ---------------------------------------------------------------- tab СИЛА
void SilvetonSamplerView::suOscTabAmp(Canvas& c, const RectF& a, int u, int g) {
    const float* patch = suP(u).data() + 1;
    const auto box = [&](const RectF& r, const std::string& title) {
        nlSub(c, r);   // SILVETON_NEW_LOOK_V1: an inset well with a blue title
        text(c, title, r.left + 12.0F, r.top + 14.0F, 11.0F, NL_BLUE, Opt().bold().spacing(0.2F));
    };
    const float x0 = a.left + kBoxPad;
    const int envSel = rI(suV(u, su::genId(g, su::GN_AMPENV)));
    if (envSel <= 0) {
        const RectF b(a.left, a.top + 6.0F, a.right, a.top + 110.0F);
        box(b, "ОБВИВКА НА СИЛАТА");
        text(c, "Осцилатор " + std::to_string(g + 1) + " няма обвивка на силата - звучи постоянно, докато държиш клавиша.", x0, b.top + 46.0F, 12.5F, NL_TXT, Opt().maxW(b.width() - 2.0F * kBoxPad));
        const RectF kb(x0, b.top + 60.0F, x0 + 260.0F, b.top + 92.0F);
        stripToggle(c, kb, "ВКЛЮЧИ ОБВИВКА 1", false, C_ACCENT, 12.0F);
        hit(kb, [this, u, g](float, float) { suSet(u, su::genId(g, su::GN_AMPENV), 1.0F); });
        return;
    }
    const int e = std::clamp(envSel - 1, 0, su::kEnvs - 1);
    // ---- the picture of the envelope (start, the points up to the sustain one, the release)
    const RectF b1(a.left, a.top + 6.0F, a.right, a.top + 100.0F);
    box(b1, "ОБВИВКА " + std::to_string(envSel) + " · СИЛА НА ОСЦИЛАТОР " + std::to_string(g + 1));
    {
        const RectF gr(x0, b1.top + 24.0F, b1.right - kBoxPad, b1.bottom - 8.0F);
        nlLcd(c, gr, 6.0F);
        const int sus = std::clamp(rI(suV(u, su::envId(e, su::EV_SUS))), 0, su::kEnvPoints - 1);
        float t[su::kEnvPoints], l[su::kEnvPoints];
        float total = 0.0F;
        for (int i = 0; i <= sus; ++i) { t[i] = su::envTimeOf(std::clamp(suV(u, su::envId(e, su::envT(i))), 0.0F, 1.0F)); l[i] = std::clamp(suV(u, su::envId(e, su::envL(i))), 0.0F, 1.0F); total += t[i]; }
        const float rel = su::envTimeOf(std::clamp(suV(u, su::envId(e, su::EV_REL)), 0.0F, 1.0F));
        const float hold = std::max(0.15F, total * 0.35F);
        const float span = std::max(0.3F, total + hold + rel);
        const auto px = [&](float sec) { return gr.left + 6.0F + (gr.width() - 12.0F) * sec / span; };
        const auto py = [&](float lv) { return gr.bottom - 5.0F - (gr.height() - 10.0F) * lv; };
        float x = px(0.0F), y = py(std::clamp(suV(u, su::envId(e, su::EV_START)), 0.0F, 1.0F));
        float at = 0.0F;
        const ColorInt ink = NL_BLUE;
        fill(c, RectF(x - 3.0F, y - 3.0F, x + 3.0F, y + 3.0F), 3.0F, ink);
        for (int i = 0; i <= sus; ++i) {
            at += t[i];
            const float nx = px(at), ny = py(l[i]);
            line(c, x, y, nx, ny, ink, 2.0F);
            fill(c, RectF(nx - 3.0F, ny - 3.0F, nx + 3.0F, ny + 3.0F), 3.0F, ink);
            x = nx; y = ny;
        }
        const float hx = px(at + hold);
        line(c, x, y, hx, y, Color::argb(160, 51, 160, 255), 2.0F);
        line(c, hx, y, px(at + hold + rel), py(0.0F), ink, 2.0F);
        text(c, "държане", (x + hx) * 0.5F, y - 6.0F, 9.5F, NL_TXT2, Opt().center());
        text(c, "отпускане", (hx + px(at + hold + rel)) * 0.5F, gr.bottom - 8.0F, 9.5F, NL_TXT2, Opt().center());
        text(c, fmtFixed(static_cast<double>(span), 2) + " s", gr.right - 8.0F, gr.top + 13.0F, 10.0F, NL_TXT2, Opt().right());
    }
    // ---- level and time rows (the classic shape: start, attack, decay to the held level, release)
    const RectF b2(a.left, b1.bottom + 8.0F, a.right, b1.bottom + 8.0F + 56.0F);
    const RectF b3(a.left, b2.bottom + 8.0F, a.right, b2.bottom + 8.0F + 56.0F);
    box(b2, "НИВО");
    box(b3, "ВРЕМЕ");
    const float third = (a.width() - 2.0F * kBoxPad - 16.0F) / 3.0F;
    const auto sl = [&](const RectF& r, const char* name, int id, float def) {
        const float v = std::clamp(suV(u, id), 0.0F, 1.0F);
        suSlider(c, r, name, v, su::dispText(su::paramDisp(id, patch), v), [this, u, id](float nv) { suSet(u, id, nv); }, [this, u, id, def] { suSet(u, id, def); });
    };
    const float yl = b2.top + 20.0F, yt = b3.top + 20.0F;
    sl(RectF(x0, yl, x0 + third, yl + kRow), "СТАРТ", su::envId(e, su::EV_START), 0.0F);
    sl(RectF(x0 + third + 8.0F, yl, x0 + 2.0F * third + 8.0F, yl + kRow), "АТАКА (връх)", su::envId(e, su::envL(0)), 1.0F);
    sl(RectF(x0 + 2.0F * third + 16.0F, yl, a.right - kBoxPad, yl + kRow), "ДЪРЖАНЕ", su::envId(e, su::envL(1)), 0.7F);
    sl(RectF(x0, yt, x0 + third, yt + kRow), "АТАКА", su::envId(e, su::envT(0)), suDefault(u, su::envId(e, su::envT(0))));
    sl(RectF(x0 + third + 8.0F, yt, x0 + 2.0F * third + 8.0F, yt + kRow), "ЗАТИХВАНЕ", su::envId(e, su::envT(1)), suDefault(u, su::envId(e, su::envT(1))));
    sl(RectF(x0 + 2.0F * third + 16.0F, yt, a.right - kBoxPad, yt + kRow), "ОТПУСКАНЕ", su::envId(e, su::EV_REL), suDefault(u, su::envId(e, su::EV_REL)));
    bool classic = rI(suV(u, su::envId(e, su::EV_SUS))) == 1;
    for (int i = 2; i < su::kEnvPoints; ++i) classic = classic && suV(u, su::envId(e, su::envT(i))) <= 0.001F;
    // ---- level and velocity of the oscillator
    const RectF b4(a.left, b3.bottom + 8.0F, a.right, a.bottom);
    box(b4, "СИЛА НА ОСЦИЛАТОР " + std::to_string(g + 1));
    const float ys = b4.top + 20.0F;
    const float half = (a.width() - 2.0F * kBoxPad - 12.0F) / 2.0F;
    sl(RectF(x0, ys, x0 + half, ys + kRow), "СИЛА", su::genId(g, su::GN_LEVEL), suDefault(u, su::genId(g, su::GN_LEVEL)));
    sl(RectF(x0 + half + 12.0F, ys, a.right - kBoxPad, ys + kRow), "ВЕЛОСИТИ → СИЛА", su::genId(g, su::GN_VELLEV), 0.5F);
    if (!classic) text(c, "Тази обвивка има още точки - пълният ѝ вид е в ADVANCED › ОБВИВКИ.", b1.right - kBoxPad, b1.top + 14.0F, 10.0F, NL_AMBER, Opt().right().bold().maxW(a.width() * 0.5F));
}

} // namespace silveton::ui::classic
