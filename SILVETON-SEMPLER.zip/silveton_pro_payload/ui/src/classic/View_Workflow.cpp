#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

std::string SilvetonSamplerView::openBlendLabel() {
    const auto listed = loadedFromList >= 0 ? realListItem(loadedFromList) : std::nullopt;
    return listed ? listed->name : cachedCombiName;
}

void SilvetonSamplerView::openSavePage() {
    if (scaleOpen_) closeScalePage();
    flashText.reset();
    saveOpen_ = true;
    listStoreMode_ = false;
    listEndMarking();
    listCancelPasteSelection();
    markMode = false;
    invalidate();
}

void SilvetonSamplerView::drawSavePage(Canvas& c) {
    const auto listed = loadedFromList >= 0 ? realListItem(loadedFromList) : std::nullopt;
    const std::string position = listed ? "LIST " + fmtZeroPad(loadedFromList + 1, 3) : "NOT STORED IN LIST";
    const bool edited = sampler.blendEdited();
    const RectF back(20.0F, 100.0F, 182.0F, 146.0F);
    nlBtn(c, back, "◀ BACK", NlBtn::Plain, 14.0F);
    hit(back, [this](float, float) { saveOpen_ = false; invalidate(); });
    text(c, "SAVE", 202.0F, 129.0F, 23.0F, NL_VALUE, Opt().bold());
    text(c, "Choose one blend or the complete SET", 290.0F, 128.0F, 15.0F, NL_TXT2);

    nlPanel(c, RectF(20.0F, 164.0F, 650.0F, 688.0F), "CURRENT BLEND", true);
    nlPanel(c, RectF(670.0F, 164.0F, 1320.0F, 688.0F), "COMPLETE SET");
    nlLcd(c, RectF(40.0F, 212.0F, 630.0F, 296.0F));
    text(c, position, 56.0F, 237.0F, 12.0F, NL_BLUE, Opt().bold());
    text(c, openBlendLabel(), 56.0F, 276.0F, 25.0F, NL_VALUE, Opt().bold().maxW(550.0F));
    text(c, edited ? "EDITED — current changes are still open" : "Current blend and settings", 42.0F, 326.0F, 14.0F,
         edited ? NL_AMBER : NL_TXT2, Opt().maxW(584.0F));
    text(c, "Includes parts, layers, engines, effects and Arabic scale.", 42.0F, 357.0F, 14.0F, NL_TXT2, Opt().maxW(584.0F));

    const RectF update(40.0F, 390.0F, 630.0F, 460.0F);
    lvKey(c, update, "UPDATE CURRENT LIST POSITION", listed ? position : "Choose a LIST position first",
          listed ? LvLook::Lit : LvLook::Off, 16.0F, true);
    if (listed) hit(update, [this](float, float) {
        saveOpenThen([this]() { cachedCombiName = sampler.combiName(); invalidate(); });
    });
    const RectF choose(40.0F, 478.0F, 630.0F, 548.0F);
    lvKey(c, choose, "SAVE TO LIST…", "Choose a position and name", LvLook::Plain, 17.0F, true);
    hit(choose, [this](float, float) { saveOpen_ = false; openStore(); });
    text(c, "UPDATE writes to the open blend's position.", 42.0F, 585.0F, 14.0F, NL_TXT2, Opt().maxW(584.0F));
    text(c, "SAVE TO LIST lets you keep another version elsewhere.", 42.0F, 612.0F, 14.0F, NL_TXT2, Opt().maxW(584.0F));

    nlLcd(c, RectF(690.0F, 212.0F, 1300.0F, 296.0F));
    text(c, "SET FILE NAME", 706.0F, 237.0F, 12.0F, NL_BLUE, Opt().bold());
    text(c, setsName_, 706.0F, 276.0F, 25.0F, NL_VALUE, Opt().bold().maxW(460.0F));
    const RectF name(1188.0F, 230.0F, 1288.0F, 280.0F);
    nlBtn(c, name, "RENAME", NlBtn::Plain, 12.0F);
    hit(name, [this](float, float) {
        showTextPage("SET FILE NAME", setsName_, [this](const std::string& typed) {
            const std::string value = trimmed(typed);
            if (!value.empty()) setsName_ = value;
            invalidate();
        });
    });
    text(c, "All LIST positions, blends and the current edited sound.", 692.0F, 326.0F, 14.0F, NL_TXT2, Opt().maxW(610.0F));
    text(c, "One .SVSET file. Samples remain in the sound bank.", 692.0F, 357.0F, 14.0F, NL_TXT2, Opt().maxW(610.0F));
    const RectF save(690.0F, 390.0F, 1300.0F, 460.0F);
    lvKey(c, save, "SAVE SET FILE", "Save the complete setup", LvLook::On, 17.0F, true);
    hit(save, [this](float, float) { saveSetNamed(setsName_); });
    const RectF load(690.0F, 478.0F, 1300.0F, 548.0F);
    lvKey(c, load, "LOAD SET…", "Choose a saved setup", LvLook::Plain, 17.0F, true);
    hit(load, [this](float, float) { loadSet(); });
    text(c, "Saving a SET preserves your open edits as well.", 692.0F, 585.0F, 14.0F, NL_TXT2, Opt().maxW(610.0F));
    text(c, "The keyboard stays live while you choose an action.", 692.0F, 612.0F, 14.0F, NL_TXT2, Opt().maxW(610.0F));
}

void SilvetonSamplerView::drawLiveActions(Canvas& c) {
    const int u = std::clamp(selectedUpper_, 0, 6);
    const auto partShort = [](int part) { return part == 6 ? std::string("LOWER") : "U" + std::to_string(part + 1); };
    const float y = 440.0F;
    const float bottom = 494.0F;
    nlLcd(c, RectF(20.0F, y, 206.0F, bottom));
    text(c, "SELECTED PART", 32.0F, y + 17.0F, 10.0F, NL_BLUE, Opt().bold());
    const std::string layer = stripSound[static_cast<std::size_t>(u)] > 0
        ? " / L" + std::to_string(stripSound[static_cast<std::size_t>(u)]) : " / MAIN";
    text(c, neUpperName(u) + layer, 32.0F, y + 40.0F, 13.0F, NL_VALUE, Opt().bold().maxW(164.0F));
    const RectF edit(214.0F, y, 366.0F, bottom);
    lvKey(c, edit, "SOUND EDIT", "Selected part", LvLook::Plain, 13.0F, true);
    hit(edit, [this, u](float, float) {
        editSound = std::clamp(stripSound[static_cast<std::size_t>(u)], 0, 4);
        goPage(Page::COMBI, MODE_EDIT);
    });
    const RectF copy(374.0F, y, 509.0F, bottom);
    const RectF paste(517.0F, y, 652.0F, bottom);
    lvKey(c, copy, "COPY PART", partShort(u), LvLook::Plain, 12.0F, true);
    lvKey(c, paste, "PASTE PART", copiedClip ? partShort(copiedClip->from) + " → " + partShort(u) : "Clipboard empty",
          copiedClip ? LvLook::Plain : LvLook::Off, 12.0F, true);
    hit(copy, [this, u](float, float) { copyUpper(u); });
    if (copiedClip) hit(paste, [this, u](float, float) { pasteUpper(u); });

    const GlobalUiState g = globalState.value_or(GlobalUiState{});
    const RectF minus(660.0F, y, 704.0F, bottom), val(708.0F, y, 766.0F, bottom), plus(770.0F, y, 814.0F, bottom);
    lvKey(c, minus, "−", "", LvLook::Plain, 22.0F, false);
    lvKey(c, plus, "+", "", LvLook::Plain, 22.0F, false);
    nlLcd(c, val);
    text(c, "TRANS", val.centerX(), y + 15.0F, 9.0F, NL_TXT2, Opt().center().bold());
    text(c, std::to_string(g.transpose), val.centerX(), y + 40.0F, 22.0F, NL_VALUE, Opt().center().monoBold());
    const auto setTranspose = [this](int value) {
        const auto current = sampler.globalUiState();
        if (!current) return;
        GlobalUiState next = *current;
        next.transpose = std::clamp(value, -24, 24);
        commitGlobal(next);
    };
    const auto resetTranspose = [setTranspose]() { setTranspose(0); };
    hit(minus, [this](float, float) { sampler.stepGlobalTranspose(-1); refreshGlobal(); invalidate(); }, resetTranspose);
    hit(plus, [this](float, float) { sampler.stepGlobalTranspose(1); refreshGlobal(); invalidate(); }, resetTranspose);
    pairHits.push_back(PairHit{minus, plus, resetTranspose});
    hit(val, [this, g, setTranspose](float, float) {
        showNumber("TRANSPOSE · semitones", static_cast<float>(g.transpose), -24.0F, 24.0F, 0,
                   [setTranspose](float value) { setTranspose(static_cast<int>(std::lround(value))); });
    }, resetTranspose);

    const RectF harmony(822.0F, y, 933.0F, bottom);
    lvKey(c, harmony, "HARMONY", sampler.tercaMasterOn() ? "ON" : "OFF", sampler.tercaMasterOn() ? LvLook::Lit : LvLook::Plain, 11.0F, true);
    hit(harmony, [this](float, float) {
        if (sampler.hasTercaUppers()) sampler.toggleTercaMaster();
        else { goPage(Page::COMBI, MODE_MIXER); flash("Choose T on the parts that should play harmony"); }
        invalidate();
    });
    const RectF scale(941.0F, y, 1117.0F, bottom), on(1125.0F, y, 1320.0F, bottom);
    lvKey(c, scale, "ARABIC SCALE", "NOTES / PARTS", LvLook::Plain, 12.0F, true);
    hit(scale, [this](float, float) { openScalePage(); });
    lvKey(c, on, sampler.scaleMasterOn() ? "SCALE ON" : "SCALE OFF", sampler.scaleName().empty() ? "Custom tuning" : sampler.scaleName(),
          sampler.scaleMasterOn() ? LvLook::On : LvLook::Plain, 14.0F, true);
    hit(on, [this](float, float) {
        if (!sampler.hasScaleUppers()) { openScalePage(); flash("Choose the parts that should use the scale"); }
        else { sampler.toggleScaleMaster(); invalidate(); }
    });
}

} // namespace silveton::ui::classic
