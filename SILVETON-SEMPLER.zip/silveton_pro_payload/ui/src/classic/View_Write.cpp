// SILVETON_MAC_VIEW_V1 - WRITE / COPY / MOVE, Korg style (tablet SilvetonSamplerView.kt lines 2335-2580)
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui::classic {

namespace {
std::string pad3(long long v) { return fmtZeroPad(v, 3); }
constexpr int kWritePerPage = 10;   // SILVETON_NEW_LOOK_V1: the STORE / COPY / MOVE screen: 2 columns x 5 rows on one page (20 pages for the 200 places)
} // namespace

void SilvetonSamplerView::openWrite(WriteTarget target, bool append) {
    writeMode = WriteMode::WRITE;
    writeSource = -1;
    writeSources_.clear();
    writeList = sampler.listItems(0, 0, 0);
    writeBlends.clear();
    for (const auto& kv : sampler.combiCatalog()) writeBlends[kv.first] = kv.second;
    writeName = sampler.combiName();
    selectWriteTarget(target, append);
    writeOpen = true;
    writePageFix_ = true;
    invalidate();
}

/** SILVETON_LIST_STORE_V1: STORE (the green key, SAVE LIST of ENGINE, STORE of the LIST) - no extra screen: the LIST opens and the position is
 *  chosen there. A tap on a position asks for the name and writes. The place that is suggested (and lit) is the one the old screen offered:
 *  the chosen one, else the place of the open blend, else the first free one. STORE pressed again writes to the lit place. */
void SilvetonSamplerView::openStore() {
    listPasteMode_ = false;
    if (listStoreMode_ && page_ == Page::LIST && listSelected >= 0 && listSelected < LIST_SIZE) { listStorePick(listSelected); return; }
    refreshListCache();
    int at = -1;
    if (page_ == Page::LIST && listSelected >= 0 && listSelected < LIST_SIZE) at = listSelected;
    else if (loadedFromList >= 0 && realListItem(loadedFromList)) at = loadedFromList;
    else { for (int i = 0; i < LIST_SIZE; ++i) if (!realListItem(i)) { at = i; break; } }
    if (page_ != Page::LIST) goPage(Page::LIST);
    listEndMarking();
    listSearch.clear();      // every position must be on the page
    listFavOnly = false;
    listStoreMode_ = true;
    listSelected = at;
    if (at >= 0) listPage = at / LIST_PER_PAGE;
    invalidate();
}

/** The position was chosen on the LIST (store mode): the name of the blend, then OVERWRITE if the place is taken, then it is written. */
void SilvetonSamplerView::listStorePick(int idx) {
    if (idx < 0 || idx >= LIST_SIZE) return;
    listSelected = idx;
    const std::optional<ListItem> old = realListItem(idx);
    const std::string oldName = old ? old->name : std::string();
    showTextPage("NAME OF THE BLEND · LIST " + pad3(idx + 1), sampler.combiName(), [this, idx, old, oldName](const std::string& typed) {
        std::string name = trimmed(typed);
        if (name.empty()) name = sampler.combiName();
        if (!old) { doWriteList(idx, name); return; }
        showConfirm("OVERWRITE LIST " + pad3(idx + 1), "“" + oldName + "” will be replaced by “" + name + "”.", "OVERWRITE",
                    [this, idx, name]() { doWriteList(idx, name); }, "CANCEL");
    });
}

/** COPY / MOVE a LIST position to any position 1..200 chosen on the same screen. */
void SilvetonSamplerView::openPositionPicker(WriteMode mode, int source) {
    writeMode = mode;
    writeSource = source;
    writeSources_.clear();   // (the LIST menu sets it again when several blends are marked)
    writeTarget = WriteTarget::LIST;
    writeList = sampler.listItems(0, 0, 0);
    writeBlends.clear();
    for (const auto& kv : sampler.combiCatalog()) writeBlends[kv.first] = kv.second;
    writeName = writeListName(source).value_or("");
    writeSelected = firstFreeListPosition(source);
    writePage = writeSelected >= 0 ? writeSelected / kWritePerPage : source / kWritePerPage;
    writeOpen = true;
    writePageFix_ = true;   // (the LIST menu may set the page for another page size when several blends are marked)
    invalidate();
}

std::optional<std::string> SilvetonSamplerView::writeListName(int pos) {
    if (pos < 0 || pos >= static_cast<int>(writeList.size())) return std::nullopt;
    const ListItem& it = writeList[static_cast<std::size_t>(pos)];
    if (sampler.isEmptyListItem(it)) return std::nullopt;
    return it.name;
}

int SilvetonSamplerView::firstFreeListPosition(int after) {
    for (int k = 0; k < 200; ++k) {
        const int pos = (after + 1 + k) % 200;
        if (pos != writeSource && !writeListName(pos)) return pos;
    }
    return -1;
}

void SilvetonSamplerView::selectWriteTarget(WriteTarget target, bool append) {
    writeTarget = target;
    if (target == WriteTarget::LIST) {
        if (!append && writeListName(loadedFromList)) {
            writeSelected = loadedFromList;
        } else {
            writeSelected = -1;
            for (int i = 0; i < 200; ++i) if (!writeListName(i)) { writeSelected = i; break; }
        }
    } else {
        const std::optional<int> own = editingCombiSlot;
        if (!append && own && *own >= 1 && *own <= 500) {
            writeSelected = *own - 1;
        } else {
            int first = 0;
            for (int s = 1; s <= 500; ++s) if (writeBlends.count(s) == 0) { first = s; break; }
            writeSelected = first - 1;
        }
    }
    writePage = writeSelected >= 0 ? writeSelected / kWritePerPage : 0;
}

std::optional<std::string> SilvetonSamplerView::writeOccupiedName(int pos) {
    if (writeTarget == WriteTarget::LIST) return writeListName(pos);
    const auto it = writeBlends.find(pos + 1);
    if (it == writeBlends.end()) return std::nullopt;
    return it->second;
}

// SILVETON_NEW_LOOK_V1: STORE / COPY / MOVE as a modal card over the dimmed screen (copy_move.png): the title, FROM (or the NAME),
// 20 page keys, 10 positions (2 x 5) on a page, the line of what will happen, CANCEL and the action key.
void SilvetonSamplerView::drawWriteScreen(Canvas& c) {
    fill(c, RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), 0.0F, Color::argb(199, 0, 0, 0));
    // Modal background: swallows touches outside the panel.
    hit(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), [](float, float) {});
    const RectF p(70.0F, 40.0F, 1270.0F, 760.0F);
    dialogCard(c, p);
    const bool picking = writeMode != WriteMode::WRITE;
    const bool manyIn = picking && writeSources_.size() > 1U;   // SILVETON_LIST_MENU_V2: several marked blends go together
    const std::string title = writeMode == WriteMode::WRITE ? "STORE" : (writeMode == WriteMode::COPY ? "COPY" : "MOVE");
    const bool listTarget = writeTarget == WriteTarget::LIST;
    const int total = listTarget ? 200 : 500;
    if (writePageFix_) {   // the first drawing after opening: the page of the chosen position (the LIST menu may have set another page size)
        if (writeSelected >= 0) writePage = writeSelected / kWritePerPage;
        writePageFix_ = false;
    }
    text(c, title, p.left + 30.0F, p.top + 44.0F, 28.0F, Color::WHITE, Opt().monoBold());
    text(c, manyIn ? "Choose where to start. The blends go only to free places, nothing is overwritten."
                   : picking ? "Choose where it goes. A taken position can be overwritten, the others do not move."
                             : "The blend is stored in the LIST. Choose a position and a name. A taken position can be overwritten.",
         p.left + 30.0F, p.top + 72.0F, 13.0F, NL_TXT2, Opt().maxW(p.width() - 60.0F));

    // SILVETON_LOGIC_V1: no LIST / BLENDS switch - a BLEND always goes to a place of the LIST (the store of 500 is kept by the sampler itself)

    nlLabel(c, picking ? "FROM" : "NAME", p.left + 30.0F, p.top + 100.0F, false, NL_TXT2, 11.0F);
    const RectF nameR(p.left + 30.0F, p.top + 108.0F, picking ? p.left + 550.0F : p.right - 170.0F, p.top + 156.0F);
    nlLcd(c, nameR);
    const std::string nameText = manyIn ? std::to_string(writeSources_.size()) + " MARKED BLENDS  (from " + pad3(writeSources_.front() + 1) + ")"
                                        : (picking ? pad3(writeSource + 1) + "  " + writeName : writeName);
    text(c, nameText, nameR.left + 14.0F, nameR.centerY() + 6.0F, 17.0F, NL_VALUE, Opt().monoBold().maxW(nameR.width() - 28.0F));
    if (!picking) {
        const RectF renR(p.right - 150.0F, p.top + 108.0F, p.right - 30.0F, p.top + 156.0F);
        nlBtn(c, renR, "RENAME", NlBtn::Plain, 13.0F, false);
        const auto rename = [this]() { showTextPage("RENAME", writeName, [this](const std::string& v) { writeName = v; }); };
        hit(nameR, [rename](float, float) { rename(); });
        hit(renR, [rename](float, float) { rename(); });
    }

    // the page keys, one row
    const int pages = (total + kWritePerPage - 1) / kWritePerPage;
    const float kx0 = p.left + 30.0F;
    const float kx1 = p.right - 10.0F;   // 20 keys of 53 with a gap of 4 end at x 1236
    const float keysTop = p.top + 172.0F;
    const float keyH = 38.0F;
    const float keyGap = 4.0F;
    const float keyW = std::min(53.0F, (kx1 - kx0 - static_cast<float>(pages - 1) * keyGap) / static_cast<float>(pages));
    for (int k = 0; k < pages; ++k) {
        const RectF kr(kx0 + static_cast<float>(k) * (keyW + keyGap), keysTop, kx0 + static_cast<float>(k) * (keyW + keyGap) + keyW, keysTop + keyH);
        nlBtn(c, kr, std::to_string(k + 1), k == writePage ? NlBtn::Sel : NlBtn::Off, 11.0F, writeSelected >= 0 && writeSelected / kWritePerPage == k);
        hit(kr, [this, k](float, float) { writePage = k; });
    }

    // the positions: 2 columns x 5 rows
    const float gridTop = p.top + 228.0F;
    const float cellW = 570.0F;
    const float cellH = 56.0F;
    for (int j = 0; j < kWritePerPage; ++j) {
        const int pos = writePage * kWritePerPage + j;
        if (pos >= total) break;
        const float col = static_cast<float>(j % 2);
        const float row = static_cast<float>(j / 2);
        const RectF cell(kx0 + col * (cellW + 10.0F), gridTop + row * 64.0F, kx0 + col * (cellW + 10.0F) + cellW, gridTop + row * 64.0F + cellH);
        const bool isSource = picking && (pos == writeSource || std::find(writeSources_.begin(), writeSources_.end(), pos) != writeSources_.end());
        const bool usable = !isSource;
        writeCell(c, cell, pos + 1, writeOccupiedName(pos), usable, pos == writeSelected, isSource);
        if (usable) hit(cell, [this, pos](float, float) { writeSelected = pos; });
    }

    // what will happen
    const std::string label = listTarget ? "position " : "blend place ";
    const std::optional<std::string> selName = writeSelected >= 0 ? writeOccupiedName(writeSelected) : std::nullopt;
    const std::string action = writeMode == WriteMode::WRITE ? "STORING" : (writeMode == WriteMode::COPY ? "COPYING" : "MOVING");
    std::string info;
    if (writeSelected < 0) info = "Choose a position";
    else if (manyIn) info = action + " " + std::to_string(writeSources_.size()) + " blends  ·  from " + label + pad3(writeSelected + 1) + " on, free places only";
    else if (selName) info = action + "  ·  " + label + pad3(writeSelected + 1) + "  ·  OVERWRITE “" + *selName + "”";
    else info = action + "  ·  " + label + pad3(writeSelected + 1) + " (free)";
    text(c, info, p.left + 30.0F, p.top + 571.0F, 14.0F, selName ? NL_AMBER : Color::rgb(207, 230, 255), Opt().monoBold().maxW(1000.0F));

    const RectF cancel(p.left + 30.0F, p.top + 600.0F, p.left + 290.0F, p.top + 664.0F);
    const RectF write(p.right - 260.0F, p.top + 600.0F, p.right - 10.0F, p.top + 664.0F);
    nlBtn(c, cancel, "CANCEL", NlBtn::Plain, 15.0F, false);
    hit(cancel, [this](float, float) { writeOpen = false; });
    nlBtn(c, write, title, writeSelected >= 0 ? NlBtn::On : NlBtn::Off, 16.0F, writeSelected >= 0);
    if (writeSelected >= 0) hit(write, [this](float, float) { confirmWrite(); });
}

// one position of the STORE / COPY / MOVE screen: a key with the number in a black box, the name and TAKEN / FREE / SOURCE
void SilvetonSamplerView::writeCell(Canvas& c, const RectF& r, int number, const std::optional<std::string>& name, bool usable, bool selected, bool source) {
    nlBtn(c, r, std::string(), selected ? NlBtn::Sel : (!usable && !source ? NlBtn::Off : (source || name ? NlBtn::Plain : NlBtn::Off)), 14.0F, false);
    if (source) strokeRR(c, RectF(r.left + 1.0F, r.top + 1.0F, r.right - 1.0F, r.bottom - 1.0F), 7.0F, NL_AMBER, 2.0F);
    const RectF box(r.left + 8.0F, r.top + 8.0F, r.left + 64.0F, r.top + 48.0F);
    nlLcd(c, box, 6.0F);
    text(c, pad3(number), box.centerX(), box.centerY() + 5.5F, 15.0F, NL_VALUE, Opt().center().monoBold());
    const float textX = r.left + 78.0F;
    const ColorInt sub = selected ? Color::rgb(220, 236, 255) : NL_TXT2;
    if (source) {
        text(c, name ? *name : std::string(), textX, r.top + 24.0F, 15.0F, Color::WHITE, Opt().maxW(r.width() - 90.0F));
        text(c, "SOURCE", textX, r.top + 42.0F, 11.0F, sub, Opt().bold().spacing(0.12F));
    } else if (!usable) {
        text(c, "—", textX, r.top + 24.0F, 18.0F, NL_MUT);
    } else if (name) {
        text(c, *name, textX, r.top + 24.0F, 15.0F, Color::WHITE, Opt().bold().maxW(r.width() - 90.0F));
        text(c, "TAKEN", textX, r.top + 42.0F, 11.0F, sub, Opt().bold().spacing(0.12F));
    } else {
        text(c, "— free —", textX, r.top + 24.0F, 15.0F, selected ? Color::rgb(205, 225, 248) : NL_MUT);
        text(c, "FREE", textX, r.top + 42.0F, 11.0F, sub, Opt().bold().spacing(0.12F));
    }
}

void SilvetonSamplerView::confirmWrite() {
    const int pos = writeSelected;
    if (pos < 0) return;
    if (writeMode != WriteMode::WRITE && writeSources_.size() > 1U) {   // SILVETON_LIST_MENU_V2: several blends, free places only
        doCopyOrMoveMany(writeMode == WriteMode::MOVE, writeSources_, pos);
        return;
    }
    std::string name = trimmed(writeName);
    if (name.empty()) name = sampler.combiName();
    const WriteMode mode = writeMode;
    const WriteTarget target = writeTarget;
    const int source = writeSource;
    std::function<void()> runIt;
    if (mode == WriteMode::COPY) runIt = [this, source, pos]() { doCopyOrMove(false, source, pos); };
    else if (mode == WriteMode::MOVE) runIt = [this, source, pos]() { doCopyOrMove(true, source, pos); };
    else if (target == WriteTarget::LIST) runIt = [this, pos, name]() { doWriteList(pos, name); };
    else runIt = [this, pos, name]() { doWriteBlend(pos + 1, name); };
    const std::optional<std::string> old = writeOccupiedName(pos);
    if (!old) { runIt(); return; }
    const std::string incoming = mode == WriteMode::WRITE ? name : writeName;
    const std::string label = target == WriteTarget::LIST ? "LIST" : "BLEND";
    std::string extra;
    if (target == WriteTarget::BLEND) {
        std::string users;
        for (std::size_t i = 0; i < writeList.size(); ++i) {
            const ListItem& it = writeList[i];
            if (it.combiBank == 0 && it.combiPage == 0 && it.combiSlot == pos + 1) {
                if (!users.empty()) users += ", ";
                users += pad3(static_cast<long long>(i) + 1);
            }
        }
        if (!users.empty()) extra = "\nAlso used in LIST: " + users;
    }
    showConfirm("OVERWRITE " + label + " " + pad3(pos + 1), "“" + *old + "” will be replaced by “" + incoming + "”." + extra, "OVERWRITE", runIt, "CANCEL");
}

// SILVETON_WRITE_ERR_V1: why a write / copy / move / delete failed - in words, so the screen never just falls silent.
std::string SilvetonSamplerView::failureText(const std::string& raw) {
    if (raw.empty()) return "Failed. The reason is not known.";
    auto has = [&](const char* s) { return raw.find(s) != std::string::npos; };
    if (has("No free COMBI position")) return "No free place for a blend: all 500 places are taken. Overwrite a blend or free a place.";
    if (has("LIST is full")) return "The LIST is full: 200 positions.";
    if (has("LIST position is empty")) return "There is no blend at this position of the LIST.";
    if (has("position is invalid")) return "This position is not valid.";
    if (has("COMBI position must be")) return "The number of the place must be from 1 to 500.";
    if (has("LIST name cannot be empty")) return "The name cannot be empty.";
    if (has("Write Combi failed")) return "The blend was not saved.";
    if (has("No active COMBI")) return "There is no open blend.";
    if (has("COMBI slot is empty")) return "This blend is empty.";
    return "Failed. (" + raw + ")";
}

// SILVETON_FAV_FOLLOW_V1: the star (★) follows the blend: MOVE takes it along, COPY gives the copy the same star as the source.
void SilvetonSamplerView::remapFavourites(int from, int to, bool move) {
    if (listFavs.count(from) != 0U) listFavs.insert(to); else listFavs.erase(to);
    if (move) listFavs.erase(from);
    sampler.saveListFavourites(listFavs);
}

void SilvetonSamplerView::doWriteList(int pos, const std::string& name) {
    const int index = sampler.writeCombiToList(pos, name);
    if (index < 0) { showMessage("SAVING FAILED", failureText(sampler.lastFailure())); invalidate(); return; }
    refreshListCache();
    const std::optional<ListItem> item = realListItem(index);
    if (item && item->combiBank == 0 && item->combiPage == 0) editingCombiSlot = item->combiSlot;
    loadedFromList = index;
    listFollowedActive = cachedActiveListEntry;
    listPage = std::clamp(index / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    cachedCombiName = sampler.combiName();
    refreshAllUppers();
    refreshFx();
    writeOpen = false;
    listStoreMode_ = false;   // SILVETON_LIST_STORE_V1
    flash("STORED: LIST " + pad3(index + 1) + "  „" + name + "“");   // SILVETON_LOGIC_V1: you stay where you are
}

void SilvetonSamplerView::doWriteBlend(int slot, const std::string& name) {
    if (!sampler.writeCombiSlot(slot, name)) { showMessage("SAVING FAILED", failureText(sampler.lastFailure())); invalidate(); return; }
    editingCombiSlot = slot;
    loadedFromList = -1;
    cachedCombiName = sampler.combiName();
    refreshAllUppers();
    refreshFx();
    refreshListCache();
    writeOpen = false;
    flash("STORED: BLEND " + pad3(slot));
}

// SILVETON_LIST_MENU_V2: COPY / MOVE of several blends: the free places from `start` on, in the order of the blends (nothing is written over)
void SilvetonSamplerView::doCopyOrMoveMany(bool move, const std::vector<int>& from, int start) {
    std::vector<int> dest;
    for (int p = std::max(0, start); p < 200 && dest.size() < from.size(); ++p) if (!writeListName(p)) dest.push_back(p);
    if (dest.size() < from.size()) {
        showMessage(move ? "MOVE" : "COPY", "From this position on there are not enough empty places for " + std::to_string(from.size()) + " blends. Choose an earlier position.");
        return;
    }
    int done = 0;
    for (std::size_t k = 0U; k < from.size(); ++k) {
        const bool ok = move ? sampler.moveListEntryTo(from[k], dest[k]) : sampler.copyListEntryTo(from[k], dest[k]);
        if (!ok) { showMessage(move ? "MOVING FAILED" : "COPYING FAILED", failureText(sampler.lastFailure())); break; }
        remapFavourites(from[k], dest[k], move);
        if (move && loadedFromList == from[k]) loadedFromList = dest[k];
        else if (loadedFromList == dest[k]) loadedFromList = -1;
        ++done;
    }
    refreshListCache();
    listFollowedActive = realListItem(cachedActiveListEntry) ? cachedActiveListEntry : -1;
    listPage = std::clamp(dest.front() / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    writeOpen = false;
    writeSources_.clear();
    listMarkMode_ = false;
    listMarked_.clear();
    page_ = Page::LIST;
    flash(std::string(move ? "MOVED " : "COPIED ") + std::to_string(done) + " BLENDS FROM LIST " + pad3(dest.front() + 1));
}

void SilvetonSamplerView::doCopyOrMove(bool move, int from, int to) {
    const bool ok = move ? sampler.moveListEntryTo(from, to) : sampler.copyListEntryTo(from, to);
    if (!ok) { showMessage(move ? "MOVING FAILED" : "COPYING FAILED", failureText(sampler.lastFailure())); invalidate(); return; }
    remapFavourites(from, to, move);
    if (move && loadedFromList == from) loadedFromList = to;
    else if (loadedFromList == to) loadedFromList = -1;
    refreshListCache();
    listFollowedActive = realListItem(cachedActiveListEntry) ? cachedActiveListEntry : -1;
    listPage = std::clamp(to / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    writeOpen = false;
    page_ = Page::LIST;
    flash(std::string(move ? "MOVED: LIST " : "COPIED: LIST ") + pad3(to + 1));
}

} // namespace silveton::ui::classic
