// Proves the "light drawing": a picture made by FrameRenderer (only the changed parts drawn again) is exactly the picture
// that drawing everything gives - pixel for pixel - over many random changes of a busy scene.
// Usage: imak_damage_tests <fonts dir>
#include "silveton/ui/Gfx.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

using namespace silveton::ui;

namespace {
int g_failures = 0;
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++g_failures; } } while (0)

constexpr int W = 640;
constexpr int H = 400;

struct Rng {
    std::uint32_t s;
    std::uint32_t next() { s = s * 1664525U + 1013904223U; return s >> 8U; }
    int i(int lo, int hi) { return lo + static_cast<int>(next() % static_cast<std::uint32_t>(hi - lo + 1)); }
    float f(float lo, float hi) { return lo + (hi - lo) * static_cast<float>(next() & 0xFFFFU) / 65535.0F; }
};

struct Item {
    int kind{0};
    float x{0}, y{0}, w{40}, h{30};
    ColorInt color{Color::WHITE};
    ColorInt color2{Color::BLACK};
    float angle{0};
    float stroke{2};
    std::string text{"Силветон"};
    int alpha{255};
};

Item randomItem(Rng& r) {
    Item it;
    it.kind = r.i(0, 12);
    it.x = r.f(-20.0F, static_cast<float>(W));
    it.y = r.f(-20.0F, static_cast<float>(H));
    it.w = r.f(6.0F, 150.0F);
    it.h = r.f(6.0F, 110.0F);
    it.color = Color::argb(r.i(40, 255), r.i(0, 255), r.i(0, 255), r.i(0, 255));
    it.color2 = Color::argb(r.i(0, 255), r.i(0, 255), r.i(0, 255), r.i(0, 255));
    it.angle = r.f(0.0F, 360.0F);
    it.stroke = r.f(0.5F, 9.0F);
    static const char* texts[] = {"Силветон", "SILVETON 123", "Piano + Strings", "ЛИСТ 007", "C#4  vel 127", "ÐÑ"};
    it.text = texts[r.i(0, 5)];
    it.alpha = r.i(30, 255);
    return it;
}

void drawItem(Canvas& c, const Item& it, const Image& img) {
    Paint p;
    p.color = it.color;
    switch (it.kind) {
        case 0: c.drawRect(RectF(it.x, it.y, it.x + it.w, it.y + it.h), p); break;
        case 1:
            p.shader = linearGradient(it.x, it.y, it.x + it.w * 0.3F, it.y + it.h, it.color, it.color2);
            c.drawRoundRect(RectF(it.x, it.y, it.x + it.w, it.y + it.h), 9.0F, 9.0F, p);
            break;
        case 2:
            p.shader = radialGradient(it.x, it.y, it.w, it.color, it.color2);
            c.drawCircle(it.x, it.y, it.w * 0.8F, p);
            break;
        case 3:
            p.strokeWidth = it.stroke; p.strokeCap = Cap::Round;
            c.drawLine(it.x, it.y, it.x + it.w, it.y + it.h * 0.7F, p);
            break;
        case 4:
            p.style = Style::Stroke; p.strokeWidth = it.stroke; p.strokeCap = Cap::Round;
            c.drawArc(RectF(it.x, it.y, it.x + it.w, it.y + it.w), it.angle, 220.0F, false, p);
            break;
        case 5:
            p.textSize = 10.0F + it.h * 0.2F; p.typeface = (it.kind + static_cast<int>(it.w)) % 2 == 0 ? Face::Bold : Face::Regular;
            p.letterSpacing = it.stroke > 5.0F ? 0.1F : 0.0F;
            c.drawText(it.text, it.x, it.y, p);
            break;
        case 6: {
            Path path;
            path.moveTo(it.x, it.y); path.lineTo(it.x + it.w, it.y + it.h * 0.2F); path.lineTo(it.x + it.w * 0.5F, it.y + it.h); path.close();
            c.drawPath(path, p);
            p.color = it.color2; p.style = Style::Stroke; p.strokeWidth = it.stroke;
            c.drawPath(path, p);
            break;
        }
        case 7:
            c.save();
            c.translate(it.x, it.y);
            c.rotate(it.angle, 0.0F, 0.0F);
            c.drawRoundRect(RectF(-it.w * 0.5F, -it.h * 0.5F, it.w * 0.5F, it.h * 0.5F), 5.0F, 5.0F, p);
            c.restore();
            break;
        case 8:
            c.save();
            c.clipRect(RectF(it.x, it.y, it.x + it.w, it.y + it.h));
            p.shader = linearGradient(0.0F, 0.0F, 4.0F, 0.0F, std::vector<ColorInt>{it.color, it.color, it.color2, it.color2},
                                      std::vector<float>{0.0F, 0.5F, 0.5F, 1.0F}, TileMode::Repeat);
            c.drawRect(RectF(it.x - 30.0F, it.y - 30.0F, it.x + it.w + 30.0F, it.y + it.h + 30.0F), p);
            c.restore();
            break;
        case 9: {
            Paint q;
            q.color = Color::argb(it.alpha, 255, 255, 255);
            c.drawImage(img, RectF(it.x, it.y, it.x + it.w, it.y + it.h), q);
            break;
        }
        case 10:
            p.shader = sweepGradient(it.x, it.y, std::vector<ColorInt>{it.color, it.color2, it.color}, std::vector<float>{0.0F, 0.5F, 1.0F});
            c.drawCircle(it.x, it.y, it.w * 0.5F, p);
            break;
        case 11:
            c.save();
            c.scale(1.7F, 1.3F);
            p.style = Style::Stroke; p.strokeWidth = it.stroke;
            c.drawRoundRect(RectF(it.x * 0.3F, it.y * 0.3F, it.x * 0.3F + it.w * 0.5F, it.y * 0.3F + it.h * 0.5F), 4.0F, 4.0F, p);
            c.restore();
            break;
        default:
            p.shader = linearGradient(it.x, it.y, it.x + it.w, it.y, std::vector<ColorInt>{it.color, it.color2, it.color},
                                      std::vector<float>{0.0F, 0.4F, 1.0F});
            c.drawRect(RectF(it.x, it.y, it.x + it.w, it.y + it.h), p);
            break;
    }
}

void drawScene(Canvas& c, const std::vector<Item>& items, const Image& img) {
    Paint bg;
    bg.color = Color::rgb(30, 34, 40);
    c.drawRect(RectF(0, 0, static_cast<float>(c.width()), static_cast<float>(c.height())), bg);
    bg.shader = radialGradient(static_cast<float>(W) * 0.5F, static_cast<float>(H) * 0.4F, 400.0F, Color::rgb(60, 64, 74), Color::rgb(24, 26, 30));
    c.drawRect(RectF(0, 0, static_cast<float>(W), static_cast<float>(H)), bg);
    for (const Item& it : items) drawItem(c, it, img);
}

long long countDifferent(const Canvas& a, const Canvas& b) {
    long long n = 0;
    for (std::size_t i = 0U; i < a.buffer().size(); ++i) if (a.buffer()[i] != b.buffer()[i]) ++n;
    return n;
}
} // namespace

int main(int argc, char** argv) {
    setFontDirectory(argc > 1 ? argv[1] : "resources/fonts");
    CHECK(fontsReady());

    Image img;
    img.width = 64; img.height = 48;
    {
        Rng r{7};
        img.pixels.resize(64U * 48U);
        for (auto& p : img.pixels) { const std::uint32_t a = static_cast<std::uint32_t>(r.i(120, 255)); p = (a << 24U) | ((a * static_cast<std::uint32_t>(r.i(0, 255)) / 255U) << 16U) | ((a * static_cast<std::uint32_t>(r.i(0, 255)) / 255U) << 8U) | (a / 2U); }
    }

    // ---- 1. recording + replay of the whole list = immediate drawing (every kind of draw call)
    {
        Rng r{12345};
        for (int round = 0; round < 6; ++round) {
            std::vector<Item> items;
            for (int i = 0; i < 70; ++i) items.push_back(randomItem(r));
            Canvas direct(W, H);
            drawScene(direct, items, img);
            FrameRenderer fr(W, H);
            fr.update([&](Canvas& c) { drawScene(c, items, img); });
            const long long diff = countDifferent(direct, fr.picture());
            if (diff != 0) std::fprintf(stderr, "round %d: %lld pixels differ in the first picture\n", round, diff);
            CHECK(diff == 0);
        }
    }

    // ---- 2. many random changes: the part-by-part picture stays identical to the full one
    {
        Rng r{999};
        std::vector<Item> items;
        for (int i = 0; i < 60; ++i) items.push_back(randomItem(r));
        FrameRenderer fr(W, H);
        long long repaintedTotal = 0;
        int quiet = 0;
        const int steps = 300;
        for (int step = 0; step < steps; ++step) {
            const int what = r.i(0, 9);
            bool same = false;
            switch (what) {
                case 0: case 1: case 2: {   // move one item a little (maybe less than a pixel)
                    Item& it = items[static_cast<std::size_t>(r.i(0, static_cast<int>(items.size()) - 1))];
                    it.x += r.i(0, 1) == 0 ? r.f(-0.4F, 0.4F) : r.f(-30.0F, 30.0F);
                    it.y += r.f(-10.0F, 10.0F);
                    break;
                }
                case 3: items[static_cast<std::size_t>(r.i(0, static_cast<int>(items.size()) - 1))].color = Color::argb(r.i(40, 255), r.i(0, 255), r.i(0, 255), r.i(0, 255)); break;
                case 4: if (items.size() > 10U) items.erase(items.begin() + r.i(0, static_cast<int>(items.size()) - 1)); break;
                case 5: items.insert(items.begin() + r.i(0, static_cast<int>(items.size())), randomItem(r)); break;
                case 6: std::swap(items[static_cast<std::size_t>(r.i(0, static_cast<int>(items.size()) - 1))], items[static_cast<std::size_t>(r.i(0, static_cast<int>(items.size()) - 1))]); break;
                case 7: items[static_cast<std::size_t>(r.i(0, static_cast<int>(items.size()) - 1))].text = "Промяна " + std::to_string(step); break;
                case 8: { for (int k = 0; k < 8; ++k) items[static_cast<std::size_t>(r.i(0, static_cast<int>(items.size()) - 1))].x += r.f(-20.0F, 20.0F); break; }
                default: same = true; break;   // nothing changes
            }
            fr.update([&](Canvas& c) { drawScene(c, items, img); });
            Canvas direct(W, H);
            drawScene(direct, items, img);
            const long long diff = countDifferent(direct, fr.picture());
            if (diff != 0) std::fprintf(stderr, "step %d (change %d): %lld pixels differ\n", step, what, diff);
            CHECK(diff == 0);
            if (step > 0) repaintedTotal += fr.lastRepaintedPixels();
            if (same) { CHECK(fr.changed().empty()); ++quiet; }
            if (diff != 0) break;
        }
        std::printf("random changes: %d steps, %d unchanged pictures, drawn again on average %.1f %% of the picture\n", steps, quiet,
                    100.0 * static_cast<double>(repaintedTotal) / (static_cast<double>(steps - 1) * W * H));
    }

    // ---- 3. one small thing moves in a busy picture: only a small part is drawn again
    {
        Rng r{4242};
        std::vector<Item> items;
        for (int i = 0; i < 80; ++i) { Item it = randomItem(r); it.w = std::min(it.w, 60.0F); it.h = std::min(it.h, 40.0F); if (it.kind == 2 || it.kind == 12) it.kind = 0; items.push_back(it); }
        Item mover;
        mover.kind = 2; mover.x = 100; mover.y = 100; mover.w = 14; mover.color = Color::rgb(255, 80, 40); mover.color2 = Color::argb(0, 255, 80, 40);
        items.push_back(mover);
        FrameRenderer fr(W, H);
        fr.update([&](Canvas& c) { drawScene(c, items, img); });
        for (int i = 0; i < 20; ++i) {
            items.back().x += 7.0F;
            const auto& ch = fr.update([&](Canvas& c) { drawScene(c, items, img); });
            CHECK(!ch.empty());
            CHECK(fr.lastRepaintedPixels() < static_cast<long long>(W) * H / 10);
            Canvas direct(W, H);
            drawScene(direct, items, img);
            CHECK(countDifferent(direct, fr.picture()) == 0);
        }
        const auto& none = fr.update([&](Canvas& c) { drawScene(c, items, img); });
        CHECK(none.empty());
        fr.invalidate();
        const auto& all = fr.update([&](Canvas& c) { drawScene(c, items, img); });
        CHECK(all.size() == 1U && all[0] == IRect(0, 0, W, H));
        std::printf("a small moving thing: %lld pixels drawn per picture (the whole picture has %d)\n", fr.lastRepaintedPixels() / 1, W * H);
    }

    // ---- 4. speed: the full picture against the changed part
    {
        Rng r{31337};
        std::vector<Item> items;
        for (int i = 0; i < 80; ++i) items.push_back(randomItem(r));
        Item mover;
        mover.kind = 2; mover.x = 100; mover.y = 100; mover.w = 14; mover.color = Color::rgb(255, 80, 40); mover.color2 = Color::argb(0, 255, 80, 40);
        items.push_back(mover);
        FrameRenderer fr(W, H);
        fr.update([&](Canvas& c) { drawScene(c, items, img); });
        using clock = std::chrono::steady_clock;
        const auto t0 = clock::now();
        const int n = 40;
        for (int i = 0; i < n; ++i) { Canvas c(W, H); drawScene(c, items, img); }
        const double full = std::chrono::duration<double, std::milli>(clock::now() - t0).count() / n;
        const auto t1 = clock::now();
        for (int i = 0; i < n; ++i) { items.back().x += 3.0F; fr.update([&](Canvas& c) { drawScene(c, items, img); }); }
        const double part = std::chrono::duration<double, std::milli>(clock::now() - t1).count() / n;
        const auto t2 = clock::now();
        for (int i = 0; i < n; ++i) fr.update([&](Canvas& c) { drawScene(c, items, img); });
        const double idle = std::chrono::duration<double, std::milli>(clock::now() - t2).count() / n;
        std::printf("speed: full picture %.2f ms, small change %.2f ms, nothing changed %.2f ms\n", full, part, idle);
    }

    if (g_failures == 0) std::printf("damage tests OK\n");
    return g_failures == 0 ? 0 : 1;
}
