// Exercise the current ENGINE and SOUND EDIT controls through their real hit callbacks.
#include "silveton/ui/classic/SilvetonSamplerView.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;

#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct NewLookAccess {
    static void voice(View& v) {
        v.page_ = View::Page::COMBI;
        v.combiMode_ = View::MODE_EDIT;
        v.editGroup_ = View::EG_VOICE;
        v.selectedUpper_ = 0;
        v.invalidate();
    }
    static void midi(View& v) {
        voice(v);
        v.editGroup_ = View::EG_MIDICTL;
    }
    static void engine(View& v, int upper) {
        v.engUpper_ = upper;
        v.selectedUpper_ = upper;
        v.page_ = View::Page::ENGINES;
        v.placeTab_ = 0;
        v.invalidate();
    }
    static bool tap(View& v, float x, float y) {
        const auto h = v.hitAt(x, y);
        if (!h || !h->tap) return false;
        const auto action = h->tap;
        action(x, y);
        return true;
    }
    static void number(View& v, const std::string& value) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        d->value = value;
        d->cursor = static_cast<int>(value.size());
        d->selectAll = false;
        v.dialogFire(d, d->buttons.back().action);
    }
};
} // namespace silveton::ui::classic

namespace {
using Access = classic::NewLookAccess;

ControllerEnv testEnvironment() {
    char temp[] = "/tmp/imak-engine-controls-XXXXXX";
    CHECK(::mkdtemp(temp) != nullptr);
    ControllerEnv env;
    env.dataDir = temp;
    return env;
}

struct Fixture {
    SamplerAppController controller{testEnvironment()};
    View view{controller};
    Canvas canvas{1340, 800};

    Fixture() {
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 0));
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 1));
        view.refreshAllForTests();
    }
    void draw() { view.draw(canvas); }
    void tap(float x, float y) { CHECK(Access::tap(view, x, y)); draw(); }
    void optionalTap(float x, float y) { (void)Access::tap(view, x, y); draw(); }
    void number(float x, float y, const std::string& value) {
        tap(x, y);
        Access::number(view, value);
        draw();
    }
    std::vector<float> params(int upper = 0) { return controller.engine.nativeUpperParams(upper); }
    std::vector<float> state(int upper = 0) { return controller.engine.nativeUpperState(upper); }
    void addSynth(int upper = 0) {
        Access::engine(view, upper);
        draw();
        tap(822.0F, 344.0F);
        CHECK(controller.engine.nativeUpperEngineParams(upper).at(0) == 12.0F);
    }
};

void instrumentControls() {
    Fixture f;
    Access::voice(f.view);
    f.draw();
    f.tap(812.0F, 278.0F); // SOUND EDIT: INSTRUMENT
    f.number(900.0F, 500.0F, "73");
    CHECK(f.params().at(42) == 2.0F && f.params().at(45) == 73.0F);
    const float oldSeconds = f.state().at(14);
    f.addSynth(); // adding a Synth on this UPPER must retain its Instrument mode
    CHECK(f.params().at(42) == 2.0F);
    f.tap(1237.0F, 447.0F); // PORTA ON -> OFF
    CHECK(f.params().at(45) == 0.0F && f.state().at(14) == oldSeconds);
    f.tap(1237.0F, 447.0F); // restore Instrument's previous 0..127 value
    CHECK(f.params().at(45) == 73.0F && f.state().at(14) == oldSeconds);
    f.number(1110.0F, 604.0F, "80");
    CHECK(f.params().at(45) == 80.0F && f.state().at(14) == oldSeconds);
    f.tap(997.0F, 558.0F); // RATE remains available
    CHECK(f.params().at(44) == 1.0F);
    f.tap(889.0F, 558.0F); // TIME
    CHECK(f.params().at(44) == 0.0F);
    const float fingered = f.params().at(43);
    f.optionalTap(1237.0F, 510.0F);
    CHECK(f.params().at(43) == fingered); // not a supported Instrument control
    CHECK(f.params().at(42) == 2.0F); // viewing/editing never silently changes mode
}

void kronosBassAndMainControls() {
    Fixture f;
    f.addSynth();
    f.tap(997.0F, 510.0F); // KRONOS
    f.number(1110.0F, 604.0F, "95");
    f.tap(1237.0F, 447.0F);
    CHECK(f.params().at(45) == 0.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(f.params().at(45) == 95.0F);
    const float originalFingered = f.params().at(43);
    f.tap(1237.0F, 510.0F);
    CHECK(f.params().at(43) == 1.0F - originalFingered);
    f.tap(1237.0F, 510.0F);
    CHECK(f.params().at(43) == originalFingered);
    f.tap(1105.0F, 510.0F); // BASS
    CHECK(f.params().at(42) == 3.0F);
    f.optionalTap(1237.0F, 510.0F);
    CHECK(f.params().at(43) == originalFingered);
    f.tap(997.0F, 558.0F);
    CHECK(f.params().at(44) == 1.0F);
    f.tap(889.0F, 558.0F);
    CHECK(f.params().at(44) == 0.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(f.params().at(45) == 0.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(f.params().at(45) == 95.0F);
    const auto otherUpper = f.state(1);
    for (int mode = 0; mode < 3; ++mode) {
        f.tap(889.0F + 108.0F * static_cast<float>(mode), 447.0F);
        CHECK(f.state().at(9) == static_cast<float>(mode));
    }
    f.number(1240.0F, 604.0F, "12");
    CHECK(f.params().at(48) == 12.0F && f.state(1) == otherUpper);
}

void separateTimeRestore() {
    Fixture f;
    f.addSynth();
    f.number(880.0F, 604.0F, "30"); // SILVETON: 30 ms
    f.tap(1237.0F, 447.0F);
    CHECK(f.state().at(14) == 0.0F);
    f.tap(997.0F, 510.0F); // KRONOS: 100 on its separate 0..127 scale
    f.number(1110.0F, 604.0F, "100");
    f.tap(1237.0F, 447.0F);
    CHECK(f.params().at(45) == 0.0F);
    f.tap(889.0F, 510.0F); // returning to Silveton must keep OFF until requested
    CHECK(f.state().at(14) == 0.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(std::abs(f.state().at(14) - 0.03F) < 0.000001F);
    CHECK(f.params().at(45) == 0.0F);
    f.tap(997.0F, 510.0F);
    CHECK(f.params().at(45) == 0.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(f.params().at(45) == 100.0F);
    f.addSynth(1);
    f.number(880.0F, 604.0F, "17");
    f.tap(1237.0F, 447.0F);
    Access::engine(f.view, 0);
    f.draw();
    f.tap(889.0F, 510.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(f.state().at(14) == 0.0F);
    f.tap(1237.0F, 447.0F);
    CHECK(std::abs(f.state().at(14) - 0.03F) < 0.000001F);
    Access::engine(f.view, 1);
    f.draw();
    f.tap(1237.0F, 447.0F);
    CHECK(std::abs(f.state(1).at(14) - 0.017F) < 0.000001F);
}

bool pixelsDiffer(const std::vector<std::uint32_t>& before, const Canvas& after, int left, int top, int right, int bottom) {
    for (int y = top; y < bottom; ++y) for (int x = left; x < right; ++x) {
        const auto i = static_cast<std::size_t>(y * after.width() + x);
        if (before.at(i) != after.buffer().at(i)) return true;
    }
    return false;
}

void remappedMidiAndControllerFlags() {
    Fixture f;
    Access::midi(f.view);
    f.draw();
    const auto oldPicture = f.canvas.buffer();
    CHECK(f.controller.engine.nativeUpdateGlobal(440.0F, 0, 0, 0, 0, 0, false, -1, 0, 9, 12, 65, true, true));
    f.view.globalChangedOutside();
    f.draw();
    // Only the CC subtitles in these three controls must follow the new assignments.
    CHECK(pixelsDiffer(oldPicture, f.canvas, 270, 317, 435, 334));
    CHECK(pixelsDiffer(oldPicture, f.canvas, 460, 317, 625, 334));
    CHECK(pixelsDiffer(oldPicture, f.canvas, 840, 317, 1005, 334));
    CHECK(!pixelsDiffer(oldPicture, f.canvas, 650, 317, 815, 334)); // PRESSURE is not a CC
    const auto oldState = f.state();
    const auto otherUpper = f.state(1);
    for (int k = 0; k < 4; ++k) {
        f.tap(352.0F + 190.0F * static_cast<float>(k), 310.0F);
        CHECK(f.state().at(static_cast<std::size_t>(15 + k)) == 1.0F - oldState.at(static_cast<std::size_t>(15 + k)));
        f.tap(352.0F + 190.0F * static_cast<float>(k), 310.0F);
        CHECK(f.state().at(static_cast<std::size_t>(15 + k)) == oldState.at(static_cast<std::size_t>(15 + k)));
    }
    f.number(1190.0F, 316.0F, "7");
    CHECK(f.state().at(19) == 6.0F && f.state(1) == otherUpper);
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 2) { std::fprintf(stderr, "usage: %s <fonts directory>\n", argv[0]); return 2; }
    setFontDirectory(argv[1]);
    if (!fontsReady()) { std::fprintf(stderr, "fonts are unavailable\n"); return 2; }
    struct Test { const char* name; void (*run)(); };
    const Test tests[] = {
        {"Instrument ON/OFF, TIME and RATE use its active native parameters", instrumentControls},
        {"Kronos FINGERED works; Bass ignores it; voice and bend controls remain correct", kronosBassAndMainControls},
        {"PORTA ON restores separate ms and 0..127 values for each part", separateTimeRestore},
        {"MIDI captions follow mapped CCs; controller flags and channel still work", remappedMidiAndControllerFlags}
    };
    int failures = 0;
    for (const auto& test : tests) {
        try { test.run(); std::printf("PASS %s\n", test.name); }
        catch (const std::exception& e) { std::fprintf(stderr, "FAIL %s: %s\n", test.name, e.what()); ++failures; }
    }
    return failures == 0 ? 0 : 1;
}
