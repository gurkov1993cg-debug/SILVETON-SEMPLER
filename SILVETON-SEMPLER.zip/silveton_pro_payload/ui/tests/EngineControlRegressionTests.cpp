// Exercise the shared UPPER source controls through their real hit callbacks.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SoloDefs.h"
#include "silveton/sampler/SoloModel.h"

#include <cmath>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;

#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct NewLookAccess {
    static void voice(View& v) {
        v.page_ = View::Page::COMBI;
        v.combiMode_ = View::MODE_EDIT;
        v.editGroup_ = View::EG_VOICE;
        v.selectedUpper_ = 0;
        v.invalidate();
    }
    static void midi(View& v) {
        voice(v);
        v.editGroup_ = View::EG_MIDICTL;
    }
    static void engine(View& v, int upper) {
        v.engUpper_ = upper;
        v.selectedUpper_ = upper;
        v.page_ = View::Page::ENGINES;
        v.placeTab_ = 0;
        v.invalidate();
    }
    static bool tap(View& v, float x, float y) {
        const auto h = v.hitAt(x, y);
        if (!h || !h->tap) return false;
        const auto action = h->tap;
        action(x, y);
        return true;
    }
    static void drag(View& v,float fromX,float fromY,float x,float y){
        const auto h=v.hitAt(fromX,fromY);CHECK(h&&h->drag);
        const auto action=h->drag;action(x,y,true);
    }
    static void reset(View& v,float x,float y){
        const auto h=v.hitAt(x,y);CHECK(h&&h->reset);
        const auto action=h->reset;action();
    }
    static void number(View& v, const std::string& value) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        d->value = value;
        d->cursor = static_cast<int>(value.size());
        d->selectAll = false;
        v.dialogFire(d, d->buttons.back().action);
    }


    static void pick(View& v, int index, std::size_t count) {
        CHECK(!v.dialogStack.empty()); const auto d=v.dialogStack.back();
        CHECK(d->gridItems.size()==count && d->onPick);
        const auto fn=d->onPick; v.dialogStack.pop_back(); fn(index);
    }

};
} // namespace silveton::ui::classic

namespace {
using Access = classic::NewLookAccess;

int requestUpper=-1,requestSound=-1;
ControllerEnv testEnvironment() {
    char temp[] = "/tmp/imak-engine-controls-XXXXXX";
    CHECK(::mkdtemp(temp) != nullptr);
    ControllerEnv env;
    env.dataDir = temp;
    env.chooseSoloModel=[](int upper,int sound){requestUpper=upper;requestSound=sound;};
    return env;
}

struct Fixture {
    SamplerAppController controller{testEnvironment()};
    View view{controller};
    Canvas canvas{1340, 800};

    Fixture() {
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 0));
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 1));
        view.refreshAllForTests();
    }
    void draw() { view.draw(canvas); }
    void tap(float x, float y) { CHECK(Access::tap(view, x, y)); draw(); }
    void optionalTap(float x, float y) { (void)Access::tap(view, x, y); draw(); }
    void number(float x, float y, const std::string& value) {
        tap(x, y);
        Access::number(view, value);
        draw();
    }
    std::vector<float> params(int upper = 0) { return controller.engine.nativeUpperParams(upper); }
    std::vector<float> state(int upper = 0) { return controller.engine.nativeUpperState(upper); }

};


void soloControls(){
 namespace sv=silveton::sampler;namespace so=sv::solo;Fixture f;
 auto m=std::make_shared<so::Model>();m->name="TEACHER — UPPER 1 / L2";
 so::Cell c;c.at.phase=so::Phase::Sustain;c.at.key=69;c.at.ageMs=300;c.count=1;c.sound.db.fill(-60);c.sound.db[0]=0;m->cells.push_back(c);m->prepare();
 sv::SoundAssignment source;source.engine=sv::engineDefaults(sv::EngineType::Solo);source.soloModel=m;source.name=m->name;source.commonProcessing=true;
 CHECK(f.controller.putSoundSource(0,2,source));f.view.showSoloPart(0,2);f.draw();
 CHECK(f.view.selectedSoloPart()==0&&f.view.selectedSoloSound()==2);
 f.number(810,438,"72");CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::Brightness]-.72F)<.001F);
 f.tap(479,476);CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::MorphX]-.5F)<.001F);
 CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::MorphY]-.5F)<.001F);
 Access::drag(f.view,479,476,720,350);f.draw();
 CHECK(f.controller.soundSource(0,2).engine.p[so::MorphX]==1&&f.controller.soundSource(0,2).engine.p[so::MorphY]==1);
 Access::reset(f.view,479,476);f.draw();
 CHECK(f.controller.soundSource(0,2).engine.p[so::MorphX]==0&&f.controller.soundSource(0,2).engine.p[so::MorphY]==0);
 Access::drag(f.view,479,476,562.6F,504.8F);f.draw();
 CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::MorphX]-.7F)<.001F);
 CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::MorphY]-.35F)<.001F);
 CHECK(f.controller.soundSource(0,0).program&&!f.controller.soundSource(0,0).soloModel);
 CHECK(writePng("UPPER_SOURCE.png",f.canvas));
 // Shared tuning page targets this layer, never the old SOLO rack.
 f.tap(120,205);f.tap(470,297);CHECK(f.controller.layerParams(0,1)[4]==1);CHECK(f.controller.upperState(0)->octave==0);
 // The one UPPER bend control must be editable and stored while a SOLO layer is selected.
 Access::voice(f.view);f.draw();f.tap(1244,376);
 CHECK(f.controller.upperState(0)->pitchBendRange==7&&f.params()[48]==7);
 f.number(1110,460,"12");CHECK(f.controller.upperState(0)->pitchBendRange==12&&f.params()[48]==12);
 f.number(1110,460,"0");CHECK(f.controller.upperState(0)->pitchBendRange==0);
 f.number(1110,460,"24");CHECK(f.controller.upperState(0)->pitchBendRange==24);
 f.view.showSoloPart(0,2);f.draw();
 // The native dialog callback gets the selected UPPER and existing layer.
 f.tap(412,250);CHECK(requestUpper==0&&requestSound==2);
 CHECK(f.controller.engine.nativeSaveUserPerformanceState("/tmp/upper_ui_roundtrip.SVSET"));CHECK(f.controller.engine.nativeClearPerformance());
 CHECK(f.controller.engine.nativeReplaceUserPerformanceState("/tmp/upper_ui_roundtrip.SVSET"));std::remove("/tmp/upper_ui_roundtrip.SVSET");
 CHECK(f.controller.soundSource(0,2).soloModel);
 CHECK(f.controller.upperState(0)->pitchBendRange==24);
 CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::MorphX]-.7F)<.001F);
 CHECK(std::abs(f.controller.soundSource(0,2).engine.p[so::MorphY]-.35F)<.001F);
}

}
int main(int argc,char** argv){if(argc<2)return 2;setFontDirectory(argv[1]);if(!fontsReady())return 2;try{soloControls();std::puts("PASS actual UPPER source callbacks: XY tap/drag/clamp/reset and SET persistence, layer-specific colour, common tuning, file request and saved model");}catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
