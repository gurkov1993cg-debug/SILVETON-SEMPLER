// Checks of the drawing layer: exact pixels for simple shapes, text measure, and a picture for the eyes.
#include "silveton/ui/Gfx.h"

#include <cmath>
#include <cstdio>
#include <limits>
#include <cstdlib>
#include <string>

using namespace silveton::ui;

static int g_failures = 0;
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++g_failures; } } while (0)

static std::uint32_t px(const Canvas& c, int x, int y) { return c.pixels()[static_cast<std::size_t>(y) * static_cast<std::size_t>(c.width()) + static_cast<std::size_t>(x)]; }

int main(int argc, char** argv) {
    const std::string fonts = argc > 1 ? argv[1] : "resources/fonts";
    const std::string out = argc > 2 ? argv[2] : ".";
    setFontDirectory(fonts);
    CHECK(fontsReady());

    {   // solid rectangle, exact edges
        Canvas c(20, 20);
        c.clear(Color::rgb(0, 0, 0));
        Paint p;
        p.color = Color::rgb(255, 0, 0);
        c.drawRect(RectF(2, 3, 10, 8), p);
        CHECK(px(c, 2, 3) == 0xFFFF0000U);
        CHECK(px(c, 9, 7) == 0xFFFF0000U);
        CHECK(px(c, 10, 7) == 0xFF000000U);
        CHECK(px(c, 1, 3) == 0xFF000000U);
        CHECK(px(c, 5, 8) == 0xFF000000U);
    }
    {   // half-covered edge = half colour
        Canvas c(10, 10);
        c.clear(Color::rgb(0, 0, 0));
        Paint p;
        p.color = Color::rgb(255, 255, 255);
        c.drawRect(RectF(2.5F, 2, 6, 6), p);
        const int g = Color::green(px(c, 2, 3));
        CHECK(g >= 126 && g <= 129);
        CHECK(px(c, 3, 3) == 0xFFFFFFFFU);
    }
    {   // translucent over opaque
        Canvas c(4, 4);
        c.clear(Color::rgb(0, 0, 255));
        Paint p;
        p.color = Color::argb(128, 255, 0, 0);
        c.drawRect(RectF(0, 0, 4, 4), p);
        const std::uint32_t v = px(c, 1, 1);
        CHECK(Color::alpha(v) == 255);
        CHECK(Color::red(v) >= 127 && Color::red(v) <= 129);
        CHECK(Color::blue(v) >= 126 && Color::blue(v) <= 128);
    }
    {   // circle area ~ pi r^2
        Canvas c(100, 100);
        c.clear(Color::rgb(0, 0, 0));
        Paint p;
        p.color = Color::rgb(255, 255, 255);
        c.drawCircle(50, 50, 30, p);
        double sum = 0.0;
        for (int y = 0; y < 100; ++y) for (int x = 0; x < 100; ++x) sum += Color::green(px(c, x, y)) / 255.0;
        CHECK(std::fabs(sum - 3.14159265 * 900.0) < 12.0);
        CHECK(px(c, 50, 50) == 0xFFFFFFFFU);
        CHECK(px(c, 5, 5) == 0xFF000000U);
    }
    {   // stroked circle is a ring
        Canvas c(100, 100);
        c.clear(Color::rgb(0, 0, 0));
        Paint p;
        p.color = Color::rgb(255, 255, 255);
        p.style = Style::Stroke;
        p.strokeWidth = 6.0F;
        c.drawCircle(50, 50, 30, p);
        CHECK(px(c, 50, 50) == 0xFF000000U);
        CHECK(px(c, 80, 50) == 0xFFFFFFFFU);
        CHECK(px(c, 50, 20) == 0xFFFFFFFFU);
        double sum = 0.0;
        for (int y = 0; y < 100; ++y) for (int x = 0; x < 100; ++x) sum += Color::green(px(c, x, y)) / 255.0;
        CHECK(std::fabs(sum - 3.14159265 * (33.0 * 33.0 - 27.0 * 27.0)) < 8.0);
    }
    {   // clip
        Canvas c(20, 20);
        c.clear(Color::rgb(0, 0, 0));
        c.save();
        c.clipRect(RectF(5, 5, 10, 10));
        Paint p;
        p.color = Color::rgb(255, 255, 255);
        c.drawRect(RectF(0, 0, 20, 20), p);
        c.restore();
        CHECK(px(c, 4, 7) == 0xFF000000U);
        CHECK(px(c, 5, 5) == 0xFFFFFFFFU);
        CHECK(px(c, 9, 9) == 0xFFFFFFFFU);
        CHECK(px(c, 10, 9) == 0xFF000000U);
    }
    {   // gradient
        Canvas c(100, 10);
        c.clear(Color::rgb(0, 0, 0));
        Paint p;
        p.shader = linearGradient(0, 0, 100, 0, Color::rgb(0, 0, 0), Color::rgb(255, 255, 255));
        c.drawRect(RectF(0, 0, 100, 10), p);
        CHECK(Color::green(px(c, 0, 5)) <= 3);
        CHECK(Color::green(px(c, 99, 5)) >= 252);
        const int mid = Color::green(px(c, 50, 5));
        CHECK(mid >= 124 && mid <= 132);
    }
    {   // text: width scales, Cyrillic and Latin both have letters, letter spacing adds
        Paint p;
        p.textSize = 20.0F;
        const float w1 = p.measureText("Hello");
        CHECK(w1 > 30.0F && w1 < 70.0F);
        const float wc = p.measureText("Привет");
        CHECK(wc > 30.0F && wc < 90.0F);
        Paint q = p;
        q.letterSpacing = 0.1F;
        CHECK(std::fabs(q.measureText("Hello") - (w1 + 5.0F * 2.0F)) < 0.01F);
        CHECK(utf8Length("Привет") == 6);
        CHECK(utf8Prefix("Привет", 3) == "При");
        CHECK(utf8Upper("абв ab") == "АБВ AB");
        Canvas c(200, 40);
        c.clear(Color::rgb(0, 0, 0));
        Paint t;
        t.color = Color::rgb(255, 255, 255);
        t.textSize = 24.0F;
        c.drawText("SILVETON", 10, 30, t);
        long lit = 0;
        for (int y = 0; y < 40; ++y) for (int x = 0; x < 200; ++x) if (Color::green(px(c, x, y)) > 128) ++lit;
        CHECK(lit > 150);
    }

    // a picture with everything, for looking at
    {
        Canvas c(640, 360);
        c.clear(Color::rgb(40, 44, 52));
        Paint p;
        p.shader = linearGradient(0, 0, 0, 80, Color::rgb(90, 60, 30), Color::rgb(40, 24, 10));
        c.drawRoundRect(RectF(20, 20, 300, 100), 14, 14, p);
        Paint s;
        s.color = Color::argb(120, 0, 0, 0);
        c.drawRoundRect(RectF(24, 112, 296, 124), 6, 6, s);
        Paint ring;
        ring.color = Color::rgb(230, 190, 70);
        ring.style = Style::Stroke;
        ring.strokeWidth = 8.0F;
        ring.strokeCap = Cap::Round;
        c.drawArc(RectF(340, 20, 440, 120), 135, 270, false, ring);
        Paint rad;
        rad.shader = radialGradient(520, 70, 50, Color::rgb(255, 240, 200), Color::argb(0, 255, 240, 200));
        c.drawCircle(520, 70, 50, rad);
        Paint line;
        line.color = Color::rgb(120, 200, 255);
        line.strokeWidth = 3.0F;
        line.strokeCap = Cap::Round;
        c.drawLine(30, 150, 300, 190, line);
        Path path;
        path.moveTo(340, 190); path.lineTo(400, 140); path.lineTo(460, 190); path.lineTo(400, 175); path.close();
        Paint pf;
        pf.color = Color::rgb(200, 90, 90);
        c.drawPath(path, pf);
        Paint pl;
        pl.color = Color::rgb(255, 255, 255);
        pl.style = Style::Stroke;
        pl.strokeWidth = 4.0F;
        c.drawPath(path, pl);
        Paint t;
        t.color = Color::rgb(245, 245, 245);
        t.textSize = 30.0F;
        t.typeface = Face::Bold;
        c.drawText("Силветон СЕМПЛЕР 0123", 20, 250, t);
        t.typeface = Face::Regular; t.textSize = 22.0F;
        c.drawText("Regular: Piano Strings Brass ♪ ▶ ◀", 20, 285, t);
        t.typeface = Face::Mono; t.textSize = 18.0F;
        c.drawText("Mono  C#4  Vel 127  Layer 1", 20, 315, t);
        t.letterSpacing = 0.2F; t.textAlign = Align::Right; t.typeface = Face::MonoBold;
        c.drawText("RIGHT 0.2em", 620, 345, t);
        c.save();
        c.translate(560, 240);
        c.rotate(30, 0, 0);
        Paint r;
        r.color = Color::argb(200, 90, 200, 120);
        c.drawRoundRect(RectF(-40, -15, 40, 15), 6, 6, r);
        c.restore();
        CHECK(writePng(out + "/gfx_test.png", c));
    }

    {   // SILVETON_GFX_SAFE_POLY_V1: a shape with a coordinate that is not a number (NaN), is infinite or is absurdly far outside
        // must not crash the rasterizer (that was a crash of the Manager while a screen was drawn): it is left out, and a good
        // shape after it still draws.
        const unsigned long before = badPolygonCount();
        Canvas c(40, 40);
        c.clear(Color::rgb(0, 0, 0));
        Paint p;
        p.color = Color::rgb(255, 255, 255);
        const float nan = std::numeric_limits<float>::quiet_NaN();
        const float inf = std::numeric_limits<float>::infinity();
        Path bad;
        bad.moveTo(nan, 5); bad.lineTo(nan, 8); bad.lineTo(nan, 30); bad.lineTo(nan, 25); bad.close();
        c.drawPath(bad, p);
        Path mixed;
        mixed.moveTo(5, 5); mixed.lineTo(nan, 8); mixed.lineTo(nan, 30); mixed.lineTo(3, 25); mixed.close();
        c.drawPath(mixed, p);
        Path far;
        far.moveTo(5, 5); far.lineTo(inf, 8); far.lineTo(20, -inf); far.lineTo(3, 25); far.close();
        c.drawPath(far, p);
        // the shape of the crash of 26.10.2026 (SIGSEGV in accumulateEdge, row index -2^31): corners so far outside that the slope
        // of the edge between them overflows to infinity, with ordinary y values
        Path huge;
        huge.moveTo(-3.0e38F, 5); huge.lineTo(3.0e38F, 8); huge.lineTo(20, 30); huge.lineTo(3, 25); huge.close();
        c.drawPath(huge, p);
        Path line;
        line.moveTo(nan, nan); line.lineTo(10, 10);
        Paint pl; pl.color = Color::rgb(255, 255, 255); pl.style = Style::Stroke; pl.strokeWidth = 3.0F;
        c.drawPath(line, pl);
        Path good;
        good.moveTo(30, 30); good.lineTo(38, 30); good.lineTo(38, 38); good.lineTo(30, 38); good.close();
        c.drawPath(good, p);
        CHECK(px(c, 34, 34) == 0xFFFFFFFFU);
        CHECK(px(c, 2, 2) == 0xFF000000U);
        CHECK(badPolygonCount() >= before + 4UL);
    }
    {   // colour themes (SILVETON_THEMES_V1): graphite changes nothing, light turns the brightness over, black goes deeper, alpha stays
        const ColorInt dark = Color::rgb(40, 44, 52), white = Color::rgb(240, 240, 240), blue = Color::rgb(60, 130, 230);
        CHECK(colorOfTheme(dark, 0) == dark);
        CHECK(colorOfTheme(dark, 7) == dark);                                     // unknown theme = graphite
        const ColorInt ld = colorOfTheme(dark, 1), lw = colorOfTheme(white, 1);
        CHECK(Color::red(ld) > 180 && Color::red(lw) < 60);                       // dark panel -> light, white text -> dark text
        const ColorInt lb = colorOfTheme(blue, 1);
        CHECK(Color::blue(lb) > Color::red(lb));                                  // a blue stays blue
        const ColorInt shadow = Color::argb(120, 0, 0, 0);
        CHECK(colorOfTheme(shadow, 1) == shadow);                                 // shadows stay dark
        CHECK(Color::alpha(colorOfTheme(Color::argb(77, 40, 44, 52), 1)) == 77);  // transparency stays
        const ColorInt bd = colorOfTheme(dark, 2);
        CHECK(Color::red(bd) < Color::red(dark) && Color::blue(bd) < Color::blue(dark));
        CHECK(colorOfTheme(white, 2) == white);                                   // light things stay in black
        CHECK(colorOfTheme(Color::rgb(0, 0, 0), 2) == Color::rgb(0, 0, 0));
        // КЛАСИКА: dark glass and white stay, the writing of the displays stays, blue turns green, graphite turns light grey
        CHECK(colorOfTheme(Color::rgb(15, 18, 21), 3) == Color::rgb(15, 18, 21));
        CHECK(colorOfTheme(Color::WHITE, 3) == Color::WHITE);
        CHECK(colorOfTheme(themekeep::kLcd, 3) == themekeep::kLcd && colorOfTheme(themekeep::kLcdOk, 3) == themekeep::kLcdOk);
        const ColorInt cb = colorOfTheme(Color::rgb(70, 136, 206), 3);
        CHECK(Color::green(cb) > Color::blue(cb) && Color::green(cb) > Color::red(cb));
        CHECK(Color::red(colorOfTheme(Color::rgb(41, 46, 52), 3)) > 190);
        CHECK(Color::red(colorOfTheme(Color::rgb(228, 231, 235), 3)) < 60);       // the ink of the panels turns dark
        // a real picture: the same rectangle on a canvas in the three themes
        Canvas c(8, 8);
        Paint p; p.color = dark;
        setColorTheme(1); c.clear(Color::rgb(10, 10, 10)); c.drawRect(RectF(0, 0, 8, 8), p);
        CHECK(Color::red(px(c, 4, 4)) > 180);
        setColorTheme(2); c.clear(Color::rgb(10, 10, 10)); c.drawRect(RectF(0, 0, 8, 8), p);
        CHECK(Color::red(px(c, 4, 4)) < 40);
        setColorTheme(0); c.clear(Color::rgb(10, 10, 10)); c.drawRect(RectF(0, 0, 8, 8), p);
        CHECK(px(c, 4, 4) == dark);
    }
    if (g_failures == 0) std::printf("gfx tests OK\n");
    return g_failures == 0 ? 0 : 1;
}
