// SILVETON_LIST_PERSIST_TEST_V1: a blend deleted from the LIST must stay deleted after a restart of the program (26.10.2026:
// "трия бленди от семплера и след всяко влизане на ново те са там"). The same folders, a new controller = a new start.
#include "silveton/host/HostIo.h"
#include "silveton/sampler/SvBankFormat.h"
#include "silveton/ui/SamplerAppController.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include <unistd.h>

using namespace silveton::ui;
namespace sv = silveton::sampler;

namespace {
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

void writeBank(const std::string& path, const std::vector<std::string>& names) {
    std::vector<std::uint8_t> strings{0U};
    auto addString = [&](const std::string& text) -> std::uint32_t {
        const auto offset = static_cast<std::uint32_t>(strings.size());
        strings.insert(strings.end(), text.begin(), text.end());
        strings.push_back(0U);
        return offset;
    };
    const auto bankName = addString("DEMO BANK");
    const auto sampleName = addString("DEMO SAMPLE");
    const auto sampleIdentity = addString("sample://demo");
    const auto msName = addString("DEMO MULTI");
    const auto msIdentity = addString("multi://demo");
    std::vector<std::uint8_t> sounds, layers, multis, samples, zones, audio;
    for (std::size_t i = 0U; i < names.size(); ++i) {
        sv::SvSoundRecord sound{};
        sound.nameOffset = addString(names[i]);
        sound.firstLayer = static_cast<std::uint32_t>(i);
        sound.layerCount = 1U;
        sound.soundSlotId = static_cast<std::uint32_t>(i + 1U);
        sv::appendSoundRecord(sounds, sound);
        sv::SvSoundLayerRecord layer{};
        layer.multisampleId = 4000001U; layer.enabled = 1U; layer.keyLow = 0U; layer.keyHigh = 127U; layer.velocityLow = 1U; layer.velocityHigh = 127U;
        sv::appendSoundLayerRecord(layers, layer);
    }
    sv::SvMultisampleRecord ms{};
    ms.multisampleId = 4000001U; ms.nameOffset = msName; ms.sourceIdentityOffset = msIdentity; ms.firstZone = 0U; ms.zoneCount = 1U;
    sv::appendMultisampleRecord(multis, ms);
    sv::SvSampleRecord sample{};
    sample.sampleId = 3000001U; sample.nameOffset = sampleName; sample.sourceIdentityOffset = sampleIdentity; sample.sampleRate = 48000U; sample.channels = 1U;
    constexpr std::uint32_t kFrames = 4800U;   // 100 ms: long enough for the bank's own playback probe (the render test's 8 frames are not)
    sample.encoding = 1U; sample.bitsPerSample = 16U; sample.rootKey = 60U; sample.totalFrames = kFrames; sample.audioOffset = 0U; sample.audioSize = kFrames * 2U;
    sv::appendSampleRecord(samples, sample);
    sv::SvZoneRecord zone{};
    zone.sampleId = 3000001U; zone.keyLow = 0U; zone.keyHigh = 127U; zone.velocityLow = 1U; zone.velocityHigh = 127U; zone.rootKey = 60U;
    sv::appendZoneRecord(zones, zone);
    for (std::uint32_t i = 0U; i < kFrames; ++i) {
        const auto v = static_cast<std::int16_t>(16000.0 * std::sin(2.0 * 3.14159265358979 * 261.63 * static_cast<double>(i) / 48000.0));
        const auto u = static_cast<std::uint16_t>(v);
        audio.push_back(static_cast<std::uint8_t>(u & 0xFFU));
        audio.push_back(static_cast<std::uint8_t>((u >> 8U) & 0xFFU));
    }
    sv::SvBankHeader header{};
    header.bankNameOffset = bankName;
    header.soundCount = static_cast<std::uint32_t>(names.size());
    header.soundLayerCount = static_cast<std::uint32_t>(names.size());
    header.multisampleCount = 1U; header.sampleCount = 1U; header.zoneCount = 1U;
    std::vector<std::uint8_t> file(sv::kSvBankHeaderSize, 0U);
    auto appendSec = [&](sv::SvSection section, const std::vector<std::uint8_t>& data) {
        auto& d = header.sections[static_cast<std::size_t>(section)];
        d.offset = static_cast<std::uint64_t>(file.size());
        d.size = static_cast<std::uint64_t>(data.size());
        file.insert(file.end(), data.begin(), data.end());
    };
    appendSec(sv::SvSection::Sounds, sounds); appendSec(sv::SvSection::SoundLayers, layers); appendSec(sv::SvSection::Multisamples, multis);
    appendSec(sv::SvSection::Samples, samples); appendSec(sv::SvSection::Zones, zones); appendSec(sv::SvSection::Strings, strings); appendSec(sv::SvSection::Audio, audio);
    header.fileSize = static_cast<std::uint64_t>(file.size());
    header.payloadSha256 = sv::sha256(file.data() + sv::kSvBankHeaderSize, file.size() - sv::kSvBankHeaderSize);
    const auto serialized = sv::serializeHeader(header);
    std::copy(serialized.begin(), serialized.end(), file.begin());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(file.data()), static_cast<std::streamsize>(file.size()));
}

std::vector<std::string> listNames(SamplerAppController& c) {
    std::vector<std::string> out;
    for (const auto& item : c.listItems(0, 0, 0)) if (!(item.combiBank == 0 && item.combiPage == 0 && item.combiSlot == 0)) out.push_back(item.name);
    return out;
}

// The Manager keeps the places that left the sampler in ПРАТЕНИ.txt and gives them back at every start (SVSamplerHost); here a small file does it.
std::vector<int> readRemoved(const std::string& dir) {
    std::vector<int> out;
    std::ifstream in(dir + "/removed.txt");
    int p = 0;
    while (in >> p) out.push_back(p);
    return out;
}

void addRemoved(const std::string& dir, const std::vector<int>& places) {
    std::ofstream out(dir + "/removed.txt", std::ios::app);
    for (const int p : places) out << p << "\n";
}

std::string catalogNames(SamplerAppController& c) {
    std::string s;
    for (const auto& it : c.soundCatalog()) if (it.slot >= 1 && it.slot <= 500) s += (s.empty() ? "" : ",") + it.name;
    return s;
}

std::unique_ptr<SamplerAppController> startProgram(const ControllerEnv& env, const std::string& dir) {
    auto c = std::make_unique<SamplerAppController>(env);
    c->setRemovedSounds(readRemoved(dir));
    c->setSoundsRemovedHandler([dir](const std::vector<int>& places) { addRemoved(dir, places); });
    c->engine.setBackends(std::make_unique<silveton::host::OfflineAudioOutput>(96000.0, 96U), std::make_unique<silveton::host::ManualMidiInput>());
    CHECK(c->start());
    for (int i = 0; i < 100 && c->soundCatalog().empty(); ++i) usleep(50000);
    c->waitForBankLoad();
    return c;
}
} // namespace

int phase(const std::string& dir, int step) {
    const std::string bank = dir + "/SILVETON_BANK.sv";
    ControllerEnv env;
    env.dataDir = dir + "/data";
    env.bankCandidates = {bank};
    auto c = startProgram(env, dir);
    if (step == 1) {   // first run: three blends in the LIST (pasted sounds = one blend each), then the middle one is deleted
        CHECK(c->soundCatalog().size() == 4U);
        int first = -1, count = 0;
        CHECK(!c->pasteSoundsToList({{1, "Grand Piano"}, {2, "Fretless Bass"}, {3, "Warm Pad"}}, 0, first, count));
        CHECK(count == 3);
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano", "Fretless Bass", "Warm Pad"}));
        CHECK(c->deleteLiveListEntry(1));
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano", "Warm Pad"}));
    } else if (step == 2) {   // the program is started again: the deleted blend must not be back; DELETE with its sounds (the LIST menu)
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano", "Warm Pad"}));
        const auto places = c->soundsOnlyInListEntry(2);   // position 3 = "Warm Pad" (position 2 is the empty one)
        std::vector<int> p;
        for (const auto& sp : places) p.push_back(sp.first);
        CHECK(!c->deleteListEntryWithSounds(2, p));
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano"}));
    } else if (step == 3) {
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano"}));
        // the sound of the deleted blend must not be back either ("като пусна наново програмата да не се появяват пак")
        CHECK(catalogNames(*c) == "Grand Piano,Fretless Bass,Accordion");
    } else if (step == 4) {
        // SILVETON_LIST_DELETE_GHOST_V1 ("като изтрия бленда да изчезва и нейният саунд"): in step 1 the blend "Fretless Bass" was taken off
        // the LIST by the plain DELETE, which keeps the blend itself in BLENDS (a ghost). It must not keep its sound alive: the same sound
        // put on the LIST again and deleted must leave with its blend.
        int first = -1, count = 0;
        CHECK(!c->pasteSoundsToList({{2, "Fretless Bass"}}, 1, first, count));
        CHECK(count == 1);
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano", "Fretless Bass"}));
        const auto leaving = c->soundsOnlyInListEntry(first);
        CHECK(leaving.size() == 1U && leaving[0].first == 2 && leaving[0].second == "Fretless Bass");
        CHECK(!c->deleteListEntryWithSounds(first, {leaving[0].first}));
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano"}));
        CHECK(catalogNames(*c) == "Grand Piano,Accordion");
    } else {
        CHECK(listNames(*c) == (std::vector<std::string>{"Grand Piano"}));
        CHECK(catalogNames(*c) == "Grand Piano,Accordion");   // both deleted sounds stay out after another start
    }
    c->close();
    return 0;
}

// Every start of the program is a new process (the sound engine is one per process): the test runs itself three times.
int main(int argc, char** argv) {
    if (argc >= 3) return phase(argv[1], std::atoi(argv[2]));
    char tmpl[] = "/tmp/imak-list-persist-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string dir = tmpl;
    writeBank(dir + "/SILVETON_BANK.sv", {"Grand Piano", "Fretless Bass", "Warm Pad", "Accordion"});
    for (int step = 1; step <= 5; ++step) {
        const std::string cmd = std::string("\"") + argv[0] + "\" \"" + dir + "\" " + std::to_string(step);
        const int rc = std::system(cmd.c_str());
        if (rc != 0) { std::fprintf(stderr, "FAILED: start %d of the program (exit %d)\n", step, rc); return 1; }
    }
    std::printf("list persist test OK\n");
    return 0;
}
