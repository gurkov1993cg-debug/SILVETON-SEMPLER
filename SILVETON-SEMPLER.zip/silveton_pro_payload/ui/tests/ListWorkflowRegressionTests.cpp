// Exercise clipboard contents, whole LIST edits, persistence rollback, and real touch controls.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SamplerTypes.h"

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <unistd.h>

namespace {
int checks = 0;
#define CHECK(x) do { ++checks; if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)
using Controller = silveton::ui::SamplerAppController;
using View = silveton::ui::classic::SilvetonSamplerView;
const std::vector<std::string> names{"Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrot"};

std::vector<std::string> listNames(Controller& c) {
    std::vector<std::string> out;
    for (const auto& row : c.listItems(0, 0, 0)) out.push_back(c.isEmptyListItem(row) ? "-" : row.name);
    return out;
}

void seed(Controller& c) {
    CHECK(c.engine.nativeClearPerformance());
    c.engine.nativeClearList(0, 0, 0);
    for (int slot = 1; slot <= 500; ++slot) c.engine.nativeClearCombi(0, 0, slot);
    CHECK(c.engine.nativeAssignUpperSound(0, 0, 9001, 0));
    std::vector<int> numbers, addresses;
    for (int i = 0; i < 6; ++i) {
        CHECK(c.engine.nativeUpdateUpperTune(0, 0, 0, static_cast<float>(i * 100), 2, 0.0F));
        CHECK(c.engine.nativeWriteCombi(0, 0, i + 1, names[static_cast<std::size_t>(i)]));
        numbers.push_back(i + 1);
        addresses.insert(addresses.end(), {0, 0, i + 1});
    }
    CHECK(c.engine.nativeWriteList(0, 0, 0, "LIVE", numbers, names, addresses));
    c.saveListFavourites({1, 3});
    CHECK(c.activateListEntry(0, 0, 0, 0));
}

void copySnapshot(Controller& c) {
    seed(c);
    CHECK(c.activateListEntry(0, 0, 0, 1));
    std::vector<float> scale(12U, 0.0F); scale[4] = -37.5F;
    c.setScale(scale, "COPY SCALE", 2);
    c.setScaleTarget(0, true);
    c.setScaleEnabled(true);
    CHECK(c.writeCombiToList(1, "Bravo") == 1);
    Controller::ListClipboard clip;
    CHECK(c.captureListClipboard({1}, false, clip));
    CHECK(clip.combis[0]->uppers[0].tuneCents == 100.0F);
    CHECK(clip.combis[0]->scale.cents[4] == -37.5F);
    CHECK(c.engine.nativeUpdateUpperTune(0, 0, 0, 900.0F, 2, 0.0F));
    c.setScaleNote(4, 12.25F);
    CHECK(c.writeCombiToList(1, "Bravo changed") == 1);
    CHECK(c.engine.nativeStoredCombi(0, 0, 2)->uppers[0].tuneCents == 900.0F);
    int first = -1;
    CHECK(c.pasteListClipboard(clip, 0, first));
    CHECK(first == 0);
    auto rows = c.listItems(0, 0, 0);
    const int firstSlot = rows[0].combiSlot;
    const auto stored = c.engine.nativeStoredCombi(0, 0, firstSlot);
    CHECK(rows[0].name == "Bravo" && firstSlot != 2);
    CHECK(stored->uppers[0].tuneCents == 100.0F);
    CHECK(stored->scale.cents[4] == -37.5F && stored->scale.tonic == 2 && stored->scale.enabled);
    CHECK(c.activeListEntry(0, 0, 0) == 2);
    CHECK(c.engine.nativeUpperState(0).at(12) == 900.0F);
    CHECK(c.pasteListClipboard(clip, 7, first));
    rows = c.listItems(0, 0, 0);
    const int secondSlot = rows[7].combiSlot;
    CHECK(secondSlot != firstSlot && secondSlot != 2);
    CHECK(c.activateListEntry(0, 0, 0, 0));
    CHECK(c.engine.nativeUpdateUpperTune(0, 0, 0, 350.0F, 2, 0.0F));
    CHECK(c.writeCombiToList(0, "First copy changed") == 0);
    CHECK(c.engine.nativeStoredCombi(0, 0, secondSlot)->uppers[0].tuneCents == 100.0F);
    CHECK(clip.combis[0]->uppers[0].tuneCents == 100.0F);
    std::puts("PASS COPY freezes sound, engine and scale; repeated PASTE creates independent blends");
}

void reorder(Controller& c) {
    seed(c);
    CHECK(c.activateListEntry(0, 0, 0, 2));
    CHECK(c.engine.nativeUpdateUpperTune(0, 0, 0, 777.0F, 2, 0.0F));
    CHECK(c.blendEdited());
    Controller::ListClipboard cut;
    CHECK(c.captureListClipboard({1, 3}, true, cut));
    int first = -1;
    CHECK(c.pasteListClipboard(cut, 2, first));
    CHECK(listNames(c) == (std::vector<std::string>{"Alpha", "Charlie", "Bravo", "Delta", "Echo", "Foxtrot"}));
    CHECK(c.listFavourites() == (std::set<int>{2, 3}));
    CHECK(c.activeListEntry(0, 0, 0) == 1);
    CHECK(c.engine.nativeUpperState(0).at(12) == 777.0F && c.blendEdited());
    CHECK(c.captureListClipboard({2, 3}, true, cut));
    CHECK(c.pasteListClipboard(cut, 3, first));
    CHECK(listNames(c) == (std::vector<std::string>{"Alpha", "Charlie", "Echo", "Bravo", "Delta", "Foxtrot"}));
    CHECK(c.listFavourites() == (std::set<int>{3, 4}));
    CHECK(c.activeListEntry(0, 0, 0) == 1);
    CHECK(c.combiCatalog().size() == 6U);
    CHECK(c.captureListClipboard({3}, true, cut));
    CHECK(c.renameLiveListEntry(3, "Renamed source"));
    const auto before = listNames(c);
    CHECK(!c.pasteListClipboard(cut, 0, first));
    CHECK(listNames(c) == before);
    std::puts("PASS block MOVE and overlapping destination preserve neighbours, favourites and edited live audio");
}

void fullList(Controller& c) {
    seed(c);
    std::vector<int> numbers, addresses;
    std::vector<std::string> labels;
    for (int i = 0; i < 200; ++i) {
        numbers.push_back(i + 1); labels.push_back("Blend " + std::to_string(i + 1));
        addresses.insert(addresses.end(), {0, 0, 1});
    }
    CHECK(c.engine.nativeWriteList(0, 0, 0, "LIVE", numbers, labels, addresses));
    Controller::ListClipboard clip;
    CHECK(c.captureListClipboard({0}, false, clip));
    const std::size_t combis = c.combiCatalog().size();
    int first = -1;
    CHECK(!c.pasteListClipboard(clip, 0, first));
    CHECK(listNames(c) == labels && c.combiCatalog().size() == combis);
    CHECK(c.captureListClipboard({0}, true, clip));
    CHECK(c.pasteListClipboard(clip, 199, first));
    auto after = listNames(c);
    CHECK(after.size() == 200U && after.front() == "Blend 2" && after.back() == "Blend 1");
    CHECK(c.captureListClipboard({0, 1, 2}, true, clip));
    CHECK(!c.pasteListClipboard(clip, 199, first));
    CHECK(listNames(c) == after);
    std::puts("PASS full LIST: COPY fails without changes, MOVE remains available, end boundaries are checked");
}

void rollback(Controller& c, const std::string& dir) {
    seed(c);
    CHECK(c.activateListEntry(0, 0, 0, 3));
    Controller::ListClipboard copy, cut;
    CHECK(c.captureListClipboard({1, 4}, false, copy));
    CHECK(c.captureListClipboard({1, 4}, true, cut));
    const auto before = listNames(c);
    const auto favourites = c.listFavourites();
    const auto combis = c.combiCatalog();
    const std::string moved = dir + ".blocked";
    CHECK(std::rename(dir.c_str(), moved.c_str()) == 0);
    { std::ofstream blocked(dir); blocked << "not a directory"; }
    int first = -1;
    CHECK(!c.pasteListClipboard(copy, 2, first));
    CHECK(listNames(c) == before && c.listFavourites() == favourites);
    CHECK(c.combiCatalog() == combis && c.activeListEntry(0, 0, 0) == 3);
    CHECK(!c.pasteListClipboard(cut, 0, first));
    CHECK(listNames(c) == before && c.listFavourites() == favourites);
    CHECK(!c.renameLiveListEntry(0, "Must not survive"));
    CHECK(listNames(c) == before);
    CHECK(!c.deleteLiveListEntries({1, 3}));
    CHECK(listNames(c) == before && c.activeListEntry(0, 0, 0) == 3);
    CHECK(std::remove(dir.c_str()) == 0);
    CHECK(std::rename(moved.c_str(), dir.c_str()) == 0);
    CHECK(c.pasteListClipboard(cut, 0, first));
    CHECK(first == 0 && listNames(c).at(0) == "Bravo" && listNames(c).at(1) == "Echo");
    std::puts("PASS failed save rolls back copy/move/rename/group delete; CUT is retryable and keeps sources");
}
} // namespace

namespace silveton::ui::classic {
struct ViewTestAccess {
    static void list(View& v) { v.setPage(View::Page::LIST); v.refreshAllForTests(); }
    static bool marking(const View& v) { return v.listMarkMode_; }
    static std::size_t marked(const View& v) { return v.listMarked_.size(); }
    static bool destination(const View& v) { return v.listPasteMode_; }
    static bool copied(const View& v) { return static_cast<bool>(v.pasteAction_); }
    static void name(View& v, const std::string& text) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        d->value = text;
        d->cursor = static_cast<int>(text.size());
        d->selectAll = false;
        v.dialogFire(d, d->buttons.back().action);
    }
};
} // namespace silveton::ui::classic

namespace {
void touchWorkflow(Controller& c) {
    seed(c);
    View view(c);
    silveton::ui::Canvas canvas(1340, 800);
    using A = silveton::ui::classic::ViewTestAccess;
    A::list(view);
    const auto draw = [&]() { view.draw(canvas); };
    const auto tap = [&](float x, float y) {
        view.pointer(View::PointerAction::Down, x, y);
        view.pointer(View::PointerAction::Up, x, y);
        draw();
    };
    draw();
    tap(250.0F, 120.0F); // SELECT
    CHECK(A::marking(view) && A::marked(view) == 0U);
    view.pointer(View::PointerAction::Down, 140.0F, 224.0F);
    view.pointer(View::PointerAction::Move, 670.0F, 224.0F);
    view.pointer(View::PointerAction::Up, 670.0F, 224.0F);
    draw();
    CHECK(A::marked(view) == 3U);
    CHECK(c.activeListEntry(0, 0, 0) == 0 && c.combiName() == "Alpha");
    tap(360.0F, 120.0F); // COPY
    CHECK(A::destination(view) && A::copied(view));
    CHECK(!A::marking(view));
    tap(250.0F, 120.0F); // CANCEL destination, retain clipboard
    CHECK(!A::destination(view) && A::copied(view));
    CHECK(listNames(c) == names);
    tap(560.0F, 120.0F); // PASTE
    tap(930.0F, 224.0F); // chosen position 4 was Delta; it shifts, never loads
    CHECK(!A::destination(view) && A::copied(view));
    CHECK(c.activeListEntry(0, 0, 0) == 0 && c.combiName() == "Alpha");
    CHECK(listNames(c) == (std::vector<std::string>{"Alpha", "Bravo", "Charlie", "Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrot"}));
    tap(680.0F, 120.0F); // RENAME the selected pasted item
    A::name(view, "Pasted Alpha"); draw();
    CHECK(c.listItems(0, 0, 0).at(3).name == "Pasted Alpha");
    tap(460.0F, 120.0F); // CUT
    CHECK(A::destination(view));
    const auto before = listNames(c);
    tap(250.0F, 120.0F); // cancel has no delete side effect
    CHECK(listNames(c) == before && A::copied(view));
    std::puts("PASS real touch SELECT/drag, COPY, CANCEL, repeated PASTE, RENAME and CUT preserve live recall");
}
} // namespace

int main(int argc, char** argv) {
    try {
        CHECK(argc == 2);
        silveton::ui::setFontDirectory(argv[1]);
        CHECK(silveton::ui::fontsReady());
        char temp[] = "/tmp/silveton-list-workflow-XXXXXX";
        CHECK(::mkdtemp(temp) != nullptr);
        silveton::ui::ControllerEnv env; env.dataDir = temp;
        Controller controller(env);
        copySnapshot(controller);
        reorder(controller);
        fullList(controller);
        rollback(controller, temp);
        touchWorkflow(controller);
        controller.close();
        std::printf("LIST workflow: %d checks, 5 groups passed\n", checks);
        return 0;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "FAIL LIST workflow: %s\n", e.what());
        return 1;
    }
}
