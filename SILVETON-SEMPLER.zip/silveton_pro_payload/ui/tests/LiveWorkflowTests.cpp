// Real hit callbacks exercise the shared LIVE / SAVE / SCALE navigation.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SetPackage.h"

#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;
#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct ViewTestAccess {
    static void live(View& v) { v.goPage(View::Page::COMBI, View::MODE_LIVE); }
    static bool tap(View& v, float x, float y) {
        const auto h = v.hitAt(x, y);
        if (!h || !h->tap) return false;
        const auto action = h->tap;
        action(x, y);
        return true;
    }
    static bool saveOpen(const View& v) { return v.saveOpen_; }
    static bool scaleOpen(const View& v) { return v.scaleOpen_; }
    static bool storeMode(const View& v) { return v.listStoreMode_; }
    static bool soundEdit(const View& v) { return v.page_ == View::Page::COMBI && v.combiMode_ == View::MODE_EDIT; }
    static int soundSlot(const View& v) { return v.editSound; }
    static void select(View& v, int part, int sound = 0) { v.selectedUpper_ = part; v.stripSound.at(static_cast<std::size_t>(part)) = sound; }
    static void setName(View& v, const std::string& name) { v.setsName_ = name; }
    static std::string label(View& v) { return v.openBlendLabel(); }
    static void activate(View& v, int position) {
        v.loadedFromList = position; v.cachedActiveListEntry = position; v.listSelected = position;
        v.refreshListCache(); v.refreshAllForTests();
    }
    static bool marking(const View& v) { return v.markMode; }
    static void mark(View& v) { v.markMode = true; v.linkOn = true; v.marked[0] = true; v.marked[1] = true; }
    static bool linked(const View& v) { return v.linkOn; }
    static void startScaleScan(View& v) { v.sampler.startScaleScan(); v.scanMode = v.sampler.pollScan(); }
    static void confirm(View& v, const std::string& label) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        for (const auto& button : d->buttons) if (button.label == label) {
            v.dialogFire(d, button.action); return;
        }
        CHECK(false);
    }
};
} // namespace silveton::ui::classic

namespace {
using A = classic::ViewTestAccess;
struct Fixture {
    std::string directory;
    ControllerEnv env;
    SamplerAppController controller;
    View view;
    Canvas canvas{1340, 800};
    static std::string temp() {
        char name[] = "/tmp/imak-live-workflow-XXXXXX";
        CHECK(::mkdtemp(name) != nullptr);
        return name;
    }
    static ControllerEnv environment(const std::string& p) { ControllerEnv e; e.dataDir = p; return e; }
    Fixture() : directory(temp()), env(environment(directory)), controller(env), view(controller) {
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 0));
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9002, 1));
        CHECK(controller.writeCombiToList(7, "LIVE TEST") == 7);
        A::activate(view, 7);
        A::live(view);
        draw();
    }
    void draw() { view.draw(canvas); }
    void tap(float x, float y) { CHECK(A::tap(view, x, y)); draw(); }
};

void scaleAndBack() {
    Fixture f;
    const auto original = f.controller.engine.nativeUpperState(0);
    f.tap(1030.0F, 466.0F); // explicit Arabic-scale shortcut
    CHECK(A::scaleOpen(f.view) && f.view.dialogOpen());
    CHECK(f.view.page() == View::Page::COMBI);
    CHECK(original == f.controller.engine.nativeUpperState(0));
    f.view.keyDown(View::Key::Escape); f.draw();
    CHECK(!A::scaleOpen(f.view) && !f.view.dialogOpen());
    CHECK(f.view.page() == View::Page::COMBI);
    f.tap(1030.0F, 466.0F); A::startScaleScan(f.view);
    CHECK(f.controller.pollScan() == 2); f.draw();
    f.tap(906.0F, 46.0F); // leaving for SAVE must not leave MIDI scan armed
    CHECK(A::saveOpen(f.view) && f.controller.pollScan() == 0);
    f.view.keyDown(View::Key::Escape); f.draw();
    f.tap(1030.0F, 466.0F); A::startScaleScan(f.view); f.draw();
    f.tap(109.0F, 746.0F); // leaving through global LIVE navigation does the same
    CHECK(!A::scaleOpen(f.view) && f.controller.pollScan() == 0);
    // The ON key with no assigned part leads to assignment instead of doing nothing.
    for (int u = 0; u < 15; ++u) f.controller.setScaleTarget(u, false);
    f.draw(); f.tap(1220.0F, 466.0F);
    CHECK(A::scaleOpen(f.view));
    f.view.keyDown(View::Key::Escape); f.draw();
    f.controller.setScaleTarget(0, true);
    f.controller.setScaleEnabled(false); f.draw();
    f.tap(1220.0F, 466.0F); CHECK(f.controller.scaleMasterOn());
    f.tap(1220.0F, 466.0F); CHECK(!f.controller.scaleMasterOn());
}

void saveScope() {
    Fixture f;
    auto& n = f.controller.engine;
    CHECK(n.nativeUpdateUpperTune(0, 0, 0, 350.0F, 2, 0.0F));
    f.view.refreshAllForTests(); f.draw();
    f.tap(906.0F, 46.0F); CHECK(A::saveOpen(f.view));
    CHECK(f.view.dialogOpen());
    A::setName(f.view, "WORKFLOW-SET"); f.draw();
    f.tap(980.0F, 422.0F); // actual SAVE SET FILE button
    const auto set = silveton::sampler::SetPackage::load(f.directory + "/WORKFLOW-SET.SVSET");
    CHECK(set.ok() && set.data.performance.has_value());
    CHECK(set.data.performance->combi.uppers[0].tuneCents == 350.0F);
    CHECK(set.data.combis.at(0).combi.uppers[0].tuneCents != 350.0F);
    CHECK(n.nativeBlendEdited()); // SET did not silently WRITE the LIST blend
    f.tap(310.0F, 422.0F); // UPDATE CURRENT LIST POSITION
    CHECK(!n.nativeBlendEdited());
    CHECK(n.nativeActivateListEntry(0, 0, 0, 7));
    CHECK(n.nativeUpperState(0).at(12) == 350.0F);
    f.draw(); f.tap(310.0F, 510.0F); // SAVE TO LIST
    CHECK(!A::saveOpen(f.view) && A::storeMode(f.view) && f.view.page() == View::Page::LIST);
    CHECK(f.view.dialogOpen());
    f.view.keyDown(View::Key::Escape); f.draw();
    CHECK(!A::storeMode(f.view));
    CHECK(n.nativeActiveListEntry(0, 0, 0) == 7);
}

void liveTargets() {
    Fixture f;
    auto& n = f.controller.engine;
    CHECK(n.nativeUpdateUpperTune(0, 1, 0, 31.0F, 2, 0.0F));
    f.view.refreshAllForTests();
    A::select(f.view, 0); f.draw(); f.tap(441.0F, 466.0F); // COPY PART
    A::select(f.view, 1); f.draw(); f.tap(581.0F, 466.0F); // PASTE PART
    A::confirm(f.view, "PASTE PART"); f.draw();
    CHECK(n.nativeUpperState(1).at(12) == 31.0F);
    A::select(f.view, 1, 3); f.draw(); f.tap(285.0F, 466.0F);
    CHECK(A::soundEdit(f.view) && A::soundSlot(f.view) == 3);
    A::mark(f.view); A::live(f.view); CHECK(!A::marking(f.view) && !A::linked(f.view)); f.draw();
    const auto first = f.controller.globalUiState(); CHECK(first);
    // Two callbacks before a redraw must both take effect.
    CHECK(A::tap(f.view, 792.0F, 466.0F)); CHECK(A::tap(f.view, 792.0F, 466.0F));
    CHECK(f.controller.globalUiState()->transpose == first->transpose + 2);
    f.draw(); f.tap(682.0F, 466.0F);
    CHECK(f.controller.globalUiState()->transpose == first->transpose + 1);
    CHECK(f.controller.renameLiveListEntry(7, "RENAMED ON LIST"));
    A::activate(f.view, 7);
    CHECK(A::label(f.view) == "RENAMED ON LIST");
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    setFontDirectory(argv[1]); if (!fontsReady()) return 2;
    struct Test { const char* name; void (*run)(); };
    const Test tests[] = {
        {"LIVE scale access, scope toggle and Android Back", scaleAndBack},
        {"SAVE hub distinguishes one blend and complete SET", saveScope},
        {"LIVE copy targets, selected sound, transpose and renamed label", liveTargets}
    };
    int failed = 0;
    for (const auto& test : tests) {
        try { test.run(); std::printf("PASS %s\n", test.name); }
        catch (const std::exception& e) { ++failed; std::fprintf(stderr, "FAIL %s: %s\n", test.name, e.what()); }
    }
    return failed ? 1 : 0;
}
