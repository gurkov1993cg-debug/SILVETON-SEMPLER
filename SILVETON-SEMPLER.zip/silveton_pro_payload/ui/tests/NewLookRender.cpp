// SILVETON_NEW_LOOK_V1 - draws the screens of the NEW LOOK (classic view) with demo sounds into PNG pictures.
// Usage: imak_ui_newlook <fonts dir> <output dir>
#include "silveton/host/HostIo.h"
#include "silveton/sampler/SvBankFormat.h"
#include "silveton/sampler/SuseTools.h"
#include "silveton/sampler/ModelDefs.h"
#include "ModelFixtures.h"
#include "silveton/ui/classic/SilvetonSamplerView.h"
#ifdef IMAK_GL_COMPARE
#include "GlRenderer.h"
#endif

#include <algorithm>
#include <cmath>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <set>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::ui;
namespace sv = silveton::sampler;

namespace silveton::ui::classic {
// the test reaches inside the view to open screens and dialogs
struct NewLookAccess {
    using V = SilvetonSamplerView;
    static void live(V& v) { v.page_ = V::Page::COMBI; v.combiMode_ = V::MODE_LIVE; v.invalidate(); }
    static void mixer(V& v) { v.page_ = V::Page::COMBI; v.combiMode_ = V::MODE_MIXER; v.invalidate(); }
    static void edit(V& v, int group, int upper = 0, int sound = 0) {
        v.page_ = V::Page::COMBI; v.combiMode_ = V::MODE_EDIT; v.editGroup_ = group; v.selectedUpper_ = upper; v.editSound = sound; v.invalidate();
    }
    static void placeTab(V& v, int t) { v.placeTab_ = t; v.invalidate(); }
    static void engineUpper(V& v, int upper) { v.engUpper_ = upper; v.selectedUpper_ = upper; v.page_ = V::Page::ENGINES; v.invalidate(); }
    static void engine(V& v, int slot) { v.selectedUpper_ = 0; v.engSlot_ = slot; v.page_ = V::Page::ENGINES; v.invalidate(); }
    static void settingsTab(V& v, int t) { v.page_ = V::Page::SETTINGS; v.settingsTab = t; v.invalidate(); }
    static void color(V& v, int k) { v.applyColor(k, false); }
    static void listAction(V& v, int idx, int which) { v.listRowAction(idx, which); }
    static bool hasOffer(V& v) { return static_cast<bool>(v.pasteAction_); }
    static void paste(V& v, int idx) { const auto act = v.pasteAction_; if (act) act(idx); }
    static bool listHas(V& v, int idx) { return v.realListItem(idx).has_value(); }
    static std::string listName(V& v, int idx) { const auto it = v.realListItem(idx); return it ? it->name : std::string(); }
    static int colorKey(V& v) { return v.colorKey_; }
    static void listPage(V& v) { v.page_ = V::Page::LIST; v.invalidate(); }
    static void closeDialogs(V& v) { v.dialogStack.clear(); v.writeOpen = false; v.picker.reset(); v.invalidate(); }
    static void numberDialog(V& v) { v.showNumber("UPPER 1 LEVEL dB", -3.5F, -60.0F, 12.0F, 1, [](float) {}); }
    static void textDialog(V& v) { v.showTextPage("NAME", "Grand Piano", [](const std::string&) {}); }
    static void openStore(V& v) { v.openStore(); }
    static bool onList(V& v) { return v.page_ == V::Page::LIST; }
    static bool onEngines(V& v) { return v.page_ == V::Page::ENGINES; }
    static bool storeMode(V& v) { return v.listStoreMode_; }
    static int engUpper(V& v) { return v.engUpper_; }
    static int upperEngine(V& v, int u) { return static_cast<int>(std::lround(v.engineP(u, 0))); }
    static void applyDialog(V& v) {   // the right-hand button of the top dialog (APPLY / OVERWRITE)
        if (v.dialogStack.empty()) return;
        const auto d = v.dialogStack.back();
        v.dialogFire(d, d->buttons.back().action);
    }
    static int listPageNo(V& v) { return v.listPage; }
    static bool markMode(V& v) { return v.listMarkMode_; }
    static bool scaleOpen(V& v) { return v.scaleOpen_; }
    static int scaleSel(V& v) { return v.scaleSel_; }
    static int scaleTop(V& v) { return v.scaleOwnTop_; }
    static std::size_t dialogDepth(V& v) { return v.dialogStack.size(); }
    static void setDialogText(V& v, const std::string& t) { if (!v.dialogStack.empty()) { v.dialogStack.back()->value = t; v.dialogStack.back()->cursor = static_cast<int>(t.size()); v.dialogStack.back()->selectAll = false; } }
    static int gridCurrent(V& v) { return v.dialogStack.empty() ? -2 : v.dialogStack.back()->gridCurrent; }
    static std::size_t markedCount(V& v) { return v.listMarked_.size(); }
    static void setListPage(V& v, int p) { v.listPage = p; v.invalidate(); }
    static void openPicker(V& v, int upper) { v.openPicker(upper, 0); }
    static void listMenu(V& v, int idx) { const auto it = v.realListItem(idx); if (it) v.showListContextMenu(idx, *it); }
    static void tap(V& v, float x, float y) { v.pointer(V::PointerAction::Down, x, y); v.pointer(V::PointerAction::Up, x, y); }
    static void confirm(V& v) { v.showConfirm("DELETE LIST 037", "\"Grand Piano + Strings\" will be removed from the LIST.", "DELETE", [] {}, "CANCEL"); }
    static void message(V& v) { v.showMessage("MISSING SOUNDS", "These sounds are not in the bank:\nUPPER 2 · slot 044\nUPPER 5 · slot 120\n… and 1 more"); }
    static std::vector<std::shared_ptr<V::Hit>> hitList(V& v) { return v.hits; }
    static std::shared_ptr<V::Hit> hitAt(V& v, float x, float y) { return v.hitAt(x, y); }
    static void drag(V& v, float x, float y, float dx, float dy) {
        v.pointer(V::PointerAction::Down, x, y);
        for (int k = 1; k <= 6; ++k) v.pointer(V::PointerAction::Move, x + dx * static_cast<float>(k) / 6.0F, y + dy * static_cast<float>(k) / 6.0F);
        v.pointer(V::PointerAction::Up, x + dx, y + dy);
    }
    static int pageNo(V& v) { return static_cast<int>(v.page_) * 100 + v.combiMode_ * 10 + v.editGroup_; }
    static bool dialogOpen(V& v) { return !v.dialogStack.empty() || v.writeOpen; }
};
} // namespace silveton::ui::classic

namespace {
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

void writeBank(const std::string& path, const std::vector<std::string>& names, int frames = 8) {
    std::vector<std::uint8_t> strings{0U};
    auto addString = [&](const std::string& text) -> std::uint32_t {
        const auto offset = static_cast<std::uint32_t>(strings.size());
        strings.insert(strings.end(), text.begin(), text.end());
        strings.push_back(0U);
        return offset;
    };
    const auto bankName = addString("DEMO BANK");
    const auto sampleName = addString("DEMO SAMPLE");
    const auto sampleIdentity = addString("sample://demo");
    const auto msName = addString("DEMO MULTI");
    const auto msIdentity = addString("multi://demo");
    std::vector<std::uint8_t> sounds, layers, multis, samples, zones, audio;
    for (std::size_t i = 0U; i < names.size(); ++i) {
        sv::SvSoundRecord sound{};
        sound.nameOffset = addString(names[i]);
        sound.firstLayer = static_cast<std::uint32_t>(i);
        sound.layerCount = 1U;
        sound.soundSlotId = static_cast<std::uint32_t>(i + 1U);
        sv::appendSoundRecord(sounds, sound);
        sv::SvSoundLayerRecord layer{};
        layer.multisampleId = 4000001U; layer.enabled = 1U; layer.keyLow = 0U; layer.keyHigh = 127U; layer.velocityLow = 1U; layer.velocityHigh = 127U;
        sv::appendSoundLayerRecord(layers, layer);
    }
    sv::SvMultisampleRecord ms{};
    ms.multisampleId = 4000001U; ms.nameOffset = msName; ms.sourceIdentityOffset = msIdentity; ms.firstZone = 0U; ms.zoneCount = 1U;
    sv::appendMultisampleRecord(multis, ms);
    sv::SvSampleRecord sample{};
    sample.sampleId = 3000001U; sample.nameOffset = sampleName; sample.sourceIdentityOffset = sampleIdentity; sample.sampleRate = 48000U; sample.channels = 1U;
    sample.encoding = 1U; sample.bitsPerSample = 16U; sample.rootKey = 60U; sample.totalFrames = static_cast<std::uint32_t>(frames); sample.audioOffset = 0U; sample.audioSize = static_cast<std::uint64_t>(frames) * 2U;
    sv::appendSampleRecord(samples, sample);
    sv::SvZoneRecord zone{};
    zone.sampleId = 3000001U; zone.keyLow = 0U; zone.keyHigh = 127U; zone.velocityLow = 1U; zone.velocityHigh = 127U; zone.rootKey = 60U;
    sv::appendZoneRecord(zones, zone);
    const std::int16_t pcm[8] = {0, 8192, -8192, 16384, -16384, 32767, -32768, 4096};
    for (int i = 0; i < frames; ++i) {
        // 8 frames = the first toy sample; a longer one (the bank swap of the 01.11.2026 scenes) is a soft sine the bank check can hear
        const std::int16_t v = frames == 8 ? pcm[i] : static_cast<std::int16_t>(std::lround(12000.0 * std::sin(6.283185307179586 * 261.6 * i / 48000.0)));
        const auto u = static_cast<std::uint16_t>(v);
        audio.push_back(static_cast<std::uint8_t>(u & 0xFFU));
        audio.push_back(static_cast<std::uint8_t>((u >> 8U) & 0xFFU));
    }
    sv::SvBankHeader header{};
    header.bankNameOffset = bankName;
    header.soundCount = static_cast<std::uint32_t>(names.size());
    header.soundLayerCount = static_cast<std::uint32_t>(names.size());
    header.multisampleCount = 1U; header.sampleCount = 1U; header.zoneCount = 1U;
    std::vector<std::uint8_t> file(sv::kSvBankHeaderSize, 0U);
    auto appendSec = [&](sv::SvSection section, const std::vector<std::uint8_t>& data) {
        auto& d = header.sections[static_cast<std::size_t>(section)];
        d.offset = static_cast<std::uint64_t>(file.size());
        d.size = static_cast<std::uint64_t>(data.size());
        file.insert(file.end(), data.begin(), data.end());
    };
    appendSec(sv::SvSection::Sounds, sounds); appendSec(sv::SvSection::SoundLayers, layers); appendSec(sv::SvSection::Multisamples, multis);
    appendSec(sv::SvSection::Samples, samples); appendSec(sv::SvSection::Zones, zones); appendSec(sv::SvSection::Strings, strings); appendSec(sv::SvSection::Audio, audio);
    header.fileSize = static_cast<std::uint64_t>(file.size());
    header.payloadSha256 = sv::sha256(file.data() + sv::kSvBankHeaderSize, file.size() - sv::kSvBankHeaderSize);
    const auto serialized = sv::serializeHeader(header);
    std::copy(serialized.begin(), serialized.end(), file.begin());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(file.data()), static_cast<std::streamsize>(file.size()));
}

std::string g_out;
bool g_fast = false;   // profiling: one picture per screen

// "Light drawing" on the real screens: the picture kept by the FrameRenderer (only the changed parts drawn again) must be
// exactly the picture that drawing the recorded operations completely gives.
FrameRenderer g_light(1340, 800);
long long g_lightPictures = 0, g_lightRepainted = 0, g_lightIdlePictures = 0, g_lightIdleRepainted = 0;
double g_lightIdleMs = 0.0;
void checkLight(classic::SilvetonSamplerView& view, const std::string& name) {
    for (int i = 0; i < 4; ++i) {   // the first picture after a change of screen, then the ones that follow while nothing is touched
        const auto t0 = std::chrono::steady_clock::now();
        g_light.update([&](Canvas& c) { view.draw(c); });
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        Canvas full(1340, 800);
        full.replay(g_light.lastList(), IRect(0, 0, 1340, 800));
        long long different = 0;
        for (std::size_t k = 0U; k < full.buffer().size(); ++k) if (full.buffer()[k] != g_light.picture().buffer()[k]) ++different;
        if (different != 0) std::fprintf(stderr, "light drawing: %s picture %d: %lld pixels differ\n", name.c_str(), i, different);
        CHECK(different == 0);
        ++g_lightPictures;
        g_lightRepainted += g_light.lastRepaintedPixels();
        if (i > 0) { ++g_lightIdlePictures; g_lightIdleRepainted += g_light.lastRepaintedPixels(); g_lightIdleMs += ms; }
    }
}


#ifdef IMAK_GL_COMPARE
// SILVETON_GPU_DRAW_V1: the picture the video card draws from the recorded list must be the picture the software renderer draws
// from the same list (to within a rounding step). Needs EGL / OpenGL ES 3 at run time (Mesa's surfaceless platform on Linux).
std::unique_ptr<silveton::gl::GlRenderer> g_glRenderer;
FrameRenderer g_glRecorder(1340, 800);
void checkVideoCard(classic::SilvetonSamplerView& view, const std::string& name) {
    if (!g_glRenderer) {
        silveton::gl::GlRenderer::Options options;
        options.surfaceless = true;
        options.width = 1340;
        options.height = 800;
        std::string error;
        g_glRenderer = silveton::gl::GlRenderer::create(options, error);
        if (!g_glRenderer) { std::fprintf(stderr, "video card drawing: %s\n", error.c_str()); std::exit(3); }
        std::printf("video card: %s\n", g_glRenderer->info().c_str());
    }
    g_glRecorder.record([&](Canvas& c) { view.draw(c); });
    for (int pass = 0; pass < 2; ++pass) {   // the second time everything comes from the caches
        if (!g_glRenderer->render(g_glRecorder.lastList(), false)) { std::fprintf(stderr, "video card drawing %s: %s\n", name.c_str(), g_glRenderer->lastError().c_str()); std::exit(3); }
        std::vector<std::uint32_t> got;
        CHECK(g_glRenderer->readPixels(got));
        Canvas expected(1340, 800);
        expected.replay(g_glRecorder.lastList(), IRect(0, 0, 1340, 800));
        long long over = 0;
        int worst = 0;
        for (std::size_t k = 0U; k < got.size(); ++k) {
            int d = 0;
            for (unsigned shift = 0U; shift <= 24U; shift += 8U) d = std::max(d, std::abs(static_cast<int>((got[k] >> shift) & 255U) - static_cast<int>((expected.buffer()[k] >> shift) & 255U)));
            worst = std::max(worst, d);
            if (d > 8) ++over;
        }
        if (over != 0 || worst > 16) std::fprintf(stderr, "video card drawing: %s (pass %d): %lld pixels differ by more than 8, worst %d\n", name.c_str(), pass, over, worst);
        CHECK(over == 0 && worst <= 16);
    }
}
#endif

void shot(classic::SilvetonSamplerView& view, const std::string& name) {
    Canvas canvas(1340, 800);
    for (int i = 0; i < (g_fast ? 1 : 3); ++i) view.draw(canvas);   // a few frames: caches fill, telemetry arrives
    const auto t0 = std::chrono::steady_clock::now();
    const int timed = g_fast ? 1 : 5;
    for (int i = 0; i < timed; ++i) view.draw(canvas);
    const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / timed;
    CHECK(writePng(g_out + "/" + name + ".png", canvas));
    std::printf("wrote %s.png  (%.1f ms per picture)\n", name.c_str(), ms);
    checkLight(view, name);
#ifdef IMAK_GL_COMPARE
    checkVideoCard(view, name);
#endif
}

// ------------------------------------------------------------------------------------------------------------- TOUCH SWEEP
// Every key and knob registered on a screen is touched (a tap, or a drag for a knob) and the picture must change (or a dialog / another screen
// opens). A key that is covered by a later key (the last registered hit wins) is reported too.
std::uint64_t pictureHash(const Canvas& c) {
    std::uint64_t h = 1469598103934665603ULL;
    for (const auto px : c.buffer()) { h ^= px; h *= 1099511628211ULL; }
    return h;
}
void frame(classic::SilvetonSamplerView& v, int n = 2) { Canvas c(1340, 800); for (int i = 0; i < n; ++i) v.draw(c); }
std::uint64_t frameHash(classic::SilvetonSamplerView& v) { Canvas c(1340, 800); v.draw(c); v.draw(c); return pictureHash(c); }

int g_sweepDead = 0, g_sweepShadow = 0, g_sweepTested = 0;
void sweepScene(classic::SilvetonSamplerView& view, const std::string& name, const std::function<void()>& setup) {
    using A = classic::NewLookAccess;
    auto fresh = [&] { A::closeDialogs(view); A::color(view, 0); setup(); frame(view); };
    fresh();
    const auto hits0 = A::hitList(view);
    int dead = 0, shadow = 0;
    for (std::size_t i = 0U; i < hits0.size(); ++i) {
        const RectF r = hits0[i]->rect;
        if (r.width() < 3.0F || r.height() < 3.0F) continue;
        const float cx = r.centerX(), cy = r.centerY();
        if (cx < 0.0F || cy < 0.0F || cx > 1340.0F || cy > 800.0F) continue;
        fresh();
        const auto now = A::hitList(view);
        if (i >= now.size() || std::fabs(now[i]->rect.left - r.left) > 0.5F || std::fabs(now[i]->rect.top - r.top) > 0.5F || std::fabs(now[i]->rect.right - r.right) > 0.5F || std::fabs(now[i]->rect.bottom - r.bottom) > 0.5F) continue;   // the screen changed its keys: skip
        const auto top = A::hitAt(view, cx, cy);
        const bool sameRect = top && std::fabs(top->rect.left - r.left) < 0.5F && std::fabs(top->rect.top - r.top) < 0.5F && std::fabs(top->rect.right - r.right) < 0.5F && std::fabs(top->rect.bottom - r.bottom) < 0.5F;
        if (top && !sameRect) {
            const bool inside = top->rect.left >= r.left - 0.5F && top->rect.right <= r.right + 0.5F && top->rect.top >= r.top - 0.5F && top->rect.bottom <= r.bottom + 0.5F;
            if (!inside) { ++shadow; std::printf("  COVERED %-22s key (%.0f,%.0f)-(%.0f,%.0f) is under (%.0f,%.0f)-(%.0f,%.0f)\n", name.c_str(), r.left, r.top, r.right, r.bottom, top->rect.left, top->rect.top, top->rect.right, top->rect.bottom); }
            continue;   // the touch goes to the other one: that one has its own turn
        }
        const int pageBefore = A::pageNo(view);
        const std::uint64_t before = frameHash(view);
        const bool isKnob = static_cast<bool>(now[i]->drag);
        if (isKnob) A::drag(view, cx, cy, 0.0F, -40.0F); else A::tap(view, cx, cy);
        const bool changed = frameHash(view) != before || A::pageNo(view) != pageBefore || A::dialogOpen(view);
        ++g_sweepTested;
        if (!changed) {
            if (isKnob) {   // at its top end a knob does not go up; some move sideways or need a longer drag (graph points, small whole-number knobs)
                static const float tries[][2] = {{0.0F, 40.0F}, {40.0F, 0.0F}, {-40.0F, 0.0F}, {0.0F, -200.0F}, {0.0F, 200.0F}};
                bool moved = false;
                for (const auto& t : tries) {
                    fresh();
                    A::drag(view, cx, cy, t[0], t[1]);
                    if (frameHash(view) != before || A::dialogOpen(view)) { moved = true; break; }
                }
                if (moved) continue;
            }
            ++dead; std::printf("  NOTHING %-22s %s (%.0f,%.0f)-(%.0f,%.0f)\n", name.c_str(), isKnob ? "knob" : "key ", r.left, r.top, r.right, r.bottom);
        }
    }
    A::closeDialogs(view);
    g_sweepDead += dead; g_sweepShadow += shadow;
    std::printf("SWEEP %-22s keys %3zu  nothing-happens %d  covered %d\n", name.c_str(), hits0.size(), dead, shadow);
    std::fflush(stdout);
}
} // namespace

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: %s <fonts dir> <output dir>\n", argv[0]); return 2; }
    setFontDirectory(argv[1]);
    CHECK(fontsReady());
    g_out = argv[2];
    g_fast = true;
    char tmpl[] = "/tmp/imak-ui-newlook-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string dir = tmpl;
    const std::vector<std::string> names = {
        "Grand Piano", "Bright Piano", "Electric Piano", "Rhodes Tine", "Wurlitzer", "Clavinet", "Church Organ", "Rock Organ", "Warm Pad", "Soft Strings",
        "String Ensemble", "Brass Section", "Trumpet", "Alto Sax", "Flute", "Oboe", "Nylon Guitar", "Steel Guitar", "Fretless Bass", "Slap Bass",
        "Choir Aahs", "Vocal Ooh", "Marimba", "Vibraphone", "Harp", "Music Box", "Bell Tree", "Synth Lead", "Analog Bass", "Sweep Pad",
        "Kronos Piano Concert", "Sine Wave", "Saw Wave", "Square Wave", "Noise Wash", "Dulcimer", "Accordion", "Harmonica", "Banjo", "Sitar"};
    const std::string bank = dir + "/SILVETON_BANK.sv";
    writeBank(bank, names);

    ControllerEnv env;
    env.dataDir = dir + "/data";
    env.bankCandidates = {bank};
    SamplerAppController controller(env);
    auto manualMidi = std::make_unique<silveton::host::ManualMidiInput>();
    silveton::host::ManualMidiInput* midiIn = manualMidi.get();
    controller.engine.setBackends(std::make_unique<silveton::host::OfflineAudioOutput>(96000.0, 96U), std::move(manualMidi));
    CHECK(controller.start());
    for (int i = 0; i < 100 && controller.soundCatalog().empty(); ++i) usleep(50000);
    const auto catalog = controller.soundCatalog();
    CHECK(catalog.size() == names.size());

    const int pick[5] = {0, 8, 10, 18, 22};
    for (int u = 0; u < 5; ++u) {
        CHECK(controller.assignUpperSound(u, catalog[static_cast<std::size_t>(pick[u])]));
        auto s = controller.upperState(u);
        CHECK(s.has_value());
        SamplerAppController::UpperState n = *s;
        n.enabled = true;
        n.levelDb = u == 0 ? 0.0F : -2.0F * static_cast<float>(u);
        n.pan = u == 0 ? 0.0F : (u % 2 == 0 ? 0.35F : -0.35F);
        if (u == 3) { n.keyLow = 36; n.keyHigh = 59; }
        if (u == 1) { n.keyLow = 60; n.keyHigh = 127; }
        controller.updateUpperMain(u, n);
    }
    controller.setLayerSound(0, 0, catalog[10].slot);
    controller.setLayerSound(0, 1, catalog[9].slot);
    const int listPos[] = {0, 1, 2, 3, 6, 7, 12, 29, 30, 45};
    const char* listNames[] = {"Piano + Strings", "Warm Layers", "Concert Grand", "Rhodes Night", "Church Pad", "Brass Stab", "Soft Organ", "Last of page 1", "First of page 2", "Page 2 pad"};
    for (int i = 0; i < 10; ++i) CHECK(controller.writeCombiToList(listPos[i], listNames[i]) >= 0);

    {   // SILVETON_MODELS_FROM_FILE_V1: nothing is built into the sampler - the 11 test sounds come as a SILVETON_OSC.sv next to the bank
        const std::vector<std::uint8_t> m = silveton::sampler::model::fixtureModelFileBytes();
        { std::ofstream o(dir + "/SILVETON_OSC.sv", std::ios::binary | std::ios::trunc); o.write(reinterpret_cast<const char*>(m.data()), static_cast<std::streamsize>(m.size())); }
        (void)controller.reloadUserWaves();
        CHECK(controller.learnedModelNames().size() == 11U);
    }
    // engine places 1..4: SILVETON SYNTH with models 12 / 7 / none, place 4 = an old engine (MS20)
    {
        const float models[4] = {12.0F, 7.0F, 0.0F, 0.0F};
        for (int i = 0; i < 4; ++i) {
            CHECK(controller.setUpperEngineParam(7 + i, 0, i == 3 ? 3.0F : 12.0F));
            if (i < 3) CHECK(controller.setUpperEngineParam(7 + i, sv::model::MO_MODEL + 1, models[i]));
        }
    }
    classic::SilvetonSamplerView view(controller);
    using A = classic::NewLookAccess;
    using V = classic::SilvetonSamplerView;
    view.refreshAllForTests();
    A::live(view);
    shot(view, "nl_live");
    A::mixer(view);                                       shot(view, "nl_mixer");
    const char* groupNames[10] = {"tune", "range", "velocity", "filter", "envelope", "modulation", "wave", "eq", "voice", "midi"};
    for (int g = 0; g < 10; ++g) { A::edit(view, g, 0, 0); shot(view, std::string("nl_edit_") + groupNames[g]); }
    A::edit(view, 3, 0, 1);                                shot(view, "nl_edit_filter_L1");
    A::edit(view, 0, 2, 0);                                shot(view, "nl_edit_tune_u3");
    A::engine(view, 0);                                    shot(view, "nl_engine_0");
    A::engine(view, 3);                                    shot(view, "nl_engine_3");
    A::engine(view, 0); A::placeTab(view, 1);              shot(view, "nl_engine_fx");
    A::placeTab(view, 0);
    CHECK(controller.setUpperEngineParam(0, 0, 12.0F)); view.refreshAllForTests();
    A::engineUpper(view, 0);                               shot(view, "nl_engine_upper_synth");
    CHECK(controller.setUpperEngineParam(0, 0, 3.0F)); view.refreshAllForTests();
    A::engineUpper(view, 0);                               shot(view, "nl_engine_legacy");
    CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();
    A::listPage(view);                                     shot(view, "nl_list");
    A::listMenu(view, 0);                                  shot(view, "nl_list_menu");
    A::closeDialogs(view);
    view.setPage(V::Page::EFFECTS);                        shot(view, "nl_effects");
    for (int t = 0; t < 4; ++t) { A::settingsTab(view, t); shot(view, "nl_settings_" + std::to_string(t)); }
    // the five THEME keys of SETTINGS: tapped like a finger does; every colour is checked on LIVE and on SETTINGS
    static const char* const themeNames[] = {"graphite", "light", "black", "classic", "old"};
    for (int th = 4; th >= 0; --th) {
        A::settingsTab(view, 0); frame(view);
        A::tap(view, 466.0F + 169.5F * static_cast<float>(th) + 80.0F, 565.0F);
        CHECK(A::colorKey(view) == th);
        CHECK(controller.classicColor() == th);
        shot(view, std::string("theme_") + themeNames[th] + "_settings");
        A::live(view); shot(view, std::string("theme_") + themeNames[th] + "_live");
    }
    CHECK(colorTheme() == 0);
    // the old palette (OLD) on other screens
    A::color(view, 4);
    A::listPage(view);                                     shot(view, "old_list");
    A::edit(view, 3, 0, 0);                                shot(view, "old_edit_filter");
    A::engineUpper(view, 0);                               shot(view, "old_engine");
    view.setPage(V::Page::EFFECTS);                        shot(view, "old_effects");
    A::mixer(view);                                        shot(view, "old_mixer");
    A::color(view, 0);
    A::settingsTab(view, 1); shot(view, "nl_settings_midi");
    A::tap(view, 964.0F, 573.0F);                          shot(view, "nl_settings_cal");
    A::closeDialogs(view);
    view.setPage(V::Page::EFFECTS);
    shot(view, "nl_effects_pre");
    A::tap(view, 672.0F, 118.0F);                          shot(view, "nl_effects_pre2");
    A::tap(view, 600.0F, 255.0F);                          shot(view, "nl_effects_delay");
    A::live(view);
    A::confirm(view);                                      shot(view, "nl_dialog_confirm");
    A::closeDialogs(view);
    A::message(view);                                      shot(view, "nl_dialog_message");
    A::closeDialogs(view);
    view.setSoftKeyboard(true);
    A::numberDialog(view);                                 shot(view, "nl_dialog_number");
    A::closeDialogs(view);
    A::textDialog(view);                                   shot(view, "nl_dialog_text");
    A::closeDialogs(view);
    view.setSoftKeyboard(false);
    {   // SAVE LIST / STORE: no extra screen - the LIST opens and the position is chosen there
        A::engine(view, 0);
        A::openStore(view);
        CHECK(A::onList(view) && A::storeMode(view) && !A::dialogOpen(view));
        shot(view, "nl_store_list");
        int e = -1, taken = -1;
        for (int i = 0; i < 200 && (e < 0 || taken < 0); ++i) { if (A::listHas(view, i)) { if (taken < 0) taken = i; } else if (e < 0) e = i; }
        CHECK(e >= 0 && taken >= 0);
        const auto cellAt = [&](int idx) {   // the centre of a LIST cell on its page
            A::setListPage(view, idx / 30);
            frame(view);
            const int j = idx % 30;
            A::tap(view, 20.0F + static_cast<float>(j % 5) * 261.6F + 126.0F, 150.0F + static_cast<float>(j / 5) * 70.0F + 31.0F);
        };
        cellAt(e);                                         // a free position: the name, then it is written
        CHECK(A::dialogOpen(view));                        shot(view, "nl_store_name");
        A::applyDialog(view);
        CHECK(!A::dialogOpen(view) && A::listHas(view, e) && !A::storeMode(view));
        A::openStore(view);
        cellAt(taken);                                     // a taken position: the name, then OVERWRITE
        CHECK(A::dialogOpen(view));
        A::applyDialog(view);
        CHECK(A::dialogOpen(view));                        shot(view, "nl_store_overwrite");
        A::applyDialog(view);
        CHECK(!A::dialogOpen(view) && !A::storeMode(view));
        A::engine(view, 0);
        A::openStore(view);                                // CANCEL leaves the mode, nothing is written
        frame(view);
        A::tap(view, 993.0F, 120.0F);
        CHECK(!A::storeMode(view) && A::onList(view));
        A::closeDialogs(view);
        // marking: the DELETE key starts it, a finger dragged over the cells marks all the blends it passes
        A::setListPage(view, 0);
        frame(view);
        A::tap(view, 1255.0F, 120.0F);
        frame(view);
        CHECK(A::markMode(view));
        int expect = 0;
        for (int i = 0; i < 5; ++i) if (A::listHas(view, i)) ++expect;
        CHECK(expect >= 2);
        A::drag(view, 20.0F + 126.0F, 150.0F + 31.0F, 4.0F * 261.6F, 0.0F);   // along the first row of cells
        CHECK(static_cast<int>(A::markedCount(view)) == expect);
        shot(view, "nl_list_marked");
        A::tap(view, 993.0F, 120.0F);                      // CANCEL ends the marking
        frame(view);
        CHECK(!A::markMode(view) && A::markedCount(view) == 0U);
    }
    {   // MIXER > ENGINE of an Upper without an engine: the key to add SILVETON SYNTH is right there
        A::mixer(view);
        frame(view);
        std::vector<RectF> keys;
        for (const auto& h : A::hitList(view)) if (std::fabs(h->rect.width() - 76.0F) < 0.5F && std::fabs(h->rect.height() - 28.0F) < 0.5F) keys.push_back(h->rect);
        CHECK(keys.size() >= 14U);
        std::sort(keys.begin(), keys.end(), [](const RectF& a, const RectF& b) { return a.left < b.left; });
        const RectF engKey = keys.front();                 // the engine key of the first strip
        CHECK(A::upperEngine(view, 0) == 0);
        A::tap(view, engKey.centerX(), engKey.centerY());
        CHECK(A::onEngines(view) && A::engUpper(view) == 0);
        shot(view, "nl_mixer_engine_empty");
        const auto hl = A::hitList(view);
        const auto it = std::find_if(hl.begin(), hl.end(), [](const auto& h) {
            return std::fabs(h->rect.width() - 340.0F) < 0.5F && std::fabs(h->rect.height() - 44.0F) < 0.5F;
        });
        CHECK(it != hl.end());
        A::tap(view, (*it)->rect.centerX(), (*it)->rect.centerY());
        CHECK(A::upperEngine(view, 0) == 12);              // the Upper is now SILVETON SYNTH
        shot(view, "nl_mixer_engine_added");
        A::closeDialogs(view);
    }
    A::openPicker(view, 0);                                shot(view, "nl_picker");
    A::closeDialogs(view);

    {   // COPY and MOVE of the LIST menu work on the LIST screen itself: no screen for choosing the place, a hold on an empty position pastes
        A::closeDialogs(view);
        A::listPage(view); frame(view);
        int src = -1, e1 = -1, e2 = -1;
        for (int i = 0; i < 200 && src < 0; ++i) if (A::listHas(view, i)) src = i;
        for (int i = std::max(src, 0); i < 200; ++i) if (!A::listHas(view, i)) { if (e1 < 0) e1 = i; else { e2 = i; break; } }
        CHECK(src >= 0 && e1 > src && e2 > e1);
        const std::string nm = A::listName(view, src);
        A::listAction(view, src, 3);                                   // COPY
        CHECK(!A::dialogOpen(view) && A::hasOffer(view));
        frame(view);
        A::paste(view, e1);
        CHECK(A::listHas(view, src) && A::listHas(view, e1) && A::listName(view, e1) == nm && !A::hasOffer(view));
        A::listAction(view, e1, 4);                                    // MOVE
        CHECK(!A::dialogOpen(view) && A::hasOffer(view));
        A::paste(view, e2);
        CHECK(!A::listHas(view, e1) && A::listHas(view, e2) && A::listName(view, e2) == nm && !A::hasOffer(view));
        CHECK(controller.deleteLiveListEntry(e2));
        A::listPage(view); frame(view);
        std::printf("LIST COPY / MOVE on the LIST screen: ok\n");
        // SILVETON_SET_NEXT_TO_BANK_V1: a SET is one file `name.SVSET` NEXT TO the bank (no subfolder), the sampler's own files are not sets
        {
            const std::string setPath = dir + "/Test Set.SVSET";
            CHECK(!controller.saveSetAs("Test Set").has_value());
            struct stat st {};
            CHECK(::stat(setPath.c_str(), &st) == 0 && S_ISREG(st.st_mode));
            CHECK(::stat((dir + "/SILVETON_SETS").c_str(), &st) != 0);
            const auto sets = controller.savedSets();
            CHECK(std::find(sets.begin(), sets.end(), std::string("Test Set")) != sets.end());
            CHECK(std::find(sets.begin(), sets.end(), std::string("SILVETON_BLENDS")) == sets.end());
            CHECK(controller.saveSetAs("SILVETON_BLENDS").has_value());
            CHECK(!controller.loadSavedSet("Test Set").has_value());
            std::printf("SET is one file next to the bank: ok\n");
        }
        // SILVETON_SCALE_PAGE_V1: the SCALE page (the SCALE key of the LIST row opens it)
        {
            A::listPage(view); frame(view);
            A::tap(view, 1270.0F, 617.0F);                                   // the SCALE key
            CHECK(A::scaleOpen(view));
            frame(view);
            shot(view, "nl_scale_equal");
            A::tap(view, 180.0F, 245.0F);                                    // JUST INTONATION (tonic C)
            CHECK(controller.scaleName() == "JUST INTONATION / C");
            frame(view);
            A::tap(view, 155.0F, 548.0F);                                    // the tonic D
            CHECK(controller.scaleName() == "JUST INTONATION / D");
            const float e0 = controller.scaleCents()[4];
            frame(view);
            A::tap(view, 372.0F + 2.0F * 88.0F + 44.0F, 420.0F);            // the key E (the third white key)
            frame(view);
            A::tap(view, 372.0F + 5.0F * 103.0F + 40.0F, 562.0F);           // +1.00
            const float e1 = controller.scaleCents()[4];
            CHECK(std::fabs(e1 - (e0 + 1.0F)) < 0.02F && controller.scaleName() == "MANUAL");
            frame(view);
            A::drag(view, 668.0F, 494.0F, 0.0F, -40.0F);                     // the knob, a finger drag up
            CHECK(controller.scaleCents()[4] > e1 + 3.0F);
            frame(view);
            A::tap(view, 372.0F + 2.0F * 103.0F + 40.0F, 562.0F);           // -0.01 (to the hundredth)
            frame(view);
            shot(view, "nl_scale_manual");
            A::tap(view, 1170.0F, 498.0F);                                   // SAVE AS MINE
            CHECK(A::dialogOpen(view));
            A::applyDialog(view);
            CHECK(!A::dialogOpen(view) && controller.userScaleCount() == 1);
            frame(view);
            shot(view, "nl_scale_mine");
            A::tap(view, 1100.0F, 199.0F);                                   // the saved row = use it
            CHECK(controller.scaleName() == controller.userScaleName(0));
            frame(view);
            A::tap(view, 1284.0F, 199.0F);                                   // x = delete (asks first)
            CHECK(A::dialogOpen(view));
            A::applyDialog(view);
            CHECK(!A::dialogOpen(view) && controller.userScaleCount() == 0);
            frame(view);
            A::tap(view, 548.0F, 300.0F);                                    // the black key Eb
            CHECK(A::scaleSel(view) == 3);
            const float b0 = controller.scaleCents()[3];
            frame(view);
            A::tap(view, 372.0F + 5.0F * 103.0F + 40.0F, 562.0F);           // +1.00
            CHECK(std::fabs(controller.scaleCents()[3] - (b0 + 1.0F)) < 0.02F);
            {   // the sound engine got the same numbers
                const auto adv = controller.globalAdvanced();
                CHECK(adv.has_value() && adv->scaleCents.size() == 12U && std::fabs(adv->scaleCents[3] - (b0 + 1.0F)) < 0.02F);
            }
            frame(view);
            A::tap(view, 798.0F, 494.0F);                                    // NOTE TO 0.00
            CHECK(std::fabs(controller.scaleCents()[3]) < 0.005F);
            frame(view);
            A::tap(view, 481.0F, 494.0F);                                    // the number: typed exactly
            CHECK(A::dialogOpen(view));
            A::closeDialogs(view);
            for (int i = 1; i <= 6; ++i) CHECK(controller.saveUserScale("S" + std::to_string(i)));
            frame(view);
            A::tap(view, 1242.0F, 432.0F);                                   // the arrow down of MY SCALES
            CHECK(A::scaleTop(view) == 1);
            for (int i = 5; i >= 0; --i) controller.deleteUserScale(i);
            frame(view);
            // Q SCAN (the key of the LIST row) with the keys E and B played, the SCALE page shows the result
            frame(view);
            controller.setScale(SamplerAppController::scaleTurned(SamplerAppController::scalePresets()[1].cents, 0), "JUST INTONATION / C");
            controller.startScaleScan();
            midiIn->send(0x90, 64, 100); midiIn->send(0x90, 71, 100);
            midiIn->send(0x80, 64, 0);   midiIn->send(0x80, 71, 0);
            (void)controller.pollScan();
            const auto sc = controller.scaleCents();
            const auto ji = SamplerAppController::scaleTurned(SamplerAppController::scalePresets()[1].cents, 0);
            std::printf("after Q SCAN of E and B: name='%s' C=%.2f E=%.2f (was %.2f) B=%.2f (was %.2f) Eb=%.2f (was %.2f)\n", controller.scaleName().c_str(), static_cast<double>(sc[0]), static_cast<double>(sc[4]), static_cast<double>(ji[4]), static_cast<double>(sc[11]), static_cast<double>(ji[11]), static_cast<double>(sc[3]), static_cast<double>(ji[3]));
            CHECK(std::fabs(sc[4] - (ji[4] - 50.0F)) < 0.01F && std::fabs(sc[11] - (ji[11] - 50.0F)) < 0.01F);   // played notes: 50 cents lower on top of the scale
            CHECK(std::fabs(sc[3] - ji[3]) < 0.01F && std::fabs(sc[0] - ji[0]) < 0.01F);                         // the other notes stay
            frame(view);
            shot(view, "nl_scale_scan");
            A::tap(view, 85.0F, 120.0F);                                     // back to the LIST
            CHECK(!A::scaleOpen(view) && A::onList(view));
            frame(view);
            std::printf("SCALE page: ok\n");
        }
    }
    {   // SILVETON_MODELS_255_V1 + SILVETON_MODEL_RENAME_V1: a teacher file with 200 sounds next to the bank; the RENAME key of the MODEL list
        A::closeDialogs(view);
        {
            std::vector<unsigned char> f = {'S', 'V', 'O', 'S', 'C', '0', '0', '3', 200, 0, 0, 0};
            const auto u16 = [&f](unsigned v) { f.push_back(static_cast<unsigned char>(v & 255U)); f.push_back(static_cast<unsigned char>(v >> 8)); };
            for (int i = 1; i <= 200; ++i) {
                const std::string nm = "Teacher sound " + std::to_string(i), slot = "S" + std::to_string(i);
                u16(static_cast<unsigned>(nm.size())); f.insert(f.end(), nm.begin(), nm.end());
                u16(static_cast<unsigned>(slot.size())); f.insert(f.end(), slot.begin(), slot.end());
                u16(1);                                                       // one zone, not "ok" (no data rows) - enough to count and name the model
                f.push_back(36); f.push_back(96); f.push_back(60); f.push_back(0);
                f.insert(f.end(), 40U * 4U, 0);                               // the numbers
                u16(0); u16(0); u16(32); u16(0); u16(0);                      // H, A, L, frameMs (4 bytes)
            }
            const char* endMark = "SVOSCEND"; f.insert(f.end(), endMark, endMark + 8);
            std::ofstream out(dir + "/SILVETON_OSC.sv", std::ios::binary);
            out.write(reinterpret_cast<const char*>(f.data()), static_cast<std::streamsize>(f.size()));
        }
        (void)controller.reloadUserWaves();
        const std::vector<std::string> all = controller.learnedModelNames();
        std::printf("models: %zu (the 200 sounds of the file), note='%s'\n", all.size(), controller.learnedModelsNote().c_str());
        CHECK(all.size() == 200U && controller.learnedModelsNote().empty());
        CHECK(all.back() == "Teacher sound 200 (S200)");
        view.refreshAllForTests();
        A::engine(view, 0);
        frame(view);
        A::tap(view, 498.0F, 196.0F);                                         // the MODEL key: the list opens
        CHECK(A::dialogDepth(view) == 1U);
        frame(view);
        A::tap(view, 170.0F, 246.0F);                                         // page key 2
        frame(view);
        A::tap(view, 200.0F, 318.0F);                                         // the first model of page 2 = MODEL 21 (chosen)
        CHECK(A::gridCurrent(view) == 20);
        frame(view);
        shot(view, "nl_model_list_200");
        A::tap(view, 1078.0F, 184.0F);                                        // RENAME
        CHECK(A::dialogDepth(view) == 2U);
        frame(view);
        shot(view, "nl_model_rename_text");
        A::setDialogText(view, "My Oud 21");
        A::applyDialog(view);
        CHECK(A::dialogDepth(view) == 1U);
        CHECK(controller.learnedModelNames()[20] == "My Oud 21" && controller.learnedModelNames()[21] == all[21]);
        frame(view);
        shot(view, "nl_model_list_renamed");
        {   // the names are kept: a new start of the controller reads them again
            ControllerEnv env2;
            env2.dataDir = env.dataDir;
            env2.bankCandidates = {bank};
            SamplerAppController again(env2);
            (void)again.reloadUserWaves();
            CHECK(again.learnedModelNames().size() == 200U && again.learnedModelNames()[20] == "My Oud 21");
        }
        CHECK(controller.renameLearnedModel(20, all[20]) && controller.learnedModelNames()[20] == all[20]);                          // the original name = back to the original
        A::closeDialogs(view);
        std::printf("MODELS 200 + RENAME: ok\n");
        {   // SILVETON_MODELS_FROM_FILE_V1: models taken out of the file for good; the places keep their models; a new start does not bring them back
            const auto place = [&controller](int part, float model) { CHECK(controller.setUpperEngineParam(part, 0, 12.0F)); CHECK(controller.setUpperEngineParam(part, sv::model::MO_MODEL + 1, model)); };
            place(7, 5.0F); place(8, 21.0F); place(9, 100.0F);
            const auto at = [&controller](int part) { return static_cast<int>(std::lround(controller.upperEngineParams(part)[static_cast<std::size_t>(sv::model::MO_MODEL) + 1U])); };
            const auto err = controller.deleteLearnedModels({0, 20});
            CHECK(!err.has_value());
            const std::vector<std::string> now = controller.learnedModelNames();
            CHECK(now.size() == 198U && now[0] == all[1] && now[19] == all[21] && now.back() == all.back());
            CHECK(at(7) == 4 && at(8) == 0 && at(9) == 98);   // 5 -> 4 (one before it went), 21 was deleted -> NONE, 100 -> 98
            const auto info = controller.learnedModelsInfo();
            CHECK(info.fileFound && info.models == 198 && info.soundsInFile == 198);
            ControllerEnv env3; env3.dataDir = env.dataDir; env3.bankCandidates = {bank};
            SamplerAppController restart(env3);
            (void)restart.reloadUserWaves();
            CHECK(restart.learnedModelNames().size() == 198U);   // after a new start: still 198, they did not come back
            std::printf("MODELS DELETE: ok\n");
        }
    }
    {   // SILVETON_PORTA_ALL_V1: the SILVETON portamento shows TIME, BALANCE and NEAR-NOTE in ENGINE and in LIVE
        A::closeDialogs(view);
        controller.setPortaBalance(14); controller.setPortaNear(120);
        A::engine(view, 0);
        frame(view);
        A::tap(view, 889.0F, 510.0F);                                         // the SILVETON key of PORTAMENTO
        frame(view);
        shot(view, "nl_engine_porta_silveton");
        A::tap(view, 1000.0F, 633.0F);                                        // the number under BALANCE: the exact entry opens
        CHECK(A::dialogDepth(view) == 1U);
        A::closeDialogs(view);
        frame(view);
        A::live(view);
        frame(view);
        A::tap(view, 346.0F, 572.0F);                                         // the SILVETON key of the PORTAMENTO panel
        frame(view);
        shot(view, "nl_live_porta_silveton");
        A::tap(view, 610.0F, 656.0F);                                         // under the BALANCE knob
        CHECK(A::dialogDepth(view) == 1U);
        A::closeDialogs(view);
        A::tap(view, 346.0F, 638.0F);                                         // INSTRUMENT: one TIME knob again
        frame(view);
        shot(view, "nl_live_porta_instrument");
        A::tap(view, 346.0F, 572.0F);                                         // back to SILVETON
        controller.setPortaBalance(11); controller.setPortaNear(90);
        CHECK(controller.portaBalance() == 11 && controller.portaNear() == 90);
        std::printf("PORTAMENTO SILVETON knobs: ok\n");
    }
    if (argc > 3 && std::string(argv[3]) == "--touch") {
        view.setSoftKeyboard(false);
        auto D = [&] { frame(view); };
        sweepScene(view, "live", [&] { A::live(view); });
        sweepScene(view, "mixer", [&] { A::mixer(view); });
        const char* gn[10] = {"edit-sample", "edit-multisample", "edit-velocity", "edit-filter", "edit-envelope", "edit-modulation", "edit-wave", "edit-eq", "edit-voice", "edit-midi"};
        for (int g = 0; g < 10; ++g) sweepScene(view, gn[g], [&, g] { A::edit(view, g, 0, 0); });
        sweepScene(view, "edit-sample-L1", [&] { A::edit(view, 0, 0, 1); });
        sweepScene(view, "edit-filter-L1", [&] { A::edit(view, 3, 0, 1); });
        sweepScene(view, "list", [&] { A::listPage(view); });
        sweepScene(view, "engine-place1", [&] { A::engine(view, 0); A::placeTab(view, 0); });
        sweepScene(view, "engine-place1-fx", [&] { A::engine(view, 0); A::placeTab(view, 1); });
        sweepScene(view, "engine-empty-place", [&] { A::engine(view, 5); A::placeTab(view, 0); });
        sweepScene(view, "effects", [&] { view.setPage(V::Page::EFFECTS); });
        sweepScene(view, "effects-delay", [&] { view.setPage(V::Page::EFFECTS); D(); A::tap(view, 672.0F, 118.0F); D(); A::tap(view, 600.0F, 255.0F); D(); });
        for (int t = 0; t < 3; ++t) sweepScene(view, "settings-" + std::to_string(t), [&, t] { A::settingsTab(view, t); });
        sweepScene(view, "pedal-calibration", [&] { A::settingsTab(view, 1); D(); A::tap(view, 964.0F, 573.0F); });
        sweepScene(view, "dialog-number", [&] { view.setSoftKeyboard(true); A::live(view); A::numberDialog(view); });
        sweepScene(view, "dialog-text", [&] { view.setSoftKeyboard(true); A::live(view); A::textDialog(view); });
        view.setSoftKeyboard(false);
        sweepScene(view, "dialog-confirm", [&] { A::live(view); A::confirm(view); });
        sweepScene(view, "store", [&] { A::live(view); A::openStore(view); });
        sweepScene(view, "picker", [&] { A::live(view); A::openPicker(view, 0); });
        sweepScene(view, "list-menu", [&] { A::listPage(view); D(); A::listMenu(view, 0); });
        std::printf("TOUCH SWEEP DONE: %d keys and knobs touched, %d did nothing, %d covered by another key\n", g_sweepTested, g_sweepDead, g_sweepShadow);
        return 0;
    }
    std::printf("NEWLOOK_DONE\n");
    return 0;
}
