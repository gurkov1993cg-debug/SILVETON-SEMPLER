// Native scale workflow: exact tuning, routing, bypass and per-blend recall.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/host/HostIo.h"
#include "silveton/sampler/SetPackage.h"

#include <cmath>
#include <cstdio>
#include <fstream>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;
namespace sv = silveton::sampler;
#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct NewLookAccess {
    static void open(View& v) { v.openScalePage(); }
    static bool scaleOpen(const View& v) { return v.scaleOpen_; }
    static void tap(View& v, float x, float y) {
        const auto hit = v.hitAt(x, y);
        CHECK(hit && hit->tap);
        const auto action = hit->tap; action(x, y);
    }
    static void number(View& v, const std::string& value) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        d->value = value; d->cursor = static_cast<int>(value.size()); d->selectAll = false;
        v.dialogFire(d, d->buttons.back().action);
    }
};
}

namespace {
using Access = classic::NewLookAccess;
ControllerEnv environment() {
    char tmp[] = "/tmp/silveton-scale-workflow-XXXXXX";
    CHECK(::mkdtemp(tmp)); ControllerEnv env; env.dataDir = tmp; return env;
}
struct Fixture {
    ControllerEnv env{environment()};
    SamplerAppController ctrl{env};
    View view{ctrl};
    Canvas canvas{1340, 800};
    Fixture() {
        CHECK(ctrl.engine.nativeClearPerformance());
        CHECK(ctrl.engine.nativeAssignUpperSound(0, 0, 9005, 0));
        CHECK(ctrl.engine.nativeAssignUpperSound(0, 0, 9005, 1));
        CHECK(ctrl.engine.nativeSetScaleTuning(false, 0, 0, std::vector<float>(12U, 0.0F), "EQUAL"));
        ctrl.syncScaleFromEngine(); view.refreshAllForTests();
    }
    void draw() { view.draw(canvas); }
    void tap(float x, float y) { Access::tap(view, x, y); draw(); }
};

bool near(float a, float b) { return std::fabs(a - b) < 0.001F; }

void controls(const std::string& imagePath) {
    Fixture f;
    f.view.setPage(View::Page::COMBI);
    Access::open(f.view); f.draw();
    CHECK(Access::scaleOpen(f.view));
    CHECK(f.view.page() == View::Page::COMBI);
    f.tap(90.0F, 674.0F); // UPPER 1 target, without secretly enabling master
    CHECK(f.ctrl.quarterChosen(0) && !f.ctrl.scaleEnabled());
    f.tap(900.0F, 120.0F); CHECK(f.ctrl.scaleEnabled());
    f.tap(768.0F, 400.0F); // G key
    f.tap(758.0F, 494.0F); CHECK(near(f.ctrl.scaleCents()[7], -50.0F));
    f.tap(947.0F, 494.0F); CHECK(near(f.ctrl.scaleCents()[7], 50.0F));
    f.tap(851.0F, 494.0F); CHECK(near(f.ctrl.scaleCents()[7], 0.0F));
    f.tap(480.0F, 495.0F); Access::number(f.view, "-37.25"); f.draw();
    CHECK(near(f.ctrl.scaleCents()[7], -37.25F));
    f.tap(900.0F, 120.0F);
    CHECK(!f.ctrl.scaleEnabled() && f.ctrl.quarterChosen(0));
    CHECK(near(f.ctrl.scaleCents()[7], -37.25F));
    f.tap(900.0F, 120.0F);
    f.tap(1250.0F, 674.0F); // SYNTH target bank
    f.tap(70.0F, 674.0F); CHECK(f.ctrl.quarterChosen(7));
    f.tap(1250.0F, 674.0F);
    f.tap(95.0F, 429.0F); // RAST
    f.tap(150.0F, 544.0F); // tonic D: E half-flat/B half-flat move to F#/C#
    CHECK(f.ctrl.scaleTonic() == 2);
    CHECK(near(f.ctrl.scaleCents()[6], -50.0F) && near(f.ctrl.scaleCents()[1], -50.0F));
    CHECK(near(f.ctrl.scaleCents()[4], 0.0F));
    CHECK(f.ctrl.saveUserScale("MY RAST D"));
    f.ctrl.setScale(std::vector<float>(12U, 0.0F), "EQUAL", 0);
    CHECK(f.ctrl.useUserScale(0)); CHECK(f.ctrl.scaleTonic() == 2);
    if (!imagePath.empty()) { f.draw(); CHECK(writePng(imagePath, f.canvas)); }
    f.tap(80.0F, 120.0F);
    CHECK(!Access::scaleOpen(f.view) && f.view.page() == View::Page::COMBI);
    std::puts("PASS controls: direct targets/master, 12-key exact cents, +/-50/0, preset tonic, user tuning, return to LIVE");
}

void persistence() {
    Fixture f;
    std::vector<float> a(12U, 0.0F), b(12U, 0.0F);
    a[9] = -50.0F; b[4] = -37.25F; b[11] = 18.5F;
    f.ctrl.setScale(a, "SCALE A", 0); f.ctrl.setScaleTarget(0, true); f.ctrl.setScaleEnabled(true);
    CHECK(f.ctrl.writeCombiToList(0, "BLEND A") == 0);
    f.ctrl.setScale(b, "SCALE B", 7); f.ctrl.setScaleTarget(0, false); f.ctrl.setScaleTarget(1, true); f.ctrl.setScaleTarget(6, true); f.ctrl.setScaleEnabled(false);
    CHECK(f.ctrl.writeCombiToList(1, "BLEND B") == 1);
    CHECK(f.ctrl.activateListEntry(0, 0, 0, 0));
    CHECK(f.ctrl.scaleName() == "SCALE A" && f.ctrl.scaleEnabled() && f.ctrl.quarterChosen(0) && !f.ctrl.quarterChosen(1));
    CHECK(f.ctrl.scaleCents() == a);
    // Recall bypassing UI/controller still restores native scope and tuning.
    const auto rows = f.ctrl.listItems(0, 0, 0);
    CHECK(f.ctrl.engine.nativeActivateCombi(rows[1].combiBank, rows[1].combiPage, rows[1].combiSlot));
    f.ctrl.pollScan();
    CHECK(f.ctrl.scaleName() == "SCALE B" && !f.ctrl.scaleEnabled() && f.ctrl.quarterChosen(1) && f.ctrl.quarterChosen(6));
    CHECK(f.ctrl.scaleCents() == b && f.ctrl.scaleTonic() == 7);
    CHECK(!f.ctrl.blendEdited());
    // Store current edited tuning independently of either WRITE slot.
    f.ctrl.setScaleNote(0, -12.34F); CHECK(f.ctrl.blendEdited());
    CHECK(!f.ctrl.saveSetAs("SCALE SET"));
    f.ctrl.setScale(a, "CHANGED", 0);
    CHECK(!f.ctrl.loadSavedSet("SCALE SET"));
    CHECK(near(f.ctrl.scaleCents()[0], -12.34F) && !f.ctrl.scaleEnabled() && f.ctrl.quarterChosen(6));
    CHECK(f.ctrl.blendEdited());
    CHECK(f.ctrl.activateListEntry(0, 0, 0, 1)); CHECK(f.ctrl.scaleCents() == b && !f.ctrl.blendEdited());
    CHECK(f.ctrl.copyListEntryTo(0, 4)); CHECK(f.ctrl.moveListEntryTo(4, 6));
    CHECK(f.ctrl.activateListEntry(0, 0, 0, 6)); CHECK(f.ctrl.scaleCents() == a && f.ctrl.scaleEnabled());
    std::puts("PASS persistence: distinct per-blend cents/root/master/targets, native recall, LIST copy/move, open edited SET snapshot");

    auto saved = sv::SetPackage::load(f.env.dataDir + "/SCALE_SET.SVSET");
    if (!saved.ok()) saved = sv::SetPackage::load(f.env.dataDir + "/SCALE SET.SVSET");
    CHECK(saved.ok());
    // Existing v19 layouts remain readable with no scale extension.
    for (auto& cs : saved.data.combis) cs.combi.scale = {};
    if (saved.data.performance) saved.data.performance->combi.scale = {};
    CHECK(sv::SetPackage::save(f.env.dataDir + "/LEGACY.SVSET", saved.data).success);
    const auto legacy = sv::SetPackage::load(f.env.dataDir + "/LEGACY.SVSET"); CHECK(legacy.ok());
    CHECK(!legacy.data.combis.front().combi.scale.stored);
    CHECK(!f.ctrl.loadSavedSet("LEGACY")); // uses legacy SET-wide T/Q; no required migration

    CHECK(!f.ctrl.saveSetAs("VALID"));
    std::ifstream file(f.env.dataDir + "/VALID.SVSET", std::ios::binary);
    std::string bytes((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    const auto block = bytes.rfind("SVSC"); CHECK(block != std::string::npos);
    std::string nonfinite = bytes;
    const auto currentSet = sv::SetPackage::load(f.env.dataDir + "/VALID.SVSET"); CHECK(currentSet.ok());
    std::size_t record = block + 12U;
    bool explicitCombi = false;
    for (std::size_t i = 0U; i < currentSet.data.combis.size(); ++i) {
        if (nonfinite.at(record) == 1) { explicitCombi = true; break; }
        ++record; // a legacy COMBI has only its absent flag in SVSC
    }
    if (!explicitCombi) { CHECK(nonfinite.at(record) == 1); ++record; } // live snapshot present
    CHECK(nonfinite.at(record) == 1); // explicit scale in the first matching COMBI or live snapshot
    const std::size_t cents = record + 5U; // stored, enabled, targets(u16), tonic
    nonfinite[cents] = 0; nonfinite[cents + 1U] = 0;
    nonfinite[cents + 2U] = static_cast<char>(0xC0); nonfinite[cents + 3U] = 0x7F;
    { std::ofstream bad(f.env.dataDir + "/NONFINITE.SVSET", std::ios::binary); bad.write(nonfinite.data(), static_cast<std::streamsize>(nonfinite.size())); }
    CHECK(!sv::SetPackage::load(f.env.dataDir + "/NONFINITE.SVSET").ok());
    bytes.resize(bytes.size() - 1U);
    { std::ofstream bad(f.env.dataDir + "/BROKEN.SVSET", std::ios::binary); bad.write(bytes.data(), static_cast<std::streamsize>(bytes.size())); }
    CHECK(!sv::SetPackage::load(f.env.dataDir + "/BROKEN.SVSET").ok());
    const auto current = f.ctrl.engine.nativeScaleTuning();
    CHECK(f.ctrl.loadSavedSet("BROKEN").has_value()); CHECK(f.ctrl.engine.nativeScaleTuning() == current);
    std::vector<float> invalid(12U, 0.0F); invalid[3] = std::numeric_limits<float>::quiet_NaN();
    CHECK(!f.ctrl.engine.nativeSetScaleTuning(true, 1, 0, invalid, "INVALID")); CHECK(f.ctrl.engine.nativeScaleTuning() == current);
    std::puts("PASS compatibility: legacy SET and explicit OFF distinct, malformed scale block rejected without replacing live state");
}

double frequency(const std::vector<float>& stereo) {
    std::vector<double> crossings;
    for (std::size_t i = 4002U; i < stereo.size(); i += 2U) {
        const double a = stereo[i - 2U], b = stereo[i];
        if (a <= 0.0 && b > 0.0) crossings.push_back(static_cast<double>(i / 2U) - 1.0 + (-a) / (b - a));
    }
    CHECK(crossings.size() >= 5U);
    return 96000.0 * static_cast<double>(crossings.size() - 1U) / (crossings.back() - crossings.front());
}

void audio() {
    Fixture f;
    auto out = std::make_unique<silveton::host::OfflineAudioOutput>(96000.0, 96U);
    auto* audioOut = out.get();
    f.ctrl.engine.setBackends(std::move(out), std::make_unique<silveton::host::ManualMidiInput>());
    CHECK(f.ctrl.engine.nativeAudioOpen() && f.ctrl.engine.nativeAudioStart());
    CHECK(f.ctrl.engine.nativeUpdateUpperMain(1, false, false, false, 0, 0, 0, 127, 0));
    std::vector<float> tuning(12U, 0.0F); tuning[9] = -50.0F; tuning[0] = -35.0F;
    f.ctrl.setScale(tuning, "PITCH TEST", 0); f.ctrl.setScaleTarget(0, true); f.ctrl.setScaleEnabled(true);
    CHECK(f.ctrl.engine.nativeMidi(0x90, 69, 100));
    const double lowered = frequency(audioOut->pump(24000U));
    CHECK(std::abs(lowered - 440.0 * std::pow(2.0, -0.5 / 12.0)) < 0.5);
    f.ctrl.setScaleEnabled(false);
    const double equal = frequency(audioOut->pump(24000U)); CHECK(std::abs(equal - 440.0) < 0.5);
    f.ctrl.setScaleEnabled(true); f.ctrl.setScaleTarget(0, false);
    CHECK(std::abs(frequency(audioOut->pump(24000U)) - 440.0) < 0.5);
    f.ctrl.setScaleTarget(0, true);
    CHECK(std::abs(frequency(audioOut->pump(24000U)) - lowered) < 0.5);
    CHECK(f.ctrl.engine.nativeMidi(0xB0, 64, 127)); CHECK(f.ctrl.engine.nativeMidi(0x80, 69, 0));
    f.ctrl.setScaleNote(9, 25.0F);
    CHECK(std::abs(frequency(audioOut->pump(24000U)) - 440.0 * std::pow(2.0, 0.25 / 12.0)) < 0.5);
    CHECK(f.ctrl.engine.nativeMidi(0xB0, 64, 0)); audioOut->pump(96000U);
    CHECK(f.ctrl.engine.nativePanic()); audioOut->pump(960U);
    auto global = f.ctrl.globalUiState(); CHECK(global); global->transpose = -6; CHECK(f.ctrl.updateGlobalUi(*global));
    CHECK(f.ctrl.engine.nativeMidi(0x90, 69, 100));
    CHECK(std::abs(frequency(audioOut->pump(24000U)) - 440.0 * std::pow(2.0, (-6.0 + 0.25) / 12.0)) < 0.5);
    CHECK(f.ctrl.engine.nativeMidi(0x80, 69, 0)); audioOut->pump(48000U);
    f.ctrl.engine.nativeSetTerca(1, 0, 0); CHECK(f.ctrl.engine.nativeMidi(0x90, 69, 100));
    const double third = frequency(audioOut->pump(24000U));
    CHECK(std::abs(third - 440.0 * std::pow(2.0, (-3.0 - 0.35) / 12.0)) < 0.5);
    CHECK(f.ctrl.engine.nativeMidi(0x80, 69, 0)); audioOut->pump(96000U);
    double energy = 0.0; for (float value : audioOut->pump(4800U)) energy += static_cast<double>(value) * value;
    CHECK(energy < 1.0e-8);
    std::printf("PASS audio: A4 %.5f Hz / bypass %.5f Hz, live sustain retune, targets, transpose, scale-aware third, note release\n", lowered, equal);
    f.ctrl.engine.nativeSetTerca(0, 0, 0);
}
}

int main(int argc, char** argv) {
    try {
        CHECK(argc >= 2); setFontDirectory(argv[1]); CHECK(fontsReady());
        controls(argc >= 3 ? argv[2] : std::string()); persistence(); audio();
        std::puts("Scale workflow: all groups passed"); return 0;
    } catch (const std::exception& e) { std::fprintf(stderr, "FAILED: %s\n", e.what()); return 1; }
}
