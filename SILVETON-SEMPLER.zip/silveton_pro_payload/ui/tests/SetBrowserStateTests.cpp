// SET browser state travels with its LIST, including across devices and old files.
#include "silveton/ui/SamplerAppController.h"
#include "silveton/sampler/SetPackage.h"

#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <atomic>
#include <fstream>
#include <set>
#include <string>
#include <thread>
#include <vector>
#include <unistd.h>

using silveton::ui::SamplerAppController;
namespace sv = silveton::sampler;
#define CHECK(x) do { if (!(x)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #x); std::exit(1); } } while (false)

int main() {
    char temp[] = "/tmp/silveton-set-browser-XXXXXX";
    CHECK(::mkdtemp(temp) != nullptr);
    const std::string dir = temp;
    silveton::ui::ControllerEnv env;
    env.dataDir = dir;
    {
        SamplerAppController controller(env);
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 0));
        CHECK(controller.writeCombiToList(0, "A BLEND") == 0);
        controller.saveListFavourites({0, 17, 199});
        controller.saveSoundFavourites({7, 9001, 10001});
        controller.rememberRecentSound(9001);
        controller.rememberRecentSound(7);
        controller.rememberRecentSound(10002);
        CHECK(!controller.saveSetAs("SET A"));
        auto saved = sv::SetPackage::load(dir + "/SET A.SVSET");
        CHECK(saved.ok());
        CHECK(saved.data.extra.find("list_favs=0,17,199\n") != std::string::npos);
        CHECK(saved.data.extra.find("sound_favs=7,9001,10001\n") != std::string::npos);
        CHECK(saved.data.extra.find("sound_recent=10002,7,9001\n") != std::string::npos);

        controller.saveListFavourites({9});
        controller.saveSoundFavourites({9006});
        controller.rememberRecentSound(9006);
        CHECK(!controller.saveSetAs("SET B"));
        CHECK(!controller.loadSavedSet("SET A"));
        CHECK((controller.listFavourites() == std::set<int>{0, 17, 199}));
        CHECK((controller.soundFavourites() == std::set<int>{7, 9001, 10001}));
        CHECK((controller.recentSounds() == std::vector<int>{10002, 7, 9001}));
        CHECK(!controller.loadSavedSet("SET B"));
        CHECK((controller.listFavourites() == std::set<int>{9}));
        CHECK((controller.soundFavourites() == std::set<int>{9006}));
        CHECK(controller.recentSounds().front() == 9006);

        // A malformed load must preserve the previous browser state.
        { std::ofstream bad(dir + "/BROKEN.SVSET", std::ios::binary); bad << "invalid"; }
        CHECK(controller.loadSavedSet("BROKEN").has_value());
        CHECK((controller.listFavourites() == std::set<int>{9}));
        CHECK((controller.soundFavourites() == std::set<int>{9006}));

        // Legacy files with old metadata, or no metadata at all, have no stars.
        auto legacy = saved.data;
        legacy.extra = "terca_uppers=0\nscale_uppers=0\n";
        CHECK(sv::SetPackage::save(dir + "/LEGACY.SVSET", legacy).success);
        CHECK(!controller.loadSavedSet("LEGACY"));
        CHECK(controller.listFavourites().empty());
        CHECK(controller.soundFavourites().empty());
        CHECK(controller.recentSounds().empty());
        legacy.extra.clear();
        CHECK(sv::SetPackage::save(dir + "/NO METADATA.SVSET", legacy).success);
        controller.saveListFavourites({5});
        controller.saveSoundFavourites({9004});
        CHECK(!controller.loadSavedSet("NO METADATA"));
        CHECK(controller.listFavourites().empty() && controller.soundFavourites().empty());

        // API returns a result so SOURCE autosave can retain and retry edits.
        CHECK(controller.soloSaveSession());

        // Imported filenames remain selectable exactly as shown by the browser.
        CHECK(sv::SetPackage::save(dir + "/Other.Mixed Name.svset", saved.data).success);
        const std::string longName(55U, 'L');
        CHECK(sv::SetPackage::save(dir + "/" + longName + ".SVSET", saved.data).success);
        const auto sets = controller.savedSets();
        CHECK(std::find(sets.begin(), sets.end(), "Other.Mixed Name") != sets.end());
        CHECK(std::find(sets.begin(), sets.end(), longName) != sets.end());
        CHECK(controller.setExists("Other.Mixed Name"));
        CHECK(!controller.loadSavedSet("Other.Mixed Name"));
        CHECK(!controller.loadSavedSet(longName));
        controller.saveListFavourites({6});
        CHECK(!controller.saveSetAs("Other.Mixed Name"));
        CHECK(!silveton::ui::files::exists(dir + "/Other_Mixed Name.SVSET"));
        CHECK(!controller.loadSavedSet("Other.Mixed Name"));
        CHECK((controller.listFavourites() == std::set<int>{6}));

        // Save As and its overwrite check agree even when typed text is cleaned.
        CHECK(!controller.saveSetAs("Clean/Name"));
        CHECK(controller.setExists("Clean/Name"));
        CHECK(controller.setExists("Clean_Name"));

        // The private autosave names are also reserved on case-insensitive Macs.
        CHECK(controller.saveSetAs("silveton_blends").has_value());
        CHECK(controller.saveSetAs("Silveton_User_State").has_value());
        CHECK(!controller.setExists("silveton_blends"));
        CHECK(sv::SetPackage::save(dir + "/silveton_blends.svset", saved.data).success);
        const auto visible = controller.savedSets();
        CHECK(std::find(visible.begin(), visible.end(), "silveton_blends") == visible.end());

        // A previous directory SET can be replaced without first deleting it.
        const std::string legacyDir = dir + "/DIRECTORY.SVSET";
        CHECK(silveton::ui::files::makeDirectories(legacyDir));
        CHECK(silveton::ui::files::copyFile(dir + "/SET A.SVSET", legacyDir + "/manifest.svs"));
        CHECK(!controller.loadSavedSet("DIRECTORY"));
        CHECK(!controller.saveSetAs("DIRECTORY"));
        CHECK(silveton::ui::files::isFile(legacyDir));
        CHECK(sv::SetPackage::load(legacyDir).ok());

        // Model chooser work and deferred UI autosave may arrive together.
        std::atomic<int> failed{0};
        const auto save = [&] { for (int i = 0; i < 6; ++i) if (!controller.soloSaveSession()) ++failed; };
        std::thread worker(save);
        save();
        worker.join();
        CHECK(failed == 0);
        CHECK(sv::SetPackage::load(dir + "/SILVETON_BLENDS.SVSET").ok());
    }

    // Independent preferences directory emulates loading the one SET on another device.
    const std::string other = dir + "/second-device";
    CHECK(silveton::ui::files::makeDirectories(other));
    CHECK(silveton::ui::files::copyFile(dir + "/SET A.SVSET", other + "/SET A.SVSET"));
    env.dataDir = other;
    {
        SamplerAppController controller(env);
        CHECK(!controller.loadSavedSet("SET A"));
        CHECK((controller.listFavourites() == std::set<int>{0, 17, 199}));
        CHECK((controller.soundFavourites() == std::set<int>{7, 9001, 10001}));
        CHECK((controller.recentSounds() == std::vector<int>{10002, 7, 9001}));
    }

    // A file cannot act as the autosave folder. The failure is returned and warned.
    const std::string blocked = dir + "/not-a-folder";
    { std::ofstream file(blocked); file << "blocked"; }
    env.dataDir = blocked;
    std::string warning;
    env.statusChanged = [&warning](const std::string& text) { warning = text; };
    {
        SamplerAppController controller(env);
        CHECK(!controller.soloSaveSession());
        CHECK(!warning.empty());
        // A failed legacy-theme COPY/MOVE must restore order, favourites and
        // selection and remove the new COMBI allocated for a failed copy.
        CHECK(controller.engine.nativeClearPerformance());
        CHECK(controller.engine.nativeAssignUpperSound(0, 0, 9001, 0));
        CHECK(controller.engine.nativeWriteCombi(0, 0, 1, "SOURCE"));
        CHECK(controller.engine.nativeWriteList(0, 0, 0, "LIVE", {1, 2}, {"SOURCE", "TARGET"}, {0, 0, 1, 0, 0, 1}));
        CHECK(controller.engine.nativeSetActiveListEntry(0, 0, 0, 1));
        controller.saveListFavourites({0});
        CHECK(!controller.copyListEntryTo(0, 1));
        CHECK(!controller.engine.nativeCombiSlotOccupied(0, 0, 2));
        CHECK(controller.listItems(0, 0, 0).at(1).name == "TARGET");
        CHECK((controller.listFavourites() == std::set<int>{0}));
        CHECK(controller.activeListEntry(0, 0, 0) == 1);
        CHECK(!controller.moveListEntryTo(0, 1));
        CHECK(controller.listItems(0, 0, 0).at(0).name == "SOURCE");
        CHECK(controller.listItems(0, 0, 0).at(1).name == "TARGET");
        CHECK((controller.listFavourites() == std::set<int>{0}));
        CHECK(controller.activeListEntry(0, 0, 0) == 1);

        CHECK(controller.engine.nativeUpdateUpperTune(0, 1, -2, 777.0F, 12, 0.25F));
        const auto openBefore = controller.engine.nativeUpperState(0);
        const auto nameBefore = controller.engine.nativeCombiName();
        const bool dirtyBefore = controller.engine.nativeBlendEdited();
        CHECK(dirtyBefore);
        const auto storedBefore = controller.engine.nativeStoredCombi(0, 0, 1);
        CHECK(storedBefore && storedBefore->name == "SOURCE");
        const auto unchangedWrite = [&] {
            CHECK(controller.engine.nativeUpperState(0) == openBefore);
            CHECK(controller.engine.nativeCombiName() == nameBefore);
            CHECK(controller.engine.nativeBlendEdited() == dirtyBefore);
            CHECK(controller.activeListEntry(0, 0, 0) == 1);
            const auto source = controller.engine.nativeStoredCombi(0, 0, 1);
            CHECK(source && source->name == storedBefore->name);
            CHECK(source->uppers[0].tuneCents == storedBefore->uppers[0].tuneCents);
            CHECK(source->uppers[0].program == storedBefore->uppers[0].program);
            CHECK(source->uppers[0].soundSlotId == storedBefore->uppers[0].soundSlotId);
            CHECK(controller.listItems(0, 0, 0).size() == 2);
            CHECK(controller.listItems(0, 0, 0).at(1).name == "TARGET");
            CHECK((controller.listFavourites() == std::set<int>{0}));
        };
        CHECK(!controller.writeCombiSlot(1, "FAILED SLOT WRITE"));
        CHECK(!controller.lastFailure().empty());
        unchangedWrite();
        CHECK(controller.writeCombiToList(5, "FAILED NEW LIST WRITE") == -1);
        CHECK(!controller.engine.nativeCombiSlotOccupied(0, 0, 2));
        unchangedWrite();

        // Replacing a uniquely referenced stored blend also rolls back its
        // previous parameters, rather than leaving the failed WRITE behind.
        CHECK(controller.engine.nativeWriteCombi(0, 0, 2, "UNIQUE TARGET"));
        CHECK(controller.engine.nativeSetListEntry(0, 0, 0, 1, 2, "TARGET", 0, 0, 2));
        CHECK(controller.engine.nativeUpdateUpperTune(0, -1, 3, -333.0F, 7, 0.15F));
        const auto edited = controller.engine.nativeUpperState(0);
        CHECK(controller.writeCombiToList(1, "FAILED REPLACEMENT") == -1);
        const auto target = controller.engine.nativeStoredCombi(0, 0, 2);
        CHECK(target && target->name == "UNIQUE TARGET" && target->uppers[0].tuneCents == 777.0F);
        CHECK(controller.listItems(0, 0, 0).at(1).name == "TARGET");
        CHECK(controller.engine.nativeUpperState(0) == edited && controller.engine.nativeBlendEdited());
        CHECK(controller.activeListEntry(0, 0, 0) == 1);
        CHECK((controller.listFavourites() == std::set<int>{0}));
    }
    std::puts("PASS SET browser state: stars/recent, SET isolation, filenames, reserved names, directory replacement, concurrent autosave, cross-device restore and errors");
}
