// SAVE SET restores the open performance without silently doing WRITE.
#include "silveton/ui/SamplerAppController.h"
#include "silveton/sampler/SetPackage.h"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

namespace sv = silveton::sampler;
using silveton::ui::SamplerAppController;

#define CHECK(x) do { if (!(x)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #x); std::exit(1); } } while (false)

namespace {
bool isFile(const std::string& path) {
    struct stat s {};
    return ::stat(path.c_str(), &s) == 0 && S_ISREG(s.st_mode);
}

sv::SetData readSet(const std::string& path) {
    const auto loaded = sv::SetPackage::load(path);
    CHECK(loaded.ok());
    return loaded.data;
}

void checkReferencesOnly(const sv::Combi& c) {
    for (int i = 0; i < sv::kPartCount; ++i) {
        CHECK(c.part(i).program == nullptr);
        for (const auto& layer : c.part(i).layers) CHECK(layer.program == nullptr);
    }
}
} // namespace

int main() {
    char temp[] = "/tmp/imak-set-persistence-XXXXXX";
    CHECK(::mkdtemp(temp) != nullptr);
    const std::string dir = temp;
    silveton::ui::ControllerEnv env;
    env.dataDir = dir;
    SamplerAppController controller(env);
    auto& native = controller.engine;
    CHECK(native.nativeGlobalState().at(6) == 0.0F); // unchanged default: limiter OFF
    CHECK(native.nativeClearPerformance());
    CHECK(native.nativeAssignUpperSound(0, 0, 9001, 0));
    CHECK(native.nativeUpdateUpperTune(0, 0, 0, 100.0F, 2, 0.0F));
    CHECK(controller.writeCombiToList(2, "STORED A") == 2);
    CHECK(!native.nativeBlendEdited());
    CHECK(native.nativeUpdateUpperTune(0, 0, 0, 700.0F, 2, 0.0F));
    // Retained sample programs in any engine place/layer must not embed audio.
    for (int i = 0; i < sv::kPartCount; ++i) {
        CHECK(native.nativeAssignUpperSound(0, 0, 9001, i));
        CHECK(native.nativeSetLayerSound(i, 0, 9002));
    }
    CHECK(native.nativeSetUpperEngineParam(7, 0, static_cast<float>(sv::EngineType::Synth)));
    CHECK(native.nativeSetUpperParam(0, 49, 350.0F));
    CHECK(native.nativeSetUpperParam(7, 49, 450.0F));
    CHECK(native.nativeUpdateUpperTune(14, 1, 2, 250.0F, 5, 0.3F));
    CHECK(native.nativeUpdateGlobal(442.0F, 1, -7.0F, 1.0F, 2.0F, 3.0F, true, -9.0F, 2, 2, 11, 64, true, true));
    controller.setPortaBalance(3);
    controller.setPortaNear(25);
    controller.setVoiceCeiling(16);
    CHECK(!controller.saveSetAs("SAVED"));
    CHECK(isFile(dir + "/SAVED.SVSET"));
    const auto saved = readSet(dir + "/SAVED.SVSET");
    CHECK(saved.performance.has_value());
    CHECK(saved.combis.size() == 1U && saved.combis[0].combi.uppers[0].tuneCents == 100.0F);
    CHECK(saved.performance->combi.uppers[0].tuneCents == 700.0F);
    CHECK(saved.performance->combi.part(14).tuneCents == 250.0F);
    CHECK(saved.performance->combi.part(7).evenDecayMs == 450.0F);
    CHECK(saved.performance->activeListAddress == std::optional<sv::SlotAddress>({0U, 0U, 0U}));
    CHECK(saved.performance->activeListEntry == 2 && saved.performance->edited);
    CHECK(saved.samples.empty() && saved.multisamples.empty() && saved.programs.empty());
    checkReferencesOnly(saved.performance->combi);
    for (const auto& c : saved.combis) checkReferencesOnly(c.combi);
    CHECK(saved.extra.find("porta_balance=3") != std::string::npos);
    CHECK(saved.extra.find("porta_near=25") != std::string::npos);
    CHECK(saved.extra.find("voice_ceiling=16") != std::string::npos);
    CHECK(native.nativeBlendEdited());
    std::puts("PASS SAVE SET: edited live COMBI and LIST position saved separately from WRITE slots; one file, no embedded audio");

    // A completely different live/stored blend must be replaced by the snapshot.
    CHECK(native.nativeUpdateUpperTune(0, 0, 0, 900.0F, 2, 0.0F));
    CHECK(controller.writeCombiToList(0, "CURRENT B") == 0);
    controller.setPortaBalance(40);
    controller.setPortaNear(400);
    controller.setVoiceCeiling(128);
    CHECK(!controller.loadSavedSet("SAVED"));
    CHECK(native.nativeCombiName() == "STORED A");
    CHECK(native.nativeUpperState(0).at(12) == 700.0F);
    CHECK(native.nativeUpperState(14).at(12) == 250.0F);
    CHECK(native.nativeActiveListEntry(0, 0, 0) == 2 && native.nativeBlendEdited());
    CHECK(native.nativeUpperParams(7).at(49) == 450.0F);
    for (int i = 0; i < sv::kPartCount; ++i) {
        CHECK(!native.nativeUpperSoundName(i).empty());
        CHECK(!native.nativeLayerName(i, 0).empty());
    }
    CHECK(controller.portaBalance() == 3 && controller.portaNear() == 25 && controller.voiceCeiling() == 16);
    CHECK(native.nativeGlobalState().at(0) == 442.0F && native.nativeGlobalState().at(6) == 1.0F);
    CHECK(native.nativeGlobalState().at(7) == -9.0F);
    CHECK(!native.nativeCombiSlotOccupied(0, 0, 2)); // unrelated stored B is gone
    // The Manager's separate OPEN-COMBI file also strips/rebinds engine sources.
    CHECK(native.nativeSaveOpenCombi(dir + "/OPEN-COMBI.SVSET"));
    CHECK(isFile(dir + "/OPEN-COMBI.SVSET"));
    CHECK(native.nativeLoadOpenCombi(dir + "/OPEN-COMBI.SVSET"));
    CHECK(!native.nativeUpperSoundName(7).empty() && !native.nativeUpperSoundName(14).empty());
    CHECK(!controller.loadSavedSet("SAVED"));
    // LOAD's automatic save and repeated native saves keep all embedded metadata.
    CHECK(readSet(dir + "/SILVETON_BLENDS.SVSET").extra == saved.extra);
    CHECK(native.nativeSaveUserPerformanceState(dir + "/REPEAT.SVSET"));
    CHECK(readSet(dir + "/REPEAT.SVSET").extra == saved.extra);
    CHECK(!controller.loadSavedSet("REPEAT"));
    CHECK(native.nativeUpperState(0).at(12) == 700.0F && native.nativeBlendEdited());
    CHECK(controller.writeCombiToList(2, "WRITTEN A") == 2);
    CHECK(!native.nativeBlendEdited());
    const auto written = readSet(dir + "/SILVETON_BLENDS.SVSET");
    CHECK(written.combis[0].combi.uppers[0].tuneCents == 700.0F);
    CHECK(written.performance && !written.performance->edited);
    std::puts("PASS LOAD SET: restored live parameters, all15 source bindings, selected LIST, dirty state, settings and limiter; explicit WRITE unchanged");

    // All five older extension blocks may precede the new snapshot. Reading
    // only four blocks used to lose T/Q even before SVPS was introduced.
    auto extended = saved;
    auto& stored = extended.combis[0].combi;
    stored.uppers[0].evenDecayMs = 300.0F;
    stored.uppers[0].engine = sv::engineDefaults(sv::EngineType::Synth);
    stored.engineSlots[0].engine = sv::engineDefaults(sv::EngineType::Synth);
    stored.engineSlots[0].enabled = true;
    stored.engineInsert[0].type = sv::EffectType::Delay;
    stored.engineSlots[0].fxSend4 = 0.25F;
    CHECK(sv::SetPackage::save(dir + "/EXTENDED.SVSET", extended).success);
    const auto roundTrip = readSet(dir + "/EXTENDED.SVSET");
    CHECK(roundTrip.extra == saved.extra && roundTrip.performance.has_value());
    CHECK(roundTrip.combis[0].combi.engineInsert[0].type == sv::EffectType::Delay);
    CHECK(roundTrip.performance->combi.engineSlots[0].engine.type == sv::EngineType::Synth);
    CHECK(roundTrip.performance->combi.part(14).layers[0].soundSlotId == 9002U);
    std::puts("PASS extension chain: all legacy optional blocks plus live snapshot round trip");

    // A damaged snapshot or invalid COMBI must fail without replacing the live
    // performance, library or selected entry.
    std::ifstream in(dir + "/SAVED.SVSET", std::ios::binary);
    std::string bytes((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    CHECK(bytes.size() > 1U);
    bytes.pop_back();
    { std::ofstream out(dir + "/BROKEN.SVSET", std::ios::binary); out.write(bytes.data(), static_cast<std::streamsize>(bytes.size())); }
    CHECK(!sv::SetPackage::load(dir + "/BROKEN.SVSET").ok());
    CHECK(!native.nativeReplaceUserPerformanceState(dir + "/BROKEN.SVSET"));
    CHECK(native.nativeCombiName() == "WRITTEN A" && native.nativeActiveListEntry(0, 0, 0) == 2);
    auto invalid = saved;
    invalid.combis[0].combi.name.clear();
    CHECK(sv::SetPackage::save(dir + "/INVALID.SVSET", invalid).success);
    CHECK(!native.nativeReplaceUserPerformanceState(dir + "/INVALID.SVSET"));
    CHECK(native.nativeCombiName() == "WRITTEN A" && native.nativeCombiSlotOccupied(0, 0, 1));
    std::puts("PASS rejected load: previous live performance and LIST survive invalid or truncated SET");

    // A legacy v19 SET has no snapshot or the new settings keys. It opens its
    // first valid listed blend and leaves device preferences at their values.
    auto legacy = saved;
    legacy.performance.reset();
    legacy.extra = "terca_uppers=0\nscale_uppers=0\n";
    CHECK(sv::SetPackage::save(dir + "/LEGACY.SVSET", legacy).success);
    controller.setPortaBalance(20);
    controller.setPortaNear(120);
    controller.setVoiceCeiling(64);
    CHECK(!controller.loadSavedSet("LEGACY"));
    CHECK(native.nativeUpperState(0).at(12) == 100.0F && !native.nativeBlendEdited());
    CHECK(native.nativeActiveListEntry(0, 0, 0) == 2);
    CHECK(controller.portaBalance() == 20 && controller.portaNear() == 120 && controller.voiceCeiling() == 64);
    legacy.lists.clear();
    CHECK(sv::SetPackage::save(dir + "/UNLISTED.SVSET", legacy).success);
    CHECK(!controller.loadSavedSet("UNLISTED"));
    CHECK(native.nativeUpperState(0).at(12) == 100.0F && native.nativeActiveListEntry(0, 0, 0) == -1);
    legacy.combis.clear();
    CHECK(sv::SetPackage::save(dir + "/EMPTY.SVSET", legacy).success);
    CHECK(!controller.loadSavedSet("EMPTY"));
    CHECK(native.nativeCombiName() == "EMPTY" && !native.nativeBlendEdited());
    CHECK(native.nativeActiveListEntry(0, 0, 0) == -1);
    std::puts("PASS legacy SETs: listed, unlisted and empty files load without stale live state; absent settings retain defaults/preferences");

    auto missing = saved;
    auto& missingPart = missing.performance->combi.part(14);
    missingPart.engine = sv::engineDefaults(sv::EngineType::Off);
    missingPart.soundSlotId = 499U;
    missingPart.name = "Unavailable sample";
    missingPart.layers = {};
    CHECK(sv::SetPackage::save(dir + "/MISSING.SVSET", missing).success);
    CHECK(!controller.loadSavedSet("MISSING"));
    CHECK(native.nativeUpperState(14).at(0) == 0.0F);
    CHECK(native.nativeLastRecallMissing().find("15\t0\tUnavailable sample\t499") != std::string::npos);
    std::puts("PASS missing samples: snapshot opens, unavailable part stays off and recall report names the missing source");

    // A sample used only by another saved live snapshot must not be offered for
    // DELETE with a blend, including sources/layers in engine places.
    CHECK(native.nativeWriteProgram(0, 0, 499, 0, "PROTECTED SOURCE"));
    CHECK(native.nativeAssignUpperSound(0, 0, 499, 0));
    CHECK(native.nativeWriteCombi(0, 0, 77, "DELETE CANDIDATE"));
    CHECK(native.nativeSoundsOnlyInCombi(0, 0, 77, false, {}, {}) == std::vector<int>{499});
    sv::SetData protectedSet;
    protectedSet.performance.emplace();
    auto& protectedPart = protectedSet.performance->combi.part(14);
    protectedPart.soundSlotId = 499U;
    protectedPart.name = "PROTECTED SOURCE";
    const std::string protectedPath = dir + "/PROTECTED.SVSET";
    CHECK(sv::SetPackage::save(protectedPath, protectedSet).success);
    CHECK(native.nativeSoundsOnlyInCombi(0, 0, 77, false, {protectedPath}, {}).empty());
    protectedPart.soundSlotId = sv::kNoSoundSlot;
    protectedPart.layers[0].soundSlotId = 499U;
    protectedPart.layers[0].name = "PROTECTED SOURCE";
    CHECK(sv::SetPackage::save(protectedPath, protectedSet).success);
    CHECK(native.nativeSoundsOnlyInCombi(0, 0, 77, false, {protectedPath}, {}).empty());
    std::puts("PASS saved snapshot source protection: DELETE respects references in all15 parts and layers");
    controller.close();
    std::puts("All SET persistence regressions passed");
    return 0;
}
