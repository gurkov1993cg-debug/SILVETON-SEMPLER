// Exercise the actual Settings LOAD callback and the limiter control.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SetPackage.h"
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

#define CHECK(x) do { if (!(x)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #x); std::exit(1); } } while (false)

namespace {
class RecoverableOutput final : public silveton::host::AudioOutput {
public:
    bool open(RenderFn, void*, double, std::uint32_t) override { opened=true; broken=false; ++opens; return true; }
    bool start() override { running=opened; ++starts; return running; }
    void stop() override { running=false; }
    void close() override { opened=running=false; }
    double sampleRate() const override { return opened?48000.0:0.0; }
    std::uint32_t framesPerBurst() const override { return opened?96U:0U; }
    double latencyMs() const override { return 4.0; }
    bool needsRecovery() const override { return broken; }
    bool opened=false,running=false,broken=false;
    int opens=0,starts=0;
};
}

namespace silveton::ui::classic {
struct ViewTestAccess {
    using V = SilvetonSamplerView;
    static void load(V& v, const std::string& name) {
        v.loadSetNamed(name);
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        for (const auto& button : d->buttons) {
            if (button.label == "LOAD") { v.dialogFire(d, button.action); return; }
        }
        CHECK(false);
    }
    static void checkSelected(V& v, int position, const std::string& name, int slot) {
        CHECK(v.cachedActiveListEntry == position);
        CHECK(v.loadedFromList == position && v.listSelected == position);
        CHECK(v.listFollowedActive == position);
        CHECK(v.listPage == (position >= 0 ? position / V::LIST_PER_PAGE : 0));
        CHECK(v.cachedCombiName == name);
        if (slot >= 0) CHECK(v.editingCombiSlot && *v.editingCombiSlot == slot);
        else CHECK(!v.editingCombiSlot);
    }
    static void toggleLimiter(V& v) { v.refreshGlobal(); CHECK(v.globalState); v.editGlobal(6, *v.globalState); }
    static void resetLimiter(V& v) { v.refreshGlobal(); CHECK(v.globalState); v.resetGlobal(6, *v.globalState); }
};
} // namespace silveton::ui::classic

int main() {
    using namespace silveton::ui;
    using V = classic::SilvetonSamplerView;
    using T = classic::ViewTestAccess;
    char temp[] = "/tmp/imak-set-ui-XXXXXX";
    CHECK(::mkdtemp(temp) != nullptr);
    ControllerEnv env;
    env.dataDir = temp;
    SamplerAppController controller(env);
    auto& native = controller.engine;
    CHECK(native.nativeClearPerformance());
    CHECK(native.nativeAssignUpperSound(0, 0, 9001, 0));
    CHECK(controller.writeCombiToList(57, "SAVED A") == 57);
    CHECK(native.nativeUpdateUpperTune(0, 0, 0, 700.0F, 2, 0.0F));
    CHECK(!controller.saveSetAs("UI-A"));
    CHECK(controller.writeCombiToList(3, "CURRENT B") == 3);
    V view(controller);
    T::load(view, "UI-A");
    T::checkSelected(view, 57, "SAVED A", 1);
    CHECK(native.nativeUpperState(0).at(12) == 700.0F && native.nativeBlendEdited());

    CHECK(native.nativeGlobalState().at(6) == 0.0F);
    T::toggleLimiter(view);
    CHECK(native.nativeGlobalState().at(6) == 1.0F);
    T::toggleLimiter(view);
    CHECK(native.nativeGlobalState().at(6) == 0.0F);
    T::toggleLimiter(view);
    T::resetLimiter(view);
    CHECK(native.nativeGlobalState().at(6) == 0.0F);

    silveton::sampler::SetData empty;
    empty.name = "Empty legacy SET";
    CHECK(silveton::sampler::SetPackage::save(std::string(temp) + "/UI-EMPTY.SVSET", empty).success);
    T::load(view, "UI-EMPTY");
    T::checkSelected(view, -1, "EMPTY", -1);
    std::puts("PASS Settings LOAD: active LIST/page, current name and WRITE destination restored; empty SET clears selection");
    std::puts("PASS Settings limiter: OFF -> ON -> OFF and reset to original OFF default");
    controller.close();

    // Recovery must not turn an explicitly paused output back on. Exercise the
    // controller poll as well as the host, since the host already preserves it.
    {
        SamplerAppController recovery(env);
        auto output=std::make_unique<RecoverableOutput>();
        auto* device=output.get();
        recovery.engine.setBackends(std::move(output), std::make_unique<silveton::host::ManualMidiInput>());
        CHECK(recovery.start());
        CHECK(device->running && device->starts==1);
        recovery.pauseAudio();
        CHECK(!device->running && !recovery.audioRunning());
        device->broken=true;
        recovery.housekeeping();
        CHECK(device->opens==2 && !device->running && device->starts==1);
        CHECK(!recovery.audioRunning() && !recovery.engine.nativeAudioNeedsRecovery());
        CHECK(recovery.resumeAudio());
        CHECK(device->running && recovery.audioRunning());
        recovery.close();
    }
    std::puts("PASS paused output recovery: housekeeping repairs device and preserves pause until explicit resume");
    return 0;
}
