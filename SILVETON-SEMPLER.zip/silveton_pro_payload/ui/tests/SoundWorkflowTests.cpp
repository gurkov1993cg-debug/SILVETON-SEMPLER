// Actual SOUND EDIT callbacks: scoped copy/paste, deferred moves and full-part fidelity.
#include "silveton/ui/classic/SilvetonSamplerView.h"
#include "silveton/sampler/SoloModel.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <unistd.h>

using namespace silveton::ui;
using View = classic::SilvetonSamplerView;
#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " #x); } while (false)

namespace silveton::ui::classic {
struct NewLookAccess {
    static void edit(View& v, int upper = 0, int slot = 0) {
        v.page_ = View::Page::COMBI;
        v.combiMode_ = View::MODE_EDIT;
        v.editGroup_ = View::EG_TUNE;
        v.selectedUpper_ = upper;
        v.stripSound[static_cast<std::size_t>(upper)] = slot;
        v.editSound = slot;
        v.invalidate();
    }
    static bool tap(View& v, float x, float y) {
        const auto h = v.hitAt(x, y);
        if (!h || !h->tap) return false;
        const auto action = h->tap;
        action(x, y);
        return true;
    }
    static bool picker(const View& v) { return static_cast<bool>(v.picker); }
    static bool soundClip(const View& v) { return v.copiedSound_.has_value(); }
    static bool cut(const View& v) { return v.copiedSound_ && v.copiedSound_->cut; }
    static int soundId(const View& v) { return v.copiedSound_ ? v.copiedSound_->soundId : 0; }
    static void confirm(View& v) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        CHECK(!d->buttons.empty());
        v.dialogFire(d, d->buttons.back().action);
    }
    static void cancel(View& v) {
        CHECK(!v.dialogStack.empty());
        v.dialogCancel(v.dialogStack.back());
    }
    static void fakeSameNamePicker(View& v, int upper, int wrongId, const std::string& name) {
        v.lastPickedSound[static_cast<std::size_t>(upper)] = View::SoundItem{0, 0, wrongId, name};
    }
    static void directPaste(View& v, int upper, int slot) { v.pasteSoundSlot(upper, slot); }
    static void actions(View& v, int upper, int slot) { v.showSoundActions(upper, slot); }
    static void bankPicker(View& v,int upper,int slot){v.openPicker(upper,slot-1);}
    static void link(View& v){v.linkOn=true;v.marked[0]=v.marked[1]=true;}
    static void pickName(View& v,Canvas& canvas,const std::string& name){
        CHECK(v.picker&&!v.dialogOpen());const auto items=v.pickerItems(*v.picker);
        for(std::size_t i=0;i<items.size();++i)if(items[i].name==name){
            v.picker->page=static_cast<int>(i/40);v.draw(canvas);const int cell=static_cast<int>(i%40);
            CHECK(tap(v,145.F+261.6F*(cell%5),222.F+62.F*(cell/5)));v.draw(canvas);return;
        }
        throw std::runtime_error("Missing picker sound: "+name);
    }
    static void preview(View& v,int id){
        CHECK(v.picker);
        if(id==0){v.pickerAssign(*v.picker,std::nullopt);return;}
        for(const auto& item:v.sampler.soundCatalog())if(item.slot==id){v.pickerAssign(*v.picker,item);return;}
        throw std::runtime_error("Missing preview sound");
    }
    static void item(View& v, const std::string& wanted) {
        CHECK(!v.dialogStack.empty());
        const auto d = v.dialogStack.back();
        for (std::size_t i = 0; i < d->items.size(); ++i) if (d->items[i] == wanted) {
            const auto action = d->onItem;
            v.closeDialog(d);
            action(static_cast<int>(i));
            return;
        }
        throw std::runtime_error("Missing dialog item: " + wanted);
    }
};
} // namespace silveton::ui::classic

namespace {
using Access = classic::NewLookAccess;
int loadUpper=-1,loadSound=-1;
ControllerEnv environment() {
    char dir[] = "/tmp/silveton-sound-workflow-XXXXXX";
    CHECK(::mkdtemp(dir) != nullptr);
    ControllerEnv env;
    env.dataDir = dir;
    env.chooseSoloModel=[](int upper,int sound){loadUpper=upper;loadSound=sound;};
    return env;
}
struct Fixture {
    SamplerAppController controller{environment()};
    View view{controller};
    Canvas canvas{1340, 800};
    Fixture() {
        CHECK(controller.engine.nativeClearPerformance());
        for (int i = 0; i < 7; ++i) CHECK(controller.setUpperEngineParam(i, 0, 0.0F));
        CHECK(controller.assignUpperSound(0, {0, 0, 9001, "source"}));
        CHECK(controller.assignUpperSound(1, {0, 0, 9002, "target"}));
        view.refreshAllForTests();
        Access::edit(view);
        draw();
    }
    void draw() { view.draw(canvas); }
    void tap(float x, float y) { CHECK(Access::tap(view, x, y)); draw(); }
    void edit(int upper, int slot = 0) { Access::edit(view, upper, slot); draw(); }
    int layer(int upper, int slot) { return static_cast<int>(controller.layerParams(upper, slot).at(31)); }
};

void copyToEmptyLayer() {
    Fixture f;
    CHECK(f.controller.setLayerParam(1, 0, 1, -12.5F));
    CHECK(f.controller.setLayerParam(1, 0, 2, 0.37F));
    CHECK(f.controller.setLayerParam(1, 0, 6, 41.0F));
    CHECK(f.controller.setLayerParam(1, 0, 7, 89.0F));
    f.tap(746.0F, 676.0F); // COPY SOUND (MAIN)
    CHECK(Access::soundId(f.view) == 9001);
    f.tap(295.0F, 120.0F); // select UPPER 2
    f.tap(890.0F, 183.0F); // empty L1 remains selectable while clipboard exists
    CHECK(!Access::picker(f.view));
    f.tap(1075.0F, 676.0F); // PASTE SOUND
    CHECK(f.layer(1, 0) == 9001 && f.controller.upperSoundSlot(0) == 9001);
    const auto target = f.controller.layerParams(1, 0);
    CHECK(target.at(1) == -12.5F && std::abs(target.at(2) - 0.37F) < 0.000001F);
    CHECK(target.at(6) == 41.0F && target.at(7) == 89.0F);
    CHECK(Access::soundClip(f.view)); // COPY can be pasted repeatedly
    std::puts("PASS sound copy selects empty destination and preserves its level/pan/range");
}

void deferredCutAndCancel() {
    Fixture f;
    CHECK(f.controller.setLayerSound(0, 0, 9002));
    f.view.refreshAllForTests(); f.draw();
    f.tap(910.0F, 676.0F); // CUT SOUND
    CHECK(Access::cut(f.view) && f.controller.upperSoundSlot(0) == 9001);
    f.edit(1);
    f.tap(1075.0F, 676.0F); // occupied destination asks before replacement
    CHECK(f.view.dialogOpen());
    CHECK(f.controller.upperSoundSlot(0) == 9001 && f.controller.upperSoundSlot(1) == 9002);
    Access::cancel(f.view); f.draw();
    CHECK(f.controller.upperSoundSlot(0) == 9001 && f.controller.upperSoundSlot(1) == 9002);
    f.edit(2);
    f.tap(1075.0F, 676.0F); // successful empty destination commits the move
    CHECK(f.controller.upperSoundSlot(2) == 9001 && f.controller.upperSoundSlot(0) == 0);
    CHECK(f.layer(0, 0) == 9002);
    CHECK(f.controller.upperState(0)->enabled); // removing MAIN did not silence L1
    CHECK(!Access::soundClip(f.view));
    std::puts("PASS CUT is deferred, cancel is lossless, MAIN move keeps other layers enabled");
}

void changedSourceIsNotRemoved() {
    Fixture f;
    f.tap(910.0F, 676.0F);
    CHECK(f.controller.assignUpperSound(0, {0, 0, 9002, "replacement"}));
    f.edit(2);
    f.tap(1075.0F, 676.0F);
    CHECK(f.view.dialogOpen());
    CHECK(f.controller.upperSoundSlot(0) == 9002 && f.controller.upperSoundSlot(2) == 0);
    CHECK(Access::cut(f.view));
    std::puts("PASS changed CUT source cannot be cleared or pasted as a stale move");
}

void soundMenuCancelCut() {
    Fixture f;
    f.view.secondaryClick(770.0F, 183.0F); // MAIN tab context menu
    CHECK(f.view.dialogOpen());
    Access::item(f.view, "CUT SOUND"); f.draw();
    CHECK(Access::cut(f.view));
    f.tap(1237.0F, 676.0F); // SOUND MENU is also reachable without a hold
    Access::item(f.view, "CANCEL CUT"); f.draw();
    CHECK(!Access::soundClip(f.view) && f.controller.upperSoundSlot(0) == 9001);
    std::puts("PASS context menu and direct SOUND MENU share working cut/cancel actions");
}

void wholePartFidelity() {
    Fixture f;
    auto source = *f.controller.upperState(0);
    source.levelDb = -8.25F; source.pan = -0.41F; source.enabled = false; source.mute = true;
    source.voiceMode = 2; source.portamentoSec = 0.057F;
    CHECK(f.controller.updateUpperMain(0, source));
    CHECK(f.controller.updateUpperTune(0, source));
    CHECK(f.controller.setLayerSound(0, 0, 9002));
    CHECK(f.controller.setLayerParam(0, 3, 2, 0.61F)); // an empty layer still has editable settings
    CHECK(f.controller.setUpperEngineParam(0, 0, 13.0F)); // current SOLO
    CHECK(f.controller.updateUpperMain(0, source));
    for (int slot = 0; slot < 5; ++slot) {
        CHECK(f.controller.setSoundWaveParam(0, slot, 2, 0.17F + 0.1F * static_cast<float>(slot)));
        CHECK(f.controller.setSoundWaveParam(0, slot, 7, -0.42F + 0.1F * static_cast<float>(slot)));
        CHECK(f.controller.setSoundSynthParam(0, slot, 9, 0.2F + 0.1F * static_cast<float>(slot)));
        CHECK(f.controller.setSoundSynthParam(0, slot, 20, 1.0F));
        CHECK(f.controller.setSoundSynthParam(0, slot, 21, 2.0F));
        CHECK(f.controller.setSoundSynthParam(0, slot, 22, 0.37F));
        CHECK(f.controller.setSoundSynthParam(0, slot, 23, 1.0F));
    }
    CHECK(f.controller.setFxParam(4, 0, 1.0F));
    CHECK(f.controller.setFxParam(4, 1, 0.42F));
    if (!f.controller.quarterChosen(0)) f.controller.toggleQuarter(0);
    if (!f.controller.tercaChosen(0)) f.controller.toggleTerca(0);
    const auto expectedState = f.controller.engine.nativeUpperState(0);
    const auto expectedParams = f.controller.upperParams(0);
    const auto expectedEngine = f.controller.upperEngineParams(0);
    const auto expectedFx = f.controller.fxParams(4);
    f.view.refreshAllForTests(); f.edit(0);
    // Same display name at another ID must never redirect the clipboard to that ID.
    Access::fakeSameNamePicker(f.view, 0, 9002, f.controller.upperState(0)->soundName);
    f.tap(412.0F, 676.0F); // COPY PART
    f.edit(1);
    f.tap(570.0F, 676.0F); // PASTE PART
    CHECK(f.view.dialogOpen());
    CHECK(f.controller.upperSoundSlot(1) == 9002); // not changed until confirmation
    Access::confirm(f.view); f.draw();
    CHECK(!f.view.dialogOpen());
    CHECK(f.controller.upperSoundSlot(1) == 9001);
    CHECK(f.controller.engine.nativeUpperState(1) == expectedState);
    CHECK(f.controller.upperParams(1) == expectedParams);
    CHECK(f.controller.upperEngineParams(1) == expectedEngine);
    CHECK(f.controller.fxParams(5) == expectedFx);
    for (int slot = 0; slot < 5; ++slot) {
        CHECK(f.controller.soundWaveParams(1, slot) == f.controller.soundWaveParams(0, slot));
        CHECK(f.controller.soundSynthParams(1, slot) == f.controller.soundSynthParams(0, slot));
        if (slot > 0) CHECK(f.controller.layerParams(1, slot - 1) == f.controller.layerParams(0, slot - 1));
    }
    CHECK(f.controller.quarterChosen(1) && f.controller.tercaChosen(1));
    std::puts("PASS whole-part copy preserves IDs, 5 Wave/Synth matrices, empty layers, engine, FX, ON/MUTE and T/Q");
}

void learnedSourcesAndCancel() {
    Fixture f;
    namespace sv=silveton::sampler;
    auto model=std::make_shared<sv::solo::Model>();model->name="Learned source";
    sv::SoundAssignment source;source.name=model->name;source.soloModel=model;
    source.engine=sv::engineDefaults(sv::EngineType::Solo);source.commonProcessing=true;
    CHECK(f.controller.putSoundSource(0,0,source));
    CHECK(f.controller.putSoundSource(0,2,source));
    CHECK(f.controller.setLayerParam(0,1,0,0));
    auto state=*f.controller.upperState(0);state.enabled=false;CHECK(f.controller.updateUpperMain(0,state));
    f.view.refreshAllForTests();f.edit(0);
    f.tap(412,676);f.edit(1);f.tap(570,676);Access::confirm(f.view);f.draw();
    for(int slot:{0,2}){
        const auto pasted=f.controller.soundSource(1,slot);
        CHECK(pasted.soloModel==model&&pasted.commonProcessing);
    }
    CHECK(!f.controller.upperState(1)->enabled&&f.controller.layerParams(1,1)[0]==0);
    for(int slot:{0,2}){
        Access::fakeSameNamePicker(f.view,1,9001,source.name);
        Access::bankPicker(f.view,1,slot);Access::preview(f.view,9001);
        Access::preview(f.view,0); // same numeric ID as the model, but a different source
        f.draw();f.tap(1100,120); // CANCEL
        CHECK(f.controller.soundSource(1,slot).soloModel==model);
        CHECK(!f.controller.upperState(1)->enabled&&f.controller.layerParams(1,1)[0]==0);
    }
    std::puts("PASS learned MAIN/layer whole-part copy and picker cancellation preserve models and ON/OFF");
}

void directSoundPicker() {
    Fixture f;namespace sv=silveton::sampler;
    auto model=std::make_shared<sv::solo::Model>();model->name="My trained sound";
    sv::SoundAssignment source;source.name=model->name;source.soloModel=model;source.commonProcessing=true;
    source.engine=sv::engineDefaults(sv::EngineType::Solo);CHECK(f.controller.putSoundSource(0,2,source));
    CHECK(f.controller.setUpperParam(0,48,12));CHECK(f.controller.setLayerParam(0,1,2,.37F));
    f.view.refreshAllForTests();f.edit(0,2);Access::bankPicker(f.view,0,2);f.draw();
    CHECK(Access::picker(f.view)&&!f.view.dialogOpen());
    f.tap(810,120);CHECK(loadUpper==0&&loadSound==2); // direct native file request; no category dialog
    CHECK(Access::picker(f.view)); // cancelling the native panel can leave the existing picker intact
    Access::pickName(f.view,f.canvas,"STAVROS");
    CHECK(!f.controller.soundSource(0,2).soloModel&&f.controller.soundSource(0,2).commonProcessing);
    CHECK(f.controller.upperParams(0)[48]==12&&std::abs(f.controller.layerParams(0,1)[2]-.37F)<1e-6);
    f.tap(1100,120);CHECK(f.controller.soundSource(0,2).soloModel==model);
    Access::bankPicker(f.view,0,2);Access::pickName(f.view,f.canvas,"DRUGO");Access::link(f.view);f.tap(1250,120);
    CHECK(!Access::picker(f.view)&&!f.view.dialogOpen());
    CHECK(f.controller.soundSource(0,2).name=="DRUGO"&&f.controller.soundSource(1,2).name=="DRUGO");
    CHECK(f.controller.soundSource(1,2).commonProcessing);
    CHECK(f.controller.recentSounds().front()==10002);
    Access::bankPicker(f.view,0,2);f.draw();CHECK(writePng("SOUND_PICKER.png",f.canvas));
    Access::pickName(f.view,f.canvas,"SAW");f.tap(1250,120);
    CHECK(f.controller.soundSource(0,2).program&&!f.controller.soundSource(0,2).engine.chosen());
    CHECK(f.controller.soundSource(1,2).program&&!f.controller.soundSource(1,2).engine.chosen());
    std::puts("PASS direct common picker, ordinary SOLO entries, file request, cancel, LINK, recent and existing oscillator selection");
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 2) { std::fprintf(stderr, "usage: SoundWorkflowTests FONTS\n"); return 2; }
    setFontDirectory(argv[1]);
    if (!fontsReady()) return 3;
    try {
        copyToEmptyLayer();
        deferredCutAndCancel();
        changedSourceIsNotRemoved();
        soundMenuCancelCut();
        wholePartFidelity();
        learnedSourcesAndCancel();
        directSoundPicker();
    } catch (const std::exception& e) { std::fprintf(stderr, "FAIL %s\n", e.what()); return 1; }
    std::puts("Sound workflow: 7 groups passed");
    return 0;
}
