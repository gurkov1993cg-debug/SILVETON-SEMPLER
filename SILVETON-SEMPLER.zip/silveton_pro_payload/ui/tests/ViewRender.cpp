// Draws the screens of the sampler with demo sounds into PNG pictures (and checks that nothing crashes).
// Usage: imak_ui_render <fonts dir> <output dir>
#include "silveton/host/HostIo.h"
#include "silveton/sampler/SvBankFormat.h"
#include "silveton/sampler/SuseTools.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/classic/SilvetonSamplerView.h"   // SILVETON_OLD_THEME_V1
#ifdef IMAK_GL_COMPARE
#include "GlRenderer.h"
#endif

#include <cmath>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <set>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::ui;
namespace sv = silveton::sampler;

namespace silveton::ui::classic {
// SILVETON_OLD_THEME_V1: the same for the old look
struct ViewTestAccess {
    using V = SilvetonSamplerView;
    static void enginePage(V& v, int page) { v.enginePage_ = page; v.invalidate(); }
    static void engineTab(V& v) { v.selectedUpper_ = 0; v.page_ = V::Page::ENGINES; v.invalidate(); }   // SILVETON_ENGINES_PAGE_V1
    static void engineSlot(V& v, int slot) { v.engSlot_ = slot; v.invalidate(); }   // SILVETON_ENGINE_SLOTS_V1
    // SILVETON_SUSE_V1: the pages of SILVETON SYNTH
    static void suPage(V& v, int page) { v.suPage_ = page; v.suStatus_.clear(); v.suStatusUntilMs_ = 0; v.invalidate(); }
    static int suPageNow(V& v) { return v.suPage_; }
    static void suGen(V& v, int g, int sub) { v.suGen_ = g; v.suSub_ = sub; v.invalidate(); }
    static void suLink(V& v, int d, int s) { v.suLinkDst_ = d; v.suLinkSrc_ = s; v.invalidate(); }
    static void suWave(V& v, int slot, int mode) { v.suWaveSlot_ = slot; v.suWaveMode_ = mode; v.invalidate(); }
    static void suEnv(V& v, int e) { v.suEnv_ = e; v.invalidate(); }
    static void suStatusClear(V& v) { v.suStatus_.clear(); v.suStatusUntilMs_ = 0; }
    static void suOscAdvanced(V& v, bool on) { v.suOscAdv_ = on; v.invalidate(); }
    static int suPickSlotNow(V& v) { return v.suPickSlot_; }
    static void suEnvAdvanced(V& v, bool on) { v.suEnvAdv_ = on; v.invalidate(); }
    static void suPick(V& v, int pick, int gen) { v.suPick_ = pick; v.suPickGen_ = gen; v.invalidate(); }
    static void suSetValue(V& v, int u, int id, float x) { v.suSet(u, id, x); }
    static void suMod(V& v, int tab, int lfo) { v.suModTab_ = tab; v.suLfo_ = lfo; v.invalidate(); }
    static void suCtl(V& v, int k) { v.suCtl_ = k; v.invalidate(); }
    static void suGroup(V& v, int g, int pick) { v.suPresetGroup_ = g; v.suPresetPick_ = pick; v.suListPage_ = 0; v.invalidate(); }
    static void suLab(V& v, const std::vector<float>& a, float la, const std::vector<float>& b, float lb) { v.suLabA_ = a; v.suLabLoudA_ = la; v.suLabB_ = b; v.suLabLoudB_ = lb; v.suLabNow_ = 2; v.invalidate(); }
    static void suTap(V& v, float x, float y) { v.pointer(V::PointerAction::Down, x, y); v.pointer(V::PointerAction::Up, x, y); }
    static void storeAt(V& v, int pos, const std::string& name) { v.writeSelected = pos; v.writeName = name; v.confirmWrite(); }   // SILVETON_LOGIC_V1
    static bool onEngines(V& v) { return v.page_ == V::Page::ENGINES; }
    static bool listNamed(V& v, int pos, const std::string& name) { const auto it = v.realListItem(pos); return it && it->name == name; }
    static void unstore(V& v, int pos) { v.sampler.deleteLiveListEntry(pos); v.refreshListCache(); }
    static void openStore(V& v) { v.openStore(); }   // the same call as the ЗАПИШИ key of the left rail
    static void closeWrite(V& v) { v.writeOpen = false; v.invalidate(); }
    static void settingsTab(V& v, int t) { v.settingsTab = t; v.invalidate(); }
    // SILVETON_FULL_KEYBOARD_V1: the number page of the old look with its whole keyboard
    static void numberDialog(V& v) { v.showNumber("UPPER 1 LEVEL dB", -3.5F, -60.0F, 12.0F, 1, [](float) {}); }
    static void closeDialogs(V& v) { v.dialogStack.clear(); }
    static std::string dialogValue(V& v) { return v.dialogStack.empty() ? std::string("<none>") : v.dialogStack.back()->value; }
    static std::size_t keyCount(V& v) { Canvas c(1340, 800); v.draw(c); return v.dialogStack.empty() ? 0U : v.dialogStack.back()->kbKeys.size(); }
    static bool pressKey(V& v, const std::string& label) {
        Canvas c(1340, 800);
        v.draw(c);
        if (v.dialogStack.empty()) return false;
        for (const auto& k : v.dialogStack.back()->kbKeys) {
            if (k.label != label) continue;
            v.pointer(V::PointerAction::Down, k.rect.centerX(), k.rect.centerY());
            v.pointer(V::PointerAction::Up, k.rect.centerX(), k.rect.centerY());
            return true;
        }
        return false;
    }
    // SILVETON_BATCH_1101 (Цветомир, 01.11.2026): the same taps a finger makes on the ЛИСТ, the dialogs and the pedal page
    static bool tapListCell(V& v, int idx) {
        v.listPage = idx / V::LIST_PER_PAGE;   // the page of the ЛИСТ with this position, as the finger would have turned to it
        v.invalidate();
        Canvas c(1340, 800);
        v.draw(c);
        for (const auto& cell : v.listCells_) {
            if (cell.first != idx) continue;
            v.pointer(V::PointerAction::Down, cell.second.centerX(), cell.second.centerY());
            v.pointer(V::PointerAction::Up, cell.second.centerX(), cell.second.centerY());
            return true;
        }
        return false;
    }
    static int loadedFrom(V& v) { return v.loadedFromList; }   // the ЛИСТ position the open blend came from
    static int selected(V& v) { return v.listSelected; }
    static bool dialogOpen(V& v) { return !v.dialogStack.empty(); }
    static bool dialogTitleIs(V& v, const std::string& t) { return !v.dialogStack.empty() && v.dialogStack.back()->title == t; }
    static bool dialogHas(V& v, const std::string& part) { return !v.dialogStack.empty() && v.dialogStack.back()->message.find(part) != std::string::npos; }
    static bool pressDialogButton(V& v, const std::string& label) {   // the tap on a button: the dialog closes, then its action runs
        if (v.dialogStack.empty()) return false;
        const auto d = v.dialogStack.back();
        for (const auto& b : d->buttons) {
            if (b.label != label) continue;
            v.dialogFire(d, b.action);
            return true;
        }
        return false;
    }
    static bool pickDialogItem(V& v, int which) {   // a row of a list dialog (the ЛИСТ menu)
        if (v.dialogStack.empty() || !v.dialogStack.back()->onItem) return false;
        const auto d = v.dialogStack.back();
        const auto pick = d->onItem;
        v.dialogFire(d, [pick, which] { pick(which); });
        return true;
    }
    static void contextMenu(V& v, int idx) { const auto it = v.realListItem(idx); if (it) v.showListContextMenu(idx, *it); }
    static void markForDelete(V& v, std::set<int> marked) { v.listMarkMode_ = true; v.listMarked_ = std::move(marked); v.invalidate(); }
    static void markOff(V& v) { v.listMarkMode_ = false; v.listMarked_.clear(); v.invalidate(); }
    static void deleteMarked(V& v) { v.deleteMarkedListEntries(); }
    static bool isFavourite(V& v, int idx) { return v.listFavs.count(idx) != 0U; }
    static void addFavourite(V& v, int idx) { v.listFavs.insert(idx); }
    static void copyFailing(V& v, int from, int to) { v.doCopyOrMove(false, from, to); }
    static void openPedalCal(V& v) { v.pedalCalOpen_ = true; v.invalidate(); }
    static bool pedalCalOpen(V& v) { return v.pedalCalOpen_; }
    static bool tapPedalKey(V& v, int which) {   // 0 = ЗАПОМНИ МИН, 1 = ЗАПОМНИ МАКС, 2 = ВРЪЩАНЕ НА 0 – 127, 3 = ГОТОВО (the keys of the page, 330 x 90 / 60 units)
        Canvas c(1340, 800);
        v.draw(c);
        const float h = which < 2 ? 90.0F : 60.0F;
        int seen = 0;
        for (const auto& hp : v.hits) {
            if (std::fabs(hp->rect.width() - 330.0F) > 0.5F || std::fabs(hp->rect.height() - h) > 0.5F) continue;
            if (seen++ != (which & 1)) continue;
            v.pointer(V::PointerAction::Down, hp->rect.centerX(), hp->rect.centerY());
            v.pointer(V::PointerAction::Up, hp->rect.centerX(), hp->rect.centerY());
            return true;
        }
        return false;
    }
};
}

namespace silveton::ui {
// Friend of the view: lets the tests open pages and dialogs without a mouse.
struct ViewTestAccess {
    using V = SilvetonSamplerView;
    using Tab = V::UpperTab;
    static void edit(V& v, int upper, int sound, V::UpperTab tab) { v.selectedUpper_ = upper; v.stripSound[static_cast<std::size_t>(upper)] = sound; v.editSound = sound; v.tab = tab; v.invalidate(); }
    static void common(V& v, int upper, V::UpperTab tab) { v.selectedUpper_ = upper; v.tab = tab; v.invalidate(); }
    static void picker(V& v, int upper, int layer) { v.openPicker(upper, layer); }
    static void closePicker(V& v) { v.picker.reset(); }
    static void pickerAssignItem(V& v, const SilvetonSamplerView::SoundItem& item) { v.pickerAssign(*v.picker, item); }
    static void numberDialog(V& v) { v.showNumber("UPPER 1 LEVEL dB", -3.5F, -60.0F, 12.0F, 1, [](float) {}); }
    static void textDialog(V& v) { v.showTextPage("ИМЕ НА БЛЕНДА", "Piano + Strings", [](const std::string&) {}); }
    static void soundGrid(V& v) { v.showSoundPicker(0); }
    static void blendGrid(V& v) { v.showBlendPicker(); }
    static void confirm(V& v) { v.showConfirm("DELETE  ЛИСТ 007", "„Warm Pad“ излиза от ЛИСТА и мястото остава празно. Другите позиции не мърдат, самата бленда не се трие.", "DELETE", [] {}, "CANCEL"); }
    static void items(V& v) { v.showItems("007   Warm Pad", {"RENAME", "COPY TO…", "MOVE TO…", "EDIT", "DELETE"}, [](int) {}); }
    static void closeDialogs(V& v) { v.dialogStack.clear(); }
    static void listMenu(V& v, int index) { const auto it = v.realListItem(index); if (it) v.showListContextMenu(index, *it); }
    static void listFav(V& v, int index) { v.listFavs.insert(index); }
    static void listSelect(V& v, int index) { v.listSelected = index; }
    static void listMark(V& v, bool on, std::set<int> marked) { v.listMarkMode_ = on; v.listMarked_ = std::move(marked); v.invalidate(); }   // SILVETON_MULTI_DELETE_V1
    static void pickerPage(V& v, int page) { if (v.picker) v.picker->page = page; v.invalidate(); }
    static void pickerMark(V& v, bool on, std::set<int> marked) { if (v.picker) { v.picker->markMode = on; v.picker->marked = std::move(marked); } v.invalidate(); }
    static void openCopy(V& v, int source) { v.openPositionPicker(V::WriteMode::COPY, source); }
    static void openWriteScreen(V& v, bool blend) { v.openWrite(blend ? V::WriteTarget::BLEND : V::WriteTarget::LIST, false); }
    static void closeWrite(V& v) { v.writeOpen = false; }
    static void storeDialog(V& v) { v.storeToList(); }
    static void fx(V& v, int unit, int type) { v.fxUnitFocus = unit; v.setFxP(unit, 0, static_cast<float>(type)); v.invalidate(); }
    static void focus(V& v, int unit) { v.fxUnitFocus = unit; v.invalidate(); }
    static void settingsTab(V& v, int t) { v.settingsTab = t; v.bankInfoCache = v.sampler.bankInfo(); v.invalidate(); }
    static void deleteSounds(V& v) { if (v.bankInfoCache) v.showDeleteSounds(*v.bankInfoCache); }
    static void search(V& v, const std::string& q) { v.listSearch = q; }
    static void favOnly(V& v, bool on) { v.listFavOnly = on; }
    static void dropdown(V& v, int upper) { v.dropUpper = upper; v.invalidate(); }
    static int editSoundOf(V& v) { return v.editSound; }
    static void theme(V& v, bool) { V::applyTheme(true); v.invalidate(); }   // SILVETON_PRO_UI_V1: one (dark) look
    // SILVETON_PRO_UI_V1: the older pages of an Upper are shown inside the new frame - their own units -> the picture
    static float ex(float x) { return V::fitXf(RectF(112.0F, 514.0F, 1326.0F, 786.0F), RectF(10.0F, 444.0F, 1330.0F, 736.0F)).dx(x); }
    static float ey(float y) { return V::fitXf(RectF(112.0F, 514.0F, 1326.0F, 786.0F), RectF(10.0F, 444.0F, 1330.0F, 736.0F)).dy(y); }
    static void language(V& v, int lang) { v.setLanguage(lang); }
    static void uiTheme(V& v, int t) { v.setTheme(t); }   // SILVETON_THEMES_V1
    static classic::SilvetonSamplerView* classicView(V& v) { return v.classic_.get(); }   // SILVETON_OLD_THEME_V1
    static void enginePage(V& v, int page) { v.enginePage_ = page; v.invalidate(); }   // SILVETON_ENGINES_V1
    // on-screen keyboard / toast / second finger (the tablet)
    static void softKeyboard(V& v, bool on) { v.setSoftKeyboard(on); }
    static std::string dialogValue(V& v) { return v.dialogStack.empty() ? std::string("<none>") : v.dialogStack.back()->value; }
    static bool pressKey(V& v, const std::string& label, int occurrence = 0) {
        Canvas c(1340, 800);
        v.draw(c);
        if (v.dialogStack.empty()) return false;
        int seen = 0;
        for (const auto& k : v.dialogStack.back()->kbKeys) {
            if (k.label != label) continue;
            if (seen++ != occurrence) continue;
            v.pointer(V::PointerAction::Down, k.rect.centerX(), k.rect.centerY());
            v.pointer(V::PointerAction::Up, k.rect.centerX(), k.rect.centerY());
            return true;
        }
        return false;
    }
    static std::size_t keyCount(V& v) { return v.dialogStack.empty() ? 0U : v.dialogStack.back()->kbKeys.size(); }
    static bool pairCheck(V& v, SamplerAppController& ctl) {
        v.setPage(V::Page::LIST);
        Canvas c(1340, 800);
        v.draw(c);
        if (v.pairHits.empty()) return false;
        const auto pair = v.pairHits.front();
        ctl.stepGlobalTranspose(3);
        v.refreshAllForTests();
        v.draw(c);
        const float ax = pair.xf.dx(pair.a.centerX()), ay = pair.xf.dy(pair.a.centerY());   // the page's own units -> the picture
        v.pointer(V::PointerAction::Down, ax, ay);
        v.secondPointerDown(pair.xf.dx(pair.b.centerX()), pair.xf.dy(pair.b.centerY()));
        const bool consumed = v.pairConsumed;
        v.pointer(V::PointerAction::Up, ax, ay);
        v.setPage(V::Page::COMBI);
        const auto g = ctl.globalUiState();
        return consumed && g && g->transpose == 0 && !v.pairConsumed;
    }
    static void mark(V& v, bool markMode, int a, int b) { v.markMode = markMode; v.marked[static_cast<std::size_t>(a)] = true; v.marked[static_cast<std::size_t>(b)] = true; v.linkOn = true; }
};
} // namespace silveton::ui

namespace {
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

void writeBank(const std::string& path, const std::vector<std::string>& names, int frames = 8) {
    std::vector<std::uint8_t> strings{0U};
    auto addString = [&](const std::string& text) -> std::uint32_t {
        const auto offset = static_cast<std::uint32_t>(strings.size());
        strings.insert(strings.end(), text.begin(), text.end());
        strings.push_back(0U);
        return offset;
    };
    const auto bankName = addString("DEMO BANK");
    const auto sampleName = addString("DEMO SAMPLE");
    const auto sampleIdentity = addString("sample://demo");
    const auto msName = addString("DEMO MULTI");
    const auto msIdentity = addString("multi://demo");
    std::vector<std::uint8_t> sounds, layers, multis, samples, zones, audio;
    for (std::size_t i = 0U; i < names.size(); ++i) {
        sv::SvSoundRecord sound{};
        sound.nameOffset = addString(names[i]);
        sound.firstLayer = static_cast<std::uint32_t>(i);
        sound.layerCount = 1U;
        sound.soundSlotId = static_cast<std::uint32_t>(i + 1U);
        sv::appendSoundRecord(sounds, sound);
        sv::SvSoundLayerRecord layer{};
        layer.multisampleId = 4000001U; layer.enabled = 1U; layer.keyLow = 0U; layer.keyHigh = 127U; layer.velocityLow = 1U; layer.velocityHigh = 127U;
        sv::appendSoundLayerRecord(layers, layer);
    }
    sv::SvMultisampleRecord ms{};
    ms.multisampleId = 4000001U; ms.nameOffset = msName; ms.sourceIdentityOffset = msIdentity; ms.firstZone = 0U; ms.zoneCount = 1U;
    sv::appendMultisampleRecord(multis, ms);
    sv::SvSampleRecord sample{};
    sample.sampleId = 3000001U; sample.nameOffset = sampleName; sample.sourceIdentityOffset = sampleIdentity; sample.sampleRate = 48000U; sample.channels = 1U;
    sample.encoding = 1U; sample.bitsPerSample = 16U; sample.rootKey = 60U; sample.totalFrames = static_cast<std::uint32_t>(frames); sample.audioOffset = 0U; sample.audioSize = static_cast<std::uint64_t>(frames) * 2U;
    sv::appendSampleRecord(samples, sample);
    sv::SvZoneRecord zone{};
    zone.sampleId = 3000001U; zone.keyLow = 0U; zone.keyHigh = 127U; zone.velocityLow = 1U; zone.velocityHigh = 127U; zone.rootKey = 60U;
    sv::appendZoneRecord(zones, zone);
    const std::int16_t pcm[8] = {0, 8192, -8192, 16384, -16384, 32767, -32768, 4096};
    for (int i = 0; i < frames; ++i) {
        // 8 frames = the first toy sample; a longer one (the bank swap of the 01.11.2026 scenes) is a soft sine the bank check can hear
        const std::int16_t v = frames == 8 ? pcm[i] : static_cast<std::int16_t>(std::lround(12000.0 * std::sin(6.283185307179586 * 261.6 * i / 48000.0)));
        const auto u = static_cast<std::uint16_t>(v);
        audio.push_back(static_cast<std::uint8_t>(u & 0xFFU));
        audio.push_back(static_cast<std::uint8_t>((u >> 8U) & 0xFFU));
    }
    sv::SvBankHeader header{};
    header.bankNameOffset = bankName;
    header.soundCount = static_cast<std::uint32_t>(names.size());
    header.soundLayerCount = static_cast<std::uint32_t>(names.size());
    header.multisampleCount = 1U; header.sampleCount = 1U; header.zoneCount = 1U;
    std::vector<std::uint8_t> file(sv::kSvBankHeaderSize, 0U);
    auto appendSec = [&](sv::SvSection section, const std::vector<std::uint8_t>& data) {
        auto& d = header.sections[static_cast<std::size_t>(section)];
        d.offset = static_cast<std::uint64_t>(file.size());
        d.size = static_cast<std::uint64_t>(data.size());
        file.insert(file.end(), data.begin(), data.end());
    };
    appendSec(sv::SvSection::Sounds, sounds); appendSec(sv::SvSection::SoundLayers, layers); appendSec(sv::SvSection::Multisamples, multis);
    appendSec(sv::SvSection::Samples, samples); appendSec(sv::SvSection::Zones, zones); appendSec(sv::SvSection::Strings, strings); appendSec(sv::SvSection::Audio, audio);
    header.fileSize = static_cast<std::uint64_t>(file.size());
    header.payloadSha256 = sv::sha256(file.data() + sv::kSvBankHeaderSize, file.size() - sv::kSvBankHeaderSize);
    const auto serialized = sv::serializeHeader(header);
    std::copy(serialized.begin(), serialized.end(), file.begin());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(file.data()), static_cast<std::streamsize>(file.size()));
}

std::string g_out;
bool g_fast = false;   // profiling: one picture per screen

// "Light drawing" on the real screens: the picture kept by the FrameRenderer (only the changed parts drawn again) must be
// exactly the picture that drawing the recorded operations completely gives.
FrameRenderer g_light(1340, 800);
long long g_lightPictures = 0, g_lightRepainted = 0, g_lightIdlePictures = 0, g_lightIdleRepainted = 0;
double g_lightIdleMs = 0.0;
void checkLight(SilvetonSamplerView& view, const std::string& name) {
    for (int i = 0; i < 4; ++i) {   // the first picture after a change of screen, then the ones that follow while nothing is touched
        const auto t0 = std::chrono::steady_clock::now();
        g_light.update([&](Canvas& c) { view.draw(c); });
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        Canvas full(1340, 800);
        full.replay(g_light.lastList(), IRect(0, 0, 1340, 800));
        long long different = 0;
        for (std::size_t k = 0U; k < full.buffer().size(); ++k) if (full.buffer()[k] != g_light.picture().buffer()[k]) ++different;
        if (different != 0) std::fprintf(stderr, "light drawing: %s picture %d: %lld pixels differ\n", name.c_str(), i, different);
        CHECK(different == 0);
        ++g_lightPictures;
        g_lightRepainted += g_light.lastRepaintedPixels();
        if (i > 0) { ++g_lightIdlePictures; g_lightIdleRepainted += g_light.lastRepaintedPixels(); g_lightIdleMs += ms; }
    }
}


#ifdef IMAK_GL_COMPARE
// SILVETON_GPU_DRAW_V1: the picture the video card draws from the recorded list must be the picture the software renderer draws
// from the same list (to within a rounding step). Needs EGL / OpenGL ES 3 at run time (Mesa's surfaceless platform on Linux).
std::unique_ptr<silveton::gl::GlRenderer> g_glRenderer;
FrameRenderer g_glRecorder(1340, 800);
void checkVideoCard(SilvetonSamplerView& view, const std::string& name) {
    if (!g_glRenderer) {
        silveton::gl::GlRenderer::Options options;
        options.surfaceless = true;
        options.width = 1340;
        options.height = 800;
        std::string error;
        g_glRenderer = silveton::gl::GlRenderer::create(options, error);
        if (!g_glRenderer) { std::fprintf(stderr, "video card drawing: %s\n", error.c_str()); std::exit(3); }
        std::printf("video card: %s\n", g_glRenderer->info().c_str());
    }
    g_glRecorder.record([&](Canvas& c) { view.draw(c); });
    for (int pass = 0; pass < 2; ++pass) {   // the second time everything comes from the caches
        if (!g_glRenderer->render(g_glRecorder.lastList(), false)) { std::fprintf(stderr, "video card drawing %s: %s\n", name.c_str(), g_glRenderer->lastError().c_str()); std::exit(3); }
        std::vector<std::uint32_t> got;
        CHECK(g_glRenderer->readPixels(got));
        Canvas expected(1340, 800);
        expected.replay(g_glRecorder.lastList(), IRect(0, 0, 1340, 800));
        long long over = 0;
        int worst = 0;
        for (std::size_t k = 0U; k < got.size(); ++k) {
            int d = 0;
            for (unsigned shift = 0U; shift <= 24U; shift += 8U) d = std::max(d, std::abs(static_cast<int>((got[k] >> shift) & 255U) - static_cast<int>((expected.buffer()[k] >> shift) & 255U)));
            worst = std::max(worst, d);
            if (d > 8) ++over;
        }
        if (over != 0 || worst > 16) std::fprintf(stderr, "video card drawing: %s (pass %d): %lld pixels differ by more than 8, worst %d\n", name.c_str(), pass, over, worst);
        CHECK(over == 0 && worst <= 16);
    }
}
#endif

void shot(SilvetonSamplerView& view, const std::string& name) {
    Canvas canvas(1340, 800);
    for (int i = 0; i < (g_fast ? 1 : 3); ++i) view.draw(canvas);   // a few frames: caches fill, telemetry arrives
    const auto t0 = std::chrono::steady_clock::now();
    const int timed = g_fast ? 1 : 5;
    for (int i = 0; i < timed; ++i) view.draw(canvas);
    const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / timed;
    CHECK(writePng(g_out + "/" + name + ".png", canvas));
    std::printf("wrote %s.png  (%.1f ms per picture)\n", name.c_str(), ms);
    checkLight(view, name);
#ifdef IMAK_GL_COMPARE
    checkVideoCard(view, name);
#endif
}
} // namespace

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: %s <fonts dir> <output dir>\n", argv[0]); return 2; }
    setFontDirectory(argv[1]);
    CHECK(fontsReady());
    g_out = argv[2];
    g_fast = argc > 3;
    char tmpl[] = "/tmp/imak-ui-render-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string dir = tmpl;
    const std::vector<std::string> names = {
        "Grand Piano", "Bright Piano", "Electric Piano", "Rhodes Tine", "Wurlitzer", "Clavinet", "Church Organ", "Rock Organ", "Warm Pad", "Soft Strings",
        "String Ensemble", "Brass Section", "Trumpet", "Alto Sax", "Flute", "Oboe", "Nylon Guitar", "Steel Guitar", "Fretless Bass", "Slap Bass",
        "Choir Aahs", "Vocal Ooh", "Marimba", "Vibraphone", "Harp", "Music Box", "Bell Tree", "Synth Lead", "Analog Bass", "Sweep Pad",
        "Kronos Piano Concert", "Sine Wave", "Saw Wave", "Square Wave", "Noise Wash", "Dulcimer", "Accordion", "Harmonica", "Banjo", "Sitar"};
    const std::string bank = dir + "/SILVETON_BANK.sv";
    writeBank(bank, names);

    ControllerEnv env;
    env.dataDir = dir + "/data";
    env.bankCandidates = {bank};
    SamplerAppController controller(env);
    controller.engine.setBackends(std::make_unique<silveton::host::OfflineAudioOutput>(96000.0, 96U), std::make_unique<silveton::host::ManualMidiInput>());
    CHECK(controller.start());
    for (int i = 0; i < 100 && controller.soundCatalog().empty(); ++i) usleep(50000);
    const auto catalog = controller.soundCatalog();
    CHECK(catalog.size() == names.size());

    // an interesting COMBI: five Uppers with sounds
    const int pick[5] = {0, 8, 10, 18, 22};
    for (int u = 0; u < 5; ++u) {
        CHECK(controller.assignUpperSound(u, catalog[static_cast<std::size_t>(pick[u])]));
        auto s = controller.upperState(u);
        CHECK(s.has_value());
        SamplerAppController::UpperState n = *s;
        n.enabled = true;
        n.levelDb = u == 0 ? 0.0F : -2.0F * static_cast<float>(u);
        n.pan = u == 0 ? 0.0F : (u % 2 == 0 ? 0.35F : -0.35F);
        if (u == 3) { n.keyLow = 36; n.keyHigh = 59; }
        if (u == 1) { n.keyLow = 60; n.keyHigh = 127; }
        controller.updateUpperMain(u, n);
    }
    controller.setLayerSound(0, 0, catalog[10].slot);
    controller.setLayerSound(0, 1, catalog[9].slot);

    // some BLENDS in the LIST
    const int listPos[] = {0, 1, 2, 3, 6, 7, 12, 29, 30, 45};
    const char* listNames[] = {"Piano + Strings", "Warm Layers", "Concert Grand", "Rhodes Night", "Church Pad", "Brass Stab", "Soft Organ", "Last of page 1", "First of page 2", "Page 2 pad"};
    for (int i = 0; i < 10; ++i) CHECK(controller.writeCombiToList(listPos[i], listNames[i]) >= 0);

    // SILVETON_ONLY_OLD_V1: the program opens with the OLD look; the checks below are of the new screens, which are switched off in the program
    CHECK(controller.uiTheme() == 4);
    {
        SilvetonSamplerView first(controller);
        CHECK(ViewTestAccess::classicView(first) != nullptr);
    }
    controller.setUiTheme(0);
    SilvetonSamplerView view(controller);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    view.refreshAllForTests();
    using TA = ViewTestAccess;
    using Tab = TA::Tab;

    shot(view, "combi");                                   // the COMBI page as it opens (TUNE of Upper 1)
    TA::edit(view, 0, 0, Tab::TONE);       shot(view, "combi_tone");
    TA::edit(view, 0, 0, Tab::WAVE);       shot(view, "combi_wave_off");
    CHECK(controller.setSoundWaveParam(0, 0, 0, 1.0F)); CHECK(controller.setSoundWaveParam(0, 0, 6, 1.0F)); CHECK(controller.setSoundWaveParam(0, 0, 3, 0.2F));
    view.refreshAllForTests(); TA::edit(view, 0, 0, Tab::WAVE); shot(view, "combi_wave_auto");
    CHECK(controller.setSoundWaveParam(0, 0, 0, 2.0F)); CHECK(controller.setSoundWaveParam(0, 0, 6, 2.0F));
    CHECK(controller.setSoundWaveParam(0, 0, 10, static_cast<float>(catalog[28].slot))); CHECK(controller.setSoundWaveParam(0, 0, 11, static_cast<float>(catalog[31].slot))); CHECK(controller.setSoundWaveParam(0, 0, 12, static_cast<float>(catalog[32].slot)));
    view.refreshAllForTests(); TA::edit(view, 0, 0, Tab::WAVE); shot(view, "combi_wave_multi");
    TA::picker(view, 0, 100 + 3);          // the picker of frame 4 of MULTI
    TA::pickerAssignItem(view, catalog[5]);
    CHECK(static_cast<int>(controller.soundWaveParams(0, 0)[13]) == catalog[5].slot);   // slot 4 = id 13
    shot(view, "combi_wave_picker");
    TA::pickerAssignItem(view, catalog[6]);
    CHECK(static_cast<int>(controller.soundWaveParams(0, 0)[13]) == catalog[6].slot);
    TA::closePicker(view);
    CHECK(controller.setSoundWaveParam(0, 0, 0, 0.0F));
    view.refreshAllForTests();
    TA::edit(view, 0, 0, Tab::RANGE);      shot(view, "combi_range");
    {   // SILVETON_KEYRANGE_V1 + SILVETON_VELOCITY_V1: RANGE = the keys only; VEL = the five sounds on one scale, curves, fades, crossfade
        using P = SilvetonSamplerView::PointerAction;
        Canvas cv(1340, 800);
        // (the numbers below are in the units of the older page; TA::ex / ey put them where the new frame shows it)
        const auto press = [&](float x, float y) { view.draw(cv); view.pointer(P::Down, TA::ex(x), TA::ey(y)); view.pointer(P::Up, TA::ex(x), TA::ey(y)); view.draw(cv); };
        const auto drag = [&](float x0, float y0, float x1, float y1) {
            view.draw(cv);
            view.pointer(P::Down, TA::ex(x0), TA::ey(y0));
            for (int i = 1; i <= 6; ++i) {
                const float t = static_cast<float>(i) / 6.0F;
                view.pointer(P::Move, TA::ex(x0 + (x1 - x0) * t), TA::ey(y0 + (y1 - y0) * t));
                view.draw(cv);
            }
            view.pointer(P::Up, TA::ex(x1), TA::ey(y1));
            view.draw(cv);
        };
        // ---- RANGE has no velocity any more; the key ends of a layer are dragged on its row
        TA::edit(view, 0, 1, Tab::RANGE);
        view.refreshAllForTests();
        shot(view, "combi_range_layer");
        CHECK(static_cast<int>(controller.layerParams(0, 0)[6]) == 0);
        drag(940.0F, 626.0F, 1018.19F, 626.0F);                               // L1: the lowest key to 36
        CHECK(static_cast<int>(controller.layerParams(0, 0)[6]) == 36);
        CHECK(static_cast<int>(controller.layerParams(0, 0)[7]) == 127);
        CHECK(TA::editSoundOf(view) == 1);
        press(910.0F, 662.0F);                                                // the label of L2: the page now edits L2
        CHECK(TA::editSoundOf(view) == 2);
        press(910.0F, 590.0F);                                                // ... and the label of ОСН
        CHECK(TA::editSoundOf(view) == 0);
        // the key ends by playing: a tap, then the key on the MIDI keyboard (the second tap cancels)
        press(620.0F, 557.0F);
        CHECK(controller.keyScanUpper() == 0 && controller.keyScanEdge() == 0 && controller.keyScanSound() == 0);
        press(620.0F, 557.0F);
        CHECK(controller.keyScanUpper() < 0);
        press(790.0F, 557.0F);
        CHECK(controller.keyScanUpper() == 0 && controller.keyScanEdge() == 1);
        press(790.0F, 557.0F);
        CHECK(controller.keyScanUpper() < 0);
        CHECK(controller.setLayerParam(0, 0, 6, 0.0F));                       // L1 back to the whole keyboard

        // ---- VEL: L1 goes out at 80 over 20 steps, L2 comes in from 60 over 20 steps, both crossfade
        CHECK(controller.setLayerParam(0, 0, 9, 80.0F)); CHECK(controller.setLayerParam(0, 0, 33, 20.0F)); CHECK(controller.setLayerParam(0, 0, 47, 1.0F));
        CHECK(controller.setLayerParam(0, 1, 8, 60.0F)); CHECK(controller.setLayerParam(0, 1, 32, 20.0F)); CHECK(controller.setLayerParam(0, 1, 47, 1.0F));
        view.refreshAllForTests();
        TA::edit(view, 0, 1, Tab::VELOCITY);  shot(view, "combi_vel");
        CHECK(static_cast<int>(controller.layerParams(0, 0)[33]) == 20 && static_cast<int>(controller.layerParams(0, 0)[32]) == 0);   // the fades are where the page reads them
        drag(426.5F, 626.0F, 473.1F, 626.0F);                                  // the highest value of L1 to 100
        CHECK(static_cast<int>(controller.layerParams(0, 0)[9]) == 100);
        press(160.0F, 662.0F);                                                // L2 (the label of row 2)
        CHECK(TA::editSoundOf(view) == 2);
        const float fadeBefore = controller.layerParams(0, 1)[32];
        drag(1005.0F, 589.0F, 1005.0F, 529.0F);                                // the FADE IN chip, dragged up
        CHECK(controller.layerParams(0, 1)[32] > fadeBefore);
        press(780.0F, 712.0F);                                                 // the ready curve HARD
        CHECK(static_cast<int>(controller.layerParams(0, 1)[35]) == 2);
        drag(747.0F, 630.0F, 747.0F, 600.0F);                                  // a drag on the graph = the own curve, starting like HARD
        CHECK(static_cast<int>(controller.layerParams(0, 1)[35]) == 6);
        CHECK(std::abs(controller.layerParams(0, 1)[36 + 4] - 103.0F) <= 1.5F);
        shot(view, "combi_vel_custom");
        press(1200.0F, 733.0F); press(1200.0F, 733.0F);                        // НУЛИРАЙ (double tap)
        CHECK(static_cast<int>(controller.layerParams(0, 1)[35]) == 0 && static_cast<int>(controller.layerParams(0, 1)[32]) == 0);
        CHECK(static_cast<int>(controller.layerParams(0, 1)[8]) == 60);        // the range stays
        // ОСНОВЕН: the same page reads and writes the Upper's own ids (50.., 55..)
        TA::edit(view, 0, 0, Tab::VELOCITY);
        press(780.0F, 712.0F);                                                 // HARD
        CHECK(static_cast<int>(controller.upperParams(0)[55]) == 2);
        press(1004.0F, 733.0F);                                                // САМОСТ. L1–L4 (toggle)
        CHECK(controller.upperParams(0)[54] < 0.5F);
        press(1004.0F, 733.0F);
        CHECK(controller.upperParams(0)[54] >= 0.5F);
        press(1200.0F, 697.0F);                                                // КРОСФЕЙД of ОСНОВЕН
        CHECK(controller.upperParams(0)[67] >= 0.5F);
        shot(view, "combi_vel_basic");
        CHECK(controller.setUpperParam(0, 55, 0.0F)); CHECK(controller.setUpperParam(0, 67, 0.0F));
        CHECK(controller.setLayerParam(0, 0, 9, 127.0F)); CHECK(controller.setLayerParam(0, 0, 33, 0.0F)); CHECK(controller.setLayerParam(0, 0, 47, 0.0F));
        CHECK(controller.setLayerParam(0, 1, 8, 1.0F)); CHECK(controller.setLayerParam(0, 1, 47, 0.0F));
        view.refreshAllForTests();
        TA::edit(view, 0, 0, Tab::RANGE);
    }
    TA::edit(view, 3, 0, Tab::TUNE);       shot(view, "combi_tune_u4");
    TA::edit(view, 0, 1, Tab::TUNE);       shot(view, "combi_layer");
    TA::common(view, 0, Tab::PORTA);       shot(view, "combi_porta");
    {   // SILVETON_BASS_PORTA_V1: the VOICE page with the BASS portamento on, then back to SILVETON for the pictures that follow
        CHECK(controller.setUpperParam(0, 42, 3.0F)); view.refreshAllForTests();
        TA::common(view, 0, Tab::PORTA);   shot(view, "combi_porta_bass");
        CHECK(controller.setUpperParam(0, 42, 0.0F)); view.refreshAllForTests();
    }
    TA::common(view, 0, Tab::CONTROL);     shot(view, "combi_control");
    TA::common(view, 0, Tab::FX);          shot(view, "combi_fx");
    {   // SILVETON_ENGINES_V1: the ENGINE page - OFF, then a few engines and their three pages
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_off");
        CHECK(controller.setUpperEngineParam(0, 0, 7.0F)); view.refreshAllForTests();      // CX-3
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_cx3");
        CHECK(controller.setUpperEngineParam(0, 0, 2.0F)); view.refreshAllForTests();      // POLYSIX
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_polysix");
        TA::enginePage(view, 1);           shot(view, "combi_engine_filter");
        TA::enginePage(view, 2);           shot(view, "combi_engine_mod");
        TA::enginePage(view, 3);           shot(view, "combi_engine_ofs");   // SILVETON_OFS_V1
        TA::enginePage(view, 100);         shot(view, "combi_engine_select");   // SILVETON_UI_KRONOS_V1: the page ДВИГАТЕЛ
        TA::enginePage(view, 101);         shot(view, "combi_engine_output");   // the page ИЗХОД
        TA::enginePage(view, 0);
        CHECK(controller.setUpperEngineParam(0, 0, 3.0F)); view.refreshAllForTests();      // MS-20
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_ms20");
        CHECK(controller.setUpperEngineParam(0, 0, 5.0F)); view.refreshAllForTests();      // MOD-7
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_mod7");
        CHECK(controller.setUpperEngineParam(0, 0, 6.0F)); view.refreshAllForTests();      // STR-1
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_str1");
        CHECK(controller.setUpperEngineParam(0, 0, 8.0F)); view.refreshAllForTests();      // SGX
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_sgx");
        CHECK(controller.setUpperEngineParam(0, 0, 9.0F)); view.refreshAllForTests();      // EP
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_ep");
        CHECK(controller.setUpperEngineParam(0, 0, 4.0F)); view.refreshAllForTests();      // AL-1
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_al1");
        TA::theme(view, true);             shot(view, "combi_engine_dark");
        TA::theme(view, false);
        CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();      // back to OFF for the pictures that follow
    }
    TA::common(view, 0, Tab::EQ);          shot(view, "combi_eq");
    TA::edit(view, 0, 0, Tab::TUNE);
    TA::theme(view, true);                 shot(view, "combi_dark");          // the ТЪМНА theme of the settings
    TA::common(view, 0, Tab::PORTA);       shot(view, "combi_dark_voice");
    TA::theme(view, false);
    TA::edit(view, 0, 0, Tab::TUNE);
    TA::dropdown(view, 0);                 shot(view, "combi_dropdown");
    TA::dropdown(view, -1);
    TA::mark(view, true, 0, 2);            shot(view, "combi_marked");
    TA::mark(view, false, 0, 2);
    {   // SILVETON_COMBI_DROP_V1: a SOUND of the Manager dropped into each of the 35 places of the COMBI page
        CHECK(view.prepareComboDrop());
        const auto slots = view.comboSlots();
        CHECK(slots.size() == 35U);
        for (const auto& s : slots) {
            CHECK(s.right - s.left > 100.0F && s.bottom - s.top > 50.0F);
            CHECK(s.left >= 10.0F && s.right <= 1330.0F && s.top >= 80.0F && s.bottom <= 736.0F);   // inside the strips (SILVETON_PRO_UI_V1)
            int hits = 0;
            for (const auto& other : slots) if (other.contains((s.left + s.right) * 0.5F, (s.top + s.bottom) * 0.5F)) ++hits;
            CHECK(hits == 1);                                  // every point belongs to one place only
        }
        CHECK(slots[0].label == "ОСНОВЕН" && slots[4].label == "L4");
        CHECK(slots[0].sound == "Grand Piano");                // Upper 1: ОСНОВЕН
        CHECK(slots[1].sound == "String Ensemble");            // L1
        CHECK(slots[2].sound == "Soft Strings");               // L2
        CHECK(slots[3].sound.empty() && slots[4].sound.empty());
        CHECK(slots[30].sound.empty());                        // Upper 7 is empty
        CHECK(view.dropSoundIntoSlot(0, 3, catalog[1].slot, catalog[1].name));        // L3 of Upper 1 (an empty layer)
        CHECK(controller.layerName(0, 2) == catalog[1].name);
        CHECK(controller.layerName(0, 0) == "String Ensemble" && controller.layerName(0, 1) == "Soft Strings");   // the others stay
        CHECK(view.dropSoundIntoSlot(0, 2, catalog[19].slot, catalog[19].name));      // L2 replaced
        CHECK(controller.layerName(0, 1) == catalog[19].name && controller.layerName(0, 0) == "String Ensemble");
        CHECK(view.dropSoundIntoSlot(0, 0, catalog[5].slot, catalog[5].name));        // ОСНОВЕН replaced
        CHECK(controller.upperState(0).has_value() && controller.upperState(0)->soundName == catalog[5].name);
        CHECK(view.dropSoundIntoSlot(6, 4, catalog[7].slot, catalog[7].name));        // L4 of the empty Upper 7
        CHECK(controller.layerName(6, 3) == catalog[7].name);
        CHECK(!view.dropSoundIntoSlot(0, 5, catalog[1].slot, "x") && !view.dropSoundIntoSlot(7, 0, catalog[1].slot, "x"));
        CHECK(!view.dropSoundIntoSlot(0, 0, 0, "x") && !view.dropSoundIntoSlot(0, 0, 501, "x"));
        const auto after = view.comboSlots();
        CHECK(after.size() == 35U && after[0].sound == catalog[5].name && after[2].sound == catalog[19].name && after[3].sound == catalog[1].name && after[34].sound == catalog[7].name);
        shot(view, "combi_after_drop");
        {   // SILVETON_LAYER_MOVE_V1: the sound field of the strip is the handle; copy and move between places
            const float fieldX = 10.0F + 60.0F;                                           // SILVETON_PRO_UI_V1: the strips of the new frame
            const auto src = view.layerSourceAt(fieldX, 80.0F + 55.0F);                  // the strip of Upper 1 shows ОСНОВЕН
            CHECK(src.has_value() && src->upper == 0 && src->slot == 0 && src->name == catalog[5].name && src->sound == catalog[5].slot);
            CHECK(!view.layerSourceAt(fieldX, 80.0F + 200.0F).has_value());               // not on the sound field
            CHECK(!view.layerSourceAt(5.0F, 150.0F).has_value());                         // outside the strips
            const float field7 = 10.0F + 6.0F * ((1320.0F - 36.0F) / 7.0F + 6.0F) + 60.0F;
            const auto src7 = view.layerSourceAt(field7, 80.0F + 55.0F);                  // the strip of Upper 7 shows L4 (the drop selected it)
            CHECK(src7.has_value() && src7->upper == 6 && src7->slot == 4 && src7->name == catalog[7].name);
            CHECK(controller.setLayerParam(1, 2, 1, -6.0F));                              // L3 of Upper 2 has its own level
            CHECK(view.moveLayerSound(0, 0, 1, 3, true));                                 // COPY ОСНОВЕН of Upper 1 -> L3 of Upper 2
            CHECK(controller.layerName(1, 2) == catalog[5].name && controller.upperState(0)->soundName == catalog[5].name);
            CHECK(std::fabs(controller.layerParams(1, 2)[1] - (-6.0F)) < 0.001F);          // the settings of the place stayed
            CHECK(view.moveLayerSound(0, 2, 2, 4, false));                                // MOVE L2 of Upper 1 -> L4 of Upper 3
            CHECK(controller.layerName(2, 3) == catalog[19].name);
            CHECK(controller.layerParams(0, 1)[31] == 0.0F);                              // L2 of Upper 1 is empty now
            CHECK(controller.layerName(0, 0) == "String Ensemble");                       // the others stay
            CHECK(!view.moveLayerSound(0, 2, 2, 4, false));                               // the source is empty: nothing to move
            CHECK(!view.moveLayerSound(2, 4, 2, 4, false) && !view.moveLayerSound(0, 0, 0, 5, false) && !view.moveLayerSound(7, 0, 0, 1, false));
            CHECK(view.moveLayerSound(6, 4, 6, 0, false));                                // MOVE L4 of Upper 7 -> ОСНОВЕН of Upper 7
            CHECK(controller.upperState(6)->soundName == catalog[7].name && controller.layerParams(6, 3)[31] == 0.0F);
            CHECK(view.moveLayerSound(6, 0, 3, 1, true));                                 // COPY ОСНОВЕН of Upper 7 -> L1 of Upper 4
            CHECK(controller.layerName(3, 0) == catalog[7].name);
            shot(view, "combi_after_move");
            CHECK(controller.setLayerSound(1, 2, 0));
            CHECK(controller.setLayerParam(1, 2, 1, 0.0F));
            CHECK(controller.setLayerSound(2, 3, 0));
            CHECK(controller.setLayerSound(3, 0, 0));
            CHECK(controller.clearUpperSound(6));
        }
        // back to the COMBI the following pictures expect
        CHECK(view.dropSoundIntoSlot(0, 0, catalog[0].slot, catalog[0].name));
        CHECK(view.dropSoundIntoSlot(0, 2, catalog[9].slot, catalog[9].name));
        CHECK(controller.setLayerSound(0, 2, 0));
        CHECK(controller.setLayerSound(6, 3, 0));
        view.refreshAllForTests();
        TA::edit(view, 0, 0, Tab::TUNE);
    }
    TA::picker(view, 0, -1);               shot(view, "combi_picker");
    TA::pickerMark(view, true, {catalog[1].slot, catalog[3].slot, catalog[8].slot});   shot(view, "combi_picker_mark");   // SILVETON_MULTI_DELETE_V1
    TA::pickerMark(view, false, {});
    TA::pickerPage(view, 1);               shot(view, "combi_picker_empty");   // SILVETON_SOUND_BY_NUMBER_V2: page 2 = places 041..080, the empty ones shown
    TA::pickerPage(view, 0);
    TA::closePicker(view);
    TA::numberDialog(view);                shot(view, "dialog_number");
    TA::closeDialogs(view);
    TA::textDialog(view);                  shot(view, "dialog_text");
    TA::closeDialogs(view);

    // The tablet has no keyboard of its own: the dialogs draw one (Latin / Bulgarian БДС letters, digits).
    TA::softKeyboard(view, true);
    TA::textDialog(view);                  shot(view, "dialog_text_kb");
    CHECK(TA::keyCount(view) > 30U);
    CHECK(TA::pressKey(view, "ИЗЧИСТИ"));  CHECK(TA::dialogValue(view).empty());
    CHECK(TA::pressKey(view, "P"));        CHECK(TA::dialogValue(view) == "P");       // a capital at the start of the sentence
    CHECK(TA::pressKey(view, "i"));        CHECK(TA::dialogValue(view) == "Pi");
    CHECK(TA::pressKey(view, "SHIFT"));                                                  // one capital
    CHECK(TA::pressKey(view, "A"));        CHECK(TA::dialogValue(view) == "PiA");
    CHECK(TA::pressKey(view, "n"));        CHECK(TA::dialogValue(view) == "PiAn");
    CHECK(TA::pressKey(view, "DELETE"));        CHECK(TA::dialogValue(view) == "PiA");
    CHECK(TA::pressKey(view, "EN"));                                                   // the Bulgarian letters
    shot(view, "dialog_text_kb_bg");
    CHECK(TA::pressKey(view, "ИЗЧИСТИ"));
    CHECK(TA::pressKey(view, "П"));        CHECK(TA::pressKey(view, "р"));  CHECK(TA::pressKey(view, "и"));
    CHECK(TA::pressKey(view, "в"));        CHECK(TA::pressKey(view, "е"));  CHECK(TA::pressKey(view, "т"));
    CHECK(TA::dialogValue(view) == "Привет");
    CHECK(TA::pressKey(view, " "));        CHECK(TA::pressKey(view, "ю"));  CHECK(TA::pressKey(view, "щ"));
    CHECK(TA::dialogValue(view) == "Привет ющ");
    CHECK(TA::pressKey(view, "БГ"));
    shot(view, "dialog_text_kb_end");
    TA::closeDialogs(view);
    TA::numberDialog(view);                shot(view, "dialog_number_kb");
    CHECK(TA::pressKey(view, "ИЗЧИСТИ"));
    CHECK(TA::pressKey(view, "1"));        CHECK(TA::pressKey(view, "2"));  CHECK(TA::pressKey(view, "."));
    CHECK(TA::pressKey(view, "5"));        CHECK(TA::pressKey(view, "±"));
    CHECK(TA::dialogValue(view) == "-12.5");
    CHECK(TA::pressKey(view, "±"));        CHECK(TA::dialogValue(view) == "12.5");
    CHECK(TA::pressKey(view, "DELETE"));        CHECK(TA::dialogValue(view) == "12.");
    TA::closeDialogs(view);
    TA::softKeyboard(view, false);
    TA::textDialog(view);
    CHECK(TA::keyCount(view) == 0U || (TA::pressKey(view, "q") == false));         // no keyboard when it is not asked for
    shot(view, "dialog_text");
    TA::closeDialogs(view);
    view.showToast("MASTER +2 dB");        shot(view, "toast");
    CHECK(TA::pairCheck(view, controller)); // a second finger on the + of a - / + pair = reset
    TA::soundGrid(view);                   shot(view, "dialog_grid");
    TA::closeDialogs(view);
    TA::confirm(view);                     shot(view, "dialog_confirm");
    TA::closeDialogs(view);
    TA::items(view);                       shot(view, "dialog_items");
    TA::closeDialogs(view);

    // LIST and WRITE
    view.setPage(SilvetonSamplerView::Page::LIST);
    TA::listFav(view, 2); TA::listFav(view, 12);
    view.refreshAllForTests();
    shot(view, "list");
    TA::listSelect(view, 5);               shot(view, "list_selected");
    TA::listMark(view, true, {30, 45});    shot(view, "list_mark");       // SILVETON_MULTI_DELETE_V1 (page 2 is shown)
    TA::listMark(view, false, {});
    TA::listMenu(view, 2);                 shot(view, "list_menu");
    TA::closeDialogs(view);
    TA::storeDialog(view);                 shot(view, "list_store");
    TA::closeDialogs(view);
    TA::openCopy(view, 2);                 shot(view, "write_copy");
    TA::closeWrite(view);
    TA::openWriteScreen(view, false);      shot(view, "write_list");
    TA::openWriteScreen(view, true);       shot(view, "write_blend");
    TA::closeWrite(view);
    TA::search(view, "pad");               shot(view, "list_search");
    TA::search(view, "");
    TA::favOnly(view, true);               shot(view, "list_favs");
    TA::favOnly(view, false);

    // EFFECTS
    view.setPage(SilvetonSamplerView::Page::EFFECTS);
    TA::fx(view, 0, 4);                    shot(view, "effects_hall");
    TA::fx(view, 1, 1);                    shot(view, "effects_delay");
    TA::fx(view, 2, 14);                   shot(view, "effects_rotary");
    TA::fx(view, 3, 15);                   shot(view, "effects_comp");
    TA::focus(view, 5);                    shot(view, "effects_insert_off");
    TA::focus(view, 0);

    // SETTINGS
    view.setPage(SilvetonSamplerView::Page::SETTINGS);
    TA::settingsTab(view, 0);              shot(view, "settings");
    TA::settingsTab(view, 1);              shot(view, "settings_midi");
    TA::settingsTab(view, 2);              shot(view, "settings_info");
    TA::deleteSounds(view);                shot(view, "settings_delete");
    TA::closeDialogs(view);
    TA::settingsTab(view, 0);
    // SILVETON_PRO_UI_V1: the screens in ENGLISH (SETTINGS > LANGUAGE), then back to БЪЛГАРСКИ
    TA::language(view, 1);                 shot(view, "settings_en");
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "combi_en");
    CHECK(controller.setUpperEngineParam(0, 0, 4.0F)); view.refreshAllForTests();
    TA::common(view, 0, Tab::ENGINE);      shot(view, "combi_engine_en");
    CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();
    TA::common(view, 0, Tab::FX);          shot(view, "effects_en");
    view.setPage(SilvetonSamplerView::Page::LIST);
    shot(view, "list_en");
    TA::language(view, 0);
    CHECK(controller.uiLanguage() == 0);
    view.setPage(SilvetonSamplerView::Page::SETTINGS);

    // SILVETON_THEMES_V1: the three themes (ГРАФИТ is every picture above), the choice is kept
    TA::uiTheme(view, 1);                  shot(view, "theme_light_settings");
    CHECK(controller.uiTheme() == 1);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "theme_light_mixer");
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_light_engine");
    view.setPage(SilvetonSamplerView::Page::LIST);
    shot(view, "theme_light_list");
    TA::uiTheme(view, 2);                  shot(view, "theme_black_list");
    CHECK(controller.uiTheme() == 2);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "theme_black_mixer");
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_black_engine");
    view.setPage(SilvetonSamplerView::Page::SETTINGS);
    shot(view, "theme_black_settings");
    TA::uiTheme(view, 3);                  shot(view, "theme_classic_settings");
    CHECK(controller.uiTheme() == 3);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "theme_classic_mixer");
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_classic_engine");
    CHECK(controller.setUpperEngineParam(0, 0, 6.0F)); view.refreshAllForTests();      // STR-1 on a page of knobs
    TA::enginePage(view, 0);
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_classic_str1");
    CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();
    TA::enginePage(view, 100);
    view.setPage(SilvetonSamplerView::Page::LIST);
    shot(view, "theme_classic_list");
    // SILVETON_OLD_THEME_V1: the whole OLD look as a theme (СТАРА), and the way back from its SETTINGS page
    TA::uiTheme(view, 4);
    CHECK(controller.uiTheme() == 4);
    CHECK(TA::classicView(view) != nullptr);
    {
        using Old = classic::SilvetonSamplerView;
        Old* old = TA::classicView(view);
        old->setPage(Old::Page::COMBI);      shot(view, "theme_old_combi");
        CHECK(controller.setUpperEngineParam(7, 0, 2.0F)); old->refreshAllForTests();      // POLYSIX under the old mixer
        classic::ViewTestAccess::engineTab(*old);  shot(view, "theme_old_engine");
        CHECK(controller.setUpperEngineParam(7, 0, 0.0F)); old->refreshAllForTests();
        {   // SILVETON_SUSE_V1: SILVETON SYNTH on the ДВИГАТЕЛИ page - the 12 pages as the tablet draws them, and real finger taps
            using VT = classic::ViewTestAccess;
            namespace su = sv::suse;
            const auto load = [&](int preset) {
                std::vector<float> p(static_cast<std::size_t>(su::kParamCount));
                su::factoryPreset(preset, p.data());
                CHECK(controller.setUpperEngineBlock(7, 1, p));
                old->refreshAllForTests();
                VT::engineTab(*old);
                VT::suStatusClear(*old);
            };
            // the page keys of the head: 12 keys, 75 px apart, the first one starts at x = 410
            const auto pageKeyX = [](int k) { return 388.0F + 22.0F + static_cast<float>(k) * 75.0F + 34.0F; };
            CHECK(controller.setUpperEngineParam(7, 0, static_cast<float>(static_cast<int>(sv::EngineType::Suse)))); old->refreshAllForTests();
            VT::engineTab(*old);   VT::engineSlot(*old, 0);
            CHECK(controller.upperEngineParams(7).size() == static_cast<std::size_t>(su::kParamCount) + 1U);
            VT::suPage(*old, 0);   VT::suGen(*old, 0, 0);   shot(view, "suse_01_osc_simple_start");
            {   // the portamento card of ДВИГАТЕЛИ: KRONOS shows TIME, FINGERED and TIME / RATE; a tap on FINGERED lights it; back to SILVETON
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 452.0F, 716.0F);                                   // KRONOS (the first page)
                { Canvas redraw(1340, 800); old->draw(redraw); }
                shot(view, "suse_29_osc_porta_kronos");
                VT::suTap(*old, 748.0F, 704.0F);                                   // FINGERED
                { Canvas redraw(1340, 800); old->draw(redraw); }
                shot(view, "suse_30_osc_porta_kronos_fingered");
                VT::suTap(*old, 748.0F, 704.0F);                                   // FINGERED off again
                VT::suTap(*old, 452.0F, 686.0F);                                   // SILVETON again
                { Canvas redraw(1340, 800); old->draw(redraw); }
            }
            load(10);              VT::suGen(*old, 0, 0);   shot(view, "suse_02_osc_simple_fm_epiano");
            {   // the simple screen with the finger: wave A key -> the pictures -> a picture -> back, and the mix slider
                load(0);
                CHECK(VT::suPageNow(*old) == 0);
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 404.0F + 145.0F, 412.0F + 38.0F + 52.0F);          // the key ВЪЛНОВА ФОРМА А
                CHECK(VT::suPageNow(*old) == 1 && VT::suPickSlotNow(*old) == 0);
                shot(view, "suse_03_osc_choose_wave_a");
                const float cw = (600.0F - 4.0F * 9.0F) / 10.0F, ch = (364.0F - 22.0F - 4.0F * 6.0F) / 7.0F;
                VT::suTap(*old, 404.0F + 5.0F * (cw + 4.0F) + cw * 0.5F, 412.0F + 22.0F + 1.0F * (ch + 4.0F) + ch * 0.5F);   // the 16th picture
                CHECK(VT::suPageNow(*old) == 0 && VT::suPickSlotNow(*old) == -1);
                CHECK(std::lround(controller.upperEngineParams(7)[static_cast<std::size_t>(su::genId(0, su::GN_SEL1)) + 1U]) == 15);
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 404.0F + 906.0F - 145.0F, 412.0F + 38.0F + 52.0F);  // the key ВЪЛНОВА ФОРМА Б
                CHECK(VT::suPageNow(*old) == 1 && VT::suPickSlotNow(*old) == 1);
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 1326.0F - 150.0F, 412.0F + 232.0F);                  // ОТКАЗ: back, nothing changed
                CHECK(VT::suPageNow(*old) == 0 && VT::suPickSlotNow(*old) == -1);
                CHECK(std::lround(controller.upperEngineParams(7)[static_cast<std::size_t>(su::genId(0, su::GN_SEL2)) + 1U]) == 4);
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 404.0F + 453.0F + 40.0F, 412.0F + 38.0F + 50.0F);   // the mix slider, a bit right of the middle
                CHECK(controller.upperEngineParams(7)[static_cast<std::size_t>(su::genId(0, su::GN_F0)) + 1U] > 0.55F);
                shot(view, "suse_04_osc_simple_after_choice");
            }
            load(7);               VT::suGen(*old, 0, 0);   shot(view, "suse_05_osc_simple_string");
            load(0);
            VT::suOscAdvanced(*old, true);
            VT::suGen(*old, 0, 0);                          shot(view, "suse_06_osc_all_settings_sound");
            VT::suGen(*old, 1, 1);                          shot(view, "suse_07_osc_all_settings_tone");
            VT::suGen(*old, 0, 2);                          shot(view, "suse_08_osc_all_settings_filter");
            VT::suOscAdvanced(*old, false);
            {   // a drawn wave built from harmonics, then the pictures and the editor
                float amp[su::kEditHarmonics] = {}, ph[su::kEditHarmonics] = {}, pts[su::kDrawLen];
                amp[0] = 1.0F; amp[1] = 0.55F; amp[2] = 0.3F; amp[4] = 0.35F; amp[6] = 0.2F; amp[10] = 0.12F; ph[1] = 1.0F; ph[4] = -0.8F;
                su::waveFromHarmonics(amp, ph, pts);
                std::vector<float> v(static_cast<std::size_t>(su::kDrawLen));
                for (int i = 0; i < su::kDrawLen; ++i) v[static_cast<std::size_t>(i)] = 0.5F + 0.5F * pts[i];
                CHECK(controller.setUpperEngineBlock(7, su::drawId(0, 0) + 1, v)); old->refreshAllForTests();
                VT::engineTab(*old);
            }
            load(0);
            VT::suPage(*old, 1);   VT::suPick(*old, 3, 0);  shot(view, "suse_05_wave_pictures");
            {   // two real taps: the picture of the 8th wave, then ПОСТАВИ КАТО ВЪЛНА Б; the oscillator 1 must then hold that wave as B
                const float cw = (600.0F - 4.0F * 9.0F) / 10.0F, ch = (364.0F - 22.0F - 4.0F * 6.0F) / 7.0F;
                VT::suTap(*old, 404.0F + 7.0F * (cw + 4.0F) + cw * 0.5F, 412.0F + 22.0F + ch * 0.5F);
                VT::suTap(*old, 404.0F + 620.0F + 140.0F, 412.0F + 293.0F);
                const auto got = controller.upperEngineParams(7);
                CHECK(std::lround(got[static_cast<std::size_t>(su::genId(0, su::GN_SEL2)) + 1U]) == 7);
                CHECK(std::lround(got[static_cast<std::size_t>(su::genId(0, su::GN_METHOD)) + 1U]) == su::M_WAVE);
                shot(view, "suse_06_wave_pictures_after_tap");
            }
            VT::suPick(*old, su::kWaveDrawn0, 0);          shot(view, "suse_07_wave_pictures_drawn");
            VT::suPage(*old, 2);   VT::suWave(*old, 0, 1); shot(view, "suse_08_draw_harmonics");
            VT::suWave(*old, 0, 0);                         shot(view, "suse_09_draw_free");
            load(12);              VT::suPage(*old, 3);   VT::suLink(*old, 0, 1); shot(view, "suse_10_fm_pm_six_operators");
            {   // the amount of a link that is OFF chooses the type itself (the user's "nothing changes")
                load(0);
                CHECK(controller.setUpperEngineParam(7, su::genId(1, su::GN_METHOD) + 1, static_cast<float>(su::M_WAVE))); old->refreshAllForTests();
                VT::engineTab(*old);
                CHECK(std::lround(controller.upperEngineParams(7)[static_cast<std::size_t>(su::linkType(1, 0)) + 1U]) == su::L_OFF);
                VT::suLink(*old, 1, 0);
                VT::suSetValue(*old, 7, su::linkAmt(1, 0), 0.6F);
                CHECK(std::lround(controller.upperEngineParams(7)[static_cast<std::size_t>(su::linkType(1, 0)) + 1U]) == su::L_PM);
                shot(view, "suse_11_fm_pm_auto_type");
            }
            load(6);               VT::suPage(*old, 4);   VT::suGen(*old, 0, 0);  shot(view, "suse_12_physics_violin");
            load(3);               VT::suPage(*old, 4);                           shot(view, "suse_13_physics_zurna");
            load(7);               VT::suPage(*old, 4);                           shot(view, "suse_14_physics_plucked_string");
            load(18);              VT::suPage(*old, 5);                           shot(view, "suse_15_filters");
            load(10);              VT::suPage(*old, 6);   VT::suEnv(*old, 0);     shot(view, "suse_16_envelopes");
            VT::suEnv(*old, 1);                                                   shot(view, "suse_17_envelopes_2");
            load(0);               VT::suEnv(*old, 0);                            shot(view, "suse_17b_envelope_start_sound");
            VT::suEnvAdvanced(*old, true);                                        shot(view, "suse_17c_envelope_five_points");
            VT::suEnvAdvanced(*old, false);
            load(22);              VT::suPage(*old, 7);   VT::suMod(*old, 0, 0);  shot(view, "suse_18_mod_lfo");
            VT::suMod(*old, 1, 0);                                                shot(view, "suse_19_mod_steps");
            VT::suMod(*old, 2, 0);                                                shot(view, "suse_20_mod_matrix");
            load(6);               VT::suPage(*old, 8);                           shot(view, "suse_21_legato");
            load(26);              VT::suPage(*old, 9);                           shot(view, "suse_22_tuning_rast");
            {   // a MIDI route: CC 74 -> the cutoff of filter A
                CHECK(controller.setUpperEngineParam(7, su::ctlId(0, su::CT_SRC) + 1, 75.0F));
                CHECK(controller.setUpperEngineParam(7, su::ctlId(0, su::CT_D1) + 1, static_cast<float>(su::kDestFilterBase)));
                CHECK(controller.setUpperEngineParam(7, su::ctlId(0, su::CT_A1) + 1, 0.8F));
                old->refreshAllForTests(); VT::engineTab(*old);
            }
            VT::suPage(*old, 10);  VT::suCtl(*old, 0);                            shot(view, "suse_23_midi");
            {   // SOUND LAB: two real patches, their real loudness
                std::vector<float> pa(static_cast<std::size_t>(su::kParamCount)), pb(static_cast<std::size_t>(su::kParamCount));
                su::factoryPreset(10, pa.data()); su::factoryPreset(17, pb.data());
                const float la = su::referenceLoudnessDb(pa.data()), lb = su::referenceLoudnessDb(pb.data());
                VT::suLab(*old, pa, la, pb, lb);
            }
            VT::suPage(*old, 11);  VT::suGroup(*old, 0, -1);                      shot(view, "suse_24_presets_basic");
            VT::suGroup(*old, 1, 2);                                              shot(view, "suse_25_presets_winds");
            // real taps: the page key ПРЕСЕТИ -> ОСЦИЛ., the key ОСЦИЛ. -> ПРЕСЕТИ, the first preset of the first group
            VT::suTap(*old, pageKeyX(0), 208.0F);
            CHECK(VT::suPageNow(*old) == 0);
            VT::suTap(*old, pageKeyX(11), 208.0F);
            CHECK(VT::suPageNow(*old) == 11);
            VT::suGroup(*old, 0, -1);
            old->refreshAllForTests();
            { Canvas redraw(1340, 800); old->draw(redraw); }
            VT::suTap(*old, 404.0F + 90.0F, 412.0F + 80.0F + 17.0F);               // the first key of the grid: НАЧАЛЕН ЗВУК
            {
                std::vector<float> want(static_cast<std::size_t>(su::kParamCount));
                su::factoryPreset(0, want.data());
                const auto got = controller.upperEngineParams(7);
                CHECK(got.size() == want.size() + 1U);
                int diff = 0;
                for (int i = 0; i < su::kParamCount; ++i) {
                    if (i == su::E_SOURCE_ID || i == su::E_BYPASS_ID || i == su::E_BEND_UP_ID || i == su::E_BEND_DOWN_ID) continue;
                    if (std::fabs(got[static_cast<std::size_t>(i) + 1U] - want[static_cast<std::size_t>(i)]) > 1.0e-6F) ++diff;
                }
                CHECK(diff == 0);   // a tap on a factory preset puts every number of it into the place
            }
            {   // the button НУЛИРАЙ ЗВУКА: a loud, changed sound (the FM bell) -> a question -> the starting sound
                load(11);
                std::vector<float> start(static_cast<std::size_t>(su::kParamCount));
                su::setDefaults(start.data());
                const auto countDiff = [&] {
                    const auto got = controller.upperEngineParams(7);
                    int diff = 0;
                    for (int i = 0; i < su::kParamCount; ++i) {
                        if (i == su::E_SOURCE_ID || i == su::E_BYPASS_ID || i == su::E_BEND_UP_ID || i == su::E_BEND_DOWN_ID) continue;
                        if (std::fabs(got[static_cast<std::size_t>(i) + 1U] - start[static_cast<std::size_t>(i)]) > 1.0e-6F) ++diff;
                    }
                    return diff;
                };
                CHECK(countDiff() > 0);
                VT::suPage(*old, 6);   VT::suEnv(*old, 0);
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 1326.0F - 116.0F, 172.0F);                          // НУЛИРАЙ ЗВУКА
                CHECK(VT::dialogOpen(*old));
                shot(view, "suse_26_reset_question");
                CHECK(countDiff() > 0);                                             // nothing is lost before the player says ДА
                CHECK(VT::pressDialogButton(*old, "НЕ"));
                CHECK(countDiff() > 0);
                { Canvas redraw(1340, 800); old->draw(redraw); }
                VT::suTap(*old, 1326.0F - 116.0F, 172.0F);
                CHECK(VT::dialogOpen(*old));
                CHECK(VT::pressDialogButton(*old, "ДА, НУЛИРАЙ"));
                CHECK(countDiff() == 0);                                            // every number is the starting one again
                shot(view, "suse_27_after_reset");
            }
            VT::engineSlot(*old, 5);                                              shot(view, "suse_28_empty_place");
            VT::engineSlot(*old, 0);
            CHECK(controller.setUpperEngineParam(7, 0, 0.0F)); old->refreshAllForTests();
            controller.suseSaveSession();   // no SILVETON SYNTH is left: the kept session is removed now, not 1.5 s later (a later bank load would bring it back)
        }
        old->setPage(Old::Page::LIST);       shot(view, "theme_old_list");
        old->setPage(Old::Page::EFFECTS);    shot(view, "theme_old_effects");
        old->setPage(Old::Page::SETTINGS);   shot(view, "theme_old_settings");
        classic::ViewTestAccess::settingsTab(*old, 3);   shot(view, "theme_old_settings_set");   // SILVETON_LOGIC_V1
        classic::ViewTestAccess::settingsTab(*old, 0);
        {   // SILVETON_BATCH_1101 (Цветомир, 01.11.2026): the five changes, with the same taps a finger makes
            using OT = classic::ViewTestAccess;
            const auto setLevel = [&controller](int upper, float db) {
                auto st = controller.upperState(upper);
                CHECK(st.has_value());
                SamplerAppController::UpperState n = *st;
                n.levelDb = db;
                CHECK(controller.updateUpperMain(upper, n));
            };
            old->setPage(Old::Page::LIST);
            old->refreshAllForTests();
            // --- 3. the question before another blend opens (ЗАПАЗИ ЛИ ПРОМЕНИТЕ?)
            CHECK(OT::tapListCell(*old, 0));                       // the scenes before this one changed the open blend: the question comes (НЕ ЗАПАЗВАЙ)
            if (OT::dialogOpen(*old)) { CHECK(OT::dialogTitleIs(*old, "ЗАПАЗИ ЛИ ПРОМЕНИТЕ?")); CHECK(OT::pressDialogButton(*old, "НЕ ЗАПАЗВАЙ")); }
            CHECK(!OT::dialogOpen(*old));                          // "Piano + Strings" is open, nothing is changed
            CHECK(OT::loadedFrom(*old) == 0);
            CHECK(!controller.blendEdited());
            {   // MUTE alone is played live, it is not a change
                auto st = controller.upperState(1);
                CHECK(st.has_value());
                SamplerAppController::UpperState n = *st;
                n.mute = true;
                CHECK(controller.updateUpperMain(1, n));
                CHECK(!controller.blendEdited());
                n.mute = false;
                CHECK(controller.updateUpperMain(1, n));
                CHECK(!controller.blendEdited());
            }
            setLevel(0, -7.0F);                                    // a real change
            CHECK(controller.blendEdited());
            CHECK(OT::tapListCell(*old, 1));                       // another blend: the question comes first
            CHECK(OT::dialogTitleIs(*old, "ЗАПАЗИ ЛИ ПРОМЕНИТЕ?"));
            CHECK(OT::loadedFrom(*old) == 0);                      // still the same blend behind the question
            shot(view, "q3_save_question");
            CHECK(OT::pressDialogButton(*old, "ОТКАЗ"));           // ОТКАЗ = stay, nothing lost
            CHECK(!OT::dialogOpen(*old));
            CHECK(OT::loadedFrom(*old) == 0 && controller.blendEdited());
            CHECK(OT::tapListCell(*old, 1));
            CHECK(OT::pressDialogButton(*old, "НЕ ЗАПАЗВАЙ"));     // the change is dropped, the other blend opens
            CHECK(OT::loadedFrom(*old) == 1 && !controller.blendEdited());
            CHECK(OT::tapListCell(*old, 0));                       // the first blend is as it was written: 0 dB
            CHECK(!OT::dialogOpen(*old));
            CHECK(std::fabs(controller.upperState(0)->levelDb) < 0.05F);
            setLevel(0, -7.0F);
            CHECK(OT::tapListCell(*old, 2));
            CHECK(OT::pressDialogButton(*old, "ЗАПИШИ"));          // ЗАПИШИ = into its own place, then the other blend opens
            CHECK(OT::loadedFrom(*old) == 2 && !controller.blendEdited());
            CHECK(OT::listNamed(*old, 0, "Piano + Strings"));
            CHECK(OT::tapListCell(*old, 0));
            CHECK(std::fabs(controller.upperState(0)->levelDb + 7.0F) < 0.05F);   // the saved blend has the change
            setLevel(0, 0.0F);                                     // put it back as it was
            CHECK(controller.writeCombiToList(0, "Piano + Strings") == 0);
            CHECK(!controller.blendEdited());
            old->refreshAllForTests();

            // --- 1. a blend with a sound that is no longer in the bank opens without it, and says which
            const std::string smallBank = dir + "/SILVETON_SMALL.sv";      // next to the bank, so the same BLENDS file belongs to both
            const std::string fullBank = dir + "/SILVETON_FULL.sv";
            writeBank(smallBank, std::vector<std::string>(names.begin(), names.begin() + 8), 4800);   // only places 1..8
            writeBank(fullBank, names, 4800);                                                          // the same 40 sounds again
            CHECK(controller.useBankFile(smallBank));
            old->refreshAllForTests();
            CHECK(controller.soundCatalog().size() == 8U);
            CHECK(!controller.blendEdited());
            CHECK(OT::tapListCell(*old, 3));                       // "Rhodes Night" needs places 1, 9, 11, 19, 23 (+ layers)
            CHECK(OT::loadedFrom(*old) == 3);                       // it opened (before this, it did not)
            CHECK(OT::dialogTitleIs(*old, "ЛИПСВАТ ЗВУЦИ"));
            CHECK(OT::dialogHas(*old, "Warm Pad"));
            CHECK(!controller.lastRecallMissing().empty());
            shot(view, "q1_missing_sounds");
            CHECK(OT::pressDialogButton(*old, "OK") || OT::dialogOpen(*old));
            OT::closeDialogs(*old);
            CHECK(controller.useBankFile(fullBank));               // the full bank back for the rest of the test
            old->refreshAllForTests();
            CHECK(controller.soundCatalog().size() == names.size());
            CHECK(OT::tapListCell(*old, 3));                       // all sounds are there: opens quietly
            CHECK(!OT::dialogOpen(*old));
            CHECK(controller.lastRecallMissing().empty());

            // --- 2. ЛИСТ ИЗТРИЙ = only the name goes, the place is free, the blend and the sounds stay
            old->setPage(Old::Page::LIST);
            old->refreshAllForTests();
            OT::addFavourite(*old, 45);
            const std::size_t blendsBefore = controller.combiCatalog().size();
            const std::size_t soundsBefore = controller.soundCatalog().size();
            OT::contextMenu(*old, 45);
            CHECK(OT::pickDialogItem(*old, 5));                    // ИЗТРИЙ in the menu
            CHECK(OT::dialogHas(*old, "мястото остава празно"));
            CHECK(OT::dialogHas(*old, "звуците не се трият"));
            shot(view, "q2_list_delete_one");
            CHECK(OT::pressDialogButton(*old, "ИЗТРИЙ"));
            CHECK(!OT::listNamed(*old, 45, "Page 2 pad"));         // the place is free
            CHECK(OT::listNamed(*old, 30, "First of page 2"));     // the others did not move
            CHECK(!OT::isFavourite(*old, 45));                     // its star went with the name
            CHECK(controller.combiCatalog().size() == blendsBefore);   // the blend is still in the 500 places
            CHECK(controller.soundCatalog().size() == soundsBefore);   // and the sounds are still there
            CHECK(controller.writeCombiToList(45, "Page 2 pad") == 45);   // the free place can be written again at once
            old->refreshAllForTests();
            OT::markForDelete(*old, {30, 45});
            OT::deleteMarked(*old);
            CHECK(OT::dialogHas(*old, "Самите бленди и звуците не се трият"));
            shot(view, "q2_list_delete_many");
            CHECK(OT::pressDialogButton(*old, "ОТКАЗ"));
            CHECK(OT::listNamed(*old, 30, "First of page 2") && OT::listNamed(*old, 45, "Page 2 pad"));
            OT::markOff(*old);
            old->refreshAllForTests();

            // --- 5. a write that fails says why in plain words
            OT::copyFailing(*old, 100, 101);                       // position 101 has no blend: nothing to copy
            CHECK(OT::dialogTitleIs(*old, "КОПИРАНЕТО НЕ УСПЯ"));
            CHECK(OT::dialogHas(*old, "няма бленда"));
            shot(view, "q5_copy_failed");
            OT::closeDialogs(*old);

            // --- 4. the pedal: calibration page
            old->setPage(Old::Page::SETTINGS);
            OT::settingsTab(*old, 1);
            shot(view, "q4_midi_page");                            // the new key КАЛИБРАЦИЯ ПЕДАЛ
            OT::openPedalCal(*old);
            CHECK(controller.midiCcValue(11) < 0);                 // nothing from the pedal yet
            shot(view, "q4_pedal_waiting");
            CHECK(controller.engine.nativeMidi(0xB0, 11, 9));      // the pedal all the way DOWN reaches only 9 (that is why the sound never went to zero)
            CHECK(controller.midiCcValue(11) == 9);
            shot(view, "q4_pedal_low");
            CHECK(OT::tapPedalKey(*old, 0));                       // ЗАПОМНИ МИН
            {
                const auto g = controller.globalAdvanced();
                CHECK(g.has_value() && std::fabs(g->expressionMin - 9.0F / 127.0F) < 0.001F);
            }
            CHECK(controller.engine.nativeMidi(0xB0, 11, 120));    // all the way UP reaches only 120
            CHECK(OT::tapPedalKey(*old, 1));                       // ЗАПОМНИ МАКС
            {
                const auto g = controller.globalAdvanced();
                CHECK(g.has_value() && std::fabs(g->expressionMax - 120.0F / 127.0F) < 0.001F);
            }
            CHECK(controller.engine.nativeMidi(0xB0, 11, 64));
            shot(view, "q4_pedal_done");
            CHECK(OT::tapPedalKey(*old, 2));                       // ВРЪЩАНЕ НА 0 – 127
            {
                const auto g = controller.globalAdvanced();
                CHECK(g.has_value() && g->expressionMin == 0.0F && g->expressionMax == 1.0F);
            }
            CHECK(OT::pedalCalOpen(*old));
            CHECK(OT::tapPedalKey(*old, 3));                       // ГОТОВО
            CHECK(!OT::pedalCalOpen(*old));
            OT::settingsTab(*old, 0);
        }
        {   // SILVETON_USER_WAVES_V1: a wave of the OSCILLATOR LAB in SILVETON_OSC next to the bank = USER 1 of the oscillators, listed on INFO
            const std::string osc = dir + "/SILVETON_OSC";
            ::mkdir(osc.c_str(), 0755);
            ::mkdir((osc + "/MOJA STRUNA").c_str(), 0755);
            {
                std::ofstream f(osc + "/MOJA STRUNA/single_cycle.wav", std::ios::binary);
                const auto le = [&f](unsigned v, int n) { for (int i = 0; i < n; ++i) f.put(static_cast<char>((v >> (8 * i)) & 0xFFU)); };
                f.write("RIFF", 4); le(36U + 4096U, 4); f.write("WAVEfmt ", 8); le(16U, 4); le(1U, 2); le(1U, 2); le(48000U, 4); le(96000U, 4); le(2U, 2); le(16U, 2);
                f.write("data", 4); le(4096U, 4);
                for (int i = 0; i < 2048; ++i) {
                    const double th = 6.283185307179586 * i / 2048.0;
                    le(static_cast<unsigned>(static_cast<std::uint16_t>(static_cast<std::int16_t>(std::lround(12000.0 * (std::sin(th) + 0.4 * std::sin(2.0 * th) + 0.2 * std::sin(5.0 * th)))))), 2);
                }
            }
            const auto rep = controller.reloadUserWaves();
            CHECK(rep.folderFound && rep.names.size() == 1U && rep.names[0] == "MOJA STRUNA");
            classic::ViewTestAccess::settingsTab(*old, 2);   shot(view, "theme_old_info_waves");
            classic::ViewTestAccess::settingsTab(*old, 0);
            old->setPage(Old::Page::COMBI);
            CHECK(controller.setUpperEngineParam(7, 0, 2.0F));                                   // POLYSIX
            CHECK(controller.setUpperEngineParam(7, sv::P6_OSC + 1, 0.0F));
            old->refreshAllForTests();
            classic::ViewTestAccess::engineTab(*old);   shot(view, "osc_1_engine_before");
            CHECK(controller.setUpperEngineParam(7, sv::P6_OSC + 1, static_cast<float>(sv::kOscOwnWaves + sv::kTableWaveCount)));   // what a pick does
            CHECK(controller.setUpperEngineParam(7, sv::P6_OSC_LEVEL + 1, 0.7F));
            old->refreshAllForTests();
            classic::ViewTestAccess::engineTab(*old);   shot(view, "osc_3_engine_after");
            for (int t = 1; t <= 9; ++t) {   // every engine as the tablet draws it
                CHECK(controller.setUpperEngineParam(7, 0, static_cast<float>(t))); old->refreshAllForTests();
                classic::ViewTestAccess::engineTab(*old);   classic::ViewTestAccess::enginePage(*old, sv::engineOscPage(static_cast<sv::EngineType>(t)));   shot(view, "eng_" + std::to_string(t));
            }
            {   // SILVETON_ENGINE_SLOTS_V1: the engines on their own - two AL-1 and an EP side by side, each with its own ВКЛ / СИЛА
                CHECK(controller.setUpperEngineParam(7, 0, 4.0F));   // slot 1: AL-1
                CHECK(controller.setUpperEngineParam(8, 0, 4.0F));   // slot 2: AL-1 again
                CHECK(controller.setUpperEngineParam(9, 0, 9.0F));   // slot 3: EP
                old->refreshAllForTests();
                classic::ViewTestAccess::engineTab(*old);   classic::ViewTestAccess::engineSlot(*old, 0);   classic::ViewTestAccess::enginePage(*old, sv::engineOscPage(sv::EngineType::AL1));   shot(view, "slots_1");
                classic::ViewTestAccess::engineSlot(*old, 1);   shot(view, "slots_2");
                classic::ViewTestAccess::engineSlot(*old, 2);   classic::ViewTestAccess::enginePage(*old, sv::engineOscPage(sv::EngineType::EP));   shot(view, "slots_3");
                classic::ViewTestAccess::engineSlot(*old, 5);   shot(view, "slots_empty");
                classic::ViewTestAccess::engineSlot(*old, 0);
                classic::ViewTestAccess::openStore(*old);   shot(view, "slots_store");   // ЗАПИШИ from the ДВИГАТЕЛИ page: choose the place in the ЛИСТ
                classic::ViewTestAccess::storeAt(*old, 100, "Двигатели тест");   // the same as pressing ЗАПИШИ on a free place
                CHECK(classic::ViewTestAccess::onEngines(*old));                   // you stay on the page
                CHECK(classic::ViewTestAccess::listNamed(*old, 100, "Двигатели тест"));
                classic::ViewTestAccess::unstore(*old, 100);
                classic::ViewTestAccess::closeWrite(*old);
                for (int sl = 0; sl < 3; ++sl) CHECK(controller.setUpperEngineParam(7 + sl, 0, 0.0F));
                old->refreshAllForTests();
            }
            CHECK(controller.setUpperEngineParam(7, 0, 2.0F)); old->refreshAllForTests();
            CHECK(controller.setUpperEngineParam(7, sv::P6_OSC + 1, static_cast<float>(sv::kOscOwnWaves + sv::kTableWaveCount)));   // OSC = USER 1
            old->refreshAllForTests();
            classic::ViewTestAccess::engineTab(*old);   shot(view, "theme_old_user_wave");
            CHECK(controller.setUpperEngineParam(7, 0, 0.0F)); old->refreshAllForTests();
            std::remove((osc + "/MOJA STRUNA/single_cycle.wav").c_str());
            ::rmdir((osc + "/MOJA STRUNA").c_str());
            ::rmdir(osc.c_str());
            CHECK(controller.reloadUserWaves().names.empty());
            old->setPage(Old::Page::SETTINGS);
        }
        {   // SILVETON_USER_WAVES_V1: SILVETON_OSC.sv is found also when the bank is not (a tablet with no SILVETON_BANK.sv found)
            const std::string nb = dir + "/NO_BANK";
            ::mkdir(nb.c_str(), 0755);
            ::mkdir((nb + "/data").c_str(), 0755);
            {
                std::ofstream f(nb + "/SILVETON_OSC.sv", std::ios::binary);
                const auto le = [&f](unsigned v, int n) { for (int i = 0; i < n; ++i) f.put(static_cast<char>((v >> (8 * i)) & 0xFFU)); };
                f.write("SVOSC001", 8); le(1U, 4);
                const std::string name = "Моят Орган";
                le(static_cast<unsigned>(name.size()), 2); f.write(name.data(), static_cast<std::streamsize>(name.size()));
                le(1U, 2); f.put(0); f.put(127); f.put(60); f.put(0); le(2048U, 4);
                for (int i = 0; i < 2048; ++i) {
                    const float v = static_cast<float>(0.5 * std::sin(6.283185307179586 * i / 2048.0) + 0.3 * std::sin(3.0 * 6.283185307179586 * i / 2048.0));
                    std::uint32_t u = 0U; std::memcpy(&u, &v, 4U); le(u, 4);
                }
                f.write("SVOSCEND", 8);
            }
            ControllerEnv env2;
            env2.dataDir = nb + "/data";
            env2.bankCandidates = {nb + "/SILVETON_BANK.sv"};   // there is no bank there
            SamplerAppController noBank(env2);
            const auto rep = noBank.reloadUserWaves();
            CHECK(rep.folderFound && rep.names.size() == 1U && rep.names[0] == "Моят Орган" && rep.folder == nb + "/SILVETON_OSC.sv");
            CHECK(!noBank.bankInfo());
            std::remove((nb + "/SILVETON_OSC.sv").c_str());
            CHECK(noBank.reloadUserWaves().names.empty());
            CHECK(controller.reloadUserWaves().names.empty());   // back to the bank's place (nothing there)
        }
        {   // SILVETON_FULL_KEYBOARD_V1: typing a value by hand in the old look shows the whole keyboard (digits, all letters, minus, point, delete, clear)
            using OT = classic::ViewTestAccess;
            old->setSoftKeyboard(true);
            OT::numberDialog(*old);                shot(view, "theme_old_number_kb");
            CHECK(OT::keyCount(*old) >= 40U);
            CHECK(OT::pressKey(*old, "ИЗЧИСТИ"));
            CHECK(OT::pressKey(*old, "1"));        CHECK(OT::pressKey(*old, "2"));  CHECK(OT::pressKey(*old, "."));
            CHECK(OT::pressKey(*old, "5"));        CHECK(OT::pressKey(*old, "±"));
            CHECK(OT::dialogValue(*old) == "-12.5");
            CHECK(OT::pressKey(*old, "Q"));        CHECK(OT::dialogValue(*old) == "-12.5");   // a letter types nothing into a number
            CHECK(OT::pressKey(*old, "DELETE"));   CHECK(OT::dialogValue(*old) == "-12.");
            OT::closeDialogs(*old);
            old->setSoftKeyboard(false);
        }
    }
    {   // SILVETON_ONLY_OLD_V1: the old SETTINGS page has no way back to the new screens (where НОВИ ТЕМИ was, a touch does nothing);
        // the new screens (switched off in the program) still answer СТАРА on their SETTINGS page
        using PA = SilvetonSamplerView::PointerAction;
        view.pointer(PA::Down, 1060.0F, 651.0F);
        view.pointer(PA::Up, 1060.0F, 651.0F);
        CHECK(controller.uiTheme() == 4);
        CHECK(TA::classicView(view) != nullptr);
        TA::uiTheme(view, 1);
        CHECK(TA::classicView(view) == nullptr);
        view.setPage(SilvetonSamplerView::Page::SETTINGS);
        TA::settingsTab(view, 0);
        shot(view, "theme_back_light_settings");
        view.pointer(PA::Down, 1087.0F, 709.0F);
        view.pointer(PA::Up, 1087.0F, 709.0F);
        CHECK(controller.uiTheme() == 4);
        CHECK(TA::classicView(view) != nullptr);
        Canvas again(1340, 800);
        view.draw(again);                                   // the old look draws and answers
        view.setWarning("TEST");                            // a warning of the shell reaches the old look on the drawing thread
        CHECK(view.redrawDue(0));
        view.draw(again);
        view.setWarning("");
    }
    TA::uiTheme(view, 0);
    CHECK(controller.uiTheme() == 0);
    CHECK(TA::classicView(view) == nullptr);
    TA::common(view, 0, Tab::MIXER);

    // a click on a control: PAN of Upper 1 double-click = reset; the level key of Upper 1
    view.pointer(SilvetonSamplerView::PointerAction::Down, 140.0F, 200.0F);
    view.pointer(SilvetonSamplerView::PointerAction::Up, 140.0F, 200.0F);
    // a finger dragging over the screen: only the parts under it should be drawn again
    {
        long long dragPictures = 0, dragRepainted = 0;
        double dragMs = 0.0;
        view.pointer(SilvetonSamplerView::PointerAction::Down, 140.0F, 300.0F);
        for (int i = 0; i < 20; ++i) {
            view.pointer(SilvetonSamplerView::PointerAction::Move, 140.0F + 3.0F * static_cast<float>(i), 300.0F + 2.0F * static_cast<float>(i));
            const auto t0 = std::chrono::steady_clock::now();
            g_light.update([&](Canvas& c) { view.draw(c); });
            dragMs += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
            ++dragPictures;
            dragRepainted += g_light.lastRepaintedPixels();
            Canvas full(1340, 800);
            full.replay(g_light.lastList(), IRect(0, 0, 1340, 800));
            long long different = 0;
            for (std::size_t k = 0U; k < full.buffer().size(); ++k) if (full.buffer()[k] != g_light.picture().buffer()[k]) ++different;
            CHECK(different == 0);
        }
        view.pointer(SilvetonSamplerView::PointerAction::Up, 200.0F, 340.0F);
        std::printf("light drawing, finger dragging: %.1f %% of the picture drawn again per picture, %.2f ms per picture\n",
                    100.0 * static_cast<double>(dragRepainted) / (static_cast<double>(dragPictures) * 1340.0 * 800.0), dragMs / static_cast<double>(dragPictures));
    }
    std::printf("light drawing, all %lld pictures exact. While nothing is touched: %.2f %% of the picture drawn again, %.2f ms per picture (all pictures: %.2f %%)\n",
                g_lightPictures, 100.0 * static_cast<double>(g_lightIdleRepainted) / (static_cast<double>(std::max<long long>(1, g_lightIdlePictures)) * 1340.0 * 800.0),
                g_lightIdleMs / static_cast<double>(std::max<long long>(1, g_lightIdlePictures)),
                100.0 * static_cast<double>(g_lightRepainted) / (static_cast<double>(std::max<long long>(1, g_lightPictures)) * 1340.0 * 800.0));
    controller.close();
    // SILVETON_GFX_SAFE_POLY_V1: no screen of the test may hand the rasterizer a coordinate that is not a number
    std::printf("polygons with a coordinate that is not a number: %lu\n", silveton::ui::badPolygonCount());
    CHECK(silveton::ui::badPolygonCount() == 0UL);
    std::printf("view render test OK\n");
    return 0;
}
