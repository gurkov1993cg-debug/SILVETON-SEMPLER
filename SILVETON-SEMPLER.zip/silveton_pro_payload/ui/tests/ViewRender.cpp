// Draws the screens of the sampler with demo sounds into PNG pictures (and checks that nothing crashes).
// Usage: imak_ui_render <fonts dir> <output dir>
#include "silveton/host/HostIo.h"
#include "silveton/sampler/SvBankFormat.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/classic/SilvetonSamplerView.h"   // SILVETON_OLD_THEME_V1
#ifdef IMAK_GL_COMPARE
#include "GlRenderer.h"
#endif

#include <cmath>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <set>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::ui;
namespace sv = silveton::sampler;

namespace silveton::ui::classic {
// SILVETON_OLD_THEME_V1: the same for the old look
struct ViewTestAccess {
    using V = SilvetonSamplerView;
    static void engineTab(V& v) { v.selectedUpper_ = 0; v.tab = V::UpperTab::ENGINE; v.invalidate(); }
    static void settingsTab(V& v, int t) { v.settingsTab = t; v.invalidate(); }
};
}

namespace silveton::ui {
// Friend of the view: lets the tests open pages and dialogs without a mouse.
struct ViewTestAccess {
    using V = SilvetonSamplerView;
    using Tab = V::UpperTab;
    static void edit(V& v, int upper, int sound, V::UpperTab tab) { v.selectedUpper_ = upper; v.stripSound[static_cast<std::size_t>(upper)] = sound; v.editSound = sound; v.tab = tab; v.invalidate(); }
    static void common(V& v, int upper, V::UpperTab tab) { v.selectedUpper_ = upper; v.tab = tab; v.invalidate(); }
    static void picker(V& v, int upper, int layer) { v.openPicker(upper, layer); }
    static void closePicker(V& v) { v.picker.reset(); }
    static void pickerAssignItem(V& v, const SilvetonSamplerView::SoundItem& item) { v.pickerAssign(*v.picker, item); }
    static void numberDialog(V& v) { v.showNumber("UPPER 1 LEVEL dB", -3.5F, -60.0F, 12.0F, 1, [](float) {}); }
    static void textDialog(V& v) { v.showTextPage("ИМЕ НА БЛЕНДА", "Piano + Strings", [](const std::string&) {}); }
    static void soundGrid(V& v) { v.showSoundPicker(0); }
    static void blendGrid(V& v) { v.showBlendPicker(); }
    static void confirm(V& v) { v.showConfirm("DELETE  ЛИСТ 007", "„Warm Pad“ излиза от ЛИСТА и мястото остава празно. Другите позиции не мърдат, самата бленда не се трие.", "DELETE", [] {}, "CANCEL"); }
    static void items(V& v) { v.showItems("007   Warm Pad", {"RENAME", "COPY TO…", "MOVE TO…", "EDIT", "DELETE"}, [](int) {}); }
    static void closeDialogs(V& v) { v.dialogStack.clear(); }
    static void listMenu(V& v, int index) { const auto it = v.realListItem(index); if (it) v.showListContextMenu(index, *it); }
    static void listFav(V& v, int index) { v.listFavs.insert(index); }
    static void listSelect(V& v, int index) { v.listSelected = index; }
    static void listMark(V& v, bool on, std::set<int> marked) { v.listMarkMode_ = on; v.listMarked_ = std::move(marked); v.invalidate(); }   // SILVETON_MULTI_DELETE_V1
    static void pickerPage(V& v, int page) { if (v.picker) v.picker->page = page; v.invalidate(); }
    static void pickerMark(V& v, bool on, std::set<int> marked) { if (v.picker) { v.picker->markMode = on; v.picker->marked = std::move(marked); } v.invalidate(); }
    static void openCopy(V& v, int source) { v.openPositionPicker(V::WriteMode::COPY, source); }
    static void openWriteScreen(V& v, bool blend) { v.openWrite(blend ? V::WriteTarget::BLEND : V::WriteTarget::LIST, false); }
    static void closeWrite(V& v) { v.writeOpen = false; }
    static void storeDialog(V& v) { v.storeToList(); }
    static void fx(V& v, int unit, int type) { v.fxUnitFocus = unit; v.setFxP(unit, 0, static_cast<float>(type)); v.invalidate(); }
    static void focus(V& v, int unit) { v.fxUnitFocus = unit; v.invalidate(); }
    static void settingsTab(V& v, int t) { v.settingsTab = t; v.bankInfoCache = v.sampler.bankInfo(); v.invalidate(); }
    static void deleteSounds(V& v) { if (v.bankInfoCache) v.showDeleteSounds(*v.bankInfoCache); }
    static void search(V& v, const std::string& q) { v.listSearch = q; }
    static void favOnly(V& v, bool on) { v.listFavOnly = on; }
    static void dropdown(V& v, int upper) { v.dropUpper = upper; v.invalidate(); }
    static int editSoundOf(V& v) { return v.editSound; }
    static void theme(V& v, bool) { V::applyTheme(true); v.invalidate(); }   // SILVETON_PRO_UI_V1: one (dark) look
    // SILVETON_PRO_UI_V1: the older pages of an Upper are shown inside the new frame - their own units -> the picture
    static float ex(float x) { return V::fitXf(RectF(112.0F, 514.0F, 1326.0F, 786.0F), RectF(10.0F, 444.0F, 1330.0F, 736.0F)).dx(x); }
    static float ey(float y) { return V::fitXf(RectF(112.0F, 514.0F, 1326.0F, 786.0F), RectF(10.0F, 444.0F, 1330.0F, 736.0F)).dy(y); }
    static void language(V& v, int lang) { v.setLanguage(lang); }
    static void uiTheme(V& v, int t) { v.setTheme(t); }   // SILVETON_THEMES_V1
    static classic::SilvetonSamplerView* classicView(V& v) { return v.classic_.get(); }   // SILVETON_OLD_THEME_V1
    static void enginePage(V& v, int page) { v.enginePage_ = page; v.invalidate(); }   // SILVETON_ENGINES_V1
    // on-screen keyboard / toast / second finger (the tablet)
    static void softKeyboard(V& v, bool on) { v.setSoftKeyboard(on); }
    static std::string dialogValue(V& v) { return v.dialogStack.empty() ? std::string("<none>") : v.dialogStack.back()->value; }
    static bool pressKey(V& v, const std::string& label, int occurrence = 0) {
        Canvas c(1340, 800);
        v.draw(c);
        if (v.dialogStack.empty()) return false;
        int seen = 0;
        for (const auto& k : v.dialogStack.back()->kbKeys) {
            if (k.label != label) continue;
            if (seen++ != occurrence) continue;
            v.pointer(V::PointerAction::Down, k.rect.centerX(), k.rect.centerY());
            v.pointer(V::PointerAction::Up, k.rect.centerX(), k.rect.centerY());
            return true;
        }
        return false;
    }
    static std::size_t keyCount(V& v) { return v.dialogStack.empty() ? 0U : v.dialogStack.back()->kbKeys.size(); }
    static bool pairCheck(V& v, SamplerAppController& ctl) {
        v.setPage(V::Page::LIST);
        Canvas c(1340, 800);
        v.draw(c);
        if (v.pairHits.empty()) return false;
        const auto pair = v.pairHits.front();
        ctl.stepGlobalTranspose(3);
        v.refreshAllForTests();
        v.draw(c);
        const float ax = pair.xf.dx(pair.a.centerX()), ay = pair.xf.dy(pair.a.centerY());   // the page's own units -> the picture
        v.pointer(V::PointerAction::Down, ax, ay);
        v.secondPointerDown(pair.xf.dx(pair.b.centerX()), pair.xf.dy(pair.b.centerY()));
        const bool consumed = v.pairConsumed;
        v.pointer(V::PointerAction::Up, ax, ay);
        v.setPage(V::Page::COMBI);
        const auto g = ctl.globalUiState();
        return consumed && g && g->transpose == 0 && !v.pairConsumed;
    }
    static void mark(V& v, bool markMode, int a, int b) { v.markMode = markMode; v.marked[static_cast<std::size_t>(a)] = true; v.marked[static_cast<std::size_t>(b)] = true; v.linkOn = true; }
};
} // namespace silveton::ui

namespace {
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

void writeBank(const std::string& path, const std::vector<std::string>& names) {
    std::vector<std::uint8_t> strings{0U};
    auto addString = [&](const std::string& text) -> std::uint32_t {
        const auto offset = static_cast<std::uint32_t>(strings.size());
        strings.insert(strings.end(), text.begin(), text.end());
        strings.push_back(0U);
        return offset;
    };
    const auto bankName = addString("DEMO BANK");
    const auto sampleName = addString("DEMO SAMPLE");
    const auto sampleIdentity = addString("sample://demo");
    const auto msName = addString("DEMO MULTI");
    const auto msIdentity = addString("multi://demo");
    std::vector<std::uint8_t> sounds, layers, multis, samples, zones, audio;
    for (std::size_t i = 0U; i < names.size(); ++i) {
        sv::SvSoundRecord sound{};
        sound.nameOffset = addString(names[i]);
        sound.firstLayer = static_cast<std::uint32_t>(i);
        sound.layerCount = 1U;
        sound.soundSlotId = static_cast<std::uint32_t>(i + 1U);
        sv::appendSoundRecord(sounds, sound);
        sv::SvSoundLayerRecord layer{};
        layer.multisampleId = 4000001U; layer.enabled = 1U; layer.keyLow = 0U; layer.keyHigh = 127U; layer.velocityLow = 1U; layer.velocityHigh = 127U;
        sv::appendSoundLayerRecord(layers, layer);
    }
    sv::SvMultisampleRecord ms{};
    ms.multisampleId = 4000001U; ms.nameOffset = msName; ms.sourceIdentityOffset = msIdentity; ms.firstZone = 0U; ms.zoneCount = 1U;
    sv::appendMultisampleRecord(multis, ms);
    sv::SvSampleRecord sample{};
    sample.sampleId = 3000001U; sample.nameOffset = sampleName; sample.sourceIdentityOffset = sampleIdentity; sample.sampleRate = 48000U; sample.channels = 1U;
    sample.encoding = 1U; sample.bitsPerSample = 16U; sample.rootKey = 60U; sample.totalFrames = 8U; sample.audioOffset = 0U; sample.audioSize = 16U;
    sv::appendSampleRecord(samples, sample);
    sv::SvZoneRecord zone{};
    zone.sampleId = 3000001U; zone.keyLow = 0U; zone.keyHigh = 127U; zone.velocityLow = 1U; zone.velocityHigh = 127U; zone.rootKey = 60U;
    sv::appendZoneRecord(zones, zone);
    const std::int16_t pcm[8] = {0, 8192, -8192, 16384, -16384, 32767, -32768, 4096};
    for (const std::int16_t v : pcm) {
        const auto u = static_cast<std::uint16_t>(v);
        audio.push_back(static_cast<std::uint8_t>(u & 0xFFU));
        audio.push_back(static_cast<std::uint8_t>((u >> 8U) & 0xFFU));
    }
    sv::SvBankHeader header{};
    header.bankNameOffset = bankName;
    header.soundCount = static_cast<std::uint32_t>(names.size());
    header.soundLayerCount = static_cast<std::uint32_t>(names.size());
    header.multisampleCount = 1U; header.sampleCount = 1U; header.zoneCount = 1U;
    std::vector<std::uint8_t> file(sv::kSvBankHeaderSize, 0U);
    auto appendSec = [&](sv::SvSection section, const std::vector<std::uint8_t>& data) {
        auto& d = header.sections[static_cast<std::size_t>(section)];
        d.offset = static_cast<std::uint64_t>(file.size());
        d.size = static_cast<std::uint64_t>(data.size());
        file.insert(file.end(), data.begin(), data.end());
    };
    appendSec(sv::SvSection::Sounds, sounds); appendSec(sv::SvSection::SoundLayers, layers); appendSec(sv::SvSection::Multisamples, multis);
    appendSec(sv::SvSection::Samples, samples); appendSec(sv::SvSection::Zones, zones); appendSec(sv::SvSection::Strings, strings); appendSec(sv::SvSection::Audio, audio);
    header.fileSize = static_cast<std::uint64_t>(file.size());
    header.payloadSha256 = sv::sha256(file.data() + sv::kSvBankHeaderSize, file.size() - sv::kSvBankHeaderSize);
    const auto serialized = sv::serializeHeader(header);
    std::copy(serialized.begin(), serialized.end(), file.begin());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(file.data()), static_cast<std::streamsize>(file.size()));
}

std::string g_out;
bool g_fast = false;   // profiling: one picture per screen

// "Light drawing" on the real screens: the picture kept by the FrameRenderer (only the changed parts drawn again) must be
// exactly the picture that drawing the recorded operations completely gives.
FrameRenderer g_light(1340, 800);
long long g_lightPictures = 0, g_lightRepainted = 0, g_lightIdlePictures = 0, g_lightIdleRepainted = 0;
double g_lightIdleMs = 0.0;
void checkLight(SilvetonSamplerView& view, const std::string& name) {
    for (int i = 0; i < 4; ++i) {   // the first picture after a change of screen, then the ones that follow while nothing is touched
        const auto t0 = std::chrono::steady_clock::now();
        g_light.update([&](Canvas& c) { view.draw(c); });
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        Canvas full(1340, 800);
        full.replay(g_light.lastList(), IRect(0, 0, 1340, 800));
        long long different = 0;
        for (std::size_t k = 0U; k < full.buffer().size(); ++k) if (full.buffer()[k] != g_light.picture().buffer()[k]) ++different;
        if (different != 0) std::fprintf(stderr, "light drawing: %s picture %d: %lld pixels differ\n", name.c_str(), i, different);
        CHECK(different == 0);
        ++g_lightPictures;
        g_lightRepainted += g_light.lastRepaintedPixels();
        if (i > 0) { ++g_lightIdlePictures; g_lightIdleRepainted += g_light.lastRepaintedPixels(); g_lightIdleMs += ms; }
    }
}


#ifdef IMAK_GL_COMPARE
// SILVETON_GPU_DRAW_V1: the picture the video card draws from the recorded list must be the picture the software renderer draws
// from the same list (to within a rounding step). Needs EGL / OpenGL ES 3 at run time (Mesa's surfaceless platform on Linux).
std::unique_ptr<silveton::gl::GlRenderer> g_glRenderer;
FrameRenderer g_glRecorder(1340, 800);
void checkVideoCard(SilvetonSamplerView& view, const std::string& name) {
    if (!g_glRenderer) {
        silveton::gl::GlRenderer::Options options;
        options.surfaceless = true;
        options.width = 1340;
        options.height = 800;
        std::string error;
        g_glRenderer = silveton::gl::GlRenderer::create(options, error);
        if (!g_glRenderer) { std::fprintf(stderr, "video card drawing: %s\n", error.c_str()); std::exit(3); }
        std::printf("video card: %s\n", g_glRenderer->info().c_str());
    }
    g_glRecorder.record([&](Canvas& c) { view.draw(c); });
    for (int pass = 0; pass < 2; ++pass) {   // the second time everything comes from the caches
        if (!g_glRenderer->render(g_glRecorder.lastList(), false)) { std::fprintf(stderr, "video card drawing %s: %s\n", name.c_str(), g_glRenderer->lastError().c_str()); std::exit(3); }
        std::vector<std::uint32_t> got;
        CHECK(g_glRenderer->readPixels(got));
        Canvas expected(1340, 800);
        expected.replay(g_glRecorder.lastList(), IRect(0, 0, 1340, 800));
        long long over = 0;
        int worst = 0;
        for (std::size_t k = 0U; k < got.size(); ++k) {
            int d = 0;
            for (unsigned shift = 0U; shift <= 24U; shift += 8U) d = std::max(d, std::abs(static_cast<int>((got[k] >> shift) & 255U) - static_cast<int>((expected.buffer()[k] >> shift) & 255U)));
            worst = std::max(worst, d);
            if (d > 8) ++over;
        }
        if (over != 0 || worst > 16) std::fprintf(stderr, "video card drawing: %s (pass %d): %lld pixels differ by more than 8, worst %d\n", name.c_str(), pass, over, worst);
        CHECK(over == 0 && worst <= 16);
    }
}
#endif

void shot(SilvetonSamplerView& view, const std::string& name) {
    Canvas canvas(1340, 800);
    for (int i = 0; i < (g_fast ? 1 : 3); ++i) view.draw(canvas);   // a few frames: caches fill, telemetry arrives
    const auto t0 = std::chrono::steady_clock::now();
    const int timed = g_fast ? 1 : 5;
    for (int i = 0; i < timed; ++i) view.draw(canvas);
    const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / timed;
    CHECK(writePng(g_out + "/" + name + ".png", canvas));
    std::printf("wrote %s.png  (%.1f ms per picture)\n", name.c_str(), ms);
    checkLight(view, name);
#ifdef IMAK_GL_COMPARE
    checkVideoCard(view, name);
#endif
}
} // namespace

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: %s <fonts dir> <output dir>\n", argv[0]); return 2; }
    setFontDirectory(argv[1]);
    CHECK(fontsReady());
    g_out = argv[2];
    g_fast = argc > 3;
    char tmpl[] = "/tmp/imak-ui-render-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string dir = tmpl;
    const std::vector<std::string> names = {
        "Grand Piano", "Bright Piano", "Electric Piano", "Rhodes Tine", "Wurlitzer", "Clavinet", "Church Organ", "Rock Organ", "Warm Pad", "Soft Strings",
        "String Ensemble", "Brass Section", "Trumpet", "Alto Sax", "Flute", "Oboe", "Nylon Guitar", "Steel Guitar", "Fretless Bass", "Slap Bass",
        "Choir Aahs", "Vocal Ooh", "Marimba", "Vibraphone", "Harp", "Music Box", "Bell Tree", "Synth Lead", "Analog Bass", "Sweep Pad",
        "Kronos Piano Concert", "Sine Wave", "Saw Wave", "Square Wave", "Noise Wash", "Dulcimer", "Accordion", "Harmonica", "Banjo", "Sitar"};
    const std::string bank = dir + "/SILVETON_BANK.sv";
    writeBank(bank, names);

    ControllerEnv env;
    env.dataDir = dir + "/data";
    env.bankCandidates = {bank};
    SamplerAppController controller(env);
    controller.engine.setBackends(std::make_unique<silveton::host::OfflineAudioOutput>(96000.0, 96U), std::make_unique<silveton::host::ManualMidiInput>());
    CHECK(controller.start());
    for (int i = 0; i < 100 && controller.soundCatalog().empty(); ++i) usleep(50000);
    const auto catalog = controller.soundCatalog();
    CHECK(catalog.size() == names.size());

    // an interesting COMBI: five Uppers with sounds
    const int pick[5] = {0, 8, 10, 18, 22};
    for (int u = 0; u < 5; ++u) {
        CHECK(controller.assignUpperSound(u, catalog[static_cast<std::size_t>(pick[u])]));
        auto s = controller.upperState(u);
        CHECK(s.has_value());
        SamplerAppController::UpperState n = *s;
        n.enabled = true;
        n.levelDb = u == 0 ? 0.0F : -2.0F * static_cast<float>(u);
        n.pan = u == 0 ? 0.0F : (u % 2 == 0 ? 0.35F : -0.35F);
        if (u == 3) { n.keyLow = 36; n.keyHigh = 59; }
        if (u == 1) { n.keyLow = 60; n.keyHigh = 127; }
        controller.updateUpperMain(u, n);
    }
    controller.setLayerSound(0, 0, catalog[10].slot);
    controller.setLayerSound(0, 1, catalog[9].slot);

    // some BLENDS in the LIST
    const int listPos[] = {0, 1, 2, 3, 6, 7, 12, 29, 30, 45};
    const char* listNames[] = {"Piano + Strings", "Warm Layers", "Concert Grand", "Rhodes Night", "Church Pad", "Brass Stab", "Soft Organ", "Last of page 1", "First of page 2", "Page 2 pad"};
    for (int i = 0; i < 10; ++i) CHECK(controller.writeCombiToList(listPos[i], listNames[i]) >= 0);

    // SILVETON_ONLY_OLD_V1: the program opens with the OLD look; the checks below are of the new screens, which are switched off in the program
    CHECK(controller.uiTheme() == 4);
    {
        SilvetonSamplerView first(controller);
        CHECK(ViewTestAccess::classicView(first) != nullptr);
    }
    controller.setUiTheme(0);
    SilvetonSamplerView view(controller);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    view.refreshAllForTests();
    using TA = ViewTestAccess;
    using Tab = TA::Tab;

    shot(view, "combi");                                   // the COMBI page as it opens (TUNE of Upper 1)
    TA::edit(view, 0, 0, Tab::TONE);       shot(view, "combi_tone");
    TA::edit(view, 0, 0, Tab::WAVE);       shot(view, "combi_wave_off");
    CHECK(controller.setSoundWaveParam(0, 0, 0, 1.0F)); CHECK(controller.setSoundWaveParam(0, 0, 6, 1.0F)); CHECK(controller.setSoundWaveParam(0, 0, 3, 0.2F));
    view.refreshAllForTests(); TA::edit(view, 0, 0, Tab::WAVE); shot(view, "combi_wave_auto");
    CHECK(controller.setSoundWaveParam(0, 0, 0, 2.0F)); CHECK(controller.setSoundWaveParam(0, 0, 6, 2.0F));
    CHECK(controller.setSoundWaveParam(0, 0, 10, static_cast<float>(catalog[28].slot))); CHECK(controller.setSoundWaveParam(0, 0, 11, static_cast<float>(catalog[31].slot))); CHECK(controller.setSoundWaveParam(0, 0, 12, static_cast<float>(catalog[32].slot)));
    view.refreshAllForTests(); TA::edit(view, 0, 0, Tab::WAVE); shot(view, "combi_wave_multi");
    TA::picker(view, 0, 100 + 3);          // the picker of frame 4 of MULTI
    TA::pickerAssignItem(view, catalog[5]);
    CHECK(static_cast<int>(controller.soundWaveParams(0, 0)[13]) == catalog[5].slot);   // slot 4 = id 13
    shot(view, "combi_wave_picker");
    TA::pickerAssignItem(view, catalog[6]);
    CHECK(static_cast<int>(controller.soundWaveParams(0, 0)[13]) == catalog[6].slot);
    TA::closePicker(view);
    CHECK(controller.setSoundWaveParam(0, 0, 0, 0.0F));
    view.refreshAllForTests();
    TA::edit(view, 0, 0, Tab::RANGE);      shot(view, "combi_range");
    {   // SILVETON_KEYRANGE_V1 + SILVETON_VELOCITY_V1: RANGE = the keys only; VEL = the five sounds on one scale, curves, fades, crossfade
        using P = SilvetonSamplerView::PointerAction;
        Canvas cv(1340, 800);
        // (the numbers below are in the units of the older page; TA::ex / ey put them where the new frame shows it)
        const auto press = [&](float x, float y) { view.draw(cv); view.pointer(P::Down, TA::ex(x), TA::ey(y)); view.pointer(P::Up, TA::ex(x), TA::ey(y)); view.draw(cv); };
        const auto drag = [&](float x0, float y0, float x1, float y1) {
            view.draw(cv);
            view.pointer(P::Down, TA::ex(x0), TA::ey(y0));
            for (int i = 1; i <= 6; ++i) {
                const float t = static_cast<float>(i) / 6.0F;
                view.pointer(P::Move, TA::ex(x0 + (x1 - x0) * t), TA::ey(y0 + (y1 - y0) * t));
                view.draw(cv);
            }
            view.pointer(P::Up, TA::ex(x1), TA::ey(y1));
            view.draw(cv);
        };
        // ---- RANGE has no velocity any more; the key ends of a layer are dragged on its row
        TA::edit(view, 0, 1, Tab::RANGE);
        view.refreshAllForTests();
        shot(view, "combi_range_layer");
        CHECK(static_cast<int>(controller.layerParams(0, 0)[6]) == 0);
        drag(940.0F, 626.0F, 1018.19F, 626.0F);                               // L1: the lowest key to 36
        CHECK(static_cast<int>(controller.layerParams(0, 0)[6]) == 36);
        CHECK(static_cast<int>(controller.layerParams(0, 0)[7]) == 127);
        CHECK(TA::editSoundOf(view) == 1);
        press(910.0F, 662.0F);                                                // the label of L2: the page now edits L2
        CHECK(TA::editSoundOf(view) == 2);
        press(910.0F, 590.0F);                                                // ... and the label of ОСН
        CHECK(TA::editSoundOf(view) == 0);
        // the key ends by playing: a tap, then the key on the MIDI keyboard (the second tap cancels)
        press(620.0F, 557.0F);
        CHECK(controller.keyScanUpper() == 0 && controller.keyScanEdge() == 0 && controller.keyScanSound() == 0);
        press(620.0F, 557.0F);
        CHECK(controller.keyScanUpper() < 0);
        press(790.0F, 557.0F);
        CHECK(controller.keyScanUpper() == 0 && controller.keyScanEdge() == 1);
        press(790.0F, 557.0F);
        CHECK(controller.keyScanUpper() < 0);
        CHECK(controller.setLayerParam(0, 0, 6, 0.0F));                       // L1 back to the whole keyboard

        // ---- VEL: L1 goes out at 80 over 20 steps, L2 comes in from 60 over 20 steps, both crossfade
        CHECK(controller.setLayerParam(0, 0, 9, 80.0F)); CHECK(controller.setLayerParam(0, 0, 33, 20.0F)); CHECK(controller.setLayerParam(0, 0, 47, 1.0F));
        CHECK(controller.setLayerParam(0, 1, 8, 60.0F)); CHECK(controller.setLayerParam(0, 1, 32, 20.0F)); CHECK(controller.setLayerParam(0, 1, 47, 1.0F));
        view.refreshAllForTests();
        TA::edit(view, 0, 1, Tab::VELOCITY);  shot(view, "combi_vel");
        CHECK(static_cast<int>(controller.layerParams(0, 0)[33]) == 20 && static_cast<int>(controller.layerParams(0, 0)[32]) == 0);   // the fades are where the page reads them
        drag(426.5F, 626.0F, 473.1F, 626.0F);                                  // the highest value of L1 to 100
        CHECK(static_cast<int>(controller.layerParams(0, 0)[9]) == 100);
        press(160.0F, 662.0F);                                                // L2 (the label of row 2)
        CHECK(TA::editSoundOf(view) == 2);
        const float fadeBefore = controller.layerParams(0, 1)[32];
        drag(1005.0F, 589.0F, 1005.0F, 529.0F);                                // the FADE IN chip, dragged up
        CHECK(controller.layerParams(0, 1)[32] > fadeBefore);
        press(780.0F, 712.0F);                                                 // the ready curve HARD
        CHECK(static_cast<int>(controller.layerParams(0, 1)[35]) == 2);
        drag(747.0F, 630.0F, 747.0F, 600.0F);                                  // a drag on the graph = the own curve, starting like HARD
        CHECK(static_cast<int>(controller.layerParams(0, 1)[35]) == 6);
        CHECK(std::abs(controller.layerParams(0, 1)[36 + 4] - 103.0F) <= 1.5F);
        shot(view, "combi_vel_custom");
        press(1200.0F, 733.0F); press(1200.0F, 733.0F);                        // НУЛИРАЙ (double tap)
        CHECK(static_cast<int>(controller.layerParams(0, 1)[35]) == 0 && static_cast<int>(controller.layerParams(0, 1)[32]) == 0);
        CHECK(static_cast<int>(controller.layerParams(0, 1)[8]) == 60);        // the range stays
        // ОСНОВЕН: the same page reads and writes the Upper's own ids (50.., 55..)
        TA::edit(view, 0, 0, Tab::VELOCITY);
        press(780.0F, 712.0F);                                                 // HARD
        CHECK(static_cast<int>(controller.upperParams(0)[55]) == 2);
        press(1004.0F, 733.0F);                                                // САМОСТ. L1–L4 (toggle)
        CHECK(controller.upperParams(0)[54] < 0.5F);
        press(1004.0F, 733.0F);
        CHECK(controller.upperParams(0)[54] >= 0.5F);
        press(1200.0F, 697.0F);                                                // КРОСФЕЙД of ОСНОВЕН
        CHECK(controller.upperParams(0)[67] >= 0.5F);
        shot(view, "combi_vel_basic");
        CHECK(controller.setUpperParam(0, 55, 0.0F)); CHECK(controller.setUpperParam(0, 67, 0.0F));
        CHECK(controller.setLayerParam(0, 0, 9, 127.0F)); CHECK(controller.setLayerParam(0, 0, 33, 0.0F)); CHECK(controller.setLayerParam(0, 0, 47, 0.0F));
        CHECK(controller.setLayerParam(0, 1, 8, 1.0F)); CHECK(controller.setLayerParam(0, 1, 47, 0.0F));
        view.refreshAllForTests();
        TA::edit(view, 0, 0, Tab::RANGE);
    }
    TA::edit(view, 3, 0, Tab::TUNE);       shot(view, "combi_tune_u4");
    TA::edit(view, 0, 1, Tab::TUNE);       shot(view, "combi_layer");
    TA::common(view, 0, Tab::PORTA);       shot(view, "combi_porta");
    {   // SILVETON_BASS_PORTA_V1: the VOICE page with the BASS portamento on, then back to SILVETON for the pictures that follow
        CHECK(controller.setUpperParam(0, 42, 3.0F)); view.refreshAllForTests();
        TA::common(view, 0, Tab::PORTA);   shot(view, "combi_porta_bass");
        CHECK(controller.setUpperParam(0, 42, 0.0F)); view.refreshAllForTests();
    }
    TA::common(view, 0, Tab::CONTROL);     shot(view, "combi_control");
    TA::common(view, 0, Tab::FX);          shot(view, "combi_fx");
    {   // SILVETON_ENGINES_V1: the ENGINE page - OFF, then a few engines and their three pages
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_off");
        CHECK(controller.setUpperEngineParam(0, 0, 7.0F)); view.refreshAllForTests();      // CX-3
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_cx3");
        CHECK(controller.setUpperEngineParam(0, 0, 2.0F)); view.refreshAllForTests();      // POLYSIX
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_polysix");
        TA::enginePage(view, 1);           shot(view, "combi_engine_filter");
        TA::enginePage(view, 2);           shot(view, "combi_engine_mod");
        TA::enginePage(view, 3);           shot(view, "combi_engine_ofs");   // SILVETON_OFS_V1
        TA::enginePage(view, 100);         shot(view, "combi_engine_select");   // SILVETON_UI_KRONOS_V1: the page ДВИГАТЕЛ
        TA::enginePage(view, 101);         shot(view, "combi_engine_output");   // the page ИЗХОД
        TA::enginePage(view, 0);
        CHECK(controller.setUpperEngineParam(0, 0, 3.0F)); view.refreshAllForTests();      // MS-20
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_ms20");
        CHECK(controller.setUpperEngineParam(0, 0, 5.0F)); view.refreshAllForTests();      // MOD-7
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_mod7");
        CHECK(controller.setUpperEngineParam(0, 0, 6.0F)); view.refreshAllForTests();      // STR-1
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_str1");
        CHECK(controller.setUpperEngineParam(0, 0, 8.0F)); view.refreshAllForTests();      // SGX
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_sgx");
        CHECK(controller.setUpperEngineParam(0, 0, 9.0F)); view.refreshAllForTests();      // EP
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_ep");
        CHECK(controller.setUpperEngineParam(0, 0, 4.0F)); view.refreshAllForTests();      // AL-1
        TA::common(view, 0, Tab::ENGINE);  shot(view, "combi_engine_al1");
        TA::theme(view, true);             shot(view, "combi_engine_dark");
        TA::theme(view, false);
        CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();      // back to OFF for the pictures that follow
    }
    TA::common(view, 0, Tab::EQ);          shot(view, "combi_eq");
    TA::edit(view, 0, 0, Tab::TUNE);
    TA::theme(view, true);                 shot(view, "combi_dark");          // the ТЪМНА theme of the settings
    TA::common(view, 0, Tab::PORTA);       shot(view, "combi_dark_voice");
    TA::theme(view, false);
    TA::edit(view, 0, 0, Tab::TUNE);
    TA::dropdown(view, 0);                 shot(view, "combi_dropdown");
    TA::dropdown(view, -1);
    TA::mark(view, true, 0, 2);            shot(view, "combi_marked");
    TA::mark(view, false, 0, 2);
    {   // SILVETON_COMBI_DROP_V1: a SOUND of the Manager dropped into each of the 35 places of the COMBI page
        CHECK(view.prepareComboDrop());
        const auto slots = view.comboSlots();
        CHECK(slots.size() == 35U);
        for (const auto& s : slots) {
            CHECK(s.right - s.left > 100.0F && s.bottom - s.top > 50.0F);
            CHECK(s.left >= 10.0F && s.right <= 1330.0F && s.top >= 80.0F && s.bottom <= 736.0F);   // inside the strips (SILVETON_PRO_UI_V1)
            int hits = 0;
            for (const auto& other : slots) if (other.contains((s.left + s.right) * 0.5F, (s.top + s.bottom) * 0.5F)) ++hits;
            CHECK(hits == 1);                                  // every point belongs to one place only
        }
        CHECK(slots[0].label == "ОСНОВЕН" && slots[4].label == "L4");
        CHECK(slots[0].sound == "Grand Piano");                // Upper 1: ОСНОВЕН
        CHECK(slots[1].sound == "String Ensemble");            // L1
        CHECK(slots[2].sound == "Soft Strings");               // L2
        CHECK(slots[3].sound.empty() && slots[4].sound.empty());
        CHECK(slots[30].sound.empty());                        // Upper 7 is empty
        CHECK(view.dropSoundIntoSlot(0, 3, catalog[1].slot, catalog[1].name));        // L3 of Upper 1 (an empty layer)
        CHECK(controller.layerName(0, 2) == catalog[1].name);
        CHECK(controller.layerName(0, 0) == "String Ensemble" && controller.layerName(0, 1) == "Soft Strings");   // the others stay
        CHECK(view.dropSoundIntoSlot(0, 2, catalog[19].slot, catalog[19].name));      // L2 replaced
        CHECK(controller.layerName(0, 1) == catalog[19].name && controller.layerName(0, 0) == "String Ensemble");
        CHECK(view.dropSoundIntoSlot(0, 0, catalog[5].slot, catalog[5].name));        // ОСНОВЕН replaced
        CHECK(controller.upperState(0).has_value() && controller.upperState(0)->soundName == catalog[5].name);
        CHECK(view.dropSoundIntoSlot(6, 4, catalog[7].slot, catalog[7].name));        // L4 of the empty Upper 7
        CHECK(controller.layerName(6, 3) == catalog[7].name);
        CHECK(!view.dropSoundIntoSlot(0, 5, catalog[1].slot, "x") && !view.dropSoundIntoSlot(7, 0, catalog[1].slot, "x"));
        CHECK(!view.dropSoundIntoSlot(0, 0, 0, "x") && !view.dropSoundIntoSlot(0, 0, 501, "x"));
        const auto after = view.comboSlots();
        CHECK(after.size() == 35U && after[0].sound == catalog[5].name && after[2].sound == catalog[19].name && after[3].sound == catalog[1].name && after[34].sound == catalog[7].name);
        shot(view, "combi_after_drop");
        {   // SILVETON_LAYER_MOVE_V1: the sound field of the strip is the handle; copy and move between places
            const float fieldX = 10.0F + 60.0F;                                           // SILVETON_PRO_UI_V1: the strips of the new frame
            const auto src = view.layerSourceAt(fieldX, 80.0F + 55.0F);                  // the strip of Upper 1 shows ОСНОВЕН
            CHECK(src.has_value() && src->upper == 0 && src->slot == 0 && src->name == catalog[5].name && src->sound == catalog[5].slot);
            CHECK(!view.layerSourceAt(fieldX, 80.0F + 200.0F).has_value());               // not on the sound field
            CHECK(!view.layerSourceAt(5.0F, 150.0F).has_value());                         // outside the strips
            const float field7 = 10.0F + 6.0F * ((1320.0F - 36.0F) / 7.0F + 6.0F) + 60.0F;
            const auto src7 = view.layerSourceAt(field7, 80.0F + 55.0F);                  // the strip of Upper 7 shows L4 (the drop selected it)
            CHECK(src7.has_value() && src7->upper == 6 && src7->slot == 4 && src7->name == catalog[7].name);
            CHECK(controller.setLayerParam(1, 2, 1, -6.0F));                              // L3 of Upper 2 has its own level
            CHECK(view.moveLayerSound(0, 0, 1, 3, true));                                 // COPY ОСНОВЕН of Upper 1 -> L3 of Upper 2
            CHECK(controller.layerName(1, 2) == catalog[5].name && controller.upperState(0)->soundName == catalog[5].name);
            CHECK(std::fabs(controller.layerParams(1, 2)[1] - (-6.0F)) < 0.001F);          // the settings of the place stayed
            CHECK(view.moveLayerSound(0, 2, 2, 4, false));                                // MOVE L2 of Upper 1 -> L4 of Upper 3
            CHECK(controller.layerName(2, 3) == catalog[19].name);
            CHECK(controller.layerParams(0, 1)[31] == 0.0F);                              // L2 of Upper 1 is empty now
            CHECK(controller.layerName(0, 0) == "String Ensemble");                       // the others stay
            CHECK(!view.moveLayerSound(0, 2, 2, 4, false));                               // the source is empty: nothing to move
            CHECK(!view.moveLayerSound(2, 4, 2, 4, false) && !view.moveLayerSound(0, 0, 0, 5, false) && !view.moveLayerSound(7, 0, 0, 1, false));
            CHECK(view.moveLayerSound(6, 4, 6, 0, false));                                // MOVE L4 of Upper 7 -> ОСНОВЕН of Upper 7
            CHECK(controller.upperState(6)->soundName == catalog[7].name && controller.layerParams(6, 3)[31] == 0.0F);
            CHECK(view.moveLayerSound(6, 0, 3, 1, true));                                 // COPY ОСНОВЕН of Upper 7 -> L1 of Upper 4
            CHECK(controller.layerName(3, 0) == catalog[7].name);
            shot(view, "combi_after_move");
            CHECK(controller.setLayerSound(1, 2, 0));
            CHECK(controller.setLayerParam(1, 2, 1, 0.0F));
            CHECK(controller.setLayerSound(2, 3, 0));
            CHECK(controller.setLayerSound(3, 0, 0));
            CHECK(controller.clearUpperSound(6));
        }
        // back to the COMBI the following pictures expect
        CHECK(view.dropSoundIntoSlot(0, 0, catalog[0].slot, catalog[0].name));
        CHECK(view.dropSoundIntoSlot(0, 2, catalog[9].slot, catalog[9].name));
        CHECK(controller.setLayerSound(0, 2, 0));
        CHECK(controller.setLayerSound(6, 3, 0));
        view.refreshAllForTests();
        TA::edit(view, 0, 0, Tab::TUNE);
    }
    TA::picker(view, 0, -1);               shot(view, "combi_picker");
    TA::pickerMark(view, true, {catalog[1].slot, catalog[3].slot, catalog[8].slot});   shot(view, "combi_picker_mark");   // SILVETON_MULTI_DELETE_V1
    TA::pickerMark(view, false, {});
    TA::pickerPage(view, 1);               shot(view, "combi_picker_empty");   // SILVETON_SOUND_BY_NUMBER_V2: page 2 = places 041..080, the empty ones shown
    TA::pickerPage(view, 0);
    TA::closePicker(view);
    TA::numberDialog(view);                shot(view, "dialog_number");
    TA::closeDialogs(view);
    TA::textDialog(view);                  shot(view, "dialog_text");
    TA::closeDialogs(view);

    // The tablet has no keyboard of its own: the dialogs draw one (Latin / Bulgarian БДС letters, digits).
    TA::softKeyboard(view, true);
    TA::textDialog(view);                  shot(view, "dialog_text_kb");
    CHECK(TA::keyCount(view) > 30U);
    CHECK(TA::pressKey(view, "ИЗЧИСТИ"));  CHECK(TA::dialogValue(view).empty());
    CHECK(TA::pressKey(view, "P"));        CHECK(TA::dialogValue(view) == "P");       // a capital at the start of the sentence
    CHECK(TA::pressKey(view, "i"));        CHECK(TA::dialogValue(view) == "Pi");
    CHECK(TA::pressKey(view, "SHIFT"));                                                  // one capital
    CHECK(TA::pressKey(view, "A"));        CHECK(TA::dialogValue(view) == "PiA");
    CHECK(TA::pressKey(view, "n"));        CHECK(TA::dialogValue(view) == "PiAn");
    CHECK(TA::pressKey(view, "DELETE"));        CHECK(TA::dialogValue(view) == "PiA");
    CHECK(TA::pressKey(view, "EN"));                                                   // the Bulgarian letters
    shot(view, "dialog_text_kb_bg");
    CHECK(TA::pressKey(view, "ИЗЧИСТИ"));
    CHECK(TA::pressKey(view, "П"));        CHECK(TA::pressKey(view, "р"));  CHECK(TA::pressKey(view, "и"));
    CHECK(TA::pressKey(view, "в"));        CHECK(TA::pressKey(view, "е"));  CHECK(TA::pressKey(view, "т"));
    CHECK(TA::dialogValue(view) == "Привет");
    CHECK(TA::pressKey(view, " "));        CHECK(TA::pressKey(view, "ю"));  CHECK(TA::pressKey(view, "щ"));
    CHECK(TA::dialogValue(view) == "Привет ющ");
    CHECK(TA::pressKey(view, "БГ"));
    shot(view, "dialog_text_kb_end");
    TA::closeDialogs(view);
    TA::numberDialog(view);                shot(view, "dialog_number_kb");
    CHECK(TA::pressKey(view, "ИЗЧИСТИ"));
    CHECK(TA::pressKey(view, "1"));        CHECK(TA::pressKey(view, "2"));  CHECK(TA::pressKey(view, "."));
    CHECK(TA::pressKey(view, "5"));        CHECK(TA::pressKey(view, "±"));
    CHECK(TA::dialogValue(view) == "-12.5");
    CHECK(TA::pressKey(view, "±"));        CHECK(TA::dialogValue(view) == "12.5");
    CHECK(TA::pressKey(view, "DELETE"));        CHECK(TA::dialogValue(view) == "12.");
    TA::closeDialogs(view);
    TA::softKeyboard(view, false);
    TA::textDialog(view);
    CHECK(TA::keyCount(view) == 0U || (TA::pressKey(view, "q") == false));         // no keyboard when it is not asked for
    shot(view, "dialog_text");
    TA::closeDialogs(view);
    view.showToast("MASTER +2 dB");        shot(view, "toast");
    CHECK(TA::pairCheck(view, controller)); // a second finger on the + of a - / + pair = reset
    TA::soundGrid(view);                   shot(view, "dialog_grid");
    TA::closeDialogs(view);
    TA::confirm(view);                     shot(view, "dialog_confirm");
    TA::closeDialogs(view);
    TA::items(view);                       shot(view, "dialog_items");
    TA::closeDialogs(view);

    // LIST and WRITE
    view.setPage(SilvetonSamplerView::Page::LIST);
    TA::listFav(view, 2); TA::listFav(view, 12);
    view.refreshAllForTests();
    shot(view, "list");
    TA::listSelect(view, 5);               shot(view, "list_selected");
    TA::listMark(view, true, {30, 45});    shot(view, "list_mark");       // SILVETON_MULTI_DELETE_V1 (page 2 is shown)
    TA::listMark(view, false, {});
    TA::listMenu(view, 2);                 shot(view, "list_menu");
    TA::closeDialogs(view);
    TA::storeDialog(view);                 shot(view, "list_store");
    TA::closeDialogs(view);
    TA::openCopy(view, 2);                 shot(view, "write_copy");
    TA::closeWrite(view);
    TA::openWriteScreen(view, false);      shot(view, "write_list");
    TA::openWriteScreen(view, true);       shot(view, "write_blend");
    TA::closeWrite(view);
    TA::search(view, "pad");               shot(view, "list_search");
    TA::search(view, "");
    TA::favOnly(view, true);               shot(view, "list_favs");
    TA::favOnly(view, false);

    // EFFECTS
    view.setPage(SilvetonSamplerView::Page::EFFECTS);
    TA::fx(view, 0, 4);                    shot(view, "effects_hall");
    TA::fx(view, 1, 1);                    shot(view, "effects_delay");
    TA::fx(view, 2, 14);                   shot(view, "effects_rotary");
    TA::fx(view, 3, 15);                   shot(view, "effects_comp");
    TA::focus(view, 5);                    shot(view, "effects_insert_off");
    TA::focus(view, 0);

    // SETTINGS
    view.setPage(SilvetonSamplerView::Page::SETTINGS);
    TA::settingsTab(view, 0);              shot(view, "settings");
    TA::settingsTab(view, 1);              shot(view, "settings_midi");
    TA::settingsTab(view, 2);              shot(view, "settings_info");
    TA::deleteSounds(view);                shot(view, "settings_delete");
    TA::closeDialogs(view);
    TA::settingsTab(view, 0);
    // SILVETON_PRO_UI_V1: the screens in ENGLISH (SETTINGS > LANGUAGE), then back to БЪЛГАРСКИ
    TA::language(view, 1);                 shot(view, "settings_en");
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "combi_en");
    CHECK(controller.setUpperEngineParam(0, 0, 4.0F)); view.refreshAllForTests();
    TA::common(view, 0, Tab::ENGINE);      shot(view, "combi_engine_en");
    CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();
    TA::common(view, 0, Tab::FX);          shot(view, "effects_en");
    view.setPage(SilvetonSamplerView::Page::LIST);
    shot(view, "list_en");
    TA::language(view, 0);
    CHECK(controller.uiLanguage() == 0);
    view.setPage(SilvetonSamplerView::Page::SETTINGS);

    // SILVETON_THEMES_V1: the three themes (ГРАФИТ is every picture above), the choice is kept
    TA::uiTheme(view, 1);                  shot(view, "theme_light_settings");
    CHECK(controller.uiTheme() == 1);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "theme_light_mixer");
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_light_engine");
    view.setPage(SilvetonSamplerView::Page::LIST);
    shot(view, "theme_light_list");
    TA::uiTheme(view, 2);                  shot(view, "theme_black_list");
    CHECK(controller.uiTheme() == 2);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "theme_black_mixer");
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_black_engine");
    view.setPage(SilvetonSamplerView::Page::SETTINGS);
    shot(view, "theme_black_settings");
    TA::uiTheme(view, 3);                  shot(view, "theme_classic_settings");
    CHECK(controller.uiTheme() == 3);
    view.setPage(SilvetonSamplerView::Page::COMBI);
    TA::common(view, 0, Tab::MIXER);       shot(view, "theme_classic_mixer");
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_classic_engine");
    CHECK(controller.setUpperEngineParam(0, 0, 6.0F)); view.refreshAllForTests();      // STR-1 on a page of knobs
    TA::enginePage(view, 0);
    TA::common(view, 0, Tab::ENGINE);      shot(view, "theme_classic_str1");
    CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); view.refreshAllForTests();
    TA::enginePage(view, 100);
    view.setPage(SilvetonSamplerView::Page::LIST);
    shot(view, "theme_classic_list");
    // SILVETON_OLD_THEME_V1: the whole OLD look as a theme (СТАРА), and the way back from its SETTINGS page
    TA::uiTheme(view, 4);
    CHECK(controller.uiTheme() == 4);
    CHECK(TA::classicView(view) != nullptr);
    {
        using Old = classic::SilvetonSamplerView;
        Old* old = TA::classicView(view);
        old->setPage(Old::Page::COMBI);      shot(view, "theme_old_combi");
        CHECK(controller.setUpperEngineParam(0, 0, 2.0F)); old->refreshAllForTests();      // POLYSIX under the old mixer
        classic::ViewTestAccess::engineTab(*old);  shot(view, "theme_old_engine");
        CHECK(controller.setUpperEngineParam(0, 0, 0.0F)); old->refreshAllForTests();
        old->setPage(Old::Page::LIST);       shot(view, "theme_old_list");
        old->setPage(Old::Page::EFFECTS);    shot(view, "theme_old_effects");
        old->setPage(Old::Page::SETTINGS);   shot(view, "theme_old_settings");
    }
    {   // SILVETON_ONLY_OLD_V1: the old SETTINGS page has no way back to the new screens (where НОВИ ТЕМИ was, a touch does nothing);
        // the new screens (switched off in the program) still answer СТАРА on their SETTINGS page
        using PA = SilvetonSamplerView::PointerAction;
        view.pointer(PA::Down, 1060.0F, 651.0F);
        view.pointer(PA::Up, 1060.0F, 651.0F);
        CHECK(controller.uiTheme() == 4);
        CHECK(TA::classicView(view) != nullptr);
        TA::uiTheme(view, 1);
        CHECK(TA::classicView(view) == nullptr);
        view.setPage(SilvetonSamplerView::Page::SETTINGS);
        TA::settingsTab(view, 0);
        shot(view, "theme_back_light_settings");
        view.pointer(PA::Down, 1087.0F, 709.0F);
        view.pointer(PA::Up, 1087.0F, 709.0F);
        CHECK(controller.uiTheme() == 4);
        CHECK(TA::classicView(view) != nullptr);
        Canvas again(1340, 800);
        view.draw(again);                                   // the old look draws and answers
        view.setWarning("TEST");                            // a warning of the shell reaches the old look on the drawing thread
        CHECK(view.redrawDue(0));
        view.draw(again);
        view.setWarning("");
    }
    TA::uiTheme(view, 0);
    CHECK(controller.uiTheme() == 0);
    CHECK(TA::classicView(view) == nullptr);
    TA::common(view, 0, Tab::MIXER);

    // a click on a control: PAN of Upper 1 double-click = reset; the level key of Upper 1
    view.pointer(SilvetonSamplerView::PointerAction::Down, 140.0F, 200.0F);
    view.pointer(SilvetonSamplerView::PointerAction::Up, 140.0F, 200.0F);
    // a finger dragging over the screen: only the parts under it should be drawn again
    {
        long long dragPictures = 0, dragRepainted = 0;
        double dragMs = 0.0;
        view.pointer(SilvetonSamplerView::PointerAction::Down, 140.0F, 300.0F);
        for (int i = 0; i < 20; ++i) {
            view.pointer(SilvetonSamplerView::PointerAction::Move, 140.0F + 3.0F * static_cast<float>(i), 300.0F + 2.0F * static_cast<float>(i));
            const auto t0 = std::chrono::steady_clock::now();
            g_light.update([&](Canvas& c) { view.draw(c); });
            dragMs += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
            ++dragPictures;
            dragRepainted += g_light.lastRepaintedPixels();
            Canvas full(1340, 800);
            full.replay(g_light.lastList(), IRect(0, 0, 1340, 800));
            long long different = 0;
            for (std::size_t k = 0U; k < full.buffer().size(); ++k) if (full.buffer()[k] != g_light.picture().buffer()[k]) ++different;
            CHECK(different == 0);
        }
        view.pointer(SilvetonSamplerView::PointerAction::Up, 200.0F, 340.0F);
        std::printf("light drawing, finger dragging: %.1f %% of the picture drawn again per picture, %.2f ms per picture\n",
                    100.0 * static_cast<double>(dragRepainted) / (static_cast<double>(dragPictures) * 1340.0 * 800.0), dragMs / static_cast<double>(dragPictures));
    }
    std::printf("light drawing, all %lld pictures exact. While nothing is touched: %.2f %% of the picture drawn again, %.2f ms per picture (all pictures: %.2f %%)\n",
                g_lightPictures, 100.0 * static_cast<double>(g_lightIdleRepainted) / (static_cast<double>(std::max<long long>(1, g_lightIdlePictures)) * 1340.0 * 800.0),
                g_lightIdleMs / static_cast<double>(std::max<long long>(1, g_lightIdlePictures)),
                100.0 * static_cast<double>(g_lightRepainted) / (static_cast<double>(std::max<long long>(1, g_lightPictures)) * 1340.0 * 800.0));
    controller.close();
    // SILVETON_GFX_SAFE_POLY_V1: no screen of the test may hand the rasterizer a coordinate that is not a number
    std::printf("polygons with a coordinate that is not a number: %lu\n", silveton::ui::badPolygonCount());
    CHECK(silveton::ui::badPolygonCount() == 0UL);
    std::printf("view render test OK\n");
    return 0;
}
